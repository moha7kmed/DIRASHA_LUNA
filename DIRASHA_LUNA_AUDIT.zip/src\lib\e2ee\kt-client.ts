/**
 * Dirasha E2EE — Key Transparency client verification (Project 2 / F7).
 *
 * Browser-side mirror of the server's RFC-6962-style proof math
 * (src/server/services/key_transparency.ts — the server module uses node:crypto;
 * this file re-implements the SAME hashing with @noble/hashes so it runs in the
 * browser). The math is mirrored BYTE-FOR-BYTE:
 *
 *   leaf  = sha256(0x00 || UTF8('<seq>|<userId>|<commitment>'))   → lowercase hex
 *   node  = sha256(0x01 || UTF8(left) || UTF8(right))             → lowercase hex
 *   empty tree root = sha256('')                                  → lowercase hex
 *
 * All hashes on the KT wire are LOWERCASE HEX (the server's COMMITMENT_RE and
 * the snapshot rootHash shape). Inclusion proofs follow the RFC-6962/RFC-9162
 * split rule exactly like the server's verifyInclusionProof: a subtree of size
 * s ≥ 2 splits into a perfect left half of k = largest power of two strictly
 * less than s leaves; the auth path is ordered leaf-up (path[0] closest to the
 * leaf) and positions are fully determined by (leafIndex, treeSize) — the
 * attacker controls only sibling VALUES, never positions.
 *
 * NO `Buffer` anywhere: all byte handling is Uint8Array + TextEncoder, and
 * base64 goes through the engine crypto helpers (btoa/atob fallback chain in
 * crypto.ts) so this module works in a browser without node polyfills (F7).
 *
 * Verification contract (v1 deployment — availability first):
 *   - Proof FETCH failure (network / 429 / 5xx) is NOT tampering evidence:
 *     the result is { ok: true, mode: 'unavailable' } and NO flag is raised
 *     (a rate-limit drain must not turn into a permanent warning banner).
 *   - mode === 'unverified' (no KT_SIGNING_KEY server-side, signature ''):
 *     the root is NOT witness-signed, so proof math against it proves nothing
 *     beyond server self-consistency → documented HONEST mode, returns
 *     { ok: true, mode: 'unverified' } and does NOT flag (every deployment
 *     without a witness key would otherwise flag forever). The engine still
 *     surfaces the mode via the result object for any UI that wants it.
 *   - A VERIFIED-mode snapshot whose signature fails against the pinned
 *     witness public key, or an inclusion proof / leaf-hash / commitment
 *     MISMATCH → { ok: false } — the caller (engine.fetchPeerDevices) raises
 *     the per-peer KT flag (localStorage 'ktFlag:<peer>') and warns loudly.
 *     NEVER blocks the bundle: the fetched keys stay usable (loud + visible,
 *     not a lockout).
 *   - CONSISTENCY + ANCHORING (fork/rollback defense): the last seen
 *     (treeVersion, rootHash) is persisted per peer under 'ktLast:<peer>'.
 *     Every subsequent proof request carries ?sinceVersion=<anchored v> and
 *     the server (routes/kt.ts) returns the RFC-6962/RFC-9162 consistency
 *     proof between the anchored and current roots. On the client:
 *       * treeVersion < anchored  → ROLLBACK → { ok: false } (old logs are
 *         never accepted once a newer snapshot was anchored, in ANY mode);
 *       * treeVersion === anchored && root differs → fork → { ok: false };
 *       * treeVersion > anchored  → verifyConsistency() must hold between the
 *         two roots — missing/garbage proof → { ok: false, reason: 'malformed'
 *         }, failed math → { ok: false, reason: 'fork-detected' }.
 *     The anchor advances ONLY on ok:true outcomes with a valid snapshot.
 *     Availability-first applies to TRANSPORT failures only — a signed
 *     contradiction is always flagged.
 *   - TOFU: the first observed snapshot is trusted; verifyRootProgression
 *     anchors later observations to it (fork detection on same-version
 *     divergence).
 *   - DAMAGED PROOFS: malformed/short/garbage proofs never throw past this
 *     module's boundary — verifyConsistency / verifyFleetInclusion /
 *     verifyInclusionProof all return false for garbage input, and
 *     fetchAndVerifyFleetProof turns every outcome into a result object.
 *   - MONITORING: every { ok: false } outcome and every client-side rate-limit
 *     trip emits a metadata-only security event through the App bridge
 *     (notifySecurityEvent → window.pushSecurityEvent; no-op when absent).
 *     No message or user content ever crosses this boundary.
 */

import { sha256 } from '@noble/hashes/sha256';
import { b64decode, b64encode, ed25519Verify, utf8Encode } from './crypto.ts';
import type { KtMode, KtProofResponse } from '../kt-contract.ts';

/* ── Hashing primitives (byte-exact mirror of key_transparency.ts) ────────── */

const enc = new TextEncoder();

function hexOf(bytes: Uint8Array): string {
  let s = '';
  for (let i = 0; i < bytes.length; i++) s += bytes[i].toString(16).padStart(2, '0');
  return s;
}

function sha256Bytes(...parts: Uint8Array[]): Uint8Array {
  // @noble/hashes 1.x: sha256 over a single concatenated input
  let total = 0;
  for (const p of parts) total += p.length;
  const buf = new Uint8Array(total);
  let off = 0;
  for (const p of parts) {
    buf.set(p, off);
    off += p.length;
  }
  return sha256(buf);
}

/** RFC-6962-style leaf hash (server ktLeafHash): H(0x00 || '<seq>|<userId>|<commitment>') → hex. */
export function ktLeafHash(seq: number, userId: string, commitment: string): string {
  return hexOf(sha256Bytes(new Uint8Array([0x00]), enc.encode(`${seq}|${userId}|${commitment}`)));
}

/** RFC-6962-style internal node hash (server ktNodeHash): H(0x01 || left || right) → hex. */
export function ktNodeHash(left: string, right: string): string {
  return hexOf(sha256Bytes(new Uint8Array([0x01]), enc.encode(left), enc.encode(right)));
}

/** Empty-tree root (RFC 6962 convention: sha256 of the empty string) — hex. */
export const KT_EMPTY_ROOT = hexOf(sha256Bytes(new Uint8Array(0)));

/** Largest power of two strictly less than size (size ≥ 2). RFC split rule (server mirror). */
export function largestPow2LessThan(size: number): number {
  if (!Number.isInteger(size) || size < 2) throw new Error('size must be an integer ≥ 2');
  let k = 1;
  while (k * 2 < size) k *= 2;
  return k;
}

/* ── Inclusion proof verification (exact server verifyInclusionProof mirror) ─ */

/**
 * Verify an RFC-6962-style inclusion proof against the snapshot root. The
 * split structure from root to leaf is fully determined by (leafIndex,
 * treeSize) — two phases, identical to the server:
 *   (1) walk root→leaf recording which half the leaf falls into per split;
 *   (2) fold leaf-up (DEEPEST split's sibling is authPath[0]) combining each
 *       sibling on the correct side until the root is recomputed.
 *
 * `authPath` is the server wire shape: hex sibling hashes ordered leaf-up.
 */
export function verifyInclusionProof(
  leafIndex: number,
  treeSize: number,
  leafHash: string,
  authPath: string[],
  root: string,
): boolean {
  if (!Number.isInteger(leafIndex) || !Number.isInteger(treeSize)) return false;
  if (treeSize < 1 || leafIndex < 0 || leafIndex >= treeSize) return false;
  if (!Array.isArray(authPath)) return false;

  // Phase 1: root→leaf walk; record which half the leaf falls into per split.
  const inLeftPerSplit: boolean[] = []; // top-down order
  let lo = 0;
  let hi = treeSize;
  while (hi - lo > 1) {
    let k: number;
    try {
      k = largestPow2LessThan(hi - lo);
    } catch {
      return false;
    }
    const inLeft = leafIndex < lo + k;
    inLeftPerSplit.push(inLeft);
    if (inLeft) hi = lo + k;
    else lo = lo + k;
  }
  if (authPath.length !== inLeftPerSplit.length) return false;

  // Phase 2: leaf-up fold — the DEEPEST split's sibling is authPath[0].
  let fn = leafHash;
  for (let d = inLeftPerSplit.length - 1; d >= 0; d--) {
    const sibling = authPath[inLeftPerSplit.length - 1 - d];
    if (typeof sibling !== 'string') return false;
    fn = inLeftPerSplit[d] ? ktNodeHash(fn, sibling) : ktNodeHash(sibling, fn);
  }
  return fn === root;
}

/* ── Fleet commitment (server computeFleetCommitment mirror) ──────────────── */

export interface FleetDevice {
  deviceId: string;
  identityDhPub: string;
  /** May be undefined/null (legacy rows) — the server line-form uses ''. */
  identitySigPub?: string | null;
}

/**
 * Canonical commitment over a user's fleet, byte-identical to the server's
 * computeFleetCommitment: sha256 over the device lines
 * '<deviceId>:<identityDhPub>:<identitySigPub>' sorted by deviceId, joined by
 * '\n' → LOWERCASE HEX (the server's KT log stores hex commitments; the old
 * base64 form was wrong and never matched the log). Empty fleet → sha256('').
 */
export function computeCommitment(devices: FleetDevice[]): string {
  const lines = [...devices]
    .filter((d) => d && typeof d.deviceId === 'string')
    .sort((a, b) => (a.deviceId < b.deviceId ? -1 : a.deviceId > b.deviceId ? 1 : 0))
    .map((d) => `${d.deviceId}:${d.identityDhPub ?? ''}:${d.identitySigPub ?? ''}`);
  return hexOf(sha256Bytes(enc.encode(lines.join('\n'))));
}

/* ── Full fleet-inclusion verification (leaf data + proof + root) ─────────── */

/** Leaf params the proof must cover (the proof response carries these). */
export interface FleetLeafParams {
  seq: number;
  userId: string;
  commitment: string;
}

/**
 * Full inclusion verification using the server-provided leaf data: recompute
 * the leaf hash from (seq, userId, commitment) and verify the RFC-6962 auth
 * path up to the snapshot root. When the proof also carries its own
 * `leafHash`/`leafIndex` (KtInclusionProof wire shape) they are cross-checked:
 * a leaf whose recomputed hash differs from the server-claimed leafHash is a
 * tampering attempt, and an explicit leafIndex is honored over the seq-1
 * default (the log is gap-free append-only, so seq-1 IS the leaf position —
 * the cross-check catches any divergence).
 */
export function verifyFleetInclusion(
  params: FleetLeafParams,
  treeSize: number,
  authPath: string[],
  rootHex: string,
  opts?: { leafIndex?: number; leafHash?: string },
): boolean {
  try {
    if (!params || !Number.isInteger(params.seq) || params.seq < 1) return false;
    if (typeof params.userId !== 'string' || params.userId.length === 0) return false;
    if (typeof params.commitment !== 'string' || params.commitment.length === 0) return false;
    const leafHash = ktLeafHash(params.seq, params.userId, params.commitment);
    // Cross-check: the server-claimed leaf hash must equal the recomputed one
    // (binds the proof to the leaf data the response carries).
    if (typeof opts?.leafHash === 'string' && opts.leafHash !== leafHash) return false;
    // The log is gap-free append-only → leaf position = seq - 1; an explicit
    // leafIndex (server-computed) is authoritative when present and must agree.
    const leafIndex = opts?.leafIndex ?? params.seq - 1;
    if (opts?.leafIndex !== undefined && opts.leafIndex !== params.seq - 1) {
      // Not a hard failure by itself: verify with the server-provided index —
      // but only when the tree positions allow it (verifyInclusionProof bounds).
      return verifyInclusionProof(opts.leafIndex, treeSize, leafHash, authPath, rootHex);
    }
    return verifyInclusionProof(leafIndex, treeSize, leafHash, authPath, rootHex);
  } catch {
    return false;
  }
}

/* ── Root progression (TOFU anchoring) ────────────────────────────────────── */

/**
 * Basic consistency check between two observed roots (TOFU anchoring).
 * v1: same-version divergence = fork evidence (fail); version advancement is
 * accepted (deeper RFC-6962 consistency proofs are verified server-mirror-side
 * in a later round — documented in src/lib/kt-contract.ts).
 */
export function verifyRootProgression(
  previousRoot: string | null,
  currentRoot: string,
  previousVersion: number,
  currentVersion: number,
): { ok: boolean; reason: string } {
  if (previousRoot === null) return { ok: true, reason: 'first-observation' };
  if (currentVersion === previousVersion) {
    return currentRoot === previousRoot
      ? { ok: true, reason: 'same-version' }
      : { ok: false, reason: 'same-version-different-root (fork!)' };
  }
  return { ok: true, reason: 'version-advanced' };
}

/* ── Consistency proof verification (RFC-6962/RFC-9162, byte-exact mirror) ── */

/**
 * Browser mirror of the server's verifyConsistencyProof
 * (src/server/services/key_transparency.ts) — the RFC-6962/RFC-9162
 * consistency proof between tree sizes m and n over the same append-only
 * leaf sequence. SAME math, byte-exact:
 *
 *   - positions are fully determined by (m, n): simulate the generation walk
 *     top-down recording 'L' (old tree entirely in the left half; right half
 *     entirely new) / 'R' (left half fully old; recurse right) moves;
 *   - proof elements are ordered deepest-first (generation order); the DEEPEST
 *     element is the fully-old subtree's own root (proof length = moves + 1);
 *   - a single leaf-up pass folds
 *       accN: every element (L-move: H(accN, p), R-move: H(p, accN))  → root_n
 *       accM: only R-move elements (fully-old blocks) H(p, accM)      → root_m
 *   - both must match the anchored roots: any deletion/rewrite of a historical
 *     entry breaks at least one of the two (fork detection).
 *
 * DEFENSIVE (damaged-proof handling): malformed/short/garbage proofs —
 * non-array, non-string elements, wrong length, invalid (m, n), non-hex
 * elements — return FALSE, never throw past this boundary.
 */
export function verifyConsistency(
  m: number,
  n: number,
  proof: unknown,
  rootM: string,
  rootN: string,
): boolean {
  try {
    if (!Number.isInteger(m) || !Number.isInteger(n)) return false;
    if (m < 1 || m > n) return false;
    if (!Array.isArray(proof)) return false;
    if (typeof rootM !== 'string' || typeof rootN !== 'string') return false;
    for (const el of proof) {
      if (typeof el !== 'string' || el.length === 0) return false;
    }
    if (m === n) return proof.length === 0 && rootM === rootN;

    // Simulate the generation walk top-down to recover the move sequence
    // (positions are determined by (m, n) alone — attacker controls only VALUES).
    const moves: Array<'L' | 'R'> = [];
    let lo = 0;
    let hi = n;
    let mRel = m;
    while (hi - lo > 1 && mRel !== hi - lo) {
      let k: number;
      try {
        k = largestPow2LessThan(hi - lo);
      } catch {
        return false;
      }
      if (mRel <= k) {
        moves.push('L');
        hi = lo + k;
      } else {
        moves.push('R');
        lo = lo + k;
        mRel -= k;
      }
    }
    // Deepest node (mRel === hi - lo) emits its own (fully-old) root first.
    if (proof.length !== moves.length + 1) return false;

    let accN: string = proof[0]; // new-root accumulator (starts at the deepest old subtree root)
    let accM: string = proof[0]; // old-root accumulator
    for (let i = 1; i <= moves.length; i++) {
      const p = proof[i];
      const move = moves[moves.length - i]; // node_{D-i}'s move
      if (move === 'L') {
        // element = right (entirely new) sibling: only affects root_n
        accN = ktNodeHash(accN, p);
      } else {
        // element = left (entirely old) block: affects both roots
        accN = ktNodeHash(p, accN);
        accM = ktNodeHash(p, accM);
      }
    }
    return accN === rootN && accM === rootM;
  } catch {
    return false; // never throw past the boundary (damaged-proof contract)
  }
}

/* ── Last-seen snapshot anchor ('ktLast:<peer>') ──────────────────────────── */

/** The last-seen (treeVersion, rootHash) anchor persisted per peer. */
export interface KtAnchor {
  treeVersion: number;
  rootHash: string;
}

const ANCHOR_ROOT_RE = /^[0-9a-f]{64}$/; // lowercase-hex sha256 (server root shape)

/**
 * Read the stored last-seen snapshot for `peerId` ('ktLast:<peer>'). Any
 * garbage/corrupt stored value is discarded (returns null + removed) — a
 * poisoned anchor must never crash or permanently wedge verification.
 */
export function getKtAnchor(peerId: string): KtAnchor | null {
  try {
    const raw = safeLocalStorage()?.getItem(`ktLast:${peerId}`);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as KtAnchor;
    if (
      parsed &&
      typeof parsed === 'object' &&
      Number.isInteger(parsed.treeVersion) &&
      parsed.treeVersion >= 1 &&
      typeof parsed.rootHash === 'string' &&
      ANCHOR_ROOT_RE.test(parsed.rootHash)
    ) {
      return { treeVersion: parsed.treeVersion, rootHash: parsed.rootHash };
    }
    safeLocalStorage()?.removeItem(`ktLast:${peerId}`); // corrupt → discard
  } catch { /* storage unavailable / unparseable */ }
  return null;
}

/** Persist the last-seen (treeVersion, rootHash) anchor for `peerId`. */
export function setKtAnchor(peerId: string, treeVersion: number, rootHash: string): void {
  try {
    if (!Number.isInteger(treeVersion) || treeVersion < 1 || !ANCHOR_ROOT_RE.test(rootHash)) return;
    safeLocalStorage()?.setItem(`ktLast:${peerId}`, JSON.stringify({ treeVersion, rootHash }));
  } catch { /* storage unavailable */ }
}

/** Test/diagnostic helper: forget the anchor (next proof re-anchors via TOFU). */
export function clearKtAnchor(peerId: string): void {
  try { safeLocalStorage()?.removeItem(`ktLast:${peerId}`); } catch { /* storage unavailable */ }
}

/* ── Security event emission (monitoring bridge — no user content) ────────── */

/**
 * Fire a structured security event into the App's monitoring pipeline.
 * App.tsx installs `(window as any).pushSecurityEvent` at module load; when it
 * is absent (tests, SSR, engine used standalone) this is a silent no-op —
 * monitoring must NEVER throw into or block the crypto paths.
 * Callers pass METADATA ONLY (peer ids, reasons, statuses) — never message or
 * user content (enforced again at the App-side ring).
 */
export function notifySecurityEvent(kind: string, detail: Record<string, unknown>): void {
  try {
    const push = (globalThis as any)?.pushSecurityEvent;
    if (typeof push === 'function') push(kind, detail);
  } catch { /* monitoring must never throw */ }
}

/* ── Witness snapshot signature (verified mode) ───────────────────────────── */

/** Same canonical signing message as the server's snapshotSigningMessage. */
const KT_SIG_CONTEXT = 'DirashaKT-v1:';

function snapshotSigningMessage(treeVersion: number, rootHash: string): Uint8Array {
  return enc.encode(`${KT_SIG_CONTEXT}${treeVersion}:${rootHash}`);
}

/**
 * The pinned witness Ed25519 PUBLIC key (std b64) clients verify snapshot
 * signatures against. Resolution order:
 *   1. `globalThis.KT_WITNESS_PUB` (window override — set from the console or
 *      an injected bootstrap script),
 *   2. `import.meta.env.VITE_KT_WITNESS_PUB` (build-time env).
 * Absent → verified-mode snapshots cannot be signature-checked; inclusion
 * proof math still runs and `signatureVerified` is reported as false.
 */
export function getKtWitnessPub(): string | null {
  const w = (globalThis as any)?.KT_WITNESS_PUB;
  if (typeof w === 'string' && w.length > 0) return w;
  const envVal = (import.meta as any)?.env?.VITE_KT_WITNESS_PUB;
  if (typeof envVal === 'string' && envVal.length > 0) return envVal;
  return null;
}

/* ── Proof fetch + end-to-end verification (engine entry point) ───────────── */

/**
 * Snapshot progression check against the stored anchor ('ktLast:<peer>') —
 * the fork/rollback defense shared by every verified-mode path:
 *   - rollback (server treeVersion < anchored) → ok:false (old-log rejection);
 *   - same version + different root → ok:false 'fork-detected';
 *   - version advance → the RFC-6962 consistency proof between the two
 *     anchored roots must verify; missing/garbage → ok:false 'malformed',
 *     failed math → ok:false 'fork-detected'.
 * Returns a FAILED result (with 'kt-failure' emitted) or null = progression OK.
 */
function progressionCheck(
  body: KtProofResponse,
  anchor: KtAnchor | null,
  snapVersion: number,
  snapRoot: string,
  peerId: string,
  mode: FleetProofMode,
): FleetProofResult | null {
  if (!anchor) return null; // TOFU: nothing anchored yet — first observation
  if (snapVersion < anchor.treeVersion) {
    // OLD-LOG REJECTION: a newer snapshot was already anchored — an older
    // tree is a rollback attack, never accepted (no re-anchoring).
    notifySecurityEvent('kt-failure', {
      peerId,
      reason: `rollback: anchored v${anchor.treeVersion}, server offered v${snapVersion}`,
    });
    return {
      ok: false,
      mode,
      signatureVerified: false,
      reason: `rollback rejected: treeVersion went backwards (anchored v${anchor.treeVersion}, offered v${snapVersion})`,
    };
  }
  if (snapVersion === anchor.treeVersion) {
    // Same version ⇒ byte-identical root or it is a fork (split-view).
    if (snapRoot !== anchor.rootHash) {
      notifySecurityEvent('kt-failure', {
        peerId,
        reason: `fork: same version v${snapVersion}, different root`,
      });
      return {
        ok: false,
        mode,
        signatureVerified: false,
        reason: 'fork-detected: same snapshot version, different root',
      };
    }
    return null;
  }
  // Version advanced ⇒ the RFC-6962 consistency proof between the anchored
  // root and the current root MUST verify. The server carries it
  // (routes/kt.ts serves it for ?sinceVersion=<anchored version>).
  const cons = (body as any).consistency;
  if (
    !cons ||
    typeof cons !== 'object' ||
    Number(cons.fromVersion) !== anchor.treeVersion ||
    Number(cons.toVersion) !== snapVersion ||
    !Array.isArray(cons.proof)
  ) {
    // Missing/mismatched/garbage consistency data = damaged proof —
    // the advanced root is UNPROVEN against the anchored history.
    notifySecurityEvent('kt-failure', { peerId, reason: 'malformed consistency proof' });
    return {
      ok: false,
      mode,
      signatureVerified: false,
      reason: 'malformed: consistency proof missing or shape-invalid for version advance',
    };
  }
  if (!verifyConsistency(anchor.treeVersion, snapVersion, cons.proof, anchor.rootHash, snapRoot)) {
    notifySecurityEvent('kt-failure', { peerId, reason: 'consistency verification failed (fork)' });
    return {
      ok: false,
      mode,
      signatureVerified: false,
      reason: 'fork-detected: consistency proof verification FAILED against the anchored root',
    };
  }
  return null;
}

export type FleetProofMode = KtMode | 'unavailable';

export interface FleetProofResult {
  /**
   * true = NO tampering evidence (do not raise any flag); false = a verified-
   * mode contradiction was observed (caller MUST warn + raise 'ktFlag:<peer>').
   * Transport failures and unverified witness mode are ok:true by design
   * (availability first — see module doc).
   */
  ok: boolean;
  mode: FleetProofMode;
  /** true only when a pinned-witness snapshot signature was verified successfully. */
  signatureVerified?: boolean;
  /** P1-D trust-gate field: true ONLY in verified mode with a verified signature. */
  verified?: boolean;
  reason?: string;
}

/** Auth headers provider — mirror of the engine's AuthHeadersProvider shape. */
type AuthHeadersProvider = () => Promise<Record<string, string>> | Record<string, string>;

function safeLocalStorage(): Storage | null {
  try {
    if (typeof globalThis.localStorage !== 'undefined') return globalThis.localStorage;
  } catch { /* sandboxed / disabled storage */ }
  return null;
}

/** Raise (or clear) the per-peer KT flag consumed by the ChatWindow header badge. */
export function setKtFlag(peerId: string): void {
  try { safeLocalStorage()?.setItem(`ktFlag:${peerId}`, '1'); } catch { /* storage unavailable */ }
}

export function clearKtFlag(peerId: string): void {
  try { safeLocalStorage()?.removeItem(`ktFlag:${peerId}`); } catch { /* storage unavailable */ }
}

/**
 * Fetch the peer's KT proof (GET /api/e2ee/kt/proof/:userId) and verify it
 * end-to-end against the LOCALLY COMPUTED fleet commitment `expectedCommitment`
 * (hex, from computeCommitment over the devices just fetched from the bundle).
 *
 * Checks, in order:
 *   1. Transport: non-2xx or unparseable body → { ok: true, 'unavailable' } —
 *      availability first, no flag (rate-limit/5xx must never degrade UX).
 *      A client-side rate-limit trip (HTTP 429) additionally emits a
 *      'rate-limit' security event (metadata only).
 *   2. mode !== 'verified' → documented honest unverified mode, { ok: true }.
 *   3. Verified mode + pinned witness pub → Ed25519 signature over
 *      'DirashaKT-v1:<v>:<root>' must verify → else { ok: false }.
 *   4. SNAPSHOT PROGRESSION against the stored anchor ('ktLast:<peer>',
 *      last seen (treeVersion, rootHash)) — the fork/rollback defense:
 *        - treeVersion < stored version → ROLLBACK attack → { ok: false }
 *          (an older log is NEVER accepted once a newer one was anchored);
 *        - treeVersion === stored && root differs → fork evidence → { ok: false };
 *        - treeVersion > stored → the RFC-6962 consistency proof the server
 *          carries (routes/kt.ts: ?sinceVersion=<stored>) MUST verify between
 *          the stored and current roots. Missing/malformed proof →
 *          { ok: false, reason: 'malformed' }; proof fails →
 *          { ok: false, reason: 'fork-detected' }.
 *      On ok:true outcomes the (treeVersion, rootHash) anchor is advanced.
 *   5. `found` false → peer has no log entry yet (TOFU bootstrap), { ok: true }.
 *   6. The logged commitment (inclusion.commitment) must EQUAL the locally
 *      computed commitment over the fetched devices — mismatch = the keys the
 *      server just handed us are NOT the keys in the transparency log.
 *   7. Full inclusion proof: recomputed leaf hash + RFC-6962 auth path up to
 *      the (signature-verified) snapshot root.
 *
 * Every { ok: false } outcome ALSO emits a 'kt-failure' security event
 * (metadata only: peer id + reason) via the App monitoring bridge.
 *
 * NEVER throws, NEVER blocks the caller: every outcome is a result object.
 */
export async function fetchAndVerifyFleetProof(
  peerId: string,
  expectedCommitment: string,
  authHeaders?: AuthHeadersProvider,
): Promise<FleetProofResult> {
  try {
    // The last-seen anchor drives (a) the ?sinceVersion= request and (b) the
    // progression/consistency/rollback checks below.
    const anchor = getKtAnchor(peerId);
    const sinceParam =
      anchor && anchor.treeVersion >= 1 ? `?sinceVersion=${anchor.treeVersion}` : '';
    const extra = authHeaders ? await authHeaders() : {};
    const res = await fetch(`/api/e2ee/kt/proof/${encodeURIComponent(peerId)}${sinceParam}`, {
      headers: {
        'Content-Type': 'application/json',
        ...(extra as Record<string, string>),
      },
    });
    if (!res.ok) {
      // Transport/rate-limit/5xx — NOT tampering evidence (availability first).
      if (res.status === 429) {
        // Client-side rate-limit trip — monitoring event (metadata only),
        // still ok:true so a drained budget never becomes a tampering flag.
        notifySecurityEvent('rate-limit', { endpoint: 'kt-proof', status: 429, peerId });
      }
      return { ok: true, mode: 'unavailable', reason: `proof fetch failed (HTTP ${res.status})` };
    }
    let body: KtProofResponse | null = null;
    try {
      body = (await res.json()) as KtProofResponse;
    } catch {
      return { ok: true, mode: 'unavailable', reason: 'proof body unparseable' };
    }
    if (!body || typeof body !== 'object' || !body.snapshot) {
      return { ok: true, mode: 'unavailable', reason: 'proof response shape invalid' };
    }
    const snapshot = body.snapshot;
    const mode: FleetProofMode = snapshot.mode === 'verified' ? 'verified' : 'unverified';

    // Damaged-response handling: a structurally invalid snapshot (garbage
    // version/root shape) is NEVER parsed leniently — every later check
    // (signature, progression, inclusion) would be meaningless against it.
    const snapVersion = Number((snapshot as any).treeVersion);
    const snapRoot = String((snapshot as any).rootHash ?? '');
    const snapshotShapeOk =
      Number.isInteger(snapVersion) && snapVersion >= 0 && ANCHOR_ROOT_RE.test(snapRoot);
    if (!snapshotShapeOk) {
      notifySecurityEvent('kt-failure', { peerId, reason: 'malformed snapshot shape' });
      return { ok: false, mode, reason: 'malformed (snapshot shape invalid)' };
    }

    // Documented UNVERIFIED witness mode: the root carries no witness
    // signature, so nothing here can independently detect a malicious server —
    // return honestly instead of pretending (no flag; the deployment simply
    // has no KT witness configured). The (shape-validated) snapshot is still
    // anchored: progression tracking (rollback detection) works in every mode.
    if (mode !== 'verified') {
      if (snapVersion >= 1) {
        const prev = anchor;
        if (prev && snapVersion < prev.treeVersion) {
          // Rollback is rejected in EVERY mode: a treeVersion that goes
          // backwards after a newer one was anchored is old-log evidence.
          notifySecurityEvent('kt-failure', { peerId, reason: 'rollback (unverified mode)' });
          return { ok: false, mode: 'unverified', reason: 'rollback rejected: treeVersion went backwards' };
        }
        setKtAnchor(peerId, snapVersion, snapRoot);
      }
      return { ok: true, mode: 'unverified', reason: 'unverified witness mode (no KT_SIGNING_KEY server-side)' };
    }

    // Verified mode: the snapshot root is the anchor. Verify its signature
    // against the PINNED witness public key FIRST (a failed signature is
    // tampering evidence — flag).
    const witnessPub = getKtWitnessPub();
    let signatureVerified = false;
    if (witnessPub) {
      try {
        signatureVerified = ed25519Verify(
          b64decode(String(snapshot.signature ?? '')),
          snapshotSigningMessage(Number(snapshot.treeVersion), String(snapshot.rootHash)),
          b64decode(witnessPub),
        );
      } catch {
        signatureVerified = false;
      }
      if (!signatureVerified) {
        notifySecurityEvent('kt-failure', { peerId, reason: 'witness snapshot signature verification failed' });
        return { ok: false, mode, signatureVerified, reason: 'witness snapshot signature verification FAILED' };
      }
    } else {
      // No pinned witness pub: the snapshot signature cannot be checked, but
      // the PROGRESSION checks (rollback / fork / consistency) still run —
      // they defend the anchored history independently of the signature.
      const prog = progressionCheck(body, anchor, snapVersion, snapRoot, peerId, mode);
      if (prog) return prog;
      if (snapVersion >= 1) setKtAnchor(peerId, snapVersion, snapRoot);
      return {
        ok: true,
        mode,
        signatureVerified,
        reason: 'verified mode but no pinned KT_WITNESS_PUB — snapshot signature unchecked (configure the witness key)',
      };
    }

    /* ── Snapshot progression vs the stored anchor (fork / rollback defense) ── */
    const prog = progressionCheck(body, anchor, snapVersion, snapRoot, peerId, mode);
    if (prog) return { ...prog, signatureVerified };

    if (!body.found || !body.inclusion) {
      // Peer has no entry in the log yet — TOFU bootstrap, nothing to compare.
      // Anchor the (signature-verified) snapshot before returning.
      if (snapVersion >= 1) setKtAnchor(peerId, snapVersion, snapRoot);
      return { ok: true, mode, signatureVerified, reason: 'peer not yet in the KT log (TOFU)' };
    }
    const inclusion = body.inclusion;

    // The logged commitment must be EXACTLY the commitment we computed over
    // the fleet the server just served — this is the whole point of KT.
    if (typeof inclusion.commitment !== 'string' || inclusion.commitment !== expectedCommitment) {
      notifySecurityEvent('kt-failure', { peerId, reason: 'fleet commitment mismatch' });
      return {
        ok: false,
        mode,
        signatureVerified,
        reason: 'fleet commitment MISMATCH: bundle keys differ from the logged transparency entry',
      };
    }

    // Full RFC-6962 inclusion proof of the logged leaf inside the snapshot tree.
    const params = { seq: Number(inclusion.seq), userId: String(body.userId ?? peerId), commitment: inclusion.commitment };
    const inclusionOk = verifyFleetInclusion(
      params,
      Number(inclusion.treeSize),
      Array.isArray(inclusion.authPath) ? inclusion.authPath : [],
      String(snapshot.rootHash),
      {
        leafIndex: Number.isInteger(inclusion.leafIndex) ? Number(inclusion.leafIndex) : undefined,
        leafHash: typeof inclusion.leafHash === 'string' ? inclusion.leafHash : undefined,
      },
    );
    if (!inclusionOk) {
      notifySecurityEvent('kt-failure', { peerId, reason: 'inclusion proof verification failed' });
      return { ok: false, mode, signatureVerified, reason: 'inclusion proof verification FAILED (tampered auth path / root mismatch)' };
    }

    // All checks passed — anchor the verified snapshot for the next round's
    // progression/consistency checks ('ktLast:<peer>').
    if (snapVersion >= 1) setKtAnchor(peerId, snapVersion, snapRoot);
    return { ok: true, mode, signatureVerified, reason: 'fleet proof verified' };
  } catch (err) {
    // Network error etc. — never block, never flag on transport failure.
    return { ok: true, mode: 'unavailable', reason: `proof fetch error: ${(err as Error)?.message ?? 'unknown'}` };
  }
}

/* Std-base64 helpers re-exported for tests of the witness-signature path. */
export { b64encode, b64decode };

/* ── P1-D (external-audit E2EE-08): Key Transparency as a TRUST GATE ──────── */

/**
 * Extended result semantics (E2EE-08): `verified` is true ONLY when the proof
 * ran in verified mode AND the pinned-witness snapshot signature verified.
 * `ok` keeps its historical meaning (no tampering EVIDENCE); `verified` is
 * the gate field — engines must not use a peer bundle before verified=true
 * (when KT enforcement is on). NEVER ok:true-with-signatureVerified:false is
 * interpreted as usable: unverified/unavailable outcomes carry verified:false.
 */
const lastKtResult = new Map<string, FleetProofResult>();

/** Last verification outcome for a peer: known=false until a proof ran. */
export function getPeerKtVerification(peerId: string): { verified: boolean; known: boolean } {
  const r = lastKtResult.get(peerId);
  if (!r) return { verified: false, known: false };
  return { verified: r.verified === true, known: true };
}

/**
 * KT enforcement switch: ON when a witness public key is pinned AND the
 * VITE_KT_ENFORCE escape hatch is not explicitly '0'. No witness pinned →
 * enforcement OFF (honest unverified mode, loudly reported) — pinning the
 * witness key out-of-band is what turns the gate on.
 */
export function isKtEnforced(): boolean {
  const w = getKtWitnessPub();
  if (!w) return false;
  const flag = (import.meta as any)?.env?.VITE_KT_ENFORCE;
  return flag !== '0';
}

/**
 * Gate wrapper around fetchAndVerifyFleetProof: records the per-peer result
 * (with the derived `verified` field) so the engine's synchronous gate can
 * consult it before any bundle use.
 */
export async function fetchAndVerifyFleetProofGated(
  peerId: string,
  expectedCommitment: string,
  authHeaders?: AuthHeadersProvider,
): Promise<FleetProofResult & { verified: boolean }> {
  const inner = await fetchAndVerifyFleetProof(peerId, expectedCommitment, authHeaders);
  const verified = inner.mode === 'verified' && inner.signatureVerified === true && inner.ok === true;
  const out: FleetProofResult & { verified: boolean } = { ...inner, verified };
  lastKtResult.set(peerId, out);
  return out;
}

/** Clear the cached KT verdict (logout / account switch hygiene). */
export function resetKtVerdicts(): void {
  lastKtResult.clear();
}

/** Clear ONE peer's cached KT verdict (device-cache invalidation → re-verify). */
export function resetKtVerdict(peerId: string): void {
  lastKtResult.delete(peerId);
}
