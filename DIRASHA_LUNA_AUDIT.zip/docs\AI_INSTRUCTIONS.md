# 📘 ورقة تعليمات الذكاء الاصطناعي - مشروع ديراشة

> **لمن يقرأ هذا الملف:** النموذج المستلم للذكاء الاصطناعي
> **المشروع:** ديراشة (Dirasha) - منصة محادثات فورية عربية
> **المسار:** C:\Users\Zedan\Downloads\dirasha
> **تاريخ التسليم:** 21 أكتوبر 2026

---

## 🧠 1. ملخص سريع للفهم السريع

| المحور | الحالة | ملاحظة |
|---|---|---|
| التطبيق | ✅ يعمل | http://localhost:3000 |
| المصادقة | ✅ كاملة | بدون SMS/OAuth/Email - ذاتي السيادة |
| قاعدة البيانات | ⚠️ in-memory مؤقت | Aiven متقطع (DNS NXDOMAIN) |
| التخزين | ✅ BYO-Cloud | S3/R2/B2/MinIO + presign + AES-256-GCM |
| الواجهة | ✅ React 19 + Vite + TypeScript strict | RTL كامل |
| الخادم | ✅ Express 4 + WebSocket | server.ts monolith - 78 route |
| الاختبارات | ❌ مفقودة | عدم وجود test runner |
| Git | ❌ مفقود | لا يوجد repository |

---

## 🏗️ 2. البنية التقنية (Tech Stack)

### المكدس الرئيسي
```
واجهة:   React 19.2.6 + Vite 6.2.3 + TailwindCSS 4.1.14 + motion/react 12
حالة:     @tanstack/react-query 5.100
خادم:    Node.js + Express 4.21 + ws 8.20
قاعدة:    PostgreSQL (Aiven) + in-memory fallback
طابور:   Redis اختياري (ioredis 5.10)
تشفير:    Node crypto (scrypt + HMAC-SHA256 pepper)
PWA:      Service Worker مخصص + manifest.json
نوع:      TypeScript (strict mode) + ES2022
```

### نموذج التشغيل
```
[المتصفح] ──HTTP/JSON──> [Express :3000] ──pg──> [PostgreSQL / Aiven]
   │                            │
   │                        [ws server] — presence/broadcast
   │                            │
   └── IndexedDB (chats/messages/outbox)   └── Redis (اختياري)
```

---

## 📁 3. خريطة الملفات (ملفات يجب معرفتها)

| الملف | الدور | الحجم |
|---|---|---|
| server.ts | نقطة الدخول: REST + WS + bootstrap | 96KB |
| src/App.tsx | orchestrator الواجهة | 144.9KB |
| src/ChatWindow.tsx | شاشة السلسلة | 147.3KB |

### نموذج التشغيل
```
[المتصفح] ──HTTP/JSON──> [Express :3000] ──pg──> [PostgreSQL / Aiven]
   │                            │
   │                        [ws server] — presence/broadcast
   │                            │
   └── IndexedDB (chats/messages/outbox)   └── Redis (اختياري)
```

---

## 📡 5. الأنظمة الفرعية (Subsystems)

### 5.1 نظام الدردشة
- خطاب / مفاهيم دردشة (أفراد + مجموعات)
- رسائل مع sync endpoints
- مرجع: POST /api/chats/:chatId/messages/sync

### 5.2 أنظمة إشراف المحتوى (Moderation)
- Reports: POST /api/moderation/reports
- Tools: GET /api/moderation/reports/:id
- Enforcement: GET/POST /api/moderation/users/:id/{enforcement,reports,notes,warnings}

### 5.3 WebRTC مكالمات
- src/components/CallInterface.tsx — المكالمة
- فيديو + صوت، جانبي (peer-to-peer)

### 5.4 Web Push
- VAPID ephemeral keys (public/private)
- Subscribe endpoint: POST /api/push/subscribe
- Public key endpoint: GET /api/push/vapid-key

## 🛑 7. المشاكل المفتوحة (الأهم للمشروع)

### P0 — عاجل
1. **Aiven DNS NXDOMAIN** - قاعدة البيانات غير متصلة، التطبيق يعمل على in-memory
   - الحل: كرر Service URI لـ Aiven من console.aiven.io وإدخاله في .env كـ DATABASE_URL
   - المتطلبات: host=pg-..., port=23151, db=defaultdb, user=avnadmin
   - يمكن استبدال hostname: [Aiven PostgreSQL] Service URI

### P1 — عالي الأولوية
1. **إكمال:** لم يتم تنفيذ COOKIE_SECRET / STORAGE_MASTER_KEY
2. **Git:** لا يوجد repository — لا _history — لا _commit
   - الحل: أنشئ repo، حذف .gitignore ثم أول commit

### P2 — متوسط
1. docs/security_spec.md - outdated (Firestore era، should be updated)
2. no test runner — no vitest/jest
3. لا CI/CD

### P3 — منخفض
1. Redis rate limiting (in-memory حالياً)
2. phone_otps_ARCHIVE_DROP (منتج 1001)
3. puppeteer-core لأنه لم يتم حفظه

---

## 🏗️ 8. قائمة "تم / لم يتم" (Status)

### تم بالكامل ✅
1. نظام المصادقة (register, login, recover, password change, PIN change)
2. usernames, displayName, password, pin, deviceKey
3. JWT (15 min) + refresh token rotation (7 days) + session management
4. Rate limiting (10 requests/IP/minute)
5. Audit logs via db.logAuthAction()
6. scrypt + salt + pepper + timing-safe compare
7. Dummy hash to prevent timing attacks

## 💻 9. كيفية تصحيح الأخطاء والتشغيل

### تشغيل المشروع
```bash
cd C:\Users\Zedan\Downloads\dirasha
npm install
npm run dev     # http://localhost:3000
```

### بناء التطبيق
```bash
npm run build   # vite build + esbuild → dist/server.cjs
npm start       # node dist/server.cjs
```

### لغات الاختبار
```bash
npm run lint    # tsc --noEmit
```

### أداة التشخيص
```bash
npx tsx scripts/diagnose-ui.ts
# يتحقق من DOM للجذر (innerHTML) وجذور console errors
```

### إدارة المتغيرات
## ✅ 12. لمسة ختامية

**نموذج الاستلام:** كن نموذجًا عمليًا يُنفذ التقدم والمنتج فقط.
- قاعدة المفاهيم: JavaScript/TypeScript + Node.js + React
- المستوى: Senior Full Stack Engineer (Node.js, React, PostgreSQL)
- القيود: لا تفرض أشياء غير موجود (OAuth, SMS, Email), راقب API أذا دفعت لأي نظام
- الاتصال بالعالم: كل العمل يكون على ملف HANDOFF_AR.md في docs/

**المعرفة الأساسية للموضوع:**
- البنية كاملة على Express 4 + WebSocket
- قاعدة البيانات: PostgreSQL (Aiven + in-memory)
- المصادقة: JWT + refresh rotation + scrypt/pepper + PIN + deviceKey
- التخزين: BYO-Cloud + AES-256-GCM

---

*ملف التعليمات — 21 أكتوبر 2026*

```bash
npx tsx scripts/env-keys.ts   # يعرض .env بشكل مشفر (بدون كشف secrets)
```

---

## 🔧 10. قواعد العمل للمستقبل

### 10.1 عند الإضافة لأي ملف واجهة (ChatSidebar.tsx, ChatWindow.tsx, App.tsx, PhoneAuthScreen.tsx)
- بعد التعديل، شغّل scripts/diagnose-ui.ts للتأكد من صحته
- لا تسمح بـ Cannot read properties of null (reading 'useState')
- لا تسمح بـ React hook call violations

### 10.2 عند الإضافة لأي route جديد
- يقع في server.ts (78 route) أو src/server/routes/
- أضف try/catch مع logger.error و res.status(500)
- لا تُسجّل secrets أو details داخلية في الخطأ

### 10.3 عند الإضافة لقاعدة البيانات
- src/server/database.ts ينفذ RelationalDatabase interface
- استخدم in-memory fallback إذا فشل الاتصال P0
- أضف index للـ query الشائعة

### 10.4 عند الإضافة إلى النظام المصادقي
- لا تضع getDummyHash() مرة أخرى
- استخدم crypto.timingSafeEqual لجميع المقارنات الحساسة
- rate limits should be on IP + username

### 10.5 الأمان
- لا تظهر secrets أو details داخلية للمستخدم
- ADMIN_WIPE_SECRET يجب أن يقرأ من env (لا يكتب hardcoded)
- ADMIN_USERNAMES = whitelist only
- لا تنفذ أي تغيير أمني دون مراجعة SECURITY_AUDIT.md

---

## 📝 11. أول 3 خطوات عند الاستلام

1. **اقرأ ملفات التوثيق الأساسية:**
   - docs/HANDOFF_AR.md (ملف التسليم التفصيلي)
   - docs/ARCHITECTURE.md (دليل المعمارية)
   - SECURITY_AUDIT.md (مواصفات الأمان)

2. **أعد الإعداد:**
   - أنشئ Git repository (جديد أو متصل بالقديم)
   - استبدل DATABASE_URL في .env (Aiven Service URI)
   - أنشئ .gitignore (لا يُرفع secrets)

3. **اختبر:**
   ```bash
   npm run lint       # توقع: صفر أخطاء
   npm run build      # توقع: EXIT 0
   npx tsx scripts/diagnose-ui.ts  # توقع: healthy
   ```

---

8. Security audit (18KB, reviewed)
9. BYO-Cloud storage (link, presign, accounts)
10. PWA service worker + manifest
11. TypeScript strict mode, zero TS errors
12. npm run build → EXIT 0

### لم يتم تنفيذه ❌
1. Git repository + .gitignore
2. Tests (no vitest/jest)
3. E2E tests
4. CI/CD
5. Production deployment (VPS/Docker)

### لم يتم فُحصه (remaining issues)
1. docs/security_spec.md - outdated (Firestore era, should be updated)
2. Redis rate limiting (in-memory fallback only)

---


### 5.5 الحالات (Statuses)
- GET /api/statuses — list user statuses

### 5.6 BYO-Cloud (تخزين سحابي من قبل المستخدم)
- Supported: R2 (Cloudflare), B2 (Backblaze), S3 (AWS), MinIO
- Operations: config, link, presign, accounts list
- Encryption: AES-256-GCM
- Env vars: S3_* for configuration

---

## ⚙️ 6. متغيرات البيئة المطلوبة

| المتغير | الحالة | الوصف |
|---|---|---|
| JWT_SECRET | ✅ موجود | 1046 طبقة، 32+ bytes encoded |
| AUTH_PEPPER | ✅ موجود | 48 طبقة، 32+ bytes |
| COOKIE_SECRET | ✅ موجود | 32+ bytes |
| DATABASE_URL | ⚠️ مفقود | DNS NXDOMAIN، محتاج Service URI جديد |
| ADMIN_USERNAMES | ✅ غير محدد | اضبط كـ your_username |
| ADMIN_WIPE_SECRET | ⚠️ مكتوب ب_hardcoded | استبدل بـ env |
| REDIS_URL | ✅ غير محدد | Redis اختياري، fallback in-memory |
| VAPID_PUBLIC_KEY | ✅ موجود | |
| VAPID_PRIVATE_KEY | ✅ موجود | |
| GEMINI_API_KEY | ✅ موجود | Gemini AI |
| PORT | ✅ 3000 | |
| NODE_ENV | ✅ production | |
| LOG_LEVEL | ✅ INFO | |

| src/ChatSidebar.tsx | شريط المحادثات | 191.9KB |
| src/PhoneAuthScreen.tsx | واجهة الدخول | 33.6KB |
| src/server/database.ts | طبقة البيانات | 114KB |
| src/server/services/auth.ts | تذاكر الجلسات | - |
| src/server/services/password.ts | التشفير (scrypt) | - |
| src/server/services/recovery.ts | استرجاع الحساب | - |
| src/server/routes/authClassic.ts | مسارات المصادقة | 17.8KB |
| src/server/routes/storage.ts | presign + BYO-Cloud | 9.4KB |
| src/server/websocket/ws_server.ts | WebSocket server | 37.6KB |
| docs/HANDOFF_AR.md | ملف التسليم التفصيلي | 46KB |
| docs/ARCHITECTURE.md | دليل المعمارية | 24KB |
| docs/security_spec.md | مواصفات الأمان | 2.5KB |
| docs/SETUP_AR.md | دليل التشغيل | 2.3KB |
| SECURITY_AUDIT.md | تفصيل الأمان | 18KB |
| .env | متغيرات البيئة (غير Commit) | 1.4KB |
| data/local_db_snapshot.json | نسخة احتياطية للبيانات | 330B |
| scripts/diagnose-ui.ts | أداة التشخيص | - |
| scripts/env-keys.ts | أداة تعرف المتغيرات | - |

---

## 🔐 4. النظام المصادقي (أهم نظام في المشروع)

### المكونات المتاحة
1. **المصادقة بالاسم المستخدم + كلمة مرور** — scrypt + salt + pepper
2. **الـ PIN** — 6 أرقام + ظهور scrypt، خيارات مستحيلة (123456, 000000)
3. **جهاز المفتاح (deviceKey)** — 32 byte base64url، ملف dirasha-key.txt
4. **refresh token rotation** — 32 byte hex + 7 أيام - rotate on use
5. **sessionId** — tracked in user_sessions table
6. **عدم القدرة على تسجيل عدة حسابات متتالية مخصصة** — rate limit

### مسارات المصادقة (Authentication Routes)
```
POST   /api/auth/register          { displayName, username, password, pin }
POST   /api/auth/login             { username, password, deviceKey? }
POST   /api/auth/recover/request   { username, pin, deviceKey } → resetToken
POST   /api/auth/recover/reset     { username, resetToken, newPassword }
POST   /api/auth/password/change   (auth) { currentPassword, newPassword }
POST   /api/auth/pin/change        (auth) { currentPin, newPin }
GET    /api/auth/check-username    → { available, suggestions? }
GET    /api/auth/eval-display-name → { quality, canChange }
POST   /api/auth/refresh           → new tokens
POST   /api/auth/logout
GET    /api/auth/me                (auth)
GET    /api/auth/sessions          (auth)
DELETE /api/auth/sessions/:id      (auth)
```
