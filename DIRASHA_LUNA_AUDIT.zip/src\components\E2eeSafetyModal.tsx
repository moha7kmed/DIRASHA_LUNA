/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * E2eeSafetyModal — "التحقق من التشفير" (Agent I integration, E2EE-SPEC).
 *
 * Shows the 60-digit safety number for a 1:1 DM peer, formatted as 6 blocks
 * of 10 digits, plus a QR code encoding the digits (scan from the other
 * device to compare). The number is derived deterministically from both
 * identity keys (identical on both devices); users compare it out-of-band to
 * detect man-in-the-middle attacks. Styling mirrors the existing dark-theme
 * modals (fixed overlay + zinc-900 card, Arabic RTL content).
 *
 * Verified state (Task C): the 'توثيق رقم الأمان' button stores the current
 * safety number under 'e2eeVerified:<myId>:<peerId>'. On every open the stored
 * value is compared with the freshly computed number — a mismatch clears the
 * stored verification automatically.
 */

import React, { useState, useEffect, useCallback } from 'react';
import QRCode from 'qrcode';
import { X, Lock, Copy, Check, Loader2, RefreshCw, ShieldCheck, AlertCircle, BadgeCheck } from 'lucide-react';

/* ── Shared E2EE localStorage keys (single source of truth) ──────────────── */

/** 'e2eeVerified:<myId>:<peerId>' = the verified safety-number string. */
export const e2eeVerifiedKey = (myId: string, peerId: string): string =>
  `e2eeVerified:${myId}:${peerId}`;
/** 'e2eeRekey:<myId>:<peerId>' === '1' → rekey warning banner for the DM. */
export const e2eeRekeyFlagKey = (myId: string, peerId: string): string =>
  `e2eeRekey:${myId}:${peerId}`;
/** 'e2eeLastSN:<myId>:<peerId>' = the last successfully fetched safety number. */
export const e2eeLastSnKey = (myId: string, peerId: string): string =>
  `e2eeLastSN:${myId}:${peerId}`;

/** Strip spaces/whitespace from a safety number for storage/QR/comparison. */
export const cleanSafetyNumber = (digits: string): string => String(digits || '').replace(/\s/g, '');

interface E2eeSafetyModalProps {
  open: boolean;
  peerId: string | null;
  peerName?: string;
  /** Provided by App: engine.getSafetyNumber(peerId) (60-digit string). */
  getSafetyNumber: (peerId: string) => Promise<string>;
  /** Current user id — scopes the 'e2eeVerified' localStorage key. */
  myId?: string | null;
  onClose: () => void;
}

/** 60 digits → 6 blocks of 10 separated by spaces. */
function formatSafetyNumber(digits: string): string {
  const clean = digits.replace(/\D/g, '').slice(0, 60);
  const blocks: string[] = [];
  for (let i = 0; i < clean.length; i += 10) {
    blocks.push(clean.slice(i, i + 10));
  }
  return blocks.join(' ');
}

export function E2eeSafetyModal({ open, peerId, peerName, getSafetyNumber, myId, onClose }: E2eeSafetyModalProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [digits, setDigits] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [attempt, setAttempt] = useState(0);
  // Safety-number QR (scan from the peer's device to compare out-of-band).
  const [qrUrl, setQrUrl] = useState<string | null>(null);
  // Verified state: the stored verification matches the current number.
  const [isVerified, setIsVerified] = useState(false);

  // Fetch the safety number whenever the modal opens for a peer (or a retry
  // is requested). Errors surface in-modal; never throw.
  useEffect(() => {
    if (!open || !peerId) return;
    let cancelled = false;
    setLoading(true);
    setError(null);
    setDigits(null);
    setCopied(false);
    setQrUrl(null);
    setIsVerified(false);
    getSafetyNumber(peerId)
      .then((n) => {
        if (!cancelled) setDigits(String(n || ''));
      })
      .catch(() => {
        if (!cancelled) setError('تعذر جلب رقم الأمان. تأكد من اتصالك ثم أعد المحاولة.');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [open, peerId, attempt, getSafetyNumber]);

  // QR + verified-state resolution once the digits are available. QRCode is
  // async (toDataURL) and renders off the critical path; failures just hide
  // the QR (the digits remain the source of truth).
  useEffect(() => {
    if (!open || !digits) return;
    let cancelled = false;
    const clean = cleanSafetyNumber(digits);
    QRCode.toDataURL(clean, {
      width: 280,
      margin: 2,
      errorCorrectionLevel: 'M',
      color: { dark: '#052e16', light: '#ffffff' },
    })
      .then((url) => {
        if (!cancelled) setQrUrl(url);
      })
      .catch(() => {
        if (!cancelled) setQrUrl(null);
      });
    // Verified state: match the stored number; a DIFFERENT stored number is
    // stale (peer re-registered) → clear it automatically.
    if (myId && peerId) {
      try {
        const stored = localStorage.getItem(e2eeVerifiedKey(myId, peerId));
        if (stored === clean) {
          setIsVerified(true);
        } else if (stored !== null) {
          localStorage.removeItem(e2eeVerifiedKey(myId, peerId));
          setIsVerified(false);
        }
      } catch { /* storage unavailable — treat as unverified */ }
    }
    return () => {
      cancelled = true;
    };
  }, [open, digits, myId, peerId]);

  const handleCopy = useCallback(async () => {
    if (!digits) return;
    try {
      await navigator.clipboard.writeText(digits.replace(/\s/g, ''));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (_) { /* clipboard unavailable — ignore */ }
  }, [digits]);

  // 'توثيق رقم الأمان': persist the CURRENT safety number as the verified
  // reference for this peer. The header badge turns solid emerald as long as
  // future fetches return the same number.
  const handleVerify = useCallback(() => {
    if (!digits || !myId || !peerId) return;
    try {
      localStorage.setItem(e2eeVerifiedKey(myId, peerId), cleanSafetyNumber(digits));
      setIsVerified(true);
    } catch { /* storage unavailable — ignore */ }
  }, [digits, myId, peerId]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[2000] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md bg-zinc-900 border border-white/10 rounded-3xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
        style={{ direction: 'rtl' }}
      >
        {/* Header — mirrors the existing modal pattern (icon + title + close) */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/5">
          <div className="flex items-center gap-2">
            <ShieldCheck size={18} className="text-emerald-400" />
            <h3 className="text-white font-bold text-sm">التحقق من التشفير</h3>
          </div>
          <button onClick={onClose} className="text-zinc-400 hover:text-white" aria-label="إغلاق">
            <X size={18} />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <p className="text-[11px] text-zinc-500 leading-relaxed">
            قارن هذا الرقم مع الطرف الآخر شخصياً أو عبر قناة موثوقة أخرى. إذا تطابق الرقمان لديكما، فهذا يعني أن
            محادثتكما مشفرة طرف-لطرف ولا يمكن لأي طرف ثالث — ولا حتى خوادم ديراشا — قراءة رسائلكما.
          </p>

          {loading && (
            <div className="flex items-center justify-center gap-2 py-6 text-zinc-400 text-sm select-none">
              <Loader2 size={18} className="animate-spin text-emerald-400" />
              <span>جارٍ حساب رقم الأمان...</span>
            </div>
          )}

          {!loading && error && (
            <div className="space-y-3">
              <div className="flex items-start gap-2 p-3 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-300 text-xs leading-relaxed">
                <AlertCircle size={16} className="shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
              <button
                onClick={() => setAttempt(a => a + 1)}
                className="w-full py-2.5 rounded-2xl bg-white/5 border border-white/10 text-zinc-200 font-bold text-xs flex items-center justify-center gap-2 hover:bg-white/10 transition-colors cursor-pointer"
              >
                <RefreshCw size={14} />
                إعادة المحاولة
              </button>
            </div>
          )}

          {!loading && !error && digits && (
            <>
              <div
                dir="ltr"
                className="flex flex-wrap items-center justify-center gap-x-2 gap-y-1.5 p-4 rounded-2xl bg-black/40 border border-white/10 select-all"
              >
                {formatSafetyNumber(digits).split(' ').map((block, i) => (
                  <span
                    key={i}
                    className="font-mono text-[15px] font-bold tracking-widest text-emerald-100/90 tabular-nums"
                  >
                    {block}
                  </span>
                ))}
              </div>

              {/* Safety-number QR — scan from the peer's device to compare */}
              {qrUrl && (
                <div className="flex flex-col items-center gap-2">
                  <div className="p-2 bg-white rounded-2xl border border-white/10">
                    <img
                      src={qrUrl}
                      width={140}
                      height={140}
                      alt="رمز QR لرقم الأمان"
                      className="block rounded-lg"
                    />
                  </div>
                  <span className="text-[10.5px] text-zinc-500 select-none">
                    امسح من جهاز الطرف الآخر للمقارنة
                  </span>
                </div>
              )}

              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopy}
                  className="flex-1 py-2.5 rounded-2xl bg-emerald-500 text-black font-black text-xs flex items-center justify-center gap-2 hover:bg-emerald-400 transition-colors cursor-pointer disabled:opacity-40"
                  disabled={copied}
                >
                  {copied ? <Check size={14} /> : <Copy size={14} />}
                  {copied ? 'تم النسخ' : 'نسخ الرقم'}
                </button>
                {/* Verified-state button: stores the current number, or shows
                    the solid 'موثّق' state while the numbers keep matching. */}
                {isVerified ? (
                  <span
                    className="flex-1 py-2.5 rounded-2xl bg-emerald-500/15 border border-emerald-400/40 text-emerald-300 font-black text-xs flex items-center justify-center gap-2 select-none"
                    title="رقم الأمان موثّق ومطابق للرقم المحفوظ"
                  >
                    <BadgeCheck size={14} />
                    ✓ موثّق
                  </span>
                ) : (
                  <button
                    onClick={handleVerify}
                    className="flex-1 py-2.5 rounded-2xl bg-white/5 border border-emerald-500/40 text-emerald-300 font-black text-xs flex items-center justify-center gap-2 hover:bg-emerald-500/10 transition-colors cursor-pointer"
                    title="حفظ رقم الأمان الحالي كمرجع موثّق لهذا الطرف"
                  >
                    <ShieldCheck size={14} />
                    توثيق رقم الأمان
                  </button>
                )}
              </div>

              <div className="flex items-center gap-1.5 text-[10.5px] text-zinc-500 select-none">
                <Lock size={11} className="text-emerald-500/80 shrink-0" />
                <span>
                  رقم الأمان لـ {peerName ? `«${peerName}»` : 'هذه المحادثة'} — يتم اشتقاقه من مفاتيح الهوية لكما ولا يتغير
                  إلا إذا أعاد أحدكما تسجيل التشفير.
                </span>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
