/**
 * Key Transparency service (Project 2 — AKD-lite per
 * docs/KEY-TRANSPARENCY-DESIGN-ar.md; the simple signed hash-chain design is
 * explicitly REJECTED there: it cannot prevent fork/split-view attacks).
 *
 * Architecture
 * ------------
 * - Append-only audit log `kt_log` (one row per identity/fleet key change;
 *   seq = tree position, NO FK so deletions can never silently rewrite
 *   history — a deletion IS the tampering the proofs detect).
 * - Snapshot `tree_version N` = Merkle root over the first N log entries
 *   (RFC-6962-style checkpoint sequence; N = leaf count, which equals max(seq)
 *   in the gap-free append-only log).
 * - Leaves: H(0x00 || '<seq>|<userId>|<commitment>'); nodes:
 *   H(0x01 || left || right); all sha256, hex strings. Empty tree root =
 *   sha256('') (RFC 6962 convention).
 * - Snapshots are Ed25519-signed ('DirashaKT-v1:<v>:<root>') with the
 *   KT_SIGNING_KEY env seed (base64 Ed25519 private seed). Without the env
 *   var the service runs in documented UNVERIFIED witness mode: proofs are
 *   still served, signature is '' and clients must warn 'unverified'.
 * - Snapshot signing job: setInterval every 5 min, signs a new version only
 *   when the log grew (dirty detection = max(seq) vs latest tree_version).
 *   Best-effort, loud logging, never throws into the event loop.
 *
 * MERKLE PROOF ALGORITHMS
 * -----------------------
 * Split rule (RFC 6962 / RFC 9162): a subtree of size s ≥ 2 splits into a
 * perfect left half of k = largest power of two strictly less than s leaves
 * and a right half of s − k leaves.
 *
 * Inclusion proof: auth path ordered leaf-up (path[0] closest to the leaf);
 * verified by the standard down-walk (reversed path), which recomputes the
 * root from the leaf with sibling positions fully determined by (leafIndex,
 * treeSize) — attacker controls only sibling VALUES, never positions.
 *
 * Consistency proof (RFC-6962-style, standard construction): the proof is the
 * sibling chain along the walk from tree(n) down to tree(m): at each split,
 * if m_rel ≤ k recurse left and emit the right-half root (entirely new), else
 * recurse right and emit the left-half root (entirely old); at the node whose
 * size equals m_rel emit that (fully-old) subtree root. Elements are ordered
 * deepest-first. Verification mirrors generation: a single pass folds
 *   - accN: every element (L-move: H(accN, p), R-move: H(p, accN)) → root_n
 *   - accM: only R-move elements (old-side blocks + deepest old root) → root_m
 * Both must match the anchored roots. Positions are determined by (m, n)
 * alone; an attacker controls only values — hiding/reordering history breaks
 * at least one of the two roots (fork detection, test kt3).
 *
 * All proof functions are PURE and unit-tested exhaustively
 * (tests/key-transparency.test.ts, kt1–kt5).
 *
 * ─── LEAD WIRE-UP POINT (routes/e2ee.ts is owned by the PQ agent this round) ───
 * In `POST /api/e2ee/register` (src/server/routes/e2ee.ts), immediately AFTER
 * the registration transaction COMMITs (right next to the `identityChanged` /
 * `deviceWasNew` rekey-notify block), call:
 *
 *   import { appendKeyChange, computeFleetCommitment } from '../services/key_transparency.ts';
 *
 *   // KT (Project 2): transparency log entry for every identity/fleet change.
 *   // Commitment = hash of the user's CURRENT fleet (legacy row + all devices).
 *   const fleet = await pool.query(
 *     `SELECT 'default' AS device_id, identity_dh_pub, identity_sig_pub FROM e2ee_registrations WHERE user_id = $1
 *      UNION ALL
 *      SELECT device_id, identity_dh_pub, identity_sig_pub FROM e2ee_device_registrations WHERE user_id = $1`,
 *     [userId],
 *   );
 *   void appendKeyChange(userId, computeFleetCommitment(fleet.rows)).catch(() => {});
 *
 * (best-effort: never block or fail the register response on KT).
 */

import { createHash } from 'node:crypto';
import { ed25519 } from '@noble/curves/ed25519';
import { pool } from '../database.ts';
import { logger } from '../logger.ts';
import type {
  KtInclusionProof,
  KtMode,
  KtProofResponse,
  KtRootResponse,
  KtSnapshot,
} from '../../lib/kt-contract.ts';

/* ===================== Hashing primitives (pure) ===================== */

const enc = new TextEncoder();

function sha256Hex(...parts: (Uint8Array | string)[]): string {
  const h = createHash('sha256');
  for (const p of parts) h.update(typeof p === 'string' ? enc.encode(p) : p);
  return h.digest('hex');
}

/** RFC-6962-style leaf hash: H(0x00 || '<seq>|<userId>|<commitment>'). */
export function ktLeafHash(seq: number, userId: string, commitment: string): string {
  return sha256Hex('\x00', `${seq}|${userId}|${commitment}`);
}

/** RFC-6962-style internal node hash: H(0x01 || left || right). */
export function ktNodeHash(left: string, right: string): string {
  return sha256Hex('\x01', left, right);
}

/** Empty-tree root (RFC 6962 convention: sha256 of the empty string). */
export const KT_EMPTY_ROOT = sha256Hex('');

/** Largest power of two strictly less than size (size ≥ 2). RFC split rule. */
export function largestPow2LessThan(size: number): number {
  if (!Number.isInteger(size) || size < 2) throw new Error('size must be an integer ≥ 2');
  let k = 1;
  while (k * 2 < size) k *= 2;
  return k;
}

/* ===================== Merkle tree (pure) ===================== */

export interface MerkleTree {
  /** Hex root ('' tree → KT_EMPTY_ROOT). */
  root: string;
  /** Per-leaf auth paths, leaf-up order (path[0] closest to the leaf). */
  authPaths: string[][];
}

/** Build the RFC-6962-style Merkle tree over hex leaf hashes (pure). */
export function buildMerkleTree(leaves: string[]): MerkleTree {
  const n = leaves.length;
  const authPaths: string[][] = new Array(n);
  for (let i = 0; i < n; i++) authPaths[i] = [];
  if (n === 0) return { root: KT_EMPTY_ROOT, authPaths };
  const root = buildRange(leaves, 0, n, authPaths);
  return { root, authPaths };
}

function buildRange(leaves: string[], lo: number, hi: number, out: string[][]): string {
  if (hi - lo === 1) return leaves[lo];
  const k = largestPow2LessThan(hi - lo);
  const left = buildRange(leaves, lo, lo + k, out);
  const right = buildRange(leaves, lo + k, hi, out);
  // Children paths are leaf-up; the sibling at THIS (shallower) level goes last.
  for (let i = lo; i < lo + k; i++) out[i].push(right);
  for (let i = lo + k; i < hi; i++) out[i].push(left);
  return ktNodeHash(left, right);
}

/**
 * Verify an inclusion proof. The split structure from root to leaf is fully
 * determined by (leafIndex, treeSize) — the attacker controls only sibling
 * VALUES, never positions. Two phases: (1) walk root→leaf to recover the
 * sequence of halves the leaf lives in; (2) fold leaf-up (path[0] is the
 * leaf's closest sibling) combining each sibling on the correct side until
 * the root is recomputed.
 */
export function verifyInclusionProof(
  leafIndex: number,
  treeSize: number,
  leafHash: string,
  authPath: string[],
  root: string,
): boolean {
  if (!Number.isInteger(leafIndex) || !Number.isInteger(treeSize)) return false;
  if (treeSize < 1 || leafIndex < 0 || leafIndex >= treeSize) return false;
  if (!Array.isArray(authPath)) return false;

  // Phase 1: root→leaf walk; record which half the leaf falls into per split.
  const inLeftPerSplit: boolean[] = []; // top-down order
  let lo = 0;
  let hi = treeSize;
  while (hi - lo > 1) {
    const k = largestPow2LessThan(hi - lo);
    const inLeft = leafIndex < lo + k;
    inLeftPerSplit.push(inLeft);
    if (inLeft) hi = lo + k;
    else lo = lo + k;
  }
  if (authPath.length !== inLeftPerSplit.length) return false;

  // Phase 2: leaf-up fold — the DEEPEST split's sibling is authPath[0].
  let fn = leafHash;
  for (let d = inLeftPerSplit.length - 1; d >= 0; d--) {
    const sibling = authPath[inLeftPerSplit.length - 1 - d];
    fn = inLeftPerSplit[d] ? ktNodeHash(fn, sibling) : ktNodeHash(sibling, fn);
  }
  return fn === root;
}

/* ===================== Consistency proof (pure, RFC-6962-style) ===================== */

/**
 * Consistency proof between tree sizes m and n (1 ≤ m ≤ n) over the same
 * append-only leaf sequence. Elements ordered deepest-first (generation
 * order). m === n → empty proof.
 */
export function consistencyProof(leaves: string[], m: number, n: number): string[] {
  if (!Number.isInteger(m) || !Number.isInteger(n)) throw new Error('m and n must be integers');
  if (m < 1 || m > n || n > leaves.length) throw new Error('invalid (m, n) for consistency proof');
  if (m === n) return [];
  const proof: string[] = [];
  recConsistency(leaves, m, 0, n, proof);
  return proof;
}

function recConsistency(leaves: string[], m: number, lo: number, hi: number, proof: string[]): void {
  if (m === hi - lo) {
    proof.push(subRoot(leaves, lo, hi)); // fully-old subtree root: the walk terminates here
    return;
  }
  const k = largestPow2LessThan(hi - lo);
  if (m <= k) {
    // old tree entirely in the left half; right half is entirely new
    recConsistency(leaves, m, lo, lo + k, proof);
    proof.push(subRoot(leaves, lo + k, hi));
  } else {
    // left half fully old; recurse into the right half
    recConsistency(leaves, m - k, lo + k, hi, proof);
    proof.push(subRoot(leaves, lo, lo + k));
  }
}

function subRoot(leaves: string[], lo: number, hi: number): string {
  if (hi - lo === 1) return leaves[lo];
  const k = largestPow2LessThan(hi - lo);
  return ktNodeHash(subRoot(leaves, lo, lo + k), subRoot(leaves, lo + k, hi));
}

/**
 * Verify a consistency proof between sizes m and n given BOTH anchored roots
 * (root_m from the client's stored snapshot, root_n from the current signed
 * snapshot). Mirrors generation: folds every element into root_n and the
 * old-side elements into root_m; both must match. Any deletion/rewrite of a
 * historical entry breaks at least one of the two (fork detection).
 */
export function verifyConsistencyProof(
  m: number,
  n: number,
  proof: string[],
  rootM: string,
  rootN: string,
): boolean {
  if (!Number.isInteger(m) || !Number.isInteger(n)) return false;
  if (m < 1 || m > n) return false;
  if (!Array.isArray(proof)) return false;
  if (m === n) return proof.length === 0 && rootM === rootN;

  // Simulate the generation walk top-down to recover the move sequence
  // (positions are determined by (m, n) alone).
  const moves: Array<'L' | 'R'> = [];
  let lo = 0;
  let hi = n;
  let mRel = m;
  while (hi - lo > 1 && mRel !== hi - lo) {
    const k = largestPow2LessThan(hi - lo);
    if (mRel <= k) {
      moves.push('L');
      hi = lo + k;
    } else {
      moves.push('R');
      lo = lo + k;
      mRel -= k;
    }
  }
  // Deepest node (mRel === hi - lo) emits its own (fully-old) root first.
  if (proof.length !== moves.length + 1) return false;

  let accN = proof[0]; // new-root accumulator (starts at the deepest old subtree root)
  let accM = proof[0]; // old-root accumulator
  for (let i = 1; i <= moves.length; i++) {
    const p = proof[i];
    const move = moves[moves.length - i]; // node_{D-i}'s move
    if (move === 'L') {
      // element = right (entirely new) sibling: only affects root_n
      accN = ktNodeHash(accN, p);
    } else {
      // element = left (entirely old) block: affects both roots
      accN = ktNodeHash(p, accN);
      accM = ktNodeHash(p, accM);
    }
  }
  return accN === rootN && accM === rootM;
}

/* ===================== Fleet commitment (pure) ===================== */

export interface FleetDevice {
  deviceId: string;
  identityDhPub: string;
  identitySigPub?: string | null;
}

/**
 * Canonical commitment over a user's fleet: sha256 over the device lines
 * '<deviceId>:<identityDhPub>:<identitySigPub>' sorted by deviceId (stable
 * canonical form — device ORDER never changes the commitment). Empty fleet →
 * sha256('') (never accepted as a real commitment by callers).
 */
export function computeFleetCommitment(devices: FleetDevice[]): string {
  const lines = [...devices]
    .filter((d) => d && typeof d.deviceId === 'string')
    .sort((a, b) => (a.deviceId < b.deviceId ? -1 : a.deviceId > b.deviceId ? 1 : 0))
    .map((d) => `${d.deviceId}:${d.identityDhPub ?? ''}:${d.identitySigPub ?? ''}`);
  return sha256Hex(lines.join('\n'));
}

/* ===================== Signing (witness key) ===================== */

const KT_SIG_CONTEXT = 'DirashaKT-v1:';
const B64_SEED_RE = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/;

let cachedKey: { seed: Uint8Array; pubB64: string } | null | undefined; // undefined = not loaded yet

/**
 * Load KT_SIGNING_KEY (base64 Ed25519 private seed, 32 bytes) once.
 * Returns null in UNVERIFIED witness mode (env absent/invalid — loud log).
 */
export function getKtSigningKey(): { seed: Uint8Array; pubB64: string } | null {
  if (cachedKey !== undefined) return cachedKey;
  cachedKey = null;
  const raw = process.env.KT_SIGNING_KEY;
  if (!raw) {
    logger.warn(
      '[KT] KT_SIGNING_KEY not configured — Key Transparency runs in UNVERIFIED witness mode: ' +
        'proofs are served but snapshots carry an EMPTY signature; clients must warn "unverified".',
    );
    return null;
  }
  if (!B64_SEED_RE.test(raw.trim())) {
    logger.error('[KT] KT_SIGNING_KEY is not valid std base64 — UNVERIFIED mode.');
    return null;
  }
  const seed = new Uint8Array(Buffer.from(raw.trim(), 'base64'));
  if (seed.length !== 32) {
    logger.error(`[KT] KT_SIGNING_KEY must decode to exactly 32 bytes (got ${seed.length}) — UNVERIFIED mode.`);
    return null;
  }
  cachedKey = { seed, pubB64: Buffer.from(ed25519.getPublicKey(seed)).toString('base64') };
  logger.info('[KT] witness signing key loaded (verified mode).', { pub: cachedKey.pubB64 });
  return cachedKey;
}

/** 'verified' when a witness key is configured, 'unverified' otherwise. */
export function getKtMode(): KtMode {
  return getKtSigningKey() ? 'verified' : 'unverified';
}

/** Test-only: forget the cached witness key so env changes are re-read. */
export function resetKtKeyCacheForTests(): void {
  cachedKey = undefined;
}

/** Canonical snapshot signing message: 'DirashaKT-v1:<treeVersion>:<rootHash>'. */
export function snapshotSigningMessage(treeVersion: number, rootHash: string): Uint8Array {
  return enc.encode(`${KT_SIG_CONTEXT}${treeVersion}:${rootHash}`);
}

/** Ed25519 signature (std base64) or '' in unverified mode. */
export function signSnapshot(treeVersion: number, rootHash: string): string {
  const key = getKtSigningKey();
  if (!key) return '';
  return Buffer.from(ed25519.sign(snapshotSigningMessage(treeVersion, rootHash), key.seed)).toString('base64');
}

/**
 * Verify a snapshot signature. `witnessPubB64` defaults to the server's own
 * witness key (self-check); clients pin an independent key.
 */
export function verifySnapshotSignature(
  treeVersion: number,
  rootHash: string,
  signatureB64: string,
  witnessPubB64?: string,
): boolean {
  const pubB64 = witnessPubB64 ?? getKtSigningKey()?.pubB64;
  if (!pubB64) return false;
  if (typeof signatureB64 !== 'string' || signatureB64.length === 0) return false;
  try {
    return ed25519.verify(
      new Uint8Array(Buffer.from(signatureB64, 'base64')),
      snapshotSigningMessage(treeVersion, rootHash),
      new Uint8Array(Buffer.from(pubB64, 'base64')),
    );
  } catch {
    return false;
  }
}

/* ===================== DB-backed operations ===================== */

const USER_ID_RE = /^[A-Za-z0-9_-]{1,128}$/;
const COMMITMENT_RE = /^[0-9a-f]{64}$/; // hex sha256

export interface AppendResult {
  ok: boolean;
  seq?: number;
  /** 'dedup' = identical commitment already logged (no transparency event). */
  dedup?: boolean;
  prevUserHash?: string | null;
  error?: string;
}

/**
 * Append one key-change entry to the transparency log. BEST-EFFORT by design:
 * never throws — the caller's register flow must never fail because of KT.
 * Deduplicates identical commitments (OPK-only refreshes are NOT key changes).
 */
export async function appendKeyChange(userId: string, commitment: string): Promise<AppendResult> {
  try {
    if (typeof userId !== 'string' || !USER_ID_RE.test(userId)) return { ok: false, error: 'invalid userId' };
    if (typeof commitment !== 'string' || !COMMITMENT_RE.test(commitment)) {
      return { ok: false, error: 'commitment must be a 64-hex sha256' };
    }
    const prev = await pool.query(
      'SELECT key_commitment FROM kt_log WHERE user_id = $1 ORDER BY seq DESC LIMIT 1',
      [userId],
    );
    const prevUserHash: string | null = prev.rows[0]?.key_commitment ?? null;
    if (prevUserHash === commitment) return { ok: true, dedup: true, prevUserHash };
    const res = await pool.query(
      `INSERT INTO kt_log (user_id, key_commitment, tree_version, prev_user_hash)
       VALUES ($1, $2, 0, $3) RETURNING seq`,
      [userId, commitment, prevUserHash],
    );
    return { ok: true, seq: Number(res.rows[0].seq), prevUserHash };
  } catch (err: any) {
    logger.error('[KT] appendKeyChange failed (best-effort, register flow unaffected):', err?.message);
    return { ok: false, error: err?.message };
  }
}

function toSnapshot(row: any): KtSnapshot {
  return {
    treeVersion: Number(row.tree_version),
    rootHash: String(row.root_hash),
    signature: String(row.signature),
    signedAt: row.signed_at ? new Date(row.signed_at).toISOString() : null,
  };
}

/** Current signed snapshot; synthetic version-0 when none exists yet (TOFU bootstrap). */
export async function getCurrentSnapshot(): Promise<KtRootResponse> {
  try {
    const res = await pool.query(
      'SELECT tree_version, root_hash, signature, signed_at FROM kt_snapshots ORDER BY tree_version DESC LIMIT 1',
    );
    if (res.rows.length > 0) return { ...toSnapshot(res.rows[0]), mode: getKtMode() };
  } catch (err: any) {
    logger.error('[KT] getCurrentSnapshot failed:', err?.message);
  }
  return { treeVersion: 0, rootHash: KT_EMPTY_ROOT, signature: '', signedAt: null, mode: getKtMode() };
}

export interface SnapshotCycleResult {
  signed: boolean;
  reason?: 'clean' | 'no-entries' | 'db-unavailable' | 'error';
  treeVersion?: number;
  rootHash?: string;
  signature?: string;
}

/**
 * One snapshot-signing cycle: if the log grew past the latest snapshot, build
 * the tree over ALL entries, sign, and publish the checkpoint. Idempotent and
 * best-effort (used by the scheduler; safe to call manually/tests).
 */
export async function runKtSnapshotCycle(): Promise<SnapshotCycleResult> {
  try {
    const latest = await pool.query(
      'SELECT tree_version FROM kt_snapshots ORDER BY tree_version DESC LIMIT 1',
    );
    const latestVersion = latest.rows.length > 0 ? Number(latest.rows[0].tree_version) : 0;
    const maxSeq = await pool.query('SELECT COALESCE(MAX(seq), 0) AS max_seq FROM kt_log');
    const max = Number(maxSeq.rows[0].max_seq);
    if (max <= latestVersion) return { signed: false, reason: 'clean', treeVersion: latestVersion };

    const entries = await pool.query('SELECT seq, user_id, key_commitment FROM kt_log ORDER BY seq');
    if (entries.rows.length === 0) return { signed: false, reason: 'no-entries' };
    const treeVersion = entries.rows.length; // = leaf count (gap-free append-only log)
    const leaves = entries.rows.map((r: any) => ktLeafHash(Number(r.seq), String(r.user_id), String(r.key_commitment)));
    const rootHash = buildMerkleTree(leaves).root;
    const signature = signSnapshot(treeVersion, rootHash);
    await pool.query(
      `INSERT INTO kt_snapshots (tree_version, root_hash, signature, signed_at)
       VALUES ($1, $2, $3, now()) ON CONFLICT (tree_version) DO NOTHING`,
      [treeVersion, rootHash, signature],
    );
    // Mark the covered entries with the snapshot version that first includes them.
    const coveredMaxSeq = Number(entries.rows[entries.rows.length - 1].seq);
    await pool.query('UPDATE kt_log SET tree_version = $1 WHERE tree_version = 0 AND seq <= $2', [
      treeVersion,
      coveredMaxSeq,
    ]);
    if (signature === '') {
      logger.warn(
        `[KT] snapshot v${treeVersion} published UNSIGNED (unverified witness mode): root=${rootHash.slice(0, 16)}…`,
      );
    } else {
      logger.info(`[KT] snapshot v${treeVersion} signed: root=${rootHash.slice(0, 16)}…`);
    }
    return { signed: true, treeVersion, rootHash, signature };
  } catch (err: any) {
    logger.error('[KT] snapshot cycle failed (best-effort):', err?.message);
    return { signed: false, reason: 'error' };
  }
}

let snapshotTimer: ReturnType<typeof setInterval> | null = null;
export const KT_SNAPSHOT_INTERVAL_MS = 5 * 60 * 1000;

/**
 * Start the 5-min snapshot signer (one initial cycle after 15 s, then every
 * 5 min when dirty). Best-effort: every failure is logged loudly, never thrown.
 */
export function startKtSnapshotScheduler(): void {
  if (snapshotTimer) return;
  setTimeout(() => {
    void runKtSnapshotCycle();
  }, 15_000).unref?.();
  snapshotTimer = setInterval(() => {
    void runKtSnapshotCycle().catch((err: any) =>
      logger.error('[KT] scheduled snapshot cycle crashed:', err?.message),
    );
  }, KT_SNAPSHOT_INTERVAL_MS);
  snapshotTimer.unref?.();
  logger.info('[KT] snapshot scheduler started (5 min interval, dirty-only).');
}

export function stopKtSnapshotScheduler(): void {
  if (snapshotTimer) {
    clearInterval(snapshotTimer);
    snapshotTimer = null;
  }
}

/** All log entries covered by snapshot version `treeVersion` (leaf order = seq order). */
async function loadSnapshotLeaves(treeVersion: number): Promise<Array<{ seq: number; userId: string; commitment: string }>> {
  const res = await pool.query(
    'SELECT seq, user_id, key_commitment FROM kt_log ORDER BY seq LIMIT $1',
    [treeVersion],
  );
  return res.rows.map((r: any) => ({ seq: Number(r.seq), userId: String(r.user_id), commitment: String(r.key_commitment) }));
}

/**
 * Build the client proof package: inclusion proof for the user's CURRENT
 * commitment within the latest signed snapshot + consistency proof from the
 * client's anchored version. Pure proof math; DB access is read-only.
 */
export async function getKtProof(userId: string, sinceVersion?: number): Promise<KtProofResponse> {
  const snapshot = await getCurrentSnapshot();
  const out: KtProofResponse = { userId, found: false, snapshot };

  if (!Number.isInteger(snapshot.treeVersion) || snapshot.treeVersion < 1) return out;

  const leavesRows = await loadSnapshotLeaves(snapshot.treeVersion);
  if (leavesRows.length === 0) return out;
  const leaves = leavesRows.map((r) => ktLeafHash(r.seq, r.userId, r.commitment));

  // Latest entry of this user within the snapshot (highest seq).
  let leafIndex = -1;
  for (let i = leavesRows.length - 1; i >= 0; i--) {
    if (leavesRows[i].userId === userId) {
      leafIndex = i;
      break;
    }
  }
  if (leafIndex >= 0) {
    const { authPaths } = buildMerkleTree(leaves);
    const row = leavesRows[leafIndex];
    out.found = true;
    out.inclusion = {
      leafIndex,
      treeSize: snapshot.treeVersion,
      leafHash: leaves[leafIndex],
      authPath: authPaths[leafIndex],
      commitment: row.commitment,
      seq: row.seq,
    };
  }

  const since = typeof sinceVersion === 'number' && Number.isInteger(sinceVersion) ? sinceVersion : undefined;
  if (since !== undefined && since >= 1 && since < snapshot.treeVersion) {
    const anchor = await pool.query('SELECT root_hash FROM kt_snapshots WHERE tree_version = $1', [since]);
    if (anchor.rows.length > 0) {
      out.consistency = {
        fromVersion: since,
        toVersion: snapshot.treeVersion,
        proof: consistencyProof(leaves, since, snapshot.treeVersion),
      };
    } else {
      logger.warn(`[KT] proof request for ${userId}: unknown sinceVersion ${since} — no consistency proof (client must re-anchor via TOFU).`);
    }
  }
  return out;
}

/* Re-exports for client-side reuse (client contract lives in src/lib/kt-contract.ts). */
export type {
  KtInclusionProof,
  KtMismatchReport,
  KtMode,
  KtProofResponse,
  KtRootResponse,
  KtSnapshot,
} from '../../lib/kt-contract.ts';
