/**
 * Group Call HTTP Routes — /api/group-calls
 * ------------------------------------------
 *   POST /api/group-calls            → create a session          { chatId }
 *   POST /api/group-calls/:id/join   → join (membership+capacity) → roster
 *   POST /api/group-calls/:id/leave  → leave                      → ok
 *   GET  /api/group-calls?chatId=…   → active sessions for a chat
 *
 * ── HOW SIGNALING WORKS (IMPORTANT) ─────────────────────────────────
 * Media signaling does NOT go through these routes. Live WebRTC
 * offer/answer/ICE relay rides the EXISTING 1:1 `call:signal` WebSocket
 * relay in src/server/websocket/ws_server.ts (handleCallSignal), which
 * forwards {callId, senderId, signal} to the receiver's `user:updates:*`
 * channel. For group calls, clients simply put the `groupCallId` in the
 * `callId` field (or a sibling `groupCallId` field) of the `call:signal`
 * payload and address each other participant via `receiverId`. Each peer
 * therefore has one RTCPeerConnection per other participant (mesh, ≤4),
 * managed client-side by src/lib/groupCallMesh.ts. NO ws_server changes
 * are required for this to work — the server relays opaque payloads.
 *
 * Mounting (coordinator integration step):
 *   import { registerGroupCallRoutes } from './src/server/routes/groupCallRoutes.ts';
 *   registerGroupCallRoutes(app, { requireAuth });
 */

import type { Express, Request, Response, NextFunction } from 'express';
import { Router } from 'express';
import { db } from '../database.ts';
import {
  createGroupCall,
  joinGroupCall,
  leaveGroupCall,
  listActive,
  GroupCallError,
} from '../groupCallSessions.ts';

interface GroupCallRouteDeps {
  requireAuth: (req: Request, res: Response, next: NextFunction) => void;
}

export const groupCallRouter = Router();

function errStatus(code: string): number {
  switch (code) {
    case 'NOT_FOUND': return 404;
    case 'FULL': return 409;
    case 'ALREADY_IN_CALL': return 409;
    case 'NOT_A_PARTICIPANT': return 404;
    default: return 500;
  }
}

/** Is the user a current member of the chat? (membership gate for every route) */
async function isChatMember(chatId: string, userId: string): Promise<boolean> {
  const members = await db.getChatMembers(chatId);
  return members.some(m => m.userId === userId);
}

export function registerGroupCallRoutes(app: Express, deps: GroupCallRouteDeps): void {
  const { requireAuth } = deps;
  app.use('/api/group-calls', requireAuth, groupCallRouter);
}

/* Create a group call in a chat the caller belongs to. */
groupCallRouter.post('/', async (req: Request, res: Response) => {
  try {
    const userId = req.user!.userId;
    const { chatId } = req.body || {};
    if (!chatId || typeof chatId !== 'string') {
      return res.status(400).json({ error: 'chatId is required' });
    }
    if (!(await isChatMember(chatId, userId))) {
      return res.status(403).json({ error: 'You are not a member of this chat' });
    }
    const session = createGroupCall(chatId, userId);
    res.status(201).json({
      groupCallId: session.groupCallId,
      chatId: session.chatId,
      initiatorId: session.initiatorId,
      participants: [],
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

/* Join: validates chat membership + capacity, returns roster to dial. */
groupCallRouter.post('/:id/join', async (req: Request, res: Response) => {
  try {
    const userId = req.user!.userId;
    const groupCallId = req.params.id;
    const session = joinGroupCall(groupCallId, userId); // throws NOT_FOUND / FULL
    if (!(await isChatMember(session.chatId, userId))) {
      leaveGroupCall(groupCallId, userId); // undo optimistic add
      return res.status(403).json({ error: 'You are not a member of this chat' });
    }
    res.json(session); // { groupCallId, chatId, initiatorId, participants[] }
  } catch (error: any) {
    if (error instanceof GroupCallError) {
      return res.status(errStatus(error.code)).json({ error: error.message, code: error.code });
    }
    res.status(500).json({ error: error.message });
  }
});

/* Leave (idempotent). */
groupCallRouter.post('/:id/leave', async (req: Request, res: Response) => {
  try {
    const userId = req.user!.userId;
    leaveGroupCall(req.params.id, userId);
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

/* List active group calls for a chat (chat members only). */
groupCallRouter.get('/', async (req: Request, res: Response) => {
  try {
    const userId = req.user!.userId;
    const chatId = req.query.chatId as string;
    if (!chatId) {
      return res.status(400).json({ error: 'chatId query parameter is required' });
    }
    if (!(await isChatMember(chatId, userId))) {
      return res.status(403).json({ error: 'You are not a member of this chat' });
    }
    res.json({ calls: listActive(chatId) });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});
