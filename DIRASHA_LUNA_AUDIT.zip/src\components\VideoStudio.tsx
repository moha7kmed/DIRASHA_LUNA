import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence, useMotionValue, useTransform } from 'motion/react';
import { X, Play, Pause, Volume2, VolumeX, Plus, Scissors, Type, Trash2, Check, Download, Layers } from 'lucide-react';

interface TextOverlay {
  id: string;
  text: string;
  x: number; // percentage
  y: number; // percentage
  fontSize: number;
  color: string;
}

interface VideoStudioProps {
  file: File;
  onCancel: () => void;
  onSend: (file: File, options: { caption: string; startTime: number; endTime: number; textOverlays: TextOverlay[] }) => void;
  submitLabel?: string;
  submitIcon?: any;
  isSubmitting?: boolean;
}

export function VideoStudio({
  file,
  onCancel,
  onSend,
  submitLabel = 'Post Status',
  submitIcon: SubmitIcon = Plus,
  isSubmitting = false
}: VideoStudioProps) {
  const [videoUrl, setVideoUrl] = useState<string>('');
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [caption, setCaption] = useState('');
  const [duration, setDuration] = useState(0);
  const [startTime, setStartTime] = useState(0);
  const [endTime, setEndTime] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  
  const [textOverlays, setTextOverlays] = useState<TextOverlay[]>([]);
  const [activeTextId, setActiveTextId] = useState<string | null>(null);
  const [isAddingText, setIsAddingText] = useState(false);
  const [tempText, setTempText] = useState('');

  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const trimmerTrackRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const url = URL.createObjectURL(file);
    setVideoUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const onLoadedMetadata = () => {
    if (videoRef.current) {
      const d = videoRef.current.duration;
      if (d !== Infinity && !isNaN(d)) {
        setDuration(d);
        if (endTime === 0) setEndTime(d);
      }
    }
  };

  const onDurationChange = () => {
    if (videoRef.current) {
      const d = videoRef.current.duration;
      if (d !== Infinity && !isNaN(d)) {
        setDuration(d);
        if (endTime === 0) setEndTime(d);
      }
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const t = videoRef.current.currentTime;
      setCurrentTime(t);
      
      // Loop within range
      if (t >= endTime) {
        videoRef.current.currentTime = startTime;
      }
      if (t < startTime) {
        videoRef.current.currentTime = startTime;
      }
    }
  };

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const addTextOverlay = (e: React.MouseEvent) => {
    if (!isAddingText || !containerRef.current) return;
    
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    const newText: TextOverlay = {
      id: Math.random().toString(36).substr(2, 9),
      text: tempText || 'Tap to edit',
      x,
      y,
      fontSize: 24,
      color: '#ffffff'
    };

    setTextOverlays([...textOverlays, newText]);
    setIsAddingText(false);
    setTempText('');
    setActiveTextId(newText.id);
  };

  const removeTextOverlay = (id: string) => {
    setTextOverlays(textOverlays.filter(t => t.id !== id));
    if (activeTextId === id) setActiveTextId(null);
  };

  const handleSend = () => {
    onSend(file, { caption, startTime, endTime, textOverlays });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0 z-50 bg-black flex flex-col md:flex-row items-stretch justify-center backdrop-blur-3xl overflow-hidden"
    >
      {/* Mobile Top Header */}
      <div className="absolute top-0 left-0 right-0 p-4 z-[60] flex justify-between items-center bg-gradient-to-b from-black/60 to-transparent md:hidden">
        <button onClick={onCancel} className="p-2 text-white">
          <X className="w-6 h-6" />
        </button>
        <button
          onClick={() => setIsAddingText(true)}
          className={`px-4 py-2 rounded-full border border-white/10 flex items-center gap-2 ${isAddingText ? 'bg-white text-black' : 'bg-white/10 text-white'}`}
        >
          <Type className="w-4 h-4" />
          <span className="text-sm font-bold">Text</span>
        </button>
      </div>

      {/* Main Preview (Left on Desktop, Top on Mobile) */}
      <div className="flex-1 min-h-0 relative flex items-center justify-center p-4 md:p-10">
        <div 
          ref={containerRef}
          className="relative w-full h-full max-w-[500px] aspect-[9/16] rounded-3xl md:rounded-[44px] overflow-hidden bg-zinc-900 border border-white/10 shadow-2xl flex items-center justify-center shrink-0"
          onClick={(e) => isAddingText ? addTextOverlay(e) : togglePlay()}
        >
          {videoUrl && (
            <video
              ref={videoRef}
              src={videoUrl}
              autoPlay
              loop
              muted={isMuted}
              playsInline
              onLoadedMetadata={onLoadedMetadata}
              onDurationChange={onDurationChange}
              onTimeUpdate={handleTimeUpdate}
              className="w-full h-full object-contain"
            />
          )}

          {/* Overlays */}
          <div className="absolute inset-0 pointer-events-none z-10">
            {textOverlays.map((overlay) => (
              <motion.div
                key={overlay.id}
                drag
                dragMomentum={false}
                onDragEnd={(_, info) => {
                   const rect = containerRef.current!.getBoundingClientRect();
                   const newX = overlay.x + (info.offset.x / rect.width) * 100;
                   const newY = overlay.y + (info.offset.y / rect.height) * 100;
                   setTextOverlays(textOverlays.map(t => t.id === overlay.id ? { ...t, x: newX, y: newY } : t));
                }}
                style={{
                  position: 'absolute',
                  left: '50%',
                  bottom: '20px',
                  transform: 'translateX(-50%)',
                  color: overlay.color,
                  fontSize: `${overlay.fontSize}px`,
                  fontWeight: 'bold',
                  textShadow: '0 2px 8px rgba(0,0,0,1)',
                  pointerEvents: 'auto',
                  cursor: 'move',
                  textAlign: 'center',
                  width: '90%'
                }}
                className="px-3 py-1 hover:ring-2 ring-white/50 rounded-lg"
                onClick={(e) => { e.stopPropagation(); setActiveTextId(overlay.id); }}
              >
                {overlay.text}
                {activeTextId === overlay.id && (
                  <button onClick={() => removeTextOverlay(overlay.id)} className="absolute -top-3 -right-3 bg-red-500 text-white p-1 rounded-full"><Trash2 className="w-3 h-3" /></button>
                )}
              </motion.div>
            ))}
          </div>

          <AnimatePresence>
            {isAddingText && (
               <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 z-50 bg-black/70 backdrop-blur-md flex flex-col items-center justify-center p-10">
                  <input
                    autoFocus
                    className="w-full bg-transparent border-b-2 border-white text-white text-center text-3xl font-bold py-4 outline-none"
                    placeholder="Enter text..."
                    value={tempText}
                    onChange={(e) => setTempText(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && setIsAddingText(false)}
                  />
                  <p className="mt-4 text-white/50">Tap video to place</p>
               </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Editor Sidebar (Right on Desktop, Bottom on Mobile) */}
      <div className="w-full md:w-[380px] h-fit md:h-full bg-zinc-950 md:bg-white/[0.03] backdrop-blur-3xl border-t md:border-t-0 md:border-l border-white/10 p-6 flex flex-col gap-6 z-50 overflow-y-auto shrink-0">
         <div className="hidden md:flex justify-between items-center mb-2">
            <h2 className="text-white font-black uppercase tracking-widest text-lg">Editor</h2>
            <button onClick={onCancel} className="p-2 text-white/50 hover:text-white"><X className="w-6 h-6" /></button>
         </div>

         {/* Trimmer Segment */}
         <div className="flex flex-col gap-4">
            <div className="flex justify-between items-center px-1">
               <span className="flex items-center gap-2 text-white/90 text-[13px] font-bold">
                 <Scissors className="w-4 h-4" />
                 <span>Trim Sequence</span>
               </span>
               <span className="text-white/40 text-[10px] font-mono tracking-wider font-bold">{(endTime - startTime).toFixed(1)}s Selected</span>
            </div>

            <div className="bg-white/5 rounded-3xl p-4 border border-white/10">
               <div className="flex flex-col gap-5 relative">
                  <div className="relative pt-3">
                     <div className="absolute top-0 left-0 right-0 flex justify-between px-1">
                        <span className="text-[9px] font-bold text-white/40 uppercase tracking-tighter">Start point</span>
                        <span className="text-[10px] font-mono text-white/60">{startTime.toFixed(1)}s</span>
                     </div>
                     <input
                       type="range"
                       min={0}
                       max={duration}
                       step={0.1}
                       value={startTime}
                       onChange={(e) => setStartTime(Math.min(parseFloat(e.target.value), endTime - 0.5))}
                       className="w-full h-1.5 bg-white/10 rounded-full appearance-none accent-white cursor-pointer"
                     />
                  </div>
                  <div className="relative pt-3">
                     <div className="absolute top-0 left-0 right-0 flex justify-between px-1">
                        <span className="text-[9px] font-bold text-sky-400/60 uppercase tracking-tighter">End point</span>
                        <span className="text-[10px] font-mono text-sky-400">{endTime.toFixed(1)}s</span>
                     </div>
                     <input
                       type="range"
                       min={0}
                       max={duration}
                       step={0.1}
                       value={endTime}
                       onChange={(e) => setEndTime(Math.max(parseFloat(e.target.value), startTime + 0.5))}
                       className="w-full h-1.5 bg-white/10 rounded-full appearance-none accent-sky-400 cursor-pointer"
                     />
                  </div>
               </div>
            </div>
         </div>

         {/* Controls Segment */}
         <div className="flex flex-col gap-4">
            <div className="flex gap-3">
               <button onClick={togglePlay} className="flex-1 h-14 bg-white/5 hover:bg-white/10 text-white rounded-[20px] border border-white/10 flex items-center justify-center transition-all">
                  {isPlaying ? <Pause className="w-5 h-5 fill-white" /> : <Play className="w-5 h-5 fill-white" />}
               </button>
               <button onClick={() => setIsMuted(!isMuted)} className="flex-1 h-14 bg-white/5 hover:bg-white/10 text-white rounded-[20px] border border-white/10 flex items-center justify-center transition-all">
                  {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
               </button>
               <button onClick={() => setIsAddingText(true)} className="flex-1 h-14 bg-white/5 hover:bg-white/10 text-white rounded-[20px] border border-white/10 flex items-center justify-center transition-all">
                  <Type className="w-5 h-5" />
               </button>
            </div>
         </div>

         {/* Caption Segment */}
         <div className="flex flex-col gap-4">
            <div className="bg-white/5 rounded-3xl p-1 px-4 border border-white/10 flex items-center gap-3 group focus-within:ring-2 ring-white/10 transition-all">
               <Layers className="w-5 h-5 text-white/20" />
               <input
                 type="text"
                 placeholder="Write a status caption..."
                 value={caption}
                 onChange={(e) => setCaption(e.target.value)}
                 className="flex-1 bg-transparent py-4 outline-none text-white font-medium"
               />
            </div>
         </div>

         {/* Footer Segment - Fixed Button */}
         <div className="mt-auto pt-4 md:pt-10 sticky bottom-0 bg-transparent">
            <button
               onClick={handleSend}
               disabled={isSubmitting}
               className="w-full h-16 bg-white text-black rounded-[24px] flex items-center justify-center gap-3 font-black uppercase tracking-widest text-sm hover:scale-[1.01] active:scale-95 transition-all shadow-xl shadow-white/5 disabled:opacity-50 disabled:pointer-events-none"
            >
               {isSubmitting ? (
                 <div className="w-6 h-6 border-2 border-black border-t-transparent rounded-full animate-spin" />
               ) : (
                 <SubmitIcon className="w-6 h-6" />
               )}
               <span>{isSubmitting ? 'UPLOADING...' : submitLabel}</span>
            </button>
         </div>
      </div>

    </motion.div>
  );
}
