/**
 * DIR-NEW-10 (external audit) — per-file media tokens + public Drive share
 * endpoint removed.
 *
 * The review found (a) /api/media-token issued resource-agnostic tokens even
 * though generateMediaToken supports resourceType/resourceId binding, and
 * (b) POST /api/storage/gdrive/share still exposed shareFileToAnyone()
 * (Drive permission type 'anyone', role 'reader') — a public-link capability
 * that contradicts the private-media model of the media proxy.
 *
 * Static asserts (repo convention — server.ts boots a listener at import, so
 * route wiring is asserted against the source):
 *   1. The media-token route passes { resourceType:'media', resourceId } to
 *      generateMediaToken when ?fileId= is present, echoes resourceId, and
 *      keeps the unbound response shape when absent.
 *   2. NO shareFileToAnyone route registration remains in server.ts or
 *      storage.ts (and storage.ts no longer even imports the helper).
 *   3. gdriveMediaHandler compares the token's resourceId claim with the
 *      resolved fileId and fails closed with 403 on mismatch.
 *
 * Run: npx vitest run tests/media-token-scope.test.ts
 */
import { describe, it, expect } from 'vitest';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const serverSrc = fs.readFileSync(path.join(repoRoot, 'server.ts'), 'utf8');
const storageSrc = fs.readFileSync(
  path.join(repoRoot, 'src/server/routes/storage.ts'),
  'utf8',
);

function mediaTokenRouteBlock(): string {
  const start = serverSrc.indexOf("app.get('/api/media-token'");
  expect(start, 'media-token route must exist').toBeGreaterThan(-1);
  const end = serverSrc.indexOf("app.get('/api/users/me'", start);
  return serverSrc.slice(start, end > start ? end : undefined);
}

describe('media-token route — optional per-file binding (DIR-NEW-10)', () => {
  it('reads ?fileId= and passes { resourceType: "media", resourceId } to generateMediaToken', () => {
    const block = mediaTokenRouteBlock();
    expect(block).toContain('req.query.fileId');
    expect(block).toContain("resourceType: 'media'");
    expect(block).toContain('resourceId: fileId');
    expect(block).toContain('AuthService.generateMediaToken(');
  });

  it('echoes resourceId only when the token is file-bound (unbound shape unchanged)', () => {
    const block = mediaTokenRouteBlock();
    expect(block).toContain('...(fileId ? { resourceId: fileId } : {})');
    // The unbound response keeps its original keys.
    expect(block).toContain('mediaToken');
    expect(block).toContain('expiresInSec: 120');
    expect(block).toContain("usage: 'Append as ?access_token=<mediaToken> to GET media URLs'");
  });

  it('rejects a malformed fileId with 400 (same shape rule as the media handler)', () => {
    const block = mediaTokenRouteBlock();
    expect(block).toContain("/^[A-Za-z0-9_-]{10,}$/.test(fileId)");
    expect(block).toContain('معرّف ملف غير صالح.');
  });
});

describe('public Drive share endpoint removal (DIR-NEW-10)', () => {
  it('no POST /api/storage/gdrive/share registration remains in server.ts', () => {
    expect(serverSrc).not.toMatch(/app\.post\(\s*['"]\/api\/storage\/gdrive\/share['"]/);
    expect(serverSrc).not.toContain('shareFileToAnyone');
  });

  it('no POST /api/storage/gdrive/share registration remains in storage.ts', () => {
    expect(storageSrc).not.toMatch(/app\.post\(\s*['"]\/api\/storage\/gdrive\/share['"]/);
    // The route block is replaced by the removal rationale, not deleted silently.
    expect(storageSrc).toContain('DIR-NEW-10');
    expect(storageSrc).toContain('POST /api/storage/gdrive/share');
    expect(storageSrc).toContain('shareFileToAnyone()');
    // storage.ts no longer imports the (unused) helper either.
    expect(storageSrc).not.toContain('shareFileToAnyone,');
  });

  it('records why the public-link capability was removed', () => {
    const block = storageSrc.slice(
      storageSrc.indexOf('DIR-NEW-10'),
      storageSrc.indexOf("app.post('/api/storage/gdrive/upload-ticket'"),
    );
    expect(block).toContain("'anyone'");
    expect(block).toContain('reader');
    expect(block).toContain('private-media model');
  });
});

describe('gdriveMediaHandler — per-file token enforcement (DIR-NEW-10)', () => {
  it('compares the token resourceId claim with the resolved fileId and 403s on mismatch', () => {
    // The check sits after the fileId resolution inside gdriveMediaHandler.
    const handlerBlock = storageSrc.slice(
      storageSrc.indexOf('const gdriveMediaHandler'),
      storageSrc.indexOf("app.get('/api/media/gdrive'"),
    );
    expect(handlerBlock).toContain('req.user as { resourceId?: string }');
    expect(handlerBlock).toContain('boundResourceId && boundResourceId !== fileId');
    expect(handlerBlock).toContain('return res.status(403)');
    // Claim-less tokens still pass (membership gate is their boundary).
    expect(handlerBlock).toContain('boundResourceId &&');
  });

  it('keeps the current-chat-membership check as the boundary for claim-less tokens', () => {
    const handlerBlock = storageSrc.slice(
      storageSrc.indexOf('const gdriveMediaHandler'),
      storageSrc.indexOf("app.get('/api/media/gdrive'"),
    );
    expect(handlerBlock).toContain('isCurrentChatMember(members, req.user?.userId)');
    // The binding check runs BEFORE the (cheap) membership lookup — fail fast.
    const bindIdx = handlerBlock.indexOf('boundResourceId');
    const memberIdx = handlerBlock.indexOf('isCurrentChatMember(members, req.user?.userId)');
    expect(bindIdx).toBeGreaterThan(-1);
    expect(memberIdx).toBeGreaterThan(bindIdx);
  });
});
