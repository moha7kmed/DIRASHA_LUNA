/**
 * Dirasha E2EE — group messaging via Signal-style Sender Keys (phase 2 module).
 *
 * Contract: E2EE-SPEC.md "Phase 2 module contracts — Groups".
 *
 * Design (pure module — wiring done by the lead):
 *   - Each member keeps one random 32B sender key per group ('gsk:<groupId>').
 *   - Message chain is STATELESS: mk_n = HKDF-SHA256(ikm = senderKey,
 *     salt = zeros(32), info = 'DirashaGroupChain-v1|<n>', 32B) — any n can be
 *     derived independently, so out-of-order delivery works with no receiver
 *     chain state and no skipped-key bookkeeping.
 *   - Wire format: content = 'DIRG1:' + b64(JSON { v, skId, n, iv, ct }) with
 *     AAD = UTF8(`${v}|${groupId}|${skId}|${n}`) (grep GROUP_AAD_TEMPLATE).
 *   - Sender-key distribution travels PAIRWISE through the 1:1 engine: the
 *     integration layer sends distributionPayload() to every member via
 *     engine.encryptMessage (the ctrl JSON rides as the DIR1 plaintext) and
 *     feeds inbound ctrl payloads into processControl().
 *   - Received member keys persist under 'gmi:<groupId>:<peerId>'.
 *
 *   const groups = new GroupCrypto({ store, namespace: accountUid });
 *   await groups.ensureSenderKey(groupId);
 *   const payload = groups.distributionPayload(groupId); // send pairwise (DIR1)
 *   const content = await groups.encryptGroupMessage(groupId, 'hello'); // 'DIRG1:...'
 *   const r = await groups.decryptGroupMessage(groupId, senderId, content);
 *
 * Every state mutation is persisted immediately (crash-safe); counters are
 * clone-and-save. Decryption NEVER throws — failures come back as
 * { error: <ErrorName> } (error names match the typed errors of types.ts).
 */

import { kdfCk } from './crypto.ts';

import { NamespacedKVStore } from './store.ts';
import { E2eeError } from './types.ts';
import type { KVStore } from './types.ts';
import {
  KEY_BYTES,
  NONCE_BYTES,
  b64decode,
  b64encode,
  aeadOpen,
  aeadSeal,
  randomBytes,
  utf8Decode,
  utf8Encode,
} from './crypto.ts';

/* ── Protocol constants ───────────────────────────────────────────────────── */

/** Wire prefix of every group message. */
export const GROUP_WIRE_PREFIX = 'DIRG1:';
/** Group envelope version — v2 = ratcheted sender keys + replay protection. */
export const GROUP_WIRE_VERSION = 2;
/** Sender-key chain info string: info = INFO_GROUP_CHAIN + '|' + n. */
export const INFO_GROUP_CHAIN = 'DirashaGroupChain-v1';
/**
 * Grep-able single source of the group AAD construction used by BOTH encrypt
 * and decrypt. The AD bytes are UTF8(groupAad(v, groupId, skId, n)).
 */
export const GROUP_AAD_TEMPLATE = '${v}|${groupId}|${skId}|${n}|${senderId}|${mv}';
/** `kind` of every group control payload riding inside a pairwise DIR1 message. */
export const GROUP_CTRL_KIND = 'dirasha-ctrl-v1';
/** Sentinel senderId meaning "decrypt with our OWN sender key" (gsk). */
export const SELF = 'self';
/** Max out-of-order gap a receiver tolerates per sender chain (Signal pattern). */
export const GROUP_MAX_SKIP = 1000;
/** Bounded cache of OWN consumed message keys for local re-decrypt. */
export const GROUP_SELF_SKIP_MAX = 500;

/* ── Persisted / wire shapes ──────────────────────────────────────────────── */

/** kv key 'gsk:<groupId>' — our OWN sender-key CHAIN state (v2 ratchet). */
export interface SenderKeyRecord {
  keyId: number;
  epoch: number;
  /** b64 of the 32-byte CHAIN key (one-way ratchet — kdfCk). */
  chainKey: string;
  n: number;
  selfSkipped: Array<{ n: number; mk: string }>;
}

/** kv key 'gmi:<groupId>:<peerId>' — a member's CHAIN state received via ctrl. */
export interface MemberKeyRecord {
  keyId: number;
  epoch: number;
  chainKey: string;
  nextN: number;
  skipped: Array<{ n: number; mk: string }>;
  receivedAt: number;
}

/** Control payload distributed pairwise through the 1:1 engine (DIR1 plaintext). */
export interface GroupCtrlPayload {
  kind: 'dirasha-ctrl-v1';
  type: 'sender-key';
  groupId: string;
  keyId: number;
  epoch: number;
  /** b64 of the member's chain key AT the distribution point. */
  key: string;
  /**
   * DIR-NEW-03: chain position at distribution — receiver's nextN := THIS
   * value (the sender's next message index), never 0. Required in v2.
   */
  n: number;
}

/** Parsed group wire envelope: content === 'DIRG1:' + b64(JSON.stringify(this)). */
export interface GroupEnvelope {
  v: number;
  /** Sender's keyId (identifies both the key and its epoch lineage). */
  skId: number;
  /** Sequence number within the sender's chain (stateless derivation index). */
  n: number;
  /** b64 of the 12-byte ChaCha20-Poly1305 nonce. */
  iv: string;
  /** b64 of ciphertext + 16-byte Poly1305 tag. */
  ct: string;
  /** Membership epoch the message was composed under (bound into AAD). */
  mv: number;
  /** Wire-bound sender identity (public metadata, AAD-consistent — anti-spoof). */
  senderId: string;
}

export type GroupDecryptResult = { plaintext: string } | { error: string };

/* ── Pure helpers (exported for tests / integrators) ──────────────────────── */

/**
 * Canonical group AD string. Must stay byte-identical to GROUP_AAD_TEMPLATE
 * (grep-able single source; encrypt and decrypt both go through this).
 */
export function groupAad(v: number, groupId: string, skId: number, n: number, senderId: string, mv: number): string {
  return `${v}|${groupId}|${skId}|${n}|${senderId}|${mv}`;
}

/**
 * v2 chain step (Signal KDF_CK via crypto.ts): message key = HMAC(ck, 0x01),
 * next chain key = HMAC(ck, 0x02) — the SAME primitive as the 1:1 ratchet.
 */
export function groupNextMessageKey(chainKeyB64: string): { mk: Uint8Array; nextChainKeyB64: string } {
  const step = kdfCk(b64decode(chainKeyB64));
  return { mk: step.mk, nextChainKeyB64: b64encode(step.ck) };
}

/**
 * v1 compat export (NO LONGER USED by the v2 ratchet): derives by ITERATING
 * the chain — exists only for tests/old callers; the ratchet itself advances
 * the persisted chain state in place.
 */
export function deriveGroupMessageKey(chainKeyB64: string, n: number): Uint8Array {
  let ck = b64decode(chainKeyB64);
  let mk = kdfCk(ck).mk;
  for (let i = 0; i < n; i++) {
    const step = kdfCk(ck);
    mk = step.mk;
    ck = step.ck;
  }
  return mk;
}

/** Structural type guard for inbound parsed control payloads. */
export function isCtrlPayload(parsed: unknown): parsed is GroupCtrlPayload {
  if (typeof parsed !== 'object' || parsed === null) return false;
  const p = parsed as Record<string, unknown>;
  return (
    p.kind === GROUP_CTRL_KIND &&
    p.type === 'sender-key' &&
    typeof p.groupId === 'string' &&
    typeof p.key === 'string' &&
    typeof p.keyId === 'number' &&
    typeof p.epoch === 'number' &&
    typeof p.n === 'number' && Number.isInteger(p.n) && p.n >= 0
  );
}

const fail = (name: string): { error: string } => ({ error: name });

/* ── F3 (audit H1): group-roster membership helpers ───────────────────────── */

/**
 * Canonical LOCAL-roster member extraction for a chat. Mirrors the App's
 * member-list source (chat hydrates with `memberIds` — array of user ids — or
 * `members` — array of member objects); `selfId` is excluded so the result is
 * the list of OTHER members (distribution targets / requesters are always
 * other users).
 *
 * NOTE (honest limitation, documented per the remediation plan): the roster is
 * CLIENT-SIDE state — the chat's member list as hydrated by the app. It can
 * only over-DENY (a stale roster may drop a legitimate requester whose
 * membership has not hydrated yet; distribution retries on the next send /
 * chat open), never over-GRANT. The server relay ALSO enforces membership
 * server-side for 'e2ee:ctrl' delivery (src/server/websocket/ws_server.ts
 * handleE2eeCtrl gates both sender and recipient on db.getChatMembers) — the
 * two layers are independent: this client check protects key MATERIAL from
 * non-member requesters even if a frame reaches the engine, the server check
 * protects DELIVERY.
 */
export function rosterMemberIds(chat: unknown, selfId?: string | null): string[] {
  const c = chat as { memberIds?: unknown; members?: unknown } | null | undefined;
  const ids: string[] = [];
  if (Array.isArray(c?.memberIds)) {
    ids.push(...(c.memberIds as unknown[]).map((id: unknown) => String(id || '')));
  } else if (Array.isArray(c?.members)) {
    ids.push(...(c.members as unknown[]).map((m: any) => String(m?.id || m?.userId || '')));
  }
  return ids.filter((id) => id && id !== (selfId ?? ''));
}

/** True when `peerId` is a member of `chat` per the LOCAL roster (F3 guard). */
export function isRosterMember(chat: unknown, peerId: string, selfId?: string | null): boolean {
  if (typeof peerId !== 'string' || peerId.length === 0) return false;
  return rosterMemberIds(chat, selfId).includes(peerId);
}

/* ── GroupCrypto ──────────────────────────────────────────────────────────── */

export interface GroupCryptoOptions {
  /** Underlying persistence (MemoryKVStore in tests, IndexedDBKVStore in browsers). */
  store: KVStore;
  /** Multi-account isolation: wraps the store in a NamespacedKVStore when set. */
  namespace?: string;
}

export class GroupCrypto {
  private readonly kv: KVStore;
  /**
   * DIR-NEW-02 (second independent review): per-chain async mutex. encrypt/
   * decrypt are read→derive→modify→write over the SAME persisted state;
   * concurrent calls (history decrypt uses Promise.all) can interleave and
   * lose updates (duplicate n on send; stale-over-fresh on receive). Every
   * state mutation is serialized per (groupId, senderId).
   */
  private chainLocks = new Map<string, Promise<unknown>>();

  private withChainLock<T>(key: string, fn: () => Promise<T>): Promise<T> {
    const prev = this.chainLocks.get(key) || Promise.resolve();
    const next = prev.then(fn, fn);
    this.chainLocks.set(key, next.catch(() => {}));
    return next;
  }

  /**
   * BATCH-7 (DIR-2026-035 — Agent-B condition #1): CROSS-TAB serialization.
   * The in-process chainLocks serialize within one tab only; two tabs racing
   * the same (group, direction) chain produced duplicate chain positions
   * (IndexedDB last-write-wins). navigator.locks (Web Locks API) provides the
   * cross-tab mutex where available; environments without it (tests, workers)
   * fall back to the in-process lock — single-tab guidance documented.
   */
  private withCrossTabLock<T>(lockName: string, fn: () => Promise<T>): Promise<T> {
    const nav = typeof navigator !== 'undefined' ? (navigator as any) : null;
    if (!nav?.locks?.request) {
      return this.withChainLock(lockName, fn); // no Web Locks — in-process only
    }
    return nav.locks.request(`dirasha:${lockName}`, async () => this.withChainLock(lockName, fn));
  }


  constructor(options: GroupCryptoOptions) {
    this.kv = options.namespace
      ? new NamespacedKVStore(options.namespace, options.store)
      : options.store;
  }

  /* ── key paths ── */

  private gskKey(groupId: string): string {
    return `gsk:${groupId}`;
  }

  private gmiKey(groupId: string, peerId: string): string {
    return `gmi:${groupId}:${peerId}`;
  }

  /* ── own sender key ── */

  /**
   * Our sender key for a group: create {keyId: timestamp int, epoch: 1,
   * key: b64 32B, n: 0} if missing. Returns {keyId, epoch} either way.
   */
  async ensureSenderKey(groupId: string): Promise<{ keyId: number; epoch: number }> {
    const existing = await this.loadSenderKey(groupId);
    if (existing) return { keyId: existing.keyId, epoch: existing.epoch };
    const created = await this.createSenderKey(groupId);
    return { keyId: created.keyId, epoch: created.epoch };
  }

  /** Stored own sender key record, or null. */
  async getSenderKey(groupId: string): Promise<SenderKeyRecord | null> {
    return this.loadSenderKey(groupId);
  }

  /**
   * JSON ctrl payload advertising OUR current sender key. Throws E2eeError if
   * no own key exists yet — call ensureSenderKey(groupId) first. The integration
   * layer sends this to each member pairwise via engine.encryptMessage.
   */
  async distributionPayload(groupId: string): Promise<string> {
    const sk = await this.loadSenderKey(groupId);
    if (!sk) throw new E2eeError(`no own sender key for group ${groupId} — call ensureSenderKey first`);
    const payload: GroupCtrlPayload = {
      kind: GROUP_CTRL_KIND,
      type: 'sender-key',
      groupId,
      keyId: sk.keyId,
      epoch: sk.epoch,
      key: sk.chainKey,
      n: sk.n, // DIR-NEW-03: receiver's nextN := the sender's current chain position
    };
    return JSON.stringify(payload);
  }

  /**
   * Rotation: fresh random key, epoch + 1, chain counter reset to 0.
   * Returns the new {keyId, epoch}. Callers must re-distribute the new
   * distributionPayload() to every member afterwards.
   */
  async rotateSenderKey(groupId: string): Promise<{ keyId: number; epoch: number }> {
    const prev = await this.loadSenderKey(groupId);
    const created = await this.createSenderKey(groupId, prev ? prev.epoch + 1 : 1, prev ? prev.keyId : 0);
    return { keyId: created.keyId, epoch: created.epoch };
  }

  /* ── member keys (ctrl path) ── */

  /**
   * Validate + persist a control payload received from `peerId` (sent pairwise
   * through the 1:1 engine). Returns true and stores 'gmi:<groupId>:<peerId>'
   * for valid sender-key payloads; returns false for anything else (unknown
   * kind / failed validation) so the integration layer can just ignore it.
   * Never throws.
   */
  async processControl(peerId: string, parsed: unknown): Promise<boolean> {
    try {
      if (!isCtrlPayload(parsed)) return false;
      if (typeof peerId !== 'string' || peerId.length === 0) return false;
      if (parsed.groupId.length === 0) return false;
      if (!Number.isInteger(parsed.keyId) || parsed.keyId <= 0) return false;
      if (!Number.isInteger(parsed.epoch) || parsed.epoch < 1) return false;
      if (b64decode(parsed.key).length !== KEY_BYTES) return false;
      // DIR-NEW-03: MONOTONIC acceptance — a re-delivered or OLDER ctrl
      // (same keyId with n < stored nextN, or an older keyId/epoch) must NOT
      // rewind the receiver state (replay-state reset protection).
      const existingRaw = await this.kv.get(this.gmiKey(parsed.groupId, peerId));
      if (existingRaw !== null) {
        try {
          const ex = JSON.parse(existingRaw) as MemberKeyRecord;
          const incomingIsOlder =
            parsed.keyId < ex.keyId ||
            (parsed.keyId === ex.keyId && Number(parsed.n) < ex.nextN) ||
            (parsed.keyId === ex.keyId && Number(parsed.n) === ex.nextN && parsed.epoch < ex.epoch);
          if (incomingIsOlder) return true; // idempotent no-op — keep the fresher state
          if (parsed.keyId === ex.keyId && Number(parsed.n) === ex.nextN && parsed.epoch === ex.epoch) {
            return true; // exact duplicate — idempotent
          }
        } catch { /* fall through — replace on parse failure */ }
      }
      const record: MemberKeyRecord = {
        keyId: parsed.keyId,
        epoch: parsed.epoch,
        chainKey: parsed.key,
        nextN: Number(parsed.n),
        skipped: [],
        receivedAt: Date.now(),
      };
      await this.kv.set(this.gmiKey(parsed.groupId, peerId), JSON.stringify(record));
      return true;
    } catch {
      return false;
    }
  }

  /** True when we hold NO sender key for `peerId` in this group (needs ctrl). */
  async needsDistribution(groupId: string, peerId: string): Promise<boolean> {
    return (await this.kv.get(this.gmiKey(groupId, peerId))) === null;
  }

  /* ── message path ── */

  /**
   * Encrypt a group text message with our sender key: derive mk_n from the
   * current chain index, seal, then clone-and-save the incremented counter.
   * Returns the 'DIRG1:...' content string.
   */
  /**
   * Encrypt a group text message with our sender-key CHAIN (v2 ratchet):
   * message key = HMAC(ck, 0x01) used ONCE, chain ratchets forward
   * (HMAC(ck, 0x02)), consumed mk cached bounded for SELF re-decrypt.
   * AAD binds sender identity + membership epoch (v2).
   */
  async encryptGroupMessage(groupId: string, text: string, senderId: string, mv: number): Promise<string> {
    if (typeof senderId !== 'string' || !senderId) throw new E2eeError('senderId required for v2 AAD binding');
    if (!Number.isFinite(mv) || mv < 1) throw new E2eeError('membershipVersion required for v2 AAD binding');
    return this.withCrossTabLock('send:' + groupId, async () => {
    let sk = await this.loadSenderKey(groupId);
    if (!sk) sk = await this.createSenderKey(groupId);
    const n = sk.n; // guarded by withChainLock — no concurrent index reuse
    const { mk, nextChainKeyB64 } = groupNextMessageKey(sk.chainKey);
    const iv = randomBytes(NONCE_BYTES);
    const aad = utf8Encode(groupAad(GROUP_WIRE_VERSION, groupId, sk.keyId, n, senderId, mv));
    const ct = aeadSeal(mk, iv, utf8Encode(text), aad);
    // Cache the consumed mk (bounded) for SELF re-decrypt, then RATCHET FORWARD.
    const selfSkipped = (sk.selfSkipped || []).slice(-GROUP_SELF_SKIP_MAX);
    selfSkipped.push({ n, mk: b64encode(mk) });
    const skNext: SenderKeyRecord = {
      keyId: sk.keyId,
      epoch: sk.epoch,
      chainKey: nextChainKeyB64,
      n: n + 1,
      selfSkipped: selfSkipped.slice(-GROUP_SELF_SKIP_MAX),
    };
    await this.saveSenderKey(groupId, skNext);
    const envelope: GroupEnvelope = {
      v: GROUP_WIRE_VERSION,
      skId: sk.keyId,
      n,
      iv: b64encode(iv),
      ct: b64encode(ct),
      mv,
      senderId,
    };
    return GROUP_WIRE_PREFIX + b64encode(utf8Encode(JSON.stringify(envelope)));
    });
  }

  /**
   * Decrypt a 'DIRG1:...' v2 group message (ratcheted Sender Keys):
   *  - epoch fail-closed (skId mismatch → DecryptFailedError),
   *  - n >= nextN → advance the receiver chain with bounded skipped-key
   *    caching (out-of-order delivery within GROUP_MAX_SKIP),
   *  - n < nextN → consume the cached skipped key ONE-TIME (a second
   *    delivery of the same ciphertext fails = replay protection),
   *  - gaps beyond GROUP_MAX_SKIP fail closed,
   *  - AAD binds sender identity + membership epoch (tamper fails AEAD).
   * SELF path consumes from the bounded selfSkipped cache. Never throws.
   */
  async decryptGroupMessage(groupId: string, senderId: string, content: string): Promise<GroupDecryptResult> {
    // Parse + structural validation (DecryptFailedError on any malformation).
    let envelope: GroupEnvelope;
    try {
      if (typeof content !== 'string' || !content.startsWith(GROUP_WIRE_PREFIX)) {
        return fail('DecryptFailedError');
      }
      const parsed = JSON.parse(utf8Decode(b64decode(content.slice(GROUP_WIRE_PREFIX.length))));
      if (
        typeof parsed !== 'object' ||
        parsed === null ||
        parsed.v !== GROUP_WIRE_VERSION ||
        typeof parsed.skId !== 'number' ||
        !Number.isInteger(parsed.skId) ||
        typeof parsed.n !== 'number' ||
        !Number.isInteger(parsed.n) || parsed.n < 0 ||
        typeof parsed.iv !== 'string' ||
        typeof parsed.ct !== 'string' || parsed.ct.length === 0 ||
        typeof parsed.mv !== 'number' || !Number.isInteger(parsed.mv) || parsed.mv < 1 ||
        typeof parsed.senderId !== 'string' || parsed.senderId.length === 0
      ) {
        return fail('DecryptFailedError');
      }
      if (b64decode(parsed.iv).length !== NONCE_BYTES) return fail('DecryptFailedError');
      envelope = parsed as GroupEnvelope;
    } catch {
      return fail('DecryptFailedError');
    }

    // Key material: member chain for the sender, or our own when SELF.
    // Key material + epoch + ratchet: ALL inside the per-chain lock
    // (DIR-NEW-02: loading OUTSIDE the lock let concurrent calls stomp each
    // other with stale snapshots — the exact lost-update the reviewer flagged).
    return this.withChainLock('recv:' + groupId + ':' + senderId, async () => {
    let keyRecord: MemberKeyRecord | SenderKeyRecord | null;
    if (senderId === SELF) {
      keyRecord = await this.loadSenderKey(groupId);
    } else {
      keyRecord = await this.loadMemberKey(groupId, senderId);
    }
    if (!keyRecord) return fail('DecryptFailedError');

    // Epoch check: old-epoch envelopes (skId replaced on rotation) fail closed.
    if (keyRecord.keyId !== envelope.skId) return fail('DecryptFailedError');
    // v2 anti-spoof: the caller-declared sender must match the wire-bound
    // identity; SELF path uses the wire-bound identity for the AAD.
    if (senderId !== SELF && senderId !== envelope.senderId) return fail('DecryptFailedError');

    try {
      if (senderId === SELF) {
        // SELF: consume from the bounded selfSkipped cache (one-time).
        const sk = keyRecord as SenderKeyRecord;
        const idx = (sk.selfSkipped || []).findIndex((e) => e.n === envelope.n);
        if (idx < 0) return fail('DecryptFailedError'); // consumed/beyond window
        const mk = b64decode(sk.selfSkipped[idx].mk);
        const aad = utf8Encode(groupAad(GROUP_WIRE_VERSION, groupId, envelope.skId, envelope.n, envelope.senderId, envelope.mv));
        const pt = aeadOpen(mk, b64decode(envelope.iv), b64decode(envelope.ct), aad);
        sk.selfSkipped.splice(idx, 1);
        await this.saveSenderKey(groupId, sk);
        return { plaintext: utf8Decode(pt) };
      }
      const rec = keyRecord as MemberKeyRecord;
      rec.skipped = rec.skipped || [];
      if (envelope.n >= rec.nextN) {
        // Advance the receiver chain: cache skipped keys for the gap, consume n.
        const gap = envelope.n - rec.nextN;
        if (gap > GROUP_MAX_SKIP) return fail('DecryptFailedError');
        while (rec.nextN < envelope.n) {
          const step = kdfCk(b64decode(rec.chainKey));
          rec.skipped.push({ n: rec.nextN, mk: b64encode(step.mk) });
          rec.chainKey = b64encode(step.ck);
          rec.nextN++;
        }
        const stepN = kdfCk(b64decode(rec.chainKey));
        const mk = stepN.mk;
        rec.chainKey = b64encode(stepN.ck);
        rec.nextN = envelope.n + 1;
        rec.receivedAt = Date.now();
        const aad = utf8Encode(groupAad(GROUP_WIRE_VERSION, groupId, envelope.skId, envelope.n, senderId, envelope.mv));
        const pt = aeadOpen(mk, b64decode(envelope.iv), b64decode(envelope.ct), aad);
        rec.skipped = rec.skipped.slice(-GROUP_MAX_SKIP);
        await this.kv.set(this.gmiKey(groupId, senderId), JSON.stringify(rec));
        return { plaintext: utf8Decode(pt) };
      }
      // n < nextN: skipped lookup — one-time consumption (replay protection).
      const idx = rec.skipped.findIndex((e) => e.n === envelope.n);
      if (idx < 0) return fail('DecryptFailedError'); // replay / outside window
      const mk = b64decode(rec.skipped[idx].mk);
      const aad = utf8Encode(groupAad(GROUP_WIRE_VERSION, groupId, envelope.skId, envelope.n, senderId, envelope.mv));
      const pt = aeadOpen(mk, b64decode(envelope.iv), b64decode(envelope.ct), aad);
      rec.skipped.splice(idx, 1);
      await this.kv.set(this.gmiKey(groupId, senderId), JSON.stringify(rec));
      return { plaintext: utf8Decode(pt) };
    } catch {
      return fail('TamperedError');
    }
    });
  }

  /* ── membership epochs (external-audit E2EE-01/E2EE-02) ── */

  /**
   * Locally-tracked membership_version for a group — the last value seen from
   * the server (chat hydrate or membership_changed event). Persisted under
   * 'gmv:<groupId>' so an offline-reconnecting client can detect "server mv >
   * my last-seen mv" and rotate before its next send.
   */
  async getMembershipVersion(groupId: string): Promise<number | null> {
    const raw = await this.kv.get(`gmv:${groupId}`);
    if (raw === null) return null;
    const n = Number(JSON.parse(raw));
    return Number.isFinite(n) ? n : null;
  }

  async setMembershipVersion(groupId: string, mv: number): Promise<void> {
    if (!Number.isFinite(mv) || mv < 1) return;
    await this.kv.set(`gmv:${groupId}`, JSON.stringify(mv));
  }

  /* ── lifecycle ── */

  /**
   * Forget everything about a group: our own sender key plus every received
   * member key ('gsk:<groupId>' and all 'gmi:<groupId>:*' entries).
   */
  async deleteGroup(groupId: string): Promise<void> {
    const keys = await this.kv.keys();
    const prefix = `gmi:${groupId}:`;
    for (const k of keys) {
      if (k.startsWith(prefix)) await this.kv.del(k);
    }
    await this.kv.del(this.gskKey(groupId));
  }

  /* ── internal persistence ── */

  private async loadSenderKey(groupId: string): Promise<SenderKeyRecord | null> {
    const raw = await this.kv.get(this.gskKey(groupId));
    if (raw === null) return null;
    try {
      const parsed = JSON.parse(raw) as SenderKeyRecord;
      if (typeof parsed?.keyId !== 'number' || typeof parsed?.epoch !== 'number' || typeof parsed?.chainKey !== 'string') {
        return null;
      }
      // v1 static-key records (no chainKey) fail this shape check → replaced.
      return { ...parsed, selfSkipped: Array.isArray(parsed.selfSkipped) ? parsed.selfSkipped : [] };
    } catch {
      return null;
    }
  }

  private async loadMemberKey(groupId: string, peerId: string): Promise<MemberKeyRecord | null> {
    const raw = await this.kv.get(this.gmiKey(groupId, peerId));
    if (raw === null) return null;
    try {
      const parsed = JSON.parse(raw) as MemberKeyRecord;
      if (typeof parsed?.keyId !== 'number' || typeof parsed?.epoch !== 'number' || typeof parsed?.chainKey !== 'string') {
        return null;
      }
      return { ...parsed, nextN: Number(parsed.nextN) || 0, skipped: Array.isArray(parsed.skipped) ? parsed.skipped : [] };
    } catch {
      return null;
    }
  }

  /** Create and persist a fresh sender key (timestamp keyId, no collisions). */
  private async createSenderKey(groupId: string, epoch = 1, prevKeyId = 0): Promise<SenderKeyRecord> {
    const record: SenderKeyRecord = {
      keyId: Math.max(Date.now(), prevKeyId + 1),
      epoch,
      chainKey: b64encode(randomBytes(KEY_BYTES)),
      n: 0,
      selfSkipped: [],
    };
    await this.kv.set(this.gskKey(groupId), JSON.stringify(record));
    return { ...record };
  }

  private async saveSenderKey(groupId: string, record: SenderKeyRecord): Promise<void> {
    await this.kv.set(this.gskKey(groupId), JSON.stringify(record));
  }
}
