/**
 * Dirasha E2EE — encrypted media module tests (Agent M).
 *
 * Covers: attachment round-trip (small + 2MB random), AEAD wrong-key →
 * TamperedError, sha256 mismatch → TamperedError, buildEncryptedPayload /
 * parseEncryptedPayload round-trip incl. back-compat with plain text,
 * mime/name preservation, empty-bytes edge.
 */
import { describe, it, expect } from 'vitest';

import { sha256 } from '@noble/hashes/sha256';

import {
  encryptAttachment,
  decryptAttachment,
  buildEncryptedPayload,
  parseEncryptedPayload,
  TamperedError,
  MEDIA_INFO,
  MEDIA_MSG_KIND,
} from '../src/lib/e2ee/media.ts';
import { b64encode, utf8Encode } from '../src/lib/e2ee/crypto.ts';

/** Deterministic pseudo-random filler (fast, reproducible across runs). */
function pseudoRandomBytes(n: number, seed = 0x9e3779b9): Uint8Array {
  const out = new Uint8Array(n);
  let s = seed >>> 0;
  for (let i = 0; i < n; i++) {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    out[i] = s >>> 24;
  }
  return out;
}

describe('encryptAttachment / decryptAttachment round-trip', () => {
  it('round-trips a small text file with mime and name preserved', () => {
    const bytes = utf8Encode('مرحبا Dirasha — attachment body ✓');
    const { blob, payload } = encryptAttachment(bytes, 'text/plain', 'hello.txt');

    // Blob differs from plaintext and carries the 16-byte Poly1305 tag.
    expect(blob.length).toBe(bytes.length + 16);
    expect(Array.from(blob.slice(0, 4))).not.toEqual(Array.from(bytes.slice(0, 4)));

    const res = decryptAttachment(payload, blob);
    expect(Array.from(res.bytes)).toEqual(Array.from(bytes));
    expect(res.mime).toBe('text/plain');
    expect(res.name).toBe('hello.txt');
  });

  it('round-trips 2MB of random bytes', () => {
    const bytes = pseudoRandomBytes(2 * 1024 * 1024);
    const { blob, payload } = encryptAttachment(bytes, 'application/octet-stream', 'big.bin');

    expect(payload.size).toBe(2 * 1024 * 1024);
    const res = decryptAttachment(payload, blob);
    expect(res.bytes.length).toBe(2 * 1024 * 1024);
    expect(Array.from(res.bytes)).toEqual(Array.from(bytes));
  });

  it('round-trips empty bytes (0-byte attachment)', () => {
    const { blob, payload } = encryptAttachment(new Uint8Array(0), 'application/pdf', 'empty.pdf');

    // Tag-only ciphertext; zero plaintext still has a valid sha256.
    expect(blob.length).toBe(16);
    expect(payload.size).toBe(0);

    const res = decryptAttachment(payload, blob);
    expect(res.bytes.length).toBe(0);
    expect(res.mime).toBe('application/pdf');
    expect(res.name).toBe('empty.pdf');
  });

  it('produces a well-formed payload with correct lengths and digest', () => {
    const bytes = pseudoRandomBytes(1024, 42);
    const { payload } = encryptAttachment(bytes, 'image/jpeg', 'photo.jpg');

    expect(typeof payload.attId).toBe('string');
    expect(payload.attId.length).toBeGreaterThan(0);
    expect(b64encode(sha256(bytes))).toBe(payload.sha256);
    // key = 32B → 44 std-b64 chars (no padding chars beyond '='), iv = 12B → 16.
    expect(b64decodeLen(payload.key)).toBe(32);
    expect(b64decodeLen(payload.iv)).toBe(12);
    expect(b64decodeLen(payload.sha256)).toBe(32);
    expect(payload.mime).toBe('image/jpeg');
    expect(payload.name).toBe('photo.jpg');
  });

  it('uses a fresh key, iv and attId per attachment', () => {
    const bytes = utf8Encode('same input');
    const a = encryptAttachment(bytes, 'text/plain', 'a.txt');
    const b = encryptAttachment(bytes, 'text/plain', 'a.txt');
    expect(a.payload.key).not.toBe(b.payload.key);
    expect(a.payload.iv).not.toBe(b.payload.iv);
    expect(a.payload.attId).not.toBe(b.payload.attId);
    expect(Array.from(a.blob)).not.toEqual(Array.from(b.blob));
  });
});

describe('decryptAttachment tamper / corruption handling', () => {
  const bytes = utf8Encode('attack at dawn');

  it('throws TamperedError when the payload key is wrong', () => {
    const { blob, payload } = encryptAttachment(bytes, 'text/plain', 'x.txt');
    // Attacker swaps in a different media key (e.g. from another attachment).
    const other = encryptAttachment(utf8Encode('other'), 'text/plain', 'y.txt');
    expect(() => decryptAttachment({ ...payload, key: other.payload.key }, blob)).toThrow(TamperedError);
  });

  it('throws TamperedError on sha256 mismatch', () => {
    const { blob, payload } = encryptAttachment(bytes, 'text/plain', 'x.txt');
    // AEAD still opens (ciphertext untouched) but the declared digest is a
    // digest of different plaintext → integrity check must fail.
    const forged = { ...payload, sha256: b64encode(sha256(utf8Encode('attack at dusk'))) };
    expect(() => decryptAttachment(forged, blob)).toThrow(TamperedError);
  });

  it('throws TamperedError when the ciphertext is corrupted', () => {
    const { blob, payload } = encryptAttachment(bytes, 'text/plain', 'x.txt');
    const flipped = new Uint8Array(blob);
    flipped[0] ^= 0x01;
    expect(() => decryptAttachment(payload, flipped)).toThrow(TamperedError);
  });

  it('throws TamperedError when the tag is truncated', () => {
    const { blob, payload } = encryptAttachment(bytes, 'text/plain', 'x.txt');
    expect(() => decryptAttachment(payload, blob.slice(0, blob.length - 4))).toThrow(TamperedError);
  });

  it('throws TamperedError when attId (AAD) is altered', () => {
    const { blob, payload } = encryptAttachment(bytes, 'text/plain', 'x.txt');
    expect(() => decryptAttachment({ ...payload, attId: '00000000-0000-4000-8000-000000000000' }, blob))
      .toThrow(TamperedError);
  });
});

describe('buildEncryptedPayload / parseEncryptedPayload', () => {
  it('round-trips text + files', () => {
    const { payload } = encryptAttachment(utf8Encode('doc'), 'application/pdf', 'doc.pdf');
    const { payload: p2 } = encryptAttachment(new Uint8Array([1, 2, 3]), 'image/png', 'img.png');

    const wire = buildEncryptedPayload('مرحبا', [payload, p2]);
    // Container is valid JSON with our kind discriminator.
    expect(JSON.parse(wire).kind).toBe(MEDIA_MSG_KIND);

    const parsed = parseEncryptedPayload(wire);
    expect(parsed.text).toBe('مرحبا');
    expect(parsed.files).toHaveLength(2);
    expect(parsed.files[0]).toEqual(payload);
    expect(parsed.files[1]).toEqual(p2);
  });

  it('round-trips empty text (attachment-only message)', () => {
    const { payload } = encryptAttachment(utf8Encode('only file'), 'video/mp4', 'clip.mp4');
    const wire = buildEncryptedPayload('', [payload]);
    const parsed = parseEncryptedPayload(wire);
    expect(parsed.text).toBe('');
    expect(parsed.files).toEqual([payload]);
  });

  it('round-trips text with no files', () => {
    const parsed = parseEncryptedPayload(buildEncryptedPayload('just text', []));
    expect(parsed.text).toBe('just text');
    expect(parsed.files).toEqual([]);
  });

  it('treats plain text as pure text (back-compat)', () => {
    expect(parseEncryptedPayload('hello world')).toEqual({ text: 'hello world', files: [] });
    expect(parseEncryptedPayload('')).toEqual({ text: '', files: [] });
    expect(parseEncryptedPayload('not json { at all')).toEqual({ text: 'not json { at all', files: [] });
  });

  it('treats foreign JSON (wrong/missing kind) as pure text', () => {
    expect(parseEncryptedPayload('{"kind":"other","text":"x"}')).toEqual({
      text: '{"kind":"other","text":"x"}',
      files: [],
    });
    expect(parseEncryptedPayload('{"text":"no kind"}')).toEqual({ text: '{"text":"no kind"}', files: [] });
    // Non-object JSON (numbers, strings-as-JSON) also falls back.
    expect(parseEncryptedPayload('12345')).toEqual({ text: '12345', files: [] });
  });

  it('throws TamperedError when the container claims our kind but is malformed', () => {
    expect(() => parseEncryptedPayload(JSON.stringify({ kind: MEDIA_MSG_KIND, files: [] }))).toThrow(TamperedError);
    expect(() => parseEncryptedPayload(JSON.stringify({ kind: MEDIA_MSG_KIND, text: 'x', files: 'no' }))).toThrow(
      TamperedError,
    );
    expect(() =>
      parseEncryptedPayload(JSON.stringify({ kind: MEDIA_MSG_KIND, text: 'x', files: [{ attId: 'a' }] })),
    ).toThrow(TamperedError);
    expect(() =>
      parseEncryptedPayload(
        JSON.stringify({ kind: MEDIA_MSG_KIND, text: 'x', files: [{ ...validPayload(), size: -1 }] }),
      ),
    ).toThrow(TamperedError);
  });
});

/** A hand-built valid payload shape for negative tests. */
function validPayload() {
  const { payload } = encryptAttachment(utf8Encode('seed'), 'text/plain', 'seed.txt');
  return payload;
}

/** b64 string → decoded byte length (test helper). */
function b64decodeLen(s: string): number {
  return Buffer.from(s, 'base64').length;
}

it('MEDIA_INFO matches the spec constant', () => {
  expect(MEDIA_INFO).toBe('DirashaMedia-v1');
});
