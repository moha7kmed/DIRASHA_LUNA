/**
 * P1-C (external-audit E2EE-07) — group Sender-Key ratchet v2 acceptance tests.
 * Run: npx vitest run tests/group-ratchet.test.ts
 */
import { describe, it, expect } from 'vitest';
import { kdfCk } from '../src/lib/e2ee/crypto.ts';
import { GroupCrypto, SELF, GROUP_MAX_SKIP, groupAad, GROUP_WIRE_VERSION } from '../src/lib/e2ee/group.ts';
import { b64decode, b64encode, aeadOpen, aeadSeal, utf8Decode, utf8Encode, randomBytes } from '../src/lib/e2ee/crypto.ts';
import { MemoryKVStore } from '../src/lib/e2ee/store.ts';

function make(name: string) {
  const store = new MemoryKVStore();
  return { id: name, groups: new GroupCrypto({ store, namespace: name }), store };
}
async function distribute(sender: any, receivers: any[], groupId = 'g1'): Promise<void> {
  await sender.groups.ensureSenderKey(groupId);
  const payload = JSON.parse(await sender.groups.distributionPayload(groupId));
  for (const r of receivers) expect(await r.groups.processControl(sender.id, payload)).toBe(true);
}
function parseEnv(content: string): any {
  return JSON.parse(utf8Decode(b64decode(content.slice('DIRG1:'.length))));
}
function forgeEnvelope(mutate: (e: any) => void, base: any): string {
  const e: any = JSON.parse(JSON.stringify(base));
  mutate(e);
  return 'DIRG1:' + b64encode(utf8Encode(JSON.stringify(e)));
}
const errOf = (r: any): string => ('error' in r ? r.error : '');

describe('P1-C ratchet v2 (E2EE-07)', () => {
  it('AAD v2 six fields', () => {
    expect(groupAad(2, 'g1', 42, 7, 'alice', 3)).toBe('2|g1|42|7|alice|3');
    expect(GROUP_WIRE_VERSION).toBe(2);
  });

  it('positive path: consecutive messages decrypt', async () => {
    const A = make('alice'); const B = make('bob');
    await distribute(A, [B]);
    for (let i = 0; i < 5; i++) {
      const ct = await A.groups.encryptGroupMessage('g1', 'msg ' + i, 'alice', 4);
      await expect(B.groups.decryptGroupMessage('g1', 'alice', ct)).resolves.toMatchObject({ plaintext: 'msg ' + i });
    }
    expect((await A.groups.getSenderKey('g1'))!.n).toBe(5);
  });

  it('ACCEPTANCE 1 — chain-key compromise does not reveal past messages', async () => {
    const A = make('alice'); const B = make('bob');
    await distribute(A, [B]);
    const oldCt = await A.groups.encryptGroupMessage('g1', 'OLD-LEAKED-SECRET', 'alice', 1);
    await A.groups.encryptGroupMessage('g1', 'NEW-SECRET', 'alice', 1);
    const sk = await A.groups.getSenderKey('g1');
    const guessMk = kdfCk(b64decode(sk!.chainKey)).mk;
    const env = parseEnv(oldCt);
    const aad = utf8Encode(groupAad(2, 'g1', env.skId, env.n, 'alice', 1));
    let leaked = false;
    try { aeadOpen(guessMk, b64decode(env.iv), b64decode(env.ct), aad); leaked = true; } catch { /* one-way */ }
    expect(leaked).toBe(false);
    await expect(B.groups.decryptGroupMessage('g1', 'alice', oldCt)).resolves.toMatchObject({ plaintext: 'OLD-LEAKED-SECRET' });
  });

  it('ACCEPTANCE 2 — replay rejected', async () => {
    const A = make('alice'); const B = make('bob');
    await distribute(A, [B]);
    const ct = await A.groups.encryptGroupMessage('g1', 'once', 'alice', 1);
    await expect(B.groups.decryptGroupMessage('g1', 'alice', ct)).resolves.toMatchObject({ plaintext: 'once' });
    expect(errOf(await B.groups.decryptGroupMessage('g1', 'alice', ct))).toBe('DecryptFailedError');
  });

  it('ACCEPTANCE 3 — out-of-order in window; beyond MAX_SKIP fails closed', async () => {
    const A = make('alice'); const B = make('bob');
    await distribute(A, [B]);
    const cts: string[] = [];
    for (let i = 0; i < 3; i++) cts.push(await A.groups.encryptGroupMessage('g1', 'm' + i, 'alice', 1));
    await expect(B.groups.decryptGroupMessage('g1', 'alice', cts[2])).resolves.toMatchObject({ plaintext: 'm2' });
    await expect(B.groups.decryptGroupMessage('g1', 'alice', cts[0])).resolves.toMatchObject({ plaintext: 'm0' });
    await expect(B.groups.decryptGroupMessage('g1', 'alice', cts[1])).resolves.toMatchObject({ plaintext: 'm1' });
    const sk = await A.groups.getSenderKey('g1');
    const step = kdfCk(b64decode(sk!.chainKey));
    // Receiver nextN = 3 (three delivered); gap must EXCEED GROUP_MAX_SKIP.
    const farCt = forgeEnvelope((e) => Object.assign(e, {
      v: 2, skId: sk!.keyId, n: 3 + GROUP_MAX_SKIP + 1,
      iv: b64encode(randomBytes(12)),
      ct: b64encode(aeadSeal(step.mk, randomBytes(12), utf8Encode('forged'), utf8Encode(groupAad(2, 'g1', sk!.keyId, GROUP_MAX_SKIP + 2, 'alice', 1)))),
      mv: 1, senderId: 'alice',
    }), { v: 2, skId: 1, n: 0, iv: '', ct: '', mv: 1, senderId: 'alice' });
    expect(errOf(await B.groups.decryptGroupMessage('g1', 'alice', farCt))).toBe('DecryptFailedError');
  });

  it('ACCEPTANCE 4 — old epoch fails closed (skId mismatch)', async () => {
    const A = make('alice'); const B = make('bob');
    await distribute(A, [B]);
    const oldCt = await A.groups.encryptGroupMessage('g1', 'pre-rotation', 'alice', 1);
    await A.groups.rotateSenderKey('g1');
    // Real flow: re-distribution happens BEFORE the next send (App awaits it).
    await B.groups.processControl('alice', JSON.parse(await A.groups.distributionPayload('g1')));
    const postCt = await A.groups.encryptGroupMessage('g1', 'post-rotation', 'alice', 2);
    expect(await B.groups.decryptGroupMessage('g1', 'alice', postCt)).toEqual({ plaintext: 'post-rotation' });
    expect(errOf(await B.groups.decryptGroupMessage('g1', 'alice', oldCt))).toBe('DecryptFailedError');
  });

  it('ACCEPTANCE 5 — identity/AAD tamper + wrong-sender anti-spoof', async () => {
    const A = make('alice'); const B = make('bob');
    await distribute(A, [B]);
    const ct = await A.groups.encryptGroupMessage('g1', 'payload', 'alice', 1);
    const ct2 = await A.groups.encryptGroupMessage('g1', 'payload-2', 'alice', 1); // undelivered (n=1)
    const env = parseEnv(ct2); // forge tests use the UNDELIVERED envelope
    expect(errOf(await B.groups.decryptGroupMessage('g1', 'mallory', ct))).toBe('DecryptFailedError');
    expect(errOf(await B.groups.decryptGroupMessage('g1', 'alice', forgeEnvelope((e) => { e.mv = 99; }, env)))).toBe('TamperedError');
    // Forged identity hits the wire-bound anti-spoof check BEFORE AEAD (cheaper,
    // fail-closed): DecryptFailedError. mv-tamper hits the AAD mismatch: TamperedError.
    expect(errOf(await B.groups.decryptGroupMessage('g1', 'alice', forgeEnvelope((e) => { e.senderId = 'mallory'; }, env)))).toBe('DecryptFailedError');
  });

  it('ACCEPTANCE 6 — SELF re-decrypt works; own replay rejected', async () => {
    const A = make('alice');
    const ct = await A.groups.encryptGroupMessage('g1', 'note to self', 'alice', 1);
    await expect(A.groups.decryptGroupMessage('g1', SELF, ct)).resolves.toMatchObject({ plaintext: 'note to self' });
    expect(errOf(await A.groups.decryptGroupMessage('g1', SELF, ct))).toBe('DecryptFailedError');
  });
});

describe('DIR-NEW-02/03 — concurrency + re-distribution (second review)', () => {
  it('ACCEPTANCE — 10 concurrent encrypts: every n unique + monotonic (no duplicate sequence)', async () => {
    const A = make('alice'); const B = make('bob');
    await distribute(A, [B]);
    const results = await Promise.all(
      Array.from({ length: 10 }, (_, i) => A.groups.encryptGroupMessage('g1', 'c' + i, 'alice', 1)),
    );
    const ns = results.map((ct) => parseEnv(ct).n);
    expect(new Set(ns).size).toBe(10);
    expect([...ns].sort((a, b) => a - b).join(',')).toBe('0,1,2,3,4,5,6,7,8,9');
    // Every message still decrypts (state intact after the parallel burst).
    for (let i = 0; i < 10; i++) {
      const r = await B.groups.decryptGroupMessage('g1', 'alice', results[i]);
      expect('plaintext' in r ? r.plaintext : '').toBe('c' + i);
    }
  });

  it('ACCEPTANCE — parallel out-of-order decrypt (Promise.all) leaves no replay window', async () => {
    const A = make('alice'); const B = make('bob');
    await distribute(A, [B]);
    const cts: string[] = [];
    for (let i = 0; i < 8; i++) cts.push(await A.groups.encryptGroupMessage('g1', 'p' + i, 'alice', 1));
    // Deliver the whole batch in PARALLEL in shuffled order, twice for one of them.
    const shuffled = [cts[5], cts[3], cts[7], cts[1], cts[6], cts[0], cts[4], cts[2]];
    const out = await Promise.all(shuffled.map((ct) => B.groups.decryptGroupMessage('g1', 'alice', ct)));
    expect(out.filter((r) => 'plaintext' in r).length).toBe(8);
    // Replay after the parallel burst → rejected (state was not rolled back).
    expect(errOf(await B.groups.decryptGroupMessage('g1', 'alice', cts[0]))).toBe('DecryptFailedError');
  });

  it('DIR-NEW-03 — re-distribution AFTER progress carries the chain position', async () => {
    const A = make('alice'); const B = make('bob');
    await distribute(A, [B]);
    for (let i = 0; i < 5; i++) await A.groups.encryptGroupMessage('g1', 'm' + i, 'alice', 1);
    // Recovery path: re-distribute the CURRENT chain state (clearDistFlags →
    // distributionPayload) — the payload now carries n=5.
    const payload = JSON.parse(await A.groups.distributionPayload('g1'));
    expect(payload.n).toBe(5);
    await B.groups.processControl('alice', payload);
    // The very NEXT message decrypts on the receiver (nextN was set to 5, not 0).
    const next = await A.groups.encryptGroupMessage('g1', 'after-redist', 'alice', 1);
    expect(parseEnv(next).n).toBe(5);
    await expect(B.groups.decryptGroupMessage('g1', 'alice', next)).resolves.toMatchObject({ plaintext: 'after-redist' });
  });

  it('DIR-NEW-03 — older/duplicate ctrl does NOT rewind receiver state (monotonic)', async () => {
    const A = make('alice'); const B = make('bob');
    await distribute(A, [B]);
    const p0 = JSON.parse(await A.groups.distributionPayload('g1')); // n=0
    await A.groups.encryptGroupMessage('g1', 'x', 'alice', 1); // chain at n=1
    const p1 = JSON.parse(await A.groups.distributionPayload('g1')); // n=1
    await B.groups.processControl('alice', p1); // receiver nextN=1
    // Re-deliver the OLDER ctrl (n=0) → must be an idempotent no-op, NOT a reset.
    expect(await B.groups.processControl('alice', p0)).toBe(true);
    const raw = await B.store.get('bob:gmi:g1:alice'); // NamespacedKVStore prefixes with the account ns
    expect(JSON.parse(raw!).nextN).toBe(1);
  });
});
