/**
 * BATCH-5 regression tests. Static source asserts:
 *   b5-1  role='banned' removed from validRoles (DIR-2026-007).
 *   b5-2  Vault reads audited (DIR-2026-021).
 *   b5-3  Drive proxy MIME pinning + forced download (DIR-2026-022).
 *   b5-4  check-username throttled (DIR-2026-027); 2fa-disable + recover/reset throttled.
 *   b5-5  Push endpoints restricted to real Web-Push services (DIR-2026-033).
 *   b5-6  window.open carries noopener (DIR-2026-040).
 *   b5-7  Redis getKeys uses SCAN, not KEYS (DIR-2026-042).
 *   b5-8  Dedup claim is atomic SET-NX (DIR-AB-08).
 *   b5-9  Status comments capped (DIR-AB-06); admin log strings sanitized (052).
 */
import { describe, it, expect } from 'vitest';
import { readFileSync } from 'fs';
import path from 'path';

const repo = path.resolve(__dirname, '..');
const read = (p: string) => readFileSync(path.join(repo, p), 'utf8');

describe('BATCH-5 remediation', () => {
  it('b5-1 banned is not a role anymore', () => {
    const srv = read('server.ts');
    expect(srv).not.toMatch(/'user', 'moderator', 'admin', 'developer', 'banned'/);
  });
  it('b5-2 vault reads leave audit records', () => {
    const srv = read('server.ts');
    expect((srv.match(/VAULT_READ/g) || []).length).toBeGreaterThanOrEqual(2);
  });
  it('b5-3 proxy MIME decision delegated to the exact-allowlist guard (B5-F1)', () => {
    const st = read('src/server/routes/storage.ts');
    expect(st).toMatch(/decideProxyHeaders\(upstreamCt\)/);
    const guard = read('src/server/guards/proxyHeaders.ts');
    expect(guard).toMatch(/INLINE_MIME/);
    // Wildcard families must NOT exist — image/svg+xml must never be inline.
    expect(guard).not.toMatch(/mediaLike|startsWith\('image\/'\)/);
    expect(guard).toMatch(/'image\/png'/);
    // The INLINE_MIME list itself must not contain svg (comment mentions excluded).
    const listBlock = guard.slice(guard.indexOf('const INLINE_MIME'), guard.indexOf(']);'));
    expect(listBlock).not.toMatch(/svg/i);
  });
  it('b5-4 enumeration/password-oracle routes throttled', () => {
    const srv = read('server.ts');
    expect(srv).toMatch(/username-check:/);
    const auth = read('src/server/routes/authClassic.ts');
    // BATCH-6 (F-6): the throttle path writes NO audit row (flood vector);
    // real password failures still audit (2fa_disable_failed).
    expect(auth).not.toMatch(/2fa_disable_throttled/);
    expect(auth).toMatch(/2fa_disable_failed/);
    // BATCH-6 (F-5/F-14): the old regex was VACUOUS (matched the pre-existing
    // recover/request limiter, passed even on revert). Asserts the REAL hunk:
    // recover/reset uses its OWN dedicated budget key.
    expect(auth).toMatch(/checkLimit\('auth:recover:reset:ip', clientIp\(req\)\)/);
    expect(auth).not.toMatch(/checkLimit\('auth:recover:ip', clientIp\(req\)\)/);
  });
  it('b5-5 push endpoint decision delegated to the pure guard (BATCH-6 F-3/F-13)', () => {
    const srv = read('server.ts');
    expect(srv).toMatch(/decidePushEndpointAllowed\(subscription\.endpoint\)/);
    const guard = read('src/server/guards/pushEndpoint.ts');
    expect(guard).toMatch(/push\.services\.mozilla\.com/);
    expect(guard).toMatch(/notify\.windows\.com/);
    expect(guard).not.toMatch(/push\.mozilla\.org|autopush\.mozilla\.org|service\.push\.microsoft\.com/);
  });
  it('b5-6 window.open carries noopener', () => {
    const cw = read('src/components/ChatWindow.tsx');
    expect(cw).toMatch(/window\.open\(att\.url, '_blank', 'noopener,noreferrer'\)/);
  });
  it('b5-7 redis SCAN replaces KEYS', () => {
    const rc = read('src/server/websocket/redis_client.ts');
    expect(rc).toMatch(/redisPub\.scan\(cursor/);
    expect(rc).not.toMatch(/redisPub\.keys\(pattern\)/);
  });
  it('b5-8 dedup claim is atomic', () => {
    const dm = read('src/server/websocket/dedup_manager.ts');
    expect(dm).toMatch(/setTempIfAbsent/);
    expect(dm).not.toMatch(/getTemp\(key\)/);
  });
  it('b5-9 comment cap + log sanitization', () => {
    const st = read('src/server/routes/status.ts');
    // B5-F2: validation delegated to the guard; the INSERT binds the
    // validated value (comment), never the raw text_content.
    expect(st).toMatch(/validateComment\(text_content\)/);
    expect(st).toMatch(/parentId, comment\]/);
    expect(st).not.toMatch(/parentId, text_content\]/);
    const srv = read('server.ts');
    expect(srv).toMatch(/control-character-stripped/);
    expect(srv).toMatch(/clean\(action, 120\)/);
  });
});
