# سجل الأدلة الموحد (EVIDENCE REGISTER) — تدقيق ديراشة

> كل صف = ادعاء أمني → نوع الدليل → المسار/الأمر الفعلي → التصنيف. هذا السجل
> هو فهرس التحقق: أي مراجع يستطيع فتح الملف أو تشغيل الأمر والوصول لنفس النتيجة.
> المصادر: تدقيق A1 (المحرك والعميل) + تدقيق A2 (السيرفر/API/قاعدة البيانات)
> + مجسات الإنتاج الفعلية. التصنيفات: VERIFIED / PARTIALLY VERIFIED / UNVERIFIED
> / NOT IMPLEMENTED / FAILED.

## 1. أدلة E2EE (التشفير طرف-لطرف)

| الادعاء | الدليل | التصنيف |
|---|---|---|
| المحتوى يُشفَّر في المحرك قبل الخروج | engine.ts — دالة التغليف داخل بناء الظرف (seal) | VERIFIED |
| السيرفر يخزن DIR1/DIRM1/DIRG1 مشفرة | مجسد حي متكرر: آخر رسالة في API المحادثة تبدأ بـDIR1:/DIRG1 | VERIFIED |
| فك التشفير عند المستلم فقط (لا فك سيرفري) | لا مسار فك في server.ts/routes (grep) | VERIFIED |
| ذرية الاشتقاق-ثم-التزام (فشل AEAD لا يفسد الجلسة) | ratchetDecrypt + الاختبارات (engine tests — replay cases) | VERIFIED |
| حذف خاص OPK بعد الاستخدام المؤكد بالترتيب الصحيح | decryptEnvelope → saveSession ثم kv.del — اختبار o1 | VERIFIED |
| حراس إعادة الإرسال الأربعة (bootstrappedEk/retiredEks/retiredIks/dropped) | engine.ts + اختبارات الانحدار (replay fails closed) | VERIFIED |
| PQXDH هجين (PQ_SS يدخل HKDF بمعلومات مميزة) | engine.ts initSessionAsInitiator + tests/e2e-pq.test.ts 13 اختبار | VERIFIED |
| منع التراجع الكمي الصامت (حزم تكشف/لا تكشف) | حارس pq:true — اختبار pq5 | VERIFIED |
| الحشو داخل الـAEAD بالسلال | padding.ts + علم p:1 — اختبارات السلال | VERIFIED |
| توقيع لقطات الشفافية بالشاهد | KT root: mode=verified, signature present (حي) | VERIFIED |
| إثباتات تضمين/اتساق + كشف الفورك | tests/key-transparency.test.ts (21 — فحص شامل m,n) | VERIFIED |
| إدخال KT عند تسجيل المفاتيح | routes/e2ee.ts بعد COMMIT (aliases camelCase — إصلاح موثق) | VERIFIED |

## 2. أدلة فجوات وثغرات (أعلى الأدلة خطورة)

| النتيجة | الخطورة | الدليل | التصنيف |
|---|---|---|---|
| كاش الرسائل المفكوك + مفاتيح فك المرفقات بنص صريح محليًا | **Critical** | App.tsx (كتابات MessagesCacheDB) + messages_cache_db.ts؛ الخزنة تغطي محرك KV فقط | VERIFIED |
| طلب مفتاح مجموعة بلا تحقق عضوية المجموعة | **High** | App.tsx (key-request handler + توزيع) + group.ts processControl | VERIFIED |
| تحقق الشفافية بالعميل غير موصول (kt-client.ts dead code + Buffer) | **High** | grep الاستيرادات = صفر؛ ملف kt-client.ts | NOT IMPLEMENTED |
| هبوط صامت لنص صريح عند 404 حزمة (لا ذاكرة ولا تحذير) | Medium | engine.ts (fetchPeerDevices 404→PeerNotRegistered) + App (fallback) | VERIFIED |
| تراجع الكمي بإشراف السيرفر (لا ذاكرة عميل لـpq:true) | Medium | engine.ts حارس pq | PARTIALLY VERIFIED |
| تدوير المجموعة بحدث الطرد فقط + إعادة إرسال مجموعة ممكنة (لا دفتر n مستهلك) | Medium | App.tsx chat:evicted + group.ts | VERIFIED |
| verifyIdentityCurrency فشل مفتوح عند انقطاع النقل | Low | engine.ts (fail-open موثق بالكود) | VERIFIED |
| MAX_DEVICES عميل 6 مقابل توثيق سيرفر 8 | Low | crypto.ts vs docs | VERIFIED |
| emergencyRotate لا يمسح كاش الرسائل المحلي | Low | engine.ts (يمسح session:* فقط) | VERIFIED |
| مفاتيح الاستخدام الواحد: بقاء الخاص غير المستهلك للأبد | Low | engine.ts (حذف عند الاستخدام فقط — موثق كمفاضلة) | PARTIALLY VERIFIED |

## 3. أدلة السيرفر وAPI (من تدقيق A2 + المجسات الحية)

| النتيجة | الخطورة | الدليل | التصنيف |
|---|---|---|---|
| 167 نقطة نهاية مجرودة بمصادقة/تخويل/حدود | — | API_SECURITY_MATRIX.md | VERIFIED |
| تجاوز سياسة الإرسال عبر messages/sync (بلا assertCanSendMessage) | Medium | server.ts (sync bridge) | VERIFIED |
| دليل المستخدمين الكامل بلا ترقيم/حد معدل | Medium | server.ts /api/users | VERIFIED |
| الثقة بـx-forwarded-host في قائمة الأصول | Medium | server.ts (allowList) | PARTIALLY VERIFIED (لا يتأكد إلا برسالة حية) |
| غياب RLS كليًا (عزل بمستوى التطبيق فقط) | Medium | grep ROW LEVEL SECURITY = 0 | VERIFIED |
| اتصال Aiven بـssl rejectUnauthorized:false | Medium | database.ts | VERIFIED |
| توكن الوصول كاملًا في رابط WS | Low | ws_server.ts (auth subprotocol/URL) | VERIFIED |
| تسريب err.message في 500s (بلا stacks) | Low | نمط متكرر (88 موضعًا) | VERIFIED |
| sessions/check بلا فحص ملكية (oracle) | Low | server.ts | VERIFIED |
| صفر SQL injection (كل الاستعلامات مُعامَلة) | إيجابي | فحص مواضع interpolation (قوائم داخلية) | VERIFIED |
| صفر SSRF/path traversal (وسيط Drive بhost ثابت + regex) | إيجابي | routes/storage | VERIFIED |
| الحدود الموزعة fشل-مغلق للفئة الحرجة وموصولة فعليًا | إيجابي | redis_client evalAtomic + rate_limiter | VERIFIED |

## 4. أدلة الاختبارات الفعلية

| الأمر | النتيجة الفعلية (آخر تشغيل موثق) |
|---|---|
| `npm test` | 15 ملفًا / **210 اختبارًا ناجحًا** (شمل عشوائي 30 سيناريو + انحدارات التدقيق العدائي) |
| `npx tsc --noEmit` | صفر أخطاء |
| `npm run build` | أخضر (عميل + سيرفر) |
| بطارية نصوص حية (متصفحين) | PASS-REG + PASS-DECRYPT + PASS-SERVER-CIPHER |
| بطارية مجموعات حية (CDP) | PASS ×2 + مفاتيح الطرفين في المخازن |
| بطارية الأجهزة المتعددة | كل تدفق نجح عبر التشغيلات + تطابق الأسطول 6/6 |
| مجسات API الحية | 6/6 رفض كما هو متوقع (الجدول أعلاه) |

## 5. أدلة غير متاحة أو تعذر تشغيلها (بصراحة)

- مجس 4th-bundle-fetch على هدف **حقيقي** تم تخطيه: كل جلب يستهلك OPK (تعديل حالة) — ممنوع بالتدقيق. بديل آمن نُفذ على هدف وهمي (النتيجة موثقة أعلاه).
- اختبار WebAuthn حي بمتصفح: موجود (deploy/passkeys-verify.cjs بمُصادق افتراضي CDP) — آخر تشغيل مسجل به عوائق ملاحة (SW reload) — النتيجة النهائية للحفل الكامل: PARTIALLY VERIFIED.
- اختبار مرفق مشفر داخل مجموعة حيًا: NOT IMPLEMENTED في البطاريات (الوحدة مختبرة وحدةً فقط).
- تدوير الطوارئ حيًا مع تفعيل العلم: NOT IMPLEMENTED في البطاريات (الوحدة مختبرة 3 اختبارات + العلم متوقف).

## 6. أدلة الخصوصية وتدفق البيانات (تدقيق A3)

| النتيجة | الخطورة | الدليل | التصنيف |
|---|---|---|---|
| نسخة صريحة من الوسائط تُرفع لـDrive قبل التغليف (الاسم الأصلي في الميتاداتا) وتُترك يتيمة | **High** | ChatWindow.tsx:1643/1964/2172/2308/4068 + storageUtils.ts:186-196 | VERIFIED |
| القنوات + المسار الاحتياطي يحملان نصًا صريحًا كاملًا | **High** | App.tsx:1608-1612/4818-4820 + ws_server.ts:874-882 | VERIFIED |
| auth_logs تحفظ IP كاملًا بلا تقليم وبلا FK (تنجو من حذف الحساب) | Medium-High | database.ts:5485-5511 + authClassic.ts:267 | VERIFIED |
| تنظيف خزنة الرسائل المحذوفة رقاقة فارغة (يرجع 0) + محتوى أصلي قابل للبحث من المشرفين | Medium-High | database.ts:5135-5137 + server.ts:3339-3348 | VERIFIED |
| ملفات Drive لا تُحذف أبدًا من التطبيق | Medium | غياب نقطة حذف (grep) | VERIFIED |
| IP مقتطع يصل مزودات الضغط في تنبيهات الأمان | Medium | securityAlerts.ts:70-72 | VERIFIED |
| Gemini لا يرسل شيئًا لجوجل (no-op موثق) | إيجابي | services/gemini.ts:1-19 | VERIFIED |
| الإشعارات عامة (بلا محتوى/أسماء) — SW لا يسجل حمولات | إيجابي | push.ts:37-71 + service-worker.js | VERIFIED |

## 7. أدلة نموذج التهديدات وسلسلة التوريد والاختبارات (تدقيق A4)

| النتيجة | الخطورة | الدليل | التصنيف |
|---|---|---|---|
| npm audit --omit=dev: صفر ثغرات (اليوم) | إيجابي | تشغيل فعلي | VERIFIED |
| SBOM: 371 مكوّنًا + scan-secrets: 182 ملفًا نظيفًا + تراخيص: صفر مرفوضة | إيجابي | تشغيل فعلي | VERIFIED |
| Typosquat: الـ50 مباشرة تحقق منها (المشرفون الصحيحون) | إيجابي | npm view | VERIFIED |
| CSP صارم + صفر XSS sinks + CSRF عبر Origin + clickjacking مغطى | إيجابي | server.ts:253-270/291-304 + grep | VERIFIED |
| refresh token يعود في جسم الاستجابة رغم قناة الكوكي | Medium | server.ts:718 | VERIFIED |
| مجساد الرفض الحية: 6/6 PASSED (تفصيلها في API_MATRIX) | إيجابي | تشغيل فعلي | VERIFIED |
| بطاريات حية: نتائج متفاوتة اليوم (نوافذ SW-reload) — 1:1 PASS كامل، مجموعات CDP PASS، تدوير/مفاتيح مرور PARTIALLY | PARTIALLY | deploy/*.log | PARTIALLY VERIFIED |