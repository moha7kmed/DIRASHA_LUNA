/**
 * TOTP two-factor service (RFC 6238 via otplib)
 * ---------------------------------------------
 * Secret at rest: encrypted via the database layer's AES-256-GCM
 * snapshot encryption (same derived key, ENC1 blob) — no separate
 * key management. Replay protection: see route layer (counter binding).
 */
import { generateSecret, generateURI, verifySync } from 'otplib';

export const TOTP_ISSUER = 'Dirasha';

/** New enrollment secret + otpauth:// URI for the authenticator app. */
export function createEnrollment(accountName: string): { secret: string; otpauthUri: string } {
  const secret = generateSecret();
  const otpauthUri = generateURI({ issuer: TOTP_ISSUER, label: accountName, secret });
  return { secret, otpauthUri };
}

/** Verify a 6-digit token (±1 step window). Returns matched delta or null. */
export function verifyTotp(token: string, secret: string): number | null {
  try {
    const res = verifySync({ token: String(token || ''), secret });
    return res.valid ? (res.delta ?? 0) : null;
  } catch {
    return null;
  }
}

/** Current 30-second counter window (for replay binding). */
export function currentTotpCounter(): number {
  return Math.floor(Date.now() / 1000 / TOTP_STEP_SECONDS);
}

export const TOTP_STEP_SECONDS = 30;
