/**
 * Project 9 — Passkeys/WebAuthn server-side security tests.
 * Covers the pure helpers exported from src/server/routes/passkeys.ts
 * (the route handlers are exercised E2E against PG like the other auth
 * surfaces; these tests pin the SECURITY-CRITICAL logic):
 *   1. Signature-counter monotonicity (clone detection → reject + invalidate)
 *   2. Challenge TTL expiry + one-time consumption
 *   3. Origin/RP-ID mismatch rejection (cross-origin assertions)
 *   4. Credential ownership gating
 *   5. The library's verify boundary rejects crafted garbage responses
 * Run: npm test
 */
import { describe, it, expect } from 'vitest';
import {
  checkCounterMonotonic,
  ChallengeStore,
  originMatchesRpId,
  deriveRpIdFromHost,
  assertCredentialOwnership,
} from '../src/server/routes/passkeys.ts';
import { verifyRegistrationResponse } from '@simplewebauthn/server';

/* ── 1. Counter monotonicity (clone detection) ──────────────────────────────── */
describe('passkey counter monotonicity (clone detection)', () => {
  it('accepts a strictly greater counter (normal usage)', () => {
    expect(checkCounterMonotonic(5, 6)).toEqual({ ok: true, clone: false });
    expect(checkCounterMonotonic(0, 1).ok).toBe(true);
    expect(checkCounterMonotonic(999999, 1000000).ok).toBe(true);
  });

  it('REJECTS an equal counter as a replay (counter MUST strictly increase)', () => {
    const r = checkCounterMonotonic(42, 42);
    expect(r.ok).toBe(false);
    expect(r.clone).toBe(true);
    expect(r.reason).toBe('counter_not_increased');
  });

  it('REJECTS a regressed counter as a clone (signature replay from a duplicated credential)', () => {
    const r = checkCounterMonotonic(10, 9);
    expect(r.ok).toBe(false);
    expect(r.clone).toBe(true);
    expect(r.reason).toBe('counter_regressed');
  });

  it('accepts the 0/0 counterless-authenticator mode (WebAuthn spec: no counter support)', () => {
    const r = checkCounterMonotonic(0, 0);
    expect(r.ok).toBe(true);
    expect(r.clone).toBe(false);
    expect(r.reason).toBe('counterless_authenticator');
  });

  it('treats non-finite or negative counters as a hard reject + clone', () => {
    expect(checkCounterMonotonic(NaN, 1)).toEqual({ ok: false, clone: true, reason: 'invalid_counter' });
    expect(checkCounterMonotonic(1, Infinity)).toEqual({ ok: false, clone: true, reason: 'invalid_counter' });
    expect(checkCounterMonotonic(-1, 0).clone).toBe(true);
    expect(checkCounterMonotonic(0, -5).clone).toBe(true);
  });
});

/* ── 2. Challenge store: TTL + single use ───────────────────────────────────── */
describe('passkey challenge store (5-min TTL, one-time consume)', () => {
  const makeStore = (ttlMs = 5 * 60 * 1000) => {
    let now = 1_000_000;
    const store = new ChallengeStore(ttlMs, () => now);
    return { store, tick: (ms: number) => { now += ms; } };
  };

  it('set/consume roundtrips a library-generated challenge', () => {
    const { store } = makeStore();
    store.set('reg:user1', 'CHALLENGE_ABC');
    expect(store.consume('reg:user1')).toBe('CHALLENGE_ABC');
  });

  it('issue() returns a base64url challenge and stores it', () => {
    const { store } = makeStore();
    const c = store.issue('auth:alice');
    expect(c).toMatch(/^[A-Za-z0-9_-]{40,}$/); // 32 bytes → ~43 base64url chars
    expect(store.consume('auth:alice')).toBe(c);
  });

  it('expires challenges after the TTL (5-minute default, tested with a short TTL)', () => {
    const { store, tick } = makeStore(5000);
    store.set('auth:bob', 'OLD_CHALLENGE');
    tick(4999);
    expect(store.consume('auth:bob')).toBe('OLD_CHALLENGE'); // just inside TTL
    store.set('auth:bob', 'NEW_CHALLENGE');
    tick(5001);
    expect(store.consume('auth:bob')).toBeNull(); // expired → null
    expect(store.peek('auth:bob')).toBeNull();    // and already consumed above
  });

  it('consume is strictly one-time: the second attempt fails even inside the TTL', () => {
    const { store } = makeStore();
    store.set('reg:user2', 'ONE_TIME');
    expect(store.consume('reg:user2')).toBe('ONE_TIME');
    expect(store.consume('reg:user2')).toBeNull(); // replay of the same challenge → dead
  });

  it('unknown keys consume to null (no challenge ever issued)', () => {
    const { store } = makeStore();
    expect(store.consume('auth:nobody')).toBeNull();
  });

  it('expired entries stop counting toward the live-store size', () => {
    const { store, tick } = makeStore(1000);
    store.set('a', '1');
    store.set('b', '2');
    expect(store.size()).toBe(2);
    tick(1500); // both now expired
    store.set('c', '3');
    expect(store.size()).toBe(1); // only the fresh challenge remains live
    expect(store.consume('a')).toBeNull();
    expect(store.consume('c')).toBe('3');
  });
});

/* ── 3. Origin / RP-ID ──────────────────────────────────────────────────────── */
describe('passkey origin/RP-ID validation (cross-origin rejection)', () => {
  it('derives rpID as host without port', () => {
    expect(deriveRpIdFromHost('dirasha.onrender.com:443')).toBe('dirasha.onrender.com');
    expect(deriveRpIdFromHost('localhost:3000')).toBe('localhost');
    expect(deriveRpIdFromHost('dirasha.onrender.com')).toBe('dirasha.onrender.com');
    expect(deriveRpIdFromHost('[::1]:3000')).toBe('::1'); // IPv6-aware
    expect(deriveRpIdFromHost('')).toBe('');
    expect(deriveRpIdFromHost(undefined)).toBe('');
  });

  it('accepts an origin whose hostname exactly equals the rpID', () => {
    expect(originMatchesRpId('https://dirasha.onrender.com', 'dirasha.onrender.com')).toBe(true);
    expect(originMatchesRpId('https://localhost:3000', 'localhost')).toBe(true);
    expect(originMatchesRpId('http://localhost:5173', 'localhost')).toBe(true); // dev secure-context exception
  });

  it('REJECTS cross-origin assertions', () => {
    expect(originMatchesRpId('https://evil.example.com', 'dirasha.onrender.com')).toBe(false);
    // subdomain delegation is NOT allowed (strict single-host equality)
    expect(originMatchesRpId('https://app.dirasha.onrender.com', 'dirasha.onrender.com')).toBe(false);
    // a different port on the SAME host is still the same rpID per WebAuthn
    // (rpID = effective domain, portless); the FULL origin is pinned exactly
    // via expectedOrigin at verify time, so a port swap still fails there.
    expect(originMatchesRpId('https://dirasha.onrender.com:8443', 'dirasha.onrender.com')).toBe(true);
    expect(originMatchesRpId('https://evil.example.com', 'dirasha.onrender.com')).toBe(false);
  });

  it('REJECTS garbage, null and missing origins', () => {
    expect(originMatchesRpId(undefined, 'dirasha.onrender.com')).toBe(false);
    expect(originMatchesRpId('null', 'dirasha.onrender.com')).toBe(false);
    expect(originMatchesRpId('not a url', 'dirasha.onrender.com')).toBe(false);
    expect(originMatchesRpId('https://dirasha.onrender.com', '')).toBe(false);
  });

  it('REJECTS non-https origins for non-localhost hosts', () => {
    expect(originMatchesRpId('http://dirasha.onrender.com', 'dirasha.onrender.com')).toBe(false);
  });
});

/* ── 4. Ownership ───────────────────────────────────────────────────────────── */
describe('passkey credential ownership', () => {
  it('grants access only to the owning user id', () => {
    expect(assertCredentialOwnership('user-1', 'user-1')).toBe(true);
  });

  it('denies foreign users, and empty/null owners', () => {
    expect(assertCredentialOwnership('user-1', 'user-2')).toBe(false);
    expect(assertCredentialOwnership('', 'user-1')).toBe(false);
    expect(assertCredentialOwnership(null, 'user-1')).toBe(false);
    expect(assertCredentialOwnership(undefined, 'user-1')).toBe(false);
  });
});

/* ── 5. Library verify boundary (crafted garbage response objects) ──────────── */
describe('passkey verify boundary (@simplewebauthn/server)', () => {
  it('throws on a crafted malformed registration response (parsing boundary rejects garbage)', async () => {
    const garbage = {
      id: 'not-a-real-credential-id',
      rawId: '%%%',
      type: 'public-key',
      response: {
        clientDataJSON: 'Zm9v', // base64 of "foo" — not valid JSON
        attestationObject: '!!!not-base64!!!',
      },
    } as unknown as Parameters<typeof verifyRegistrationResponse>[0]['response'];
    await expect(
      verifyRegistrationResponse({
        response: garbage,
        expectedChallenge: 'some-challenge',
        expectedOrigin: 'https://dirasha.onrender.com',
        expectedRPID: 'dirasha.onrender.com',
      }),
    ).rejects.toBeTruthy();
  });

  it('throws when the crafted response challenge does not match the stored challenge', async () => {
    // Valid base64url JSON clientData with a WRONG challenge — the library's
    // challenge comparison must fail before any credential trust is granted.
    const clientData = Buffer.from(JSON.stringify({
      type: 'webauthn.create',
      origin: 'https://dirasha.onrender.com',
      challenge: 'ATTACKER_CHALLENGE',
    })).toString('base64');
    const crafted = {
      id: 'AA',
      rawId: 'AA',
      type: 'public-key',
      response: {
        clientDataJSON: clientData,
        attestationObject: Buffer.from('{}').toString('base64'), // structurally invalid CBOR for attestation
      },
    } as unknown as Parameters<typeof verifyRegistrationResponse>[0]['response'];
    await expect(
      verifyRegistrationResponse({
        response: crafted,
        expectedChallenge: 'SERVER_GENERATED_CHALLENGE',
        expectedOrigin: 'https://dirasha.onrender.com',
        expectedRPID: 'dirasha.onrender.com',
      }),
    ).rejects.toThrow(/challenge/i);
  });
});
