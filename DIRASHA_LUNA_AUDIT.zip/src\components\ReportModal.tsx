import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Flag, Check, Loader2, AlertCircle } from 'lucide-react';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetUserId: string;
  targetUserDisplayName: string;
  targetMessageId?: string | null;
  targetMessageContent?: string | null;
  accessToken: string;
}

const CATEGORIES = [
  { id: 'Spam', label: 'رسائل مزعجة (Spam)' },
  { id: 'Harassment', label: 'مضايقة أو إساءة (Harassment)' },
  { id: 'Hate Speech', label: 'خطاب كراهية (Hate Speech)' },
  { id: 'Impersonation', label: 'انتحال شخصية (Impersonation)' },
  { id: 'Scam / Fraud', label: 'احتيال أو تضليل (Scam / Fraud)' },
  { id: 'Violence', label: 'عنف أو تهديد (Violence)' },
  { id: 'Adult Content', label: 'محتوى غير لائق (Adult Content)' },
  { id: 'Other', label: 'آخر (Other)' },
];

export function ReportModal({
  isOpen,
  onClose,
  targetUserId,
  targetUserDisplayName,
  targetMessageId,
  targetMessageContent,
  accessToken
}: ReportModalProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCategory) {
      setError('يرجى اختيار فئة البلاغ أولاً.');
      return;
    }
    if (selectedCategory === 'Other' && !description.trim()) {
      setError('يرجى كتابة تفاصيل البلاغ عند اختيار تصنيف (آخر).');
      return;
    }
    if (description.length > 500) {
      setError('لا يمكن أن يتجاوز الوصف 500 حرف.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/moderation/reports', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({
          targetUserId,
          targetMessageId: targetMessageId || undefined,
          targetType: targetMessageId ? 'message' : 'user',
          category: selectedCategory,
          description: description.trim() || undefined
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'فشل في إرسال البلاغ.');
      }

      setSuccess(true);
      if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
        (window as any).showGlobalToast('تم إرسال البلاغ مراجعة أمنية.', 'success');
      }
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        navigator.vibrate([30]);
      }
      setTimeout(() => {
        handleClose();
      }, 2500);
    } catch (err: any) {
      setError(err.message || 'حدث خطأ ما أثناء إرسال البلاغ.');
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setSelectedCategory('');
    setDescription('');
    setError(null);
    setSuccess(false);
    onClose();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[150] flex items-center justify-center bg-black/60 px-4 font-sans" dir="rtl">
        <div className="absolute inset-0" onClick={handleClose} />

        <motion.div
          initial={{ opacity: 0, scale: 0.98, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.98, y: 10 }}
          transition={{ duration: 0.15 }}
          className="relative w-[92vw] max-w-[420px] max-h-[80vh] bg-[#212121] border border-white/10 rounded-2xl overflow-hidden shadow-2xl text-white z-10 flex flex-col"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-white/10 shrink-0">
            <div className="flex items-center gap-2 text-zinc-200">
              <Flag className="w-4 h-4" />
              <h3 className="text-sm font-semibold">إبلاغ عن {targetMessageId ? 'رسالة' : 'مستخدم'}</h3>
            </div>
            <button
              onClick={handleClose}
              className="text-zinc-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="p-5 overflow-y-auto overflow-x-hidden scrollbar-hide space-y-4">
            {success ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center justify-center py-8 text-center space-y-3"
              >
                <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white mb-2">
                  <Check className="w-5 h-5" strokeWidth={2} />
                </div>
                <h4 className="text-sm font-medium text-zinc-200">شكرًا لك</h4>
                <p className="text-xs text-zinc-400">تم استلام بلاغك وسيقوم فريقنا بمراجعته قريباً للتحقق من أي انتهاكات للشروط.</p>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="text-[13px] text-zinc-300">
                  <span className="font-semibold">{targetUserDisplayName}</span>
                </div>

                <div className="space-y-2">
                  <label className="block text-xs font-medium text-zinc-400">
                    سبب الإبلاغ
                  </label>
                  <div className="flex flex-col gap-1.5">
                    {CATEGORIES.map((cat) => (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => {
                          setSelectedCategory(cat.id);
                          setError(null);
                        }}
                        className={`px-3 py-2.5 text-right text-xs rounded-lg transition-colors flex items-center justify-between ${
                          selectedCategory === cat.id
                            ? 'bg-zinc-700 text-white font-medium'
                            : 'hover:bg-zinc-800 text-zinc-300'
                        }`}
                      >
                        {cat.label}
                        {selectedCategory === cat.id && <Check className="w-3.5 h-3.5" />}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2 pt-2">
                  <label className="block text-xs font-medium text-zinc-400 flex justify-between">
                    <span>تفاصيل إضافية (اختياري)</span>
                    <span>{description.length}/500</span>
                  </label>
                  <textarea
                    value={description}
                    onChange={(e) => {
                      if (e.target.value.length <= 500) {
                        setDescription(e.target.value);
                        setError(null);
                      }
                    }}
                    placeholder="يمكنك إضافة أي سياق إضافي هنا..."
                    className="w-full h-20 bg-zinc-800/50 border border-zinc-700 rounded-lg p-3 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-zinc-500 resize-none transition-colors"
                  />
                </div>

                {error && (
                  <div className="p-3 bg-zinc-800/80 border border-zinc-700 rounded-lg text-xs text-zinc-300 flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-zinc-400 mt-0.5" />
                    <span>{error}</span>
                  </div>
                )}

                <div className="pt-3">
                  <button
                    type="submit"
                    disabled={loading || !selectedCategory}
                    className="w-full py-2.5 bg-zinc-100 hover:bg-white text-zinc-900 text-[13px] font-semibold rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 relative"
                  >
                    {loading ? (
                      <Loader2 className="w-4 h-4 animate-spin text-zinc-600" />
                    ) : (
                      'إرسال البلاغ'
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
