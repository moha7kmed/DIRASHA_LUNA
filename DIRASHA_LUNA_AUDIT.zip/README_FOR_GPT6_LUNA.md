# README_FOR_GPT6_LUNA.md

مُراجع GPT-6 Luna العزيز،

هذه الحزمة (حزمة التدقيق المستقلة) خاصة بمشروع **DIRASHA**، تم إعدادها لتكون مادة مصدر أولية لمراجعة أمنية وتشفيرية ومعمارية مستقلة من قِبل نموذج خارجي (GPT-6 Luna)، دون الاعتماد على المستودع الأصلي (Git).

---

## 1. ما هو مشروع DIRASHA؟

DIRASHA هو تطبيق مراسلة وتواصل فوري (Messaging / Collaboration) يركّز على الخصوصية والأمان التشفيري من النهاية إلى النهاية (E2EE). يدعم المحادثات الفردية وال grupية، المكالمات الصوتية والمرئية (WebRTC)، مشاركة الوسائط، إدارة الجلسات والأجهزة، التخزين السحابي vinculado (BYO-Cloud)، النسخ الاحتياطي والاستعادة، والمزامنة مع الرسائل المجدولة.

## 2. وظائف التطبيق الأساسية

- المراسلة الفورية الفردية والجماعية مع تشفير من النهاية إلى النهاية
- المكالمات الصوتية والمرئية الجماعية عبر WebRTC مع شبكة تشبيك (mesh) للمكالمات
- المصادقة والتفويض: تسجيل دخول كلاسيكي، Passkeys (WebAuthn)، توكينات التجديد (refresh tokens)، TOTP (التحقق الثنائي)، إدارة الجلسات النشطة
- إدارة الأجهزة الموثوقة وجلسة كل جهاز
- تشفير الوسائط (الصور/الفيديو/الصوت) قبل الرفع
- تخزين وقبو (Vault) للمصادقات وبيانات الاعتماد المشفرة
- النسخ الاحتياطي والاستعادة (Backup & Recovery) مع تشفير النسخ المحلية
- المزامنة والرسائل المجدولة (Sync & Scheduled Messages)
- حرس أمن (Security Guards) على مداخل API و WebSocket
- التكامل مع قاعدة بيانات (PostgreSQL/PGlite) و Redis
- مراقبة التنبيهات الأمنية وسجلات التدقيق

## 3. المعمارية ومكونات المشروع

- `src/` — كود المصدر completo (واجهة React + خادم Express + WebSocket)
  - `src/components` — مكونات واجهة المستخدم
  - `src/lib` — مكتبات مشتركة (tشفير، зб، WebSocket، ذاكرة تخزين مؤقت)
  - `src/lib/e2ee` — تنفيذ التشفير من النهاية إلى النهاية (crypto، engine، group، kt-client، media، vault، padding، backup)
  - `src/server` — الخادم (auth، e2ee، kt، passkeys، storage، recovery، totp، rate_limiter، securityAlerts، websocket/ws_server، redis_client، database)
  - `src/server/routes` — مسارات API (authClassic، e2ee، groupCallRoutes، kt، passkeys، status، storage)
  - `src/server/websocket` — خادم WebSocket (ws_server، ack_manager، presence_manager، write_queue)
  - `src/guards` — حراس الأمن على النقاط النهائية
- `tests/` — اختبارات مكتوبة بـ Vitest (وحدة، تكامل، سلوك، انحدار، تشفير، أمان) مع تجريب (fixtures) شهادات اختبار TLS فقط
- `docs/` — وثائق المعمارية (ARC، تدفق البيانات، نموذج التهديد، مخزون التشفير، تصميم E2EE/PQXDH/مكالمات جماعية/مرسل مختوم)
- `deploy/coturn/` — قوالب النشر (docker-compose.yml، turnserver.conf)
- `package.json` / `package-lock.json` / `tsconfig.json` / `vite.config.ts` / `vitest.config.ts` / `Dockerfile` / `render.yaml` — إعدادات التشغيل والتبعيات والبناء
- `.env.example` — مثال متغيرات البيئة (قيم فارغة/مقبّلة؛ لا يحتوي أسراراً)
- تقارير التدقيق النهائية في مجلد `DIRASHA_FINAL_AUDIT_CLOSURE/`

## 4. مواقع تنفيذ التشفير (الأماكن الأساسية للمراجع)

- `src/lib/e2ee/crypto.ts` — البدائيات التشفيرية (AES-GCM، تجزئة، مشتقات مفاتيح)
- `src/lib/e2ee/engine.ts` — محرك التشفير والفك من النهاية إلى النهاية
- `src/lib/e2ee/group.ts` — تشفير المجموعات والمُركّب (ratchet) الجماعي
- `src/lib/e2ee/kt-client.ts` و `src/server/key_transparency.ts` — الشفافية المفتاحية (Key Transparency)
- `src/lib/e2ee/media.ts` — تشفير الوسائط
- `src/lib/e2ee/vault.ts` و `src/lib/e2ee/backup.ts` — قبو التشفير والنسخ الاحتياطي المشفر
- `src/lib/e2ee/padding.ts` — التبطين (padding) لإخفاء أنماط الأحجام
- `src/server/e2ee.ts` — منطق E2EE على الخادم
- `src/server/auth.ts`، `authClassic.ts`، `passkeys.ts`، `totp.ts`، `password.ts`، `recovery.ts` — المصادقة وإدارة المفاتيح والسرية
- `src/server/storage.ts` — تخزين البيانات linked storage
- `src/lib/socket_client.ts`، `src/server/websocket/ws_server.ts` — قناة WebSocket الآمنة

## 5. مواقع الاختبارات

- `tests/` — جميع ملفات الاختبار (`*.test.ts`) تشمل:
  - تشفير: `crypto-hardening.test.ts`، `e2ee-engine.test.ts`، `e2ee-group.test.ts`، `e2ee-rotation.test.ts`، `e2ee-media.test.ts`، `e2ee-backup.test.ts`، `e2ee-vault-padding.test.ts`، `e2ee-fuzz.test.ts`
  - مصادقة/جلسات: `auth-session.test.ts`، `passkeys.test.ts`، `refresh-token-body.test.ts`
  - مجموعات: `group-membership.test.ts`، `group-ratchet.test.ts`
  - قاعدة بيانات/تخزين: `db-tls.test.ts`، `db-tls-negative.test.ts`، `db-fail-closed.test.ts`، `cache-vault.test.ts`، `vault-hardening.test.ts`
  - أمان/شبكة: `security.test.ts`، `e2ee-security-audit.test.ts`، `ws-ticket.test.ts`، `ws-legacy-cutoff.test.ts`، `ingress-policy.test.ts`، `distributed-rate-limit.test.ts`، `scanner-hardening.test.ts`
  - pós-كمي: `e2e-pq.test.ts`
  - 기타: `media-auth.test.ts`، `media-token-scope.test.ts`، `media-e2e-flow.test.ts`، `key-transparency.test.ts`، `kt-gate.test.ts`، `status-privacy.test.ts`، `notification-privacy.test.ts`، `users-endpoint.test.ts`، `app-client-hardening.test.ts`، `authclassic-hardening.test.ts`، `remediation-batch*.test.ts`، `infra-p3.test.ts`
## 6. التقارير الأمنية الموجودة (في `DIRASHA_FINAL_AUDIT_CLOSURE/`)

جميع التقارير النهائية المدرجة للمراجعة:
- `DIRASHA_FINAL_CLOSURE_SUMMARY.md`
- `DIRASHA_FINAL_VERIFICATION_REPORT.md`
- `DIRASHA_FINAL_RELEASE_GATE.md`
- `DIRASHA_APPSEC_ADVERSARIAL_REVIEW.md`
- `DIRASHA_CRYPTO_PRIVACY_ADVERSARIAL_REVIEW.md`
- `DIRASHA_PROTOCOL_READINESS_ASSESSMENT.md`
- `DIRASHA_CRYPTOGRAPHIC_RESIDUALS.md`
- `DIRASHA_FINAL_SECURITY_LEDGER.csv`
- `DIRASHA_EVIDENCE_INDEX.md`
- `STAGING_RUNTIME_VALIDATION_PLAN.md`
- `DIRASHA_STAGING_RUNTIME_REPORT.md`
- `DIRASHA_GIT_INTEGRITY_REPORT.md`

## 7. وضع G1 وG2

يرجى الاطلاع على `DIRASHA_FINAL_CLOSURE_SUMMARY.md` و`DIRASHA_FINAL_RELEASE_GATE.md` لحالة بوابات الإطلاق G1/G2 والتحقق من الامتثال.

## 8. المخاطر التشفيرية المعروفة (مخلّفات)

يرجى مراجعة `DIRASHA_CRYPTOGRAPHIC_RESIDUALS.md` و`DIRASHA_CRYPTO_PRIVACY_ADVERSARIAL_REVIEW.md` لمعرفة المخاطر التشفيرية المتبقية المعروفة والتقييمات المعارضة. هذه التقارير هي جهود بشرية/آلية سابقة **وليست حقيقة نهائية**.

## 9. الهدف المستقبلي: DIRASHA PROTOCOL

بعد اكتمال نضج التطبيق واستقرار تنفيذه، الهدف هو تطوير **DIRASHA PROTOCOL** كبروتوكول اتصال مستقل ومعياري (مفتوح)، منفصل عن تطبيق DIRASHA الحالي، ليتم اعتماده من قبل تطبيقات أخرى مع ضمانات تشفيرية قابلة للتدقيق المستقل.

## 10. طلب إلى GPT-6 Luna

يُرجى مراجعة كود مصدر المشروع والتشفير والاختبارات بنفسك، وعدم الاعتماد على التقارير المدرجة باعتبارها حقيقة نهائية أو معززة. التقارير مرجع المساعدة فقط، والكود هو المصدر الموثوق. يُطلب تحديد أي ثغرات تشفيرية أو Architectural أو تنفيذية وتقديم توصيات تصحيحية.

---

ملاحظات عامة للحزمة:
- لا تحتوي الحزمة على `.env` حقيقي، ولا مفاتيح إنتاج، ولا كلمات مرور، ولا رموز API، ولا بيانات مستخدمين حقيقية، ولا نسخ احتياطية للإنتاج.
- `.env.example` مُدرج مع قيم فارغة/مقبّلة وأسماء المتغيرات محفوظة كما هي.
- تم استبعاد `.git` و `node_modules` و `dist` والسجلات والصور الثنائية غير الضرورية ونسخ بيانات المستخدم المحلي (راجع `PACKAGE_REPORT.md` للقائمة الكاملة بالاستبعادات).
- راجع `BUNDLE_MANIFEST.csv` لقائمة الملفات المسجلة وأحصافها SHA-256 للتحقق من السلامة.

- `tests/fixtures/` — تجريب اختبار: شهادات/مفاتيح TLS خاصة ببيئة الاختبار فقط (`test-ca.*`، `test-host.*`) **ليست مفاتيح إنتاج**.
