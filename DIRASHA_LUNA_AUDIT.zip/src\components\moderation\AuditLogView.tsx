import React from 'react';
import { ShieldAlert, Calendar, Clock, ArrowRight, ShieldCheck, Trash2, Ban, VolumeX, CheckCircle, RefreshCw } from 'lucide-react';
import { motion } from 'motion/react';
import { UserBadge } from './ModerationShared.tsx';

interface AuditLog {
  id: string;
  action: string;
  moderatorId: string;
  moderatorName?: string;
  moderatorAvatar?: string;
  targetId?: string;
  targetName?: string;
  targetAvatar?: string;
  targetResource?: string;
  reason?: string;
  metadata?: any;
  createdAt: string;
}

interface AuditLogViewProps {
  logs: AuditLog[];
  loading: boolean;
}

export function AuditLogView({ logs, loading }: AuditLogViewProps) {
  if (loading && logs.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-32 text-zinc-500">
        <RefreshCw className="w-8 h-8 animate-spin mb-4 text-indigo-500/40" />
        <span className="text-[10px] font-black uppercase tracking-widest text-zinc-600">Retrieving secure ledger...</span>
      </div>
    );
  }

  if (logs.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-32 text-zinc-500 rounded-[40px] border border-dashed border-white/5 bg-white/[0.01]">
        <ShieldCheck className="w-12 h-12 mb-4 opacity-5" />
        <span className="text-[11px] font-black uppercase tracking-widest opacity-40">Audit record is currently clear</span>
      </div>
    );
  }

  const getActionIcon = (action: string) => {
    switch (action) {
      case 'USER_BANNED': return <Ban className="w-4 h-4 text-zinc-100" />;
      case 'USER_UNBANNED': return <ShieldCheck className="w-4 h-4 text-zinc-400" />;
      case 'USER_MUTED': return <VolumeX className="w-4 h-4 text-zinc-100" />;
      case 'USER_UNMUTED': return <RefreshCw className="w-4 h-4 text-zinc-400" />;
      case 'MESSAGE_DELETED': return <Trash2 className="w-4 h-4 text-zinc-300" />;
      case 'REPORT_RESOLVED': return <CheckCircle className="w-4 h-4 text-emerald-400" />;
      case 'USER_ROLE_UPDATED': return <ShieldCheck className="w-4 h-4 text-zinc-200" />;
      default: return <ShieldAlert className="w-4 h-4 text-zinc-400" />;
    }
  };

  const getActionLabel = (action: string) => {
    if (!action) return 'SYSTEM EVENT';
    const labels: Record<string, string> = {
      'USER_MUTED': 'Mute Applied',
      'USER_UNMUTED': 'Mute Lifted',
      'USER_BANNED': 'Ban Imposed',
      'USER_UNBANNED': 'Ban Revoked',
      'USER_WARNED': 'Formal Warning',
      'WARNINGS_CLEARED': 'Warnings Wiped',
      'MESSAGE_DELETED': 'Message Purged',
      'REPORT_RESOLVED': 'Inquiry Closed',
      'REPORT_REJECTED': 'Inquiry Dismissed',
      'USER_ROLE_UPDATED': 'Privilege Shift',
      'LOGIN_SUCCESS': 'Security Access'
    };
    return labels[action] || action.replace(/_/g, ' ');
  };

  return (
    <div className="space-y-6 pb-20">
      {logs.map((log) => (
        <motion.div
          key={log.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="group relative bg-white/[0.02] border border-white/5 rounded-[40px] overflow-hidden hover:bg-white/[0.04] hover:border-white/10 transition-all p-6 md:p-8 backdrop-blur-md"
        >
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="flex flex-col md:flex-row md:items-center gap-6 flex-1">
               <div className="flex items-center gap-4">
                  <UserBadge 
                    user={{ 
                      id: log.moderatorId, 
                      displayName: log.moderatorName || 'Authority',
                      avatarUrl: log.moderatorAvatar
                    }}
                    size="sm"
                  />
                  <div className="p-2.5 bg-white/5 rounded-xl border border-white/5 group-hover:bg-white/10 transition-colors shrink-0">
                    {getActionIcon(log.action)}
                  </div>
               </div>
               
               <div className="flex flex-col gap-1.5 flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="text-[9px] font-black text-white bg-white/5 px-2.5 py-1 rounded-lg border border-white/5 uppercase tracking-widest shrink-0">
                      {getActionLabel(log.action)}
                    </span>
                    
                    {log.targetId && (
                      <div className="flex items-center gap-3">
                        <ArrowRight className="w-3.5 h-3.5 text-zinc-800" />
                        <UserBadge 
                          user={{ 
                            id: log.targetId, 
                            displayName: log.targetName || 'Subject',
                            avatarUrl: log.targetAvatar
                          }}
                          size="sm"
                        />
                      </div>
                    )}
                  </div>
                  
                  <p className="text-[10px] text-zinc-500 leading-relaxed font-bold uppercase tracking-wide opacity-50">
                    {log.metadata?.reason || log.reason || 'Record entry generated.'}
                  </p>
               </div>
            </div>

            <div className="flex flex-row lg:flex-col items-center lg:items-end gap-4 shrink-0 pt-4 lg:pt-0 border-t lg:border-t-0 border-white/5">
               <div className="flex items-center gap-2 text-[9px] font-black text-zinc-600 uppercase tracking-widest bg-white/5 px-2.5 py-1 rounded-lg">
                  <Calendar className="w-3 h-3 opacity-40" />
                  <span>{new Date(log.createdAt).toLocaleDateString('en-US', { day: 'numeric', month: 'short' })}</span>
               </div>
               <div className="flex items-center gap-2 text-[9px] font-black text-zinc-700 uppercase tracking-widest bg-white/5 px-2.5 py-1 rounded-lg">
                  <Clock className="w-3 h-3 opacity-40" />
                  <span>{new Date(log.createdAt).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}</span>
               </div>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}

