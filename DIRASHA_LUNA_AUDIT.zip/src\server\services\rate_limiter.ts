/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Project 5 — Distributed Rate Limiting.
 *
 * Replaces the per-process in-memory fixed-window maps that used to live in
 * server.ts (`rateLimitHit`) and the route modules (`limitHit` in e2ee.ts)
 * with ONE Redis-backed, atomically-incremented counter service shared by
 * every server instance and surviving restarts (keys expire via TTL).
 *
 * Atomicity: each check is a SINGLE Redis EVAL of a tiny Lua script
 * (INCR + PEXPIRE-on-first + compare). Redis executes scripts serially, so
 * there is no read-then-write race — N parallel hits across any number of
 * instances can never exceed the configured limit.
 *
 * Failure semantics (BINDING security directive — a counter-service outage
 * must never silently disable protection):
 *   - `critical` class limits (auth + e2ee crypto surfaces): Redis failure
 *     → FAIL CLOSED (request denied 429) + loud error log.
 *   - `throughput` class limits (enumeration-scrape / upload budgets): Redis
 *     failure → fall back to a per-process local Map + loud warn log
 *     (documented choice: losing Redis must not take down message/storage
 *     throughput; the local Map still bounds a single attacker process).
 *   - Redis NOT CONFIGURED (single-node deployments, dev): local Map for
 *     both classes, with a loud one-time startup warning. This is a
 *     deliberate deployment mode, not a failure.
 *
 * WS event budgets (`consumeEventBudget` in ws_server.ts) intentionally stay
 * in-memory: they are per-connection abuse braking, where a restart reset is
 * acceptable and a distributed counter would add a Redis round-trip to every
 * socket event.
 */

export type RateLimitClass = 'critical' | 'throughput';

export interface RateLimitRule {
  limit: number;
  windowMs: number;
  class: RateLimitClass;
}

/**
 * Central, table-driven limits map. EVERY route limiter routes through a rule
 * name from this table — limit VALUES here are verbatim copies of the values
 * that were tuned separately (do not change them in this task).
 */
export const RATE_LIMIT_RULES = {
  /* ── Auth (critical: credential surfaces) ── */
  'auth:register:ip':           { limit: 10,  windowMs: 60 * 60 * 1000,  class: 'critical' },   // register: 10/hour/IP
  'auth:login:ip':              { limit: 30,  windowMs: 10 * 60 * 1000,  class: 'critical' },   // login: 30/10min/IP
  'auth:recover:ip':            { limit: 8,   windowMs: 60 * 60 * 1000,  class: 'critical' },   // recover request: 8/hour/IP
  'auth:recover:user':          { limit: 5,   windowMs: 30 * 60 * 1000,  class: 'critical' },   // recover request: 5/30min/user
  'auth:passwordchange:user':   { limit: 5,   windowMs: 60 * 60 * 1000,  class: 'critical' },   // password change: 5/hour/user
  // BATCH-6 (F-5): dedicated budget for recover/reset — sharing
  // 'auth:recover:ip' with recover/request let an attacker pre-fill the IP
  // budget and grief the reset flow of users behind the same NAT.
  'auth:recover:reset:ip':        { limit: 15,  windowMs: 60 * 60 * 1000,  class: 'throughput' },
  'auth:pin:change':            { limit: 5,   windowMs: 10 * 60 * 1000,  class: 'critical' },   // pin change: 5/10min per user+IP (AUTH-06: scrypt brute-force guard)
  'auth:sessions:revoke':       { limit: 10,  windowMs: 60 * 60 * 1000,  class: 'critical' },   // single-session revoke: 10/hour/user
  'auth:sessions:revoke-others':{ limit: 5,   windowMs: 60 * 60 * 1000,  class: 'critical' },   // bulk revoke: 5/hour/user
  'passkeys:register-verify':   { limit: 10,  windowMs: 60 * 60 * 1000,  class: 'critical' },   // passkey registration options+verify: 10/hour/user
  'passkeys:login-verify':      { limit: 20,  windowMs: 60 * 60 * 1000,  class: 'critical' },   // passkey login verify: 20/hour per username+IP
  'passkeys:login-options':     { limit: 30,  windowMs: 60 * 1000,       class: 'critical' },   // passkey login options: 30/min per username

  /* ── E2EE (critical: key-cryptography surfaces; prekeys/bundlepeer guard
        OPK draining just like register/bundle) ── */
  'e2ee:register':              { limit: 30,  windowMs: 60 * 60 * 1000,  class: 'critical' },   // register: 30/hour/user (multi-device + rekeys headroom)
  'e2ee:bundle':                { limit: 120, windowMs: 60 * 60 * 1000,  class: 'critical' },   // bundle: 120/hour/user (group sender-key bursts headroom)
  'e2ee:prekeys':               { limit: 10,  windowMs: 60 * 60 * 1000,  class: 'critical' },   // prekeys: 10/hour/user
  'e2ee:bundlepeer':            { limit: 10,  windowMs: 10 * 60 * 1000,  class: 'critical' },   // per-target cooldown: 10/10min requester→target
  'export:data:user':           { limit: 5,   windowMs: 60 * 60 * 1000,  class: 'critical' },   // data export: 5/hour/user (heavy cross-table privacy export — abuse/DoS budget)

  /* ── Throughput (enumeration / upload budgets) ── */
  'auth:sessions:list':         { limit: 30,  windowMs: 60 * 1000,       class: 'throughput' }, // sessions list: 30/min/user (panel auto-refresh)
  'username:change':            { limit: 3,   windowMs: 60 * 60 * 1000,  class: 'throughput' }, // username change: 3/hour/user
  'search:user':                { limit: 60,  windowMs: 60 * 1000,       class: 'throughput' }, // directory search: 60/min/user
  'users:directory:list':       { limit: 30,  windowMs: 60 * 1000,       class: 'throughput' }, // GET /api/users directory list: 30/min/user (scrape budget)
  'storage:presign':            { limit: 60,  windowMs: 60 * 60 * 1000,  class: 'throughput' }, // upload presign: 60/hour/user
  'gdrive:share':               { limit: 30,  windowMs: 10 * 60 * 1000,  class: 'throughput' }, // gdrive share: 30/10min/user
  'storage:gdrive-ticket':      { limit: 30,  windowMs: 10 * 60 * 1000,  class: 'throughput' }, // gdrive upload ticket: 30/10min/user
  'e2ee:identity':              { limit: 60,  windowMs: 60 * 60 * 1000,  class: 'throughput' }, // identity fetch: 60/hour/user
  'e2ee:status':                { limit: 30,  windowMs: 60 * 1000,       class: 'throughput' }, // status: 30/min/user
} as const satisfies Record<string, RateLimitRule>;

export type RateLimitRuleName = keyof typeof RATE_LIMIT_RULES;

/**
 * Atomic fixed-window script: INCR the bucket, set TTL only on the first
 * hit of the window, deny once the count exceeds the limit.
 * KEYS[1] = bucket key, ARGV[1] = window TTL ms, ARGV[2] = limit.
 * Returns 1 (rate-limited) or 0 (allowed).
 */
export const RATE_LIMIT_LUA = `
local c = redis.call('INCR', KEYS[1])
if c == 1 then
  redis.call('PEXPIRE', KEYS[1], ARGV[1])
end
if c > tonumber(ARGV[2]) then
  return 1
end
return 0
`;

/** Minimal Redis surface the limiter needs (implemented by redisCluster). */
export interface RateLimitRedisAdapter {
  /** Runs the script atomically; resolves null when Redis is unreachable. */
  evalAtomic(script: string, keys: string[], args: (string | number)[]): Promise<string | null>;
  /** True when Redis was configured via env (REDIS_URL / REDIS_HOST). */
  getIsConfigured(): boolean;
  getIsConnected(): boolean;
}

interface LocalBucket { count: number; resetAt: number }

/**
 * Distributed, table-driven rate limiter.
 * `check(rule, key)` returns true = RATE LIMITED (deny), false = allowed.
 */
export class DistributedRateLimiter {
  private localBuckets = new Map<string, LocalBucket>();
  private lastFallbackLogAt = 0;
  private configuredWithoutRedisWarned = false;
  private gcTimer: NodeJS.Timeout;

  constructor(private redis: RateLimitRedisAdapter) {
    if (!redis.getIsConfigured()) {
      console.warn(
        '[RateLimiter] REDIS_URL/REDIS_HOST not configured — rate limiting runs on the ' +
        'per-process local Map (single-node mode). Counters reset on restart and are NOT ' +
        'shared across instances. Configure Redis for distributed enforcement.',
      );
      this.configuredWithoutRedisWarned = true;
    }
    // Sweep expired local buckets (last-resort fallback cache only).
    this.gcTimer = setInterval(() => {
      const now = Date.now();
      for (const [k, v] of this.localBuckets) if (v.resetAt < now) this.localBuckets.delete(k);
    }, 60_000);
    this.gcTimer.unref();
  }

  dispose(): void {
    clearInterval(this.gcTimer);
  }

  /** Loud, throttled failure logging (never silent, but capped to one line/10s). */
  private logFallback(level: 'error' | 'warn', message: string): void {
    const now = Date.now();
    if (now - this.lastFallbackLogAt < 10_000) return;
    this.lastFallbackLogAt = now;
    if (level === 'error') console.error(message);
    else console.warn(message);
  }

  private redisKey(rule: RateLimitRuleName, key: string): string {
    return `rl:v1:${rule}:${key}`;
  }

  /**
   * Single atomic check against Redis. Resolves:
   *   'allowed' | 'limited' on a successful EVAL, or null when Redis is
   *   unreachable (caller applies failure semantics per rule class).
   */
  private async atomicCheck(rule: RateLimitRuleName, key: string): Promise<'allowed' | 'limited' | null> {
    const cfg = RATE_LIMIT_RULES[rule];
    try {
      const result = await this.redis.evalAtomic(
        RATE_LIMIT_LUA,
        [this.redisKey(rule, key)],
        [cfg.windowMs, cfg.limit],
      );
      if (result === null) return null;
      return result === '1' ? 'limited' : 'allowed';
    } catch {
      return null;
    }
  }

  /**
   * Last-resort per-process fixed window (mirrors the legacy in-memory impl).
   *
   * SHARED-LIMITER HONESTY (residual-risk disclosure): this path is IN-MEMORY
   * PER-INSTANCE. It is used in exactly two modes —
   *   (a) deliberate single-node deployments (no REDIS_URL/REDIS_HOST), and
   *   (b) `throughput`-class rules during a Redis outage (fail-open choice).
   * In both modes a multi-instance deployment gets a SEPARATE budget per
   * instance, so the effective limit is `limit × instance-count` per key
   * (counters also reset on instance restart). `critical` rules such as
   * 'auth:pin:change' do NOT degrade to this path — they FAIL CLOSED on
   * outage. No Redis → run ONE instance or accept the multiplied budget;
   * a durable shared counter would require a Redis/DB-backed store (see the
   * module header for the deliberate non-goal of adding that dependency here).
   */
  private localCheck(rule: RateLimitRuleName, key: string): boolean {
    const cfg = RATE_LIMIT_RULES[rule];
    const k = this.redisKey(rule, key);
    const now = Date.now();
    const bucket = this.localBuckets.get(k);
    if (!bucket || bucket.resetAt < now) {
      this.localBuckets.set(k, { count: 1, resetAt: now + cfg.windowMs });
      return false; // within limit
    }
    bucket.count++;
    return bucket.count > cfg.limit; // true = rate limited
  }

  /**
   * Route the rule through the central table.
   * true = rate limited (deny). The failure class of the rule decides the
   * outage behavior (fail-closed vs local-Map fallback) — never silent.
   */
  async check(rule: RateLimitRuleName, key: string): Promise<boolean> {
    const cfg = RATE_LIMIT_RULES[rule];

    // Deliberate single-node mode (no Redis configured): local Map for both
    // classes. Warned loudly once at construction, not per-request.
    if (!this.redis.getIsConfigured()) {
      return this.localCheck(rule, key);
    }

    const result = await this.atomicCheck(rule, key);
    if (result !== null) return result === 'limited';

    // Redis configured but unreachable — counter-service FAILURE.
    if (cfg.class === 'critical') {
      // FAIL CLOSED: a critical limit must never be silently disabled by an
      // outage. Denying login/register/e2ee crypto surfaces for the outage
      // window is the safe side of the tradeoff.
      this.logFallback(
        'error',
        `[RateLimiter] REDIS UNAVAILABLE — FAIL CLOSED: denying '${rule}' for key ${key} ` +
        `(critical limit; Redis outage must not disable protection).`,
      );
      return true;
    }
    // Throughput class: documented choice — degrade to the per-process local
    // Map so message/storage throughput survives an outage, while still
    // bounding a single attacker process. Loudly logged, never silent.
    this.logFallback(
      'warn',
      `[RateLimiter] REDIS UNAVAILABLE — degrading '${rule}' to the per-process local Map ` +
      `(throughput limit; counters are per-instance until Redis recovers).`,
    );
    return this.localCheck(rule, key);
  }

  /** Test/ops introspection: number of live local fallback buckets. */
  localBucketCount(): number {
    return this.localBuckets.size;
  }
}
