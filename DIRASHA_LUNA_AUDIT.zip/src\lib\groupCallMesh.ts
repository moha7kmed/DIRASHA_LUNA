/**
 * GroupCallMesh — client-side full-mesh WebRTC manager (framework-agnostic)
 * --------------------------------------------------------------------------
 * One RTCPeerConnection PER other participant (N-1 PCs for N callers, ≤4).
 *
 * Signaling transport: the caller supplies `sendSignal`, typically wrapping
 * the dedicated `groupcall:signal` WS relay (src/server/websocket/ws_server.ts →
 * handleGroupCallSignal), which authorizes against the in-memory
 * groupCallSessions registry and relays to the target participant. Payload
 * shape on the wire:
 *
 *   ws.send(JSON.stringify({
 *     event: 'groupcall:signal',
 *     payload: {
 *       groupCallId,
 *       receiverId: toUserId,     // one specific peer per message
 *       signal: GroupCallSignal,  // opaque, routed by handleSignal() below
 *     },
 *   }))
 *
 * Incoming `groupcall:signal` events are fed to
 * mesh.handleSignal(payload.senderId, payload.signal). Presence is handled
 * via `groupcall:joined` / `groupcall:leave` client events which the server
 * broadcasts as `groupcall:peer-joined` / `groupcall:peer-left`; peers
 * announced that way are dialed through addPeer().
 *
 * Perfect negotiation is NOT implemented in v1. A simple polite/impolite
 * split avoids offer glare: in each pair, the peer with the lexicographically
 * SMALLER userId is the impolite offerer; the larger id is polite and only
 * answers. No rollback, no renegotiation after connection is established.
 */

export type GroupCallSignal =
  | { kind: 'offer'; description: RTCSessionDescriptionInit }
  | { kind: 'answer'; description: RTCSessionDescriptionInit }
  | { kind: 'candidate'; candidate: RTCIceCandidateInit };

export interface GroupCallMeshCallbacks {
  /** Remote MediaStream arrived (or was replaced) for a peer. */
  onTrack?: (peerId: string, stream: MediaStream) => void;
  /** A peer's PC reached 'connected'. */
  onParticipantConnected?: (peerId: string) => void;
  /** A peer's PC failed/disconnected permanently, or the peer hung up. */
  onParticipantLeft?: (peerId: string) => void;
  /** Non-fatal mesh error (logged; the mesh stays up for other peers). */
  onError?: (peerId: string | null, error: unknown) => void;
}

export interface JoinOptions {
  groupCallId: string;
  myId: string;
  /** Roster returned by POST /api/group-calls/:id/join (includes me — it is skipped). */
  participants: string[];
  /** Local mic/cam stream (already acquired by the caller via getUserMedia). */
  getUserMediaStream: () => MediaStream | Promise<MediaStream>;
  /** Transport: send a WebRTC signal to one peer via the call:signal relay. */
  sendSignal: (groupCallId: string, toUserId: string, signal: GroupCallSignal) => void;
  iceServers?: RTCIceServer[];
  /** 'relay' forces TURN-only (IP-hiding) — mirrors the 1:1 callRelayEnabled policy. */
  iceTransportPolicy?: RTCIceTransportPolicy;
  callbacks?: GroupCallMeshCallbacks;
}

interface PeerEntry {
  pc: RTCPeerConnection;
  polite: boolean;
  stream: MediaStream | null;
  /** Candidates that arrived before setRemoteDescription() was possible. */
  pendingCandidates: RTCIceCandidateInit[];
}

export class GroupCallMesh {
  private groupCallId = '';
  private myId = '';
  private peers = new Map<string, PeerEntry>();
  private _localStream: MediaStream | null = null;
  private sendSignal: JoinOptions['sendSignal'] | null = null;
  private callbacks: GroupCallMeshCallbacks = {};
  private iceServers: RTCIceServer[] = [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ];
  private iceTransportPolicy: RTCIceTransportPolicy = 'all';
  private left = new Set<string>();
  /** Signals that arrived before join() finished wiring the mesh. */
  private pendingSignals: Array<{ fromUserId: string; signal: GroupCallSignal }> = [];
  /** addPeer() requests for peers announced while join() was still acquiring media. */
  private pendingAddPeers: string[] = [];
  /** Camera video track from the local stream — kept so screen sharing can be undone. */
  private cameraVideoTrack: MediaStreamTrack | null = null;
  /** Active screen-share track being sent instead of the camera (null = camera). */
  private screenVideoTrack: MediaStreamTrack | null = null;

  /** The screen track currently replacing the camera in every video sender (null = camera). */
  get screenShareTrack(): MediaStreamTrack | null {
    return this.screenVideoTrack;
  }

  /**
   * Swap what every peer's video sender transmits: pass the screen
   * `MediaStreamTrack` to start sharing, or `null` to restore the camera.
   * Uses sender.replaceTrack() only — same m-line, no renegotiation needed
   * (the mesh performs none after the initial offer/answer).
   * The camera track reference is retained internally so restoration works
   * even after multiple share cycles.
   */
  async setScreenShare(track: MediaStreamTrack | null): Promise<void> {
    if (track) {
      if (track.kind !== 'video') {
        throw new Error('setScreenShare expects a video MediaStreamTrack');
      }
      // Never push an ended track into a sender — it black-screens the peers.
      if (track.readyState !== 'live') {
        throw new Error('Cannot share a screen track that is not live');
      }
      this.screenVideoTrack = track;
    } else {
      this.screenVideoTrack = null;
    }

    const outgoing = track ?? this.cameraVideoTrack;
    const replaces: Array<Promise<void>> = [];
    for (const entry of this.peers.values()) {
      const sender = entry.pc.getSenders().find(s => s.track?.kind === 'video');
      if (sender && outgoing && outgoing.readyState === 'live') {
        replaces.push(
          sender.replaceTrack(outgoing).catch(err => {
            this.callbacks.onError?.(null, err);
          })
        );
      }
    }
    await Promise.all(replaces);
  }

  /** ids of peers this mesh currently holds PCs for. */
  get participants(): string[] {
    return Array.from(this.peers.keys());
  }

  get selfId(): string {
    return this.myId;
  }

  get localStream(): MediaStream | null {
    return this._localStream;
  }

  /** Dial every participant. Impolite (smaller id) peers fire offers immediately. */
  async join(opts: JoinOptions): Promise<void> {
    // Reset any stale mesh state so a reused instance starts clean.
    this.leave();
    this.groupCallId = opts.groupCallId;
    this.myId = opts.myId;
    this.sendSignal = opts.sendSignal;
    this.callbacks = opts.callbacks || {};
    if (opts.iceServers && opts.iceServers.length) this.iceServers = opts.iceServers;
    this.iceTransportPolicy = opts.iceTransportPolicy || 'all';

    this._localStream = await opts.getUserMediaStream();
    // Remember the camera track so setScreenShare(null) can restore it later.
    this.cameraVideoTrack = this._localStream.getVideoTracks()[0] || null;

    for (const peerId of opts.participants) {
      if (peerId === this.myId) continue;
      this.ensurePeer(peerId);
    }

    // Impolite side (smaller userId) creates the offer; polite side waits.
    for (const [peerId, entry] of this.peers) {
      if (!entry.polite) {
        try {
          await this.makeOffer(peerId, entry);
        } catch (err) {
          this.callbacks.onError?.(peerId, err);
        }
      }
    }

    // Replay anything that arrived while media acquisition was in flight:
    // dropping these strands a polite peer waiting for an offer forever.
    const bufferedSignals = this.pendingSignals.splice(0, this.pendingSignals.length);
    for (const { fromUserId, signal } of bufferedSignals) {
      await this.handleSignal(fromUserId, signal);
    }
    const bufferedPeers = this.pendingAddPeers.splice(0, this.pendingAddPeers.length);
    for (const peerId of bufferedPeers) {
      if (peerId !== this.myId && !this.peers.has(peerId)) {
        await this.addPeer(peerId);
      }
    }
  }

  /**
   * Feed a signal received from the call:signal relay.
   * Safe to call for unknown senders: a PC is created lazily (handles
   * late joiners / races where the roster was stale).
   */
  async handleSignal(fromUserId: string, signal: GroupCallSignal): Promise<void> {
    if (!this.groupCallId) {
      // Mesh not wired yet — buffer instead of dropping (replayed after join()).
      this.pendingSignals.push({ fromUserId, signal });
      if (this.pendingSignals.length > 100) this.pendingSignals.shift();
      return;
    }
    if (fromUserId === this.myId) return;
    if (this.left.has(fromUserId)) return; // peer already hung up — drop stragglers
    const entry = this.peers.get(fromUserId) ?? this.ensurePeer(fromUserId);

    try {
      switch (signal.kind) {
        case 'offer': {
          await entry.pc.setRemoteDescription(signal.description);
          this.flushPendingCandidates(entry);
          const answer = await entry.pc.createAnswer();
          await entry.pc.setLocalDescription(answer);
          this.sendSignal?.(this.groupCallId, fromUserId, {
            kind: 'answer',
            description: { type: answer.type, sdp: answer.sdp },
          });
          break;
        }
        case 'answer': {
          // v1: ignore answers in states where setRemoteDescription is illegal
          // (no glare handling — the polite/impolite split prevents overlap).
          if (entry.pc.signalingState === 'have-local-offer') {
            await entry.pc.setRemoteDescription(signal.description);
            this.flushPendingCandidates(entry);
          }
          break;
        }
        case 'candidate': {
          if (signal.candidate) {
            // Trickle race: candidates may arrive before the remote description
            // is installed — addIceCandidate would throw and lose the candidate.
            if (entry.pc.remoteDescription) {
              await entry.pc.addIceCandidate(signal.candidate);
            } else {
              entry.pendingCandidates.push(signal.candidate);
            }
          }
          break;
        }
      }
    } catch (err) {
      this.callbacks.onError?.(fromUserId, err);
    }
  }

  /**
   * Dial a peer that was NOT in the join roster (late joiner announced via
   * the groupcall:peer-joined presence broadcast). Impolite peers offer
   * immediately; polite peers wait for the incoming offer.
   */
  async addPeer(peerId: string): Promise<void> {
    if (!this.groupCallId) {
      // join() still in flight — queue so the late joiner is not lost.
      if (peerId && !this.pendingAddPeers.includes(peerId)) this.pendingAddPeers.push(peerId);
      return;
    }
    if (peerId === this.myId || this.left.has(peerId)) return;
    if (this.peers.has(peerId)) return;
    const entry = this.ensurePeer(peerId);
    if (!entry.polite) {
      try {
        await this.makeOffer(peerId, entry);
      } catch (err) {
        this.callbacks.onError?.(peerId, err);
      }
    }
  }

  /** Notify the mesh that a peer said goodbye (call:end / call:leave relay). */
  handlePeerLeft(peerId: string): void {
    this.closePeer(peerId);
    this.left.add(peerId);
    this.callbacks.onParticipantLeft?.(peerId);
  }

  /** Close every PC and drop the local stream reference (does NOT stop tracks). */
  leave(): void {
    for (const peerId of Array.from(this.peers.keys())) {
      this.closePeer(peerId);
    }
    this._localStream = null;
    this.cameraVideoTrack = null;
    this.screenVideoTrack = null;
    this.sendSignal = null;
    this.left.clear();
    this.pendingSignals = [];
    this.pendingAddPeers = [];
  }

  /* ------------------------------ internals ------------------------------ */

  private ensurePeer(peerId: string): PeerEntry {
    let entry = this.peers.get(peerId);
    if (entry) return entry;

    const polite = this.myId > peerId; // smaller id → impolite offerer
    const pc = new RTCPeerConnection({
      iceServers: this.iceServers,
      iceTransportPolicy: this.iceTransportPolicy,
    });
    entry = { pc, polite, stream: null, pendingCandidates: [] };
    this.peers.set(peerId, entry);

    if (this._localStream) {
      for (const track of this._localStream.getTracks()) {
        pc.addTrack(track, this._localStream);
      }
      // A screen share started before this PC existed (late joiner / replayed
      // signal): apply the current sharing state to the fresh video sender.
      if (this.screenVideoTrack && this.screenVideoTrack.readyState === 'live') {
        const sender = pc.getSenders().find(s => s.track?.kind === 'video');
        if (sender) {
          sender.replaceTrack(this.screenVideoTrack).catch(err => {
            this.callbacks.onError?.(peerId, err);
          });
        }
      }
    }

    pc.onicecandidate = (ev) => {
      if (ev.candidate) {
        this.sendSignal?.(this.groupCallId, peerId, {
          kind: 'candidate',
          candidate: ev.candidate.toJSON(),
        });
      }
    };

    pc.ontrack = (ev) => {
      const stream = ev.streams[0] || new MediaStream([ev.track]);
      entry!.stream = stream;
      this.callbacks.onTrack?.(peerId, stream);
    };

    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'connected') {
        this.callbacks.onParticipantConnected?.(peerId);
      } else if (pc.connectionState === 'failed' && !this.left.has(peerId)) {
        this.left.add(peerId);
        this.callbacks.onParticipantLeft?.(peerId);
      }
      // 'disconnected' alone is transient — v1 waits for 'failed'.
    };

    return entry;
  }

  private async makeOffer(peerId: string, entry: PeerEntry): Promise<void> {
    const offer = await entry.pc.createOffer();
    await entry.pc.setLocalDescription(offer);
    this.sendSignal?.(this.groupCallId, peerId, {
      kind: 'offer',
      description: { type: offer.type, sdp: offer.sdp },
    });
  }

  private closePeer(peerId: string): void {
    const entry = this.peers.get(peerId);
    if (!entry) return;
    try {
      entry.pc.onicecandidate = null;
      entry.pc.ontrack = null;
      entry.pc.onconnectionstatechange = null;
      entry.pc.close();
    } catch {
      /* already closed */
    }
    this.peers.delete(peerId);
  }

  /** Replay candidates buffered before the remote description was installed. */
  private flushPendingCandidates(entry: PeerEntry): void {
    while (entry.pendingCandidates.length) {
      const candidate = entry.pendingCandidates.shift();
      if (!candidate) continue;
      entry.pc.addIceCandidate(candidate).catch((err) => {
        this.callbacks.onError?.(null, err);
      });
    }
  }
}
