# DATA_FLOW.md — جرد البيانات وخريطة تدفقها (Data Inventory & Data-Flow Audit)

> **نطاق هذا المستند:** تدقيق خصوصية/بيانات للنظام Dirasha — جرد كامل للبيانات + خريطة تدفق، **وليس** مراجعة تشفير (crypto يغطيها مستند منفصل).
>
> **تصنيف كل عبارة:**
> - `VERIFIED` — تم التحقق منها بالقراءة المباشرة من الكود مع ذكر `file:line`.
> - `PARTIALLY VERIFIED` — الجزء المؤكد مذكور، والباقي مبني على استنتاج من الكود دون مسار تنفيذ كامل.
> - `UNVERIFIED` — لم يُعثر على دليل في الكود؛ تُذكر كفجوة معلنة.
>
> **قواعد هذا التدقيق:** قراءة فقط؛ لا قيم أسرار في هذا الملف (أسماء مفاتيح الإعدادات فقط + الغرض). تاريخ التدقيق: 2026-11-17.

---

## 1) جرد البيانات (DATA INVENTORY)

### 1.1 بيانات الحساب (Account Data)

| البيان | سبب الجمع | مكان التخزين | من يصل إليه | التشفير | الاستبقاء | مسار الحذف | مسار التصدير | التصنيف |
|---|---|---|---|---|---|---|---|---|
| username, display_name, bio, avatar/banner URLs, role, ban/mute metadata | الهوية والعرض والإشراف | جدول `users` | الخادم، المشرِّفون، بقية المستخدمين (حسب إعدادات الخصوصية) | لا — نص صريح (metadata غير حساسة) | إلى حين حذف الحساب | `DELETE /api/users/me` → `db.deleteUser` | لا يوجد API تصدير | VERIFIED (database.ts:1898-1927, server.ts:1143-1156, database.ts:4880-4890) |
| password_hash, pin_hash, device_key_hash | مصادقة كلمة المرور/PIN | أعمدة في `users` | الخادم فقط | Hash+pepper (تخزين بصيغة hash — التفاصيل في مستند crypto) | حتى التغيير/الحذف | حذف الحساب (CASCADE) | لا يوجد | VERIFIED (database.ts:1951-1953) |
| reset_token_hash + reset_token_expires | استعادة كلمة المرور | أعمدة في `users` | الخادم فقط | hash فقط | حتى الاستخدام أو الاستبدال | تُصفَّر بعد الاستخدام (`reset_token_hash=NULL`) | — | VERIFIED (database.ts:2570-2610) |
| totp_secret, totp_last_counter, totp_backup_hashes | 2FA (TOTP) | أعمدة في `users` | الخادم فقط | `totp_secret` يُفك/يُشفَّر عبر snapshot-encryption helper عند الاستخدام (`decryptSnapshot`) — التفاصيل في مسار auth | حتى إزالة 2FA/حذف الحساب | حذف الحساب (CASCADE) | لا يوجد | PARTIALLY VERIFIED (database.ts:1958-1960؛ routes/authClassic.ts:289-318 — التشفير at-rest للعمود نفسه لم يُراجع هنا) |
| 2FA backup codes | استرداد 2FA | `users.totp_backup_hashes` | الخادم فقط | hashes | حتى الاستهلاك | حذف الحساب | لا يوجد | VERIFIED (routes/authClassic.ts:307-314) |
| WebAuthn credentials (credential_id, COSE public_key, counter, transports, device_type) | تسجيل دخول بالـ passkeys | جدول `webauthn_credentials` | الخادم فقط | مفاتيح عامة فقط — لا أسرار | حتى حذفها/حذف الحساب | CASCADE مع `users` | لا يوجد | VERIFIED (database.ts:1302-1313؛ routes/passkeys.ts) |

### 1.2 مفاتيح E2EE والشفافية (E2EE Keys & Key Transparency)

| البيان | سبب الجمع | مكان التخزين | من يصل إليه | التشفير | الاستبقاء | مسار الحذف | التصنيف |
|---|---|---|---|---|---|---|---|
| E2EE public keys (identity DH + signing + signed prekey + توقيعه + PQ prekey ML-KEM-768 + توقيعه) | دليل مفاتيح عام فقط (dumb key directory) | `e2ee_registrations` + `e2ee_device_registrations` | أي مستخدم يطلب bundle لأي نظير | مفاتيح **عامة** — لا تحتاج تشفيرًا | حتى إعادة التسجيل | CASCADE مع `users` | VERIFIED (database.ts:1233-1251, 1267-1289, 1329-1330؛ routes/e2ee.ts:1-16) |
| One-time prekeys (public) | تفاوض X3DH/PQXDH | `e2ee_one_time_prekeys` + `e2ee_device_one_time_prekeys` | الخادم يستهلكها ذرّيًا (ONE per bundle fetch) | عامة | تُستهلك (consumed=true) وتبقى الصفوف | CASCADE مع `users` | VERIFIED (database.ts:1241-1251, 1277-1289) |
| المفاتيح الخاصة (private keys/sessions) | — | **لا تصل الخادم إطلاقًا** — IndexedDB محليًا: `dirasha-e2ee` مع تغليف KEK من `dirasha-vault` | الجهاز فقط | كل قيمة AES-GCM بمفتاح KEK غير قابل للاستخراج (non-extractable) | حتى مسح المتصفح | حذف IndexedDB / تسجيل خروج | VERIFIED (src/lib/e2ee/store.ts:14-16؛ vault.ts:15-33, 95-101) |
| KT log commitments (user_id + sha256 commitment + tree_version + prev_user_hash) | Key Transparency — كشف التلاعب بالمفاتيح | `kt_log` (append-only بلا FK عمدًا) | الخادم + تحقق العملاء | commitments (derivatives عامة) | **الأبدية بالتصميم** — حذفها يكسر سلاسل الاتساق (consistency proofs) | لا يوجد — مقصود | VERIFIED (database.ts:1336-1358) |
| kt_snapshots (root_hash + Ed25519 signature) | Checkpoints موقّعة لسجل KT | `kt_snapshots` | العملاء للتحقق | توقيعات عامة | أبدية | لا يوجد — مقصود | VERIFIED (database.ts:1360-1370) |
| kt_mismatch_reports (reporter, subject, expected/observed root, detail) | بلاغات فشل تحقق KT من العملاء | `kt_mismatch_reports` | المشرِّفون | نص صريح | **لا يوجد pruning** — استبقاء غير محدود | لا يوجد | VERIFIED (database.ts:1372-1384 — وغياب أي حذف) |

### 1.3 الرسائل (Messages)

| البيان | سبب الجمع | مكان التخزين | من يصل إليه | التشفير | الاستبقاء | مسار الحذف | التصنيف |
|---|---|---|---|---|---|---|---|
| محتوى الرسالة — **نص مشفّر** (بادئات `DIR1:`/`DIRM1:`/`DIRG1:`) | المراسلة E2EE في 1:1 والمجموعات المؤهلة | `messages.content` | الخادم يعاملها opaque؛ المستقبِل يفكها محليًا | E2EE client-side (تُشفَّر قبل الإرسال) | غير محدود افتراضيًا؛ أو expires_at (disappearing) | حذف للجميع / disappearing / حذف الحساب (CASCADE على sender) | VERIFIED (App.tsx:4686-4827؛ ws_server.ts:753-765؛ database.ts:2020-2033) |
| محتوى الرسالة — **نص صريح (plaintext)** للقنوات (`type='channel'`) وللـ DMs غير المؤهلة E2EE (نظير بلا bundle → fallback صريح متعمد) | المراسلة في القنوات + التوافق الرجعي | `messages.content` | الخادم يقرأ فعليًا: @mention parsing + dedup matching | **لا يوجد** | غير محدود | نفس ما سبق | VERIFIED (App.tsx:1608-1612 groups-only؛ App.tsx:4818-4820 plaintext fallback؛ ws_server.ts:874-882, 813-816) |
| Metadata الرسائل: sender_id, sender_name, chat_id, timestamps, reply_to_id, client_message_id, type, deleted_for, poll, scheduled_at | العرض والترتيب والفرز | `messages` | الخادم + أعضاء الشات | لا (metadata) | غير محدود | مع الرسالة/الشات/الحساب | VERIFIED (database.ts:2020-2033, 1146, 1193-1194) |
| Read receipts / delivery state | حالة القراءة | `message_reads` | الخادم | لا | **180 يومًا** — prune مجدول | prune تلقائي | VERIFIED (database.ts:5206-5241؛ moderation_jobs.ts:159-170) |
| Reactions, pins, stars | تفاعلات | `message_reactions`, `message_pins`, `message_stars` | الخادم | لا | غير محدود | CASCADE مع الرسالة/الحساب | VERIFIED (database.ts:2045-2076) |
| Search index على المحتوى | البحث داخل الشات | فهرس `idx_messages_content_prefix` (left(content,32)) + pg_trgm GIN (best-effort) | الخادم | فهرس على النص المخزن (ciphertext أو plaintext حسب النوع) | مع الرسالة | مع الرسالة | VERIFIED (database.ts:1152-1157, 1392-1401, 5279-5295) |

### 1.4 المرفقات والوسائط (Attachments/Media)

| البيان | سبب الجمع | مكان التخزين | من يصل إليه | التشفير | الاستبقاء | مسار الحذف | التصنيف |
|---|---|---|---|---|---|---|---|
| Blobs مشفّرة `enc.bin` (octet-stream) | وسائط E2EE | Google Drive للمستخدم (folder `Dirasha Media`) أو S3-compatible | أي حامل الرابط (share anyone-with-link) | مشفّرة client-side قبل الرفع | **الأبدية عمليًا** — التطبيق لا يحذف ملفات Drive إطلاقًا | لا يوجد حذف آلي | VERIFIED (App.tsx:4749-4762؛ gdrive.ts:228-256؛ لا يوجد endpoint حذف ملفات — routes/storage.ts كاملًا) |
| **⚠️ نسخة plaintext أصلية للمرفق (بالأصل original filename) تُرفع أولًا** | رفع الوسائط من ChatWindow قبل لف E2EE | Drive المستخدم / managed S3 fallback | Drive: أي حامل رابط؛ S3: مشغّل الخدمة | **لا** — تُرفع الصوت/الملف/الصورة كـ plaintext قبل أن يشفّرها لف E2EE ويعيد رفعها كـ `enc.bin` | الأبدية (نسخة يتيمة orphaned) | لا يوجد | VERIFIED (ChatWindow.tsx:1639-1656 صوت؛ :1961-1968 ملفات بالاسم الأصلي؛ :2172, :2308, :4068 صور؛ App.tsx:4732-4741 يجلب الـ plaintext ويعيد تشفيره) |
| Metadata المرفقات: name, size, mime_type, url | عرض وتحميل | `attachments` (+ meta JSONB) | الخادم + أعضاء الشات | لا (metadata؛ الاسم على السلك = `enc.bin` في مسار E2EE) | مع الرسالة | CASCADE مع الرسالة | VERIFIED (database.ts:2035-2043, 1168) |
| بيانات الـ statuses (نص صريح `text_content` + media_url + تعليقات/مشاهدات/إعجابات) | حالات المستخدمين | `statuses`, `status_comments` | كل من يرى الحالة | لا — statuses خارج نطاق E2EE بالتصميم | expires_at (افتراضي 24h) لكن الصفوف تبقى | CASCADE مع الحساب | VERIFIED (database.ts:2092-2103؛ routes/status.ts:55-99, 211-222) |
| بيانات اعتماد التخزين (BYO S3) أو Google refresh token | ربط التخزين الشخصي | `user_storage_accounts.credentials_encrypted` | الخادم فقط | AES-256-GCM بمفتاح مشتق من `STORAGE_MASTER_KEY`/`COOKIE_SECRET` | حتى فك الربط/حذف الحساب | `DELETE /api/storage/link` و `DELETE /api/storage/gdrive` → `deleteUserStorage` + CASCADE | VERIFIED (database.ts:1934-1946, 2731-2736؛ storage.ts:100-125؛ gdrive.ts:259-261؛ routes/storage.ts:195-205, 495-504) |

### 1.5 الجلسات والتوكنات والاشتراكات (Sessions/Tokens/Push)

| البيان | سبب الجمع | مكان التخزين | من يصل إليه | التشفير | الاستبقاء | مسار الحذف | التصنيف |
|---|---|---|---|---|---|---|---|
| Refresh token (hash) + session records + `ip_address` + `user_agent` + last_active | إدارة الجلسات والأجهزة | `user_sessions` | الخادم | refresh مخزّن كـ hash | حتى revocation/انتهاء | revoke endpoints + CASCADE مع الحساب | VERIFIED (database.ts:1975-1985؛ routes/authClassic.ts:347-367) |
| Access token (JWT قصير العمر) | مصادقة API | ذاكرة المتصفح فقط (module memory) — لا localStorage | الجهاز فقط | — (in-memory) | ~15 دقيقة | مسح الذاكرة عند الخروج | VERIFIED (src/lib/token_vault.ts:4-17, 40-56) |
| Refresh token في المتصفح | تجديد الجلسة | HttpOnly cookie `refreshToken` فقط | الخادم عبر cookie | HttpOnly + cookie flags | مدة الجلسة | logout/revoke | VERIFIED (token_vault.ts:4-10) |
| Push subscriptions (endpoint URL + keys) | إشعارات Web Push | `push_subscriptions` | الخادم → مزود الـ push | JSON صريح (endpoint + مفاتيح P-256 للمزود) | حتى فشل الإرسال (410/404/401/403/400 → eviction) أو إلغاء الاشتراك | eviction تلقائي + **لا CASCADE مع الحساب (بلا FK — صفوف يتيمة بعد حذف الحساب!)** | VERIFIED (database.ts:2142-2147 — لا FK؛ push.ts:107-113؛ database.ts:4734) |
| VAPID keys | توقيع إشعارات Web Push | env: `VAPID_PUBLIC_KEY` / `VAPID_PRIVATE_KEY` (إلزامية في production) | الخادم → مزود الـ push | سر env | — | — | VERIFIED (push.ts:10-28) |

### 1.6 سجلات المصادقة والأمان (Auth Logs) — IPs

| البيان | سبب الجمع | مكان التخزين | من يصل إليه | التشفير | الاستبقاء | مسار الحذف | التصنيف |
|---|---|---|---|---|---|---|---|
| **عناوين IP كاملة** (login/login_failed/2fa/recover/register/…) | تنبيهات الدخول الجديد + تدقيق أمني | `auth_logs.ip` (VARCHAR 64) + `metadata` JSON يكرر الـ ip | الخادم + المشرِّفون (غير موجود endpoint عام) | لا | **غير محدود — لا يوجد prune لـ auth_logs** | **لا يوجد** — وبلا FK على `users` فلا يُحذف مع الحساب | VERIFIED (database.ts:1990-1999 بلا FK؛ database.ts:5485-5511 يكتب `meta.ip` خامًا بحد 64 حرفًا؛ routes/authClassic.ts:215, 267, 320, 347, 410 تمرر clientIp كاملًا؛ لا يوجد أي `DELETE FROM auth_logs`) |
| IPs **مقتطعة (24 حرفًا)** في أجسام الإشعارات/WS | تنبيهات أمنية | Push payload + Redis `user:updates:<id>` | المستخدم + **مرحّلات الـ push التابعة لطرف ثالث** | لا | لحظي (إشعار) | — | VERIFIED (securityAlerts.ts:32-41, 70-74, 101-104) |
| user_agent (≤200 حرف) | تمييز الأجهزة | `auth_logs.user_agent` + `user_sessions.user_agent` | الخادم | لا | غير محدود (auth_logs) / مدة الجلسة | لا يوجد لـ auth_logs | VERIFIED (securityAlerts.ts:65؛ routes/authClassic.ts:347-351) |
| سجل baseline آخر 50 دخول ناجح | مقارنة IPs معروفة | يُقرأ من `auth_logs` | الخادم (security alerts engine) | — | — | — | VERIFIED (securityAlerts.ts:36-37, 63-74) |
| سجلات إشراف (moderation audit) | تدقيق قرارات الإشراف | `moderation_audit_logs` (metadata JSONB) | المشرِّفون | لا | **365 يومًا** — prune مجدول كل ساعة | prune تلقائي | VERIFIED (database.ts:5247-5277؛ moderation_jobs.ts:173-180) |

### 1.7 البلاغات (Reports)

| البيان | سبب الجمع | مكان التخزين | من يصل إليه | التشفير | الاستبقاء | مسار الحذف | التصنيف |
|---|---|---|---|---|---|---|---|
| Report: reporter, target_user, target_message_id, category, description (≤500 حرف نص حر) | الإشراف | `reports` | المشرِّفون | لا | **غير محدود — لا يوجد prune** (لا يوجد دليل على أي retention 90 يومًا في الكود) | حذف target_user → CASCADE؛ reporter → SET NULL؛ لا حذف ذاتي | VERIFIED (database.ts:2105-2116؛ server.ts:3033-3136) — **ادعاء "snapshot محتوى 90 يومًا" غير موجود: لا يُخزَّن محتوى الرسالة المبلَّغ عنها إطلاقًا، فقط معرّفها** |
| Deleted Messages Vault (snapshot عند "حذف للجميع": `originalContent`, attachments metadata, deletedBy, deleteReason) | إشراف/تدقيق بعد الحذف | **ذاكرة العملية فقط** `memoryStore.deletedMessagesVault` | المشرِّفون عبر `/api/moderation/vault` (requireModerator) | لا — لكن في مسار E2EE المحتوى المخزّن ciphertext، وفي القنوات/fallback **plaintext** | **⚠️ لا نهائي فعليًا: `cleanupExpiredDeletedMessages()` تعيد 0 دائمًا (no-op) رغم ادعاء الـ 30 يومًا في السجل** | لا يعمل — لا حذف حقيقي؛ وتُفقد عند restart (ليست في الـ snapshot) | VERIFIED (database.ts:231, 5083-5088, 5094-5101؛ server.ts:2899-2912, 3339-3348؛ database.ts:5135-5137 no-op؛ moderation_jobs.ts:83-95 ادعاء مضلل) |

### 1.8 التكاملات الخارجية (Gemini / Drive / AI)

| البيان | الحالة | الدليل | التصنيف |
|---|---|---|---|
| **Google Gemini / AI Assistant** | **محذوف نهائيًا** — `handleGeminiBotMessage` no-op ولا يُرسل أي محتوى مستخدم لأي خدمة AI؛ لا يوجد أي استدعاء `generativelanguage.googleapis.com` | services/gemini.ts:1-19 (سطر 1: "AI Assistant (Nexora) has been permanently removed"); grep عام على `generativelanguage` = لا نتائج خارج الملف | VERIFIED |
| بقايا AI في المخطط | جدول `system_api_keys` (service_name default `'gemini'`) + أعمدة ban مثل `muted_from_ai_until` ما زالت في المخطط بلا مستهلك | database.ts:2078-2090 (service_name), :1926 | VERIFIED |
| Google Drive | راجع قسم 3 (Third-Party Map) | — | VERIFIED |

### 1.9 المخازن المحلية على الجهاز (Client Stores)

| المخزن | المحتوى | تشفير | الدليل | التصنيف |
|---|---|---|---|---|
| IndexedDB `dirasha-e2ee` (store `kv`) | هوية E2EE + prekeys خاصة + session state لكل نظير | نعم — كل قيمة AES-GCM عبر KEK غير قابل للاستخراج من `dirasha-vault` | store.ts:14-16؛ vault.ts:15-33 | VERIFIED |
| IndexedDB `dirasha-vault` (store `keys`) | مفتاح KEK نفسه (CryptoKey object) | غير قابل للاستخراج من المتصفح | vault.ts:42-101 | VERIFIED |
| IndexedDB `dirashaMessagesDB` (store `messages`) | **رسائل مُفكّكة (plaintext) — آخر 150 رسالة لكل شات** ككاش للأداء | **لا — خارج تغليف الـ vault!** سرقة ملف قاعدة البيانات تعطي نص الرسائل | messages_cache_db.ts:4-6, 108 | VERIFIED |
| IndexedDB `dirashaChatsDB` + localStorage `chats_list_<userId>` | قائمة الشاتات + آخر رسالة | لا | chats_cache_db.ts:7-9؛ App.tsx:1494 | VERIFIED |
| IndexedDB `dirashaOutboxDB` (store `outbox`) | رسائل معلقة للإرسال — في مسار E2EE تحمل **ciphertext** (المحتوى يُمسح من acked items)، وفي المسار الصريح plaintext | حسب نوع الشات | outbox_db.ts:18-20؛ App.tsx:2295-2303, 4868-4870 | VERIFIED |
| localStorage `dirasha_user` | بروفايل المستخدم الحالي (لا توكنات) | لا | App.tsx:381, 2758, 2815 | VERIFIED |
| localStorage أعلام E2EE (`e2eeVerified:*`, `e2eeRekey:*`, `e2eeLastSN:*`, `dist:<group>:<peer>`) | حالة التحقق الأمني وتوزيع sender keys | لا (metadata) | App.tsx:1630-1643, 1755-1781 | VERIFIED |
| Service Worker cache `dirasha-pwa-cache-v5` | أصول ثابتة فقط — **API وsocket.io لا تُخزَّن إطلاقًا** | — | service-worker.js:7-12, 47-53, 153-158 | VERIFIED |
| ملف snapshot الخادم `data/local_db_snapshot.json` (وضع memory فقط) | مستخدمون/جلسات/**رسائل**/سجلات + تشفير AES-256-GCM | نعم — مشفّر at-rest؛ وضع PG لا يكتبه | database.ts:13-31, 300-303, 353-357 | VERIFIED |

---

## 2) خريطة تدفق البيانات (DATA FLOW MAP)

### 2.1 رسالة نصية E2EE (1:1 أو مجموعة مؤهلة)

```
 [المستخدم يكتب]
      │  (plaintext موجود لحظيًا في الذاكرة + النسخة المتيمزة UI فقط)
      ▼
 App.tsx:4779/4802 ── تشفير client-side ──►  DIR1:/DIRM1:  أو  DIRG1:  (ciphertext)
      │                                        ▲ نقطة التشفير الوحيدة للمحتوى
      │ outbox IndexedDB يحمل ciphertext (App.tsx:4868-4870)
      ▼
 WebSocket 'message' ──► ws_server.ts:753-765 (cap 24KB للمشفّر / 8KB للصريح)
      │                   :806 dedup key = أول 10 أحرف من المحتوى (تُسجَّل في اللوج!)
      │                   :874-882 @mention regex (no-op على ciphertext)
      ▼
 Redis pub/sub ──► channels: chat:<id> + user:updates:<id>   [payload كامل incl. ciphertext]
      │                                                        (ws_server.ts:953-969)
      ▼
 BackgroundWriteQueue.enqueue ──► queue صامد في Redis بتكرار content
      │                           TTL حتى سنة عند التعطل (write_queue.ts:82-89!)
      ▼
 db.createMessage ──► PostgreSQL (Aiven): messages.content = ciphertext   (write_queue.ts:130-142)
      │
      ├──► Web Push لكل عضو غير المرسل: payload عام فقط
      │    title='ديراشة' body='لديك رسالة جديدة' data={chatId,messageId}
      │    (write_queue.ts:184-190 ← push.ts:56-71) ──► مرحّل FCM/APNs (طرف ثالث — لا محتوى)
      ▼
 المستقبِل: WS push ──► decrypt محلي (e2ee engine) ──► IndexedDB dirashaMessagesDB
      (plaintext مُفكَّك يُخزَّن هنا بلا تشفير vault — messages_cache_db.ts:108)
```

### 2.2 رسالة صريحة (قناة channel / DM fallback)

```
 [المستخدم يكتب] ──► (لا تشفير: القنوات مستبعدة App.tsx:1608-1612؛
                      أو PeerNotRegisteredError → fallback مقصود App.tsx:4818-4820)
      ▼
 WS (ws_server.ts:684+) ──► الخادم يقرأ plaintext فعليًا:
      ├── mention parsing (ws_server.ts:874-882)
      ├── dedup matching m.content === content (ws_server.ts:813-816)
      └── log: أول 10 أحرف في dedupKey (ws_server.ts:806)
      ▼
 Redis (payload plaintext) ──► Aiven PG messages.content = PLAINTEXT
```

### 2.3 مرفق/وسائط (المسار الحرج)

```
 [اختيار ملف/تسجيل صوتي في ChatWindow]
      ▼
 uploadMediaFile(file, file.name)  ◄── ⚠️ الرفع الأول: PLAINTEXT + الاسم الأصلي
      │                                  ChatWindow.tsx:1964 (ملفات), :1643 (صوت), :2172/:2308/:4068 (صور)
      ├──(أ) Google Drive: browser ──HTTP multipart──► googleapis.com
      │        metadata.name = الاسم الأصلي!  (storageUtils.ts:186-196)
      │        access token صادر للـ browser عبر /api/storage/gdrive/upload-ticket
      │        (routes/storage.ts:473-487 — التوكن يعبر إلى العميل)
      └──(ب) S3 presign: browser ──PUT──► مزود S3 (R2/B2/MinIO/AWS)
               object key UUID يولّده الخادم (storage.ts:150-166) — الاسم الأصلي لا يصل للمفتاح
      ▼
 [لف E2EE إن وُجد نظير مؤهل] ──► App.tsx:4732-4741 يجلب الـ plaintext المرفوع مرة أخرى
      │                            ──► encryptAttachment ──► رفع ثانٍ 'enc.bin' (App.tsx:4749-4762)
      │                            ──► السلك يحمّل enc.bin فقط… لكن النسخة plaintext الأولى
      │                                **لا تُحذف من Drive/S3 — orphan دائم**
      ▼
 attachments row في PG (database.ts:2035-2043): name='enc.bin', meta.e2ee=true
      ▼
 التشغيل: /api/media/gdrive proxy يمرر البايتات عبر الخادم (routes/storage.ts:379-404)
      └── للوسائط المشفرة: بايتات ciphertext؛ للوسائط الصريحة (قنوات/statuses): الخادم يرى البايتات
```

### 2.4 تسجيل الدخول (Login)

```
 POST /api/auth/login ──► authClassic.ts:239+ ──► clientIp من x-forwarded-for (authClassic.ts:43-52)
      ├── تحقق password (+pepper) / passkey / TOTP
      ├── logAuthAction('login'|'login_failed'|...) مع ip كامل + user_agent
      │        ──► auth_logs (PG) + memoryStore.auditLogs  (database.ts:5485-5511)
      ├── issueSession ──► user_sessions: refresh_token_hash + ip_address كامل + UA
      │        (database.ts:2850-2870؛ authClassic.ts:347-367)
      ├── SecurityAlerts.notifyNewLogin: مقارنة آخر 50 دخول ناجح (baseline)
      │        ──► Push + WS toast: نص الإشعار يحمل IP مقتطعًا (24 حرفًا)
      │            ──► يعبر إلى مرحّل push (طرف ثالث!)  (securityAlerts.ts:63-83)
      └── الجهاز: access token في الذاكرة + refresh في HttpOnly cookie (token_vault.ts)
```

### 2.5 الحذف

```
 حذف للجميع:  POST /api/messages/:id/delete-everyone (server.ts:2875-2965)
      ├── نسخة إلى deletedMessagesVault (ذاكرة فقط — originalContent)  :2899-2912
      ├── logModerationAction ──► moderation_audit_logs (365d)
      └── UPDATE content='' + deleted_at → لا يوجد hard DELETE للصف
 حذف لي:     deleted_for += userId — المحتوى يبقى كاملًا في DB (server.ts:2968-3010)
 disappearing: sweep كل 5 دقائق → UPDATE content='' + deleted_at (database.ts:3749-3753) — wipe حقيقي للمحتوى
 حذف الحساب: DELETE /api/users/me → CASCADE (رسائل المرسل، جلساته، مفاتيحه، webauthn،
      user_storage_accounts incl. التوكن المشفر)… لكن: auth_logs و push_subscriptions
      و reports (reporter SET NULL) و kt_log تبقى  (database.ts:4880-4890 + مخطط FK)
```

---

## 3) خريطة الأطراف الثالثة (THIRD-PARTY MAP)

| الطرف الثالث | ما الذي يعبر الحدود؟ | بيانات محتوى (content-bearing)؟ | التصنيف |
|---|---|---|---|
| **Aiven (PostgreSQL)** — `DATABASE_URL` | كل الجداول: messages (ciphertext للمشفّر؛ **plaintext للقنوات/DM fallback**)، attachments metadata، users، auth_logs (**IPs كاملة**)، user_sessions (**IP كامل**)، reports، push_subscriptions، e2ee public keys، kt_log | نعم — plaintext ممكن (القنوات + fallback + statuses) | VERIFIED (ws_server.ts:753-765؛ App.tsx:4818-4820؛ database.ts:1990-1999) |
| **Redis** (`REDIS_URL`/`REDIS_HOST` — المزود غير محدد في الكود؛ بدون env يعمل in-memory fallback) | pub/sub `chat:<id>` + `user:updates:<id>` بحمولة msg:new كاملة (ciphertext أو plaintext + sender object)؛ write-queue مع content وTTL **سنة**؛ rate-limit keys؛ pendingStates | نعم — نفس طبيعة المحتوى في PG | VERIFIED (redis_client.ts:50-56, 108؛ ws_server.ts:953-969؛ write_queue.ts:82-89) |
| **Google Drive (OAuth + REST)** | refresh token (مشفر at-rest لدينا) في تبادل OAuth؛ metadata الملف: **name** (`enc.bin` للمرفقات E2EE بعد التشفير، لكن **الاسم الأصلي في الرفع الأول الصريح**)، mimeType، folder `Dirasha Media`؛ upload-ticket يمنح **access token للـ browser** فيرفع مباشرة؛ about.get يعيد **إيميل حساب Google كتلميح** (cached 10 دقائق)؛ البايتات نفسها: ciphertext (`enc.bin`) أو **plaintext** (النسخة الأولى + القنوات) | نعم — البايتات plaintext للنسخة الأولى؛ ومحتوى القنوات الصريح كليًا | VERIFIED (gdrive.ts:39-44, 272, 343-354؛ storageUtils.ts:186-196؛ routes/storage.ts:473-487؛ ChatWindow.tsx:1964) |
| **مرحّلات Web Push (FCM/APNs + مزود browser-push عبر VAPID)** | الحمولة عامة فقط: `title='ديراشة'`, `body='لديك رسالة جديدة'`, `data={chatId, messageId}` — لا محتوى ولا أسماء مرسلين | **لا** — استثناء واحد: تنبيهات الأمان تحمل **IP مقتطعًا (≤24 حرفًا)** في body الإشعار | VERIFIED (push.ts:37-71؛ write_queue.ts:180-190؛ service-worker.js:181-203؛ securityAlerts.ts:70-72) |
| **Google Gemini / أي خدمة AI** | **لا شيء** — الخدمة محذوفة نهائيًا؛ لا يوجد أي مسار يرسل محتوى مستخدم لمزود AI | لا | VERIFIED (gemini.ts:1-19) |
| **مزود S3 الافتراضي/المرتبط** (R2/B2/MinIO/AWS عبر presign) | BYO: حساب المستخدم نفسه؛ managed fallback (`S3_*` env): **bucket المشغّل** — يستقبل الوسائط plaintext (رفع ChatWindow الأول + القنوات) | نعم | VERIFIED (storage.ts:100-147, 218-270) |
| **Render (استضافة)** | يستضيف الخادم؛ logs الخادم قد تحمل أول 10 أحرف من محتوى الرسالة (dedupKey) وأخطاء GDrive مع مقاطع error bodies | ضئيل لكن غير صفري | VERIFIED (ws_server.ts:806؛ gdrive.ts:142-143) |

**خلاصة حدود الثقة:** محتوى رسائل E2EE النصية يعبر الخادم + Redis + Aiven بصيغة ciphertext فقط (VERIFIED). **الثغرات الحدودية:** (1) وسائط plaintext تُرفع إلى Drive/S3 قبل التشفير، (2) القنوات والـ fallback نص صريح عبر كامل السلسلة، (3) IP مقتطع في إشعارات الأمان عبر مرحّلات Google.

### ملاحظة تكوين حساسة (بدون أي قيم)

- `deploy/full-env.json` يخزّن **قيمًا فعلية** لأسماء المفاتيح التالية: `DATABASE_URL`, `JWT_SECRET`, `AUTH_PEPPER`, `ADMIN_USERNAMES`, `NODE_ENV`, `STORAGE_MASTER_KEY`, `NODE_VERSION`, `COOKIE_SECRET`, `ALLOWED_ORIGINS`, `GDRIVE_CLIENT_ID`, `GDRIVE_CLIENT_SECRET`, `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, `KT_SIGNING_KEY`. وجود قيم أسرار (وأخصها `DATABASE_URL` الذي يتضمن بيانات دخول Aiven) في ملف داخل مستودع العمل يخضع لمراجعة hygiene منفصلة — يُذكر هنا بالأسماء فقط. VERIFIED (بنية الملف — قائمة {key,value} بعدد 14).
- يوجد أيضًا `deploy/render-env-paste.txt` و `deploy/kt-keys.txt` (أسماء ملفات فقط — المحتوى لم يُنسخ عمدًا). VERIFIED (مجرد وجود الملفات).
- `ALLOWED_ORIGINS`: قائمة مفصولة بفواصل، هي المرجع في production؛ بدونها يُسمح بالأصل الحالي في dev. VERIFIED (server.ts:237-246).

---

## 4) تدقيق الاستبقاء والحذف (RETENTION/DELETION AUDIT)

| البند | الحالة الفعلية | الدليل | التصنيف |
|---|---|---|---|
| حذف رسالة للجميع | Soft-delete: `content=''` + `deleted_at`؛ **نسخة من المحتوى الأصلي في vault الذاكرة بلا استبقاء فعلي** | server.ts:2899-2940 | VERIFIED |
| حذف رسالة لي (`deleted_for`) | إخفاء فقط — المحتوى يبقى في DB إلى الأبد | server.ts:2968-3010؛ database.ts:4069-4075 | VERIFIED |
| Disappearing messages | الأفضل في النظام: sweep كل 5 دقائق يمسح المحتوى فعليًا (`content=''`) ويبث `msg:delete:everyone` | database.ts:3733-3753؛ moderation_jobs.ts:41-54 | VERIFIED |
| Deleted Messages Vault 30-day | **ادعاء لا يتحقق**: `cleanupExpiredDeletedMessages()` تُعيد `0` حرفيًا — لا حذف أبداً؛ السجل اليومي يطبع "Permanently deleted 0" وهو مضلل | database.ts:5135-5137؛ moderation_jobs.ts:83-95 | VERIFIED |
| Read receipts | 180 يومًا، prune مجدول (batched 5000/حجم 20000) | database.ts:5206-5241 | VERIFIED |
| moderation_audit_logs | 365 يومًا، prune كل ساعة | database.ts:5247-5277؛ moderation_jobs.ts:159-181 | VERIFIED |
| auth_logs | **بلا prune إطلاقًا — استبقاء غير محدود**، وبلا FK → تنجو من حذف الحساب | grep: لا يوجد `DELETE FROM auth_logs` | VERIFIED |
| reports / kt_mismatch_reports | بلا prune — غير محدود | grep عام | VERIFIED |
| KT log | **لا يُحذف بالتصميم** (append-only؛ الحذف يكسر consistency proofs) — موثق في تعليق الـ migration | database.ts:1336-1349 | VERIFIED |
| حذف الحساب | موجود: `DELETE /api/users/me` → FK CASCADE للرسائل المرسلة/الجلسات/المفاتيح/webauthn/storage-link؛ **لا يمسح**: auth_logs، push_subscriptions (بلا FK)، kt_log (مقصود)، reports عن الآخرين (SET NULL) | server.ts:1143-1156؛ database.ts:4880-4890 | VERIFIED |
| حذف الحسابات الخاملة | تلقائي يومي (opt-in عبر `autoDeleteAfterMonths`) → `db.deleteUser` | moderation_jobs.ts:70-80 | VERIFIED |
| مسح شامل إداري | `resetAndWipeAllUsersAndData` عبر مسار `ADMIN_WIPE_SECRET` | database.ts:2160-2229 | VERIFIED (مسار الإطلاق في server.ts — PARTIALLY VERIFIED) |
| حذف ملفات Drive/S3 | **غير موجود** — فك ربط التخزين يحذف التوكن من DB فقط؛ الملفات (enc.bin و/orphan plaintext) تبقى عند Google/مزود S3 | routes/storage.ts كاملًا (لا endpoint حذف ملفات) | VERIFIED |
| تصدير بيانات المستخدم | **لا يوجد API تصدير**؛ البديل الوحيد: ملف backup محلي مشفر `DIRBK1:` (ChaCha20-Poly1305، passphrase لا يُخزَّن) | grep `/api/export` = لا نتائج؛ backup.ts:1-50 | VERIFIED |

---

## 5) مسح السجلات/التحليلات (LOGS/ANALYTICS SWEEP)

**الخادم:**
- `logger.ts` يعمل redaction تلقائي لأي مفتاح يطابق `/password|token|secret|authorization/i` + ring buffer 500 إدخال | logger.ts:24-45, 62-92 | VERIFIED
- لا يُعثر على أي `console.log`/`logger` يسجّل محتوى رسالة كاملًا (grep شامل على src/server) | VERIFIED
- **استثناء 1:** dedupKey يضمّن أول 10 أحرف من المحتوى ويطبع في logs عند التكرار | ws_server.ts:803-811 | VERIFIED — على ciphertext عادة، لكن على plaintext في القنوات
- **استثناء 2:** GDrive errors تسجّل مقاطع (≤200 حرف) من error bodies الخارجية — لا توكنات | gdrive.ts:142-143, 194-195 | VERIFIED
- إشعار الـ push يسجّل userId وعدد endpoints فقط | push.ts:98 | VERIFIED
- DashboardStats telemetry: معرّفات وتوقيتات فقط (messageId/senderId/chatId/timings) | write_queue.ts:198-208 | VERIFIED

**العميل:**
- `console.log('[dispatchSystemCallMessage]', content, …)` يسجّل محتوى سجل المكالمات في كونسول المتصفح | App.tsx:535 | VERIFIED (منخفض — جهاز المستخدم)
- SW: لا يسجّل الـ payload إطلاقًا — عدّادات فقط + fallback عام لأي payload غير قابل للفك | service-worker.js:181-203 | VERIFIED
- flag `e2eeDebug` في localStorage يفعّل لوجات ctrl (metadata فقط) | App.tsx:1683 | VERIFIED

**لا يوجد تحليلات خارجية (analytics/beacons):** SW cache يضم عناصر من `unsplash.com`/`ibb.co`/`gstatic` (أيقونات/صور ثابتة — أيقونة الإشعارات من `i.ibb.co` service-worker.js:205) لكن لا يوجد SDK تحليلات يرسل بيانات سلوكية. VERIFIED (grep src) — PARTIALLY VERIFIED لتحميل الأيقونة الخارجية كـ phone-home محتمل.

---

## 6) الفجوات الصريحة والادعاءات غير المتحقق منها

1. **[UNVERIFIED → غير موجود]** لا يوجد أي endpoint لتصدير بيانات المستخدم (portability) ولا صفحة "تنزيل بياناتي".
2. **[UNVERIFIED → غير موجود]** ادعاء "report snapshots تخزن محتوى البلاغ 90 يومًا" لا أساس له في الكود: `reports` لا تخزن محتوى الرسالة، ولا يوجد retention 90d لأي جدول في النظام (الموجود: 180d reads، 365d moderation logs).
3. **[PARTIALLY VERIFIED]** مزود Redis: الكود يدعم أي `REDIS_URL`/`REDIS_HOST`؛ لا يمكن تأكيد "Redis Cloud" من المستودع (لا يوجد في full-env.json مفتاح REDIS).
4. **[PARTIALLY VERIFIED]** تشفير `users.totp_secret` at-rest يعتمد على helper مشترك مع snapshot encryption؛ مراجعته التفصيلية في نطاق crypto auditor.
5. **[VERIFIED كفجوة]** `write_queue` يكتب نسخة كاملة من الطابور (شاملة content) إلى Redis مع TTL سنة عند كل عملية — في الحالات الطبيعية تُزال الرسالة من الطابور فور نجاح الكتابة، لكن عند تعطل DB قبل استنفاد المحاولات تبقى نسخة المحتوى (ciphertext/صريح) في Redis حتى سنة.
6. **[VERIFIED كفجوة]** `push_subscriptions` بدون FK → بعد حذف الحساب تبقى صفوف subscription لمستخدم غير موجود (لا تتلقى push لأن getPushSubscriptionsForUser لن يُستدعى، لكنها metadata يتيمة).
7. **[VERIFIED كفجوة]** لمرة واحدة فقط: هجرة legacy توكنات من localStorage تمسحها نهائيًا (token_vault.ts:22-38) — الحالة الانتقالية موثقة.

---

## 7) أهم النتائج مرتبة بالخطورة (Privacy Findings)

| # | الخطورة | النتيجة | الدليل |
|---|---|---|---|
| 1 | **High** | **وسائط plaintext تُرفع إلى Drive/S3 قبل لف E2EE** — الصوت/الصور/الملفات (بالاسم الأصلي على Drive) تصل مزود تخزين خارجي كنص صريح ثم يعاد رفعها مشفرة، والنسخة الصريحة تبقى للأبد (orphan) | ChatWindow.tsx:1639-1656, 1961-1968, 2172, 2308, 4068؛ App.tsx:4732-4762؛ storageUtils.ts:186-196 |
| 2 | **High** | **القنوات (`type='channel'`) و DM fallback خارج E2E بالكامل**: محتوى صريح يعبر الخادم + Redis + Aiven، ويُقرأ فعليًا للـ mentions | App.tsx:1608-1612, 4818-4820؛ ws_server.ts:874-882 |
| 3 | **Medium-High** | **auth_logs تخزن IPs كاملة بلا استبقاء أقصى ولا حذف مع الحساب** (بينما الإشعارات تقطعها 24 حرفًا فقط) | database.ts:5485-5511؛ authClassic.ts:267 |
| 4 | **Medium-High** | **Deleted Messages Vault بلا استبقاء فعلي**: cleanup no-op رغم ادعاء 30 يومًا؛ المحتوى الأصلي (صريح للقنوات) قابل للبحث من المشرِّفين بلا سقف زمني | database.ts:5135-5137؛ server.ts:3339-3348 |
| 5 | **Medium** | **كاش الرسائل المفككة plaintext في IndexedDB** (`dirashaMessagesDB`) خارج تغليف الـ vault — سرقة ملفات المتصفح تكشف آخر 150 رسالة/شات | messages_cache_db.ts:4-6, 108 |
| 6 | **Medium** | **ملفات Drive لا تُحذف أبدًا** عند حذف الرسائل/الحساب — بلاغ حذف لا يمحو النسخة عند الطرف الثالث | routes/storage.ts (لا حذف ملفات) |
| 7 | **Medium** | IP مقتطع (≤24) في أجسام إشعارات الأمان يعبر مرحّلات push التابعة لـ Google/Apple | securityAlerts.ts:70-72 |
| 8 | **Low-Medium** | أول 10 أحرف من المحتوى في logs الخادم (Render) عبر dedupKey | ws_server.ts:803-811 |
| 9 | **Low** | write-queue بنسخ المحتوى إلى Redis بـ TTL سنة (سلوك التعطل) | write_queue.ts:82-89 |
| 10 | **Low** | بقايا مخطط AI (`system_api_keys` service_name='gemini') ومفتاح `muted_from_ai_until` بلا مستهلك | database.ts:2078-2090, 1926 |

### ملاحظة إيجابية مهمة (للدقة)
الادعاء المقلق الأول في نطاق التدقيق — "ما الذي يرسله gemini.ts إلى Google" — **انتهى**: الخدمة محذوفة نهائيًا ولا يوجد أي مسار AI (services/gemini.ts:1). أيضًا حمولات Web Push للرسائل عامة بالكامل ولا تحمل محتوى أو أسماء (push.ts:37-71) — تطبيق حرفي لعقد الخصوصية في الكود.
