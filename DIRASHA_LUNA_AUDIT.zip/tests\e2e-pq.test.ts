/**
 * Dirasha E2EE — PQXDH (post-quantum hybrid X3DH) tests, per the approved
 * design doc docs/PQXDH-DESIGN-ar.md §3/§4:
 *
 *   pq1  hybrid session init (both engines PQ) → round-trip messages
 *   pq2  the hybrid SK DIFFERS from the classical-only derivation
 *        (proof that PQ_SS enters the KDF) + stripping pq from the wire
 *        fails closed (no silent downgrade)
 *   pq3  legacy device (pq:false) ↔ PQ initiator → classical path works
 *   pq4  tampered pqCt → session derives wrong → AEAD fails
 *        (TamperedError, a DecryptFailedError — no silent fallback)
 *   pq5  bundle advertises pq:true with unusable PQ material → the engine
 *        does NOT silently downgrade: that device's envelope FAILS
 *   pq6  DIRM1 first message with 6 devices + PQ fits the 16000 transport
 *        ceiling (and exceeds the old 8000 gate — the reason it was raised)
 *   pq7  PQ bootstrap replay → replay guard rejects (guards unchanged)
 *   pq8  legacy (pre-PQ) registered device upgrades on the next
 *        ensureRegistered() → bundle then advertises pq:true
 *   pq9  tampered SPK+PQ combined signature → device skipped, fail closed
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';

import { DirashaE2EE } from '../src/lib/e2ee/engine.ts';
import { MemoryKVStore } from '../src/lib/e2ee/store.ts';
import type { KVStore } from '../src/lib/e2ee/types.ts';
import {
  WIRE_PREFIX,
  WIRE_PREFIX_MULTI,
  PQ_PUB_BYTES,
  PQ_CT_BYTES,
  PQ_SPK_SIG_PREFIX,
  b64encode,
  b64decode,
  utf8Encode,
  utf8Decode,
  generateX25519,
  generateEd25519,
  generateMlKem768,
  ed25519Sign,
  x25519Shared,
  x3dhSk,
  x3dhSkPq,
  pqDecapsulate,
  SPK_SIG_PREFIX,
  concatBytes,
  ZERO32,
  pqEncapsulate,
} from '../src/lib/e2ee/crypto.ts';

/* ── Mock server (multi-device e2ee routes incl. the v10 PQ fields) ───────── */

interface ServerOpk { id: number; pub: string; consumed: boolean }
interface ServerDeviceReg {
  deviceId: string;
  identityDhPub: string;
  identitySigPub: string;
  signedPrekeyPub: string;
  prekeySignature: string;
  pqPrekeyPub: string | null;
  pqPrekeySignature: string | null;
  opks: ServerOpk[];
}

function createMockServer() {
  const regs = new Map<string, Map<string, ServerDeviceReg>>();
  const userOf = (init?: RequestInit): string => {
    const headers = (init?.headers ?? {}) as Record<string, string>;
    return String(headers.Authorization ?? '').replace(/^Bearer\s+/, '');
  };
  const respond = (status: number, data: unknown) =>
    new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json' } });

  const fetch = async (url: any, init?: RequestInit): Promise<Response> => {
    const path = String(url).split('?')[0];
    const method = (init?.method ?? 'GET').toUpperCase();
    const body = init?.body ? JSON.parse(String(init.body)) : {};
    const user = userOf(init);

    if (path === '/api/e2ee/register' && method === 'POST') {
      const deviceId = typeof body.deviceId === 'string' && body.deviceId ? body.deviceId : 'default';
      let devices = regs.get(user);
      if (!devices) {
        devices = new Map<string, ServerDeviceReg>();
        regs.set(user, devices);
      }
      devices.set(deviceId, {
        deviceId,
        identityDhPub: body.identityDhPub,
        identitySigPub: body.identitySigPub,
        signedPrekeyPub: body.signedPrekeyPub,
        prekeySignature: body.prekeySignature,
        // v10: optional PQ fields — absent → NULL (legacy classical device).
        pqPrekeyPub: typeof body.pqPrekeyPub === 'string' ? body.pqPrekeyPub : null,
        pqPrekeySignature: typeof body.pqPrekeySignature === 'string' ? body.pqPrekeySignature : null,
        opks: (body.oneTimePrekeys ?? []).map((o: any) => ({ id: o.id, pub: o.pub, consumed: false })),
      });
      return respond(200, { ok: true });
    }
    if (path.startsWith('/api/e2ee/bundle/') && method === 'GET') {
      const devices = regs.get(path.split('/').pop()!);
      if (!devices || devices.size === 0) return respond(404, { registered: false });
      return respond(200, {
        registered: true,
        devices: [...devices.values()].map((d) => {
          const opk = d.opks.find((o) => !o.consumed) ?? null;
          if (opk) opk.consumed = true;
          const hasPq = !!(d.pqPrekeyPub && d.pqPrekeySignature);
          return {
            deviceId: d.deviceId,
            identityDhPub: d.identityDhPub,
            identitySigPub: d.identitySigPub,
            signedPrekeyPub: d.signedPrekeyPub,
            prekeySignature: d.prekeySignature,
            opk: opk ? { id: opk.id, pub: opk.pub } : null,
            pq: hasPq,
            ...(hasPq ? { pqPrekeyPub: d.pqPrekeyPub!, pqPrekeySignature: d.pqPrekeySignature! } : {}),
          };
        }),
      });
    }
    if (path === '/api/e2ee/prekeys' && method === 'POST') {
      const devices = regs.get(user);
      if (!devices || devices.size === 0) return respond(404, { ok: false });
      const primary = [...devices.values()][0];
      for (const o of body.oneTimePrekeys ?? []) primary.opks.push({ id: o.id, pub: o.pub, consumed: false });
      return respond(200, { ok: true, opkRemaining: 0 });
    }
    if (path === '/api/e2ee/status' && method === 'GET') {
      const devices = regs.get(user);
      const remaining = devices
        ? [...devices.values()].reduce((a, d) => a + d.opks.filter((o) => !o.consumed).length, 0)
        : 0;
      return respond(200, { registered: !!devices && devices.size > 0, opkRemaining: remaining });
    }
    if (path.startsWith('/api/e2ee/identity/') && method === 'GET') {
      const devices = regs.get(path.split('/').pop()!);
      if (!devices || devices.size === 0) return respond(404, { registered: false });
      const primary = [...devices.values()][0];
      return respond(200, { registered: true, identityDhPub: primary.identityDhPub, deviceCount: devices.size });
    }
    return respond(404, { error: 'not found' });
  };

  return { fetch, regs };
}

/* ── Harness ──────────────────────────────────────────────────────────────── */

let server: ReturnType<typeof createMockServer>;

function makeEngine(user: string, store?: KVStore): DirashaE2EE {
  return new DirashaE2EE({
    authHeaders: () => ({ Authorization: `Bearer ${user}` }),
    store: store ?? new MemoryKVStore(),
    selfId: user,
  });
}

async function sendAndDecrypt(from: DirashaE2EE, fromId: string, to: DirashaE2EE, toId: string, text: string) {
  const { content } = await from.encryptMessage(toId, text);
  return to.decryptMessage(fromId, content);
}

/** Parse a DIR1 wire string into its envelope object. */
function parseWire(content: string): any {
  return JSON.parse(utf8Decode(b64decode(content.slice(WIRE_PREFIX.length))));
}

/** Re-serialize an envelope object into a DIR1 wire string. */
function toWire(env: any): string {
  return WIRE_PREFIX + b64encode(utf8Encode(JSON.stringify(env)));
}

/** Re-serialize a DIRM1 container object into its wire string. */
function toMultiWire(multi: any): string {
  return WIRE_PREFIX_MULTI + b64encode(utf8Encode(JSON.stringify(multi)));
}

function deviceIdsOf(user: string): string[] {
  return [...server.regs.get(user)!.keys()];
}

beforeEach(() => {
  server = createMockServer();
  vi.stubGlobal('fetch', server.fetch as unknown as typeof fetch);
});

afterEach(() => {
  vi.unstubAllGlobals();
});

/* ── Tests ────────────────────────────────────────────────────────────────── */

describe('PQXDH (post-quantum hybrid X3DH)', () => {
  it('(pq1) both engines PQ: hybrid bootstrap carries pq:1 + 1088B pqCt; messages round-trip', async () => {
    const alice = makeEngine('alice');
    const bobStore = new MemoryKVStore();
    const bob = makeEngine('bob', bobStore);
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    // Every fresh registration advertises an ML-KEM-768 quantum prekey.
    const bobDev = [...server.regs.get('bob')!.values()][0];
    expect(bobDev.pqPrekeyPub).not.toBeNull();
    expect(b64decode(bobDev.pqPrekeyPub!).length).toBe(PQ_PUB_BYTES);
    expect(b64decode(bobDev.pqPrekeySignature!).length).toBe(64);

    const first = (await alice.encryptMessage('bob', 'مرحبا كميّة 🔐')).content;
    expect(first.startsWith('DIR1:')).toBe(true); // single device → legacy wire
    const env = parseWire(first);
    expect(env.pq).toBe(1);
    expect(typeof env.pqCt).toBe('string');
    expect(b64decode(env.pqCt).length).toBe(PQ_CT_BYTES);
    expect(env.x3dh).toBeTruthy();
    // The PQ ciphertext rides at the ENVELOPE level only (no double carriage
    // inside the x3dh block — size discipline for the transport ceiling).
    expect(env.x3dh.pqCt).toBeUndefined();

    expect(await bob.decryptMessage('alice', first)).toEqual({ plaintext: 'مرحبا كميّة 🔐' });

    // The responder session documents the hybrid derivation.
    const aliceDev = deviceIdsOf('alice')[0];
    const bobSession = JSON.parse((await bobStore.get(`session:alice:${aliceDev}`))!);
    expect(bobSession.pq).toBe(true);

    // Full ratchet round trip on the hybrid session, both directions.
    expect(await sendAndDecrypt(alice, 'alice', bob, 'bob', 'hybrid msg 2')).toEqual({ plaintext: 'hybrid msg 2' });
    expect(await sendAndDecrypt(bob, 'bob', alice, 'alice', 'hybrid reply')).toEqual({ plaintext: 'hybrid reply' });
    // After the confirmation reply, later envelopes carry no bootstrap/pq flag.
    const later = parseWire((await alice.encryptMessage('bob', 'no bootstrap left')).content);
    expect(later.x3dh).toBeUndefined();
    expect(later.pq).toBeUndefined();
    expect(later.pqCt).toBeUndefined();
    expect(await bob.decryptMessage('alice', toWire(later))).toEqual({ plaintext: 'no bootstrap left' });
  });

  it('(pq2) the hybrid SK differs from the classical-only derivation (PQ_SS provably enters the KDF)', () => {
    // Direct primitive-level proof: same DH material, with and without PQ_SS,
    // under the two DISTINCT info strings — outputs are fully independent.
    const ik = generateX25519();
    const spk = generateX25519();
    const ek = generateX25519();
    const dh1 = x25519Shared(ik.priv, spk.pub);
    const dh2 = x25519Shared(ek.priv, ik.pub);
    const dh3 = x25519Shared(ek.priv, spk.pub);
    const classicalIkm = concatBytes(ZERO32, dh1, dh2, dh3);
    const pq = generateMlKem768();
    const { ss } = pqEncapsulate(pq.pub);
    const hybridIkm = concatBytes(ZERO32, dh1, dh2, dh3, ss);
    const skClassical = x3dhSk(classicalIkm);
    const skHybrid = x3dhSkPq(hybridIkm);
    expect(Buffer.from(skClassical).equals(Buffer.from(skHybrid))).toBe(false);
    // And flipping even one IKM byte changes the hybrid SK (avalanche).
    const tampered = hybridIkm.slice();
    tampered[tampered.length - 1] ^= 0x01;
    expect(Buffer.from(x3dhSkPq(tampered)).equals(Buffer.from(skHybrid))).toBe(false);
  });

  it('(pq2b) stripping pq/pqCt from a hybrid bootstrap fails AEAD — no silent downgrade on the wire', async () => {
    const alice = makeEngine('alice');
    const bob = makeEngine('bob');
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    // A wire attacker strips the PQ fields hoping the responder falls back to
    // the classical derivation: the responder derives a DIFFERENT SK with the
    // classical info string → the bootstrap AEAD never verifies → error.
    const first = (await alice.encryptMessage('bob', 'strip me')).content;
    const env = parseWire(first);
    expect(env.pq).toBe(1);
    delete env.pq;
    delete env.pqCt;
    const res = (await bob.decryptMessage('alice', toWire(env))) as any;
    expect(res.error).toBe('TamperedError'); // TamperedError extends DecryptFailedError
    // The honest envelope still decrypts (state untouched by the failed strip).
    expect(await bob.decryptMessage('alice', first)).toEqual({ plaintext: 'strip me' });
  });

  it('(pq3) legacy device (pq:false) ↔ PQ initiator → classical path works end to end', async () => {
    const alice = makeEngine('alice');
    const bob = makeEngine('bob');
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    // Server-side: strip bob's device PQ keys → the bundle advertises pq:false
    // (a pre-v10 legacy device without quantum material).
    const bobDev = [...server.regs.get('bob')!.values()][0];
    bobDev.pqPrekeyPub = null;
    bobDev.pqPrekeySignature = null;
    alice.clearDeviceCache();

    const first = (await alice.encryptMessage('bob', 'classical fallback')).content;
    const env = parseWire(first);
    expect(env.pq).toBeUndefined();
    expect(env.pqCt).toBeUndefined();
    expect(await bob.decryptMessage('alice', first)).toEqual({ plaintext: 'classical fallback' });
    expect(await sendAndDecrypt(bob, 'bob', alice, 'alice', 'classical reply')).toEqual({ plaintext: 'classical reply' });
    expect(await sendAndDecrypt(alice, 'alice', bob, 'bob', 'classical 3')).toEqual({ plaintext: 'classical 3' });
  });

  it('(pq4) tampered pqCt → wrong session derivation → AEAD fails (DecryptFailedError family, no fallback)', async () => {
    const alice = makeEngine('alice');
    const bob = makeEngine('bob');
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    const first = (await alice.encryptMessage('bob', 'pq tamper')).content;
    const env = parseWire(first);
    // Flip one base64 char INSIDE pqCt: still valid std-b64, still exactly
    // 1088 decoded bytes, but ML-KEM decapsulates it to a DIFFERENT secret
    // (implicit rejection) → SK differs → the ratchet AEAD tag fails.
    const flip = (ch: string) => (ch === 'A' ? 'B' : 'A');
    const ct = env.pqCt as string;
    env.pqCt = flip(ct[0]) + ct.slice(1);
    const res = (await bob.decryptMessage('alice', toWire(env))) as any;
    // TamperedError IS a DecryptFailedError (subclass) — the contract is
    // "no silent fallback": the error is surfaced, never classical re-derivation.
    expect(res.error === 'TamperedError' || res.error === 'DecryptFailedError').toBe(true);
    // The honest original still decrypts afterwards.
    expect(await bob.decryptMessage('alice', first)).toEqual({ plaintext: 'pq tamper' });
  });

  it('(pq5) bundle advertises pq:true but PQ material is unusable → that device FAILS, never classical', async () => {
    const alice = makeEngine('alice');
    const bob = makeEngine('bob');
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    // (a) pq:true but the PQ fields are MISSING → TamperedError, device skipped.
    // Simulate an inconsistent/attacker-controlled bundle: pq advertised,
    // material stripped.
    const origFetch = server.fetch;
    vi.stubGlobal('fetch', async (url: any, init?: RequestInit) => {
      const res = await origFetch(url, init);
      if (String(url).startsWith('/api/e2ee/bundle/bob') && res.status === 200) {
        const body: any = await res.json();
        for (const d of body.devices) {
          d.pq = true;
          delete d.pqPrekeyPub;
          delete d.pqPrekeySignature;
        }
        return new Response(JSON.stringify(body), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }
      return res;
    });
    await expect(alice.encryptMessage('bob', 'no downgrade')).rejects.toThrow();

    // (b) pq:true with a CORRUPTED combined signature → same fail-closed shape.
    vi.stubGlobal('fetch', origFetch as unknown as typeof fetch);
    alice.clearDeviceCache();
    const bobDev = [...server.regs.get('bob')!.values()][0];
    const badSig = bobDev.pqPrekeySignature!;
    bobDev.pqPrekeySignature = (badSig[0] === 'A' ? 'B' : 'A') + badSig.slice(1);
    await expect(alice.encryptMessage('bob', 'no downgrade 2')).rejects.toThrow();
    bobDev.pqPrekeySignature = badSig;

    // (c) pq:true with WRONG-SIZE pq material → fail closed too.
    alice.clearDeviceCache();
    const goodPqPub = bobDev.pqPrekeyPub!;
    bobDev.pqPrekeyPub = b64encode(new Uint8Array(32));
    await expect(alice.encryptMessage('bob', 'no downgrade 3')).rejects.toThrow();
    bobDev.pqPrekeyPub = goodPqPub;

    // With the bundle restored, the hybrid exchange succeeds.
    alice.clearDeviceCache();
    expect(await sendAndDecrypt(alice, 'alice', bob, 'bob', 'hybrid after restore'))
      .toEqual({ plaintext: 'hybrid after restore' });
  });

  it('(pq6) DIRM1 first message to 6 PQ devices fits the E2EE transport ceiling (and busts the old 8000)', async () => {
    const alice = makeEngine('alice');
    const bobs: DirashaE2EE[] = [];
    await alice.ensureRegistered();
    for (let i = 0; i < 6; i++) {
      const engine = makeEngine('bob', new MemoryKVStore());
      await engine.ensureRegistered();
      bobs.push(engine);
    }
    expect(deviceIdsOf('bob')).toHaveLength(6);

    const { content } = await alice.encryptMessage('bob', 'fleet-first-message');
    // The very first fan-out (bootstrap + PQ ciphertext per device) is exactly
    // the transport-ceiling case: bigger than the OLD 8000 gate. MEASURED:
    // ~20.2KB wire (the whole DIRM1 container is b64-of-JSON, so the task's
    // raw-byte estimate 13.7KB ≈ 18.3KB wire + per-device padded AEAD ct).
    // The E2EE gate is therefore 24KB (the existing e2ee:ctrl relay ceiling).
    expect(content.startsWith('DIRM1:')).toBe(true);
    expect(content.length).toBeGreaterThan(8000);
    expect(content.length).toBeLessThanOrEqual(24576);
    expect(content.length).toBeLessThan(21000); // measured ~20.2KB — bounded, not free-form

    // All 6 devices decrypt it.
    for (const bob of bobs) {
      expect(await bob.decryptMessage('alice', content)).toEqual({ plaintext: 'fleet-first-message' });
    }
  });

  it('(pq7) replaying a hybrid bootstrap is rejected by the unchanged replay guards', async () => {
    const alice = makeEngine('alice');
    const bob = makeEngine('bob');
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    const first = (await alice.encryptMessage('bob', 'pq replay me')).content;
    expect(await bob.decryptMessage('alice', first)).toEqual({ plaintext: 'pq replay me' });
    // The OPK priv is deleted after confirmed use (P4) — a hybrid replay must
    // still fail closed via the bootstrappedEk guard, never re-derive SK.
    expect(await bob.decryptMessage('alice', first)).toEqual({ error: 'TamperedError' });
    // The session survives and traffic keeps flowing (hybrid chain intact).
    expect(await sendAndDecrypt(alice, 'alice', bob, 'bob', 'still alive')).toEqual({ plaintext: 'still alive' });
  });

  it('(pq8) a pre-PQ registered device upgrades on the next ensureRegistered() (bundle flips to pq:true)', async () => {
    const alice = makeEngine('alice');
    const bobStore = new MemoryKVStore();
    const bob = makeEngine('bob', bobStore);
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    // Simulate a device that registered BEFORE the PQ upgrade: no local PQ
    // prekey record, not yet registered (i.e. its next ensureRegistered will
    // (re-)register).
    await bobStore.del('pqpq-priv');
    const identity = JSON.parse((await bobStore.get('identity'))!);
    identity.registered = false;
    await bobStore.set('identity', JSON.stringify(identity));
    // Server-side: wipe the stored PQ pair too (a pre-v10 server state).
    const bobDev = [...server.regs.get('bob')!.values()][0];
    bobDev.pqPrekeyPub = null;
    bobDev.pqPrekeySignature = null;
    alice.clearDeviceCache();

    // The upgrade run: PQ prekey generated + re-registered with it.
    await bob.ensureRegistered();
    // Re-read the device row: registration REPLACES the server's row object.
    const upgradedDev = [...server.regs.get('bob')!.values()][0];
    expect(upgradedDev.pqPrekeyPub).not.toBeNull();
    expect(b64decode(upgradedDev.pqPrekeyPub!).length).toBe(PQ_PUB_BYTES);
    alice.clearDeviceCache();

    // Alice now sees pq:true and runs the HYBRID exchange against bob.
    const first = parseWire((await alice.encryptMessage('bob', 'post upgrade')).content);
    expect(first.pq).toBe(1);
    expect(await bob.decryptMessage('alice', toWire(first))).toEqual({ plaintext: 'post upgrade' });
  });

  it('(pq9) the combined SPK+PQ signature is verified by the CLIENT against IK_sig', async () => {
    const alice = makeEngine('alice');
    const bob = makeEngine('bob');
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    // Independent re-derivation of the exact signature the client must verify:
    // Ed25519('DirashaPQSPK-v1:' + b64(spkPub) + b64(pqPub)) under IK_sig.
    const bobDev = [...server.regs.get('bob')!.values()][0];
    const msg = PQ_SPK_SIG_PREFIX + bobDev.signedPrekeyPub + bobDev.pqPrekeyPub!;
    expect(b64decode(bobDev.pqPrekeySignature!).length).toBe(64);
    // The engine accepted it during pq1-style init — here we additionally
    // prove the SIGNATURE INPUT is the combined string: flipping one byte of
    // the signed PQ pub inside the bundle breaks the device.
    const flippedPub = b64encode(b64decode(bobDev.pqPrekeyPub!).map((b, i) => (i === 0 ? b ^ 0x01 : b)));
    bobDev.pqPrekeyPub = flippedPub;
    alice.clearDeviceCache();
    await expect(alice.encryptMessage('bob', 'sig binds pq pub')).rejects.toThrow();
    bobDev.pqPrekeyPub = b64encode(b64decode(flippedPub).map((b, i) => (i === 0 ? b ^ 0x01 : b)));
  });

  it('(pq10) PQ primitives: sizes match FIPS-203 §(768) and the envelope validator rejects malformed pqCt', async () => {
    // Measured noble sizes (design doc §2.1).
    expect(PQ_PUB_BYTES).toBe(1184);
    expect(PQ_CT_BYTES).toBe(1088);
    const kp = generateMlKem768();
    expect(kp.pub.length).toBe(1184);
    const { ct, ss } = pqEncapsulate(kp.pub);
    expect(ct.length).toBe(1088);
    expect(ss.length).toBe(32);

    const alice = makeEngine('alice');
    const bob = makeEngine('bob');
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    // pq:1 without pqCt → TamperedError from the envelope validator.
    const first = parseWire((await alice.encryptMessage('bob', 'shape')).content);
    const noCt = { ...first };
    delete noCt.pqCt;
    expect(((await bob.decryptMessage('alice', toWire(noCt))) as any).error).toBe('TamperedError');

    // pqCt with the WRONG LENGTH (pq flag present) → TamperedError.
    const shortCt = { ...first, pqCt: b64encode(new Uint8Array(64)) };
    expect(((await bob.decryptMessage('alice', toWire(shortCt))) as any).error).toBe('TamperedError');

    // pqCt present WITHOUT the pq flag → TamperedError (inconsistent shape).
    const flagless = { ...first };
    delete flagless.pq;
    expect(((await bob.decryptMessage('alice', toWire(flagless))) as any).error).toBe('TamperedError');
  });

  it('(pq11) multi-device fleet with MIXED PQ/legacy devices: hybrid per pq device, classical per legacy device', async () => {
    const alice = makeEngine('alice');
    const bobPq = makeEngine('bob', new MemoryKVStore());
    const bobLegacy = makeEngine('bob', new MemoryKVStore());
    await alice.ensureRegistered();
    await bobPq.ensureRegistered();
    await bobLegacy.ensureRegistered();

    // Device 2 simulates a pre-PQ device.
    const devices = [...server.regs.get('bob')!.values()];
    devices[1].pqPrekeyPub = null;
    devices[1].pqPrekeySignature = null;
    alice.clearDeviceCache();

    const { content } = await alice.encryptMessage('bob', 'mixed fleet');
    expect(content.startsWith('DIRM1:')).toBe(true);
    const multi = JSON.parse(utf8Decode(b64decode(content.slice(WIRE_PREFIX_MULTI.length))));
    expect(multi.devices).toHaveLength(2);
    const pqEntry = multi.devices.find((e: any) => e.d === devices[0].deviceId);
    const legacyEntry = multi.devices.find((e: any) => e.d === devices[1].deviceId);
    expect(pqEntry.env.pq).toBe(1);
    expect(legacyEntry.env.pq).toBeUndefined();

    expect(await bobPq.decryptMessage('alice', content)).toEqual({ plaintext: 'mixed fleet' });
    expect(await bobLegacy.decryptMessage('alice', content)).toEqual({ plaintext: 'mixed fleet' });
    // Both keep receiving subsequent fan-outs on their independent chains.
    const next = (await alice.encryptMessage('bob', 'mixed 2')).content;
    expect(await bobPq.decryptMessage('alice', next)).toEqual({ plaintext: 'mixed 2' });
    expect(await bobLegacy.decryptMessage('alice', next)).toEqual({ plaintext: 'mixed 2' });
  });
});

/* Sanity: the standalone helpers imported above are exercised by the engine. */
describe('PQXDH crypto helpers', () => {
  it('ML-KEM-768 encapsulate/decapsulate agree; SPK signature prefix is stable', () => {
    const kp = generateMlKem768();
    const { ct, ss } = pqEncapsulate(kp.pub);
    const ss2 = pqDecapsulate(ct, kp.priv);
    expect(Buffer.from(ss).equals(Buffer.from(ss2))).toBe(true);
    expect(SPK_SIG_PREFIX).toBe('DirashaSPK-v1:');
    expect(PQ_SPK_SIG_PREFIX).toBe('DirashaPQSPK-v1:');
    // A classical SPK sig over the plain prefix is unchanged.
    const sig = ed25519Sign(utf8Encode(SPK_SIG_PREFIX + b64encode(generateX25519().pub)), generateEd25519().priv);
    expect(sig.length).toBe(64);
  });
});
