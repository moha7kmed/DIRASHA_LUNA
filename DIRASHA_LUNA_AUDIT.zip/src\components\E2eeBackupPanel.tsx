/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * E2eeBackupPanel — "النسخة الاحتياطية المشفرة" (E2EE backup UI).
 *
 * Self-contained modal panel, mounted by the lead agent later. Two tabs:
 *
 *  - EXPORT (تصدير محادثة): seals ONE chat (props.chatId/chatName) into a
 *    `DIRBK1:...` encrypted backup via createBackup() and downloads it as
 *    `<chatName>-dirasha-backup.dirk`. Message contents are unwrapped through
 *    parseEncryptedPayload() so the backup stores readable text (not the
 *    `dirasha-msg-v1` container). Shows the 8-hex passphrase fingerprint.
 *
 *  - IMPORT (استيراد): reads a `.dirk` file + passphrase, opens it with
 *    openBackup() and shows a read-only viewer of the restored messages.
 *    READ-ONLY: nothing is written back to the server or local store.
 *
 * PERFORMANCE CONTRACT (backup.ts): createBackup / openBackup /
 * backupFingerprint each run a full scrypt (~0.3–1s, synchronous). Every call
 * site here yields to the browser first (a ~30ms setTimeout) so the
 * "جارٍ التشفير..." note paints before the main thread blocks.
 *
 * The passphrase is never stored anywhere — it exists only inside the handler
 * closure for the duration of one operation.
 *
 * Styling mirrors the existing dark-theme modals (E2eeSafetyModal pattern):
 * fixed overlay + zinc-900 rounded-3xl card, Arabic RTL content.
 */

import React, { useState, useCallback, useMemo, useRef } from 'react';
import {
  X,
  Lock,
  Loader2,
  ShieldCheck,
  AlertCircle,
  Eye,
  EyeOff,
  Download,
  Upload,
  FileDown,
  CheckCircle2,
  MessageSquare,
} from 'lucide-react';

import {
  createBackup,
  openBackup,
  exportAccountBackup,
  importAccountBackup,
  backupFingerprint,
  BackupError,
} from '../lib/e2ee/backup.ts';
import { parseEncryptedPayload } from '../lib/e2ee/media.ts';

/* ══ Loose prop typing (deliberately uncoupled from App's message types) ══ */

/** Minimal message shape the panel needs (superset fields are ignored). */
export interface BackupPanelMessage {
  id?: string;
  senderId?: string;
  senderName?: string;
  content?: string;
  createdAt?: string;
  type?: string;
  [k: string]: unknown;
}

/** One chat supplied by the caller in accountMode (full-account export). */
export interface BackupPanelChat {
  chatId: string;
  chatName: string;
  messages: BackupPanelMessage[];
}

export interface E2eeBackupPanelProps {
  /** Chat to export (selected by the lead before mounting the panel). */
  chatId: string;
  /** Display name of that chat (goes into the file name + backup metadata). */
  chatName: string;
  /** Lead-provided loader: decrypted messages for the chat (oldest→newest). */
  getMessages: () => Promise<BackupPanelMessage[]>;
  /** Close handler for the panel. */
  onClose: () => void;
  /** Optional visibility switch (defaults to true — always shown when mounted). */
  open?: boolean;
  /**
   * Project 11 — FULL ACCOUNT mode ("الحساب كامل"). When true:
   *   - EXPORT seals ALL chats via the v2 format (exportAccountBackup) — the
   *     chats come from the caller-supplied {@link getAllChats} loader (the
   *     lead mounts it; per-chat getMessages is ignored on this path).
   *   - IMPORT opens account files via importAccountBackup, which accepts BOTH
   *     v2 account files and legacy v1 single-chat files (versioned parse).
   * The existing per-chat flow (accountMode unset/false) is untouched.
   * RESTORE stays read-only in both modes: decrypted messages are displayed in
   * the in-panel viewer only — never written back to the server or the local
   * store (no re-upload, no history pollution).
   */
  accountMode?: boolean;
  /**
   * accountMode export loader: ALL of the account's chats with their decrypted
   * messages. Required for export in accountMode; ignored otherwise.
   */
  getAllChats?: () => Promise<BackupPanelChat[]>;
}

type Tab = 'export' | 'import';
type ExportStep = 'idle' | 'busy' | 'done';
type ImportStep = 'idle' | 'busy' | 'done';

/* ══ Small helpers ══ */

/** Sanitize a user-supplied chat name for use inside a download file name. */
function safeFileName(name: string): string {
  const cleaned = String(name || 'chat').replace(/[\\/:*?"<>|]/g, '_').trim();
  return cleaned.length > 0 ? cleaned.slice(0, 60) : 'chat';
}

/** Format an ISO timestamp for the Arabic UI (empty-safe). */
function fmtDate(iso: unknown): string {
  const d = iso ? new Date(String(iso)) : null;
  if (!d || Number.isNaN(d.getTime())) return '—';
  try {
    return d.toLocaleString('ar', { dateStyle: 'medium', timeStyle: 'short' });
  } catch {
    return d.toISOString();
  }
}

/**
 * Crude passphrase strength hint (client-side convenience only — not security).
 * Returns [label, colorClass] with 0..3 levels.
 */
function strengthHint(pass: string): [string, string] {
  let score = 0;
  if (pass.length >= 10) score++;
  if (pass.length >= 16) score++;
  if (/[a-z]/.test(pass) && /[A-Z]/.test(pass)) score++;
  if (/\d/.test(pass) && /[^\w\s]/.test(pass)) score++;
  if (score <= 1) return ['ضعيفة', 'text-red-400'];
  if (score <= 2) return ['متوسطة', 'text-amber-400'];
  return ['قوية', 'text-emerald-400'];
}

/**
 * Unwrap one message's content for the backup snapshot. The stored envelope
 * plaintext for E2EE media messages is our `dirasha-msg-v1` container JSON —
 * extract `.text` (and mark attachments). Non-container / legacy plaintext
 * passes through unchanged (parseEncryptedPayload back-compat); a container
 * that CLAIMS our kind but is malformed falls back to the raw string so no
 * data is silently dropped from the backup.
 */
function exportContent(raw: unknown, msg: BackupPanelMessage): string {
  const text = typeof raw === 'string' ? raw : String(raw ?? '');
  try {
    const parsed = parseEncryptedPayload(text);
    const hasFiles = Array.isArray(parsed.files) && parsed.files.length > 0;
    const type = String((msg as { type?: unknown }).type ?? '');
    const isMedia = hasFiles || (type && type !== 'text' && type !== 'system');
    if (parsed.text && parsed.text.length > 0) {
      return isMedia ? `${parsed.text}\n[مرفقات: ${Math.max(parsed.files.length, 1)}]` : parsed.text;
    }
    if (hasFiles) return '[مرفق مشفر]';
    return text;
  } catch {
    // parseEncryptedPayload throws only for a malformed claimed-container —
    // keep the original string so the backup stays lossless.
    return text;
  }
}

/* ══ Component ══ */

export function E2eeBackupPanel({
  chatId,
  chatName,
  getMessages,
  onClose,
  open = true,
  accountMode = false,
  getAllChats,
}: E2eeBackupPanelProps) {
  const [tab, setTab] = useState<Tab>('export');

  /* ── Export state ── */
  const [exPass, setExPass] = useState('');
  const [exPass2, setExPass2] = useState('');
  const [exShow, setExShow] = useState(false);
  const [exStep, setExStep] = useState<ExportStep>('idle');
  const [exError, setExError] = useState<string | null>(null);
  const [exFingerprint, setExFingerprint] = useState<string | null>(null);
  const [exFileName, setExFileName] = useState<string | null>(null);

  /* ── Import state ── */
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [imFileText, setImFileText] = useState<string | null>(null);
  const [imFileName, setImFileName] = useState<string | null>(null);
  const [imPass, setImPass] = useState('');
  const [imShow, setImShow] = useState(false);
  const [imStep, setImStep] = useState<ImportStep>('idle');
  const [imError, setImError] = useState<string | null>(null);
  const [imResult, setImResult] = useState<{ chats: any[]; createdAt: string } | null>(null);

  const [strengthLabel, strengthColor] = useMemo(() => strengthHint(exPass), [exPass]);

  const resetExport = useCallback(() => {
    setExPass(''); setExPass2(''); setExShow(false);
    setExStep('idle'); setExError(null); setExFingerprint(null); setExFileName(null);
  }, []);

  const resetImport = useCallback(() => {
    setImFileText(null); setImFileName(null); setImPass(''); setImShow(false);
    setImStep('idle'); setImError(null); setImResult(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  }, []);

  /* ── EXPORT ── */
  const handleExport = useCallback(async () => {
    if (exStep === 'busy') return;
    setExError(null);
    if (!exPass) { setExError('أدخل كلمة سر للنسخة الاحتياطية.'); return; }
    if (exPass !== exPass2) { setExError('كلمتا السر غير متطابقتين.'); return; }
    if (accountMode && typeof getAllChats !== 'function') {
      setExError('لم يتم تزويد اللوحة بقائمة المحادثات (getAllChats) — تصدير الحساب الكامل غير متاح.');
      return;
    }

    setExStep('busy');
    // Yield one frame so the "جارٍ التشفير..." note paints before the
    // synchronous ~1s scrypt blocks the main thread (backup.ts UI contract).
    await new Promise((r) => setTimeout(r, 30));
    try {
      let chats: Array<{ chatId: string; peerName: string; messages: any[] }>;
      if (accountMode) {
        // Project 11 (accountMode): the CALLER supplies ALL chats — each is
        // unwrapped through the same lossless exportContent() path, then the
        // whole set is sealed as ONE v2 account backup (payload kind
        // 'dirasha-backup-v2'). Only message content + metadata is sealed;
        // keys and session secrets are never included (backup.ts contract).
        const rawChats = await getAllChats!();
        chats = (Array.isArray(rawChats) ? rawChats : []).map((c) => ({
          chatId: String(c?.chatId ?? ''),
          peerName: String(c?.chatName ?? ''),
          messages: (Array.isArray(c?.messages) ? c.messages : []).map((m) => ({
            id: String((m as BackupPanelMessage).id ?? ''),
            senderId: String((m as BackupPanelMessage).senderId ?? ''),
            senderName: String((m as BackupPanelMessage).senderName ?? ''),
            content: exportContent((m as BackupPanelMessage).content, m),
            createdAt: String((m as BackupPanelMessage).createdAt ?? ''),
            type: String((m as BackupPanelMessage).type ?? 'text'),
          })),
        }));
      } else {
        const rawMessages = await getMessages();
        const messages = (Array.isArray(rawMessages) ? rawMessages : []).map((m) => ({
          id: String((m as BackupPanelMessage).id ?? ''),
          senderId: String((m as BackupPanelMessage).senderId ?? ''),
          senderName: String((m as BackupPanelMessage).senderName ?? ''),
          content: exportContent((m as BackupPanelMessage).content, m),
          createdAt: String((m as BackupPanelMessage).createdAt ?? ''),
          type: String((m as BackupPanelMessage).type ?? 'text'),
        }));
        chats = [{ chatId: String(chatId), peerName: String(chatName || ''), messages }];
      }

      // backupFingerprint + (exportAccount|create)Backup each run a full scrypt (~1s).
      const fingerprint = backupFingerprint(exPass);
      const fileText = accountMode
        ? exportAccountBackup(exPass, chats)
        : createBackup(exPass, chats);

      const fileName = accountMode
        ? 'dirasha-account-backup.dirk'
        : `${safeFileName(chatName)}-dirasha-backup.dirk`;
      const blob = new Blob([fileText], { type: 'application/octet-stream' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      a.click();
      URL.revokeObjectURL(url);

      setExFingerprint(fingerprint);
      setExFileName(fileName);
      setExStep('done');
    } catch (e) {
      setExError('تعذر إنشاء النسخة الاحتياطية. تأكد من اتصالك ثم أعد المحاولة.');
      setExStep('idle');
    }
  }, [exStep, exPass, exPass2, getMessages, chatId, chatName, accountMode, getAllChats]);

  /* ── IMPORT: file picker ── */
  const handlePickFile = useCallback(async (file: File | null | undefined) => {
    if (!file) return;
    setImError(null);
    setImResult(null);
    setImStep('idle');
    try {
      const text = await file.text();
      setImFileText(text);
      setImFileName(file.name);
    } catch {
      setImError('تعذر قراءة الملف. حاول اختياره مجدداً.');
    }
  }, []);

  /* ── IMPORT: open ── */
  const handleImport = useCallback(async () => {
    if (imStep === 'busy') return;
    setImError(null);
    if (!imFileText) { setImError('اختر ملف النسخة الاحتياطية أولاً.'); return; }
    if (!imPass) { setImError('أدخل كلمة سر النسخة الاحتياطية.'); return; }

    setImStep('busy');
    // Yield so the "جارٍ فك التشفير..." note paints before the ~1s scrypt.
    await new Promise((r) => setTimeout(r, 30));
    try {
      // Project 11: accountMode uses the VERSIONED parser (v2 account files AND
      // legacy v1 files both open); the per-chat flow keeps the strict v1
      // openBackup. Both are read-only decrypt + display — nothing is uploaded
      // to the server or written to the local store.
      const opened = accountMode
        ? importAccountBackup(imPass, imFileText)
        : openBackup(imPass, imFileText);
      setImResult({ chats: opened.chats as any[], createdAt: opened.createdAt });
      setImStep('done');
    } catch (e) {
      if (e instanceof BackupError) {
        setImError(e.code === 'BAD_PASSPHRASE'
          ? 'كلمة السر غير صحيحة'
          : 'الملف تالف أو ليس نسخة ديراشة');
      } else {
        setImError('الملف تالف أو ليس نسخة ديراشة');
      }
      setImStep('idle');
    }
  }, [imStep, imFileText, imPass, accountMode]);

  if (!open) return null;

  const totalMessages = imResult
    ? imResult.chats.reduce((n, c) => n + (Array.isArray(c?.messages) ? c.messages.length : 0), 0)
    : 0;

  const inputCls = 'w-full bg-zinc-800/80 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white outline-none focus:border-emerald-500/50';

  return (
    <div
      className="fixed inset-0 z-[2000] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg bg-zinc-900 border border-white/10 rounded-3xl overflow-hidden max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
        style={{ direction: 'rtl' }}
      >
        {/* Header — mirrors the existing modal pattern (icon + title + close) */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/5 shrink-0">
          <div className="flex items-center gap-2">
            <ShieldCheck size={18} className="text-emerald-400" />
            <h3 className="text-white font-bold text-sm">
              {accountMode ? 'النسخة الاحتياطية المشفرة — الحساب كامل' : 'النسخة الاحتياطية المشفرة'}
            </h3>
          </div>
          <button onClick={onClose} className="text-zinc-400 hover:text-white" aria-label="إغلاق">
            <X size={18} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 px-5 pt-4 shrink-0">
          {(
            [
              { id: 'export' as Tab, label: accountMode ? 'تصدير الحساب كامل' : 'تصدير محادثة', icon: Download },
              { id: 'import' as Tab, label: 'استيراد', icon: Upload },
            ]
          ).map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => { setTab(id); setExError(null); setImError(null); }}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
                tab === id
                  ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                  : 'bg-white/5 text-zinc-400 border-white/10 hover:bg-white/10'
              }`}
            >
              <Icon size={14} />
              {label}
            </button>
          ))}
        </div>

        <div className="p-5 space-y-4 overflow-y-auto">
          {/* ══ EXPORT TAB ══ */}
          {tab === 'export' && (
            <>
              <div className="flex items-start gap-2 p-3 rounded-2xl bg-emerald-500/5 border border-emerald-500/15 text-emerald-200/80 text-xs leading-relaxed">
                <MessageSquare size={16} className="shrink-0 mt-0.5 text-emerald-400" />
                {accountMode ? (
                  <span>
                    سيتم تصدير <span className="font-bold">كل محادثاتك</span> في ملف واحد مشفّر
                    طرف-لطرف بكلمة سر من اختيارك. لا يمكن لأي طرف — ولا حتى خوادم ديراشا — قراءة
                    محتواه دون كلمة السر. النسخة تحفظ نصوص الرسائل وبياناتها الظاهرة فقط — لن تتضمن
                    أي مفاتيح تشفير أو أسرار جلسات، ولا يمكن استخدامها لاستعادة محادثات مباشرة.
                  </span>
                ) : (
                  <span>
                    سيتم تصدير محادثة <span className="font-bold">«{chatName}»</span> كاملة في ملف واحد
                    مشفّر طرف-لطرف بكلمة سر من اختيارك. لا يمكن لأي طرف — ولا حتى خوادم ديراشا —
                    قراءة محتواها دون كلمة السر.
                  </span>
                )}
              </div>

              {exStep !== 'done' && (
                <>
                  {/* Passphrase (double entry + strength hint + show/hide) */}
                  <div className="space-y-2">
                    <div className="relative">
                      <input
                        type={exShow ? 'text' : 'password'}
                        value={exPass}
                        onChange={(e) => setExPass(e.target.value)}
                        placeholder="كلمة سر النسخة الاحتياطية"
                        className={`${inputCls} pl-10`}
                        dir="ltr"
                        autoComplete="new-password"
                        disabled={exStep === 'busy'}
                      />
                      <button
                        type="button"
                        onClick={() => setExShow((s) => !s)}
                        className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white cursor-pointer"
                        aria-label={exShow ? 'إخفاء كلمة السر' : 'إظهار كلمة السر'}
                        tabIndex={-1}
                      >
                        {exShow ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                    {exPass && (
                      <div className="flex items-center gap-1.5 text-[11px] px-1">
                        <Lock size={11} className="text-zinc-500" />
                        <span className="text-zinc-500">قوة كلمة السر:</span>
                        <span className={`font-bold ${strengthColor}`}>{strengthLabel}</span>
                      </div>
                    )}
                    <div className="relative">
                      <input
                        type={exShow ? 'text' : 'password'}
                        value={exPass2}
                        onChange={(e) => setExPass2(e.target.value)}
                        placeholder="تأكيد كلمة السر"
                        className={inputCls}
                        dir="ltr"
                        autoComplete="new-password"
                        disabled={exStep === 'busy'}
                      />
                    </div>
                  </div>

                  {exError && (
                    <div className="flex items-start gap-2 p-3 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-300 text-xs leading-relaxed">
                      <AlertCircle size={16} className="shrink-0 mt-0.5" />
                      <span>{exError}</span>
                    </div>
                  )}

                  {exStep === 'busy' ? (
                    <div className="flex items-center justify-center gap-2 py-4 text-zinc-400 text-sm select-none">
                      <Loader2 size={18} className="animate-spin text-emerald-400" />
                      <span>جارٍ التشفير... (قد تستغرق ثانية)</span>
                    </div>
                  ) : (
                    <button
                      onClick={handleExport}
                      disabled={!exPass}
                      className="w-full py-2.5 rounded-2xl bg-emerald-500 text-black font-black text-xs flex items-center justify-center gap-2 hover:bg-emerald-400 transition-colors cursor-pointer disabled:opacity-40"
                    >
                      <FileDown size={14} />
                      إنشاء النسخة وتنزيلها (.dirk)
                    </button>
                  )}
                </>
              )}

              {exStep === 'done' && (
                <div className="space-y-3">
                  <div className="flex items-start gap-2 p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs leading-relaxed">
                    <CheckCircle2 size={16} className="shrink-0 mt-0.5" />
                    <span>تم إنشاء النسخة الاحتياطية وتنزيلها: <span className="font-mono" dir="ltr">{exFileName}</span></span>
                  </div>

                  {exFingerprint && (
                    <div className="space-y-1.5">
                      <p className="text-[11px] text-zinc-500">بصمة كلمة السر (للمقارنة عند الاستيراد):</p>
                      <div
                        dir="ltr"
                        className="p-3 rounded-2xl bg-black/40 border border-white/10 text-center font-mono text-[15px] font-bold tracking-[0.3em] text-emerald-100/90 select-all"
                      >
                        {exFingerprint}
                      </div>
                    </div>
                  )}

                  <div className="flex items-start gap-2 p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-bold leading-relaxed">
                    <AlertCircle size={16} className="shrink-0 mt-0.5" />
                    <span>احفظ كلمة السر — لا يمكن استعادتها دونها</span>
                  </div>

                  <button
                    onClick={resetExport}
                    className="w-full py-2.5 rounded-2xl bg-white/5 border border-white/10 text-zinc-200 font-bold text-xs hover:bg-white/10 transition-colors cursor-pointer"
                  >
                    إنشاء نسخة أخرى
                  </button>
                </div>
              )}
            </>
          )}

          {/* ══ IMPORT TAB ══ */}
          {tab === 'import' && (
            <>
              <div className="flex items-start gap-2 p-3 rounded-2xl bg-white/5 border border-white/10 text-zinc-300 text-xs leading-relaxed">
                <Upload size={16} className="shrink-0 mt-0.5 text-zinc-400" />
                <span>
                  {accountMode
                    ? 'افتح ملف نسخة الحساب الكامل أو ملف نسخة قديم لمحادثة واحدة بكلمة سره. '
                    : 'افتح ملف نسخة احتياطية ('}
                  {accountMode ? null : <span className="font-mono" dir="ltr">.dirk</span>}
                  {accountMode ? null : ') بكلمة سرها. '}
                  المعاينة للقراءة فقط — لن يتم استيراد أي شيء إلى حسابك أو الخوادم، ولن تُعاد
                  الرسائل إلى المحادثات المباشرة.
                </span>
              </div>

              {imStep !== 'done' && (
                <>
                  {/* File picker */}
                  <div>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".dirk,.dirasha-backup,application/octet-stream"
                      onChange={(e) => handlePickFile(e.target.files?.[0])}
                      className="hidden"
                    />
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full py-3 rounded-2xl border border-dashed border-white/15 bg-black/20 text-zinc-300 text-xs font-bold flex items-center justify-center gap-2 hover:border-emerald-500/40 hover:text-emerald-300 transition-colors cursor-pointer"
                    >
                      <FileDown size={14} />
                      {imFileName
                        ? <span className="font-mono" dir="ltr">{imFileName}</span>
                        : 'اختر ملف النسخة الاحتياطية (.dirk)'}
                    </button>
                  </div>

                  {/* Passphrase */}
                  <div className="relative">
                    <input
                      type={imShow ? 'text' : 'password'}
                      value={imPass}
                      onChange={(e) => setImPass(e.target.value)}
                      placeholder="كلمة سر النسخة الاحتياطية"
                      className={`${inputCls} pl-10`}
                      dir="ltr"
                      autoComplete="off"
                      disabled={imStep === 'busy' || !imFileText}
                    />
                    <button
                      type="button"
                      onClick={() => setImShow((s) => !s)}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white cursor-pointer"
                      aria-label={imShow ? 'إخفاء كلمة السر' : 'إظهار كلمة السر'}
                      tabIndex={-1}
                    >
                      {imShow ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>

                  {imError && (
                    <div className="flex items-start gap-2 p-3 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-300 text-xs leading-relaxed">
                      <AlertCircle size={16} className="shrink-0 mt-0.5" />
                      <span>{imError}</span>
                    </div>
                  )}

                  {imStep === 'busy' ? (
                    <div className="flex items-center justify-center gap-2 py-4 text-zinc-400 text-sm select-none">
                      <Loader2 size={18} className="animate-spin text-emerald-400" />
                      <span>جارٍ فك التشفير... (قد تستغرق ثانية)</span>
                    </div>
                  ) : (
                    <button
                      onClick={handleImport}
                      disabled={!imFileText || !imPass}
                      className="w-full py-2.5 rounded-2xl bg-emerald-500 text-black font-black text-xs flex items-center justify-center gap-2 hover:bg-emerald-400 transition-colors cursor-pointer disabled:opacity-40"
                    >
                      <Lock size={14} />
                      فتح النسخة
                    </button>
                  )}
                </>
              )}

              {/* Restored (read-only) viewer */}
              {imStep === 'done' && imResult && (
                <div className="space-y-3">
                  <div className="flex items-start gap-2 p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs leading-relaxed">
                    <CheckCircle2 size={16} className="shrink-0 mt-0.5" />
                    <span>
                      تم فتح النسخة بنجاح: {imResult.chats.length} محادثة، {totalMessages} رسالة —
                      أُنشئت في {fmtDate(imResult.createdAt)}
                    </span>
                  </div>

                  <div className="max-h-72 overflow-y-auto rounded-2xl border border-white/10 bg-black/30 p-3 space-y-4">
                    {imResult.chats.map((chat: any, ci: number) => (
                      <div key={String(chat?.chatId ?? ci)} className="space-y-2">
                        <div className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-300/90 border-b border-white/5 pb-1.5">
                          <MessageSquare size={12} />
                          <span>{String(chat?.peerName || 'محادثة بدون اسم')}</span>
                          <span className="text-zinc-500 font-normal">
                            ({Array.isArray(chat?.messages) ? chat.messages.length : 0} رسالة)
                          </span>
                        </div>
                        {(Array.isArray(chat?.messages) ? chat.messages : []).map((m: any, mi: number) => (
                          <div
                            key={String(m?.id ?? mi)}
                            className="rounded-xl bg-zinc-800/60 border border-white/5 px-3 py-2"
                          >
                            <div className="flex items-center justify-between gap-2 mb-1">
                              <span className="text-[11px] font-bold text-zinc-300">
                                {String(m?.senderName || m?.senderId || 'مجهول')}
                              </span>
                              <span className="text-[10px] text-zinc-500">{fmtDate(m?.createdAt)}</span>
                            </div>
                            <p className="text-xs text-zinc-200 leading-relaxed whitespace-pre-wrap break-words">
                              {String(m?.content ?? '')}
                            </p>
                          </div>
                        ))}
                      </div>
                    ))}
                  </div>

                  <button
                    onClick={resetImport}
                    className="w-full py-2.5 rounded-2xl bg-white/5 border border-white/10 text-zinc-200 font-bold text-xs hover:bg-white/10 transition-colors cursor-pointer"
                  >
                    فتح نسخة أخرى
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default E2eeBackupPanel;
