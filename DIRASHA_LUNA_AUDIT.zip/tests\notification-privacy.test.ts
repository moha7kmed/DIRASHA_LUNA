/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * PROJECT 7 — Privacy-Preserving Notifications regression tests.
 *
 * Grounded leak being guarded against: write_queue.ts used to push message
 * content + sender display name through WebPushService.sendPush; the payload
 * transits third-party relays (FCM/APNs gateways, browser-push endpoints) and
 * is rendered verbatim by the OS. The server must therefore emit ONLY a
 * generic label plus routing metadata ({chatId, messageId}).
 *
 * Run: npm test
 */
import { describe, it, expect } from 'vitest';

const DISTINCT_CONTENT = 'SECRET-CONTENT-أسرار-VERY-PRIVATE-MESAGE';
const DISTINCT_SENDER = 'SECRET-SENDER-NAME-显示名';
const DISTINCT_ATTACHMENT_URL = 'https://evil.example.com/leak.png';

describe('Project 7: message push payload privacy (buildMessagePushPayload)', () => {
  it('uses ONLY the generic Arabic title and body — no sender name, no content', async () => {
    const { buildMessagePushPayload, GENERIC_PUSH_TITLE, GENERIC_PUSH_BODY } =
      await import('../src/server/services/push.ts');

    const payload = buildMessagePushPayload('chat-123', 'msg-456');
    expect(payload.title).toBe(GENERIC_PUSH_TITLE);
    expect(payload.title).toBe('ديراشة');
    expect(payload.body).toBe(GENERIC_PUSH_BODY);
    expect(payload.body).toBe('لديك رسالة جديدة');
    // Generic — must not contain any user-controlled fragments
    expect(payload.body).not.toContain(DISTINCT_CONTENT);
    expect(payload.title).not.toContain(DISTINCT_SENDER);
  });

  it('data payload carries ONLY routing metadata: chatId + messageId', async () => {
    const { buildMessagePushPayload } = await import('../src/server/services/push.ts');
    const payload = buildMessagePushPayload('chat-123', 'msg-456');
    const dataKeys = Object.keys(payload.data).sort();
    expect(dataKeys).toEqual(['chatId', 'messageId']);
    expect(payload.data.chatId).toBe('chat-123');
    expect(payload.data.messageId).toBe('msg-456');
    // No sender identity in routing data
    expect((payload.data as any).senderName).toBeUndefined();
    expect((payload.data as any).senderId).toBeUndefined();
    expect((payload.data as any).content).toBeUndefined();
  });

  it('serializes a content-free wire payload even when inputs contain hostile strings', async () => {
    const { buildMessagePushPayload, buildWebPushEnvelope } =
      await import('../src/server/services/push.ts');

    // buildWebPushEnvelope is the ONLY place a push payload is serialized (push.ts).
    // Send the generic builder's output through it exactly like sendPush does.
    const payload = buildMessagePushPayload('chat-123', 'msg-456');
    const wire = buildWebPushEnvelope(payload.title, payload.body, payload.data);
    const parsed = JSON.parse(wire);

    expect(parsed.title).toBe('ديراشة');
    expect(parsed.body).toBe('لديك رسالة جديدة');
    expect(wire).not.toContain(DISTINCT_CONTENT);
    expect(wire).not.toContain(DISTINCT_SENDER);
    expect(wire).not.toContain(DISTINCT_ATTACHMENT_URL);
    // Routing metadata survives; only chatId/messageId/timestamp added
    expect(parsed.data.chatId).toBe('chat-123');
    expect(parsed.data.messageId).toBe('msg-456');
    expect(typeof parsed.data.timestamp).toBe('number');
    expect(Object.keys(parsed.data).sort()).toEqual(['chatId', 'messageId', 'timestamp']);
  });

  it('envelope builder adds nothing beyond title/body/data (no sneak channels)', async () => {
    const { buildWebPushEnvelope } = await import('../src/server/services/push.ts');
    const parsed = JSON.parse(buildWebPushEnvelope('t', 'b', { chatId: 'c', messageId: 'm' }));
    expect(Object.keys(parsed).sort()).toEqual(['body', 'data', 'title']);
  });
});

describe('Project 7: write_queue wiring (static source contract)', () => {
  it('message push goes exclusively through buildMessagePushPayload — no inline body/title construction', async () => {
    const fs = await import('fs');
    const path = await import('path');
    const src = fs.readFileSync(
      path.resolve(__dirname, '../src/server/websocket/write_queue.ts'),
      'utf-8'
    );
    // The generic builder must be imported and invoked
    expect(src).toContain('buildMessagePushPayload');
    expect(src).toContain("from '../services/push.ts'");
    // The old leaking preview builder is fully gone
    expect(src).not.toContain('buildPushPreview');
    expect(src).not.toContain('PUSH_PREVIEW_MAX');
    // No sender display name as push title, no job.content-derived push body
    expect(src).not.toContain('senderDisplayName');
    expect(src).not.toContain("job.senderName || 'مستخدم ديراشة'");
    // The sendPush call in write_queue must receive the builder's fields
    expect(src).toMatch(/sendPush\(memb\.userId, pushPayload\.title, pushPayload\.body, pushPayload\.data\)/);
  });

  it('service worker never logs raw push payloads and falls back to a generic body', async () => {
    const fs = await import('fs');
    const path = await import('path');
    const src = fs.readFileSync(
      path.resolve(__dirname, '../src/service-worker.js'),
      'utf-8'
    );
    // The push event must not be logged whole (payload would be inspectable)
    expect(src).not.toContain("console.log('[ServiceWorker] Push event received:', event)");
    // Undecodable payload fallback must NOT render raw text on the lock screen
    expect(src).not.toContain('body: event.data.text()');
    expect(src).toContain('لديك رسالة جديدة');
    // Click routing uses only chatId (no content-derived navigation)
    expect(src).toContain("data.chatId");
  });
});
