# DIRASHA_EVIDENCE_INDEX
## فهرس الأدلة — كل دليل بمكانه ودرجته (E1-E5) والـ SHA المرتبط به

**قاعدة الدرجات:** E1=Source · E2=Reproducible Test · E3=Runtime · E4=External Standard · E5=Formal.
**SHA الحاكم:** `006a004e6832dd22a02c34dc24c9fefb40daf2f3` (Candidate) — السلسلة: `42582df → 4c8824a → c4b1416 → 006a004`.

## أ. أدلة المستودع (E1 — Source)

| الدليل | المسار | يثبت |
|---|---|---|
| نموذج الدور الدائم | `src/server/database.ts:89-95` (mapUserRow) · `:2735-2760` (createPasswordUser) | لا اشتقاق صلاحية من الاسم |
| حجز أسماء المشغلين | `authClassic.ts:228-238` + `server.ts:1128-1147` (ADV-01 fix) + `server.ts:1526` | register/rename/profile-rename محمية |
| bootstrap-operator | `server.ts` (claim-first ON CONFLICT + timingSafeEqual + audit) | توفير واحد الاستخدام |
| reset-database guard | `server.ts:4331+` (limiter pre-gate + confirm + timing-safe + audit) | DIR-2026-006 |
| بثّ projection | `server.ts:1214-1227` (5 حقول) + `presence_manager.ts` (بلا lastSeen) | DIR-2026-010p/AB-09 |
| بوابة الدخول المشفر | `guards/encryptionPolicy.ts:51-108` + wiring ×5 | E2EE-03/DIR-NEW-01 |
| ratchet v2 | `group.ts:141-144,376-504,329-341,465-468` | E2EE-07/013/014 |
| mv hydration + snapshot import | `database.ts:2106,1898` | DIR-MV-01 |
| roster restore | `database.ts:4186-4205` (prevMembers/prevRoles/prevMv + persist) | AB-02/ADV-02 |
| membership atomic | `database.ts:4070-4211` | CB-01/E2EE-01/02 |
| tombstones ×5 | `server.ts` (edit/sync/react/star/pin → 409) | AB-03 |
| sync gates | `server.ts:3061-3092` (cap/type/allowlist) | AB-01/07 |
| spent-token detector | `database.ts:3504-3530` + `auth.ts:390-394` | CB-02/AUTH-01 |
| session PG fallback | `database.ts:5613-5631` | AB-05 |
| WS ban checks | `ws_server.ts:492-505,577-589` | AB-04/026 |
| media scoping | `server.ts:463-469` + `storage.ts:466-470` (membership) | CB-03/MEDIA-01 |
| decideProxyHeaders | `guards/proxyHeaders.ts` + wiring `storage.ts` | B5-F1 |
| validateComment + binding | `guards/statusPolicy.ts:116-133` + `status.ts:331` | B5-F2/AB-06 |
| decidePushEndpointAllowed | `guards/pushEndpoint.ts` + wiring `server.ts:677` | F-3/33 |
| clientIp lib | `lib/trustedClientIp.ts` | F-4/AUTH-07 |
| vault quarantine | `vault.ts:329-350` | DIR-NEW-12 |
| KT gate | `engine.ts:1041-1070` + `kt-client.ts:778-799` | E2EE-08 |
| re-encrypt retry | `ChatWindow.tsx:2816-2843` | ADV-04/CB-04 |
| sweep gates | `moderation_jobs.ts:135-168` + `database.ts:5931` (compose_mv v14) | ADV-03 |

## ب. أدلة الاختبارات (E2 — Reproducible)

| الدليل | الأمر | النتيجة (قياسات مستقلة) |
|---|---|---|
| Suite كامل @ 006a004 | `npm test` | **663 passed / 1 skipped / 0 failed (664) — 44 ملفًا** (الوكيلان + المنسق) |
| طبقة سلوكية جديدة | `tests/remediation-b6.test.ts` | 25 اختبارًا ينفذون الحراس فعليًا |
| **Revert-proof** | `node DIRASHA_FINAL_VERIFICATION/revert-proof/run-revert-check.mjs` | 4/4 تأكيدات تفشل على التنفيذ القديم |
| typecheck | `npm run typecheck` | 0 أخطاء |
| scanner | `node scripts/scan-secrets.cjs` | PASS 253 ملفًا |
| npm audit | `npm audit --omit=dev` | 0 vulnerabilities |

## ج. أدلة Git (E1)
- HEAD `006a004` · baseline ancestors (`42582df`,`4c8824a`,`c4b1416`) مؤكدة `merge-base --is-ancestor`.
- master ثابت `e77cfb7` · fsck نظيف · ملفات المستخدم الـ15 خارج كل commits.
- سكربت السجل: `node DIRASHA_FINAL_VERIFICATION/verify-ledger.mjs` → ALL PASS (96/96/0 dupes/85 RC/0 mismatches).

## د. أدلة خارجية (E4)
- Mozilla Push Service docs (mozilla-push-service.readthedocs.io) · Microsoft WNS overview (learn.microsoft.com) · Firebase Cloud Messaging docs — مضيفي push الرسميون.
- Signal specs (X3DH/DR/PQXDH) · IETF MLS RFC 9420 · NIST FIPS 203 — مراجع المقارنة البروتوكولية (Protocol Readiness).
- OWASP ASVS 5.0/WSTG 4.2 — أطر التصنيف.

## هـ. ما لا يوجد (بصراحة)
- **E3 runtime:** صفر — لا staging في الجلسة (G2).
- **E5 formal:** صفر — لا formal verification (أي ادعاء منها مرفوض).
- أدلة تدوير الأسرار: صفر — G1 OWNER-REQUIRED.
