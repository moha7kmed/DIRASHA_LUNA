# TEST_RESULTS.md — جرد الاختبارات الفعلي (Test Inventory Audit)

> **تاريخ التنفيذ:** 2026-11-17. كل الأرقام من تشغيل **فعلي** بتاريخ اليوم. لا أسرار في الملف.
> **تصنيف:** [مُنفَّذ | Executed] / [مُتحقق | Verified] / [تحليل | Analysis].

---

## 1. نتائج التشغيل الفعلي

### `npm test` [مُنفَّذ]
```
Test Files  15 passed (15)
     Tests  210 passed (210)
   Start at 22:53:47
   Duration 164.95s (tests 96%, import 4%)
```
- **15 ملفًا / 210 اختبارًا — كلها خضراء** — exit 0.
- **ملاحظة صادقة:** تعليق CI في verify.yml يقول "Full test suite (109 tests …)" — الرقم **قديم وغير مطابق** (الفعلي 210) [مُتحقق — verify.yml خطوة "Full test suite" مقابل ناتج التشغيل]. Severity: Low (توثيق زائد القول).

### `npm run typecheck` (tsc --noEmit) [مُنفَّذ]
- نُفِّذ وخرج **exit 0 بلا أخطاء**.

---

## 2. جرد الملفات — ملف اختبار واحد لكل سطر (15 ملفًا) [مُتحقق — ترويسات الملفات + عدّ it/test]

| الملف | العدد ~ | التغطية في سطر |
|---|---|---|
| tests/distributed-rate-limit.test.ts | 13 | الـ limiter الموزع على Redis: ذرّية العدّ المتوازي، fail-closed للـ critical، تدهور throughput للـ local Map |
| tests/e2e-pq.test.ts | 13 | PQXDH: تهجين الجلسة، اختلاف SK عن الكلاسيكي، فشل صريح عند إزالة pq من السلك (لا downgrade صامت) |
| tests/e2ee-backup.test.ts | 30 | النسخ الاحتياطي المشفر بالمَرور: round-trip، مرور خاطئ، ciphertext تالف، بصمة الـ passphrase، unicode، حواف فارغة |
| tests/e2ee-engine.test.ts | 21 | محرك 1:1 متعدد الأجهزة: round-trip بخطوات ratchet بالاتجاهين عبر mock-fetch يقلد عقد الخادم |
| tests/e2ee-fuzz.test.ts | 5 | **مضخم خصائصي seeded**: طوبولوجيا عشوائية 1..3 أقران × 1..3 أجهزة مع timeline عدائي — تحقق I1–I7 بعد كل عملية |
| tests/e2ee-group.test.ts | 16 | Sender Keys لثلاثة أعضاء: توزيع pairwise، processControl، مشتقات السلسلة، التدوير |
| tests/e2ee-media.test.ts | 17 | المرفقات: round-trip ‏2MB، مفتاح خاطئ ⇒ TamperedError، sha256 mismatch، container build/parse مع back-compat |
| tests/e2ee-rotation.test.ts | 3 | التدوير الطارئ (r1) تغيير الهوية ومسح الجلسات وOPK جديد، (r2) سلوك قرين يحمل جلسة قديمة، (r3) التعافي |
| tests/e2ee-security-audit.test.ts | 8 | الانحدارات الأمنية من تدقيق 2026-11: replay/rollback للـ X3DH bootstrap وstale pre-rekey rebuild (E1–E4) |
| tests/e2ee-server.test.ts | 12 | validators الخادم لدليل المفاتيح (أطوال base64/Ed25519/bounds) — المعالجات نفسها تُختبر حيًا |
| tests/e2ee-vault-padding.test.ts | 12 | الخزنة: non-extractable KEK، padding، عزل namespace متعدد الحسابات، ترحيل plaintext القديم |
| tests/key-transparency.test.ts | 21 | رياضيات KT الخالصة: inclusion/consistency proofs بنمط RFC-6962، أوضاع توقيع الشاهد، التزامات الأسطول |
| tests/notification-privacy.test.ts | 6 | خصوصية الإشعارات: عنوان/نص عام فقط — لا اسم مرسل ولا محتوى في payload الـ push |
| tests/passkeys.test.ts | 20 | أمان WebAuthn الخادمي: رتابة العداد، TTL الـ challenge، رفض Origin/RP-ID مغاير |
| tests/security.test.ts | 13 | media tokens قصيرة العمر، تشفير snapshot في السكون، ترحيل token vault من localStorage |

**المجموع ~210 مع اللحاقات الداخلية (subtests/each loops) — مطابق لناتج vitest.**

## 3. الثوابت الخصائصية في fuzz harness (I1–I7) [مُتحقق — tests/e2ee-fuzz.test.ts:1-25]

- **I1** تسليم مرتَّب لكل (مرسل، جهاز مستقبل) يفك إلى النص الأصلي حرفيًا.
- **I2** تسليم خارج الترتيب ضمن نافذة ≤ MAX_SKIP/2 يفك عند وصوله.
- **I3** عبوات مزوّرة (ct/iv/hdr.n/hdr.pn/hdr.dh/ik) ⇒ خطأ من عائلة أخطاء E2EE، ورسالة صالحة لاحقة تفك سليماً (سلامة الحالة).
- **I4** إعادة تسليم envelope مستهلَك ⇒ plaintextه الأصلي أو خطأ — **أبداً** نص مخالف (النصوص علامات فريدة).
- **I5** `decryptMessage` لا يرمي أبدًا (كل نداء ملفوف؛ الرمي يفشل السيناريو).
- **I6** سقوط بعد MAX_SKIP ثم وصول متأخر ⇒ خطأ نظيف مع تعافٍ عضوي (bootstrap متأخر) أو بإعادة تهيئة جلسة أو rekey منتصف البث.
- **I7** عدم تلوث النصوص بين الجلسات (تساوي العلامة الفريدة لكل envelope id عند كل فك).
- قابلية إعادة الإنتاج: mulberry32 بذرة رئيسية ثابتة؛ سيناريو مفرد عبر `FUZZ_SEED=<index>` [الملف نفسه].
- **الصدق:** الملف يوثق فئة خلل معروفة (.concern "stale pre-rekey bootstrap rebuild") مع repro حتمي داخل الملف — أي أن الـ harness يكشف ثغراته بنفسه بدل إخفائها [مُتحقق — tests/e2ee-fuzz.test.ts:26-40].

## 4. البطاريات الحية (deploy/*.cjs) وآخر نتائجها من logs اليوم [مُتحقق — deploy/*.log بتاريخ 2026-11-17]

| السكربت | ما يتحقق منه | آخر نتيجة مسجلة |
|---|---|---|
| deploy/e2ee-verify.cjs | تسجيل هويتين حيًّا، إرسال 1:1، فك العميل، وفحص أن المخزن على الخادم ciphertext | 2026-11-17T20:04: **PASS-REG / PASS-DECRYPT / PASS-SERVER-CIPHER** |
| deploy/e2ee-multi-verify.cjs | 1:1 عبر ثلاث جلسات (A + جهازان لـ B): overlap التوزيع والفك | 2026-11-17T15:14: **FAIL-DEVICE1 / PASS-DEVICE2 / FAIL-MULTI-DEVICE / PASS-REPLY-FROM-DEVICE2** — fan-out متعدد الأجهزة **فاشل جزئيًا وقتها** (Overlap 6/6 لكن device1 لم يفك) |
| deploy/e2ee-group-verify.cjs | مجموعة حية: توزيع sender keys وde/فك في الاتجاهين + فحص مخزن الخادم | 2026-11-17T17:23: **FAIL-GROUP-DECRYPT / FAIL-GROUP-REVERSE / FAIL-server-check** (خلل `list.find is not a function` في الفحص نفسه) |
| deploy/cdp-ctrl-probe.cjs | نفس مسار ctrl عبر CDP لاحقًا | 2026-11-17T19:14: **PASS-GROUP-DECRYPT / PASS-GROUP-REVERSE** — إذ المجموعة أُصلحت بعد فشل الساعة 17:23 |
| deploy/passkeys-verify.cjs | احتفال WebAuthn حي بـ **virtual authenticator** (ctap2, resident key, UV): تسجيل ثم دخول passkey | 2026-11-17T18:55: **FAIL-REGISTER** (زر التسجيل لم يُنقر/نص النجاح لم يظهر) + **FAIL-STORED: none** ثم **PASS-PASSKEY-LOGIN** — نتيجة **متناقضة ظاهريًا**: دخول ناجح دون اعتماد مخزَّن ⇒ تشير إلى اعتماد مسجل مسبقًا على الحساب أو ثغرة في قياس التسجيل UI. **جواب سؤال التدقيق:** نعم، يوجد اختبار حي لـ WebAuthn بمصادقة افتراضية، وآخر نتيجة له فشل جزء التسجيل منه |

**الخلاصة الصادقة للبطاريات:** 1:1 ينجح رصينًا (ثلاث عقبات PASS اليوم)؛ multi-device فشل وقت 15:14 ولم يُعاد تشغيله بعد إصلاحات 19:14+؛ المجموعة فشلت 17:23 ونجحت 19:14؛ passkeys تسجيله غير مُثبت والدخول مُثبت.

## 5. حالة الإلزام في CI [مُتحقق — .github/workflows/verify.yml]

على **push وPR إلى master** (وليس schedule) يعمل بالترتيب: gitleaks (تاريخ كامل) → `npm run scan-secrets` → `npm audit --omit=dev --audit-level=high` → `npm run license-check` → typecheck → **npm test (210)** → build → sbom → SHA256SUMS/provenance artifacts. وجدول أسبوعي منفصل (dependency-audit-weekly) يشغّل audit + outdated report فقط. **كل البوابات أعلاه فاشلة فعليًا (gates) عدا outdated (معلوماتي).**

## 6. الثغرات الصادقة — ما الذي لا يُختبر (قائمة صريحة) [تحليل + مُتحقق]

1. **لا اختبار حي حالي لمرفقات وسائط المجموعات** — tests/e2ee-media.ts يختبر الوحدة، وdeploy لا يحتوي battery لمرفقات مجموعة فعلية عبر UI. لا ملف log لمرفقات حية.
2. **التدوير الطارئ الحي مع flag** — tests/e2ee-rotation.test.ts يغطي المحرك وحداتياً؛ لا يوجد deploy battery يستدعي emergencyRotate على بيئة prod، والـ flag (e2eeRekeyFlagKey في App.tsx:1763) غير مُختبر حيًّا.
3. **احتفال WebAuthn التسجيلي الحي** — آخر تشغيل حي فشل في جزء التسجيل (FAIL-REGISTER/FAIL-STORED)؛ خادمياً مغطى بـ 20 اختبار وحدة لكن الاحتفال الكامل register→login لم يثبت نجاحه حياً في اليوم المذكور.
4. **KT client verification** — كود ميت حالياً (غير مستورد؛ انظر THREAT_MODEL §2b)، فلا يوجد اختبار نهائي-to-end يكتشف تبديل هوية عبر UI.
5. **اختبار خادم لـ reset-database وdashboards** — مسارات requireAdmin غير مغطاة في vitest (تعتمد PG حي) ولا في deploy.
6. **multi-device fan-out** — آخر نتيجة حية FAIL ولم يُعاد التحقق بعد تغييرات اليوم؛ الغلاف الوحداتي موجود (e2ee-engine/e2e-pq بأجهزة متعددة) لكن الفشل الحي يشير إلى عقد توزيع لم يُختبر بعد على prod.
7. **CSRF/Headers/CSP** — لا اختبارات آلية للترويسات (فحص يدوي فقط في هذا التدقيق)؛ لا اختبار يعيد التحقق من ناتج CSP عند تغيير كود الخادم.
8. **migration legacy plaintext في vault** — مغطاة وحداتياً (e2ee-vault-padding) لكن لا اختبار ترحيل بيانات IndexedDB حقيقية من إصدارات سابقة.

## 7. التحقق الختامي

- بعد كتابة هذا الجرد أُعيد `npm test`: **15/15 ملفات، 210/210 اختبارات، green** — حالة المستودع لم تتغير (التغيير الوحيد: ثلاثة مستندات تحت docs/security) [مُنفَّذ].
