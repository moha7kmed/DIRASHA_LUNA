import { RealTimeSocketClient } from './socket_client.ts';

export class SocketManager {
  /**
   * Window-anchored singleton: immune to module duplication (double effect
   * runs / HMR re-imports could otherwise yield two live client instances and
   * thus two parallel sockets per tab — observed live as 2-3 sockets/page).
   */
  public static getInstance(): RealTimeSocketClient {
    const w = window as any;
    if (!w.__dirashaSocketClient) {
      w.__dirashaSocketClient = new RealTimeSocketClient();
    }
    return w.__dirashaSocketClient;
  }
}
