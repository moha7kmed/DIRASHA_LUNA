/**
 * Classic Credentials Auth — Roblox-style registration (phone-free era)
 * ----------------------------------------------------------------------
 *   POST /api/auth/register         { displayName, username, password, pin }
 *                                   → session + deviceKey (save it in the browser!)
 *   POST /api/auth/login            { username, password, deviceKey? }
 *   POST /api/auth/recover/request  { username, pin, deviceKey }  → resetToken
 *   POST /api/auth/recover/reset    { username, resetToken, newPassword }
 *   POST /api/auth/password/change  (auth) { currentPassword, newPassword }
 *   POST /api/auth/pin/change       (auth) { currentPin, newPin }
 *
 * Defence-in-depth:
 *   scrypt + salt + pepper (services/password.ts)
 *   progressive account lock (10 fails → 15 min) + dual-axis rate limiting
 *   device fingerprint + recovery PIN + one-time reset tokens (10-min TTL)
 *   full auth audit trail via db.logAuthAction
 */

import type { Express, Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import { db, RelationalDatabase, encryptSnapshot, decryptSnapshot } from '../database.ts';
import { clientIp, parseTrustedProxyHops, xffClientFromRight } from '../lib/trustedClientIp.ts';
// BATCH-6 (F-4): helpers extracted to the shared lib — re-exported for existing tests.
export { clientIp, parseTrustedProxyHops, xffClientFromRight };
import { AuthService } from '../services/auth.ts';
import { hashSecret, verifySecret, verifySecretDetailed, validatePasswordStrength, validatePin, digestToken } from '../services/password.ts';
import { createEnrollment, verifyTotp, currentTotpCounter } from '../services/totp.ts';
import { generateDeviceKey, verifyDeviceKey, generateResetToken, verifyResetToken } from '../services/recovery.ts';
import {
  validateUsername, validateDisplayName, sanitizeDisplayName,
  normalizeUsername, evaluateDisplayNameQuality,
} from '../../lib/identityUtils.ts';
import { redisCluster } from '../websocket/redis_client.ts';
import { logger } from '../logger.ts';
import { SecurityAlertsService } from '../services/securityAlerts.ts';
import type { RateLimitRuleName } from '../services/rate_limiter.ts';
import QRCode from 'qrcode';

interface ClassicAuthDeps {
  requireAuth: (req: Request, res: Response, next: NextFunction) => void;
  /** Project 5: table-driven distributed limiter — true = rate limited (deny). */
  checkLimit: (rule: RateLimitRuleName, key: string) => Promise<boolean>;
}

/**
 * AUTH-07 — hardened client-IP extraction for rate-limit keys + audit logs.
 *
 * X-Forwarded-For is an append-only hop list whose LEFTMOST value arrives
 * verbatim from the requester, so trusting the first entry lets any client
 * forge a fresh rate-limit bucket (or a fake IP in security alerts) with one
 * header. Only entries appended by TRUSTED proxies are meaningful.
 *
 * Trust model (fail-closed — an unknown IP source always yields a STRICTER
 * result, never a looser one):
 *   - TRUST_PROXY_HOPS unset or 0 (default): use req.socket.remoteAddress
 *     ONLY. The client-supplied XFF chain is never consulted. DEPLOYMENT
 *     NOTE: Render's edge proxy is exactly ONE trusted hop — set
 *     TRUST_PROXY_HOPS=1 in the production environment to restore real-client
 *     attribution (Render's proxy overwrites/appends the true client address
 *     as the last XFF entry, which is the only client-forge-free position).
 *   - TRUST_PROXY_HOPS=N (N ≥ 1): the client is the Nth entry from the RIGHT
 *     of the XFF chain (what the outermost trusted hop appended). Everything
 *     further left is client-forgeable and ignored.
 *   - Fail-closed fallbacks: XFF missing, shorter than the trusted-hop count,
 *     or an unparseable env value resolve to req.socket.remoteAddress (the
 *     TCP peer — the edge proxy's own address when behind one) or the shared
 *     'unknown' bucket, so attackers collapse into one shared budget instead
 *     of gaining per-IP buckets. A FULL-LENGTH chain under a configured
 *     TRUST_PROXY_HOPS is trusted even when the socket address is unavailable:
 *     the Nth-from-the-right entry was appended by the outermost trusted
 *     proxy, never by the client (deployment assumption: the app port is only
 *     reachable through the edge proxy — true on Render).
 *
 * Exported for pure-behavior tests (see tests/authclassic-hardening.test.ts).
 */
/** Up to 4 valid, actually-free alternative usernames for 409 responses. */
async function buildUsernameSuggestions(baseRaw: string): Promise<string[]> {
  const base = baseRaw.substring(0, 15);
  const templates = [`${base}_pro`, `${base}_net`, `${base}_app`, `${base}99`, `${base}_dev`, `${base}7`, `${base}_co`];
  const out: string[] = [];
  for (const t of templates) {
    if (out.length >= 4) break;
    const c = t.toLowerCase();
    // BATCH-1 review fix: never suggest operator handles (ADMIN_USERNAMES) or
    // previously-released reserved names.
    if (db.isAdminReservedName(c)) continue;
    if (validateUsername(c).isValid && !db.isUsernameReserved(c) && !(await db.getUserByUsername(c))) out.push(c);
  }
  let i = 1;
  while (out.length < 4 && i < 100) {
    const c = `${base}${i}`;
    if (db.isAdminReservedName(c)) { i++; continue; }
    if (validateUsername(c).isValid && !db.isUsernameReserved(c) && !(await db.getUserByUsername(c)) && !out.includes(c)) out.push(c);
    i++;
  }
  return out;
}

/** Deterministic dummy hash so "user not found" costs the same CPU as "wrong password" (anti-enumeration timing). */
let dummyHashPromise: Promise<string> | null = null;
function getDummyHash(): Promise<string> {
  if (!dummyHashPromise) dummyHashPromise = hashSecret('dirasha-timing-equalizer');
  return dummyHashPromise;
}

/**
 * Short-lived pending TOTP enrollments (process memory, 10-min TTL). The
 * secret becomes the account 2FA secret ONLY after the user proves possession
 * by submitting a valid code in the enable step.
 */
const pendingTotp = new Map<string, { encSecret: string; expires: number }>();
const PENDING_TOTP_TTL = 10 * 60 * 1000;

/**
 * HIBP Pwned Passwords k-anonymity check (OWASP Auth CS — breach screening).
 * Only a 5-char SHA-1 prefix leaves the server; the password never does.
 * Fails OPEN when the service is unreachable (availability first);
 * toggle: PASSWORD_BREACH_CHECK=false.
 */
const HIBP_ENABLED = process.env.PASSWORD_BREACH_CHECK !== 'false';
async function passwordPwned(password: string): Promise<number> {
  if (!HIBP_ENABLED) return 0;
  try {
    const sha1 = crypto.createHash('sha1').update(password, 'utf8').digest('hex');
    const prefix = sha1.slice(0, 5);
    const suffix = sha1.slice(5);
    const res = await fetch('https://api.pwnedpasswords.com/range/' + prefix, {
      signal: AbortSignal.timeout(1500),
      headers: { 'Add-Padding': 'true' },
    });
    if (!res.ok) return 0;
    const body = await res.text();
    for (const line of body.split('\n')) {
      const [suffixLine, countStr] = line.trim().split(':');
      if (suffixLine && suffixLine.toUpperCase() === suffix.toUpperCase()) {
        return parseInt(countStr, 10) || 0;
      }
    }
    return 0;
  } catch {
    return 0;
  }
}

export function registerClassicAuthRoutes(app: Express, deps: ClassicAuthDeps): void {
  const { requireAuth, checkLimit } = deps;

  // P1-hardening (F6): bind the refresh token to an HttpOnly cookie on every
  // session-issuing route (register/login/recover). Options mirror the
  // /api/auth/refresh route so rotation stays seamless. The token is NEVER
  // returned in the JSON body — the cookie is the only transport.
  const bindRefreshCookie = (res: Response, refreshToken: string): void => {
    res.cookie('refreshToken', refreshToken, {
      httpOnly: true,
      secure: true,
      sameSite: 'none', // required for the sandboxed-iframe preview environment
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });
  };

  /* ==================== REGISTER ==================== */
  app.post('/api/auth/register', async (req: Request, res: Response) => {
    try {
      const ip = clientIp(req);
      if (await checkLimit('auth:register:ip', ip)) {
        return res.status(429).json({ error: 'تم تجاوز حد إنشاء الحسابات من هذا الجهاز. حاول بعد ساعة.' });
      }

      const { displayName, username, password, pin } = req.body || {};
      if (!displayName || !username || !password || !pin) {
        return res.status(400).json({ error: 'جميع الحقول مطلوبة: اسم العرض، اسم المستخدم، كلمة المرور، ورمز الاسترجاع PIN.' });
      }

      // Display name — validate raw, then sanitize, then quality gate
      const rawName = String(displayName).trim();
      const nameCheck = validateDisplayName(rawName);
      if (!nameCheck.isValid) return res.status(400).json({ error: nameCheck.error, field: 'displayName' });
      const cleanDisplayName = sanitizeDisplayName(rawName);
      const quality = evaluateDisplayNameQuality(cleanDisplayName);
      if (!quality.isValid) return res.status(400).json({ error: quality.reason, field: 'displayName' });

      // Username — normalize → validate → explicit uniqueness check (409 + suggestions)
      const cleanUsername = normalizeUsername(String(username));
      const usernameCheck = validateUsername(cleanUsername);
      if (!usernameCheck.isValid) return res.status(400).json({ error: usernameCheck.error, field: 'username' });
      if (await db.getUserByUsername(cleanUsername)) {
        return res.status(409).json({
          error: 'USERNAME_TAKEN',
          message: `اسم المستخدم "@${cleanUsername}" محجوز بالفعل من مستخدم آخر. اختر اسماً آخر.`,
          suggestions: await buildUsernameSuggestions(cleanUsername),
          field: 'username',
        });
      }
      // Anti-impersonation: usernames released by a change stay reserved forever
      if (db.isUsernameReserved(cleanUsername)) {
        return res.status(409).json({
          error: 'USERNAME_RESERVED',
          message: `اسم المستخدم "@${cleanUsername}" محفوظ من استخدام سابق — اختر اسماً آخر.`,
          suggestions: await buildUsernameSuggestions(cleanUsername),
          field: 'username',
        });
      }

      // BATCH-1 (DIR-2026-001): operator handles (ADMIN_USERNAMES) are RESERVED
      // from public registration. They grant NO privilege — this closes the
      // claim-a-privileged-handle impersonation window entirely.
      if (db.isAdminReservedName(cleanUsername)) {
        return res.status(409).json({
          error: 'USERNAME_RESERVED',
          message: `اسم المستخدم "@${cleanUsername}" محجوز للإدارة — اختر اسماً آخر.`,
          suggestions: await buildUsernameSuggestions(cleanUsername),
          field: 'username',
        });
      }

      // Password + PIN policies
      const pwCheck = validatePasswordStrength(String(password), cleanUsername);
      if (!pwCheck.isValid) return res.status(400).json({ error: pwCheck.error, field: 'password' });
      const pwned = await passwordPwned(String(password));
      if (pwned > 0) {
        return res.status(400).json({
          error: 'كلمة المرور دي ظهرت في تسريبات معروفة. اختر كلمة مرور تانية غير مستخدمة.',
          field: 'password',
        });
      }
      const pinCheck = validatePin(String(pin));
      if (!pinCheck.isValid) return res.status(400).json({ error: pinCheck.error, field: 'pin' });

      // Hash secrets (scrypt — intentionally slow) and bind the device
      const [passwordHash, pinHash] = await Promise.all([hashSecret(String(password)), hashSecret(String(pin))]);
      const device = generateDeviceKey();

      let user;
      try {
        user = await db.createPasswordUser({
          username: cleanUsername, displayName: cleanDisplayName,
          passwordHash, pinHash, deviceKeyHash: device.hash,
        });
      } catch (e: any) {
        if (e?.code === '23505' || /unique|duplicate/i.test(e?.message || '')) {
          return res.status(409).json({
            error: 'USERNAME_TAKEN',
            message: `اسم المستخدم "@${cleanUsername}" محجوز بالفعل من مستخدم آخر. اختر اسماً آخر.`,
            suggestions: await buildUsernameSuggestions(cleanUsername),
            field: 'username',
          });
        }
        throw e;
      }

      const session = await AuthService.issueSession(user, req.headers['user-agent'] || 'unknown', ip);
      await db.logAuthAction(user.id, 'register', { ip, userAgent: req.headers['user-agent'] });
      redisCluster.publish('presence:broadcast', {
        event: 'user:created',
        payload: { user: { id: user.id, username: user.username, displayName: user.displayName, avatarUrl: user.avatarUrl, verified: user.verified, onlineStatus: 'online' } },
      }).catch(() => {});

      bindRefreshCookie(res, session.refreshToken);
      // F6 hardening: refresh token is delivered ONLY via the HttpOnly cookie
      // (bindRefreshCookie above) — never mirrored in the JSON body.
      res.status(201).json({
        user: session.user,
        accessToken: session.accessToken,
        sessionId: session.sessionId,
        deviceKey: device.key, // shown ONCE — client stores it as the recovery fingerprint
      });
    } catch (err: any) {
      logger.error('[Auth] register failed:', err?.message);
      res.status(500).json({ error: 'حدث خطأ أثناء إنشاء الحساب. حاول مرة أخرى.' });
    }
  });


  /* ==================== LOGIN ==================== */
  app.post('/api/auth/login', async (req: Request, res: Response) => {
    try {
      const ip = clientIp(req);
      if (await checkLimit('auth:login:ip', ip)) {
        return res.status(429).json({ error: 'محاولات دخول كثيرة من هذا الجهاز. انتظر عشر دقائق.' });
      }

      const { username, password, deviceKey } = req.body || {};
      if (!username || !password) {
        return res.status(400).json({ error: 'اسم المستخدم وكلمة المرور مطلوبان.' });
      }
      const cleanUsername = String(username).toLowerCase().trim();

      const user = await db.getUserByUsername(cleanUsername);
      const secrets = user ? await db.getUserSecrets(user.id) : null;

      // Account lock check (before any crypto work)
      if (secrets?.lockedUntil && new Date(secrets.lockedUntil).getTime() > Date.now()) {
        const mins = Math.ceil((new Date(secrets.lockedUntil).getTime() - Date.now()) / 60000);
        return res.status(423).json({ error: `الحساب مقفل مؤقتاً بسبب محاولات فاشلة متكررة. حاول بعد ${mins} دقيقة.`, locked: true });
      }

      // Timing-safe verification even for unknown accounts
      const hashToCheck = secrets?.passwordHash || (await getDummyHash());
      const pwResult = await verifySecretDetailed(String(password), hashToCheck);
      const passwordOk = pwResult.ok;

      if (!user || !secrets || !passwordOk) {
        if (user && secrets) {
          const r = await db.recordLoginResult(user.id, false);
          await db.logAuthAction(user.id, 'login_failed', { ip });
          // Security alerts engine (fire-and-forget, never blocks the response):
          // throttled to 1 push / user / 15 min, skipped for IPs that logged in
          // successfully before. Only fires for EXISTING usernames.
          void SecurityAlertsService.notifyFailedAttempts(user.id, ip).catch(() => {});
          if (r.lockedUntil) {
            const secs = Math.ceil((new Date(r.lockedUntil).getTime() - Date.now()) / 1000);
            return res.status(423).json({ error: `محاولات فاشلة متكررة. حاول بعد ${secs} ثانية.`, locked: true });
          }
          return res.status(401).json({ error: 'اسم المستخدم أو كلمة المرور غير صحيحة.' });
        }
        return res.status(401).json({ error: 'اسم المستخدم أو كلمة المرور غير صحيحة.' });
      }

      // OWASP: transparently re-hash legacy v1 credentials to v2 on successful auth
      if (pwResult.needsRehash) {
        await db.setUserPassword(user.id, await hashSecret(String(password)));
      }

      // ── TOTP 2FA challenge (MFA CS: strict attempts + replay-bound windows) ──
      // Backup codes: single-use recovery codes accepted in the same field.
      let replayCounter = 0;
      if (secrets.totpSecret) {
        const totpCode = String((req.body || {}).totpCode || '').trim();
        let totpOk = false;
        let usedBackup = false;
        try {
          const plainSecret = decryptSnapshot(secrets.totpSecret);
          const delta = verifyTotp(totpCode, plainSecret);
          if (delta !== null) {
            const used = currentTotpCounter() + delta;
            if (used > (secrets.totpLastCounter || 0)) {
              replayCounter = used;
              totpOk = true;
            }
          }
        } catch {
          totpOk = false;
        }
        // Backup-code fallback: single-use, hash-compared, consumed on success
        if (!totpOk && Array.isArray(secrets.totpBackupHashes) && secrets.totpBackupHashes.length > 0) {
          const normalized = totpCode.toUpperCase().replace(/[^A-Z0-9]/g, '');
          const supplied = digestToken(normalized);
          const matchIdx = secrets.totpBackupHashes.findIndex(h => h === supplied);
          if (matchIdx !== -1) {
            const remaining = secrets.totpBackupHashes.filter((_, i) => i !== matchIdx);
            await db.setTotpBackupHashes(user.id, remaining);
            totpOk = true;
            usedBackup = true;
          }
        }
        if (!totpOk) {
          await db.recordLoginResult(user.id, false);
          await db.logAuthAction(user.id, 'login_2fa_wrong_code', { ip });
          void SecurityAlertsService.notifyFailedAttempts(user.id, ip).catch(() => {});
          return res.status(401).json({ error: 'رمز التحقق بخطوتين غير صحيح.', code: 'totp_required' });
        }
        if (!usedBackup) {
          await db.setTotpSecret(user.id, secrets.totpSecret, replayCounter);
        }
        if (usedBackup && secrets.totpBackupHashes.length <= 1) {
          // last code consumed — warn on this response so the user regenerates
          res.setHeader('X-Backup-Codes-Exhausted', '1');
        }
      }

      await db.recordLoginResult(user.id, true);

      // Known-device detection (audit signal — not a login blocker)
      const knownDevice = secrets.deviceKeyHash && typeof deviceKey === 'string'
        ? verifyDeviceKey(deviceKey, secrets.deviceKeyHash)
        : false;

      let sessionBundle;
      try {
        sessionBundle = await AuthService.issueSession(user, req.headers['user-agent'] || 'unknown', ip);
      } catch (e: any) {
        return res.status(403).json({ error: e.message }); // banned
      }

      await db.logAuthAction(user.id, knownDevice ? 'login_known_device' : 'login_new_device', { ip, userAgent: req.headers['user-agent'] });

      // Session-meta capture: stamp ip + truncated UA (max 200) + last_active
      // onto the active session row (fire-and-forget — never delays the response).
      void db.updateSessionMeta(sessionBundle.sessionId, ip, String(req.headers['user-agent'] || 'unknown').slice(0, 200)).catch(() => {});
      // Security alerts engine (fire-and-forget): compares this login IP against
      // the previous successful-login baseline, pushes on a brand-new IP, and
      // records the 'login' baseline entry future logins compare against.
      void SecurityAlertsService.notifyNewLogin(user.id, {
        ip,
        userAgent: String(req.headers['user-agent'] || 'unknown'),
      }).catch(() => {});

      bindRefreshCookie(res, sessionBundle.refreshToken);
      // Security alert (Telegram/Signal parity): notify the account's devices
      // about a login from an UNRECOGNIZED device. The logging-in device itself
      // filters the toast client-side by sessionId.
      if (!knownDevice) {
        redisCluster.publish(`user:updates:${user.id}`, {
          event: 'security:new_login',
          payload: { sessionId: sessionBundle.sessionId, ip, time: new Date().toISOString(), userAgent: String(req.headers['user-agent'] || '').slice(0, 120) },
        }).catch(() => {});
      }
      // F6 hardening: refresh token is delivered ONLY via the HttpOnly cookie
      // (bindRefreshCookie above) — never mirrored in the JSON body.
      res.status(200).json({
        user: sessionBundle.user,
        accessToken: sessionBundle.accessToken,
        sessionId: sessionBundle.sessionId,
        knownDevice,
      });
    } catch (err: any) {
      logger.error('[Auth] login failed:', err?.message);
      res.status(500).json({ error: 'حدث خطأ أثناء تسجيل الدخول. حاول مرة أخرى.' });
    }
  });


  /* ==================== RECOVERY: device fingerprint + PIN → reset token ==================== */
  app.post('/api/auth/recover/request', async (req: Request, res: Response) => {
    try {
      const ip = clientIp(req);
      if (await checkLimit('auth:recover:ip', ip)) {
        return res.status(429).json({ error: 'محاولات استرجاع كثيرة. حاول بعد ساعة.' });
      }

      const { username, pin, deviceKey } = req.body || {};
      if (!username || !pin || !deviceKey) {
        return res.status(400).json({ error: 'اسم المستخدم ورمز PIN ومفتاح الجهاز (ملف dirasha-key.txt) كلها مطلوبة.' });
      }

      const cleanUsername = String(username).toLowerCase().trim();
      if (await checkLimit('auth:recover:user', cleanUsername)) {
        return res.status(429).json({ error: 'محاولات كثيرة على هذا الحساب. انتظر قليلاً.' });
      }

      const user = await db.getUserByUsername(cleanUsername);
      const secrets = user ? await db.getUserSecrets(user.id) : null;

      // Both factors must pass — failures are reported generically (no oracles)
      const pinOk = secrets?.pinHash ? await verifySecret(String(pin), secrets.pinHash) : false;
      const deviceOk = secrets?.deviceKeyHash ? verifyDeviceKey(String(deviceKey), secrets.deviceKeyHash) : false;

      if (!user || !secrets || !pinOk || !deviceOk) {
        await db.logAuthAction(user?.id || 'anonymous', 'recover_failed', { ip });
        return res.status(401).json({
          error: 'فشل التحقق من الهوية. تأكد من اسم المستخدم ورمز PIN وأنك على نفس الجهاز الذي سجّلت منه (ملف dirasha-key.txt).',
        });
      }

      const rt = generateResetToken();
      await db.storeResetToken(user.id, rt.hash, rt.expiresAt);
      await db.logAuthAction(user.id, 'recover_granted', { ip });

      res.status(200).json({ ok: true, resetToken: rt.token, expiresInSec: 600 });
    } catch (err: any) {
      logger.error('[Auth] recover/request failed:', err?.message);
      res.status(500).json({ error: 'حدث خطأ غير متوقع. حاول مرة أخرى.' });
    }
  });

  /* ==================== RECOVERY: burn reset token → new password ==================== */
  app.post('/api/auth/recover/reset', async (req: Request, res: Response) => {
    try {
      // BATCH-5 (DIR-2026-027): IP-throttled via the existing recover limiter
      // (token entropy carries the security load; this removes the last
      // unthrottled scrypt surface).
      if (await checkLimit('auth:recover:reset:ip', clientIp(req))) {
        return res.status(429).json({ error: 'محاولات كثيرة — حاول لاحقاً.' });
      }
      const { username, resetToken, newPassword } = req.body || {};
      if (!username || !resetToken || !newPassword) {
        return res.status(400).json({ error: 'بيانات ناقصة لإتمام إعادة التعيين.' });
      }
      const cleanUsername = String(username).toLowerCase().trim();
      const user = await db.getUserByUsername(cleanUsername);
      if (!user) {
        return res.status(401).json({ error: 'رابط الاسترجاع غير صالح أو انتهت صلاحيته.' });
      }

      const record = await db.getResetTokenRecord(user.id);
      if (!record?.hash || !record.expiresAt || !verifyResetToken(String(resetToken), record.hash, record.expiresAt)) {
        return res.status(401).json({ error: 'رابط الاسترجاع غير صالح أو انتهت صلاحيته. أعد طلب الاسترجاع.' });
      }

      const pwCheck = validatePasswordStrength(String(newPassword), cleanUsername);
      if (!pwCheck.isValid) {
        return res.status(400).json({ error: pwCheck.error, field: 'password' });
      }
      const pwnedReset = await passwordPwned(String(newPassword));
      if (pwnedReset > 0) {
        return res.status(400).json({
          error: 'كلمة المرور دي ظهرت في تسريبات معروفة. اختر كلمة مرور تانية غير مستخدمة.',
          field: 'password',
        });
      }

      const newHash = await hashSecret(String(newPassword));
      await db.setUserPassword(user.id, newHash);
      await db.clearResetToken(user.id);
      await db.revokeAllUserSessions(user.id); // security: kill every old session after a reset
      await db.setTotpSecret(user.id, null, 0); // recovery is the account master path — it also resets 2FA
      await db.logAuthAction(user.id, 'password_reset_via_recovery', { ip: clientIp(req) });

      const session = await AuthService.issueSession(user, req.headers['user-agent'] || 'unknown', clientIp(req));
      bindRefreshCookie(res, session.refreshToken);
      // F6 hardening: refresh token is delivered ONLY via the HttpOnly cookie
      // (bindRefreshCookie above) — never mirrored in the JSON body.
      res.status(200).json({
        ok: true,
        user: session.user,
        accessToken: session.accessToken,
        sessionId: session.sessionId,
      });
    } catch (err: any) {
      logger.error('[Auth] recover/reset failed:', err?.message);
      res.status(500).json({ error: 'حدث خطأ غير متوقع. حاول مرة أخرى.' });
    }
  });


  /* ==================== PASSWORD CHANGE (authenticated) ==================== */
  app.post('/api/auth/password/change', requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.userId;
      // Rate limit: 5 password changes per user per hour (brute-force / abuse guard).
      if (await checkLimit('auth:passwordchange:user', userId)) {
        return res.status(429).json({ error: 'عدد كبير من المحاولات، حاول لاحقاً.' });
      }
      const { currentPassword, newPassword } = req.body || {};
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ error: 'كلمة المرور الحالية والجديدة مطلوبتان.' });
      }
      const user = await db.getUserById(userId);
      const secrets = await db.getUserSecrets(userId);
      if (!user || !secrets?.passwordHash) {
        return res.status(404).json({ error: 'الحساب غير موجود.' });
      }
      const ok = await verifySecret(String(currentPassword), secrets.passwordHash);
      if (!ok) {
        await db.logAuthAction(userId, 'password_change_failed', { ip: clientIp(req) });
        return res.status(401).json({ error: 'كلمة المرور الحالية غير صحيحة.' });
      }
      const pwCheck = validatePasswordStrength(String(newPassword), user.username);
      if (!pwCheck.isValid) return res.status(400).json({ error: pwCheck.error });
      const pwnedChange = await passwordPwned(String(newPassword));
      if (pwnedChange > 0) {
        return res.status(400).json({ error: 'كلمة المرور دي ظهرت في تسريبات معروفة. اختر كلمة مرور تانية غير مستخدمة.' });
      }

      await db.setUserPassword(userId, await hashSecret(String(newPassword)));

      // Security parity with the recovery-reset path: a credential change must
      // invalidate every refresh session that was authenticated with the OLD
      // password. The device performing the change keeps its session so the
      // user is not logged out mid-action (mirrors /api/auth/sessions/revoke-others).
      //
      // Propagation model = recovery reset: sessions are marked revoked in the
      // user_sessions store, so /api/auth/refresh fails for those tokens and
      // each client is forced back to login. Additionally we publish
      // `session:revoke_others` on the user's private Redis channel — connected
      // sockets whose sessionId differs log out immediately (App.tsx handler).
      const activeSessions = await db.getUserSessions(userId);
      const currentSessionId = (req.headers['x-session-id'] as string) || '';
      let revokedSessions: number;
      if (currentSessionId && activeSessions.some(s => s.id === currentSessionId)) {
        await db.revokeOtherUserSessions(userId, currentSessionId);
        revokedSessions = Math.max(activeSessions.length - 1, 0);
        await redisCluster.publish(`user:updates:${userId}`, {
          event: 'session:revoke_others',
          payload: { currentSessionId },
        }).catch(() => {});
      } else {
        // Current session id is not available (client did not send x-session-id)
        // → revoke ALL sessions and force re-login on every device, including
        // the one that performed the change.
        await db.revokeAllUserSessions(userId);
        revokedSessions = activeSessions.length;
        await redisCluster.publish(`user:updates:${userId}`, {
          event: 'session:revoke_others',
          payload: { currentSessionId: '' }, // no session matches → every device logs out
        }).catch(() => {});
      }

      await db.logAuthAction(userId, 'password_changed', { ip: clientIp(req) });
      // Security alerts engine: push to all registered devices + live WS toast
      // on the user's private channel (fire-and-forget).
      void SecurityAlertsService.notifyPasswordChanged(userId).catch(() => {});
      res.status(200).json({
        ok: true,
        revokedSessions,
        message: 'تم تغيير كلمة المرور بنجاح وتم تسجيل الخروج من الأجهزة الأخرى.',
      });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  /* ==================== PIN CHANGE (authenticated) ==================== */
  app.post('/api/auth/pin/change', requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.userId;
      // AUTH-06: verifySecret on the current PIN runs full scrypt — a stolen
      // session could otherwise brute-force PINs at hash speed. Budget:
      // 5 attempts / 10 min per user+IP composite key (rule 'auth:pin:change').
      // The explicit per-call key guarantees per-user isolation: user B's
      // counter is a different bucket, and checkLimit only ever INCRs — a
      // success never resets anyone's window. Wrong current PINs count
      // against the budget because the INCR happens here, before verification.
      const ip = clientIp(req);
      if (await checkLimit('auth:pin:change', `${userId}:${ip}`)) {
        return res.status(429).json({ error: 'محاولات كثيرة على رمز PIN. حاول بعد عشر دقائق.' });
      }

      const { currentPin, newPin } = req.body || {};
      const pinCheck = validatePin(String(newPin || ''));
      if (!pinCheck.isValid) return res.status(400).json({ error: pinCheck.error });

      const secrets = await db.getUserSecrets(userId);
      if (!secrets?.pinHash) return res.status(404).json({ error: 'الحساب غير موجود.' });
      const ok = await verifySecret(String(currentPin || ''), secrets.pinHash);
      if (!ok) {
        // Minimal audit line — never the PIN value itself, only the outcome.
        await db.logAuthAction(userId, 'pin_change_failed', { ip });
        return res.status(401).json({ error: 'رمز PIN الحالي غير صحيح.' });
      }

      await db.setUserPin(userId, await hashSecret(String(newPin)));
      await db.logAuthAction(userId, 'pin_changed', { ip });
      res.status(200).json({ ok: true, message: 'تم تغيير رمز PIN بنجاح.' });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  /* ==================== DEVICES & ACTIVE SESSIONS (Signal/WhatsApp parity) ==================== */
  //
  // The sessions LIST and the bulk revoke-others endpoint already exist in
  // server.ts (GET /api/auth/sessions, POST /api/auth/sessions/revoke-others —
  // both rate-limited and emitting the same WS events). This route adds the
  // single-session revoke primitive used by ActiveSessionsPanel:
  //
  //   POST /api/auth/sessions/revoke { sessionId }
  //
  // Revocation model = the existing DELETE /api/auth/sessions/:sessionId path:
  // the user_sessions row is marked is_revoked so /api/auth/refresh fails for
  // that device's refresh token (client falls back to login on 401), and we
  // publish `session:revoked` on the user's private Redis channel — the
  // WebSocket server fans it out and App.tsx logs that device out instantly
  // when its sessionId matches. The current device is protected client-side
  // (UI disables the button) but the server still permits self-revocation so
  // "log me out everywhere" flows keep working.

  app.post('/api/auth/sessions/revoke', requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.userId;
      // Rate limit: 10 single-session revokes per user per hour (abuse guard).
      if (await checkLimit('auth:sessions:revoke', userId)) {
        return res.status(429).json({ error: 'عدد كبير من عمليات الإبطال. حاول بعد ساعة.' });
      }

      const sessionId = String((req.body || {}).sessionId || '').trim();
      if (!sessionId) {
        return res.status(400).json({ error: 'معرّف الجلسة (sessionId) مطلوب.' });
      }

      const result = await AuthService.revokeSessionById(userId, sessionId);
      if (result.status === 'not_found') {
        return res.status(404).json({ error: 'الجلسة غير موجودة أو تم إبطالها بالفعل.' });
      }
      if (result.status === 'forbidden') {
        return res.status(403).json({ error: 'لا يمكنك إبطال جلسة تابعة لحساب آخر.' });
      }

      // Live propagation: the targeted device receives `session:revoked` (FULL
      // session id so it can match its own) and logs out immediately; if its
      // sockets are offline the next refresh fails (row is revoked) and the
      // client logout-on-401 path kicks in.
      await redisCluster.publish(`user:updates:${userId}`, {
        event: 'session:revoked',
        payload: { sessionId: result.fullSessionId },
      }).catch(() => {});

      await db.logAuthAction(userId, 'session_revoked_remote', { ip: clientIp(req), sessionId });
      res.status(200).json({ ok: true, message: 'تم إبطال الجلسة وتسجيل الخروج من ذلك الجهاز.' });
    } catch (err: any) {
      logger.error('[Auth] sessions/revoke failed:', err?.message);
      res.status(500).json({ error: 'حدث خطأ أثناء إبطال الجلسة. حاول مرة أخرى.' });
    }
  });

  /* ==================== TOTP 2FA (setup / enable / disable / status) ==================== */

  app.get('/api/auth/2fa/status', requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.userId;
      const secrets = await db.getUserSecrets(userId);
      res.status(200).json({ enabled: Boolean(secrets?.totpSecret) });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.post('/api/auth/2fa/setup', requireAuth, async (req: Request, res: Response) => {
    try {
      const user = await db.getUserById(req.user!.userId);
      if (!user) return res.status(404).json({ error: 'الحساب غير موجود.' });
      const secrets = await db.getUserSecrets(user.id);
      if (secrets?.totpSecret) return res.status(409).json({ error: 'التحقق بخطوتين مفعّل بالفعل.' });
      if (pendingTotp.has(user.id)) pendingTotp.delete(user.id);
      const { secret, otpauthUri } = createEnrollment(user.username || user.id);
      const enc = encryptSnapshot(secret);
      pendingTotp.set(user.id, { encSecret: enc, expires: Date.now() + PENDING_TOTP_TTL });
      const qrDataUrl = await QRCode.toDataURL(otpauthUri);
      res.status(200).json({ secret, otpauthUri, qrDataUrl, expiresInSec: 600 });
    } catch (err: any) {
      res.status(500).json({ error: 'تعذر بدء تفعيل التحقق بخطوتين. حاول مرة أخرى.' });
    }
  });

  app.post('/api/auth/2fa/enable', requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.userId;
      const code = String((req.body || {}).code || '');
      if (!/^\d{6}$/.test(code)) return res.status(400).json({ error: 'أدخل رمزاً من 6 أرقام.' });
      const pending = pendingTotp.get(userId);
      if (!pending || pending.expires < Date.now()) {
        pendingTotp.delete(userId);
        return res.status(409).json({ error: 'انتهت صلاحية جلسة التفعيل. ابدأ التفعيل من جديد.' });
      }
      const plainSecret = decryptSnapshot(pending.encSecret);
      const delta = verifyTotp(code, plainSecret);
      if (delta === null) return res.status(401).json({ error: 'الرمز غير صحيح. تأكد من تطابق وقت جهازك.' });
      await db.setTotpSecret(userId, pending.encSecret, currentTotpCounter() + delta);
      pendingTotp.delete(userId);
      // Signal/WhatsApp parity: 10 single-use backup codes, shown ONCE.
      // Stored hashed via digestToken — plaintext never touches the DB.
      const backupCodes: string[] = [];
      for (let i = 0; i < 10; i++) {
        backupCodes.push(crypto.randomBytes(4).toString('hex').toUpperCase().replace(/(.{4})/, '$1-'));
      }
      // Hash the STRIPPED form — the login path strips separators before comparing
      await db.setTotpBackupHashes(userId, backupCodes.map(c => digestToken(c.replace(/[^A-Z0-9]/g, ''))));
      await db.logAuthAction(userId, '2fa_enabled', { ip: clientIp(req) });
      res.status(200).json({ ok: true, message: 'تم تفعيل التحقق بخطوتين.', backupCodes });
    } catch (err: any) {
      res.status(500).json({ error: 'تعذر تفعيل التحقق بخطوتين.' });
    }
  });

  app.post('/api/auth/2fa/disable', requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.userId;
      // BATCH-5 (DIR-2026-027): a stolen session must not get unlimited
      // password guesses against the 2FA disable gate — critical-class limit,
      // INCR before verify (same semantics as AUTH-06).
      if (await checkLimit('auth:pin:change', `${userId}:2fa-disable:${clientIp(req)}`)) {
        // BATCH-6 (F-6): NO audit row on the throttle path — INCR-before-verify
        // makes every spam request a 429, and an awaited DB write per 429 was
        // an audit-flood vector. Real password failures still audit below.
        return res.status(429).json({ error: 'محاولات كثيرة — حاول بعد 10 دقائق.' });
      }
      const password = String((req.body || {}).password || '');
      const secrets = await db.getUserSecrets(userId);
      if (!secrets?.totpSecret) return res.status(409).json({ error: 'التحقق بخطوتين غير مفعّل.' });
      const ok = await verifySecret(password, secrets.passwordHash || '');
      if (!ok) {
        await db.logAuthAction(userId, '2fa_disable_failed', { ip: clientIp(req) });
        return res.status(401).json({ error: 'كلمة المرور غير صحيحة.' });
      }
      await db.setTotpSecret(userId, null, 0);
      pendingTotp.delete(userId);
      await db.logAuthAction(userId, '2fa_disabled', { ip: clientIp(req) });
      res.status(200).json({ ok: true, message: 'تم إيقاف التحقق بخطوتين.' });
    } catch (err: any) {
      res.status(500).json({ error: 'تعذر إيقاف التحقق بخطوتين.' });
    }
  });
}

