# Security Specification: dirasha Firestore Rules

## Data Invariants

1. **User Identity Isolation**: A user can only write to their own profile at `/users/{userId}`.
2. **Chat Membership Integrity**: Users can only see or join chats if their UID is included in the `memberIds` array.
3. **Message Sender Verification**: A message can only be created at `/chats/{chatId}/messages/{msgId}` if:
   - The user is currently a member of the `/chats/{chatId}` thread.
   - The message's `senderId` matches the authenticated `uid`.
4. **Immutability of Key Metadata**: Fields such as `createdAt` and `senderId` cannot be updated once a message or chat is initialized.
5. **No Blind Global Reads**: We block complete unrestricted list reads to `users` and `chats` collections without filters on keys.

## The "Dirty Dozen" Payloads

1. **Spoofed User Registration**: Attempt to write another user's profile at `/users/malicious_id` with owner authenticated as `victim_id`.
2. **Elevated Privileges profile update**: Non-admin attempts to grant themselves privileges or access other private user segments.
3. **Write with Unverified Email**: Attempt to create a profile when `email_verified` is false.
4. **Unauthorized Chat Creation**: Authenticated user trying to create a chat with someone else as the owner and themselves excluded from `memberIds`.
5. **Spy Reading Direct Chat**: Eavesdropper trying to fetch `/chats/{chatId}` when they are not part of `memberIds`.
6. **Impersonated Message Sent**: User `A` trying to send a message where `senderId` is set to user `B`.
7. **Orphaned Message injection**: Sending a message inside a chat that doesn't exist or where the user is not a member.
8. **Shadow Field Injection**: Creating a user profile containing undocumented properties not listed in the whitelist.
9. **Timestamp Spoofing**: Setting client-chosen creation clocks in the future instead of using `request.time`.
10. **State Corruption on receipts**: Attempting to set someone else's incoming message state back to 'unread' after it is marked 'read'.
11. **ID Poisoning Attack**: Attempting to create a chat thread with a 500-character junk string as the document ID.
12. **Blind Collection Scrapes**: Attempting to pull all chats globally without querying for membership inside `memberIds`.

## Target Rules Architecture

All logic must fail safe, checking:
1. `request.auth != null`
2. `request.auth.token.email_verified == true`
3. Standalone `isValid[Entity]` validation function checks on keys, types, and values.
