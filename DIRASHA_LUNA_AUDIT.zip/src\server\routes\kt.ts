/**
 * Key Transparency routes (Project 2 — AKD-lite per
 * docs/KEY-TRANSPARENCY-DESIGN-ar.md).
 *
 *   GET  /api/e2ee/kt/root              → current signed snapshot (witness checkpoint)
 *   GET  /api/e2ee/kt/proof/:userId     → inclusion + consistency proofs for a peer's
 *                                         key commitment (?sinceVersion=N anchors the
 *                                         client's last-seen snapshot for consistency)
 *   POST /api/e2ee/kt/replay-detect     → admin-only: record a client verification
 *                                         failure (fork/tamper/signature mismatch) and
 *                                         return the recent mismatch audit log
 *
 * Client contract: src/lib/kt-contract.ts (types + verification algorithm).
 * Proof math + snapshot signing: src/server/services/key_transparency.ts.
 *
 * Snapshot signer: started here on registration (5-min interval, dirty-only,
 * best-effort). UNVERIFIED witness mode: when KT_SIGNING_KEY is absent the
 * snapshot signature is '' — clients must warn 'unverified' (documented
 * honest mode, never silently trusted).
 */

import type { Express, NextFunction, Request, Response } from 'express';
import { db, pool } from '../database.ts';
import { logger } from '../logger.ts';
import {
  appendKeyChange,
  getCurrentSnapshot,
  getKtProof,
  startKtSnapshotScheduler,
  stopKtSnapshotScheduler,
} from '../services/key_transparency.ts';
import type { KtMismatchReport } from '../../lib/kt-contract.ts';

export interface KtRouteDeps {
  requireAuth: (req: Request, res: Response, next: NextFunction) => void;
}

const USER_ID_RE = /^[A-Za-z0-9_-]{1,128}$/;

/* ===================== Route registration ===================== */

export function registerKtRoutes(app: Express, deps: KtRouteDeps): void {
  const { requireAuth } = deps;

  /**
   * Admin gate mirroring server.ts's requireAdmin. BATCH-1 (DIR-2026-001):
   * identity = the DURABLE role read fresh from the DB — no username matching,
   * no promotion side effects. server.ts does not export the middleware, so
   * the pattern is replicated here 1:1 — any change there must be mirrored.
   */
  const requireAdmin = (req: Request, res: Response, next: NextFunction) => {
    requireAuth(req, res, async () => {
      try {
        const u = await db.getUserById(req.user!.userId);
        const callerRole = u?.role || 'user';
        if (callerRole === 'admin' || callerRole === 'developer') {
          next();
        } else {
          logger.warn(`[KT] unauthorized replay-detect attempt by ${req.user?.username || 'none'} (role: ${callerRole})`);
          res.status(403).json({ error: '403 Forbidden: Developer privileges required.' });
        }
      } catch (err) {
        logger.error(`[KT] requireAdmin DB lookup failed: ${err?.message || err}`);
        res.status(503).json({ error: 'Authorization unavailable.' });
      }
    });
  };

  /** Light in-process throttle for the proof endpoint (60/min/user). */
  const proofHits = new Map<string, { count: number; resetAt: number }>();
  const PROOF_LIMIT = 60;
  const PROOF_WINDOW_MS = 60 * 1000;
  setInterval(() => proofHits.clear(), PROOF_WINDOW_MS).unref?.();

  function proofLimitHit(userId: string): boolean {
    const now = Date.now();
    const rec = proofHits.get(userId);
    if (!rec || rec.resetAt <= now) {
      proofHits.set(userId, { count: 1, resetAt: now + PROOF_WINDOW_MS });
      return false;
    }
    rec.count += 1;
    return rec.count > PROOF_LIMIT;
  }

  /* ── Current signed snapshot ── */
  app.get('/api/e2ee/kt/root', requireAuth, async (_req: Request, res: Response) => {
    try {
      res.status(200).json(await getCurrentSnapshot());
    } catch (err: any) {
      logger.error('[KT] /root failed:', err?.message);
      res.status(500).json({ error: 'KT snapshot unavailable.' });
    }
  });

  /* ── Inclusion + consistency proofs for a peer's commitment ── */
  app.get('/api/e2ee/kt/proof/:userId', requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = req.params.userId;
      if (typeof userId !== 'string' || !USER_ID_RE.test(userId)) {
        return res.status(400).json({ error: 'userId must be 1-128 url-safe characters ([A-Za-z0-9_-]).' });
      }
      const callerId = req.user?.userId;
      if (typeof callerId === 'string' && proofLimitHit(callerId)) {
        return res.status(429).json({ error: 'KT proof rate limit exceeded.' });
      }
      let sinceVersion: number | undefined;
      if (req.query.sinceVersion !== undefined) {
        const parsed = Number(req.query.sinceVersion);
        if (!Number.isInteger(parsed) || parsed < 0) {
          return res.status(400).json({ error: 'sinceVersion must be a non-negative integer.' });
        }
        sinceVersion = parsed;
      }
      res.status(200).json(await getKtProof(userId, sinceVersion));
    } catch (err: any) {
      logger.error('[KT] /proof failed:', err?.message);
      res.status(500).json({ error: 'KT proof unavailable.' });
    }
  });

  /* ── Admin audit log of client mismatch reports (fork/tamper detection) ── */
  app.post('/api/e2ee/kt/replay-detect', requireAuth, requireAdmin, async (req: Request, res: Response) => {
    try {
      const reporterId = req.user?.userId;
      if (typeof reporterId !== 'string' || !USER_ID_RE.test(reporterId)) {
        return res.status(403).json({ error: '403 Forbidden: Developer privileges required.' });
      }
      const { subjectUserId, expectedRoot, observedRoot, detail } = req.body || {};
      const cleanSubject =
        typeof subjectUserId === 'string' && USER_ID_RE.test(subjectUserId) ? subjectUserId : null;
      const cleanRoot = (v: unknown): string | null =>
        typeof v === 'string' && /^[0-9a-f]{0,128}$/.test(v) ? v : null;
      const cleanDetail =
        typeof detail === 'string' && detail.length > 0 ? detail.slice(0, 2000) : null;

      const insert = await pool.query(
        `INSERT INTO kt_mismatch_reports (reporter_id, subject_user_id, expected_root, observed_root, detail)
         VALUES ($1, $2, $3, $4, $5) RETURNING id, created_at`,
        [reporterId, cleanSubject, cleanRoot(expectedRoot), cleanRoot(observedRoot), cleanDetail],
      );
      logger.warn(
        `[KT] mismatch report #${insert.rows[0].id} recorded by ${reporterId}` +
          (cleanSubject ? ` (subject: ${cleanSubject})` : ''),
      );

      const recent = await pool.query(
        `SELECT id, reporter_id, subject_user_id, expected_root, observed_root, detail, created_at
           FROM kt_mismatch_reports ORDER BY created_at DESC LIMIT 100`,
      );
      const reports: KtMismatchReport[] = recent.rows.map((r: any) => ({
        id: Number(r.id),
        reporterId: String(r.reporter_id),
        subjectUserId: r.subject_user_id ? String(r.subject_user_id) : null,
        expectedRoot: r.expected_root ? String(r.expected_root) : null,
        observedRoot: r.observed_root ? String(r.observed_root) : null,
        detail: r.detail ? String(r.detail) : null,
        createdAt: new Date(r.created_at).toISOString(),
      }));
      res.status(201).json({ recorded: Number(insert.rows[0].id), reports });
    } catch (err: any) {
      logger.error('[KT] /replay-detect failed:', err?.message);
      res.status(500).json({ error: 'Failed to record mismatch report.' });
    }
  });

  /* Best-effort snapshot signer (dirty-only, 5-min cadence, loud logging). */
  startKtSnapshotScheduler();
}

/* Re-export for the lead's wire-up in routes/e2ee.ts (see service header). */
export { appendKeyChange };
