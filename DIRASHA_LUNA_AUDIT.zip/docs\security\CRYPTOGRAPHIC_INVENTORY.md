# CRYPTOGRAPHIC INVENTORY — Dirasha E2EE (تدقيق أمني، قراءة فقط)

> **حالة التدقيق:** قراءة فقط (read-only audit). كل `file:line` أدناه جاء من grep/قراءة فعلية نفّذها المدقّق على المستودع بتاريخ 2026-11-17.
> **مصدر الإصدارات:** `package-lock.json` (وليس الافتراضات) — تم فحصه بـ node.
> **قاعدة التصنيف:** كل بند يحمل واحدة من: `VERIFIED` / `PARTIALLY VERIFIED` / `UNVERIFIED` / `NOT IMPLEMENTED` / `NOT APPLICABLE` / `FAILED`.

## 0. ملخص إصدارات المكتبات (من package-lock.json — VERIFIED)

| المكتبة | الإصدار المثبَّت | المصدر |
|---|---|---|
| `@noble/curves` | **1.9.7** | package-lock.json (فحص node: `lock.packages['node_modules/@noble/curves'].version`) |
| `@noble/hashes` | **1.8.0** | package-lock.json |
| `@noble/ciphers` | **1.3.0** | package-lock.json |
| `@noble/post-quantum` | **0.7.1** | package-lock.json |

الاعتمادات معلنة في `package.json` (`dependencies`): `@noble/ciphers ^1.3.0`, `@noble/curves ^1.9.7`, `@noble/hashes ^1.8.0`, `@noble/post-quantum ^0.7.1` — **VERIFIED**.
لا توجد استخدام لأي مكتبة تشفير أخرى في الوحدة (`src/lib/e2ee/*.ts` تعتمد على `@noble/*` فقط + `globalThis.crypto` + `Buffer`) — **VERIFIED** (فحص imports).

---

## 1. X25519 (Diffie–Hellman على Curve25519)

- **المكتبة/الإصدار:** `@noble/curves@1.9.7`, الاستيراد `src/lib/e2ee/crypto.ts:19` — `import { x25519, ed25519 } from '@noble/curves/ed25519';` — **VERIFIED**.
- **الاستخدامات الفعلية (كلها من نفس الملف):**
  - توليد أزواج المفاتيح (identity / SPK / OPK / ratchet / ephemeral): `crypto.ts:167-170` — `generateX25519()` عبر `x25519.utils.randomPrivateKey()`. **VERIFIED**.
  - ECDH: `crypto.ts:178-180` — `x25519Shared(priv, pub)` عبر `x25519.getSharedSecret`. **VERIFIED**.
  - X3DH DH1..DH4 (المُبادِر): `engine.ts:696-706` (`IK_A×SPK_B`, `EK_A×IK_B`, `EK_A×SPK_B`, `EK_A×OPK_B`). **VERIFIED**.
  - X3DH DH1..DH4 (المستجيب): `engine.ts:792-800`. **VERIFIED**.
  - DHRatchet: `engine.ts:851, 860` و`engine.ts:979` (خطوة الإرسال الأولى). **VERIFIED**.
- **ما تحميه:** أساس كل مفاتيح الجلسات 1:1 (SK عبر HKDF)، وسلسلة Double Ratchet.
- **الحدود/القوة:** مفتاح 32 بايت، إخراج DH 32 بايت (`KEY_BYTES`, `crypto.ts:70`). `x25519.getSharedSecret` يرمي على المفاتيح غير الصالحة (نقاط low-order تُرفض في noble 1.x) — **PARTIALLY VERIFIED** (سلوك الرفض موثّق في المكتبة لكن لم يُختبر صراحة داخل هذا المشروع؛ اختبارات low-order غير موجودة في `tests/`).

## 2. Ed25519 (التوقيع)

- **المكتبة/الإصدار:** `@noble/curves@1.9.7`, `crypto.ts:19`. — **VERIFIED**.
- **الاستخدامات:**
  - توليد مفتاح توقيع الهوية: `crypto.ts:172-175` (`generateEd25519`).
  - توقيع SPK: `engine.ts:471` — `ed25519Sign(utf8Encode(SPK_SIG_PREFIX + b64encode(spk.pub)), ...)` حيث `SPK_SIG_PREFIX = 'DirashaSPK-v1:'` (`crypto.ts:53`). **VERIFIED**.
  - التحقق من توقيع SPK للطرف الآخر: `engine.ts:663-665` — `ed25519Verify(sigBytes, ...)` مع فحص طول 64 بايت. **VERIFIED**.
  - توقيع PQ/SPK المركّب: `engine.ts:505-508` — `ed25519Sign(PQ_SPK_SIG_PREFIX + spk.pub + pq.pub)`. التحقق من جهة العميل: `engine.ts:683-686`. **VERIFIED**.
- **ما تحميه:** ربط مفاتيح SPK وPQ prekey بهوية الطرف (منع استبدال prekey من الخادم/MITM ما لم يُستبدل الهويّة نفسها).
- **الحدود:** التحقق inside try/catch يُرجع `false` عند أي استثناء (`crypto.ts:187-193`) — سلوك fail-closed. **VERIFIED**.

## 3. ML-KEM-768 (FIPS-203 — Post-Quantum KEM)

- **المكتبة/الإصدار:** `@noble/post-quantum@0.7.1`, `crypto.ts:25` — `import { ml_kem768 } from '@noble/post-quantum/ml-kem.js';`. — **VERIFIED**.
- **الاستخدامات:**
  - توليد PQ prekey لكل جهاز: `crypto.ts:205-208` (`generateMlKem768`)، يُستدعى من `engine.ts:366-373` (`ensurePqPrekey`). **VERIFIED**.
  - Encapsulation (المُبادِر): `crypto.ts:215-218`، مستخدمة في `engine.ts:690-692`. **VERIFIED**.
  - Decapsulation (المستجيب): `crypto.ts:227-229`، مستخدمة في `engine.ts:782`. **VERIFIED**.
- **أحجام الأسلاك (من `ml_kem768.lengths`, `crypto.ts:79-83`):** public 1184B, ciphertext 1088B, shared secret 32B. الفحوص الصارمة: `engine.ts:677` (طول pub == 1184), `engine.ts:262` و`engine.ts:779` (طول pqCt == 1088). **VERIFIED**.
- **منع الهبوط الصامت (downgrade):**
  - بوابة البادئة: `engine.ts:668-693` — `device.pq === true` ⇒ إلزامي hybrid؛ أي نقص/فشل يرمي `TamperedError` ولا يوجد مسار كلاسيكي احتياطي (تعليق صريح `engine.ts:646-653`). **VERIFIED**.
  - بوابة الاستجابة: `engine.ts:774-783` — مغلف `pq:1` بدون PQ priv محلي ⇒ `DecryptFailedError` (fail closed). **VERIFIED**.
  - تمييز flag: `engine.ts:260-265` — `pqCt` بدون `pq:1` ⇒ `TamperedError`. **VERIFIED**.
- **ما تحميه:** سرية الحصة الأولى ضد خصم كمومي مستقبلي (harvest-now-decrypt-later) للجلسات المُنشأة hybrid.
- **الحد:** PQ prekey **طويل الأمد** (لا دوران لها إلا عبر `emergencyRotate`, `engine.ts:1437` الذي يحذف `PQ_PREKEY_KV`) — لا يوجد دوران دوري مجدول. **PARTIALLY VERIFIED** (الحذف عند الطوارئ موجود؛ الدورة الدورية غير موجودة).
- **الاختبار:** `tests/e2e-pq.test.ts` موجود (لم يُنفَّذ في هذا التدقيق كجزء من التحقق المستقل — انظر E2EE_AUDIT.md §d). **PARTIALLY VERIFIED**.

## 4. ChaCha20-Poly1305 (AEAD)

- **المكتبة/الإصدار:** `@noble/ciphers@1.3.0`, `crypto.ts:23` — `import { chacha20poly1305 } from '@noble/ciphers/chacha';`. — **VERIFIED**.
- **الاستخدامات:**
  - رسائل 1:1 (Double Ratchet): `crypto.ts:284-291` (`aeadSeal`/`aeadOpen`)، مُستخدمة في `engine.ts:997` (seal) و`engine.ts:892` (open). nonce عشوائي 12B لكل رسالة (`engine.ts:991`). — **VERIFIED**.
  - رسائل المجموعات: `group.ts:275` (seal) و`group.ts:341` (open). — **VERIFIED**.
  - المرفقات: `media.ts:198` (seal) و`media.ts:228` (open). — **VERIFIED**.
  - النسخ الاحتياطية: `backup.ts:262` (seal) و`backup.ts:366` (open). — **VERIFIED**.
- **المعاملات:** مفتاح 32B، nonce 12B (`NONCE_BYTES`, `crypto.ts:68`)، tag 16B، AAD إلزامي.
- **AAD (سلسلة واحدة):** `aadString(v, ik, dh, pn, n)` — `crypto.ts:277-279`، القالب `AAD_TEMPLATE = '${v}|${ik}|${dh}|${pn}|${n}'` (`crypto.ts:64`). يُبنى في التشفير `engine.ts:993` وفي فك التشفير `engine.ts:889` عبر نفس الدالة. **VERIFIED** (سلسلة مصدر واحدة — grep AAD_TEMPLATE).
- **AAD للمجموعات:** `groupAad(v, groupId, skId, n)` — `group.ts:121-123`. **VERIFIED**.
- **AAD للمرفقات:** `mediaAad(attId) = 'DirashaMedia-v1|' + attId` — `media.ts:137-139`. **VERIFIED**.
- **AAD للنسخة الاحتياطية:** `'DirashaBackup-v1|' + saltB64` — `backup.ts:213-215`. **VERIFIED**.
- **الحد:** nonce عشوائي 12B لكل رسالة (وليس عدّادًا) — في Double Ratchet المفتاح أحادي الاستخدام (mk لكل n) فالخطر نظري للغاية؛ لكن في **مفاتيح المرفقات والنسخ الاحتياطية** المفتاح يُولّد مرة واحدة مع nonce واحد — **VERIFIED** كاستخدام آمن فعليًا (مفتاح واحد + nonce واحد لكل blob).

## 5. HKDF-SHA256

- **المكتبة/الإصدار:** `@noble/hashes@1.8.0`, `crypto.ts:20` (`hkdf`). — **VERIFIED**.
- **جميع مواضع الاستخدام + info strings (لا تكرار inline):**

| الاستخدام | الموضع | salt | info | الطول |
|---|---|---|---|---|
| KDF_RK (جذر Ratchet) | `crypto.ts:237-240` | المفتاح الجذري الحالي (`rk`) | `DirashaRoot-v1` (`crypto.ts:43`) | 64B (rk+ck) |
| X3DH SK كلاسيكي | `crypto.ts:257-259` | zeros(32) | `DirashaX3DH-v1` (`crypto.ts:45`) | 32B |
| X3DH SK هجين (PQXDH) | `crypto.ts:270-272` | zeros(32) | `DirashaX3DH-PQ-v1` (`crypto.ts:51`) | 32B |
| سلسلة المجموعة (stateless) | `group.ts:130-132` | zeros(32) | `DirashaGroupChain-v1|<n>` (`group.ts:56`) | 32B |
| مفتاح المرفق | `media.ts:132-134` | zeros(32) | `DirashaMedia-v1` (`media.ts:45`) | 32B |
| مفتاح النسخة الاحتياطية | `backup.ts:208-210` | zeros(32) | `DirashaBackup-v1` (`backup.ts:70`) | 32B |

- **تركيب IKM الهجين (PQXDH) — VERIFIED بالكود:** `engine.ts:703-709` (المُبادِر) و`engine.ts:797-803` (المستجيب): `F || DH1 || DH2 || DH3 [|| DH4] || PQ_SS` حيث `F = ZERO32` مع OPK و`FF32` بدونه (`crypto.ts:74-76`) — المستجيب يعكس الترتيب بدقة (نفس ترتيب DH1..DH4 بنفس أدوار المفاتيح). **VERIFIED**.
- **تمييز info الكلاسيكي عن الهجين** (`DirashaX3DH-v1` مقابل `DirashaX3DH-PQ-v1`) يجعل SK في الحالتين مستقلين حسابيًا — **VERIFIED** كآلية منع هبوط ضمنية على مستوى KDF.

## 6. HMAC-SHA256

- **المكتبة/الإصدار:** `@noble/hashes@1.8.0`, `crypto.ts:21`. — **VERIFIED**.
- **الاستخدام:** KDF_CK لسلسلة الرسائل: `crypto.ts:245-250` — `mk = HMAC(ck, 0x01)`, `ck' = HMAC(ck, 0x02)`. مستخدمة في `engine.ts:836` (skip keys), `engine.ts:881`, `engine.ts:988`. **VERIFIED**.
- **ملاحظة:** الحدّ الأعلى للرسائل المُخطاة `MAX_SKIP = 2000` (`crypto.ts:66`, مفروض في `engine.ts:834`) مع إخلاء الأقدم (`engine.ts:840-841`). **VERIFIED**.

## 7. scrypt (KDF عبارة النسخ الاحتياطية)

- **المكتبة/الإصدار:** `@noble/hashes@1.8.0`, `backup.ts:52` (`import { scrypt } from '@noble/hashes/scrypt';`). — **VERIFIED**.
- **الاستخدام:** `backup.ts:193-200` — `scrypt(UTF8(passphrase), salt, { N: 2**15, r: 8, p: 1, dkLen: 32 })`. الثوابت معلنة `backup.ts:95-99`. **VERIFIED**.
- **salt عشوائي 16B لكل نسخة:** `backup.ts:86` (`BACKUP_SALT_BYTES = 16`) و`backup.ts:256` (`randomBytes(BACKUP_SALT_BYTES)`). فحص الطول عند الفتح: `backup.ts:351-353`. **VERIFIED**.
- **ما تحميه:** عبارة النسخة الاحتياطية (v1 محادثة واحدة / v2 الحساب كامل) — ciphertext ChaCha20-Poly1305.
- **الحد:** N=2^15 (~32MB) معقول لكنه أقل من توصية OWASP الأحدث لـ scrypt مقابل مهاجم GPU مخصص؛ مقبول لعبارة مستخدم. **PARTIALLY VERIFIED** (الثابت موجود؛ لا اختبار قوة عبارة).
- **hint:** `backup.ts:228-230` — b64(أول 8B من sha256(passKey)) معلن داخل الملف؛ موثّق صراحة أنه **بصمة راحة وليست حدًا أمنيًا** (`backup.ts:218-227`). **VERIFIED** (التصنيف مطابق للكود).

## 8. AES-GCM-256 (خزنة المفاتيح المحلية — Vault)

- **المكتبة/الإصدار:** **WebCrypto** (`crypto.subtle`) — ليس noble. `vault.ts:96-100` — `crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, false, ['encrypt','decrypt'])` — مفتاح **غير قابل للاستخراج** (`extractable: false`). **VERIFIED**.
- **الاستخدام:**
  - التشفير: `vault.ts:148-161` — AES-GCM مع IV عشوائي 12B (`IV_BYTES = 12`, `vault.ts:34`; `crypto.getRandomValues` في `vault.ts:150`).
  - فك التشفير: `vault.ts:163-184`؛ إدخال غير قابل للفك ⇒ يُعامل كمفقود (`vault.ts:177-183`).
  - التخزين: `{ v:'enc1', iv, ct }` (`ENC_VERSION = 'enc1'`, `vault.ts:33`). **VERIFIED**.
- **ما تحميه:** كل قيمة KV للمحرك (identity, spkPriv, opk:*, session:*, pqpq-priv) تمر عبر `VaultKVStore` في `App.tsx:1575-1577` و`App.tsx:1604`. **VERIFIED**.
- **حد النموذج الحرج (موثّق في الكود نفسه, `vault.ts:9-12`):** **KEK نفسه مخزّن في IndexedDB بجانب البيانات الملفوفة** (`vault.ts:42-86`, قاعدة `dirasha-vault`, مخزن `keys`, المفتاح `kek`). حماية الخزنة ضد سرقة ملف IndexedDB فقط بالاعتماد على أن المتصفح لا يصدّر `CryptoKey` غير القابل للاستخراج **من ملف قاعدة البيانات** — أي كود شرير يعمل بامتيازات الصفحة يمكنه استدعاء `crypto.subtle.decrypt` بنفس المفتاح عبر IndexedDB. **VERIFIED كحدّ حقيقي** (التصنيف صريح في jsdoc).
- **لا يوجد binding لحساب المستخدم داخل الخزنة:** KEK واحد لكل متصفح (process-wide, `vault.ts:110-128`) — عزل الحسابات يتم عبر `NamespacedKVStore` (`store.ts:48-72`) وليس بمفاتيح منفصلة لكل حساب. **VERIFIED** (عزل namespace وليس تشفيرًا منفصلًا).

## 9. SHA-256

- **المكتبة/الإصدار:** `@noble/hashes@1.8.0`, `crypto.ts:22` (`sha256`). — **VERIFIED**.
- **الاستخدامات:**
  - رقم الأمان 60 رقمًا: `crypto.ts:301-309` — `sha256(UTF8(sorted([ikA, ikB]).join(':')))` — حتمي وغير مرتب. **VERIFIED**.
  - سلامة المرفقات: `media.ts:199` (digest عند التشفير) و`media.ts:237-239` (مقارنة بزمن ثابت عبر `timingSafeEqual`, `media.ts:142-147`). **VERIFIED**.
  - hint النسخة الاحتياطية: `backup.ts:228-230`. **VERIFIED**.
  - عميل Key Transparency (merkle mirror): `kt-client.ts:23-37`. — لكن انظر ملاحظة الوفاة أدناه (§11).

## 10. CSPRNG (مولّد العشوائية)

- **التنفيذ الموحّد:** `crypto.ts:119-129` — `randomBytes(n)`:
  1. `globalThis.crypto.getRandomValues` (WebCrypto CSPRNG) — المسار الأساسي في المتصفح.
  2. Fallback: `Buffer.randomBytes` (Node crypto) في بيئة Node.
  3. لا fallback ضعيف — يرمي `'no secure random source available'` عند غياب الاثنين. **VERIFIED**.
- **UUID:** `randomDeviceId()` — `crypto.ts:132-140` — `crypto.randomUUID()` مع fallback يدوي من `randomBytes(16)` (RFC-4122 v4). **VERIFIED**.
- **الاستخدامات المفحوصة:** nonces (`engine.ts:991`, `group.ts:273`, `media.ts:197`, `backup.ts:257`), مفاتيح المرسل للمجموعة (`group.ts:398`), مفاتيح X25519/Ed25519 (داخل noble عبر `randomPrivateKey` — noble يستخدم CSPRNG النظام; **PARTIALLY VERIFIED** على مستوى المكتبة).
- **نقطة تحتاج متابعة:** `media.ts:118-126` و`vault.ts:150` تستدعيان `crypto.getRandomValues`/`crypto.randomUUID` مباشرة (لا عبر `randomBytes`) — نفس CSPRNG، متسق. **VERIFIED**.

## 11. Key Transparency client (kt-client.ts) — NOT IMPLEMENTED (كود ميت)

- الوحدة `src/lib/e2ee/kt-client.ts` (114 سطرًا) **لا يستوردها أي ملف في `src/` ولا أي اختبار** (grep: `grep -rn "kt-client|verifyInclusionFull|computeCommitment" src --include=*.ts --include=*.tsx` ⇒ لا نتائج خارج الملف نفسه؛ `tests/key-transparency.test.ts:10` يستورد **خدمة الخادم** `src/server/services/key_transparency.ts` وليس العميل).
- كما يستخدم `Buffer` مباشرة (`kt-client.ts:44,63,67,84,88`) ولا يوجد polyfill لـ Buffer في `vite.config.ts` ولا في `index.html` — لو وُصل يومًا سيرمي في المتصفح داخل try/catch (fail-open إلى "unverified mode").
- **التصنيف: NOT IMPLEMENTED** — التحقق من شفافية المفاتيح من جهة العميل غير موصول بالتطبيق الحيّ؛ الجهاز يثق بالـ bundle الذي يوفره الخادم دون تحقق TOFU فعلي.

## 12. Padding (حجب الأحجام) — Project 6

- `padding.ts:22` — buckets `[512, 1024, 4096, 16384, 65536]`; التعبئة داخل AEAD (`engine.ts:996-997` قبل seal، `engine.ts:897` بعد open)، flag على المغلف `p: PAD_FLAG` (`engine.ts:1006`). **VERIFIED**.
- **الحد (موثّق `padding.ts:9-15`):** فوق 64KB يتسرب الحجم التقريبي؛ التوقيت والعدد خارج النطاق. **VERIFIED** كحدّ صريح.

## 13. الجرد مقابل المخزون المُعلن — خلاصة التصنيف

| الخوارزمية | موجودة في الكود | محمية فعلًا في مسار الإرسال | التصنيف النهائي |
|---|---|---|---|
| X25519 | نعم | نعم (1:1) | **VERIFIED** |
| Ed25519 | نعم | نعم (SPK/PQ sig) | **VERIFIED** |
| ML-KEM-768 | نعم | نعم للأجهزة pq:true | **VERIFIED** (اختبار الحيّ: PARTIALLY) |
| ChaCha20-Poly1305 | نعم | نعم (1:1 + group + media + backup) | **VERIFIED** |
| HKDF-SHA256 | نعم | نعم (كل KDF) | **VERIFIED** |
| HMAC-SHA256 | نعم | نعم (سلسلة الرسائل) | **VERIFIED** |
| scrypt | نعم | نعم (backup) | **VERIFIED** |
| AES-GCM-256 (vault) | نعم | نعم (KV store) — بحدّ KEK-in-IndexedDB | **VERIFIED بحدّ موثّق** |
| AES-GCM (backup) | — | — | **NOT APPLICABLE** (النسخة الاحتياطية تستخدم ChaCha20-Poly1305 وليس AES-GCM؛ الادعاء إن وجد بأن backup يستخدم AES خاطئ) |
| SHA-256 | نعم | نعم (safety number, media integrity) | **VERIFIED** |
| CSPRNG | نعم | نعم | **VERIFIED** |
| Key Transparency (عميل) | ميت | لا | **NOT IMPLEMENTED** |

---
*هذا الملف توثيقي فقط؛ لم يُعدّل أي كود أثناء إعداده.*
