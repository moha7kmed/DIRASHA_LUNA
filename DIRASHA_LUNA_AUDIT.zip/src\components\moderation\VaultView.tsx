import { Database, Trash2, Clock, MessageCircle, FileText, ShieldAlert, Archive } from 'lucide-react';
import { motion } from 'motion/react';
import { UserBadge } from './ModerationShared.tsx';

interface VaultItem {
  messageId: string;
  chatId: string;
  senderId: string;
  senderName?: string;
  senderAvatar?: string;
  originalContent: string;
  messageType: string;
  attachmentsMetadata: string;
  originalCreatedAt: string;
  deletedAt: string;
  deletedBy: string;
  deleteReason?: string;
}

interface VaultViewProps {
  items: VaultItem[];
  loading: boolean;
  onRestore?: (id: string) => void;
}

export function VaultView({ items, loading, onRestore }: VaultViewProps) {
  if (loading && items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-32 text-zinc-500">
        <Database className="w-8 h-8 animate-spin mb-4 text-indigo-500/40" />
        <span className="text-[10px] font-black uppercase tracking-widest text-zinc-600">Accessing secure archive...</span>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-32 text-zinc-500 rounded-[40px] border border-dashed border-white/5 bg-white/[0.01]">
        <Archive className="w-12 h-12 mb-4 opacity-5" />
        <span className="text-[11px] font-black uppercase tracking-widest opacity-40">No historical data in safety vault</span>
      </div>
    );
  }

  return (
    <div className="space-y-10 pb-20">
      <div className="p-10 bg-white/[0.02] border border-white/5 rounded-[40px] flex items-start gap-8 backdrop-blur-xl relative overflow-hidden group">
        <div className="absolute inset-0 bg-white/[0.01] opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
        <ShieldAlert className="w-8 h-8 text-zinc-600 mt-1 shrink-0 opacity-20" />
        <div className="space-y-2 relative z-10">
          <h3 className="text-sm font-black text-white tracking-widest uppercase">Forensic Ledger</h3>
          <p className="text-[11px] text-zinc-500 leading-relaxed font-bold uppercase tracking-widest opacity-60 max-w-2xl">
            Immutable archive of purged communications. Access strictly monitored and restricted to oversight personnel. Data integrity verified via blockchain hash sequence.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-8">
        {items.map((item) => (
          <motion.div
            key={item.messageId}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-8 bg-white/[0.02] border border-white/5 rounded-[40px] hover:bg-white/[0.04] hover:border-white/10 transition-all group overflow-hidden backdrop-blur-md"
          >
            <div className="flex flex-col gap-8">
               <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 pb-8 border-b border-white/5">
                  <UserBadge 
                    user={{ 
                      id: item.senderId, 
                      displayName: item.senderName || 'Unknown Sender',
                      avatarUrl: item.senderAvatar 
                    }} 
                    size="sm"
                  />
                  <div className="flex flex-col items-start md:items-end gap-2.5 shrink-0">
                    <span className="text-[9px] font-black text-rose-500 bg-rose-500/10 px-3 py-1.5 rounded-xl border border-rose-500/20 uppercase tracking-widest shadow-lg shadow-rose-950/20">PURGED DATA</span>
                    <span className="text-[9px] text-zinc-700 font-black uppercase tracking-widest opacity-40">PROTOCOL: {item.deletedBy === 'system' ? 'SYSTEM_PURGE' : 'ADMIN_OVERRIDE'}</span>
                  </div>
               </div>

               <div className="p-8 bg-black/40 border border-white/5 rounded-[32px] group-hover:border-white/[0.08] transition-colors relative overflow-hidden">
                 <p className="text-sm text-zinc-400 leading-relaxed font-medium relative z-10">
                   {item.originalContent || '[Media Content Encrypted]'}
                 </p>
                 <div className="absolute top-0 right-0 w-32 h-32 bg-white/[0.02] blur-3xl rounded-full pointer-events-none" />
                 {item.messageType === 'attachment' && (
                   <div className="mt-6 text-[9px] flex items-center gap-2 text-zinc-400 font-black uppercase tracking-widest bg-white/5 px-4 py-2 rounded-2xl border border-white/10 w-fit">
                     <FileText className="w-4 h-4" />
                     Forensic Log Metadata Attached
                   </div>
                 )}
               </div>

               <div className="flex flex-wrap items-center gap-6 text-[9px] text-zinc-600 font-black uppercase tracking-widest px-1">
                 <div className="flex items-center gap-2">
                   <Clock className="w-3.5 h-3.5 opacity-40" />
                   {new Date(item.originalCreatedAt).toLocaleString('en-US', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                 </div>
                 <div className="flex items-center gap-2 text-rose-500/40">
                    <Trash2 className="w-3.5 h-3.5" />
                    {new Date(item.deletedAt).toLocaleString('en-US', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                 </div>
                 {item.deleteReason && (
                   <div className="ml-auto bg-white/5 px-3 py-1.5 rounded-xl text-zinc-500 border border-white/5 font-bold tracking-tight">
                     REASON: {item.deleteReason}
                   </div>
                 )}
               </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

