/**
 * F2 (audit CRITICAL) — Encrypted local message cache.
 *
 * Covers:
 *  - round-trip of encrypted cache values (no plaintext at rest),
 *  - legacy plaintext migration with verify-then-keep-plaintext-on-failure,
 *  - per-value independence (one corrupt entry never breaks others),
 *  - migration resumability (partially migrated store opens fine),
 *  - KEK persistence across instances (same 'db' — page-reload parity),
 *  - per-account KEK separation (shared cache DB across accounts),
 *  - the vault per-store in-flight guard regression (cache KEK store must
 *    never converge on the engine vault's KEK),
 *  - the per-account KEK-id helper (pure logic).
 *
 * Runs in Node: the record store and KEK store are injected in-memory via
 * MessagesCacheDB.configureForTests (production paths use IndexedDB, which
 * Node does not provide — the injected seam exercises the identical crypto
 * and migration logic).
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import {
  MessagesCacheDB,
  cacheKekId,
} from '../src/lib/messages_cache_db.ts';
import type { CacheRecord, CacheRecordStore } from '../src/lib/messages_cache_db.ts';
import { EphemeralKekStore, getOrCreateKek } from '../src/lib/e2ee/vault.ts';
import type { KekStore } from '../src/lib/e2ee/vault.ts';

/* ── In-memory record store (stands in for IndexedDB in Node) ────────────── */

class MemRecordStore implements CacheRecordStore {
  map = new Map<string, CacheRecord>();
  /** chatId → error injection for putRecord. */
  failPutFor = new Set<string>();
  /** chatId → error injection for getRecord (verify-read failure). */
  failGetFor = new Set<string>();

  async getRecord(chatId: string): Promise<CacheRecord | null> {
    if (this.failGetFor.has(chatId)) throw new Error('injected getRecord failure');
    return this.map.get(chatId) ?? null;
  }
  async putRecord(chatId: string, record: CacheRecord): Promise<void> {
    if (this.failPutFor.has(chatId)) throw new Error('injected putRecord failure');
    this.map.set(chatId, structuredClone(record));
  }
  async getAllRecords(): Promise<{ chatId: string; record: CacheRecord }[]> {
    return [...this.map.entries()].map(([chatId, record]) => ({ chatId, record }));
  }
  async deleteRecord(chatId: string): Promise<void> {
    this.map.delete(chatId);
  }
  async clearAll(): Promise<void> {
    this.map.clear();
  }
}

const isEnvelope = (r: any): boolean =>
  !!r && r.v === 'enc1' && typeof r.iv === 'string' && typeof r.ct === 'string';

const seedLegacy = (store: MemRecordStore, chatId: string, messages: any[]) =>
  store.map.set(chatId, { chatId, messages: structuredClone(messages) });

const msg = (id: string, text: string, state = 'sent') => ({
  id,
  chatId: 'c',
  senderId: 'u1',
  content: text,
  state,
  createdAt: new Date(2026, 0, 1).toISOString(),
});

describe('F2 — encrypted message cache (MessagesCacheDB)', () => {
  let store: MemRecordStore;
  let kekStore: EphemeralKekStore;

  beforeEach(() => {
    MessagesCacheDB.resetForTests();
    store = new MemRecordStore();
    kekStore = new EphemeralKekStore();
    MessagesCacheDB.configureForTests({ recordStore: store, kekStore });
    MessagesCacheDB.setOwnerUid('acc-1');
  });

  it('round-trips cached messages and never stores plaintext at rest', async () => {
    const messages = [msg('m1', 'TOP-SECRET-content'), msg('m2', 'second secret')];
    await MessagesCacheDB.put('one_to_one_a___b', messages);

    const raw = store.map.get('one_to_one_a___b') as any;
    expect(isEnvelope(raw)).toBe(true);
    expect(JSON.stringify(raw)).not.toContain('TOP-SECRET');
    expect(raw.messages).toBeUndefined();

    const back = await MessagesCacheDB.get('one_to_one_a___b');
    expect(back).toEqual(messages);
  });

  it('put still merges/dedupes with the existing (encrypted) record and upgrades state', async () => {
    await MessagesCacheDB.put('chatX', [msg('m1', 'hello', 'sent')]);
    await MessagesCacheDB.put('chatX', [msg('m1', 'hello', 'read'), msg('m2', 'world')]);

    const raw = store.map.get('chatX') as any;
    expect(isEnvelope(raw)).toBe(true);

    const back = await MessagesCacheDB.get('chatX');
    expect(back!.map((m: any) => m.id).sort()).toEqual(['m1', 'm2']);
    expect(back!.find((m: any) => m.id === 'm1').state).toBe('read');
  });

  it('gives every value its own IV and keeps entries independent (corruption isolation)', async () => {
    await MessagesCacheDB.put('chatA', [msg('a1', 'alpha')]);
    await MessagesCacheDB.put('chatB', [msg('b1', 'beta')]);

    const ra = store.map.get('chatA') as any;
    const rb = store.map.get('chatB') as any;
    expect(ra.iv).not.toBe(rb.iv); // per-value IV, no nonce reuse

    // Corrupt chatA only → chatA is a graceful miss, chatB is untouched.
    ra.ct = 'AAAA';
    expect(await MessagesCacheDB.get('chatA')).toBeNull();
    expect(await MessagesCacheDB.get('chatB')).toEqual([msg('b1', 'beta')]);
  });

  it('a missing record is a miss (not an error), exactly like the legacy cache', async () => {
    expect(await MessagesCacheDB.get('nope')).toBeNull();
  });

  it('migrateAll encrypts legacy plaintext entries and round-trips their content', async () => {
    const legacy1 = [msg('l1', 'legacy secret one'), msg('l2', 'legacy secret two')];
    const legacy2 = [msg('l3', 'more plaintext')];
    seedLegacy(store, 'old-chat', legacy1);
    seedLegacy(store, 'old-chat-2', legacy2);

    const { migrated, deletedPlaintext } = await MessagesCacheDB.migrateAll();
    expect(migrated).toBe(2);
    expect(deletedPlaintext).toBe(0);

    for (const [chatId, original] of [['old-chat', legacy1], ['old-chat-2', legacy2]] as const) {
      const raw = store.map.get(chatId) as any;
      expect(isEnvelope(raw)).toBe(true);
      expect(JSON.stringify(raw)).not.toContain('plaintext');
      expect(await MessagesCacheDB.get(chatId)).toEqual(original);
    }
  });

  it('P1-B fail-closed: a failed migration entry is DELETED — plaintext never persists (external-audit E2EE-06)', async () => {
    seedLegacy(store, 'c-ok', [msg('ok1', 'migrates fine')]);
    seedLegacy(store, 'c-bad', [msg('bad1', 'write fails here')]);

    // Simulate a storage failure while writing the encrypted record.
    store.failPutFor.add('c-bad');
    const first = await MessagesCacheDB.migrateAll();
    expect(first.migrated).toBe(1);
    expect(first.deletedPlaintext).toBe(1);

    // The failing entry is GONE — plaintext never persisted at rest.
    const raw = store.map.get('c-bad') as any;
    expect(raw).toBeUndefined();
    // Reads = cache MISS (server re-fetch covers availability).
    expect(await MessagesCacheDB.get('c-bad')).toBeNull();

    // Next open: failure cleared → the entry re-caches normally on write.
    store.failPutFor.delete('c-bad');
    await MessagesCacheDB.put('c-bad', [msg('bad1', 'write fails here')]);
    expect(isEnvelope(store.map.get('c-bad'))).toBe(true);
    expect(await MessagesCacheDB.get('c-bad')).toEqual([msg('bad1', 'write fails here')]);
  });

  it('P1-B fail-closed: read-back verification failure DELETES the record (never restored plaintext)', async () => {
    seedLegacy(store, 'c-verify', [msg('v1', 'verify me')]);

    // The write succeeds but the read-back comes back corrupted → migration
    // must NOT consider the entry verified: it restores the plaintext record.
    const origGet = store.getRecord.bind(store);
    let postWriteRead = 0;
    store.getRecord = async (chatId: string) => {
      const rec = await origGet(chatId);
      if (chatId === 'c-verify' && isEnvelope(rec as any)) {
        postWriteRead++;
        return { ...structuredClone(rec as any), ct: 'CORRUPTED' } as any;
      }
      return rec;
    };

    const res = await MessagesCacheDB.migrateAll();
    expect(res.migrated).toBe(0);
    expect(res.deletedPlaintext).toBe(1);
    expect(postWriteRead).toBeGreaterThan(0);

    // The record is GONE — plaintext never restored to disk.
    const raw = store.map.get('c-verify') as any;
    expect(raw).toBeUndefined();
  });

  it('P1-B fail-closed resumability: failed migrations DELETE plaintext (re-cached from server later)', async () => {
    seedLegacy(store, 'p1', [msg('p1m', 'part one')]);
    seedLegacy(store, 'p2', [msg('p2m', 'part two')]);
    seedLegacy(store, 'p3', [msg('p3m', 'part three')]);

    // Interrupt: only p1 migrates (p2/p3 writes fail mid-run).
    store.failPutFor.add('p2');
    store.failPutFor.add('p3');
    await MessagesCacheDB.migrateAll();
    store.failPutFor.delete('p2');
    store.failPutFor.delete('p3');

    // P1-B: p2/p3 plaintext records are GONE (deleted — never persist plaintext).
    expect(isEnvelope(store.map.get('p1'))).toBe(true);
    expect(store.map.get('p2')).toBeUndefined();
    expect(store.map.get('p3')).toBeUndefined();
    expect(await MessagesCacheDB.get('p1')).toEqual([msg('p1m', 'part one')]);
    expect(await MessagesCacheDB.get('p2')).toBeNull();
    expect(await MessagesCacheDB.get('p3')).toBeNull();

    // Availability path: once the failure clears, a normal put() re-caches.
    await MessagesCacheDB.put('p2', [msg('p2m', 'part two')]);
    await MessagesCacheDB.put('p3', [msg('p3m', 'part three')]);
    const res = await MessagesCacheDB.migrateAll();
    expect(res.migrated).toBe(0);
    expect(res.deletedPlaintext).toBe(0);
    for (const c of ['p1', 'p2', 'p3']) {
      expect(isEnvelope(store.map.get(c))).toBe(true);
      expect(await MessagesCacheDB.get(c)).not.toBeNull();
    }
  });

  it('legacy plaintext hits are served immediately and lazily migrated (availability first)', async () => {
    seedLegacy(store, 'lazy', [msg('lm1', 'lazy migrate')]);
    // get() must serve the plaintext hit, not block on migration.
    expect(await MessagesCacheDB.get('lazy')).toEqual([msg('lm1', 'lazy migrate')]);
    // The fire-and-forget lazy migration lands on the next open.
    await MessagesCacheDB.migrateAll();
    expect(isEnvelope(store.map.get('lazy'))).toBe(true);
  });

  it('already-encrypted records are skipped by migration (no double work, no churn)', async () => {
    await MessagesCacheDB.put('enc-first', [msg('e1', 'already encrypted')]);
    const before = structuredClone(store.map.get('enc-first'));
    const res = await MessagesCacheDB.migrateAll();
    expect(res.migrated).toBe(0);
    expect(store.map.get('enc-first')).toEqual(before); // untouched
  });

  it('KEK persists across instances (same db): a reloaded page decrypts old entries', async () => {
    // "Instance 1": writes under the persisted KEK store.
    await MessagesCacheDB.put('reload', [msg('r1', 'survives reload')]);

    // "Instance 2" (page reload): fresh MessagesCacheDB state, SAME KEK db.
    MessagesCacheDB.resetForTests();
    MessagesCacheDB.configureForTests({ recordStore: store, kekStore });
    MessagesCacheDB.setOwnerUid('acc-1');
    expect(await MessagesCacheDB.get('reload')).toEqual([msg('r1', 'survives reload')]);
  });

  it('MULTI-ACCOUNT: per-account KEKs isolate the shared cache DB (other account → graceful miss)', async () => {
    // Account A writes (shared cache DB, chatIds are account-agnostic).
    await MessagesCacheDB.put('shared-chat', [msg('s1', 'account A cache')]);
    expect(isEnvelope(store.map.get('shared-chat'))).toBe(true);

    // Account B on the same browser: different KEK store ⇒ A's entries fail
    // AEAD under B's KEK → treated as a CACHE MISS (server re-fetch covers
    // it), never an error and never cross-account plaintext access.
    const kekStoreB = new EphemeralKekStore();
    MessagesCacheDB.resetForTests();
    MessagesCacheDB.configureForTests({ recordStore: store, kekStore: kekStoreB });
    MessagesCacheDB.setOwnerUid('acc-2');
    expect(await MessagesCacheDB.get('shared-chat')).toBeNull();

    // B re-puts → re-encrypted under B's KEK, readable for B from then on.
    await MessagesCacheDB.put('shared-chat', [msg('s2', 'account B cache')]);
    expect(await MessagesCacheDB.get('shared-chat')).toEqual([msg('s2', 'account B cache')]);
    // The KEK id is per-account (pure helper).
    expect(cacheKekId('acc-1')).toBe('cache-kek:acc-1');
    expect(cacheKekId('acc-2')).toBe('cache-kek:acc-2');
    expect(cacheKekId('')).toBe('cache-kek:anon');
  });

  it('getStats counts messages from encrypted records and legacy records alike', async () => {
    await MessagesCacheDB.put('stats-enc', [msg('s1', 'a'), msg('s2', 'b')]);
    seedLegacy(store, 'stats-legacy', [msg('s3', 'c')]);
    const stats = await MessagesCacheDB.getStats();
    const find = (id: string) => stats.find((s) => s.chatId === id)?.messages ?? -1;
    expect(find('stats-enc')).toBe(2);
    expect(find('stats-legacy')).toBe(1);
  });

  it('clear/deleteChat pass through regardless of record format', async () => {
    await MessagesCacheDB.put('wipe-me', [msg('w1', 'bye')]);
    seedLegacy(store, 'legacy-wipe', [msg('w2', 'old')]);
    await MessagesCacheDB.deleteChat('wipe-me');
    expect(await MessagesCacheDB.get('wipe-me')).toBeNull();
    await MessagesCacheDB.clear();
    expect(await MessagesCacheDB.get('legacy-wipe')).toBeNull();
    expect(store.map.size).toBe(0);
  });
});

describe('F2 — vault per-store KEK guard (cache KEK ≠ engine KEK)', () => {
  it('concurrent getOrCreateKek on DIFFERENT KEK stores yields DIFFERENT keys', async () => {
    // Regression: a single global in-flight promise used to hand the second
    // store the first store's key. The cache vault and the engine vault must
    // never converge on one key (key separation requirement).
    const engineStore = new EphemeralKekStore();
    const cacheStore = new EphemeralKekStore();
    const [engineKek, cacheKek] = await Promise.all([
      getOrCreateKek(engineStore),
      getOrCreateKek(cacheStore),
    ]);
    expect(engineKek).not.toBe(cacheKek);
    // And each store keeps returning its own key afterwards.
    expect(await getOrCreateKek(engineStore)).toBe(engineKek);
    expect(await getOrCreateKek(cacheStore)).toBe(cacheKek);
  });

  it('concurrent getOrCreateKek on the SAME store still converges on ONE key', async () => {
    const kekStore = new EphemeralKekStore();
    const [k1, k2, k3] = await Promise.all([
      getOrCreateKek(kekStore),
      getOrCreateKek(kekStore),
      getOrCreateKek(kekStore),
    ]);
    expect(k1).toBe(k2);
    expect(k2).toBe(k3);
  });

  it('the cache KEK store is a distinct namespace from the engine vault', () => {
    // Pure helper: per-account cache KEK ids live in 'dirasha-cache-vault'
    // (production IndexedDBKekStore args) — never the engine's 'dirasha-vault'.
    expect(cacheKekId('user-9')).toBe('cache-kek:user-9');
  });
});

/* ═══ P1-B (external-audit E2EE-05) — fully-encrypted Outbox ═══════════════ */

import { OutboxDB } from '../src/lib/outbox_db.ts';
import type { OutboxRecordStore } from '../src/lib/outbox_db.ts';

class OutboxMemStore implements OutboxRecordStore {
  map = new Map<string, any>();
  getAllRaw(): Promise<any[]> { return Promise.resolve(Array.from(this.map.values())); }
  async putSealed(rec: any): Promise<void> { this.map.set(String(rec.id), rec); }
  async deleteRaw(id: string): Promise<void> { this.map.delete(String(id)); }
}

function outboxItem(overrides: Partial<any> = {}): any {
  return {
    id: 'oid-1', chatId: 'c1', senderId: 'me',
    content: 'DIR1:ENVELOPE-CONTENT', type: 'text',
    attachments: [{ url: '/api/media/x', mimeType: 'application/octet-stream', name: 'enc.bin' }],
    e2eeFiles: [{ attId: 'a1', key: 'secret-key-material', iv: 'secret-iv' }],
    replyTo: { id: 'm0', senderName: 'peer', content: 'quote plaintext snapshot' },
    createdAt: new Date().toISOString(), retryCount: 0, nextRetryTime: 0, status: 'pending',
    ...overrides,
  };
}

describe('P1-B — fully-encrypted Outbox (E2EE-05)', () => {
  let kekStore: EphemeralKekStore;
  let recs: OutboxMemStore;
  beforeEach(async () => {
    kekStore = new EphemeralKekStore();
    recs = new OutboxMemStore();
    OutboxDB.configureForTests({ recordStore: recs, kekStore });
    OutboxDB.setOwnerUid('user-A');
  });
  afterEach(() => { OutboxDB.resetForTests(); });

  it('raw stored record is a sealed envelope — NO plaintext item fields (marker grep)', async () => {
    const marker = 'QUOTE-MARKER-XYZ-7890';
    const item = outboxItem({ id: 'oid-marker', replyTo: { id: 'm0', senderName: 'p', content: marker } });
    item.e2eeFiles = [{ key: 'MEDIA-KEY-MARKER-42', iv: 'IV-MARKER-1' }];
    await OutboxDB.put(item);
    const raw = JSON.stringify(recs.map.get('oid-marker'));
    expect(raw).not.toContain(marker);
    expect(raw).not.toContain('MEDIA-KEY-MARKER-42');
    expect(raw).not.toContain('DIR1:ENVELOPE-CONTENT');
    expect(isEnvelope(JSON.parse(raw))).toBe(true);
    // Round-trip: getAll decrypts and returns the full item.
    const all = await OutboxDB.getAll();
    expect(all).toHaveLength(1);
    expect(all[0].e2eeFiles[0].key).toBe('MEDIA-KEY-MARKER-42');
    expect(all[0].replyTo.content).toBe(marker);
  });

  it('fail-closed: put WITHOUT KEK throws — nothing is persisted', async () => {
    OutboxDB.resetForTests();
    OutboxDB.configureForTests({ recordStore: recs, kekStore: undefined });
    await expect(OutboxDB.put(outboxItem({ id: 'oid-nok' }))).rejects.toThrow('OUTBOX_KEK_UNAVAILABLE');
    expect(recs.map.size).toBe(0);
  });

  it('legacy plaintext record is DELETED on read — never surfaced', async () => {
    recs.map.set('legacy-1', { id: 'legacy-1', chatId: 'c', content: 'PLAINTEXT-PENDING-ITEM' });
    const all = await OutboxDB.getAll();
    expect(all).toHaveLength(0);
    expect(recs.map.has('legacy-1')).toBe(false);
    expect(JSON.stringify(Array.from(recs.map.values()))).not.toContain('PLAINTEXT-PENDING-ITEM');
  });

  it('account switch: other account KEK record is deleted, not surfaced', async () => {
    await OutboxDB.put(outboxItem({ id: 'oid-A' }));
    // Production IndexedDBKekStore namespaces the KEK by uid; the Ephemeral
    // test seam holds ONE shared key, so simulate the switch by swapping in a
    // fresh store (different key → oid-A is undecryptable for user-B).
    OutboxDB.configureForTests({ recordStore: recs, kekStore: new EphemeralKekStore() });
    OutboxDB.setOwnerUid('user-B');
    const all = await OutboxDB.getAll();
    expect(all.filter((i) => i.id === 'oid-A')).toHaveLength(0);
  });
});
