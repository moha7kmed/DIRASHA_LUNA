/**
 * Dirasha E2EE — crypto-hardening tests (remediation F3/F7/F8/F9, audit H1).
 *
 *   h1  key-request from a NON-MEMBER peer → no distribution (no 'e2ee:ctrl'
 *       emit); member request → real distribution through the engine.
 *       The App's 'e2ee:ctrl' key-request branch delegates the membership
 *       decision to group.ts isRosterMember() (single source of the LOCAL
 *       roster guard, also used by the distribution choke point) — the
 *       harness below mirrors that branch exactly and drives the REAL
 *       GroupCrypto + engine crypto path.
 *   h2  KT (F7): fetchAndVerifyFleetProof with a valid mock proof → ok;
 *       tampered authPath → failure; the ENGINE wiring raises the
 *       localStorage 'ktFlag:<peer>' flag on a verified-mode contradiction
 *       while NEVER blocking the bundle (availability first); a positively
 *       verified proof clears the flag; transport failure / unverified mode
 *       raise no flag.
 *   h3  pqSeen (F9): classical init after a pq:true session for the SAME
 *       device → rejected (TamperedError 'pq downgraded');
 *       deleteSession() clears the memory → classical init works again.
 *   h4  downgrade flag (F8): PeerNotRegisteredError persists
 *       'e2eeDowngraded:<peer>' + wasDowngraded() surfaces it; a successful
 *       encryption clears it.
 *   h5  KT consistency verification (RFC-6962/RFC-9162): the client mirror
 *       (verifyConsistency) accepts the SERVER-GENERATED consistency proof
 *       (byte-exact mirror cross-check) and rejects tampered/malformed/
 *       garbage proofs; fetchAndVerifyFleetProof anchors the last seen
 *       (treeVersion, rootHash) per peer ('ktLast:<peer>'), verifies the
 *       consistency proof on every version advance, REJECTS old-log rollback
 *       (treeVersion < anchored — in every witness mode) and treats a
 *       missing/garbage consistency proof as 'malformed' (never throws past
 *       the boundary).
 *   h6  security-event monitoring ring: pushSecurityEvent stores structured,
 *       CONTENT-FREE events into a bounded localStorage ring
 *       ('secEvents:<uid>', max 50, oldest evicted) + one [SEC-EVENT]
 *       console.warn per event.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { sha256 } from '@noble/hashes/sha256';

import { DirashaE2EE } from '../src/lib/e2ee/engine.ts';
import { MemoryKVStore } from '../src/lib/e2ee/store.ts';
import { GroupCrypto, isRosterMember, rosterMemberIds } from '../src/lib/e2ee/group.ts';
import {
  TamperedError,
  PeerNotRegisteredError,
} from '../src/lib/e2ee/types.ts';
import {
  b64encode,
  utf8Encode,
  generateEd25519,
  ed25519Sign,
  WIRE_PREFIX,
  b64decode,
} from '../src/lib/e2ee/crypto.ts';
import {
  computeCommitment,
  fetchAndVerifyFleetProof,
  setKtFlag,
  clearKtFlag,
  verifyFleetInclusion,
  verifyConsistency,
  getKtAnchor,
  KT_EMPTY_ROOT,
} from '../src/lib/e2ee/kt-client.ts';
import { pushSecurityEvent } from '../src/App.tsx';
// Byte-exact mirror cross-check: the SERVER proof generation/verification
// (node:crypto) against the CLIENT mirror (@noble/hashes).
import {
  consistencyProof as serverConsistencyProof,
  verifyConsistencyProof as serverVerifyConsistency,
} from '../src/server/services/key_transparency.ts';

/* ── localStorage shim (vitest runs in a node env — no localStorage) ──────── */

class LocalStorageShim {
  private m = new Map<string, string>();
  getItem(k: string): string | null { return this.m.has(k) ? (this.m.get(k) as string) : null; }
  setItem(k: string, v: string): void { this.m.set(k, String(v)); }
  removeItem(k: string): void { this.m.delete(k); }
  key(i: number): string | null { return [...this.m.keys()][i] ?? null; }
  get length(): number { return this.m.size; }
  clear(): void { this.m.clear(); }
}

let storage: LocalStorageShim;

/** Poll the shim until `key` reaches `expected` (fire-and-forget engine work). */
async function waitForStorage(key: string, expected: string | null, timeoutMs = 5000): Promise<boolean> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (storage.getItem(key) === expected) return true;
    await new Promise((r) => setTimeout(r, 15));
  }
  return storage.getItem(key) === expected;
}

/* ── KT hash helpers (INDEPENDENT mirror of the server math for the test) ── */

const tEnc = new TextEncoder();
const hexOf = (b: Uint8Array): string => Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('');

function tLeafHash(seq: number, userId: string, commitment: string): string {
  const data = tEnc.encode(`${seq}|${userId}|${commitment}`);
  const buf = new Uint8Array(1 + data.length);
  buf[0] = 0x00;
  buf.set(data, 1);
  return hexOf(sha256(buf));
}

function tNodeHash(left: string, right: string): string {
  const buf = new Uint8Array(1 + tEnc.encode(left).length + tEnc.encode(right).length);
  buf[0] = 0x01;
  buf.set(tEnc.encode(left), 1);
  buf.set(tEnc.encode(right), 1 + tEnc.encode(left).length);
  return hexOf(sha256(buf));
}

const fillerCommitment = (seed: string): string => hexOf(sha256(tEnc.encode(`filler:${seed}`)));
const flipHex = (hex: string): string => (hex[0] === 'a' ? 'b' : 'a') + hex.slice(1);

/** Independent RFC-6962 subtree root mirror (server subRoot shape). */
function tSubRoot(leaves: string[], lo: number, hi: number): string {
  if (hi - lo === 1) return leaves[lo];
  let k = 1;
  while (k * 2 < hi - lo) k *= 2;
  return tNodeHash(tSubRoot(leaves, lo, lo + k), tSubRoot(leaves, lo + k, hi));
}

/**
 * Independent consistency-proof GENERATION mirror (server consistencyProof /
 * recConsistency shape): deepest-first, old-subtree root emitted at the
 * deepest node. Used to build honest proofs + tamper variants for the client.
 */
function tConsistencyProof(leaves: string[], m: number, n: number): string[] {
  if (m === n) return [];
  const proof: string[] = [];
  const rec = (mm: number, lo: number, hi: number): void => {
    if (mm === hi - lo) { proof.push(tSubRoot(leaves, lo, hi)); return; }
    let k = 1;
    while (k * 2 < hi - lo) k *= 2;
    if (mm <= k) {
      rec(mm, lo, lo + k);
      proof.push(tSubRoot(leaves, lo + k, hi));
    } else {
      rec(mm - k, lo + k, hi);
      proof.push(tSubRoot(leaves, lo, lo + k));
    }
  };
  rec(m, 0, n);
  return proof;
}

/**
 * A 9-leaf append-only log: leaf 0 = the tested user's entry (seq 1), leaves
 * 1..8 = other users' entries (seq 2..9). Roots for versions 2/3/6/9 and
 * witness signatures over 'DirashaKT-v1:<v>:<root>'.
 */
function buildVersionedLog(userId: string, commitmentHex: string, witness: { priv: Uint8Array }) {
  const leaves: string[] = [tLeafHash(1, userId, commitmentHex)];
  for (let i = 2; i <= 9; i++) leaves.push(tLeafHash(i, `log-user-${i}`, fillerCommitment(`v${i}`)));
  const roots = new Map<number, string>();
  for (const v of [2, 3, 6, 9]) roots.set(v, tSubRoot(leaves, 0, v));
  const sig = (v: number): string =>
    b64encode(ed25519Sign(tEnc.encode(`DirashaKT-v1:${v}:${roots.get(v)}`), witness.priv));
  const proof = (m: number, n: number): string[] => tConsistencyProof(leaves, m, n);
  return { leaves, roots, sig, proof };
}

/** Snapshot-only proof response (found:false — consistency tests need no auth path). */
function snapshotOnlyBody(userId: string, treeVersion: number, rootHash: string, signature: string, extra?: object) {
  return {
    userId,
    found: false,
    snapshot: { treeVersion, rootHash, signature, signedAt: null, mode: 'verified' },
    ...extra,
  };
}

/* ── Mock server (multi-device e2ee routes incl. PQ fields + KT proofs) ───── */

interface ServerOpk { id: number; pub: string; consumed: boolean }
interface ServerDeviceReg {
  deviceId: string;
  identityDhPub: string;
  identitySigPub: string;
  signedPrekeyPub: string;
  prekeySignature: string;
  pqPrekeyPub: string | null;
  pqPrekeySignature: string | null;
  opks: ServerOpk[];
}

function createMockServer() {
  const regs = new Map<string, Map<string, ServerDeviceReg>>();
  /**
   * KT proof hook: return the KtProofResponse to serve for a user, or null →
   * 404 (transport unavailable). Tests re-point it per case.
   */
  let ktProofFor: ((userId: string) => unknown | null) | null = null;

  const userOf = (init?: RequestInit): string => {
    const headers = (init?.headers ?? {}) as Record<string, string>;
    return String(headers.Authorization ?? '').replace(/^Bearer\s+/, '');
  };
  const respond = (status: number, data: unknown) =>
    new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json' } });

  /** computeFleetCommitment mirror over the registered devices (server shape). */
  const commitmentOf = (userId: string): string | null => {
    const devices = regs.get(userId);
    if (!devices || devices.size === 0) return null;
    return computeCommitment([...devices.values()].map((d) => ({
      deviceId: d.deviceId,
      identityDhPub: d.identityDhPub,
      identitySigPub: d.identitySigPub,
    })));
  };

  const fetch = async (url: any, init?: RequestInit): Promise<Response> => {
    const path = String(url).split('?')[0];
    const method = (init?.method ?? 'GET').toUpperCase();
    const body = init?.body ? JSON.parse(String(init.body)) : {};
    const user = userOf(init);

    if (path === '/api/e2ee/register' && method === 'POST') {
      const deviceId = typeof body.deviceId === 'string' && body.deviceId ? body.deviceId : 'default';
      let devices = regs.get(user);
      if (!devices) {
        devices = new Map<string, ServerDeviceReg>();
        regs.set(user, devices);
      }
      devices.set(deviceId, {
        deviceId,
        identityDhPub: body.identityDhPub,
        identitySigPub: body.identitySigPub,
        signedPrekeyPub: body.signedPrekeyPub,
        prekeySignature: body.prekeySignature,
        pqPrekeyPub: typeof body.pqPrekeyPub === 'string' ? body.pqPrekeyPub : null,
        pqPrekeySignature: typeof body.pqPrekeySignature === 'string' ? body.pqPrekeySignature : null,
        opks: (body.oneTimePrekeys ?? []).map((o: any) => ({ id: o.id, pub: o.pub, consumed: false })),
      });
      return respond(200, { ok: true });
    }
    if (path.startsWith('/api/e2ee/bundle/') && method === 'GET') {
      const devices = regs.get(path.split('/').pop()!);
      if (!devices || devices.size === 0) return respond(404, { registered: false });
      return respond(200, {
        registered: true,
        devices: [...devices.values()].map((d) => {
          const opk = d.opks.find((o) => !o.consumed) ?? null;
          if (opk) opk.consumed = true;
          const hasPq = !!(d.pqPrekeyPub && d.pqPrekeySignature);
          return {
            deviceId: d.deviceId,
            identityDhPub: d.identityDhPub,
            identitySigPub: d.identitySigPub,
            signedPrekeyPub: d.signedPrekeyPub,
            prekeySignature: d.prekeySignature,
            opk: opk ? { id: opk.id, pub: opk.pub } : null,
            pq: hasPq,
            ...(hasPq ? { pqPrekeyPub: d.pqPrekeyPub!, pqPrekeySignature: d.pqPrekeySignature! } : {}),
          };
        }),
      });
    }
    if (path === '/api/e2ee/prekeys' && method === 'POST') {
      const devices = regs.get(user);
      if (!devices || devices.size === 0) return respond(404, { ok: false });
      const primary = [...devices.values()][0];
      for (const o of body.oneTimePrekeys ?? []) primary.opks.push({ id: o.id, pub: o.pub, consumed: false });
      return respond(200, { ok: true });
    }
    if (path.startsWith('/api/e2ee/kt/proof/') && method === 'GET') {
      const userId = path.split('/').pop()!;
      const handler = ktProofFor;
      if (!handler) return respond(404, { error: 'KT proof unavailable.' });
      const proof = handler(userId);
      if (!proof) return respond(404, { error: 'KT proof unavailable.' });
      return respond(200, proof);
    }
    if (path === '/api/e2ee/status' && method === 'GET') {
      const devices = regs.get(user);
      const remaining = devices
        ? [...devices.values()].reduce((a, d) => a + d.opks.filter((o) => !o.consumed).length, 0)
        : 0;
      return respond(200, { registered: !!devices && devices.size > 0, opkRemaining: remaining });
    }
    if (path.startsWith('/api/e2ee/identity/') && method === 'GET') {
      const devices = regs.get(path.split('/').pop()!);
      if (!devices || devices.size === 0) return respond(404, { registered: false });
      const primary = [...devices.values()][0];
      return respond(200, { registered: true, identityDhPub: primary.identityDhPub, deviceCount: devices.size });
    }
    return respond(404, { error: 'not found' });
  };

  return {
    fetch,
    regs,
    commitmentOf,
    setKtProofFor: (fn: ((userId: string) => unknown | null) | null) => { ktProofFor = fn; },
  };
}

/* ── Harness ──────────────────────────────────────────────────────────────── */

let server: ReturnType<typeof createMockServer>;

function makeEngine(user: string, store?: MemoryKVStore): DirashaE2EE {
  return new DirashaE2EE({
    authHeaders: () => ({ Authorization: `Bearer ${user}` }),
    store: store ?? new MemoryKVStore(),
    selfId: user,
  });
}

/** First registered deviceId of a user on the mock server. */
function primaryDeviceIdOf(user: string): string {
  const devices = server.regs.get(user);
  if (!devices || devices.size === 0) throw new Error(`no registrations for ${user}`);
  return [...devices.keys()][0];
}

/** Parse a DIR1 wire string into its envelope object. */
function parseWire(content: string): any {
  return JSON.parse(new TextDecoder().decode(b64decode(content.slice(WIRE_PREFIX.length))));
}

/** Build a VALID verified-mode KT proof package for (userId, commitment) with leafIndex 0 of a 3-leaf tree. */
function buildKtProof(
  userId: string,
  commitmentHex: string,
  witness: { priv: Uint8Array },
  tamper: 'none' | 'authPath' | 'signature' = 'none',
) {
  const treeVersion = 3;
  // Leaf 0 = the user's entry (seq 1); leaves 1/2 = other users' entries.
  const l0 = tLeafHash(1, userId, commitmentHex);
  const l1 = tLeafHash(2, 'bob-user', fillerCommitment('bob'));
  const l2 = tLeafHash(3, 'carol-user', fillerCommitment('carol'));
  // RFC split rule for treeSize 3: [0,3) → k=2, left=[0,2) perfect, right=[2,3).
  // root = H(H(L0,L1), L2); leaf-0 auth path (leaf-up) = [L1, L2].
  const root = tNodeHash(tNodeHash(l0, l1), l2);
  const authPath = tamper === 'authPath' ? [flipHex(l1), l2] : [l1, l2];
  const signMsg = tEnc.encode(`DirashaKT-v1:${treeVersion}:${root}`);
  const signature = tamper === 'signature'
    ? b64encode(ed25519Sign(tEnc.encode(`DirashaKT-v1:${treeVersion}:${flipHex(root)}`), witness.priv))
    : b64encode(ed25519Sign(signMsg, witness.priv));
  return {
    userId,
    found: true,
    snapshot: { treeVersion, rootHash: root, signature, signedAt: null, mode: 'verified' },
    inclusion: { leafIndex: 0, treeSize: treeVersion, leafHash: l0, authPath, commitment: commitmentHex, seq: 1 },
  };
}

beforeEach(() => {
  server = createMockServer();
  vi.stubGlobal('fetch', server.fetch as unknown as typeof fetch);
  storage = new LocalStorageShim();
  vi.stubGlobal('localStorage', storage as unknown as Storage);
});

afterEach(() => {
  vi.unstubAllGlobals();
});

/* ── h1 — group key-request membership verification (F3 / audit H1) ───────── */

describe('(h1) F3 group key-request membership verification', () => {
  /** Mirrors App.tsx's groupMemberIdsOf / key-request branch semantics. */
  const CHAT = { id: 'group_chat_1', type: 'group', memberIds: ['alice', 'bob', 'carol'] };

  it('rosterMemberIds / isRosterMember: canonical LOCAL-roster extraction', () => {
    expect(rosterMemberIds(CHAT, 'alice')).toEqual(['bob', 'carol']);
    expect(isRosterMember(CHAT, 'bob', 'alice')).toBe(true);
    expect(isRosterMember(CHAT, 'mallory', 'alice')).toBe(false);
    // self is excluded → a self-"request" can never be honored
    expect(isRosterMember(CHAT, 'alice', 'alice')).toBe(false);
    // members-object roster shape
    const objChat = { type: 'group', members: [{ id: 'u1' }, { userId: 'u2' }, {}] };
    expect(rosterMemberIds(objChat, 'me')).toEqual(['u1', 'u2']);
    // un-hydrated roster (chat missing) → over-DENY, never over-grant
    expect(isRosterMember(undefined, 'bob', 'alice')).toBe(false);
    expect(isRosterMember(CHAT, '', 'alice')).toBe(false);
    // one-to-one chats / channels are not E2EE group rosters
    expect(rosterMemberIds({ type: 'one-to-one', memberIds: ['a', 'b'] }, 'me')).toEqual(['a', 'b'].filter((x) => x !== 'me'));
  });

  it('(h1) member key-request → distribution happens; NON-MEMBER request → dropped, NO ctrl emit', async () => {
    const alice = makeEngine('alice');
    const bob = makeEngine('bob');
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    const gc = new GroupCrypto({ store: new MemoryKVStore() });
    const emitted: Array<{ toUserId: string; groupId: string; payload: string }> = [];
    const socket = { emit: (ev: string, frame: any) => { if (ev === 'e2ee:ctrl') emitted.push(frame); } };

    /**
     * Exact mirror of App.tsx's 'e2ee:ctrl' key-request branch +
     * distributeGroupKeyToPeer core (real GroupCrypto + real 1:1 engine —
     * the membership guard delegated to the SAME production helper,
     * group.ts isRosterMember, that App.tsx calls at both check sites).
     */
    const handleKeyRequest = async (fromUserId: string, groupId: string): Promise<boolean> => {
      if (!isRosterMember(CHAT, fromUserId, 'alice')) {
        console.warn('[E2EE] key-request from non-member dropped');
        return false;
      }
      await gc.ensureSenderKey(groupId);
      const ctrl = await gc.distributionPayload(groupId);
      const enc = await alice.encryptMessage(fromUserId, ctrl, { chunked: true });
      for (const chunk of enc.contents || [enc.content]) {
        socket.emit('e2ee:ctrl', { toUserId: fromUserId, groupId, payload: chunk });
      }
      return true;
    };

    // Member request → honored: ctrl rides a REAL pairwise DIR1 envelope.
    expect(await handleKeyRequest('bob', 'group_chat_1')).toBe(true);
    expect(emitted.length).toBe(1);
    expect(emitted[0].toUserId).toBe('bob');
    expect(emitted[0].groupId).toBe('group_chat_1');
    expect(emitted[0].payload.startsWith(WIRE_PREFIX)).toBe(true);
    // and bob can actually open it (real round-trip through the engine)
    const r = await bob.decryptMessage('alice', emitted[0].payload);
    expect('plaintext' in r).toBe(true);

    // NON-MEMBER request → dropped BEFORE any distribution work: no ctrl emit.
    emitted.length = 0;
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    expect(await handleKeyRequest('mallory', 'group_chat_1')).toBe(false);
    expect(emitted.length).toBe(0);
    expect(warnSpy).toHaveBeenCalledWith('[E2EE] key-request from non-member dropped');
    warnSpy.mockRestore();
  });

  it('(h1) distribution-side choke point: the roster guard never over-grants', () => {
    // App.tsx distributeGroupKeyToPeer guards with
    //   chat found && chat.type === 'group' && isRosterMember(chat, peer, self)
    // — assert every constituent refuses a non-member / non-group / missing roster.
    expect(isRosterMember(CHAT, 'mallory', 'alice')).toBe(false);
    expect(isRosterMember({ id: 'g', type: 'one-to-one', memberIds: ['alice', 'bob'] }, 'bob', 'alice')).toBe(true);
    // the App choke point additionally requires type === 'group' (asserted by
    // the branch shape above); a missing roster always refuses:
    expect(isRosterMember(null, 'bob', 'alice')).toBe(false);
  });
});

/* ── h2 — KT client verification (F7) ─────────────────────────────────────── */

describe('(h2) F7 Key Transparency verification (kt-client + engine wiring)', () => {
  const DEVICES = [
    { deviceId: 'dev-a', identityDhPub: 'IK-AAA', identitySigPub: 'SIG-AAA' },
    { deviceId: 'dev-b', identityDhPub: 'IK-BBB', identitySigPub: 'SIG-BBB' },
  ];

  it('computeCommitment mirrors the server exactly (sorted lines, HEX, null sig → "")', () => {
    const c = computeCommitment(DEVICES);
    expect(c).toMatch(/^[0-9a-f]{64}$/);
    // byte-exact mirror: sha256('dev-a:IK-AAA:SIG-AAA\ndev-b:IK-BBB:SIG-BBB')
    const expected = hexOf(sha256(tEnc.encode('dev-a:IK-AAA:SIG-AAA\ndev-b:IK-BBB:SIG-BBB')));
    expect(c).toBe(expected);
    // device ORDER never changes the commitment (canonical sort)
    expect(computeCommitment([...DEVICES].reverse())).toBe(c);
    // legacy rows without identitySigPub use '' in the line (server mirror)
    expect(computeCommitment([{ deviceId: 'd', identityDhPub: 'K' }]))
      .toBe(hexOf(sha256(tEnc.encode('d:K:'))));
    // empty fleet → sha256('') (RFC 6962 convention)
    expect(computeCommitment([])).toBe(KT_EMPTY_ROOT);
  });

  it('verifyFleetInclusion: honest 3-leaf proof verifies; tampered auth path / commitment fails', () => {
    const commitment = computeCommitment(DEVICES);
    const params = { seq: 1, userId: 'alice', commitment };
    const l0 = tLeafHash(1, 'alice', commitment);
    const l1 = tLeafHash(2, 'bob-user', fillerCommitment('bob'));
    const l2 = tLeafHash(3, 'carol-user', fillerCommitment('carol'));
    const root = tNodeHash(tNodeHash(l0, l1), l2);

    // honest proof (leaf-up path [L1, L2] for leafIndex 0 of a size-3 tree)
    expect(verifyFleetInclusion(params, 3, [l1, l2], root, { leafIndex: 0, leafHash: l0 })).toBe(true);
    // seq-1 default leaf position works too
    expect(verifyFleetInclusion(params, 3, [l1, l2], root)).toBe(true);
    // tampered sibling value
    expect(verifyFleetInclusion(params, 3, [flipHex(l1), l2], root, { leafIndex: 0, leafHash: l0 })).toBe(false);
    // reordered path
    expect(verifyFleetInclusion(params, 3, [l2, l1], root, { leafIndex: 0, leafHash: l0 })).toBe(false);
    // wrong root
    expect(verifyFleetInclusion(params, 3, [l1, l2], flipHex(root), { leafIndex: 0, leafHash: l0 })).toBe(false);
    // leafHash cross-check: recomputed leaf differs from the server-claimed one
    expect(verifyFleetInclusion(params, 3, [l1, l2], root, { leafIndex: 0, leafHash: flipHex(l0) })).toBe(false);
    // proof for a DIFFERENT commitment (keys swapped server-side)
    const other = { seq: 1, userId: 'alice', commitment: fillerCommitment('swap') };
    expect(verifyFleetInclusion(other, 3, [l1, l2], root, { leafIndex: 0, leafHash: l0 })).toBe(false);
  });

  it('(h2) fetchAndVerifyFleetProof: valid mock proof → ok; tampered authPath → failure', async () => {
    const witness = generateEd25519();
    (globalThis as any).KT_WITNESS_PUB = b64encode(witness.pub);
    const commitment = computeCommitment(DEVICES);
    try {
      // VALID: signature + inclusion + commitment all consistent → ok.
      const valid = buildKtProof('alice', commitment, witness, 'none');
      vi.stubGlobal('fetch', (async (url: any) => {
        if (String(url).startsWith('/api/e2ee/kt/proof/alice')) {
          return new Response(JSON.stringify(valid), { status: 200, headers: { 'Content-Type': 'application/json' } });
        }
        return new Response(JSON.stringify({ error: 'nf' }), { status: 404 });
      }) as unknown as typeof fetch);
      const ok = await fetchAndVerifyFleetProof('alice', commitment, () => ({ Authorization: 'Bearer t' }));
      expect(ok.ok).toBe(true);
      expect(ok.mode).toBe('verified');
      expect(ok.signatureVerified).toBe(true);

      // TAMPERED auth path → verified-mode contradiction → failure result.
      const tampered = buildKtProof('alice', commitment, witness, 'authPath');
      vi.stubGlobal('fetch', (async (url: any) => {
        if (String(url).startsWith('/api/e2ee/kt/proof/alice')) {
          return new Response(JSON.stringify(tampered), { status: 200, headers: { 'Content-Type': 'application/json' } });
        }
        return new Response(JSON.stringify({ error: 'nf' }), { status: 404 });
      }) as unknown as typeof fetch);
      const failure = await fetchAndVerifyFleetProof('alice', commitment, () => ({ Authorization: 'Bearer t' }));
      expect(failure.ok).toBe(false);
      expect(failure.mode).toBe('verified');
      expect(failure.reason).toMatch(/inclusion proof verification FAILED/);

      // flag-raising helper round-trip (the surface ChatWindow reads)
      setKtFlag('alice');
      expect(storage.getItem('ktFlag:alice')).toBe('1');
      clearKtFlag('alice');
      expect(storage.getItem('ktFlag:alice')).toBe(null);
    } finally {
      delete (globalThis as any).KT_WITNESS_PUB;
    }
  });

  it('unverified witness mode + transport failure raise NO flag (documented honest modes)', async () => {
    const witness = generateEd25519();
    (globalThis as any).KT_WITNESS_PUB = b64encode(witness.pub);
    const commitment = computeCommitment(DEVICES);
    try {
      // unverified mode (signature '' — no KT_SIGNING_KEY server-side)
      vi.stubGlobal('fetch', (async (url: any) => {
        if (String(url).startsWith('/api/e2ee/kt/proof/alice')) {
          return new Response(JSON.stringify({
            userId: 'alice', found: false,
            snapshot: { treeVersion: 0, rootHash: KT_EMPTY_ROOT, signature: '', signedAt: null, mode: 'unverified' },
          }), { status: 200, headers: { 'Content-Type': 'application/json' } });
        }
        return new Response(JSON.stringify({ error: 'nf' }), { status: 404 });
      }) as unknown as typeof fetch);
      const res = await fetchAndVerifyFleetProof('alice', commitment);
      expect(res).toMatchObject({ ok: true, mode: 'unverified' });

      // transport failure (429 rate limit) → ok:true 'unavailable', never a flag
      vi.stubGlobal('fetch', (async () => new Response(JSON.stringify({ error: 'rate limited' }), { status: 429 })) as unknown as typeof fetch);
      const res2 = await fetchAndVerifyFleetProof('alice', commitment);
      expect(res2).toMatchObject({ ok: true, mode: 'unavailable' });
      expect(storage.getItem('ktFlag:alice')).toBe(null);
    } finally {
      delete (globalThis as any).KT_WITNESS_PUB;
    }
  });

  it('engine wiring (P1-D trust gate): tampered/unavailable proof BLOCKS sends (KT_UNVERIFIED_PEER) + flag raised; honest proof unblocks', async () => {
    const witness = generateEd25519();
    (globalThis as any).KT_WITNESS_PUB = b64encode(witness.pub);
    try {
      const alice = makeEngine('alice');
      const bob = makeEngine('bob');
      await alice.ensureRegistered();
      await bob.ensureRegistered();

      // (1) No KT endpoint yet (404 = transport unavailable) → the strict gate
      //     BLOCKS the send (fail-closed while a witness key is pinned).
      await expect(alice.encryptMessage('bob', 'before-kt')).rejects.toThrow(/KT_UNVERIFIED_PEER/);
      expect(storage.getItem('ktFlag:bob')).toBe(null);

      // (2) TAMPERED verified-mode proof → still BLOCKED + flag raised
      //     (loud + visible AND fail-closed — the P1-D trust-gate policy).
      const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
      server.setKtProofFor((userId) => {
        const c = server.commitmentOf(userId);
        return c ? buildKtProof(userId, c, witness, 'authPath') : null;
      });
      alice.clearDeviceCache('bob');
      await expect(alice.encryptMessage('bob', 'tampered-kt')).rejects.toThrow(/KT_UNVERIFIED_PEER/);
      expect(await waitForStorage('ktFlag:bob', '1')).toBe(true);
      expect(warnSpy.mock.calls.some((args) => String(args[0]).startsWith('[KT]'))).toBe(true);
      warnSpy.mockRestore();

      // (3) HONEST proof (signature + inclusion + commitment consistent) → flag cleared.
      server.setKtProofFor((userId) => {
        const c = server.commitmentOf(userId);
        return c ? buildKtProof(userId, c, witness, 'none') : null;
      });
      alice.clearDeviceCache('bob');
      const third = await alice.encryptMessage('bob', 'honest-kt');
      expect(third.content.startsWith(WIRE_PREFIX)).toBe(true);
      expect(await waitForStorage('ktFlag:bob', null)).toBe(true);
      // …and the honest v3 snapshot is now the stored anchor ('ktLast:bob').
      const anchored = getKtAnchor('bob');
      expect(anchored).not.toBe(null);
      expect(anchored!.treeVersion).toBe(3);

      // (4) OLD-LOG ROLLBACK (h5): the server serves an OLDER snapshot (v2,
      //     honestly signed) after v3 was anchored → rejected + flag raised —
      //     never accept an older log when a newer one was anchored.
      const cBob = server.commitmentOf('bob')!;
      const rbL0 = tLeafHash(1, 'bob', cBob);
      const rbL1 = tLeafHash(2, 'rb-other', fillerCommitment('rollback'));
      const rbRoot = tNodeHash(rbL0, rbL1);
      const rbSig = b64encode(ed25519Sign(tEnc.encode(`DirashaKT-v1:2:${rbRoot}`), witness.priv));
      server.setKtProofFor((userId) =>
        userId === 'bob' ? snapshotOnlyBody('bob', 2, rbRoot, rbSig) : null,
      );
      const rollbackWarn = vi.spyOn(console, 'warn').mockImplementation(() => {});
      alice.clearDeviceCache('bob');
      // P1-D trust gate: rollback → BLOCKED (fail-closed) + flag + loud reason.
      await expect(alice.encryptMessage('bob', 'rollback-kt')).rejects.toThrow(/KT_UNVERIFIED_PEER/);
      expect(await waitForStorage('ktFlag:bob', '1')).toBe(true);
      expect(rollbackWarn.mock.calls.some((args) => String(args[0]).includes('rollback rejected'))).toBe(true);
      rollbackWarn.mockRestore();
      // The anchor is KEPT (no re-anchoring to the older log).
      expect(getKtAnchor('bob')!.treeVersion).toBe(3);

      // (5) RECOVERY: the honest v3 proof verifies again (same-version anchor
      //     match → inclusion re-checked) → flag cleared, anchor unchanged.
      server.setKtProofFor((userId) => {
        const c = server.commitmentOf(userId);
        return c ? buildKtProof(userId, c, witness, 'none') : null;
      });
      alice.clearDeviceCache('bob');
      const fifth = await alice.encryptMessage('bob', 'recover-kt');
      expect(fifth.content.startsWith(WIRE_PREFIX)).toBe(true);
      expect(await waitForStorage('ktFlag:bob', null)).toBe(true);
      expect(getKtAnchor('bob')!.treeVersion).toBe(3);
    } finally {
      delete (globalThis as any).KT_WITNESS_PUB;
      server.setKtProofFor(null);
    }
  });
});

/* ── h5 — KT consistency verification + rollback rejection (RFC-6962/9162) ── */

describe('(h5) KT consistency verification (RFC-6962/RFC-9162 mirror + anchoring)', () => {
  const DEVICES5 = [
    { deviceId: 'dev-a', identityDhPub: 'IK-AAA', identitySigPub: 'SIG-AAA' },
    { deviceId: 'dev-b', identityDhPub: 'IK-BBB', identitySigPub: 'SIG-BBB' },
  ];

  it('verifyConsistency: SERVER-generated proof verifies on the client mirror (byte-exact cross-check)', () => {
    const commitment = computeCommitment(DEVICES5);
    const leaves = [tLeafHash(1, 'alice', commitment)];
    for (let i = 2; i <= 9; i++) leaves.push(tLeafHash(i, `u${i}`, fillerCommitment(`c${i}`)));
    const r3 = tSubRoot(leaves, 0, 3);
    const r9 = tSubRoot(leaves, 0, 9);
    const r6 = tSubRoot(leaves, 0, 6);

    // SERVER generates → CLIENT mirror verifies (same math, byte-exact).
    const serverProof = serverConsistencyProof(leaves, 3, 9);
    expect(serverProof.length).toBeGreaterThan(0);
    expect(verifyConsistency(3, 9, serverProof, r3, r9)).toBe(true);

    // CLIENT mirror generates → SERVER verifies (the mirror is two-way exact).
    const clientProof = tConsistencyProof(leaves, 3, 9);
    expect(serverVerifyConsistency(3, 9, clientProof, r3, r9)).toBe(true);
    expect(clientProof).toEqual(serverProof); // identical proof BYTES

    // Multiple (m, n) shapes: 3→6, 6→9, 3→4 (single-leaf right half), 1→9.
    for (const [m, n] of [[3, 6], [6, 9], [3, 4], [1, 9]] as Array<[number, number]>) {
      const rm = tSubRoot(leaves, 0, m);
      const rn = tSubRoot(leaves, 0, n);
      expect(verifyConsistency(m, n, tConsistencyProof(leaves, m, n), rm, rn)).toBe(true);
    }
    // r6 anchor: consistency from 3 to 6 must NOT verify against r9 as target.
    expect(verifyConsistency(3, 6, tConsistencyProof(leaves, 3, 6), r3, r6)).toBe(true);
  });

  it('verifyConsistency: tampered / malformed / garbage proofs rejected, never thrown past the boundary', () => {
    const commitment = computeCommitment(DEVICES5);
    const leaves = [tLeafHash(1, 'alice', commitment)];
    for (let i = 2; i <= 9; i++) leaves.push(tLeafHash(i, `u${i}`, fillerCommitment(`c${i}`)));
    const r3 = tSubRoot(leaves, 0, 3);
    const r9 = tSubRoot(leaves, 0, 9);
    const proof = tConsistencyProof(leaves, 3, 9);

    // Tampered element (any position) → both roots can no longer match.
    expect(verifyConsistency(3, 9, [flipHex(proof[0]), ...proof.slice(1)], r3, r9)).toBe(false);
    expect(verifyConsistency(3, 9, [...proof.slice(0, -1), flipHex(proof[proof.length - 1])], r3, r9)).toBe(false);
    // Swapped anchored roots → false.
    expect(verifyConsistency(3, 9, proof, r9, r3)).toBe(false);
    // Malformed: truncated proof (wrong length) → false.
    expect(verifyConsistency(3, 9, proof.slice(1), r3, r9)).toBe(false);
    // Garbage: non-array / non-string elements / empty strings → false, NO throw.
    expect(() => verifyConsistency(3, 9, 'garbage' as any, r3, r9)).not.toThrow();
    expect(verifyConsistency(3, 9, 'garbage' as any, r3, r9)).toBe(false);
    expect(verifyConsistency(3, 9, [123, null as any], r3, r9)).toBe(false);
    expect(verifyConsistency(3, 9, ['', 'x'], r3, r9)).toBe(false);
    expect(verifyConsistency(3, 9, null as any, r3, r9)).toBe(false);
    // Invalid (m, n) shapes → false.
    expect(verifyConsistency(0, 9, proof, r3, r9)).toBe(false);
    expect(verifyConsistency(9, 3, proof, r9, r3)).toBe(false);
    expect(verifyConsistency(3.5, 9, proof, r3, r9)).toBe(false);
    // m === n: empty proof + identical roots → true; anything else → false.
    expect(verifyConsistency(3, 3, [], r3, r3)).toBe(true);
    expect(verifyConsistency(3, 3, [], r3, r9)).toBe(false);
    expect(verifyConsistency(3, 3, [r3], r3, r3)).toBe(false);
  });

  it('fetchAndVerifyFleetProof: anchors TOFU → verifies consistency on advance → rejects rollback/tampered/missing proofs', async () => {
    const witness = generateEd25519();
    (globalThis as any).KT_WITNESS_PUB = b64encode(witness.pub);
    const commitment = computeCommitment(DEVICES5);
    try {
      const vlog = buildVersionedLog('alice', commitment, witness);

      const serve = (body: unknown | null) => {
        vi.stubGlobal('fetch', (async (url: any) => {
          if (String(url).startsWith('/api/e2ee/kt/proof/alice')) {
            if (!body) return new Response(JSON.stringify({ error: 'nf' }), { status: 404 });
            return new Response(JSON.stringify(body), { status: 200, headers: { 'Content-Type': 'application/json' } });
          }
          return new Response(JSON.stringify({ error: 'nf' }), { status: 404 });
        }) as unknown as typeof fetch);
      };
      const get = () => fetchAndVerifyFleetProof('alice', commitment, () => ({ Authorization: 'Bearer t' }));

      // (1) TOFU: first observation (v3, witness-signed) → ok, anchor stored.
      serve(snapshotOnlyBody('alice', 3, vlog.roots.get(3)!, vlog.sig(3)));
      const tofu = await get();
      expect(tofu).toMatchObject({ ok: true, mode: 'verified', signatureVerified: true });
      expect(getKtAnchor('alice')).toEqual({ treeVersion: 3, rootHash: vlog.roots.get(3)! });

      // (2) Version advance 3→6 with the HONEST consistency proof → ok;
      //     the request carried ?sinceVersion=3 (anchored version).
      let seenUrl = '';
      vi.stubGlobal('fetch', (async (url: any) => {
        seenUrl = String(url);
        return new Response(JSON.stringify(snapshotOnlyBody('alice', 6, vlog.roots.get(6)!, vlog.sig(6), {
          consistency: { fromVersion: 3, toVersion: 6, proof: vlog.proof(3, 6) },
        })), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }) as unknown as typeof fetch);
      const advance = await get();
      expect(advance).toMatchObject({ ok: true, mode: 'verified' });
      expect(seenUrl).toContain('sinceVersion=3');
      expect(getKtAnchor('alice')).toEqual({ treeVersion: 6, rootHash: vlog.roots.get(6)! });

      // (3) ROLLBACK: older snapshot (v2, honestly signed) after v6 anchored
      //     → REJECTED (never accept an older log) + anchor KEPT.
      serve(snapshotOnlyBody('alice', 2, vlog.roots.get(2)!, vlog.sig(2)));
      const rollback = await get();
      expect(rollback.ok).toBe(false);
      expect(rollback.reason).toMatch(/rollback rejected/);
      expect(getKtAnchor('alice')).toEqual({ treeVersion: 6, rootHash: vlog.roots.get(6)! });

      // (4) TAMPERED consistency on a validly-signed advance 6→9 → fork evidence.
      const tamperedProof = vlog.proof(6, 9).map((el, i) => (i === 0 ? flipHex(el) : el));
      serve(snapshotOnlyBody('alice', 9, vlog.roots.get(9)!, vlog.sig(9), {
        consistency: { fromVersion: 6, toVersion: 9, proof: tamperedProof },
      }));
      const forked = await get();
      expect(forked.ok).toBe(false);
      expect(forked.reason).toMatch(/fork-detected/);
      expect(getKtAnchor('alice')!.treeVersion).toBe(6);

      // (5) MISSING consistency data on an advance → 'malformed', rejected.
      serve(snapshotOnlyBody('alice', 9, vlog.roots.get(9)!, vlog.sig(9)));
      const missing = await get();
      expect(missing.ok).toBe(false);
      expect(missing.reason).toMatch(/malformed/);
      expect(getKtAnchor('alice')!.treeVersion).toBe(6);

      // (6) GARBAGE consistency (non-string elements) → rejected, NO throw.
      serve(snapshotOnlyBody('alice', 9, vlog.roots.get(9)!, vlog.sig(9), {
        consistency: { fromVersion: 6, toVersion: 9, proof: [null, 42, 'x'] as any },
      }));
      const garbage = await get();
      expect(garbage.ok).toBe(false);
      expect(garbage.reason).toMatch(/fork-detected|malformed/);

      // (7) RECOVERY: honest 6→9 advance → ok, anchor advances to v9.
      serve(snapshotOnlyBody('alice', 9, vlog.roots.get(9)!, vlog.sig(9), {
        consistency: { fromVersion: 6, toVersion: 9, proof: vlog.proof(6, 9) },
      }));
      const recovery = await get();
      expect(recovery).toMatchObject({ ok: true, mode: 'verified' });
      expect(getKtAnchor('alice')).toEqual({ treeVersion: 9, rootHash: vlog.roots.get(9)! });

      // (8) SAME-VERSION fork: same v9, DIFFERENT root — carried by an
      //     honestly re-signed snapshot (a forking server re-signs its own
      //     fork) → progression check catches it: 'fork-detected'.
      const forkRoot = flipHex(vlog.roots.get(9)!);
      const forkSig = b64encode(ed25519Sign(tEnc.encode(`DirashaKT-v1:9:${forkRoot}`), witness.priv));
      serve(snapshotOnlyBody('alice', 9, forkRoot, forkSig));
      const sameVersionFork = await get();
      expect(sameVersionFork.ok).toBe(false);
      expect(sameVersionFork.reason).toMatch(/fork-detected/);
      expect(getKtAnchor('alice')!.treeVersion).toBe(9); // anchor kept
    } finally {
      delete (globalThis as any).KT_WITNESS_PUB;
    }
  });

  it('rollback rejection holds in UNVERIFIED witness mode too (no silent old-log acceptance)', async () => {
    // Anchor an unverified-mode snapshot first, then serve an older version —
    // version regression is old-log evidence regardless of witness mode.
    vi.stubGlobal('fetch', (async (url: any) => {
      if (String(url).startsWith('/api/e2ee/kt/proof/alice')) {
        return new Response(JSON.stringify({
          userId: 'alice', found: false,
          snapshot: { treeVersion: 5, rootHash: KT_EMPTY_ROOT, signature: '', signedAt: null, mode: 'unverified' },
        }), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }
      return new Response(JSON.stringify({ error: 'nf' }), { status: 404 });
    }) as unknown as typeof fetch);
    const c = computeCommitment([{ deviceId: 'd', identityDhPub: 'K' }]);
    expect(await fetchAndVerifyFleetProof('alice', c)).toMatchObject({ ok: true, mode: 'unverified' });
    expect(getKtAnchor('alice')!.treeVersion).toBe(5);

    vi.stubGlobal('fetch', (async (url: any) => {
      if (String(url).startsWith('/api/e2ee/kt/proof/alice')) {
        return new Response(JSON.stringify({
          userId: 'alice', found: false,
          snapshot: { treeVersion: 2, rootHash: KT_EMPTY_ROOT, signature: '', signedAt: null, mode: 'unverified' },
        }), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }
      return new Response(JSON.stringify({ error: 'nf' }), { status: 404 });
    }) as unknown as typeof fetch);
    const rolled = await fetchAndVerifyFleetProof('alice', c);
    expect(rolled.ok).toBe(false);
    expect(rolled.reason).toMatch(/rollback rejected/);
    expect(getKtAnchor('alice')!.treeVersion).toBe(5);
  });
});

/* ── h6 — security event monitoring ring (structured, content-free, bounded) ─ */

describe('(h6) security-event monitoring ring (pushSecurityEvent)', () => {
  it('stores structured content-free events; sanitizes detail (scalars only) + one [SEC-EVENT] warn per event', () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    try {
      storage.clear();
      storage.setItem('dirasha_user', JSON.stringify({ uid: 'ring-user' }));

      pushSecurityEvent('kt-failure', { peerId: 'peer-x', reason: 'rollback rejected' });
      pushSecurityEvent('identity-change', {
        peerId: 'peer-y',
        msg: 'USER MESSAGE CONTENT MUST NOT LAND HERE', // content string... scalars pass the sanitizer — see assertion below
        attachments: [{ name: 'secret.bin' }],          // object → dropped
        notFinite: NaN,                                 // non-finite → dropped
      });
      const arr = JSON.parse(storage.getItem('secEvents:ring-user')!);
      expect(Array.isArray(arr)).toBe(true);
      expect(arr.length).toBe(2);
      expect(arr[0]).toMatchObject({ kind: 'kt-failure', peerId: 'peer-x', reason: 'rollback rejected' });
      expect(arr[0].at).toMatch(/^\d{4}-\d{2}-\d{2}T/); // ISO timestamp
      // content-free enforcement: arrays/objects/non-finite scalars cannot
      // sneak into the ring (the contract is callers pass metadata only; the
      // sanitizer guarantees structured, JSON-flat entries).
      expect(Object.keys(arr[1])).not.toContain('attachments');
      expect(Object.keys(arr[1])).not.toContain('notFinite');
      expect(arr[1].kind).toBe('identity-change');
      expect(arr[1].msg).toBe('USER MESSAGE CONTENT MUST NOT LAND HERE'); // scalar passthrough (callers own content-freedom)

      // structured console.warn: '[SEC-EVENT]' + single JSON line
      expect(warnSpy).toHaveBeenCalledTimes(2);
      expect(String(warnSpy.mock.calls[0][0])).toBe('[SEC-EVENT]');
      expect(() => JSON.parse(String(warnSpy.mock.calls[0][1]))).not.toThrow();
      expect(JSON.parse(String(warnSpy.mock.calls[0][1]))).toMatchObject({ kind: 'kt-failure' });
    } finally {
      warnSpy.mockRestore();
      storage.clear();
    }
  });

  it('ring is BOUNDED at 50 entries (oldest evicted first) and never throws', () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    try {
      storage.clear();
      storage.setItem('dirasha_user', JSON.stringify({ uid: 'ring-user' }));
      for (let i = 0; i < 60; i++) pushSecurityEvent('rate-limit', { i });
      const arr = JSON.parse(storage.getItem('secEvents:ring-user')!);
      expect(arr.length).toBe(50); // bounded
      expect(arr[0].i).toBe(10);   // oldest evicted (0..9 gone)
      expect(arr[49].i).toBe(59);  // newest kept

      // never throws past the boundary: garbage detail / no detail at all;
      // the ring stays BOUNDED (each push beyond 50 evicts the oldest).
      expect(() => pushSecurityEvent('authz-denied', { scope: 'group-key-request' })).not.toThrow();
      expect(() => pushSecurityEvent('tamper-detected', undefined as any)).not.toThrow();
      const arrAfter = JSON.parse(storage.getItem('secEvents:ring-user')!);
      expect(arrAfter.length).toBe(50); // still bounded, still rotating
      expect(arrAfter[49].kind).toBe('tamper-detected'); // newest kept
    } finally {
      warnSpy.mockRestore();
      storage.clear();
    }
  });
});

/* ── h3 — PQ downgrade memory (F9) ────────────────────────────────────────── */

describe('(h3) F9 PQ downgrade memory (pqSeen)', () => {
  it('classical init after a pq:true session for the SAME device → rejected; deleteSession re-arms', async () => {
    const aliceStore = new MemoryKVStore();
    const bobStore = new MemoryKVStore();
    const alice = makeEngine('alice', aliceStore);
    const bob = makeEngine('bob', bobStore);
    await alice.ensureRegistered();
    await bob.ensureRegistered(); // engine registers an ML-KEM-768 PQ prekey → bundle pq:true

    const bobDevId = primaryDeviceIdOf('bob');

    // First send: PQ-hybrid session established with bob's device.
    const m1 = await alice.encryptMessage('bob', 'quantum-safe hello');
    const env1 = parseWire(m1.content);
    expect(env1.pq).toBe(1); // genuinely hybrid on the wire
    // F9 memory persisted at establishment (initiator path)
    expect(await aliceStore.get(`pqSeen:bob:${bobDevId}`)).toBe('1');

    // Responder path also binds the memory: bob decrypts the PQ bootstrap.
    const dec = await bob.decryptMessage('alice', m1.content);
    expect('plaintext' in dec).toBe(true);
    const aliceDevId = primaryDeviceIdOf('alice');
    expect(await bobStore.get(`pqSeen:alice:${aliceDevId}`)).toBe('1');

    // Simulate a store loss of the ratchet state ONLY (the pqSeen memory
    // survives — it is written to a separate kv key on purpose).
    await aliceStore.del(`session:bob:${bobDevId}`);
    expect(await aliceStore.get(`pqSeen:bob:${bobDevId}`)).toBe('1');

    // The bundle now advertises CLASSICAL-ONLY keys for that device
    // (server-side PQ strip — e.g. tampered/rolled-back registration).
    const bobDevices = server.regs.get('bob')!;
    for (const d of bobDevices.values()) {
      d.pqPrekeyPub = null;
      d.pqPrekeySignature = null;
    }
    alice.clearDeviceCache('bob'); // simulate TTL expiry → fresh (tampered) bundle

    // The classical-only init is REJECTED for that device — client-enforced
    // downgrade protection beyond the server's announcement.
    let err: any = null;
    try {
      await alice.encryptMessage('bob', 'should not downgrade');
    } catch (e) { err = e; }
    expect(err).toBeInstanceOf(TamperedError);
    expect(err.message).toMatch(/pq downgraded/);
    // and the session was NOT rebuilt (no classical session slipped through)
    expect(await aliceStore.get(`session:bob:${bobDevId}`)).toBe(null);

    // Escape hatch: the explicit user action deleteSession() clears pqSeen.
    await alice.deleteSession('bob');
    expect(await aliceStore.get(`pqSeen:bob:${bobDevId}`)).toBe(null);
    // …after which the classical init succeeds (documented legacy path).
    const m2 = await alice.encryptMessage('bob', 'classical after explicit delete');
    expect(m2.content.startsWith(WIRE_PREFIX)).toBe(true);
    const env2 = parseWire(m2.content);
    expect(env2.pq).toBeUndefined(); // genuinely classical this time
    const dec2 = await bob.decryptMessage('alice', m2.content);
    expect(dec2).toMatchObject({ plaintext: 'classical after explicit delete' });
  });

  it('emergencyRotate clears all pqSeen memories (fresh identity re-arms classical)', async () => {
    const aliceStore = new MemoryKVStore();
    const bobStore = new MemoryKVStore();
    const alice = makeEngine('alice', aliceStore);
    const bob = makeEngine('bob', bobStore);
    await alice.ensureRegistered();
    await bob.ensureRegistered();
    const bobDevId = primaryDeviceIdOf('bob');
    const m = await alice.encryptMessage('bob', 'pq first');
    expect(await aliceStore.get(`pqSeen:bob:${bobDevId}`)).toBe('1');
    // bob adopts the PQ bootstrap as responder → his side binds the memory too.
    const dec = await bob.decryptMessage('alice', m.content);
    expect('plaintext' in dec).toBe(true);
    const aliceDevId = primaryDeviceIdOf('alice');
    expect(await bobStore.get(`pqSeen:alice:${aliceDevId}`)).toBe('1');

    await alice.emergencyRotate();
    expect(await aliceStore.get(`pqSeen:bob:${bobDevId}`)).toBe(null);
    // bob's responder-side memory is untouched (per-peer, per-device records
    // on each side's OWN store) — only the rotator's memories are wiped.
    expect(await bobStore.get(`pqSeen:alice:${aliceDevId}`)).toBe('1');
  });
});

/* ── h4 — plaintext downgrade memory (F8) ─────────────────────────────────── */

describe('(h4) F8 plaintext downgrade memory + surfacing', () => {
  it('PeerNotRegisteredError persists the flag and wasDowngraded() surfaces it; success clears it', async () => {
    const aliceStore = new MemoryKVStore();
    const alice = makeEngine('alice', aliceStore);
    await alice.ensureRegistered();
    // bob deliberately NOT registered → definitive 404 on the bundle fetch.

    let err: any = null;
    try {
      await alice.encryptMessage('bob', 'hello?');
    } catch (e) { err = e; }
    expect(err).toBeInstanceOf(PeerNotRegisteredError);

    // MEMORY: the downgrade is persisted per peer (App reads wasDowngraded()
    // and renders the "غير مشفرة طرف-لطرف" badge instead of the lock).
    expect(await aliceStore.get('e2eeDowngraded:bob')).toBe('1');
    expect(await alice.wasDowngraded('bob')).toBe(true);

    // Other peers are unaffected.
    expect(await alice.wasDowngraded('carol')).toBe(false);

    // bob registers; the next send encrypts successfully…
    const bob = makeEngine('bob');
    await bob.ensureRegistered();
    const msg = await alice.encryptMessage('bob', 'now encrypted');
    expect(msg.content.startsWith(WIRE_PREFIX)).toBe(true);
    const dec = await bob.decryptMessage('alice', msg.content);
    expect(dec).toMatchObject({ plaintext: 'now encrypted' });

    // …and the memory CLEARS (the badge disappears).
    expect(await alice.wasDowngraded('bob')).toBe(false);
    expect(await aliceStore.get('e2eeDowngraded:bob')).toBe(null);
  });
});
