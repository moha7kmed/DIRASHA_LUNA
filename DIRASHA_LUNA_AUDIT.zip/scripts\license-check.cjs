/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * license-check.cjs — license inventory + abandonment/denylist gate.
 *
 * Uses license-checker (devDependency) to enumerate the PRODUCTION dependency
 * tree (`npm run license-check`), writes a machine-readable summary to
 * license-summary.json (a CI artifact, gitignored), and fails when any
 * production package carries a license on the denylist below.
 *
 * Denylist policy (pragmatic):
 *   Dirasha ships minified/bundled JavaScript to clients (Vite) and bundles
 *   the server with esbuild. Strong-copyleft licenses attached to any bundled
 *   dependency would effectively force relicensing of the whole bundle, which
 *   conflicts with the Apache-2.0 header discipline used across this repo.
 *   Therefore ALL GPL / AGPL / LGPL variants are denied for production deps —
 *   not just GPL-3.0-only — because npm "installing a linked dep" is exactly
 *   how contamination happens, and weak copyleft (LGPL) is not meaningful for
 *   bundled JS. License *expressions* (e.g. "MIT OR GPL-3.0-only") are split
 *   and every term must pass.
 *
 * UNKNOWN/UNLICENSED packages are reported as warnings, not failures.
 *
 * Exit codes: 0 = clean (warnings allowed), 1 = denylist hit, 2 = tooling error.
 */

'use strict';

const fs = require('fs');
const path = require('path');

const REPO_ROOT = path.resolve(__dirname, '..');
const OUT_FILE = path.join(REPO_ROOT, 'license-summary.json');

// SPDX identifiers denied for production dependencies.
const DENYLIST = new Set([
  // GPL family
  'GPL-1.0', 'GPL-1.0-only', 'GPL-1.0-or-later',
  'GPL-2.0', 'GPL-2.0-only', 'GPL-2.0-or-later',
  'GPL-3.0', 'GPL-3.0-only', 'GPL-3.0-or-later',
  // AGPL family
  'AGPL-1.0', 'AGPL-1.0-only', 'AGPL-1.0-or-later',
  'AGPL-3.0', 'AGPL-3.0-only', 'AGPL-3.0-or-later',
  // LGPL family (bundled JS: weak copyleft is not meaningfully satisfiable)
  'LGPL-2.0', 'LGPL-2.0-only', 'LGPL-2.0-or-later',
  'LGPL-2.1', 'LGPL-2.1-only', 'LGPL-2.1-or-later',
  'LGPL-3.0', 'LGPL-3.0-only', 'LGPL-3.0-or-later',
  // Non-free / unspecified legal risk (UNLICENSED is handled as a warning —
  // the private root package itself has no license field and is not a dep)
  'Commercial', 'Proprietary',
  'CC-BY-NC-1.0', 'CC-BY-NC-2.0', 'CC-BY-NC-2.5', 'CC-BY-NC-3.0', 'CC-BY-NC-4.0',
  'CC-BY-NC-SA-1.0', 'CC-BY-NC-SA-2.0', 'CC-BY-NC-SA-2.5', 'CC-BY-NC-SA-3.0', 'CC-BY-NC-SA-4.0',
  'CC-BY-NC-ND-1.0', 'CC-BY-NC-ND-2.0', 'CC-BY-NC-ND-2.5', 'CC-BY-NC-ND-3.0', 'CC-BY-NC-ND-4.0',
  'JSON', // JSON license: "The Software shall be used for Good, not Evil." — field-of-use restriction
]);

// License terms accepted (denied terms are checked against the full set above).
// Everything MIT/ISC/BSD/Apache-2.0/0BSD/CC-BY/Unlicense/MIT-0/Zlib and most
// custom permissive texts pass; only the identifiers in DENYLIST fail.

const EXPRESSION_SPLIT_RE = /\s+(?:OR|AND|WITH)\s+|\(|\)|,/g;

function normalizeLicense(raw) {
  return String(raw || '').trim();
}

function splitExpression(expr) {
  return normalizeLicense(expr)
    .replace(EXPRESSION_SPLIT_RE, ' ')
    .split(/\s+/)
    .filter(Boolean);
}

function evaluateLicense(name, version, licenseExpr, violations, warnings) {
  const terms = splitExpression(licenseExpr);
  if (terms.length === 0) {
    warnings.push(`${name}@${version}: empty license declaration`);
    return;
  }
  // license-checker often returns literal "UNKNOWN" or "*".
  if (terms.length === 1 && (terms[0] === 'UNKNOWN' || terms[0] === '*')) {
    warnings.push(`${name}@${version}: license UNKNOWN — inspect manually`);
    return;
  }
  // Private packages (including the root project itself) carry "UNLICENSED".
  if (terms.every((t) => t === 'UNLICENSED')) {
    warnings.push(`${name}@${version}: UNLICENSED (private package, no license field)`);
    return;
  }
  for (const term of terms) {
    // license-checker sometimes emits legacy names like "GPLv3", "GPLv2".
    const mapped = term.replace(/^GPLv([123])$/i, 'GPL-$1.0').replace(/^LGPLv([0-9.]+)$/i, 'LGPL-$1.0');
    if (DENYLIST.has(mapped)) {
      violations.push({ package: `${name}@${version}`, license: mapped });
    }
  }
}

function main() {
  let checker;
  try {
    checker = require('license-checker');
  } catch (err) {
    console.error('[license-check] license-checker not installed — run `npm install` first.');
    process.exit(2);
  }

  checker.init(
    {
      start: REPO_ROOT,
      production: true, // production dependencies only
      dev: false,
      unknown: true, // include packages whose license cannot be detected
      direct: false,
    },
    (err, modules) => {
      if (err) {
        console.error('[license-check] failed:', err.message || err);
        process.exit(2);
      }

      const violations = [];
      const warnings = [];
      const packages = [];

      const names = Object.keys(modules).sort();
      const licenseTotals = {};

      for (const key of names) {
        const at = key.lastIndexOf('@');
        const name = key.slice(0, at);
        const version = key.slice(at + 1);
        const info = modules[key];
        const licenseExpr = normalizeLicense(info.licenses);

        // Totaling (raw expression string, for the summary artifact)
        licenseTotals[licenseExpr] = (licenseTotals[licenseExpr] || 0) + 1;

        packages.push({
          name,
          version,
          license: licenseExpr,
          path: info.path,
          repository: info.repository || null,
        });

        evaluateLicense(name, version, licenseExpr, violations, warnings);
      }

      const summary = {
        generatedAt: new Date().toISOString(),
        tool: 'license-checker',
        scope: 'production dependencies (--production, dev excluded)',
        packageCount: packages.length,
        licenseTotals,
        warnings,
        violations,
      };

      fs.writeFileSync(OUT_FILE, JSON.stringify(summary, null, 2) + '\n');
      console.log(`[license-check] wrote ${path.relative(REPO_ROOT, OUT_FILE)} (${packages.length} production packages).`);

      for (const w of warnings) console.warn(`[license-check] WARN: ${w}`);

      if (violations.length > 0) {
        console.error(`\n[license-check] FAIL — ${violations.length} package(s) with denied licenses:\n`);
        for (const v of violations) {
          console.error(`  ${v.package} → ${v.license}`);
        }
        console.error('\nDenylist rationale: strong-copyleft (GPL/AGPL/LGPL) contaminates the');
        console.error('bundled client/server distributions; non-free licenses are not redistributable.');
        process.exit(1);
      }

      console.log('[license-check] PASS — no denied licenses in production dependencies.');
    },
  );
}

main();
