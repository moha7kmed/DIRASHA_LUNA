/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { redisCluster } from './redis_client.ts';

export class DeduplicationManager {
  private static DEDUP_PREFIX = 'dedup:msg:';
  private static TTL_SECONDS = 300; // 5-minute sliding deduplication cache window

  /**
   * Attempts to acquire a processing lock for a specific message tracking key.
   * Returns true if this is a brand new, unique message, or false if it is a duplicate.
   * BATCH-5 (DIR-AB-08): the claim is ATOMIC (SET NX) — the previous
   * GET-then-SET let two concurrent packets race past the same key.
   */
  public static async registerEvent(messageId: string): Promise<boolean> {
    if (!messageId) return true; // Fail safe if client forgot to pass a UUID

    const key = `${this.DEDUP_PREFIX}${messageId}`;
    const claimed = await redisCluster.setTempIfAbsent(key, 'processed', this.TTL_SECONDS);
    if (!claimed) {
      // Key existed — this message was already processed or is being handled. Deduplicate.
      console.warn(`[Deduplicator] Handled duplicate packet rejection on key: ${messageId}`);
      return false;
    }
    return true;
  }
}
