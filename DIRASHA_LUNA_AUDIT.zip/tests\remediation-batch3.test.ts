/**
 * BATCH-3 regression tests (DIR-AB-03 / AB-01 / AB-07 / CB-04 / CB-05).
 * Static source asserts over the sync/tombstone/mv/call-log hardening:
 *   b3-1  Sync bridge enforces the attachment allowlist (assertAttachmentUrlsAllowed).
 *   b3-2  Sync bridge enforces the 8000-char content cap and a type allowlist.
 *   b3-3  Tombstones are terminal in BOTH the edit route and the sync update path.
 *   b3-4  Schedule + forward declare mv; forward retries once on 409 expectedVersion.
 *   b3-5  Call-log rides encryptContentForChat; failure skips (no plaintext fallback).
 */
import { describe, it, expect } from 'vitest';
import { readFileSync } from 'fs';
import path from 'path';

const repo = path.resolve(__dirname, '..');
const read = (p: string) => readFileSync(path.join(repo, p), 'utf8');

describe('BATCH-3 remediation (AB-03/AB-01/AB-07/CB-04/CB-05)', () => {
  it('b3-1 sync bridge enforces attachment allowlist', () => {
    const srv = read('server.ts');
    const sync = srv.slice(srv.indexOf('messages/sync'), srv.indexOf("app.post('/api/chats/:chatId/messages'"));
    expect(sync).toMatch(/assertAttachmentUrlsAllowed\(req, req\.body, currentUserId\)/);
    expect(sync).toMatch(/ATTACHMENT_URL_BLOCKED/);
  });

  it('b3-2 sync bridge enforces content cap + type allowlist', () => {
    const srv = read('server.ts');
    const sync = srv.slice(srv.indexOf('messages/sync'), srv.indexOf("app.post('/api/chats/:chatId/messages'"));
    expect(sync).toMatch(/content\.length > 8000/);
    expect(sync).toMatch(/SYNC_ALLOWED_TYPES/);
    expect(sync).toMatch(/SYNC_TYPE_REJECTED/);
  });

  it('b3-3 tombstones terminal in edit route and sync update path', () => {
    const srv = read('server.ts');
    expect(srv).toMatch(/MESSAGE_TOMBSTONED/);
    // edit + sync + (review follow-ups) react/star/pin = 5 guarded sites
    expect((srv.match(/MESSAGE_TOMBSTONED/g) || []).length).toBeGreaterThanOrEqual(5);
  });

  it('b3-4 schedule + forward declare mv; forward has one 409 retry', () => {
    const db = read('src/server/database.ts');
    expect(db).toMatch(/membershipVersion: Number\(c\.membership_version\) \|\| 1/);
    const cw = read('src/components/ChatWindow.tsx');
    expect(cw).toMatch(/mv: \(selectedChatMeta as any\)\?\.membershipVersion/);
    expect(cw).toMatch(/expectedVersion/);
    const types = read('src/types.ts');
    expect(types).toMatch(/membershipVersion\?: number/);
  });

  it('b3-5 call-log rides the encryption choke point', () => {
    const app = read('src/App.tsx');
    const region = app.slice(app.indexOf('dispatchSystemCallMessage'), app.indexOf('dispatchSystemCallMessage') + 2400);
    expect(region).toMatch(/encryptContentForChat/);
    expect(region).toMatch(/skipped \(encryption unavailable\)/);
  });
});
