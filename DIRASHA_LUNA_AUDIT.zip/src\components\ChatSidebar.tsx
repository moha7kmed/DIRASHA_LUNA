/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, Plus, LogOut, MessageSquare, ShieldCheck, UserPlus, X, 
  Phone, Video, Settings, Compass, HelpCircle, Bell, Shield, Users, 
  Database, Lock, Eye, Check, CheckCheck, Clock, User, Sparkles, CheckCircle, Heart,
  Volume2, VolumeX, PhoneCall, PhoneOff, CircleDot, UserCheck, MessageCircle,
  ChevronLeft, ChevronRight, Camera, Laptop, KeyRound, Trash, Trash2, Ban,
  UserX, UserMinus, Monitor, CheckSquare, Loader2, RefreshCw, Settings2, Smartphone, ShieldAlert,
  Activity, Copy, Play, SendHorizontal, Cloud, Pin, Image as ImageIcon, Folder, Megaphone
} from 'lucide-react';

import { normalizeUsername, validateUsername, sanitizeDisplayName, validateDisplayName, normalizeUsernameInput } from '../lib/identityUtils';
import { getAccessToken, getSessionId } from '../lib/token_vault';
import { TwoFactorCard } from './TwoFactorCard';
import { PasskeysCard } from './PasskeysCard';
import { fetchAllUsersPaginated } from '../lib/users_paging.ts';
import { GroupCreateModal } from './GroupCreateModal';
import { VerifiedBadge } from './VerifiedBadge';
import { ImageEditor } from './ImageEditor';
import { AdminDashboard } from './AdminDashboard';
import { VideoStudio } from './VideoStudio';
import { uploadImageToStorage } from '../lib/storageUtils';
import { MessagesCacheDB } from '../lib/messages_cache_db';
import type { SearchResult } from '../types.ts';
import { ChatsCacheDB } from '../lib/chats_cache_db';
import { OutboxDB } from '../lib/outbox_db';
import { formatCallDuration, dayLabelFor } from '../lib/callUiHelpers';
import StorageLinkCard from './StorageLinkCard';

/** Defensive IP formatter: keep first octet, mask the rest ('196.x.x.x'); truncate anything else. */
const formatDeviceIp = (ip: any): string => {
  const raw = typeof ip === 'string' ? ip.trim() : '';
  if (!raw) return 'غير معروف';
  const parts = raw.split('.');
  if (parts.length === 4 && parts.every((p) => /^\d{1,3}$/.test(p))) {
    return `${parts[0]}.x.x.x`;
  }
  return raw.length > 14 ? raw.slice(0, 11) + '…' : raw;
};

/** Defensive last-active formatter: relative Arabic (< 2 min → 'نشط الآن'), else 'آخر نشاط: …'. */
const formatDeviceLastActive = (ts: any): string => {
  if (!ts) return 'غير معروف';
  const t = new Date(ts).getTime();
  if (Number.isNaN(t)) return 'غير معروف';
  const diffMs = Date.now() - t;
  if (diffMs >= 0 && diffMs < 2 * 60 * 1000) return 'نشط الآن';
  return 'آخر نشاط: ' + new Date(t).toLocaleString();
};

/** Calls tab — real per-user call log from /api/calls, grouped by day */
function CallLogList() {
  const [calls, setCalls] = useState<any[] | null>(null);
  const [clearing, setClearing] = useState(false);
  useEffect(() => {
    (async () => {
      try {
        const res = await fetch('/api/calls', { headers: { Authorization: `Bearer ${getAccessToken()}` } });
        const d = await res.json();
        setCalls(d.calls || []);
      } catch { setCalls([]); }
    })();
  }, []);

  // Clear the whole call log (DELETE /api/calls) and empty the displayed list
  const clearCallLog = async () => {
    if (clearing) return;
    setClearing(true);
    try {
      await fetch('/api/calls', {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${getAccessToken()}` }
      });
      setCalls([]);
    } catch { /* keep list on failure */ }
    setClearing(false);
  };

  if (calls === null) {
    return <div className="py-10 text-center text-zinc-500 text-xs">جارٍ تحميل سجل المكالمات…</div>;
  }

  // Group entries by day using the shared Arabic day labels
  const groups: { label: string; items: any[] }[] = [];
  for (const c of calls) {
    const label = dayLabelFor(c.at);
    const last = groups[groups.length - 1];
    if (last && last.label === label) last.items.push(c);
    else groups.push({ label, items: [c] });
  }

  return (
    <div className="space-y-2 mt-2">
      {calls.length > 0 && (
        <div className="flex items-center justify-between px-1 pt-1">
          <span className="text-[11px] font-bold text-white/40 tracking-wide">سجل المكالمات</span>
          <button
            type="button"
            onClick={clearCallLog}
            disabled={clearing}
            className="text-[10px] font-bold px-2 py-1 rounded-full bg-red-500/15 text-red-300 hover:bg-red-500/25 transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            title="مسح سجل المكالمات بالكامل"
          >
            {clearing ? 'جارٍ المسح…' : '🗑 مسح السجل'}
          </button>
        </div>
      )}
      {groups.map((group, gi) => (
        <div key={`${group.label}-${gi}`} className="space-y-2">
          <div className="text-[10px] font-bold text-white/30 px-1 pt-1">{group.label}</div>
          {group.items.map((c, i) => (
            <div key={i} className="flex items-center gap-3 bg-white/[0.03] rounded-2xl px-3 py-2.5">
              <img src={c.avatarUrl || `https://api.dicebear.com/9.x/initials/png?seed=${encodeURIComponent(c.withName)}`} alt="" className="w-10 h-10 rounded-full object-cover" />
              <div className="flex-1 text-left">
                <p className="text-[13px] text-white font-bold">{c.withName}</p>
                <p className="text-[10px] text-zinc-500">
                  {c.direction === 'outgoing' ? '↗ صادرة' : '↙ واردة'} · {c.callType === 'video' ? 'فيديو' : 'صوت'} · {new Date(c.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  {c.durationSec ? ` · ${formatCallDuration(c.durationSec)}` : ''}
                </p>
              </div>
              <span className={`text-[10px] font-bold px-2 py-1 rounded-full ${c.status === 'completed' ? 'bg-emerald-500/15 text-emerald-300' : c.status === 'missed' ? 'bg-red-500/15 text-red-300' : 'bg-blue-500/15 text-blue-300'}`}>
                {c.status === 'completed' ? 'مكتملة' : c.status === 'missed' ? 'فائتة' : c.status === 'ringing' ? 'رنين' : c.status}
              </span>
            </div>
          ))}
        </div>
      ))}
      {calls.length === 0 && (
        <div className="py-10 text-center text-zinc-500 text-xs bg-white/[0.03] rounded-xl mt-2">
          لا توجد مكالمات بعد — ابدأ مكالمة من أي محادثة وسيظهر السجل هنا.
        </div>
      )}
    </div>
  );
}

/** Updates tab — real statuses list from /api/statuses */
function UpdatesList() {
  const [statuses, setStatuses] = useState<any[] | null>(null);
  useEffect(() => {
    (async () => {
      try {
        const res = await fetch('/api/statuses', { headers: { Authorization: `Bearer ${getAccessToken()}` } });
        const d = await res.json();
        setStatuses(d.statuses || []);
      } catch { setStatuses([]); }
    })();
  }, []);
  if (statuses === null) {
    return <div className="py-10 text-center text-zinc-500 text-xs">جارٍ تحميل الحالات…</div>;
  }
  if (statuses.length === 0) {
    return (
      <div className="py-10 text-center text-zinc-500 text-xs bg-white/[0.03] rounded-xl mt-2">
        لا توجد حالات بعد — انشر حالتك من زر «Share to My Status».
      </div>
    );
  }
  return (
    <div className="space-y-2 mt-2">
      {statuses.map((s) => (
        <div key={s.id} className="flex items-center gap-3 bg-white/[0.03] rounded-2xl px-3 py-2.5">
          <img src={s.avatar_url || `https://api.dicebear.com/9.x/initials/png?seed=${encodeURIComponent(s.display_name || 'u')}`} alt="" className="w-10 h-10 rounded-full object-cover" />
          <div className="flex-1 text-left">
            <p className="text-[13px] text-white font-bold">{s.display_name || s.username}</p>
            <p className="text-[10px] text-zinc-500">{s.content ? String(s.content).slice(0, 50) : (s.media_url ? '🎬 حالة وسائط' : 'حالة نصية')} · 👁 {s.views_count || 0} · ❤️ {s.likes_count || 0}</p>
          </div>
          <span className="text-[9px] text-zinc-500 font-mono">{new Date(s.created_at).toLocaleDateString([], { day: 'numeric', month: 'short' })}</span>
        </div>
      ))}
    </div>
  );
}

const GlassSegmentedControl = ({  options,
  value,
  onChange,
  scopeId
}: {
  options: { label: string; value: string }[];
  value: string;
  onChange: (val: string) => void;
  scopeId: string;
}) => {
  return (
    <div className="relative flex p-0.5 bg-white/[0.03] border border-white/5 rounded-[16px] backdrop-blur-md overflow-hidden select-none w-full" style={{ direction: 'ltr' }}>
      {options.map((opt) => {
        const isSelected = value === opt.value;
        return (
          <button
            key={opt.value}
            type="button"
            onClick={() => onChange(opt.value)}
            className={`relative flex-1 py-1.5 px-1.5 text-center text-[11px] font-bold rounded-[14px] transition-all duration-300 cursor-pointer overflow-hidden z-20 ${
              isSelected ? 'text-white font-black shadow-lg bg-white/[0.03]' : 'text-white/45 hover:text-white/70'
            }`}
          >
            {isSelected && (
              <motion.div
                layoutId={`active-seg-${scopeId}`}
                className="absolute inset-0 bg-white/10 border border-white/15 rounded-[12px] -z-10 shadow-[inset_0_1px_1px_rgba(255,255,255,0.2)]"
                transition={{ type: "spring", stiffness: 400, damping: 28 }}
              />
            )}
            <span className="relative z-30">{opt.label}</span>
          </button>
        );
      })}
    </div>
  );
};

/**
 * Inline channel-create modal (Telegram parity): a channel is a one-way
 * broadcast space — created owner-only with NO member picker; subscribers join
 * exclusively via invite codes. Mirrors GroupCreateModal's dark-glass styling
 * with emerald accents (GroupSettingsPanel/GroupCreateModal are read-only
 * files, so channel UI lives inline in ChatSidebar).
 */
function ChannelCreateModal({ onClose, onCreated }: { onClose: () => void; onCreated: (chatId: string) => void }) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const create = async () => {
    if (!name.trim()) return;
    setBusy(true); setError(null);
    try {
      const res = await fetch('/api/chats', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` },
        body: JSON.stringify({ type: 'channel', name: name.trim(), description: description.trim() || undefined }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'فشل إنشاء القناة.');
      onCreated(data.chat.id);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[2000] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div className="w-full max-w-md bg-zinc-900 border border-white/10 rounded-3xl overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/5">
          <div className="flex items-center gap-2">
            <Megaphone size={18} className="text-emerald-400" />
            <h3 className="text-white font-bold text-sm">قناة جديدة</h3>
          </div>
          <button onClick={onClose} className="text-zinc-400 hover:text-white"><X size={18} /></button>
        </div>

        <div className="p-5 space-y-4">
          <p className="text-[11px] text-zinc-500 leading-relaxed">
            القناة مساحة بث أحادية الاتجاه — أنت والمشرفون فقط تنشرون، ويشترك البقية عبر رابط الدعوة للقراءة فقط.
          </p>
          <input
            value={name}
            onChange={(e) => setName(e.target.value.slice(0, 100))}
            placeholder="اسم القناة"
            className="w-full bg-zinc-800/80 border border-white/10 rounded-2xl px-4 py-3 text-white outline-none focus:border-emerald-500/50"
          />
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value.slice(0, 500))}
            placeholder="وصف القناة (اختياري)"
            rows={3}
            className="w-full bg-zinc-800/60 border border-white/10 rounded-2xl px-4 py-3 text-white text-xs outline-none focus:border-emerald-500/50 resize-none"
          />
          {error && <p className="text-red-400 text-xs">{error}</p>}
          <button
            onClick={create}
            disabled={busy || !name.trim()}
            className="w-full py-3 rounded-2xl bg-emerald-500 text-black font-black text-sm disabled:opacity-40 flex items-center justify-center gap-2"
          >
            {busy ? <Loader2 size={16} className="animate-spin" /> : <Megaphone size={16} />}
            إنشاء القناة
          </button>
        </div>
      </div>
    </div>
  );
}

interface ChatSidebarProps {
  accessToken: string;
  activeChatId: string | null;
  chats: any[];
  currentUser: any;
  allUsers?: Record<string, any>;
  onChatSelect: (chatId: string) => void;
  onLogout: () => void;
  onRefreshChats: () => void;
  onSelectUserDirect?: (userId: string) => void;
  onViewProfile?: (userId: string) => void;
  presenceTick?: number;
  onSetHighlightMsgId?: (chatId: string, msgId: string) => void;
  setCurrentUser?: React.Dispatch<React.SetStateAction<any>>;
  onOpenModerationCenter?: () => void;
  /** Opens the advanced active-sessions panel (ActiveSessionsPanel). */
  onOpenSessionsPanel?: () => void;
  unreadReportsCount?: number;
  onReportUser?: (userId: string) => void;
  targetStatusData?: { statusId: string; userId: string } | null;
  setTargetStatusData?: React.Dispatch<React.SetStateAction<{ statusId: string; userId: string } | null>>;
  statusFile?: File | null;
  onStatusFileChange?: (file: File | null) => void;
  /**
   * Project 10 (Emergency Key Rotation): lead-provided handler that calls
   * e2eeRef.current.emergencyRotate() on the logged-in account's E2EE engine.
   * Optional because the lead mounts it — when absent (and the feature flag is
   * on) the button renders disabled instead of silently doing nothing.
   */
  onEmergencyRotate?: () => Promise<unknown>;
}

const SegmentedRing = ({ count, size = 64, color = "#71717a" }: { count: number; size?: number; color?: string }) => {
  if (count <= 0) return <div className="absolute inset-0 rounded-full border-2 border-white/10" />;
  if (count === 1) return <div className="absolute inset-0 rounded-full border-2 border-zinc-500" />;

  const radius = (size / 2) - 1.5;
  const circumference = 2 * Math.PI * radius;
  const gap = count > 1 ? (count > 10 ? 2 : 4) : 0;
  const segmentLength = (circumference / count) - gap;

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="absolute inset-0 transform -rotate-90 pointer-events-none overflow-visible">
      {Array.from({ length: count }).map((_, i) => (
        <circle
          key={i}
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth="2.5"
          strokeDasharray={`${segmentLength} ${circumference - segmentLength}`}
          strokeDashoffset={-(i * (segmentLength + gap))}
          strokeLinecap="round"
          className="transition-all duration-500"
        />
      ))}
    </svg>
  );
};

export function ChatSidebar({
  accessToken,
  activeChatId,
  chats,
  currentUser,
  allUsers = {},
  onChatSelect,
  onLogout,
  onRefreshChats,
  onSelectUserDirect,
  onViewProfile,
  presenceTick,
  onSetHighlightMsgId,
  setCurrentUser,
  onOpenModerationCenter,
  onOpenSessionsPanel,
  unreadReportsCount = 0,
  onReportUser,
  targetStatusData,
  setTargetStatusData,
  statusFile,
  onStatusFileChange,
  onEmergencyRotate,
}: ChatSidebarProps) {
  const profileInitializedRef = React.useRef(false);
  const [selectedAvatarFile, setSelectedAvatarFile] = useState<File | null>(null);
  const [selectedBannerFile, setSelectedBannerFile] = useState<File | null>(null);
  const [selectedBackgroundBannerFile, setSelectedBackgroundBannerFile] = useState<File | null>(null);
  const [editBannerUrl, setEditBannerUrl] = useState('');
  const [editBackgroundBannerUrl, setEditBackgroundBannerUrl] = useState('');
  const [editBannerShadowOpacity, setEditBannerShadowOpacity] = useState(60);
  const [editBgBannerShadowOpacity, setEditBgBannerShadowOpacity] = useState(20);
  
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; chatId: string; chat: any } | null>(null);
  const [showArchived, setShowArchived] = useState(false);
  const [showLocked, setShowLocked] = useState(false);
  const [lockedUnlocked, setLockedUnlocked] = useState(false);
  const [activeFolderId, setActiveFolderId] = useState<string | null>(null);
  const [showAccountDeleteConfirm, setShowAccountDeleteConfirm] = useState<'step1' | null>(null);
  const [accountDeleteText, setAccountDeleteText] = useState('');
  const [blockedUsersList, setBlockedUsersList] = useState<any[]>([]);
  const [showGroupCreate, setShowGroupCreate] = useState(false);
  const [showChannelCreate, setShowChannelCreate] = useState(false);
  const [storageEstimate, setStorageEstimate] = useState('—');
  const [cacheStats, setCacheStats] = useState<{ chatId: string; messages: number }[]>([]);

  /** Refresh storage estimate + per-chat cache counts (Telegram-parity screen). */
  const refreshCacheStats = async () => {
    try {
      const est = await (navigator as any).storage?.estimate?.();
      if (est?.usage != null) {
        const mb = (est.usage / (1024 * 1024)).toFixed(1);
        setStorageEstimate(`${mb} MB`);
      } else {
        setStorageEstimate('غير متاح');
      }
    } catch { setStorageEstimate('غير متاح'); }
    setCacheStats(await MessagesCacheDB.getStats());
  };
  const [pwChange, setPwChange] = useState({ current: '', next: '' });
  // ── Project 10: Emergency Key Rotation (تدوير مفاتيح الطوارئ) ──────────────
  // FEATURE FLAG (gradual rollout, default OFF): the section renders only when
  // localStorage['e2eeEmergencyRotation'] === '1'. To enable for verification
  // (devtools console): localStorage.setItem('e2eeEmergencyRotation', '1') and
  // reopen settings. Flip the default ON only after the flow is verified live
  // (rotation → server re-register → partner 'e2ee:rekey' fan-out).
  const emergencyRotationEnabled =
    typeof localStorage !== 'undefined' &&
    localStorage.getItem('e2eeEmergencyRotation') === '1';
  const [rotationConfirmOpen, setRotationConfirmOpen] = useState(false);
  const [rotationBusy, setRotationBusy] = useState(false);
  const [usernameChange, setUsernameChange] = useState({ next: '' });
  const [pinChange, setPinChange] = useState({ current: '', next: '' });
  const [credBusy, setCredBusy] = useState(false);
  const [credMsg, setCredMsg] = useState<{ ok: boolean; text: string } | null>(null);

  /** Load the REAL blocklist (server-enforced blocks) for the privacy view. */
  const loadBlockedUsers = async () => {
    try {
      const res = await fetch('/api/blocks', { headers: { Authorization: `Bearer ${getAccessToken()}` } });
      const data = await res.json();
      setBlockedUsersList(data.blocked_users || []);
    } catch { /* keep current list on failure */ }
  };

  const [searchQuery, setSearchQuery] = useState('');
  const [msgSearchResults, setMsgSearchResults] = useState<SearchResult[]>([]);
  const [isMsgSearching, setIsMsgSearching] = useState(false);
  const [showNewChatModal, setShowNewChatModal] = useState(false);
  const [availableUsers, setAvailableUsers] = useState<any[]>([]);
  const [userLoading, setUserLoading] = useState(false);
  const [chatCreating, setChatCreating] = useState(false);

  // WhatsApp layout tabs
  const [activeTab, setActiveTab] = useState<'chats' | 'updates' | 'calls' | 'settings' | 'communities'>('chats');
  const [chatFilter, setChatFilter] = useState<'all' | 'unread' | 'groups' | 'favourites'>('all');

  const statusFileInputRef = useRef<HTMLInputElement>(null);

  // New settings partitioned architecture states
  const [settingsSubView, setSettingsSubView] = useState<'main' | 'profile' | 'privacy' | 'notifications' | 'appearance' | 'chat' | 'sessions' | 'storage' | 'admin_dashboard'>('main');

  useEffect(() => {
    if (settingsSubView === 'storage') refreshCacheStats();
  }, [settingsSubView]);

  // Load the REAL blocklist whenever the privacy settings view opens.
  useEffect(() => {
    if (settingsSubView === 'privacy') loadBlockedUsers();
  }, [settingsSubView]);
  const [settingsError, setSettingsError] = useState<string | null>(null);
  const [settingsSuccess, setSettingsSuccess] = useState<string | null>(null);
  const [settingsSaving, setSettingsSaving] = useState(false);

  // Profile fields state
  const [editDisplayName, setEditDisplayName] = useState('');
  const [editUsername, setEditUsername] = useState('');
  const [editBio, setEditBio] = useState('');
  const [editAvatarUrl, setEditAvatarUrl] = useState('');
  const [editUsernameStatus, setEditUsernameStatus] = useState<{ status: 'idle' | 'checking' | 'available' | 'taken' | 'reserved' | 'invalid'; message?: string }>({ status: 'idle' });

  // Privacy & Device management states and actions
  const [blockingTarget, setBlockingTarget] = useState('');
  const [loadingSessions, setLoadingSessions] = useState(false);
  const [deviceSessions, setDeviceSessions] = useState<any[]>([]);

  // Subscribe to real device sessions subcollection over REST
  const fetchSessions = async () => {
    const token = getAccessToken();
    if (!token) return;
    setLoadingSessions(true);
    try {
      const res = await fetch('/api/auth/sessions', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        const activeSessionId = getSessionId() || 'sess_default';
        const sessList = data.sessions.map((s: any) => ({
          id: s.id,
          device: s.userAgent || s.user_agent || 'Unknown Device',
          // New server payloads carry ip / last_active; older ones keep legacy fields.
          // Empty (not a fake value) so the renderer can fall back to 'غير معروف'.
          ipAddress: s.ip || s.ip_address || s.ipAddress || '',
          lastActive: s.last_active || s.lastActive || s.updated_at || s.updatedAt || s.created_at || s.createdAt || null,
          isCurrent: s.id === activeSessionId
        }));
        sessList.sort((a: any, b: any) => {
          if (a.isCurrent) return -1;
          if (b.isCurrent) return 1;
          const ta = a.lastActive ? new Date(a.lastActive).getTime() : 0;
          const tb = b.lastActive ? new Date(b.lastActive).getTime() : 0;
          return tb - ta;
        });
        setDeviceSessions(sessList);
      }
    } catch (err: any) {
      if (err?.message !== 'Failed to fetch' && !err?.message?.includes('Failed to fetch')) {
        console.warn('Failed to load device sessions over REST:', err);
      }
    } finally {
      setLoadingSessions(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'settings') {
      fetchSessions();
    }
  }, [activeTab]);

  const handleRevokeSession = async (sessionId: string) => {
    const token = getAccessToken();
    if (!token) return;
    try {
      const res = await fetch(`/api/auth/sessions/${sessionId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        setSettingsSuccess('Session revoked and device terminated successfully.');
        fetchSessions();
      } else {
        throw new Error();
      }
    } catch (err) {
      setSettingsError('Failed to revoke session for this device.');
    }
  };

  const handleRevokeAllOtherSessions = async () => {
    const token = getAccessToken();
    if (!token) return;
    try {
      const toDelete = deviceSessions.filter(s => !s.isCurrent);
      await Promise.all(
        toDelete.map(s => 
          fetch(`/api/auth/sessions/${s.id}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${token}` }
          })
        )
      );
      setSettingsSuccess('All other sessions terminated and cloud synchronized.');
      fetchSessions();
    } catch (err) {
      setSettingsError('Failed to terminate other sessions.');
    }
  };

  // Load profile values on subview trigger
  useEffect(() => {
    if (settingsSubView === 'profile') {
      if (currentUser && !profileInitializedRef.current) {
        setEditDisplayName(currentUser.displayName || '');
        setEditUsername(currentUser.username || '');
        setEditBio(currentUser.bio || '');
        setEditAvatarUrl(currentUser.avatarUrl || currentUser.photoURL || '');
        setEditBannerUrl(currentUser.bannerUrl || '');
        setEditBackgroundBannerUrl(currentUser.backgroundBannerUrl || '');
        setEditBannerShadowOpacity(currentUser.bannerShadowOpacity !== undefined && currentUser.bannerShadowOpacity !== null ? Number(currentUser.bannerShadowOpacity) : 60);
        setEditBgBannerShadowOpacity(currentUser.bgBannerShadowOpacity !== undefined && currentUser.bgBannerShadowOpacity !== null ? Number(currentUser.bgBannerShadowOpacity) : 20);
        setEditUsernameStatus({ status: 'idle' });
        setSettingsError(null);
        setSettingsSuccess(null);
        profileInitializedRef.current = true;
      }
    } else {
      profileInitializedRef.current = false;
      setSettingsError(null);
      setSettingsSuccess(null);
    }
  }, [settingsSubView, currentUser]);

  // Debounced checking for editUsername during settings modification
  useEffect(() => {
    if (settingsSubView !== 'profile' || !editUsername) return;
    const checkVal = normalizeUsername(editUsername);
    if (checkVal === (currentUser?.username || '').toLowerCase().trim()) {
      setEditUsernameStatus({ status: 'idle' });
      return;
    }
    const valResult = validateUsername(checkVal);
    if (!valResult.isValid) {
      setEditUsernameStatus({ status: 'invalid', message: valResult.error });
      return;
    }

    setEditUsernameStatus({ status: 'checking' });
    const timer = setTimeout(async () => {
      try {
        const res = await fetch(`/api/auth/check-username?username=${encodeURIComponent(checkVal)}`);
        const data = await res.json();
        if (data.available) {
          setEditUsernameStatus({ status: 'available', message: 'Username is available!' });
        } else {
          setEditUsernameStatus({ status: 'taken', message: 'Username is already taken.' });
        }
      } catch (err) {
        setEditUsernameStatus({ status: 'idle' });
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [editUsername, settingsSubView, currentUser]);

  // Status playing state
  const [activeStatus, setActiveStatus] = useState<any | null>(null);
  const [activeStatusIndex, setActiveStatusIndex] = useState(0);
  const [activeStatusGroup, setActiveStatusGroup] = useState<any[]>([]);
  const [isPaused, setIsPaused] = useState(false);
  
  const [statusesList, setStatusesList] = useState<any[]>([]);

  // Effect to handle externally triggered status opening (e.g. from chat forward)
  useEffect(() => {
    if (targetStatusData && statusesList.length > 0) {
      const status = statusesList.find(s => s.id === targetStatusData.statusId);
      if (status) {
        // Find the group of statuses for this user
        const group = statusesList
          .filter(s => s.user_id === targetStatusData.userId)
          .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
        
        const idx = group.findIndex(s => s.id === targetStatusData.statusId);
        if (idx !== -1) {
          setActiveStatusGroup(group);
          setActiveStatusIndex(idx);
          setActiveStatus(group[idx]);
          // Reset the target data so it doesn't re-trigger
          if (setTargetStatusData) setTargetStatusData(null);
        }
      }
    }
  }, [targetStatusData, statusesList, setTargetStatusData]);

  const [statusComments, setStatusComments] = useState<any[]>([]);
  const [statusViewers, setStatusViewers] = useState<any[]>([]);
  const [commentText, setCommentText] = useState('');
  const [showViewersSheet, setShowViewersSheet] = useState(false);
  const [showCommentsSheet, setShowCommentsSheet] = useState(false);
  const [showShareSheet, setShowShareSheet] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isLiking, setIsLiking] = useState(false);
  const [isStatusMuted, setIsStatusMuted] = useState(false);
  const [statusDuration, setStatusDuration] = useState(10);

  useEffect(() => {
    if (!activeStatus) {
      setShowDeleteConfirm(false);
      setIsPaused(false);
      setStatusDuration(10);
    } else {
      if (activeStatus.content_type !== 'video') {
         setStatusDuration(10);
      }
    }
  }, [activeStatus]);

  // Fetch statuses
  useEffect(() => {
    if (!accessToken) return;
    
    let isMounted = true;
    const fetchStatuses = async (retryCount = 0) => {
      try {
        const res = await fetch('/api/statuses', {
          headers: {
            'Authorization': `Bearer ${accessToken}`
          }
        });
        if (!res.ok) throw new Error('status fetch failed');
        const data = await res.json();
        if (isMounted) {
          setStatusesList(data.statuses || []);
        }
      } catch (err) {
        console.error('Failed to fetch statuses:', err);
        // Exponential backoff retry up to 3 times
        if (isMounted && retryCount < 3) {
          const delay = Math.pow(2, retryCount) * 1000;
          setTimeout(() => fetchStatuses(retryCount + 1), delay);
        }
      }
    };
    
    fetchStatuses();
    
    // Listen for new status events
    const handleNewStatus = () => {
      fetchStatuses();
    };
    window.addEventListener('status-updated', handleNewStatus);
    
    return () => {
      isMounted = false;
      window.removeEventListener('status-updated', handleNewStatus);
    };
  }, [accessToken]);

  // Register view, fetch comments and viewers when activeStatus changes
  useEffect(() => {
    if (!activeStatus || !accessToken) return;

    const myId = currentUser?.uid || currentUser?.id;
    const isOwner = activeStatus.user_id === myId;

    // 1. Register view if not owner
    if (!isOwner) {
      fetch(`/api/statuses/${activeStatus.id}/view`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      }).then(res => {
        if (res.ok) {
          setStatusesList(prev => prev.map(s => s.id === activeStatus.id ? { ...s, views_count: (parseInt(s.views_count) || 0) + 1 } : s));
        }
      }).catch(err => console.error('Failed to register status view:', err));
    }

    // 2. Fetch comments
    const fetchComments = async () => {
      try {
        const res = await fetch(`/api/statuses/${activeStatus.id}/comments`, {
          headers: { 'Authorization': `Bearer ${accessToken}` }
        });
        if (res.ok) {
          const data = await res.json();
          setStatusComments(data.comments || []);
        }
      } catch (err) {
        console.error('Failed to fetch status comments:', err);
      }
    };
    fetchComments();

    // 3. Fetch viewers if owner
    if (isOwner) {
      const fetchViewers = async () => {
        try {
          const res = await fetch(`/api/statuses/${activeStatus.id}/viewers`, {
            headers: { 'Authorization': `Bearer ${accessToken}` }
          });
          if (res.ok) {
            const data = await res.json();
            setStatusViewers(data.viewers || []);
          }
        } catch (err) {
          console.error('Failed to fetch status viewers:', err);
        }
      };
      fetchViewers();
    } else {
      setStatusViewers([]);
    }

    setCommentText('');
    setShowViewersSheet(false);
    setShowCommentsSheet(false);
    setShowShareSheet(false);
  }, [activeStatus, accessToken, currentUser]);

  const handleToggleLikeStatus = async (status: any, e: any) => {
    e.stopPropagation();
    if (isLiking || !accessToken) return;
    setIsLiking(true);

    const endpoint = status.has_liked ? `/api/statuses/${status.id}/unlike` : `/api/statuses/${status.id}/like`;
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });
      if (res.ok) {
        const updatedHasLiked = !status.has_liked;
        const diff = updatedHasLiked ? 1 : -1;
        
        const updateItem = (item: any) => {
          if (item?.id === status.id) {
            return {
              ...item,
              has_liked: updatedHasLiked,
              likes_count: Math.max(0, (parseInt(item.likes_count) || 0) + diff)
            };
          }
          return item;
        };

        setStatusesList(prev => prev.map(updateItem));
        if (activeStatus?.id === status.id) {
          setActiveStatus(prev => updateItem(prev));
        }
      }
    } catch (err) {
      console.error('Failed to toggle status like:', err);
    } finally {
      setIsLiking(false);
    }
  };

  const handleDeleteStatus = (statusId: string, e: any) => {
    e.stopPropagation();
    setIsPaused(true);
    setShowDeleteConfirm(true);
  };

  const confirmDeleteStatus = async (statusId: string, e: any) => {
    e.stopPropagation();
    if (!accessToken) return;
    
    if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
       (window as any).showGlobalToast('جاري حذف الحالة...', 'info');
    }
    
    try {
      const res = await fetch(`/api/statuses/${statusId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });
      
      if (res.ok) {
        if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
          (window as any).showGlobalToast('تم حذف الحالة الخاصة بك بنجاح.', 'success');
        }
        
        // Immediate local state update for zero-latency feel
        setStatusesList(prev => {
          const newList = prev.filter(s => String(s.id) !== String(statusId));
          return newList;
        });
        
        // Find if this status belonged to the active group and update it
        setActiveStatusGroup(prev => prev.filter(s => String(s.id) !== String(statusId)));
        
        // Reset state
        setActiveStatus(null);
        setActiveStatusIndex(0);
        setShowDeleteConfirm(false);
        setIsPaused(false);
        
        // Force global re-fetch
        window.dispatchEvent(new CustomEvent('status-updated'));
        
        // Close sheets
        setShowViewersSheet(false);
        setShowCommentsSheet(false);
        setShowShareSheet(false);
      } else {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || 'Failed to delete status.');
      }
    } catch (err: any) {
      console.error(err);
      if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
        (window as any).showGlobalToast(err.message, 'error');
      }
    }
  };

  const handleSendStatusComment = async (e: any) => {
    e.preventDefault();
    if (!commentText.trim() || !activeStatus || !accessToken) return;

    try {
      const res = await fetch(`/api/statuses/${activeStatus.id}/comments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({ text_content: commentText })
      });
      if (res.ok) {
        const data = await res.json();
        const myDisplayName = currentUser?.displayName || currentUser?.display_name || 'Me';
        const myUsername = currentUser?.username || 'me';
        const myAvatarUrl = currentUser?.avatarUrl || currentUser?.photoURL || '';
        
        const completeComment = {
          ...data.comment,
          display_name: myDisplayName,
          username: myUsername,
          avatar_url: myAvatarUrl
        };

        setStatusComments(prev => [...prev, completeComment]);
        setCommentText('');
        
        if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
          (window as any).showGlobalToast('Reply sent successfully.', 'success');
        }
      }
    } catch (err) {
      console.error('Failed to send status comment:', err);
    }
  };

  const handleShareToMyStatus = async () => {
    if (!activeStatus || !accessToken) return;
    try {
      // Ensure we don't send massive data URLs in text_content if possible
      const finalCaption = activeStatus.text_content && activeStatus.text_content.length < 500 
        ? activeStatus.text_content 
        : (activeStatus.content_type === 'video' ? 'Video status' : 'Image status');

      const res = await fetch('/api/statuses', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({
          content_type: activeStatus.content_type,
          media_url: activeStatus.media_url,
          text_content: finalCaption,
          duration_hours: 24,
          settings: activeStatus.settings
        })
      });
      if (res.ok) {
        window.dispatchEvent(new CustomEvent('status-updated'));
        if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
          (window as any).showGlobalToast('تمت مشاركة الحالة في حالتك الخاصة بنجاح.', 'success');
        }
        setShowShareSheet(false);
      } else {
        const errorData = await res.json().catch(() => ({}));
        console.error('Share to my status failed:', errorData);
        if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
          (window as any).showGlobalToast(errorData.error || 'فشلت مشاركة الحالة.', 'error');
        }
      }
    } catch (err) {
      console.error('Failed to share status to my status:', err);
      if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
        (window as any).showGlobalToast('حدث خطأ أثناء مشاركة الحالة.', 'error');
      }
    }
  };

  const handleSendStatusToChat = async (chatId: string) => {
    if (!activeStatus || !accessToken) return;
    try {
      // Logic for forwarding to chat: truncate if it's a huge data URL
      const displayContent = activeStatus.text_content && activeStatus.text_content.length < 500 
        ? activeStatus.text_content 
        : 'Shared a status';

      const res = await fetch(`/api/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({
          chatId,
          content: displayContent,
          type: 'text',
          attachments: activeStatus.media_url ? [{
            url: activeStatus.media_url,
            mimeType: activeStatus.content_type === 'image' ? 'image/jpeg' : 'video/mp4',
            name: 'Status Media',
            size: 0
          }] : [],
          metadata: {
            is_status_forward: true,
            status_id: activeStatus.id,
            owner_id: activeStatus.user_id,
            preview_url: activeStatus.media_url
          }
        })
      });
      if (res.ok) {
        if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
          (window as any).showGlobalToast('تم إرسال الحالة بنجاح.', 'success');
        }
        setShowShareSheet(false);
      } else {
        const errorData = await res.json().catch(() => ({}));
        console.error('Send to chat failed:', errorData);
      }
    } catch (err) {
      console.error('Failed to send status to chat:', err);
    }
  };

  // Calling simulation states
  const [activeCall, setActiveCall] = useState<any | null>(null);
  const [callDuration, setCallDuration] = useState(0);

  // Starred messages tracking states
  const [starredMsgs, setStarredMsgs] = useState<any[]>([]);

  const fetchStarredByDB = async () => {
    if (!accessToken) return;
    try {
      const res = await fetch('/api/messages/starred', {
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
      const data = await res.json();
      if (data.starred) {
        setStarredMsgs(data.starred);
      }
    } catch (err) {
      // Endpoint may not exist yet, ignoring silently
      // console.warn('[ChatSidebar] Failed to load starred messages:', err);
    }
  };

  useEffect(() => {
    fetchStarredByDB();
  }, [currentUser, accessToken]);

  useEffect(() => {
    const handleUpdate = () => {
      fetchStarredByDB();
    };
    window.addEventListener('starred-messages-updated', handleUpdate);
    return () => window.removeEventListener('starred-messages-updated', handleUpdate);
  }, [accessToken]);

  // Status auto-close progression timer
  useEffect(() => {
    let timer: any;
    if (activeStatus && !showViewersSheet && !showCommentsSheet && !showShareSheet && !showDeleteConfirm && !commentText && !isPaused) {
      timer = setTimeout(() => {
        if (activeStatusIndex < activeStatusGroup.length - 1) {
          const nextIndex = activeStatusIndex + 1;
          setActiveStatusIndex(nextIndex);
          setActiveStatus(activeStatusGroup[nextIndex]);
        } else {
          setActiveStatus(null);
          setActiveStatusGroup([]);
          setActiveStatusIndex(0);
        }
      }, statusDuration * 1000); // Dynamic progression
    }
    return () => clearTimeout(timer);
  }, [activeStatus, activeStatusIndex, activeStatusGroup, showViewersSheet, showCommentsSheet, showShareSheet, showDeleteConfirm, commentText, isPaused, statusDuration]);

  // Calling timer simulation
  useEffect(() => {
    let timer: any;
    if (activeCall) {
      setCallDuration(0);
      timer = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [activeCall]);

  const updateUserSettings = async (payload: any) => {
    try {
      if (!currentUser) return;
      const myId = currentUser.uid || currentUser.id;
      const token = getAccessToken();
      
      const unflattenedPayload: any = {};
      for (const key of Object.keys(payload)) {
        if (key.includes('.')) {
          const parts = key.split('.');
          let cursor = unflattenedPayload;
          for (let i = 0; i < parts.length; i++) {
            const p = parts[i];
            if (i === parts.length - 1) {
              cursor[p] = payload[key];
            } else {
              cursor[p] = cursor[p] || {};
              cursor = cursor[p];
            }
          }
        } else {
          unflattenedPayload[key] = payload[key];
        }
      }

      const currentPrivacy = currentUser.privacySettings || {};
      const currentNotifs = currentUser.notificationSettings || {};
      const currentAppearance = currentUser.appearanceSettings || {};

      const finalPayload = {
        ...currentUser,
        displayName: payload.displayName !== undefined ? payload.displayName : currentUser.displayName,
        username: payload.username !== undefined ? payload.username : currentUser.username,
        bio: payload.bio !== undefined ? payload.bio : currentUser.bio,
        avatarUrl: payload.avatarUrl !== undefined ? payload.avatarUrl : (currentUser.avatarUrl || currentUser.photoURL),
        bannerUrl: payload.bannerUrl !== undefined ? payload.bannerUrl : currentUser.bannerUrl,
        backgroundBannerUrl: payload.backgroundBannerUrl !== undefined ? payload.backgroundBannerUrl : currentUser.backgroundBannerUrl,
        blockedUsers: payload.blockedUsers !== undefined ? payload.blockedUsers : (currentUser.blockedUsers || []),
        privacySettings: {
          ...currentPrivacy,
          ...(unflattenedPayload.privacySettings || {})
        },
        notificationSettings: {
          ...currentNotifs,
          ...(unflattenedPayload.notificationSettings || {})
        },
        appearanceSettings: {
          ...currentAppearance,
          ...(unflattenedPayload.appearanceSettings || {})
        },
        // CRITICAL FIX: chatSettings (and the whole-object keys) were missing from
        // this payload — every chatSettings.* toggle died in translation.
        chatSettings: {
          ...((currentUser as any).chatSettings || {}),
          ...(unflattenedPayload.chatSettings || {})
        },
        chatNotifOverrides: payload.chatNotifOverrides !== undefined ? payload.chatNotifOverrides : ((currentUser as any).chatNotifOverrides || {}),
        chatWallpapers: payload.chatWallpapers !== undefined ? payload.chatWallpapers : ((currentUser as any).chatWallpapers || {}),
        pinnedChats: payload.pinnedChats !== undefined ? payload.pinnedChats : ((currentUser as any).pinnedChats || []),
        unreadMarks: payload.unreadMarks !== undefined ? payload.unreadMarks : ((currentUser as any).unreadMarks || []),
        lockedChats: payload.lockedChats !== undefined ? payload.lockedChats : ((currentUser as any).lockedChats || []),
        archivedChats: payload.archivedChats !== undefined ? payload.archivedChats : ((currentUser as any).archivedChats || []),
        chatFolders: payload.chatFolders !== undefined ? payload.chatFolders : ((currentUser as any).chatFolders || []),
        autoDeleteAfterMonths: payload.autoDeleteAfterMonths !== undefined ? payload.autoDeleteAfterMonths : ((currentUser as any).autoDeleteAfterMonths || 0),
        updatedAt: new Date().toISOString()
      };

      const res = await fetch('/api/users/me', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(finalPayload)
      });

      if (!res.ok) {
        throw new Error('Failed to update settings via APIs.');
      }

      const resData = await res.json();
      const updatedUser = resData.user || finalPayload;

      localStorage.setItem('dirasha_user', JSON.stringify(updatedUser));
      
      if (setCurrentUser) {
        setCurrentUser(updatedUser);
      }
    } catch (err) {
      console.warn('Error saving settings:', err);
      throw err;
    }
  };

  // Helper mock Call Logs for the Calls tab
  const mockCalls = [
    {
      id: '1',
      userName: 'Mark Zuckerberg',
      userAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&h=150&q=80',
      time: 'Yesterday, 10:45 PM',
      type: 'voice',
      direction: 'incoming', // incoming, outgoing, missed
    },
    {
      id: '2',
      userName: 'Will Cathcart',
      userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&h=150&q=80',
      time: 'May 18, 4:12 PM',
      type: 'video',
      direction: 'missed',
    },
    {
      id: '3',
      userName: 'Cloud Engineer',
      userAvatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=150&h=150&q=80',
      time: 'May 15, 11:30 AM',
      type: 'voice',
      direction: 'outgoing',
    }
  ];

  // Fetch available platform users for new chat room setup from Relational Database
  useEffect(() => {
    if (showNewChatModal && currentUser) {
      setUserLoading(true);
      const myId = currentUser.uid || currentUser.id;
      const token = getAccessToken();
      
      fetchAllUsersPaginated(token)
        .then(users => ({ users }))
        .then(data => {
          if (data && data.users) {
            const uList = data.users
              .map((u: any) => ({
                id: u.id,
                ...u,
                photoURL: u.avatarUrl,
                avatarUrl: u.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop'
              }))
              .filter((u: any) => u.id !== myId);
            setAvailableUsers(uList);
          }
        })
        .catch(err => console.error('[Sidebar] Error fetching users from API:', err))
        .finally(() => setUserLoading(false));
    }
  }, [showNewChatModal, currentUser]);

  // Handle new 1-on-1 chat creation
  const handleCreateChat = async (targetUserId: string) => {
    setChatCreating(true);
    try {
      const myId = currentUser.uid || currentUser.id;
      const sortedIds = [myId, targetUserId].sort();
      const chatId = `one_to_one_${sortedIds[0]}___${sortedIds[1]}`;
      
      // Check if a direct one-to-one chat between these two users already exists
      const existing = chats.find(c => c.id === chatId);
      
      if (existing) {
        setShowNewChatModal(false);
        onChatSelect(existing.id);
        return;
      }

      // Create structured chat document on standard relational server
      const token = getAccessToken();
      const res = await fetch('/api/chats', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          type: 'one-to-one',
          memberIds: [myId, targetUserId]
        })
      });

      const data = await res.json();
      if (res.ok && data.chat) {
        setShowNewChatModal(false);
        onChatSelect(data.chat.id);
        if (onRefreshChats) onRefreshChats();
      } else {
        throw new Error(data.error || 'Failed to create chat room.');
      }
    } catch (err) {
      console.error('[Sidebar] Failed creating chat:', err);
    } finally {
      setChatCreating(false);
    }
  };

  // Filter listed chats based on query
  const filteredChats = chats.filter(c =>
    (c.name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (c.lastMessage?.content || '').toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Global real message search (GET /api/search/messages) — debounced 400ms,
  // only fires for queries >= 3 chars on top of the local chat-name filter.
  useEffect(() => {
    const q = searchQuery.trim();
    if (q.length < 3) {
      setMsgSearchResults([]);
      setIsMsgSearching(false);
      return;
    }
    setIsMsgSearching(true);
    const t = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search/messages?q=${encodeURIComponent(q)}&limit=40`, {
          headers: { Authorization: `Bearer ${getAccessToken()}` }
        });
        const data = await res.json();
        setMsgSearchResults(res.ok ? (data.messages || []) : []);
      } catch {
        setMsgSearchResults([]);
      } finally {
        setIsMsgSearching(false);
      }
    }, 400);
    return () => clearTimeout(t);
  }, [searchQuery]);

  /** First-occurrence case-insensitive <mark> highlight (plain JSX text nodes only). */
  const renderMsgExcerpt = (text: string, query: string) => {
    const safeQuery = (query || '').trim();
    if (!safeQuery) return text;
    const idx = text.toLowerCase().indexOf(safeQuery.toLowerCase());
    if (idx === -1) return text;
    return [
      <span key="pre">{text.slice(0, idx)}</span>,
      <mark key="hit" className="bg-amber-400/80 text-black rounded px-0.5">{text.slice(idx, idx + safeQuery.length)}</mark>,
      <span key="post">{text.slice(idx + safeQuery.length)}</span>
    ];
  };

  const myId = currentUser.uid || currentUser.id;

  // Real-time dynamic counts based on the actual Firestore feeds
  const totalChatsCount = chats.length;
  
  const unreadChatsCount = chats.filter(chat => {
    const isLastMessageUnread = chat.lastMessage && 
                                chat.lastMessage.senderId !== myId && 
                                chat.lastMessage.state !== 'read';
    return isLastMessageUnread;
  }).length;

  const groupsChatsCount = chats.filter(chat => chat.type === 'group').length;
  const favouritesCount = starredMsgs.length;

  // Filter registered users who match search query and aren't currentUser
  const matchingUsers = Object.values(allUsers || {}).filter((u: any) => {
    if (u.id === myId) return false;
    const isPrivileged = currentUser?.role === 'admin' || currentUser?.role === 'developer';
    if (u.id === 'user-bot-dirasha' || u.id === 'user-bot-gemini' || u.username === 'dirasha_system' || u.username === 'nexora' || u.email?.toLowerCase() === 'ayptinghanmkhlail@gmail.com') return false;
    const matchesQuery = 
      (u.displayName || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (u.username || '').toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesQuery;
  });

  return (
    <div className={`sidebar-panel flex flex-col ${activeChatId ? 'hidden-on-mobile' : ''}`} style={{ direction: 'ltr' }}>
      {/* Ambient smooth light emission backdrops from HTML design */}
      <div className="bg-blob blob-1"></div>
      <div className="bg-blob blob-2"></div>
      <div className="bg-blob blob-3"></div>
      <div className="bg-blob blob-4"></div>
      
      {/* Dynamic Glassmorphic Floating Top Overlay */}
      <div 
        className="top-glass-overlay" 
        style={{ height: `${activeTab === 'chats' ? 172 : 74}px` }}
      />
      
      {/* 1. STATUS DRAWER / FULLSCREEN PLAYER OVERLAY */}
      {activeStatus && createPortal(
        <div 
          className="fixed inset-0 bg-black/95 backdrop-blur-3xl z-[9999] flex flex-col items-center justify-center animate-fade-in select-none overflow-hidden"
          onClick={(e) => {
            // Close player if clicked on outer black backdrop on desktop/laptop
            if (e.target === e.currentTarget) {
              setActiveStatus(null);
            }
          }}
        >
          {/* Centered mobile-style story container that stretches on small screens but looks beautifully centered on PC */}
          <div 
            className="w-full max-w-[460px] h-full flex flex-col justify-between p-4 pb-10 relative"
            onClick={(e) => {
              const rect = e.currentTarget.getBoundingClientRect();
              const clickX = e.clientX - rect.left;
              const containerWidth = rect.width;
              
              // Smart Tap Logic: Left 35% for Back, rest for Forward
              if (clickX < containerWidth * 0.35) {
                if (activeStatusIndex > 0) {
                  const prevIndex = activeStatusIndex - 1;
                  setActiveStatusIndex(prevIndex);
                  setActiveStatus(activeStatusGroup[prevIndex]);
                }
              } else {
                if (activeStatusIndex < activeStatusGroup.length - 1) {
                  const nextIndex = activeStatusIndex + 1;
                  setActiveStatusIndex(nextIndex);
                  setActiveStatus(activeStatusGroup[nextIndex]);
                } else {
                  setActiveStatus(null);
                }
              }
            }}
            onMouseDown={() => setIsPaused(true)}
            onMouseUp={() => setIsPaused(false)}
            onTouchStart={() => setIsPaused(true)}
            onTouchEnd={() => setIsPaused(false)}
          >
          {/* Top multi-segment progress bar indicators */}
          <div className="w-full flex gap-1.5 mt-4 px-2" onClick={(e) => e.stopPropagation()}>
            {activeStatusGroup.map((_, idx) => (
              <div key={idx} className="h-1 flex-1 bg-white/10 rounded-full overflow-hidden relative">
                <div 
                  className={`absolute top-0 bottom-0 left-0 bg-white/80 transition-all origin-left ${idx < activeStatusIndex ? 'w-full' : idx === activeStatusIndex ? '' : 'w-0'}`}
                  style={{ 
                    width: idx < activeStatusIndex ? '100%' : idx === activeStatusIndex ? '0%' : '0%',
                    animation: (idx === activeStatusIndex && !showViewersSheet && !showCommentsSheet && !showShareSheet && !showDeleteConfirm && !commentText && !isPaused) 
                      ? `status-progress ${statusDuration}s linear forwards` 
                      : 'none'
                  }}
                ></div>
                {/* Visual indicator for paused state */}
                {idx === activeStatusIndex && (showViewersSheet || showCommentsSheet || showShareSheet || showDeleteConfirm || commentText || isPaused) && (
                   <div className="absolute inset-0 bg-white/40 animate-pulse" />
                )}
              </div>
            ))}
          </div>

          {/* Status Header */}
          <div 
            className="flex items-center justify-between mt-4 px-2" 
            onClick={(e) => e.stopPropagation()}
            onMouseDown={(e) => e.stopPropagation()}
            onMouseUp={(e) => e.stopPropagation()}
            onTouchStart={(e) => e.stopPropagation()}
            onTouchEnd={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3">
              <div className="relative p-0.5 rounded-full border border-white/20">
                <img 
                  src={activeStatus.avatar_url || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&h=150&q=80'} 
                  className="w-10 h-10 rounded-full object-cover" 
                  alt=""
                />
              </div>
              <div className="text-left">
                <div className="flex items-center gap-1.5">
                  <h5 className="text-[14px] font-bold text-white tracking-wide">{activeStatus.display_name || activeStatus.username}</h5>
                  {activeStatus.user_id === (currentUser?.uid || currentUser?.id) && (
                    <span className="text-[10px] bg-white/10 text-white/70 font-bold px-2 py-0.5 rounded-full border border-white/10 backdrop-blur-md">You</span>
                  )}
                </div>
                <span className="text-[11px] text-zinc-400/80 font-medium">
                  {new Date(activeStatus.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {activeStatus.content_type === 'video' && (
                <button 
                  onClick={(e) => { e.stopPropagation(); setIsStatusMuted(!isStatusMuted); }}
                  className="p-2.5 rounded-full bg-black/40 border border-white/20 text-white/90 hover:bg-black/60 shadow-lg drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)] transition-all cursor-pointer backdrop-blur-xl"
                >
                  {isStatusMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                </button>
              )}
              <button 
                onClick={(e) => { e.stopPropagation(); setActiveStatus(null); }}
                className="p-2.5 rounded-full bg-black/40 border border-white/20 text-white/90 hover:bg-black/60 shadow-lg drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)] transition-all cursor-pointer backdrop-blur-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Content display container */}
          <div className="flex-1 my-6 flex flex-col overflow-hidden rounded-[32px] relative border border-white/10 bg-black/40 backdrop-blur-sm p-1 shadow-2xl">
              {/* Media container */}
              <div className="relative w-full flex-1 flex items-center justify-center overflow-hidden">
                {activeStatus.content_type === 'video' ? (
                  <video 
                    key={activeStatus.id}
                    src={activeStatus.media_url} 
                    className="max-h-full max-w-full object-contain"
                    autoPlay
                    loop
                    muted={isStatusMuted}
                    playsInline
                    onLoadedMetadata={(e) => {
                       const start = activeStatus.settings?.startTime || 0;
                       if (start > 0) {
                         e.currentTarget.currentTime = start;
                       }
                       const end = activeStatus.settings?.endTime;
                       const duration = end && end > start ? (end - start) : e.currentTarget.duration;
                       if (duration && !isNaN(duration) && duration > 0 && duration !== Infinity) {
                          setStatusDuration(Math.max(3, duration));
                       }
                    }}
                    onDurationChange={(e) => {
                       const start = activeStatus.settings?.startTime || 0;
                       const end = activeStatus.settings?.endTime;
                       const duration = end && end > start ? (end - start) : e.currentTarget.duration;
                       if (duration && !isNaN(duration) && duration > 0 && duration !== Infinity) {
                          setStatusDuration(Math.max(3, duration));
                       }
                    }}
                    onTimeUpdate={(e) => {
                       const end = activeStatus.settings?.endTime;
                       const start = activeStatus.settings?.startTime || 0;
                       if (end && e.currentTarget.currentTime >= end) {
                          e.currentTarget.currentTime = start;
                       } else if (e.currentTarget.currentTime < start) {
                          e.currentTarget.currentTime = start;
                       }
                    }}
                  />
                ) : (
                    <img 
                        src={activeStatus.media_url} 
                        className="max-h-full max-w-full object-contain"
                        alt=""
                        referrerPolicy="no-referrer"
                    />
                )}
              </div>
              
              {/* Text overlays container, absolute above buttom controls to prevent overlapping */}
              {activeStatus.settings?.textOverlays && (
                <div className="absolute bottom-48 left-1/2 -translate-x-1/2 w-full px-8 flex flex-col items-center gap-1.5 z-20 pointer-events-none" onClick={(e) => e.stopPropagation()}>
                  {activeStatus.settings.textOverlays.map((overlay: any) => (
                      <div
                        key={overlay.id}
                        style={{
                          color: overlay.color,
                          fontSize: `${Math.max(10, (overlay.fontSize || 16) * 0.7)}px`,
                          fontWeight: '800',
                          textAlign: 'center',
                          textShadow: '0 2px 10px rgba(0,0,0,1)',
                          width: '100%',
                          lineHeight: '1.2'
                        }}
                      >
                        {overlay.text}
                      </div>
                  ))}
                </div>
              )}

            {/* Caption text - Centered horizontally at bottom, elevated to completely avoid the bottom viewers button */}
            {activeStatus.text_content && !showCommentsSheet && !showViewersSheet && !showShareSheet && (
              <div 
                className="absolute bottom-[82px] left-1/2 -translate-x-1/2 w-[calc(100%-170px)] max-w-[260px] pointer-events-none z-30 flex flex-col items-center"
              >
                <p className="text-[13px] text-white font-extrabold text-center leading-snug drop-shadow-[0_2px_14px_rgba(0,0,0,1)] drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)] tracking-wide selection:bg-neutral-800 line-clamp-3 overflow-hidden text-ellipsis">
                  {activeStatus.text_content}
                </p>
              </div>
            )}

            {/* TikTok Style Vertical Interaction Buttons on Right side - Hidden when secondary sheets are active to prevent UI overlap */}
            <AnimatePresence>
              {!showCommentsSheet && !showViewersSheet && !showShareSheet && (
                <motion.div 
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="absolute right-4 top-1/2 -translate-y-1/2 flex flex-col items-center gap-6 z-30" 
                  onClick={(e) => e.stopPropagation()}
                  onMouseDown={(e) => e.stopPropagation()}
                  onMouseUp={(e) => e.stopPropagation()}
                  onTouchStart={(e) => e.stopPropagation()}
                  onTouchEnd={(e) => e.stopPropagation()}
                >
                  {/* Like Section */}
                  <div className="flex flex-col items-center gap-1">
                      <button 
                        onClick={(e) => handleToggleLikeStatus(activeStatus, e)}
                        className={`w-12 h-12 rounded-full flex items-center justify-center backdrop-blur-2xl border transition-all duration-300 group shadow-[0_4px_16px_rgba(0,0,0,0.5)] drop-shadow-[0_2px_8px_rgba(0,0,0,0.6)] ${
                          activeStatus.has_liked 
                            ? 'bg-rose-500/30 border-rose-500/50 text-rose-400 hover:bg-rose-500/40' 
                            : 'bg-black/50 border-white/20 text-white hover:bg-black/70'
                        }`}
                      >
                        <Heart className={`w-6 h-6 transition-transform group-hover:scale-125 ${activeStatus.has_liked ? 'fill-rose-500' : ''}`} />
                      </button>
                      <span className="text-[12px] font-bold text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]" style={{ textShadow: '0 2px 4px rgba(0,0,0,1)' }}>{activeStatus.likes_count || 0}</span>
                  </div>

                  {/* Comments Section */}
                  <div className="flex flex-col items-center gap-1">
                      <button 
                        onClick={() => setShowCommentsSheet(!showCommentsSheet)}
                        className="w-12 h-12 rounded-full flex items-center justify-center bg-black/50 backdrop-blur-2xl border border-white/20 text-white hover:bg-black/70 transition-all duration-300 group shadow-[0_4px_16px_rgba(0,0,0,0.5)] drop-shadow-[0_2px_8px_rgba(0,0,0,0.6)]"
                      >
                        <MessageCircle className="w-6 h-6 transition-transform group-hover:scale-125" />
                      </button>
                      <span className="text-[12px] font-bold text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]" style={{ textShadow: '0 2px 4px rgba(0,0,0,1)' }}>{statusComments.length}</span>
                  </div>

                  {/* Share Section */}
                  <div className="flex flex-col items-center gap-1">
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          setShowShareSheet(!showShareSheet);
                        }}
                        className="w-12 h-12 rounded-full flex items-center justify-center bg-black/50 backdrop-blur-2xl border border-white/20 text-white hover:bg-black/70 transition-all duration-300 group shadow-[0_4px_16px_rgba(0,0,0,0.5)] drop-shadow-[0_2px_8px_rgba(0,0,0,0.6)]"
                      >
                        <RefreshCw className="w-6 h-6 transition-transform group-hover:scale-125" />
                      </button>
                      <span className="text-[10px] font-bold text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]" style={{ textShadow: '0 2px 4px rgba(0,0,0,1)' }}>Share</span>
                  </div>

                  {/* Delete Section for owners */}
                  {activeStatus.user_id === (currentUser?.uid || currentUser?.id) && (
                    <div className="flex flex-col items-center gap-1">
                        <button 
                          onClick={(e) => handleDeleteStatus(activeStatus.id, e)}
                          className="w-12 h-12 rounded-full flex items-center justify-center bg-red-500/30 backdrop-blur-2xl border border-white/20 text-rose-300 hover:bg-red-500/50 transition-all duration-300 group shadow-[0_4px_16px_rgba(0,0,0,0.5)] drop-shadow-[0_2px_8px_rgba(0,0,0,0.6)]"
                        >
                          <Trash2 className="w-6 h-6 transition-transform group-hover:scale-125" />
                        </button>
                        <span className="text-[10px] font-bold text-rose-400 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]" style={{ textShadow: '0 2px 4px rgba(0,0,0,1)' }}>حذف</span>
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

            {/* Sheets over the media content */}
            <AnimatePresence>
              {showDeleteConfirm && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  onClick={(e) => e.stopPropagation()}
                  onMouseDown={(e) => e.stopPropagation()}
                  onMouseUp={(e) => e.stopPropagation()}
                  onTouchStart={(e) => e.stopPropagation()}
                  onTouchEnd={(e) => e.stopPropagation()}
                  className="absolute inset-0 bg-black/85 backdrop-blur-3xl p-6 flex flex-col items-center justify-center rounded-[32px] z-50 m-1 border border-white/10"
                >
                  <div className="bg-zinc-950/90 border border-white/10 rounded-[28px] p-6 w-full max-w-[340px] text-center shadow-2xl backdrop-blur-xl relative">
                    <div className="w-14 h-14 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-500 flex items-center justify-center mx-auto mb-4 animate-pulse">
                      <Trash2 className="w-6 h-6" />
                    </div>
                    <h4 className="text-[16px] font-extrabold text-white mb-2 font-sans tracking-wide">حذف الحالة</h4>
                    <p className="text-[12px] text-zinc-400 leading-normal mb-5 font-sans">
                      هل أنت متأكد من رغبتك في حذف هذه الحالة؟
                    </p>
                    <div className="flex gap-3 justify-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setShowDeleteConfirm(false);
                          setIsPaused(false);
                        }}
                        className="flex-1 py-2.5 px-4 rounded-xl bg-white/5 border border-white/10 text-white hover:bg-white/10 text-[12px] font-bold transition-all cursor-pointer font-sans"
                      >
                        إلغاء
                      </button>
                      <button
                        onClick={(e) => confirmDeleteStatus(activeStatus.id, e)}
                        className="flex-1 py-2.5 px-4 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-[12px] font-bold transition-all shadow-lg hover:scale-[1.02] active:scale-[0.98] cursor-pointer font-sans"
                      >
                        حذف
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}

              {showViewersSheet && (
                <motion.div 
                  initial={{ opacity: 0, y: 100 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 100 }}
                  onClick={(e) => e.stopPropagation()}
                  className="absolute inset-0 bg-black/70 backdrop-blur-3xl p-6 flex flex-col rounded-[40px] z-20 m-2 border border-white/10"
                >
                  <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-4">
                    <h4 className="text-[14px] font-bold text-white tracking-widest uppercase flex items-center gap-2">
                      <Eye className="w-5 h-5 text-zinc-400" /> Viewed By ({statusViewers.length})
                    </h4>
                    <button 
                      onClick={() => setShowViewersSheet(false)}
                      className="p-2 text-white/60 hover:text-white rounded-full bg-white/5 transition-all"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="flex-1 overflow-y-auto custom-scroll space-y-3">
                    {statusViewers.length === 0 ? (
                      <div className="flex flex-col items-center justify-center py-20 opacity-30">
                         <Eye className="w-12 h-12 mb-3" />
                         <p className="text-[12px] font-medium">No views yet</p>
                      </div>
                    ) : (
                      statusViewers.map(viewer => (
                        <div key={viewer.id} className="flex items-center gap-3.5 p-3 rounded-3xl bg-white/[0.03] border border-white/5">
                          <img 
                            src={viewer.avatar_url || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&h=150&q=80'} 
                            className="w-10 h-10 rounded-full object-cover" 
                            alt=""
                          />
                          <div className="text-left flex-1 min-w-0">
                            <p className="text-[14px] font-bold text-white truncate">{viewer.display_name || viewer.username}</p>
                            <p className="text-[11px] text-zinc-400 font-mono">
                              {new Date(viewer.viewed_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </p>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </motion.div>
              )}

              {showCommentsSheet && (
                <motion.div 
                  initial={{ opacity: 0, y: 100 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 100 }}
                  onClick={(e) => e.stopPropagation()}
                  onMouseDown={(e) => e.stopPropagation()}
                  onMouseUp={(e) => e.stopPropagation()}
                  onTouchStart={(e) => e.stopPropagation()}
                  onTouchEnd={(e) => e.stopPropagation()}
                  className="absolute inset-0 bg-black/70 backdrop-blur-3xl p-6 flex flex-col rounded-[40px] z-20 m-2 border border-white/10"
                >
                  <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-4">
                    <h4 className="text-[14px] font-bold text-white tracking-widest uppercase flex items-center gap-2">
                      <MessageCircle className="w-5 h-5 text-zinc-400" /> Comments ({statusComments.length})
                    </h4>
                    <button 
                      onClick={() => setShowCommentsSheet(false)}
                      className="p-2 text-white/60 hover:text-white rounded-full bg-white/5 transition-all"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="flex-1 overflow-y-auto custom-scroll space-y-4 mb-4">
                    {statusComments.length === 0 ? (
                      <div className="flex flex-col items-center justify-center py-20 opacity-30">
                         <MessageCircle className="w-12 h-12 mb-3" />
                         <p className="text-[12px] font-medium">No comments yet</p>
                      </div>
                    ) : (
                      statusComments.map(comment => (
                        <div key={comment.id} className="flex gap-3.5 p-3.5 rounded-3xl bg-white/[0.03] border border-white/5 items-start">
                          <img 
                            src={comment.avatar_url || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&h=150&q=80'} 
                            className="w-9 h-9 rounded-full object-cover mt-0.5" 
                            alt=""
                          />
                          <div className="text-left flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-2">
                              <p className="text-[14px] font-bold text-white truncate">{comment.display_name || comment.username}</p>
                              <p className="text-[10px] text-zinc-500 font-mono shrink-0">
                                {new Date(comment.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </p>
                            </div>
                            <p className="text-[12px] text-zinc-200 mt-1 break-words font-sans">{comment.text_content}</p>
                          </div>
                        </div>
                      ))
                    )}
                  </div>

                  {/* Organized Glass Reply Bar inside Comments Sheet */}
                  <div className="mt-auto pt-4 border-t border-white/10">
                    <form onSubmit={handleSendStatusComment} className="flex gap-2.5">
                      <input
                        type="text"
                        placeholder="Type a reply..."
                        value={commentText}
                        onChange={(e) => setCommentText(e.target.value)}
                        className="flex-1 bg-white/5 border border-white/10 rounded-[20px] py-2.5 px-5 text-[13px] text-white placeholder-white/20 focus:outline-none focus:border-white/30 focus:bg-white/10 transition-all font-sans"
                      />
                      <button
                        type="submit"
                        disabled={!commentText.trim()}
                        className="w-10 h-10 bg-white/10 hover:bg-white/20 disabled:opacity-30 disabled:cursor-not-allowed text-white rounded-full transition-all flex items-center justify-center cursor-pointer border border-white/10 backdrop-blur-md"
                      >
                        <SendHorizontal className="w-4.5 h-4.5" />
                      </button>
                    </form>
                  </div>
                </motion.div>
              )}

              {showShareSheet && (
                <motion.div 
                  initial={{ opacity: 0, y: 100 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 100 }}
                  onClick={(e) => e.stopPropagation()}
                  onMouseDown={(e) => e.stopPropagation()}
                  onMouseUp={(e) => e.stopPropagation()}
                  onTouchStart={(e) => e.stopPropagation()}
                  onTouchEnd={(e) => e.stopPropagation()}
                  className="absolute inset-0 bg-black/70 backdrop-blur-3xl p-6 flex flex-col rounded-[40px] z-20 m-2 border border-white/10"
                >
                  <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-4">
                    <h4 className="text-[14px] font-bold text-white tracking-widest uppercase flex items-center gap-2">
                      <RefreshCw className="w-5 h-5 text-zinc-400" /> Share Status
                    </h4>
                    <button 
                      onClick={() => setShowShareSheet(false)}
                      className="p-2 text-white/60 hover:text-white rounded-full bg-white/5 transition-all"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <div className="flex-1 overflow-y-auto custom-scroll space-y-6">
                    {/* Share to My Status */}
                    <button 
                      onClick={handleShareToMyStatus}
                      className="w-full flex items-center gap-4 p-4 rounded-3xl bg-white/10 border border-white/10 hover:bg-white/20 transition-all text-left group"
                    >
                      <div className="w-12 h-12 rounded-full bg-zinc-600 flex items-center justify-center text-white group-hover:scale-110 transition-transform shadow-lg">
                        <Plus className="w-6 h-6" />
                      </div>
                      <div>
                        <p className="text-[15px] font-bold text-white">Share to My Status</p>
                        <p className="text-[12px] text-white/40">Post this to your own status feed</p>
                      </div>
                    </button>

                    <div className="space-y-3">
                      <p className="text-[11px] font-bold text-white/20 uppercase tracking-[0.2em] px-2">Send to Contacts</p>
                      {chats.map(chat => (
                        <button 
                          key={chat.id}
                          onClick={() => handleSendStatusToChat(chat.id)}
                          className="w-full flex items-center gap-4 p-3.5 rounded-3xl bg-white/[0.03] border border-white/5 hover:bg-white/[0.08] transition-all text-left"
                        >
                          <img 
                            src={chat.avatarUrl || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&h=150&q=80'} 
                            className="w-10 h-10 rounded-full object-cover" 
                            alt=""
                          />
                          <div className="flex-1 min-w-0">
                            <p className="text-[14px] font-bold text-white truncate">{chat.name}</p>
                            <p className="text-[11px] text-white/30 truncate">{chat.type === 'one-to-one' ? 'Direct Message' : 'Group Chat'}</p>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>


            {/* View count summary at bottom - Pin to extreme bottom with subtle design */}
            {activeStatus.user_id === (currentUser?.uid || currentUser?.id) && !showCommentsSheet && !showViewersSheet && !showShareSheet && (
              <div 
                className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center justify-center gap-2 bg-black/30 backdrop-blur-3xl py-2.5 px-5 rounded-full border border-white/20 cursor-pointer hover:bg-black/40 hover:scale-105 transition-all z-40 shadow-2xl drop-shadow-[0_2px_8px_rgba(0,0,0,0.5)] active:scale-95 group" 
                onClick={(e) => {
                  e.stopPropagation();
                  setShowViewersSheet(true);
                }}
                onMouseDown={(e) => e.stopPropagation()}
                onMouseUp={(e) => e.stopPropagation()}
                onTouchStart={(e) => e.stopPropagation()}
                onTouchEnd={(e) => e.stopPropagation()}
              >
                <Eye className="w-3.5 h-3.5 text-white/70 group-hover:text-white transition-colors" />
                <span className="text-[12px] font-black text-white/90 group-hover:text-white transition-colors tracking-widest">{activeStatus.views_count || 0}</span>
              </div>
            )}
          </div>
          </div>
        </div>,
        document.body
      )}

      {/* 2. SECURE AUDIO/VIDEO RINGING STATE SIMULATION OVERLAY */}
      {activeCall && (
        <div className="absolute inset-0 bg-[#091014]/98 z-50 flex flex-col items-center justify-between p-8 text-center animate-scale-in">
          <div className="mt-12 flex flex-col items-center">
            <div className="text-[10px] font-mono tracking-widest text-blue-400 bg-blue-500/10 py-1.5 px-4 rounded-full border border-blue-500/20 flex items-center gap-1.5 mb-8">
              <ShieldCheck className="w-3.5 h-3.5 animate-pulse" />
              <span>Secure Encrypted Connection</span>
            </div>
            
            {/* Pulsing Avatar container */}
            <div className="relative mb-6">
              <span className="absolute inset-0 rounded-full bg-blue-500/20 animate-ping"></span>
              <img 
                src={activeCall.userAvatar} 
                className="w-24 h-24 rounded-full object-cover border-4 border-blue-500/30 relative z-10 shadow-2xl" 
                alt=""
                referrerPolicy="no-referrer"
              />
            </div>

            <h4 className="text-lg font-bold text-white mb-1.5">{activeCall.userName}</h4>
            <span className="text-xs text-slate-400 animate-pulse font-mono">
              Securing connection line... {Math.floor(callDuration / 60)}:{(callDuration % 60).toString().padStart(2, '0')}
            </span>
          </div>

          {/* Pulsing sound waves */}
          <div className="flex items-center gap-1.5 my-4">
            <span className="w-1.5 h-8 bg-blue-500/60 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
            <span className="w-1.5 h-12 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '100ms' }}></span>
            <span className="w-1.5 h-16 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '200ms' }}></span>
            <span className="w-1.5 h-10 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
            <span className="w-1.5 h-6 bg-blue-500/60 rounded-full animate-bounce" style={{ animationDelay: '400ms' }}></span>
          </div>

          {/* Action calls */}
          <div className="mb-12 flex gap-4">
            <button 
              onClick={() => setActiveCall(null)}
              className="w-14 h-14 rounded-full bg-red-600 hover:bg-red-500 flex items-center justify-center text-white shadow-lg transition-transform hover:scale-105 active:scale-95 cursor-pointer"
              title="Hang up"
            >
              <PhoneOff className="w-6 h-6" />
            </button>
            <button 
              className="w-14 h-14 rounded-full bg-zinc-800 text-slate-300 flex items-center justify-center hover:bg-zinc-700 transition"
              title="Mute"
            >
              <Volume2 className="w-6 h-6 text-slate-400" />
            </button>
          </div>
        </div>
      )}

      {/* 3. PREMIUM APP HEADER */}
      <header className="app-header">
        <div className="flex items-center gap-3">
          <h1 className="app-title">
            {activeTab === 'chats' ? 'Chats' :
             activeTab === 'updates' ? 'Updates' :
             activeTab === 'calls' ? 'Calls' : 'Settings'}
          </h1>
        </div>
        <div className="header-actions">
          {activeTab === 'chats' && (
            <>
              <div className="icon-btn" onClick={() => setShowNewChatModal(true)} title="New Chat">
                <svg viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2.3" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
                  <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path>
                  <circle cx="12" cy="13" r="4"></circle>
                </svg>
              </div>
              <div className="icon-btn plus-btn" onClick={() => setShowNewChatModal(true)} title="Add Contact">
                <svg viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="w-4.5 h-4.5">
                  <line x1="12" y1="5" x2="12" y2="19"></line>
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
              </div>
            </>
          )}
          {activeTab === 'updates' && (
            <div className="text-left w-full pl-2">
              <h1 className="text-xl font-bold text-white tracking-tight">Updates</h1>
            </div>
          )}
          {activeTab === 'communities' && (
            <div className="text-left w-full pl-2">
              <h1 className="text-xl font-bold text-white tracking-tight">Communities</h1>
              <p className="text-[11px] text-white/30 mt-2 px-2">ميزة المجتمعات قيد التطوير — مجموعاتك الحالية في تبويب الدردشات.</p>
            </div>
          )}
          {activeTab === 'calls' && (
            <div className="text-left w-full pl-2">
              <h1 className="text-xl font-bold text-white tracking-tight">Calls</h1>
            </div>
          )}
        </div>
      </header>

      {/* 4. PREMIUM SEARCH CONTAINER */}
      {activeTab === 'chats' && (
        <div className="search-container">
          <div className="search-box">
            <div className="search-icon">
              <Search className="w-5 h-5 text-zinc-400" />
            </div>
            <input
              type="text"
              className="search-input"
              placeholder="Search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{ direction: 'ltr' }}
            />
            <button
              onClick={async () => {
                const code = window.prompt('أدخل كود الدعوة للمجموعة:');
                if (!code || !code.trim()) return;
                try {
                  const res = await fetch('/api/chats/join', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` },
                    body: JSON.stringify({ code: code.trim() }),
                  });
                  const d = await res.json();
                  if (!res.ok) throw new Error(d.error || 'فشل الانضمام.');
                  if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                    (window as any).showGlobalToast('تم الانضمام إلى المجموعة.', 'success');
                  }
                  (window as any).__openDirashaChat?.(d.chatId);
                } catch (e: any) {
                  if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                    (window as any).showGlobalToast(e.message, 'error');
                  }
                }
              }}
              title="الانضمام بكود دعوة"
              className="ml-1.5 flex items-center px-3 py-2 rounded-xl bg-emerald-500/15 text-emerald-300 border border-emerald-500/25 text-[11px] font-bold hover:bg-emerald-500/25 transition-colors cursor-pointer shrink-0"
            >
              انضم
            </button>
            <button
              onClick={() => setShowGroupCreate(true)}
              title="مجموعة جديدة"
              className="ml-2 flex items-center gap-1 px-3 py-2 rounded-xl bg-blue-500/15 text-blue-300 border border-blue-500/25 text-[11px] font-bold hover:bg-blue-500/25 transition-colors cursor-pointer shrink-0"
            >
              <Users className="w-4 h-4" />
              مجموعة
            </button>
            <button
              onClick={() => setShowChannelCreate(true)}
              title="قناة جديدة"
              className="ml-1.5 flex items-center gap-1 px-3 py-2 rounded-xl bg-emerald-500/15 text-emerald-300 border border-emerald-500/25 text-[11px] font-bold hover:bg-emerald-500/25 transition-colors cursor-pointer shrink-0"
            >
              <Megaphone className="w-4 h-4" />
              قناة
            </button>
          </div>
        </div>
      )}

      {/* 5. iOS FILTER CATEGORY TABS CONTAINER */}
      {activeTab === 'chats' && (
        <div className="tabs-container">
          <div 
            className={`tab-item ${chatFilter === 'all' ? 'active' : ''}`}
            onClick={() => setChatFilter('all')}
          >
            All
          </div>
          <div 
            className={`tab-item ${chatFilter === 'unread' ? 'active' : ''}`}
            onClick={() => setChatFilter('unread')}
          >
            Unread
          </div>
          <div 
            className={`tab-item ${chatFilter === 'groups' ? 'active' : ''}`}
            onClick={() => setChatFilter('groups')}
          >
            Groups
          </div>
          <div
            className={`tab-item ${chatFilter === 'favourites' ? 'active' : ''}`}
            onClick={() => setChatFilter('favourites')}
          >
            Favourites
          </div>
          <div
            className={`tab-item ${showArchived ? 'active' : ''}`}
            onClick={() => setShowArchived(!showArchived)}
          >
            الأرشيف
          </div>
          {/* Custom folders (Telegram parity): created inline, chats assigned via context menu */}
          {(((currentUser as any)?.chatFolders as any[]) || []).map((f) => (
            <div
              key={f.id}
              className={`tab-item ${activeFolderId === f.id ? 'active' : ''} flex items-center gap-1`}
              onClick={() => setActiveFolderId(activeFolderId === f.id ? null : f.id)}
            >
              <span>{f.name}</span>
              {activeFolderId === f.id && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (!window.confirm(`حذف المجلد "${f.name}"؟ (المحادثات لن تُحذف)`)) return;
                    const rest = ((currentUser as any)?.chatFolders as any[]).filter((x) => x.id !== f.id);
                    updateUserSettings({ chatFolders: rest });
                    setActiveFolderId(null);
                  }}
                  className="text-red-400 hover:text-red-300 text-[10px] font-black px-1"
                  title="حذف المجلد"
                >
                  ✕
                </button>
              )}
            </div>
          ))}
          <div
            className="tab-item"
            onClick={async () => {
              const name = window.prompt('اسم المجلد الجديد:');
              if (!name || !name.trim()) return;
              const folders = [...(((currentUser as any)?.chatFolders as any[]) || [])];
              folders.push({ id: 'fld-' + Date.now(), name: name.trim().slice(0, 20), chatIds: [] });
              await updateUserSettings({ chatFolders: folders });
            }}
          >
            + مجلد
          </div>
          <div
            className={`tab-item ${showLocked ? 'active' : ''}`}
            onClick={() => {
              // WhatsApp parity: locked chats revealed only after passcode
              if (!showLocked) {
                // AUTH-04: NO default passcode — unset PIN means the feature is
                // off; fail closed (never trust a fallback constant).
                const expected = String(currentUser?.privacySettings?.screenLockPasscode || '');
                if (!expected) {
                  if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                    (window as any).showGlobalToast('لم يتم ضبط رمز القفل بعد.', 'error');
                  }
                  return;
                }
                const entered = window.prompt('أدخل رمز القفل لعرض المحادثات المقفلة:');
                if (entered !== expected) {
                  if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                    (window as any).showGlobalToast('رمز غير صحيح.', 'error');
                  }
                  return;
                }
                setLockedUnlocked(true);
              } else {
                setLockedUnlocked(false);
              }
              setShowLocked(!showLocked);
            }}
          >
            المقفلة 🔒
          </div>
        </div>
      )}

      {/* CORE DYNAMIC BODY CONTENT SCROLLABLE PANELS */}
      <div className={`chats-list-scroll-area ${activeTab === 'chats' ? 'pts-chats' : 'pts-compact'}`}>
        
        {/* CHATS CORE MAIN VIEW */}
        {activeTab === 'chats' && (
          <div className="chats-list">
            {chatFilter === 'favourites' ? (
              <div className="p-3 space-y-2 select-text text-left">
                <div className="text-[11px] font-extrabold text-amber-500 uppercase tracking-wider mb-2 flex items-center gap-1.5 justify-start">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Starred Messages ({starredMsgs.length})</span>
                </div>
                
                {starredMsgs.length === 0 ? (
                  <div className="p-8 text-center text-slate-400 bg-[#1a232a] rounded-xl border border-white/5 shadow-inner mt-4">
                    <Clock className="w-8 h-8 text-amber-500/60 mx-auto mb-2.5" />
                    <p className="text-xs font-bold text-white mb-1.5 font-sans">No Starred Messages</p>
                    <p className="text-[11px] text-slate-400 leading-relaxed font-sans">Any message you star in your chats will appear here instantly for quick reference.</p>
                  </div>
                ) : (
                  starredMsgs.map((item) => (
                    <div 
                      key={item.docId}
                      onClick={() => onSetHighlightMsgId && onSetHighlightMsgId(item.chatId, item.id)}
                      className="p-3 bg-[#1e2930] hover:bg-[#202c33] active:bg-[#2a3942] rounded-xl border border-white/5 transition-all cursor-pointer shadow-sm relative group text-left"
                    >
                      <div className="flex items-center justify-between mb-1 text-left">
                        <span className="text-blue-400 font-bold text-xs">{item.senderName}</span>
                        <div className="flex items-center gap-1 text-[10px] text-slate-400 font-mono">
                          <Clock className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                          <span>{new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        </div>
                      </div>
                      <p className="text-[11px] text-slate-200 line-clamp-2 leading-relaxed break-words">{item.content}</p>
                      
                      <div className="mt-1 flex items-center justify-start text-[10px] text-blue-400 font-bold opacity-0 group-hover:opacity-100 transition-opacity">
                        <span>Click to jump to message ↩</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            ) : (
              <>
                {searchQuery && (
                  <div className="bg-[#1a232a] px-4 py-2 text-[11px] font-bold text-slate-400 border-b border-white/5">
                    Matching Chats ({filteredChats.length})
                  </div>
                )}

                {/* Chats list rendering with customized filters */}
                {filteredChats.length > 0 && filteredChats
                  .slice()
                  .sort((x, y) => {
                    // Real pinned-to-top: user_settings.pinnedChats order wins
                    const pins: string[] = ((currentUser as any)?.pinnedChats as string[]) || [];
                    const px = pins.indexOf(x.id), py = pins.indexOf(y.id);
                    const rx = px === -1 ? 999 : px, ry = py === -1 ? 999 : py;
                    return rx - ry;
                  })
                  .filter(chat => {
                    const myId = currentUser?.uid || currentUser?.id;
                    const isPrivileged = currentUser?.role === 'admin' || currentUser?.role === 'developer';
                    // Real archived + locked + custom-folder filters (user_settings)
                    const archivedList: string[] = ((currentUser as any)?.archivedChats as string[]) || [];
                    const lockedList: string[] = ((currentUser as any)?.lockedChats as string[]) || [];
                    const isArchived = archivedList.includes(chat.id);
                    const isLocked = lockedList.includes(chat.id);
                    // Telegram-parity custom folders: active folder filters to its chats
                    if (activeFolderId) {
                      const folder = (((currentUser as any)?.chatFolders as any[]) || []).find(f => f.id === activeFolderId);
                      return folder ? folder.chatIds.includes(chat.id) : false;
                    }
                    if (showLocked) return isLocked;
                    if (isLocked) return false; // locked chats hidden from main list
                    if (showArchived) return isArchived;
                    if (isArchived) return false;

                    const isLastMessageUnread = chat.lastMessage &&
                                                chat.lastMessage.senderId !== myId &&
                                                chat.lastMessage.state !== 'read';
                    if (chatFilter === 'unread') return isLastMessageUnread;
                    if (chatFilter === 'groups') return chat.type === 'group';
                    return true;
                  })
                  .map((chat, idx) => {
                    const isActive = activeChatId === chat.id;
                    const myId = currentUser?.uid || currentUser?.id;
                    const hasUnread = (chat.lastMessage &&
                                        chat.lastMessage.senderId !== myId &&
                                        chat.lastMessage.state !== 'read') ||
                                      ((((currentUser as any)?.unreadMarks as string[]) || []).includes(chat.id));
                    const isOutgoing = chat.lastMessage && chat.lastMessage.senderId === myId;
                    const isRead = chat.lastMessage && chat.lastMessage.state === 'read';

                    return (
                      <div
                        key={chat.id}
                        onContextMenu={(e) => {
                          e.preventDefault();
                          setContextMenu({ x: e.clientX, y: e.clientY, chatId: chat.id, chat });
                        }}
                        onClick={() => {
                          setSearchQuery('');
                          // Clear a manual mark-as-unread when the chat is opened
                          const marks: string[] = [...(((currentUser as any)?.unreadMarks as string[]) || [])];
                          if (marks.includes(chat.id)) {
                            updateUserSettings({ unreadMarks: marks.filter((m) => m !== chat.id) });
                          }
                          onChatSelect(chat.id);
                        }}
                        className={`chat-row ${isActive ? 'bg-white/10' : ''}`}
                      >
                        {/* Elegant custom avatar wrapper */}
                        <div className="avatar-wrapper">
                          <img
                            src={chat.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop'}
                            alt={chat.name}
                            className={`avatar-img object-cover ${chat.type === 'channel' ? 'ring-2 ring-emerald-500/60' : ''}`}
                            referrerPolicy="no-referrer"
                          />
                          {chat.type === 'channel' && (
                            <span
                              className="absolute bottom-0 left-0 w-5 h-5 rounded-full bg-emerald-500 border-2 border-[#111b21] flex items-center justify-center shadow-lg"
                              title="قناة"
                            >
                              <Megaphone className="w-2.5 h-2.5 text-black" strokeWidth={2.8} />
                            </span>
                          )}
                          {chat.type === 'one-to-one' && chat.otherMember?.onlineStatus === 'online' && (
                            <span className="online-indicator online-indicator-pulse"></span>
                          )}
                        </div>

                        {/* Liquid glass text content panels */}
                        <div className="chat-content">
                          <div className="chat-top-row">
                            <span className="chat-name flex items-center gap-1.5 min-w-0">
                              {chat.name}
                              {chat.type === 'channel' && (
                                <Megaphone className="w-3 h-3 text-emerald-400 shrink-0" />
                              )}
                              {chat.type === 'one-to-one' && chat.otherMember?.verified && (
                                <VerifiedBadge className="w-3.5 h-3.5 shrink-0" />
                              )}
                            </span>
                            <span className="chat-time">
                              {chat.lastMessage ? new Date(chat.lastMessage.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '09:07/26'}
                            </span>
                          </div>

                          <div className="chat-bottom-row">
                            <div className="chat-message-container min-w-0 flex-1">
                              {isOutgoing && chat.lastMessage && (
                                <div className="flex items-center shrink-0 mr-1.5 translate-y-[0.5px]">
                                  {chat.lastMessage.state === 'sending' ? (
                                    <Loader2 className="w-3.5 h-3.5 text-slate-500 animate-spin" strokeWidth={2.4} />
                                  ) : chat.lastMessage.state === 'read' ? (
                                    <CheckCheck className="w-3.5 h-3.5 text-[#53bdeb]" strokeWidth={2.4} />
                                  ) : chat.lastMessage.state === 'delivered' ? (
                                    <CheckCheck className="w-3.5 h-3.5 text-slate-500" strokeWidth={2.4} />
                                  ) : (
                                    <Check className="w-3.5 h-3.5 text-slate-500" strokeWidth={2.4} />
                                  )}
                                </div>
                              )}
                              <span className={`chat-message truncate ${chat.activeTypers && chat.activeTypers.length > 0 ? 'text-green-400 font-bold' : ''}`}>
                                {chat.activeTypers && chat.activeTypers.length > 0 ? (
                                  <span className="flex items-center gap-1.5">
                                    {chat.activeTypers.join(', ')} is typing...
                                  </span>
                                ) : (
                                  // E2EE (Agent I): never render (or truncate) raw DIR1
                                  // ciphertext in previews — show the lock placeholder instead.
                                  // GROUP E2EE: DIRG1 sender-key envelopes get the same guard.
                                  // F20: channels are excluded — channel content is server
                                  // plaintext by design, so no lock glyph is ever implied
                                  // there (even if a subscriber literally types 'DIR1:').
                                  chat.lastMessage
                                    ? (chat.type !== 'channel' && typeof chat.lastMessage.content === 'string' && (chat.lastMessage.content.startsWith('DIR1:') || chat.lastMessage.content.startsWith('DIRM1:') || chat.lastMessage.content.startsWith('DIRG1:'))
                                        ? <span className="text-zinc-500 italic">🔒 رسالة مشفرة</span>
                                        : chat.lastMessage.content)
                                    : <span className="text-zinc-500 italic">Select to start chatting...</span>
                                )}
                              </span>
                            </div>
                            
                            {/* Fluid Glass Badges */}
                            {hasUnread && (                              <div className="badge-unread-container flex items-center justify-center shrink-0 ml-auto">
                                <span className="badge-unread">
                                  {chat.unreadCount || 1}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
              </>
            )}

            {/* Real message search results (server-side, queries >= 3 chars) */}
            {searchQuery.trim().length >= 3 && (
              <>
                <div className="bg-[#1a232a] px-4 py-2 text-[11px] font-bold text-slate-400 border-b border-white/5 mt-4 flex items-center justify-between gap-2">
                  <span>نتائج الرسائل ({msgSearchResults.length})</span>
                  {isMsgSearching && <Loader2 className="w-3.5 h-3.5 text-slate-400 animate-spin shrink-0" />}
                </div>
                {!isMsgSearching && msgSearchResults.length === 0 ? (
                  <div className="py-5 text-center text-xs text-slate-500 bg-[#111b21] font-sans">
                    لا توجد رسائل مطابقة في محادثاتك
                  </div>
                ) : (
                  msgSearchResults.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => {
                        setSearchQuery('');
                        if (onSetHighlightMsgId) onSetHighlightMsgId(item.chatId, item.id);
                      }}
                      className="p-3.5 hover:bg-[#202c33] border-b border-white/5 cursor-pointer transition-all text-left"
                    >
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="text-[11px] font-bold text-blue-400 truncate">{item.chatName || 'محادثة'}</span>
                        <span className="text-[10px] text-slate-400 font-mono shrink-0">
                          {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-200 font-bold mb-0.5" dir="auto">{item.senderName || 'مستخدم'}</p>
                      <p className="text-[11px] text-slate-300 line-clamp-2 leading-relaxed break-words" dir="auto">
                        {renderMsgExcerpt(String(item.content || ''), searchQuery)}
                      </p>
                    </div>
                  ))
                )}
              </>
            )}

            {/* Direct user results when searching */}
            {searchQuery && (
              <>
                <div className="bg-[#1a232a] px-4 py-2 text-[11px] font-bold text-slate-400 border-b border-white/5 mt-4">
                  Platform Users ({matchingUsers.length})
                </div>
                {matchingUsers.length > 0 ? (
                  matchingUsers.map((user: any) => {
                    return (
                      <div
                        key={user.id}
                        onClick={() => {
                          setSearchQuery('');
                          if (onViewProfile) {
                            onViewProfile(user.id);
                          } else {
                            handleCreateChat(user.id);
                          }
                        }}
                        className="p-3.5 flex items-center gap-3.5 hover:bg-[#202c33] border-b border-white/5 cursor-pointer transition-all text-left"
                      >
                        <div className="relative shrink-0">
                          <img
                            src={user.photoURL || user.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop'}
                            alt={user.displayName}
                            className="w-11 h-11 rounded-full object-cover border border-white/10"
                            referrerPolicy="no-referrer"
                          />
                          {allUsers[user.id]?.onlineStatus === 'online' && (
                            <span className="online-indicator online-indicator-pulse !w-3 !h-3"></span>
                          )}
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1 justify-start">
                            {user.verified && (
                              <VerifiedBadge className="w-4 h-4 shrink-0" />
                            )}
                            <h5 className="text-sm font-bold text-white truncate font-sans">
                              {user.displayName}
                            </h5>
                          </div>
                          <span className="text-xs text-slate-400 font-mono">@{user.username || 'user'}</span>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="py-6 text-center text-xs text-slate-500 bg-[#111b21] font-sans">
                    No users found matching search criteria...
                  </div>
                )}
              </>
            )}

            {/* Placeholder fallbacks */}
            {filteredChats.length === 0 && (!searchQuery) && (
              <div className="py-16 px-6 text-center text-slate-400 flex flex-col items-center justify-center gap-4 bg-[#111b21]">
                <div className="p-4 bg-[#202c33] rounded-full">
                  <MessageCircle className="w-8 h-8 text-blue-400" />
                </div>
                <p className="text-xs leading-relaxed max-w-[240px] font-sans">No active chats found yet.</p>
                <button
                  onClick={() => setShowNewChatModal(true)}
                  className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1.5 font-bold transition-all px-4 py-2 rounded-lg bg-[#202c33] hover:bg-[#2a3942] cursor-pointer"
                >
                  <Plus className="w-4 h-4" /> Start a new chat now
                </button>
              </div>
            )}
          </div>
        )}

        {/* UPDATES TAB ACCURATE RECONSTRUCTION */}
        {activeTab === 'updates' && (() => {
          const myId = currentUser?.uid || currentUser?.id;
          
          // Group statuses by user
          const groupedByUserId = statusesList.reduce((acc, status) => {
            if (!acc[status.user_id]) {
              acc[status.user_id] = [];
            }
            acc[status.user_id].push(status);
            return acc;
          }, {} as Record<string, any[]>);

          const myStatuses = (groupedByUserId[myId] || []).sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
          const hasMyStatus = myStatuses.length > 0;
          const myLatestStatus = hasMyStatus ? [...myStatuses].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0] : null;
          
          // Filter out my own statuses from the recent updates list
          const contactStatusGroups = (Object.entries(groupedByUserId) as [string, any[]][])
            .filter(([uid]) => uid !== myId)
            .map(([uid, group]) => {
              const sorted = [...group].sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
              const latest = [...group].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];
              return {
                userId: uid,
                statuses: sorted,
                latest: latest
              };
            });

          return (
            <div className="flex-1 overflow-y-auto custom-scroll w-full p-0">
              {/* My Status Section */}
              <div className="px-4 py-6 border-b border-white/5">
                <h2 className="text-[12px] font-bold text-white/30 uppercase tracking-widest mb-5 px-1">Status</h2>
                
                <input
                  type="file"
                  ref={statusFileInputRef}
                  className="hidden"
                  accept="image/png, image/jpeg, image/jpg, image/webp, video/mp4, video/quicktime, video/webm"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      if (onStatusFileChange) onStatusFileChange(file);
                      e.target.value = '';
                    }
                  }}
                />
                
                <div className="flex items-center justify-between p-3 rounded-[24px] hover:bg-white/[0.04] transition-all duration-300 group border border-transparent hover:border-white/5">
                  <div 
                    className="flex items-center gap-4 flex-1 cursor-pointer"
                    onClick={() => {
                      if (hasMyStatus) {
                        // Open my own status for playback!
                        setActiveStatusGroup(myStatuses);
                        setActiveStatusIndex(0);
                        setActiveStatus(myStatuses[0]);
                      } else {
                        statusFileInputRef.current?.click();
                      }
                    }}
                  >
                    <div className="relative">
                      <div className={`w-14 h-14 rounded-full border-2 ${hasMyStatus ? 'border-transparent' : 'border-white/10'} p-0.5 overflow-hidden group-hover:border-zinc-400 transition-all duration-500`}>
                        <img
                          src={currentUser?.avatarUrl || currentUser?.photoURL || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&h=150&q=80'}
                          alt="My Status"
                          className="w-full h-full rounded-full object-cover"
                        />
                      </div>
                      {hasMyStatus && <SegmentedRing count={myStatuses.length} size={56} color="#71717a" />}
                      {!hasMyStatus && (
                        <div className="absolute bottom-0 right-0 bg-zinc-600 text-white rounded-full border-2 border-[#1c1c1e] w-6 h-6 flex items-center justify-center shadow-lg">
                          <Plus className="w-4 h-4" />
                        </div>
                      )}
                    </div>
                    <div className="text-left flex-1 min-w-0">
                      <h3 className="text-[16px] font-bold text-white mb-0.5">My Status</h3>
                      <p className="text-[13px] text-white/40 truncate">
                        {hasMyStatus 
                          ? `Last update: ${new Date(myLatestStatus?.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}` 
                          : 'Tap to add status update'}
                      </p>
                    </div>
                  </div>

                  {hasMyStatus && (
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        statusFileInputRef.current?.click();
                      }}
                      title="إضافة حالة جديدة"
                      className="w-10 h-10 rounded-full bg-white/5 text-white/70 hover:bg-white/10 hover:text-white transition-all cursor-pointer flex items-center justify-center border border-white/10 backdrop-blur-md"
                    >
                      <Plus className="w-5 h-5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Recent Updates */}
              <div className="px-4 py-6">
                <h2 className="text-[12px] font-bold text-white/30 uppercase tracking-widest mb-5 px-1">Recent updates</h2>
                
                <div className="space-y-2">
                  {contactStatusGroups.map(group => (
                    <div 
                      key={group.userId}
                      className="flex items-center gap-4 p-3 rounded-[24px] hover:bg-white/[0.04] transition-all duration-300 cursor-pointer border border-transparent hover:border-white/5"
                      onClick={() => {
                        setActiveStatusGroup(group.statuses);
                        setActiveStatusIndex(0);
                        setActiveStatus(group.statuses[0]);
                      }}
                    >
                      <div className="relative w-14 h-14 shrink-0">
                        <div className="w-full h-full rounded-full border-[2.5px] border-zinc-500/10 p-0.5 overflow-hidden ring-2 ring-transparent group-hover:ring-zinc-500/20 transition-all duration-500 relative">
                          <img
                            src={group.latest.avatar_url || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&h=150&q=80'}
                            alt="Contact Status"
                            className="w-full h-full rounded-full object-cover"
                          />
                        </div>
                        <SegmentedRing count={group.statuses.length} size={56} color="#71717a" />
                      </div>
                      <div className="text-left flex-1 min-w-0">
                        <h3 className="text-[16px] font-bold text-white mb-0.5">
                          {group.latest.display_name || group.latest.username}
                        </h3>
                        <p className="text-[13px] text-white/40">
                          {new Date(group.latest.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    </div>
                  ))}
                  {contactStatusGroups.length === 0 && (
                    <div className="text-center py-10 bg-white/[0.02] rounded-[32px] border border-white/[0.03] mx-2">
                      <p className="text-white/20 text-sm font-medium tracking-wide">No recent updates</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })()}

        {/* CALLS TAB VIEW */}
        {activeTab === 'calls' && (
          <div className="flex flex-col items-center justify-center h-full pt-16 space-y-4 animate-fade-in relative z-10 w-full overflow-hidden">
            <div className="bg-white/[0.02] backdrop-blur-3xl border border-white/5 shadow-2xl rounded-full px-12 py-8 flex flex-col items-center justify-center m-6 w-[80%] aspect-square max-w-[200px]">
              <h3 className="text-4xl font-black text-white/50 tracking-widest font-mono uppercase italic drop-shadow-[0_0_15px_rgba(255,255,255,0.2)]">SOON</h3>
            </div>
          </div>
        )}

        {/* COMMUNITIES TAB VIEW */}
        {activeTab === 'communities' && (
          <div className="flex flex-col items-center justify-center h-full pt-16 space-y-4 animate-fade-in relative z-10 w-full overflow-hidden">
             <div className="bg-white/[0.02] backdrop-blur-3xl border border-white/5 shadow-2xl rounded-full px-12 py-8 flex flex-col items-center justify-center m-6 w-[80%] aspect-square max-w-[200px]">
              <h3 className="text-4xl font-black text-white/50 tracking-widest font-mono uppercase italic drop-shadow-[0_0_15px_rgba(255,255,255,0.2)]">SOON</h3>
            </div>
          </div>
        )}

        {/* CALLS TAB BODY — real call log */}
        {activeTab === 'calls' && (
          <div className="flex-1 overflow-y-auto px-3 pb-24 pt-3" data-testid="calls-list">
            <CallLogList />
          </div>
        )}

        {/* UPDATES TAB BODY — real statuses list */}
        {activeTab === 'updates' && (
          <div className="flex-1 overflow-y-auto px-3 pb-24 pt-3" data-testid="updates-list">
            <UpdatesList />
          </div>
        )}

        {/* COMMUNITIES TAB BODY — honest placeholder */}
        {activeTab === 'communities' && (
          <div className="flex-1 px-3 pb-24 pt-6" data-testid="communities-body">
            <div className="p-6 text-center text-zinc-500 text-xs bg-white/[0.03] rounded-2xl border border-white/5">
              ميزة المجتمعات قيد التطوير — مجموعاتك الحالية في تبويب الدردشات.
            </div>
          </div>
        )}

        {/* SETTINGS VIEW ARCHITECTURAL HOOD */}
        {activeTab === 'settings' && (
          <div className="animate-fade-in p-4 text-left" style={{ direction: 'ltr' }}>
            
            {/* Header with Back Chevron inside Sub-views */}
            {settingsSubView !== 'main' ? (
              <div className="flex items-center justify-between mb-4 border-b border-white/5 pb-2.5">
                <button
                  onClick={() => setSettingsSubView('main')}
                  className="p-1 px-2.5 bg-white/5 text-slate-300 hover:text-white rounded-lg flex items-center gap-1.5 text-xs transition-all cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Back</span>
                </button>
                <span className="text-xs font-bold text-white/50">
                  {settingsSubView === 'profile' ? 'Edit Profile' :
                   settingsSubView === 'privacy' ? 'Privacy Settings' :
                   settingsSubView === 'notifications' ? 'Notifications' :
                   settingsSubView === 'appearance' ? 'Appearance' :
                   settingsSubView === 'chat' ? 'Chat Settings' :
                   settingsSubView === 'storage' ? 'Cloud Storage' :
                   settingsSubView === 'sessions' ? 'Active Sessions' :
                   settingsSubView === 'admin_dashboard' ? 'System Dashboard' : ''}
                </span>
              </div>
            ) : (
              <p className="text-[11px] font-bold text-white/40 mb-3 block text-left font-mono uppercase tracking-widest">Settings</p>
            )}

            {/* Error and Success settings notifications feedback */}
            {settingsError && (
              <div className="p-3 mb-4 bg-red-950/40 text-red-400 text-xs rounded-xl flex items-start gap-2 border border-red-500/20 animate-slide-in">
                <HelpCircle className="h-4 w-4 shrink-0 mt-0.5 text-red-400" />
                <span>{settingsError}</span>
              </div>
            )}
            {settingsSuccess && (
              <div className="p-3 mb-4 bg-blue-950/40 text-blue-400 text-xs rounded-xl flex items-start gap-2 border border-blue-500/20 animate-slide-in">
                <CheckCircle className="h-4 w-4 shrink-0 mt-0.5 text-blue-400" />
                <span>{settingsSuccess}</span>
              </div>
            )}

            {/* MAIN CATEGORIZED PREFERENCES VIEW */}
            {settingsSubView === 'main' && (
              <div className="flex flex-col gap-5 pb-32 px-1 animate-fade-in text-left">
                {/* User Profile Card */}
                <div 
                  onClick={() => setSettingsSubView('profile')}
                  className="bg-white/[0.03] backdrop-blur-xl border border-white/10 rounded-[28px] p-4 flex items-center gap-4 group cursor-pointer hover:bg-white/[0.06] transition-all duration-300 shadow-lg"
                >
                  <div className="relative shrink-0">
                    <img 
                      src={currentUser.avatarUrl || currentUser.photoURL} 
                      className="w-[64px] h-[64px] rounded-full object-cover border-2 border-white/20 group-hover:border-white/40 transition-all duration-500 shadow-xl" 
                      alt=""
                      referrerPolicy="no-referrer"
                    />
                    <span className="online-indicator online-indicator-pulse !w-4 !h-4 !bottom-1 !right-1 border-[3px] border-[#1c1c1e]"></span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 justify-start mb-0.5">
                      <h4 className="text-[18px] font-bold text-white truncate tracking-tight">{currentUser.displayName}</h4>
                      {currentUser.verified && (
                        <VerifiedBadge className="w-5 h-5 shrink-0" />
                      )}
                    </div>
                    <p className="text-[14px] text-white/40 font-medium truncate">@{currentUser.username}</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-white/20 group-hover:text-white/40 transition-colors" />
                </div>

                <div className="h-4"></div>

                {/* Account preferences list */}
                <div className="bg-white/5 backdrop-blur-2xl border border-white/10 rounded-[40px] overflow-hidden shadow-2xl divide-y divide-white/5">
                  
                  {/* Profile Edit */}
                  <div 
                    onClick={() => setSettingsSubView('profile')}
                    className="flex items-center gap-4 px-6 py-5 hover:bg-white/[0.08] transition-all cursor-pointer active:scale-[0.99] group"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-blue-500/20 flex items-center justify-center text-blue-400 shrink-0 group-hover:scale-110 transition-all shadow-lg">
                      <User className="w-6 h-6" />
                    </div>
                    <span className="flex-1 text-[17px] font-semibold text-white/90 tracking-tight">Edit Profile</span>
                    <ChevronRight className="w-5 h-5 text-white/20" />
                  </div>

                  {/* Privacy & Block list */}
                  <div 
                    onClick={() => setSettingsSubView('privacy')}
                    className="flex items-center gap-4 px-6 py-5 hover:bg-white/[0.08] transition-all cursor-pointer active:scale-[0.99] group"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-blue-500/20 flex items-center justify-center text-blue-400 shrink-0 group-hover:scale-110 transition-all shadow-lg">
                      <Shield className="w-6 h-6" />
                    </div>
                    <div className="flex-1 flex items-center gap-2">
                      <span className="text-[17px] font-semibold text-white/90 tracking-tight">Privacy & Security</span>
                    </div>
                    <ChevronRight className="w-5 h-5 text-white/20" />
                  </div>

                  {/* Themes & Appearances */}
                  <div 
                    onClick={() => setSettingsSubView('appearance')}
                    className="flex items-center gap-4 px-6 py-5 hover:bg-white/[0.08] transition-all cursor-pointer active:scale-[0.99] group"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 flex items-center justify-center text-indigo-400 shrink-0 group-hover:scale-110 transition-all shadow-lg">
                      <Settings2 className="w-6 h-6" />
                    </div>
                    <span className="flex-1 text-[17px] font-semibold text-white/90 tracking-tight">Appearance</span>
                    <ChevronRight className="w-5 h-5 text-white/20" />
                  </div>

                  {/* Notifications */}
                  <div 
                    onClick={() => setSettingsSubView('notifications')}
                    className="flex items-center gap-4 px-6 py-5 hover:bg-white/[0.08] transition-all cursor-pointer active:scale-[0.99] group"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-red-500/20 flex items-center justify-center text-red-400 shrink-0 group-hover:scale-110 transition-all shadow-lg">
                      <Bell className="w-6 h-6" />
                    </div>
                    <span className="flex-1 text-[17px] font-semibold text-white/90 tracking-tight">Notifications</span>
                    <ChevronRight className="w-5 h-5 text-white/20" />
                  </div>

                  {/* Chat Options */}
                  <div 
                    onClick={() => setSettingsSubView('chat')}
                    className="flex items-center gap-4 px-6 py-5 hover:bg-white/[0.08] transition-all cursor-pointer active:scale-[0.99] group"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-orange-500/20 flex items-center justify-center text-orange-400 shrink-0 group-hover:scale-110 transition-all shadow-lg">
                      <MessageCircle className="w-6 h-6" />
                    </div>
                    <span className="flex-1 text-[17px] font-semibold text-white/90 tracking-tight">Chat Settings</span>
                    <ChevronRight className="w-5 h-5 text-white/20" />
                  </div>

                  {/* Sessions Device Management */}
                  <div 
                    onClick={() => setSettingsSubView('sessions')}
                    className="flex items-center gap-4 px-6 py-5 hover:bg-white/[0.08] transition-all cursor-pointer active:scale-[0.99] group"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-purple-500/20 flex items-center justify-center text-purple-400 shrink-0 group-hover:scale-110 transition-all shadow-lg">
                      <Smartphone className="w-6 h-6" />
                    </div>
                    <span className="flex-1 text-[17px] font-semibold text-white/90 tracking-tight">Connected Devices</span>
                    <ChevronRight className="w-5 h-5 text-white/20" />
                  </div>

                  {/* Cloud Storage (BYO) */}
                  <div
                    onClick={() => setSettingsSubView('storage')}
                    className="flex items-center gap-4 px-6 py-5 hover:bg-white/[0.08] transition-all cursor-pointer active:scale-[0.99] group"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 flex items-center justify-center text-cyan-400 shrink-0 group-hover:scale-110 transition-all shadow-lg">
                      <Cloud className="w-6 h-6" />
                    </div>
                    <span className="flex-1 text-[17px] font-semibold text-white/90 tracking-tight">Cloud Storage (BYO)</span>
                    <ChevronRight className="w-5 h-5 text-white/20" />
                  </div>

                  {/* System Dashboard */}
                  {(currentUser?.role === 'developer' || currentUser?.role === 'admin') && (
                    <div 
                      onClick={() => setSettingsSubView('admin_dashboard')}
                      className="flex items-center gap-4 px-6 py-5 hover:bg-white/[0.12] transition-all cursor-pointer active:scale-[0.99] group bg-indigo-500/10 border-t border-indigo-500/25"
                    >
                      <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 flex items-center justify-center text-indigo-400 shrink-0 group-hover:scale-110 transition-all shadow-lg">
                        <Activity className="w-6 h-6 animate-pulse" />
                      </div>
                      <span className="flex-1 text-[17px] font-bold text-white tracking-tight">System Dashboard</span>
                      <ChevronRight className="w-5 h-5 text-indigo-400" />
                    </div>
                  )}

                </div>


                {/* Logout button */}
                <button
                  onClick={onLogout}
                  style={{ animationDelay: '0.4s' }}
                  className="list-item-animate mt-6 py-4 bg-red-500/10 hover:bg-red-500 hover:text-white border border-red-500/20 text-red-500 text-[15px] font-bold rounded-full transition-all duration-300 cursor-pointer flex items-center justify-center gap-2 shadow-[0_4px_12px_rgba(239,68,68,0.1)] active:scale-95"
                >
                  <LogOut className="w-5 h-5" />
                  <span>Logout</span>
                </button>

                {/* Delete account — REAL: DELETE /api/users/me with double confirmation */}
                {showDeleteConfirm === null && (
                  <button
                    onClick={() => setShowAccountDeleteConfirm('step1')}
                    className="mt-2 py-3 w-full text-[12px] font-bold text-zinc-500 hover:text-red-400 transition-colors cursor-pointer"
                  >
                    حذف الحساب نهائياً
                  </button>
                )}
                {showAccountDeleteConfirm === 'step1' && (
                  <div className="mt-2 p-4 rounded-2xl bg-red-500/10 border border-red-500/30 space-y-3">
                    <p className="text-xs text-red-300 leading-relaxed">
                      سيتم حذف حسابك وجميع بياناتك نهائياً ولا يمكن التراجع. اكتب <b className="font-mono">حذف</b> للتأكيد:
                    </p>
                    <input
                      value={accountDeleteText}
                      onChange={(e) => setAccountDeleteText(e.target.value)}
                      placeholder="اكتب: حذف"
                      className="w-full bg-black/30 border border-red-500/30 rounded-xl px-3 py-2 text-sm text-white outline-none focus:border-red-500/60"
                    />
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          setShowAccountDeleteConfirm(null);
                          setAccountDeleteText('');
                        }}
                        className="flex-1 py-2 rounded-xl bg-white/5 text-zinc-300 text-xs font-bold"
                      >
                        إلغاء
                      </button>
                      <button
                        disabled={accountDeleteText.trim() !== 'حذف'}
                        onClick={async () => {
                          try {
                            const res = await fetch('/api/users/me', {
                              method: 'DELETE',
                              headers: { Authorization: `Bearer ${getAccessToken()}` },
                            });
                            if (res.ok) {
                              localStorage.removeItem('dirasha_user');
                              if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                                (window as any).showGlobalToast('تم حذف الحساب نهائياً.', 'info');
                              }
                              onLogout();
                            } else {
                              const d = await res.json().catch(() => ({}));
                              if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                                (window as any).showGlobalToast(d.error || 'تعذر حذف الحساب. حاول مجدداً.', 'error');
                              }
                            }
                          } catch (_) {
                            if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                              (window as any).showGlobalToast('خطأ في الاتصال.', 'error');
                            }
                          }
                          setShowAccountDeleteConfirm(null);
                          setAccountDeleteText('');
                        }}
                        className="flex-1 py-2 rounded-xl bg-red-500 text-white text-xs font-black disabled:opacity-40"
                      >
                        حذف نهائي
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* NESTED VIEW: PROFILE EDIT */}
            {settingsSubView === 'profile' && (
              <div className="pb-32 px-1 animate-fade-in text-left">
                <form onSubmit={async (e) => {
                  e.preventDefault();
                  setSettingsSaving(true);
                  setSettingsSuccess(null);
                  setSettingsError(null);
                  try {
                    const cleanedName = editDisplayName.trim();
                    const nameVal = validateDisplayName(cleanedName);
                    if (!nameVal.isValid) throw new Error(nameVal.error);

                    const normUser = normalizeUsername(editUsername);
                    const userVal = validateUsername(normUser);
                    if (!userVal.isValid) throw new Error(userVal.error);

                    // Double check uniqueness if altered
                    if (normUser !== (currentUser.username || '').toLowerCase().trim()) {
                      const checkRes = await fetch(`/api/auth/check-username?username=${encodeURIComponent(normUser)}`);
                      const checkData = await checkRes.json();
                      if (!checkData.available) {
                        throw new Error('Username is already taken.');
                      }
                    }

                    const myId = currentUser.uid || currentUser.id;
                    const savedPayload = {
                      displayName: sanitizeDisplayName(cleanedName),
                      username: normUser,
                      bio: editBio.substring(0, 200).trim(),
                      photoURL: editAvatarUrl.trim(),
                      avatarUrl: editAvatarUrl.trim(),
                      bannerUrl: editBannerUrl.trim() || null,
                      backgroundBannerUrl: editBackgroundBannerUrl.trim() || null,
                      bannerShadowOpacity: editBannerShadowOpacity,
                      bgBannerShadowOpacity: editBgBannerShadowOpacity,
                      updatedAt: new Date().toISOString()
                    };

                    try {
                      const token = getAccessToken();
                      const res = await fetch('/api/users/me', {
                        method: 'PUT',
                        headers: {
                          'Content-Type': 'application/json',
                          'Authorization': `Bearer ${token}`
                        },
                        body: JSON.stringify(savedPayload)
                      });
                      
                      if (!res.ok) {
                        const errData = await res.json();
                        throw new Error(errData.error || 'Failed to update profile.');
                      }
                      
                      const resData = await res.json();
                      const finalUser = resData.user || { ...currentUser, ...savedPayload };
                      
                      localStorage.setItem('dirasha_user', JSON.stringify(finalUser));
                      
                      if (setCurrentUser) {
                        setCurrentUser(finalUser);
                      }
                      
                      setSettingsSuccess('Profile updated successfully!');
                    } catch (err: any) {
                      const errStr = String(err).toLowerCase();
                      const isQuota = errStr.includes('quota') || errStr.includes('resource-exhausted') || errStr.includes('limit exceeded');
                      
                      if (isQuota) {
                        const dirashaUserStr = localStorage.getItem('dirasha_user');
                        if (dirashaUserStr) {
                          try {
                            const parsedUser = JSON.parse(dirashaUserStr);
                            const mergedUser = { ...parsedUser, ...savedPayload };
                            localStorage.setItem('dirasha_user', JSON.stringify(mergedUser));
                          } catch (_) {}
                        }
                        
                        if (setCurrentUser) {
                          setCurrentUser((prev: any) => prev ? { ...prev, ...savedPayload } : { id: myId, uid: myId, ...savedPayload });
                        }
                        
                        // Dispatch quota error events reactively
                        if (typeof window !== 'undefined') {
                          window.dispatchEvent(new CustomEvent('firestore-quota-exceeded'));
                        }
                        
                        setSettingsSuccess('Account changes saved locally! (Cloud limited)');
                      } else {
                        setSettingsError(err.message || 'Failed to update profile.');
                      }
                    }
                  } finally {
                    setSettingsSaving(false);
                  }
                }} className="space-y-6 text-left">
                  
                  {/* Banner Upload Container */}
                  <div className="bg-white/[0.02] backdrop-blur-3xl border border-white/10 rounded-[32px] p-5 shadow-2xl relative transition-all duration-300">
                    <div className="flex justify-between items-center mb-3">
                      <label className="block text-[11px] font-bold text-white/50 uppercase tracking-widest font-mono">Banner Configuration</label>
                      {currentUser?.role === 'developer' && editBackgroundBannerUrl && (
                        <span className="text-[10px] text-amber-400 font-bold bg-amber-400/10 px-2.5 py-1 rounded-full uppercase tracking-widest">Active</span>
                      )}
                    </div>
                    
                    {currentUser?.role === 'developer' && editBackgroundBannerUrl ? (
                      <div className="w-full h-32 rounded-[28px] border border-white/5 bg-white/[0.01] flex flex-col items-center justify-center text-center p-4">
                        <span className="text-[12px] font-bold text-slate-400 font-mono uppercase tracking-widest">In Use</span>
                      </div>
                    ) : (
                      <div className="w-full h-32 rounded-[28px] overflow-hidden relative bg-white/[0.04] border border-white/10 shadow-inner group">
                        <label htmlFor="banner-file-upload" className="cursor-pointer w-full h-full block">
                          <input
                            id="banner-file-upload"
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={async (e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                try {
                                  setSettingsSaving(true);
                                  setSettingsError(null);
                                  const uid = currentUser?.uid || currentUser?.id || 'anonymous';
                                  const downloadUrl = await uploadImageToStorage(file, `users/${uid}/banner_${Date.now()}`, 1000, 0.7);
                                  await updateUserSettings({ bannerUrl: downloadUrl });
                                  setEditBannerUrl(downloadUrl);
                                  setSettingsSuccess('Standard banner updated successfully!');
                                } catch (err: any) {
                                  setSettingsError('Failed to upload banner: ' + err.message);
                                } finally {
                                  setSettingsSaving(false);
                                }
                              }
                            }}
                          />
                          {editBannerUrl ? (
                            <div className="w-full h-full relative">
                              <img
                                src={editBannerUrl}
                                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                                alt="Banner"
                                referrerPolicy="no-referrer"
                              />
                              <div 
                                className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black to-transparent pointer-events-none transition-opacity duration-200" 
                                style={{ opacity: editBannerShadowOpacity / 100 }}
                              />
                            </div>
                          ) : (
                            <div className="w-full h-full flex flex-col items-center justify-center text-white/20 group-hover:text-white/60 transition-colors">
                              <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center mb-2 shadow-inner group-hover:scale-110 transition-transform duration-300">
                                <Camera className="w-5 h-5" />
                              </div>
                              <span className="text-[12px] font-bold font-sans text-white/50 tracking-widest uppercase mt-2">Change Banner</span>
                            </div>
                          )}
                        </label>

                        {/* Trash Delete Button */}
                        {editBannerUrl && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              setEditBannerUrl('');
                            }}
                            className="absolute top-3 right-3 z-30 p-2.5 bg-black/60 hover:bg-red-500/80 rounded-full text-white/80 hover:text-white transition-all backdrop-blur-md active:scale-95 border border-white/10"
                            title="Remove"
                          >
                            <Trash className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    )}

                    {/* Standard Banner Opacity Customizer */}
                    {editBannerUrl && !editBackgroundBannerUrl && (
                      <div className="mt-4 flex items-center gap-3 w-full border-t border-white/5 pt-4">
                        <span className="text-[10px] font-bold text-white/40 font-mono uppercase tracking-widest">Shadow Blur</span>
                        <input 
                          type="range" min="0" max="100"
                          value={editBannerShadowOpacity}
                          onChange={(e) => setEditBannerShadowOpacity(Number(e.target.value))}
                          className="flex-1 h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer accent-white"
                        />
                      </div>
                    )}
                  </div>

                  {currentUser?.role === 'developer' && (
                    <div className="bg-blue-900/[0.05] backdrop-blur-3xl border border-blue-500/20 rounded-[32px] p-5 shadow-2xl mt-4 transition-all duration-300">
                      <div className="flex justify-between items-center mb-3">
                        <label className="block text-[11px] font-bold text-blue-400/80 uppercase font-mono tracking-widest">Dev Core Banner (Extended)</label>
                        {editBannerUrl && (
                          <span className="text-[10px] text-white/30 font-bold bg-white/5 px-2.5 py-1 rounded-full font-mono uppercase tracking-widest">Core Active</span>
                        )}
                      </div>
                      
                      {editBannerUrl ? (
                         <div className="w-full h-32 rounded-[28px] border border-blue-500/10 bg-blue-500/5 flex flex-col items-center justify-center text-center p-4">
                           <span className="text-[12px] font-bold text-blue-400/50 uppercase tracking-widest font-mono">Standard In Use</span>
                         </div>
                      ) : (
                        <div className="w-full h-32 rounded-[28px] overflow-hidden relative bg-black/40 border border-blue-500/10 shadow-inner group">
                          <label htmlFor="background-banner-upload" className="cursor-pointer w-full h-full block">
                            <input
                              id="background-banner-upload"
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={async (e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  try {
                                    setSettingsSaving(true);
                                    setSettingsError(null);
                                    const uid = currentUser?.uid || currentUser?.id || 'anonymous';
                                    const downloadUrl = await uploadImageToStorage(file, `users/${uid}/bg_banner_${Date.now()}`, 1000, 0.7);
                                    await updateUserSettings({ backgroundBannerUrl: downloadUrl });
                                    setEditBackgroundBannerUrl(downloadUrl);
                                    setSettingsSuccess('Dev Core banner updated successfully!');
                                  } catch (err: any) {
                                    setSettingsError('Failed to upload background banner: ' + err.message);
                                  } finally {
                                    setSettingsSaving(false);
                                  }
                                }
                              }}
                            />
                            {editBackgroundBannerUrl ? (
                              <div className="w-full h-full relative font-sans">
                                <img
                                  src={editBackgroundBannerUrl}
                                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                                  alt="Background Banner"
                                  referrerPolicy="no-referrer"
                                />
                                <div 
                                  className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black to-transparent pointer-events-none transition-opacity duration-200" 
                                  style={{ opacity: editBgBannerShadowOpacity / 100 }}
                                />
                              </div>
                            ) : (
                              <div className="w-full h-full flex flex-col items-center justify-center text-blue-500/40 group-hover:text-blue-400 transition-colors">
                                <div className="w-12 h-12 rounded-full bg-blue-500/10 flex items-center justify-center mb-2 shadow-inner group-hover:scale-110 transition-transform duration-300">
                                  <Camera className="w-5 h-5" />
                                </div>
                                <span className="text-[12px] font-bold font-sans text-blue-400/50 tracking-widest uppercase mt-2">Update Core Background</span>
                              </div>
                            )}
                          </label>

                          {editBackgroundBannerUrl && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                setEditBackgroundBannerUrl('');
                              }}
                              className="absolute top-3 right-3 z-30 p-2.5 bg-black/60 hover:bg-red-500/80 rounded-full text-white/80 hover:text-white transition-all backdrop-blur-md active:scale-95 border border-white/10"
                              title="Remove Dev Banner"
                            >
                              <Trash className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      )}

                      {editBackgroundBannerUrl && !editBannerUrl && (
                          <div className="mt-4 flex items-center gap-3 w-full border-t border-blue-500/10 pt-4">
                            <span className="text-[10px] font-bold text-blue-400/50 font-mono uppercase tracking-widest">Gradient Mask</span>
                            <input 
                              type="range" min="0" max="100"
                              value={editBgBannerShadowOpacity}
                              onChange={(e) => setEditBgBannerShadowOpacity(Number(e.target.value))}
                              className="flex-1 h-1.5 bg-blue-900/30 rounded-full appearance-none cursor-pointer accent-blue-400"
                            />
                          </div>
                      )}
                    </div>
                  )}

                  {/* Identity Section */}
                  <div className="bg-white/[0.03] backdrop-blur-3xl border border-white/10 rounded-[32px] p-8 shadow-2xl flex flex-col items-center relative gap-8 mt-4 transition-all duration-300">
                    <label className="block text-[11px] font-bold text-white/50 border-b border-white/5 pb-3 font-mono tracking-widest text-center uppercase w-full">Personal Identity</label>
                    
                    <label htmlFor="avatar-file-upload" className="cursor-pointer group flex flex-col items-center relative mt-2">
                      <input
                        id="avatar-file-upload"
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            try {
                              setSettingsSaving(true);
                              setSettingsError(null);
                              const uid = currentUser?.uid || currentUser?.id || 'anonymous';
                              const downloadUrl = await uploadImageToStorage(file, `users/${uid}/avatar_${Date.now()}`, 400, 0.7);
                              await updateUserSettings({ avatarUrl: downloadUrl, photoURL: downloadUrl });
                              setEditAvatarUrl(downloadUrl);
                              setSettingsSuccess('Profile photo updated successfully!');
                            } catch (err: any) {
                              setSettingsError('Failed to upload profile photo: ' + err.message);
                            } finally {
                              setSettingsSaving(false);
                            }
                          }
                        }}
                      />
                      <div className="relative mb-3">
                        <div className="w-28 h-28 rounded-full overflow-hidden border border-white/20 group-hover:border-blue-500/60 transition-all duration-500 shadow-[0_0_20px_rgba(255,255,255,0.05)] relative bg-white/5">
                          <img
                            src={editAvatarUrl || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&h=150&q=80'}
                            className="w-full h-full object-cover group-hover:scale-110 transition-all duration-700"
                            alt="Avatar"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
                            <Camera className="w-8 h-8 text-white scale-75 group-hover:scale-100 transition-transform duration-500" />
                          </div>
                        </div>
                        <div className="absolute -bottom-1 -right-1 w-9 h-9 flex items-center justify-center bg-blue-500 text-white rounded-full border-4 border-[#121212] shadow-xl transform scale-90 group-hover:scale-100 transition-transform duration-300">
                          <Camera className="w-4 h-4" />
                        </div>
                      </div>
                      <span className="text-[10px] font-mono tracking-widest uppercase text-white/50 group-hover:text-blue-400 transition-colors mt-2">Update Avatar</span>
                    </label>

                    <div className="w-full space-y-6">
                      <div className="space-y-2">
                        <label className="text-[11px] font-bold text-white/40 pl-1 font-mono uppercase tracking-widest">Display Name</label>
                        <input
                          type="text"
                          required
                          value={editDisplayName}
                          onChange={(e) => setEditDisplayName(e.target.value)}
                          className="w-full px-5 py-4 min-h-[56px] focus:bg-white/[0.06] bg-white/[0.03] border border-white/5 rounded-[24px] text-[15px] text-white focus:outline-none focus:border-blue-500/50 transition-all shadow-inner font-sans font-medium hover:bg-white/[0.04]"
                          placeholder="Your Display Name"
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="text-[11px] font-bold text-white/40 pl-1 font-mono uppercase tracking-widest">Handle</label>
                        <div className="relative group/input flex items-center">
                          <div className="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none">
                            <span className="text-blue-400 font-mono text-[16px]">@</span>
                          </div>
                          <input
                            type="text"
                            required
                            value={editUsername}
                            onChange={(e) => setEditUsername(normalizeUsernameInput(e.target.value))}
                            className="w-full pl-10 pr-5 py-4 min-h-[56px] focus:bg-white/[0.06] bg-white/[0.03] border border-white/5 rounded-[24px] text-[15px] text-white focus:outline-none focus:border-blue-500/50 transition-all shadow-inner font-mono font-medium text-left hover:bg-white/[0.04]"
                            placeholder="username"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label className="text-[11px] font-bold text-white/40 pl-1 font-mono uppercase tracking-widest">Bio</label>
                        <textarea
                          rows={3}
                          maxLength={200}
                          value={editBio}
                          onChange={(e) => setEditBio(e.target.value)}
                          className="w-full px-5 py-4 focus:bg-white/[0.06] bg-white/[0.03] border border-white/5 rounded-[24px] text-[14px] text-white focus:outline-none focus:border-blue-500/50 transition-all shadow-inner resize-none hover:bg-white/[0.04]"
                          placeholder="Write something about yourself..."
                        />
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={settingsSaving}
                    className="w-full mt-6 py-4 bg-white hover:bg-white/90 text-black font-black uppercase italic tracking-tighter text-[15px] min-h-[56px] rounded-[24px] shadow-[0_0_20px_rgba(255,255,255,0.1)] hover:shadow-[0_0_30px_rgba(255,255,255,0.2)] transition-all active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                  >
                    {settingsSaving ? <Loader2 className="w-5 h-5 animate-spin mx-auto text-black" /> : "Save Changes"}
                  </button>
                </form>
              </div>
            )}

            {/* NESTED VIEW: PRIVACY & SECURITY DIRECT PREFERENCES */}
            {settingsSubView === 'privacy' && (
              <motion.div
                initial={{ opacity: 0, x: 60 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -60 }}
                transition={{ type: "spring", stiffness: 350, damping: 28 }}
                className="space-y-6 text-left pb-32 px-1"
                style={{ direction: 'ltr' }}
              >
                {/* Privacy Control settings */}
                <div className="bg-white/[0.03] backdrop-blur-2xl border border-white/10 rounded-[32px] p-6 shadow-2xl space-y-6">
                  <div className="flex items-center justify-between border-b border-white/5 pb-2">
                    <span className="block text-[11px] font-bold text-white/50 uppercase tracking-widest font-mono">Privacy Control</span>
                    <Shield className="w-4 h-4 text-white/40" />
                  </div>
                  
                  {/* Last Seen visibility */}
                  <div className="space-y-2.5">
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold text-white/90">Last Seen & Online</p>
                      <p className="text-[11px] text-white/30 mb-2">Who can see your online status and last active time</p>
                    </div>
                    <GlassSegmentedControl
                      scopeId="lastSeen"
                      options={[
                        { label: 'Everyone', value: 'everyone' },
                        { label: 'My Contacts', value: 'contacts' },
                        { label: 'Nobody', value: 'nobody' }
                      ]}
                      value={currentUser.privacySettings?.lastSeenVisibility || 'everyone'}
                      onChange={(val) => updateUserSettings({ 'privacySettings.lastSeenVisibility': val })}
                    />
                  </div>

                  {/* Photo visibility */}
                  <div className="space-y-2.5 border-t border-white/5 pt-5">
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold text-white/90">Profile Photo</p>
                      <p className="text-[11px] text-white/30 mb-2">Configure who can view your profile picture</p>
                    </div>
                    <GlassSegmentedControl
                      scopeId="photoVis"
                      options={[
                        { label: 'Everyone', value: 'everyone' },
                        { label: 'My Contacts', value: 'contacts' },
                        { label: 'Nobody', value: 'nobody' }
                      ]}
                      value={currentUser.privacySettings?.avatarVisibility || 'everyone'}
                      onChange={(val) => updateUserSettings({ 'privacySettings.avatarVisibility': val })}
                    />
                  </div>

                  {/* Direct Messages permissions */}
                  <div className="space-y-2.5 border-t border-white/5 pt-5">
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold text-white/90">Direct Messages</p>
                      <p className="text-[11px] text-white/30 mb-2">Control who can start new direct conversations with you</p>
                    </div>
                    <GlassSegmentedControl
                      scopeId="dmAllow"
                      options={[
                        { label: 'Everyone', value: 'everyone' },
                        { label: 'Contacts Only', value: 'contacts' }
                      ]}
                      value={currentUser.privacySettings?.allowDirectMessages || 'everyone'}
                      onChange={(val) => updateUserSettings({ 'privacySettings.allowDirectMessages': val })}
                    />
                  </div>

                  {/* Group Invites restriction */}
                  <div className="space-y-2.5 border-t border-white/5 pt-5">
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold text-white/90">Group Invites</p>
                      <p className="text-[11px] text-white/30 mb-2">Who can add you to shared groups and group chats</p>
                    </div>
                    <GlassSegmentedControl
                      scopeId="groupAllow"
                      options={[
                        { label: 'Everyone', value: 'everyone' },
                        { label: 'My Contacts', value: 'contacts' }
                      ]}
                      value={currentUser.privacySettings?.allowGroupInvites || 'everyone'}
                      onChange={(val) => updateUserSettings({ 'privacySettings.allowGroupInvites': val })}
                    />
                  </div>
                </div>

                {/* Real privacy controls live in the Privacy card above — fake placeholders removed */}

                <div className="bg-white/[0.03] backdrop-blur-2xl border border-white/10 rounded-[32px] p-6 shadow-2xl space-y-6">
                  <div className="flex items-center justify-between border-b border-white/5 pb-2">
                    <span className="block text-[11px] font-bold text-white/50 uppercase tracking-widest font-mono">Advanced Control & Security</span>
                    <Laptop className="w-4 h-4 text-white/40" />
                  </div>

                  <div className="space-y-4">
                    {/* Active Sessions Manager */}
                    <button
                      onClick={async () => {
                        try {
                          const res = await fetch('/api/auth/sessions', {
                            headers: { 'Authorization': `Bearer ${accessToken}` }
                          });
                          const data = await res.json();
                          alert(`Active Sessions (${data.sessions?.length || 0}):\n` + 
                            (data.sessions || []).map((s: any) => 
                              `• ${s.userAgent || 'Unknown Device'} (${s.ipAddress})`
                            ).join('\n')
                          );
                        } catch (err) {
                          setSettingsError('Failed to load active sessions.');
                        }
                      }}
                      className="w-full flex items-center justify-between p-4 bg-white/[0.04] hover:bg-white/[0.08] rounded-[24px] border border-white/5 transition-all text-left"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="text-[14px] font-bold text-white/90">Session Management</p>
                        <p className="text-[11px] text-white/30">View and terminate active sessions on other devices</p>
                      </div>
                      <Monitor className="w-5 h-5 text-white/20 ml-4" />
                    </button>

                    {/* Terminate Other Sessions */}
                    <button
                      onClick={async () => {
                        if (confirm('Are you sure you want to log out from all other devices?')) {
                          setSettingsSaving(true);
                          try {
                            const currentSessionId = getSessionId();
                            await fetch('/api/auth/sessions/revoke-others', {
                              method: 'POST',
                              headers: { 
                                'Authorization': `Bearer ${accessToken}`,
                                'x-session-id': currentSessionId || ''
                              }
                            });
                            setSettingsSuccess('All other sessions terminated successfully.');
                          } catch (err) {
                            setSettingsError('Failed to terminate sessions.');
                          } finally {
                            setSettingsSaving(false);
                          }
                        }
                      }}
                      className="w-full flex items-center justify-between p-4 bg-amber-500/10 hover:bg-amber-500/20 rounded-[24px] border border-amber-500/20 transition-all text-left group"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="text-[14px] font-bold text-amber-200">Terminate All Other Sessions</p>
                        <p className="text-[11px] text-amber-500/50">Immediate logout from all browsers except this one</p>
                      </div>
                      <LogOut className="w-5 h-5 text-amber-500/40 group-hover:text-amber-500 transition-colors ml-4" />
                    </button>

                    {/* Clear Client Cache */}
                    <button
                      onClick={() => {
                        if (confirm('All cached messages and temporary files will be deleted. Continue?')) {
                          localStorage.clear();
                          window.location.reload();
                        }
                      }}
                      className="w-full flex items-center justify-between p-4 bg-white/[0.04] hover:bg-white/[0.08] rounded-[24px] border border-white/5 transition-all text-left"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="text-[14px] font-bold text-white/90">Purge Local Cache</p>
                        <p className="text-[11px] text-white/30">Free up storage and delete temporary local data</p>
                      </div>
                      <Trash2 className="w-5 h-5 text-white/20 ml-4" />
                    </button>

                    {/* Dangerous Action: Delete Account */}
                    <div className="pt-4 border-t border-white/5">
                      <button
                        onClick={async () => {
                          if (confirm('⚠️ WARNING: Your account and all messages will be permanently deleted. This cannot be undone. Are you sure?')) {
                            setSettingsSaving(true);
                            try {
                              await fetch('/api/users/me', {
                                method: 'DELETE',
                                headers: { 'Authorization': `Bearer ${accessToken}` }
                              });
                              alert('Account deleted successfully. We will miss you!');
                              onLogout();
                            } catch (err) {
                              setSettingsError('Account deletion failed. Try again later.');
                            } finally {
                              setSettingsSaving(false);
                            }
                          }
                        }}
                        className="w-full flex items-center justify-between p-4 bg-red-600/10 hover:bg-red-600/20 rounded-[24px] border border-red-600/30 transition-all text-left group"
                      >
                        <div className="flex-1 min-w-0">
                          <p className="text-[14px] font-bold text-red-400">Permanent Account Deletion</p>
                          <p className="text-[11px] text-red-400/50">Total wipe of identity and messaging records from servers</p>
                        </div>
                        <UserMinus className="w-5 h-5 text-red-600 ml-4 group-hover:scale-110 transition-transform" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Chat privacy toggle indicators */}
                <div className="bg-white/[0.03] backdrop-blur-2xl border border-white/10 rounded-[32px] p-6 shadow-2xl space-y-6">
                  <div className="flex items-center justify-between border-b border-white/5 pb-2">
                    <span className="block text-[11px] font-bold text-white/50 uppercase tracking-widest font-mono">Chat Privacy & Indicators</span>
                    <MessageSquare className="w-4 h-4 text-white/40" />
                  </div>
                  
                  {/* Read Receipts */}
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold text-white/90">Read Receipts</p>
                      <p className="text-[11px] text-white/30">If disabled, you won't be able to see when others read your messages (excluding group chats)</p>
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        const nextVal = currentUser.privacySettings?.readReceiptsEnabled !== false ? false : true;
                        setSettingsSaving(true);
                        try {
                          await updateUserSettings({ 'privacySettings.readReceiptsEnabled': nextVal });
                          setSettingsSuccess('Read receipts updated!');
                        } catch (err) {
                          setSettingsError('Failed to update read receipts.');
                        } finally {
                          setSettingsSaving(false);
                        }
                      }}
                      className={`h-6 w-11 rounded-full p-1 transition-colors duration-200 focus:outline-none cursor-pointer ${
                        currentUser.privacySettings?.readReceiptsEnabled !== false ? 'bg-blue-600' : 'bg-white/10'
                      }`}
                    >
                      <div className={`h-4 w-4 rounded-full bg-white transition-transform duration-200 ${
                        currentUser.privacySettings?.readReceiptsEnabled !== false ? '-translate-x-5' : 'translate-x-0'
                      }`} />
                    </button>
                  </div>

                  {/* Typing Indicator */}
                  <div className="flex items-center justify-between gap-4 border-t border-white/5 pt-5">
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold text-white/90">Typing Indicator</p>
                      <p className="text-[11px] text-white/30">Broadcast "typing..." status to others while preparing your messages</p>
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        const nextVal = currentUser.privacySettings?.typingIndicatorEnabled !== false ? false : true;
                        setSettingsSaving(true);
                        try {
                          await updateUserSettings({ 'privacySettings.typingIndicatorEnabled': nextVal });
                          setSettingsSuccess('Typing status preferences updated.');
                        } catch (err) {
                          setSettingsError('Failed to update typing status.');
                        } finally {
                          setSettingsSaving(false);
                        }
                      }}
                      className={`h-6 w-11 rounded-full p-1 transition-colors duration-200 focus:outline-none cursor-pointer ${
                        currentUser.privacySettings?.typingIndicatorEnabled !== false ? 'bg-blue-600' : 'bg-white/10'
                      }`}
                    >
                      <div className={`h-4 w-4 rounded-full bg-white transition-transform duration-200 ${
                        currentUser.privacySettings?.typingIndicatorEnabled !== false ? 'translate-x-5' : 'translate-x-0'
                      }`} />
                    </button>
                  </div>

                  {/* Notification Preview (Project 7) — default OFF (privacy-first) */}
                  <div className="flex items-center justify-between gap-4 border-t border-white/5 pt-5">
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold text-white/90">معاينة الرسائل في الإشعارات</p>
                      <p className="text-[11px] text-white/30">افتراضيًا لا تُعرض محتوى الرسائل في إشعارات النظام حمايةً لخصوصيتك. حتى عند التفعيل، تبقى إشعارات الخادم عامة دائمًا — التفعيل يسمح فقط بمعاينة المحتوى في الشعارات داخل التطبيق أثناء استخدامه في المقدمة.</p>
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        const nextVal = currentUser.privacySettings?.notificationPreviewEnabled === true ? false : true;
                        setSettingsSaving(true);
                        try {
                          await updateUserSettings({ 'privacySettings.notificationPreviewEnabled': nextVal });
                          setSettingsSuccess('تم تحديث إعدادات معاينة الإشعارات.');
                        } catch (err) {
                          setSettingsError('Failed to update notification preview setting.');
                        } finally {
                          setSettingsSaving(false);
                        }
                      }}
                      className={`h-6 w-11 rounded-full p-1 transition-colors duration-200 focus:outline-none cursor-pointer ${
                        currentUser.privacySettings?.notificationPreviewEnabled === true ? 'bg-blue-600' : 'bg-white/10'
                      }`}
                    >
                      <div className={`h-4 w-4 rounded-full bg-white transition-transform duration-200 ${
                        currentUser.privacySettings?.notificationPreviewEnabled === true ? 'translate-x-5' : 'translate-x-0'
                      }`} />
                    </button>
                  </div>
                </div>

                {/* Passcode Lock Setup */}
                <div className="bg-white/[0.03] backdrop-blur-2xl border border-white/10 rounded-[32px] p-6 shadow-2xl space-y-6">
                  <div className="flex items-center justify-between border-b border-white/5 pb-2">
                    <span className="text-[11px] font-bold text-white/50 uppercase tracking-widest font-mono">Two-Factor Authentication</span>
                    <Shield className="w-4 h-4 text-white/40" />
                  </div>
                  <TwoFactorCard />

                  {/* Project 9: مفاتيح المرور — طبقة دخول إضافية (تحمي تسجيل الدخول فقط، لا علاقة لها بمفاتيح E2EE) */}
                  <div className="pt-4 border-t border-white/5">
                    <PasskeysCard />
                  </div>

                  {/* Security tips — static, collapsed by default */}
                  <details className="group bg-white/[0.03] border border-white/10 rounded-[22px] overflow-hidden">
                    <summary className="flex items-center justify-between px-4 py-3 cursor-pointer select-none text-[13px] font-bold text-white/80 list-none">
                      <span>🛡️ نصائح تأمين حسابك</span>
                      <ChevronLeft className="w-4 h-4 text-white/40 transition-transform group-open:-rotate-90" />
                    </summary>
                    <ul className="px-5 pb-4 space-y-2 text-[12px] text-white/60 leading-relaxed">
                      <li className="flex gap-2"><span className="text-white/30">•</span><span>فعّل التحقق بخطوتين</span></li>
                      <li className="flex gap-2"><span className="text-white/30">•</span><span>راقب الأجهزة المسجلة وأزل غير المألوفة</span></li>
                      <li className="flex gap-2"><span className="text-white/30">•</span><span>لا تشارك رمز التحقق مع أي شخص حتى لو ادعى أنه الدعم</span></li>
                      <li className="flex gap-2"><span className="text-white/30">•</span><span>غيّر كلمة السر دورياً</span></li>
                    </ul>
                  </details>

                  <div className="flex items-center justify-between border-b border-white/5 pb-2">
                    <span className="text-[11px] font-bold text-white/50 uppercase tracking-widest font-mono">Interface Lock</span>
                    <Lock className="w-4 h-4 text-white/40 animate-pulse" />
                  </div>
                  
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold text-white/90">Screen Lock Passcode</p>
                      <p className="text-[11px] text-white/30">UI privacy screen only — it does NOT encrypt or decrypt any data</p>
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        const nextVal = !currentUser.privacySettings?.screenLockEnabled;
                        // AUTH-04: never write a default '0000' passcode; enabling
                        // requires an already-set 4-digit PIN.
                        const currentPass = String(currentUser.privacySettings?.screenLockPasscode || '');
                        if (nextVal && currentPass.length !== 4) {
                          setSettingsError('اضبط رمزًا من 4 أرقام أولًا قبل تفعيل القفل.');
                          return;
                        }
                        setSettingsSaving(true);
                        try {
                          await updateUserSettings({ 
                            'privacySettings.screenLockEnabled': nextVal,
                            'privacySettings.screenLockPasscode': currentPass 
                          });
                          setSettingsSuccess(nextVal ? 'Screen lock enabled.' : 'Screen lock disabled.');
                        } catch (err) {
                          setSettingsError('Failed to toggle screen lock.');
                        } finally {
                          setSettingsSaving(false);
                        }
                      }}
                      className={`h-6 w-11 rounded-full p-1 transition-colors duration-200 focus:outline-none cursor-pointer ${
                        currentUser.privacySettings?.screenLockEnabled ? 'bg-blue-600' : 'bg-white/10'
                      }`}
                    >
                      <div className={`h-4 w-4 rounded-full bg-white transition-transform duration-200 ${
                        currentUser.privacySettings?.screenLockEnabled ? 'translate-x-5' : 'translate-x-0'
                      }`} />
                    </button>
                  </div>

                  {currentUser.privacySettings?.screenLockEnabled && (
                    <div className="space-y-3 pt-3 border-t border-white/5 animate-fade-in text-left">
                      <p className="text-[13px] font-bold text-white/80">Update PIN (4 Digits)</p>
                      <div className="flex items-center gap-3">
                        <input
                          type="text"
                          pattern="[0-9]*"
                          inputMode="numeric"
                          maxLength={4}
                          placeholder="••••"
                          value={currentUser.privacySettings?.screenLockPasscode || ''}
                          onChange={async (e) => {
                            const val = e.target.value.replace(/[^0-9]/g, '').slice(0, 4);
                            await updateUserSettings({ 'privacySettings.screenLockPasscode': val });
                          }}
                          className="w-24 px-3 py-2 bg-black/40 border border-white/10 rounded-xl text-center text-white text-[16px] font-extrabold font-mono tracking-[0.25em] focus:outline-none focus:border-blue-500/50"
                        />
                        <p className="text-[11px] text-white/40 leading-relaxed text-left flex-1 min-w-0">
                          Set a 4-digit numeric PIN to unlock the interface. Privacy screen only — it does not encrypt or decrypt any data.
                        </p>
                      </div>
                    </div>
                  )}

                  {/* ── Project 10: Emergency Key Rotation (flag-gated, default OFF) ── */}
                  {emergencyRotationEnabled && (
                    <div className="space-y-3 pt-3 border-t border-white/5">
                      <p className="text-[14px] font-bold text-white/90">تدوير مفاتيح الطوارئ</p>
                      <p className="text-[11px] text-white/30 leading-relaxed">
                        للاستخدام عند الشك في اختراق مفاتيح التشفير على هذا الجهاز: تُولَّد هوية تشفير جديدة
                        بالكامل، وتُحذف كل جلسات التشفير المحلية، ويُعاد تسجيل المفاتيح لدى الخادم تلقائيًا.
                      </p>

                      {!rotationConfirmOpen ? (
                        <button
                          type="button"
                          onClick={() => setRotationConfirmOpen(true)}
                          disabled={rotationBusy || typeof onEmergencyRotate !== 'function'}
                          title={typeof onEmergencyRotate !== 'function' ? 'لم يتم ربط محرك التشفير بعد' : undefined}
                          className="w-full py-2.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300 font-bold text-xs flex items-center justify-center gap-2 hover:bg-amber-500/20 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                          {rotationBusy ? <Loader2 className="w-4 h-4 animate-spin" /> : <KeyRound className="w-4 h-4" />}
                          {rotationBusy ? 'جارٍ التدوير...' : 'تدوير مفاتيح الطوارئ'}
                        </button>
                      ) : (
                        /* Confirm dialog — EXACT honest text (do not soften): rotation
                           protects FUTURE messages only, it cannot undo past leaks. */
                        <div className="space-y-3 p-4 rounded-2xl bg-amber-500/5 border border-amber-500/20">
                          <div className="flex items-start gap-2">
                            <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
                            <p className="text-[12px] text-amber-200/90 leading-relaxed">
                              سيتم توليد هوية تشفير جديدة بالكامل، وإبلاغ كل جهات اتصالك تلقائيًا. لن يلغي ذلك أي نسخ من رسائلك قد يكون مهاجم قد حصل عليها سابقًا.
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <button
                              type="button"
                              disabled={rotationBusy}
                              onClick={async () => {
                                if (rotationBusy || typeof onEmergencyRotate !== 'function') return;
                                setRotationBusy(true);
                                try {
                                  await onEmergencyRotate();
                                  setRotationConfirmOpen(false);
                                  (window as any).showGlobalToast?.('تم تدوير مفاتيح التشفير بنجاح. سيعاد بناء الجلسات تلقائيًا مع جهات اتصالك.', 'success');
                                } catch {
                                  (window as any).showGlobalToast?.('تعذر إتمام تدوير المفاتيح. سيُعاد المحاولة تلقائيًا عند تسجيل الدخول القادم.', 'error');
                                } finally {
                                  setRotationBusy(false);
                                }
                              }}
                              className="flex-1 py-2 rounded-xl bg-amber-500 text-black font-black text-xs hover:bg-amber-400 transition-colors cursor-pointer disabled:opacity-40"
                            >
                              {rotationBusy ? 'جارٍ التدوير...' : 'تأكيد التدوير'}
                            </button>
                            <button
                              type="button"
                              onClick={() => setRotationConfirmOpen(false)}
                              disabled={rotationBusy}
                              className="flex-1 py-2 rounded-xl bg-white/5 border border-white/10 text-zinc-300 font-bold text-xs hover:bg-white/10 transition-colors cursor-pointer disabled:opacity-40"
                            >
                              إلغاء
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Security blocking systems */}
                <div className="bg-red-500/5 backdrop-blur-2xl border border-red-500/10 rounded-[32px] p-6 shadow-2xl space-y-4">
                  <div className="flex items-center justify-between border-b border-red-500/10 pb-3">
                    <span className="text-[11px] font-bold text-red-400 uppercase tracking-widest font-mono">Defense Shield (Blocklist)</span>
                    <ShieldAlert className="w-4 h-4 text-red-500" />
                  </div>

                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Enter UID or @username to block..."
                      value={blockingTarget}
                      onChange={(e) => setBlockingTarget(e.target.value)}
                      className="w-full pl-4 pr-16 py-3 bg-red-950/20 border border-red-500/20 rounded-[18px] text-[13px] text-white placeholder-red-500/30 focus:outline-none focus:border-red-500/50 transition-all font-mono"
                    />
                    <button
                      type="button"
                      onClick={async () => {
                        if (!blockingTarget.trim()) return;
                        setSettingsSaving(true);
                        try {
                          // REAL block flow: the server-side blocks API (enforced in
                          // messaging) — the old path wrote a dead settings array.
                          let resolvedBlockId = blockingTarget.trim();
                          if (resolvedBlockId.startsWith('@')) {
                            const cleanName = resolvedBlockId.substring(1).trim();
                            const usersRes = await fetch(`/api/users/search?query=${encodeURIComponent(cleanName)}`, { headers: { Authorization: `Bearer ${getAccessToken()}` } });
                            const usersData = await usersRes.json();
                            const found = (usersData.users || usersData.results || [])?.find((u: any) => u.username?.toLowerCase() === cleanName.toLowerCase());
                            if (found) {
                              resolvedBlockId = found.id;
                            } else {
                              throw new Error('لم يتم العثور على المستخدم.');
                            }
                          }
                          const res = await fetch('/api/blocks', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` },
                            body: JSON.stringify({ blockedUserId: resolvedBlockId }),
                          });
                          if (!res.ok) {
                            const d = await res.json().catch(() => ({}));
                            throw new Error(d.error || 'Block failed.');
                          }
                          setBlockingTarget('');
                          await loadBlockedUsers();
                          setSettingsSuccess('User blocked successfully!');
                        } catch (err: any) {
                          setSettingsError(err.message || 'Block operation failed.');
                        } finally {
                          setSettingsSaving(false);
                        }
                      }}
                      className="absolute right-1.5 top-1.5 bottom-1.5 px-4 bg-red-500 text-slate-900 rounded-[14px] font-extrabold text-[12px] hover:bg-red-400 transition-colors uppercase tracking-wider cursor-pointer"
                    >
                      {settingsSaving ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : "BLOCK"}
                    </button>
                  </div>

                  {blockedUsersList.length > 0 && (
                    <div className="space-y-3 pt-2 divide-y divide-white/5 scrollbar-none max-h-48 overflow-y-auto">
                      {blockedUsersList.map((bu: any) => (
                        <div key={bu.id} className="flex items-center justify-between pt-3 group">
                          <button
                            type="button"
                            onClick={async () => {
                              setSettingsSaving(true);
                              try {
                                const res = await fetch(`/api/blocks/${bu.id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${getAccessToken()}` } });
                                if (!res.ok) throw new Error('unblock failed');
                                await loadBlockedUsers();
                                setSettingsSuccess('User unblocked.');
                              } catch {
                                setSettingsError('Unblock failed.');
                              } finally {
                                setSettingsSaving(false);
                              }
                            }}
                            className="text-[10px] font-bold text-red-400 hover:text-white border border-red-500/20 bg-red-500/5 px-2.5 py-1 rounded-full hover:bg-red-500 transition-colors cursor-pointer"
                          >
                            UNBLOCK
                          </button>
                          <div className="flex items-center gap-3">
                            <div className="text-left">
                              <p className="text-[13px] font-bold text-white/90">{bu.displayName}</p>
                              <p className="text-[10px] text-white/20 font-mono italic">@{bu.username}</p>
                            </div>
                            <img
                              src={bu.avatarUrl || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=50&h=50&q=80'}
                              className="w-10 h-10 rounded-full object-cover grayscale opacity-50 group-hover:grayscale-0 group-hover:opacity-100 transition-all border border-red-500/10"
                              alt=""
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                  {/* Search visibility (real: enforced in search + directory) */}
                  <div className="space-y-2 border-t border-white/5 pt-5">
                    <p className="text-[14px] font-bold text-white/90">من يمكنه إيجادي في البحث</p>
                    <p className="text-[11px] text-white/30 mb-1">يحدد إن كنت ستظهر في البحث وقائمة المستخدمين</p>
                    <GlassSegmentedControl
                      scopeId="searchVis"
                      options={[
                        { label: 'Everyone', value: 'everyone' },
                        { label: 'My Contacts', value: 'contacts' },
                        { label: 'Nobody', value: 'nobody' }
                      ]}
                      value={(currentUser.privacySettings as any)?.searchVisibility || 'everyone'}
                      onChange={(val) => updateUserSettings({ 'privacySettings.searchVisibility': val })}
                    />
                  </div>

                  {/* About visibility (real: bio stripped per viewer) */}
                  <div className="space-y-2 border-t border-white/5 pt-5">
                    <p className="text-[14px] font-bold text-white/90">من يرى نبذتي</p>
                    <GlassSegmentedControl
                      scopeId="aboutVis"
                      options={[
                        { label: 'Everyone', value: 'everyone' },
                        { label: 'My Contacts', value: 'contacts' },
                        { label: 'Nobody', value: 'nobody' }
                      ]}
                      value={(currentUser.privacySettings as any)?.aboutVisibility || 'everyone'}
                      onChange={(val) => updateUserSettings({ 'privacySettings.aboutVisibility': val })}
                    />
                  </div>

                  {/* Username change (Telegram parity) — real route with uniqueness check */}
                  <div className="space-y-2 border-t border-white/5 pt-5">
                    <p className="text-[14px] font-bold text-white/90">تغيير اسم المستخدم</p>
                    <p className="text-[11px] text-white/30 mb-1">حسابك حالياً: <b className="font-mono">@{currentUser.username}</b> — التغيير محدود 3 مرات/ساعة</p>
                    <input
                      value={usernameChange.next}
                      onChange={(e) => setUsernameChange({ ...usernameChange, next: normalizeUsernameInput(e.target.value).slice(0, 20) })}
                      placeholder="الاسم الجديد (3-20 حرف)"
                      className="w-full bg-zinc-800/80 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white outline-none focus:border-emerald-500/50 font-mono"
                      dir="ltr"
                    />
                    <button
                      onClick={async () => {
                        setCredBusy(true); setCredMsg(null);
                        try {
                          const res = await fetch('/api/users/me/username', { method: 'PUT', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` }, body: JSON.stringify({ newUsername: usernameChange.next }) });
                          const d = await res.json();
                          if (!res.ok) throw new Error(d.message || d.error || 'فشل التغيير.');
                          setUsernameChange({ next: '' });
                          setCredMsg({ ok: true, text: `تم تغيير اسم المستخدم إلى @${d.username}. حدّث الصفحة.` });
                        } catch (e: any) {
                          setCredMsg({ ok: false, text: e.message });
                        } finally {
                          setCredBusy(false);
                        }
                      }}
                      disabled={credBusy || usernameChange.next.length < 3}
                      className="w-full py-2.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold text-xs disabled:opacity-40"
                    >
                      {credBusy ? '...' : 'تغيير اسم المستخدم'}
                    </button>
                  </div>

                  {/* Account credentials — REAL flows to /api/auth/password|pin/change */}
                  <div className="bg-white/[0.03] border border-white/10 rounded-3xl p-5 space-y-4">
                    <p className="text-[11px] font-bold text-white/50 uppercase tracking-widest font-mono">بيانات الدخول</p>

                    <div className="space-y-2">
                      <p className="text-[13px] font-bold text-white/90">تغيير كلمة المرور</p>
                      <input type="password" value={pwChange.current} onChange={(e) => setPwChange({ ...pwChange, current: e.target.value })} placeholder="كلمة المرور الحالية" className="w-full bg-zinc-800/80 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white outline-none focus:border-emerald-500/50" dir="ltr" />
                      <input type="password" value={pwChange.next} onChange={(e) => setPwChange({ ...pwChange, next: e.target.value })} placeholder="كلمة المرور الجديدة (10+ أحرف)" className="w-full bg-zinc-800/80 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white outline-none focus:border-emerald-500/50" dir="ltr" />
                      <button
                        onClick={async () => {
                          setCredBusy(true); setCredMsg(null);
                          try {
                            const res = await fetch('/api/auth/password/change', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` }, body: JSON.stringify({ currentPassword: pwChange.current, newPassword: pwChange.next }) });
                            const d = await res.json();
                            if (!res.ok) throw new Error(d.error || 'فشل التغيير');
                            setPwChange({ current: '', next: '' });
                            setCredMsg({ ok: true, text: 'تم تغيير كلمة المرور بنجاح.' });
                          } catch (e: any) { setCredMsg({ ok: false, text: e.message }); } finally { setCredBusy(false); }
                        }}
                        disabled={credBusy || !pwChange.current || !pwChange.next}
                        className="w-full py-2.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold text-xs disabled:opacity-40"
                      >
                        {credBusy ? '...' : 'تحديث كلمة المرور'}
                      </button>
                    </div>

                    <div className="space-y-2 border-t border-white/5 pt-4">
                      <p className="text-[13px] font-bold text-white/90">تغيير رمز الاسترجاع PIN</p>
                      <input type="password" inputMode="numeric" maxLength={6} value={pinChange.current} onChange={(e) => setPinChange({ ...pinChange, current: e.target.value.replace(/\D/g, '').slice(0, 6) })} placeholder="PIN الحالي (6 أرقام)" className="w-full bg-zinc-800/80 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white outline-none focus:border-emerald-500/50 text-center tracking-[0.4em]" dir="ltr" />
                      <input type="password" inputMode="numeric" maxLength={6} value={pinChange.next} onChange={(e) => setPinChange({ ...pinChange, next: e.target.value.replace(/\D/g, '').slice(0, 6) })} placeholder="PIN الجديد" className="w-full bg-zinc-800/80 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white outline-none focus:border-emerald-500/50 text-center tracking-[0.4em]" dir="ltr" />
                      <button
                        onClick={async () => {
                          setCredBusy(true); setCredMsg(null);
                          try {
                            const res = await fetch('/api/auth/pin/change', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` }, body: JSON.stringify({ currentPin: pinChange.current, newPin: pinChange.next }) });
                            const d = await res.json();
                            if (!res.ok) throw new Error(d.error || 'فشل التغيير');
                            setPinChange({ current: '', next: '' });
                            setCredMsg({ ok: true, text: 'تم تغيير رمز PIN بنجاح.' });
                          } catch (e: any) { setCredMsg({ ok: false, text: e.message }); } finally { setCredBusy(false); }
                        }}
                        disabled={credBusy || pinChange.current.length !== 6 || pinChange.next.length !== 6}
                        className="w-full py-2.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold text-xs disabled:opacity-40"
                      >
                        {credBusy ? '...' : 'تحديث رمز PIN'}
                      </button>
                    </div>

                    {credMsg && (
                      <p className={`text-xs ${credMsg.ok ? 'text-emerald-400' : 'text-red-400'}`}>{credMsg.text}</p>
                    )}

                    {/* Export account data — REAL server route */}
                    <div className="border-t border-white/5 pt-4">
                      <button
                        onClick={async () => {
                          try {
                            const res = await fetch('/api/users/me/export', { headers: { Authorization: `Bearer ${getAccessToken()}` } });
                            if (!res.ok) throw new Error();
                            const blob = await res.blob();
                            const url = URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = `dirasha-data-${(currentUser.username || 'me').slice(0, 12)}.json`;
                            a.click();
                            URL.revokeObjectURL(url);
                          } catch (_) {
                            if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                              (window as any).showGlobalToast('تعذر تصدير البيانات. حاول مجدداً.', 'error');
                            }
                          }
                        }}
                        className="w-full py-2.5 rounded-xl bg-white/5 text-zinc-300 border border-white/10 font-bold text-xs hover:bg-white/10"
                      >
                        تصدير بياناتي (JSON)
                      </button>
                    </div>
                  </div>
                  {/* Advanced privacy: calls + auto-delete (all real) */}
                  <div className="bg-white/[0.03] border border-white/10 rounded-3xl p-5 space-y-4">
                    <p className="text-[11px] font-bold text-white/50 uppercase tracking-widest font-mono">خصوصية متقدمة</p>

                    <div className="flex items-center justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <p className="text-[13px] font-bold text-white/90">حماية IP في المكالمات</p>
                        <p className="text-[10px] text-white/30">توجيه المكالمات عبر خوادمنا لإخفاء عنوان IP عن الطرف الآخر</p>
                      </div>
                      <button
                        onClick={() => updateUserSettings({ 'privacySettings.callRelayEnabled': !currentUser.privacySettings?.callRelayEnabled })}
                        className={`h-6 w-11 rounded-full p-1 transition-colors ${currentUser.privacySettings?.callRelayEnabled ? 'bg-blue-600' : 'bg-white/10'}`}
                      >
                        <div className={`h-4 w-4 rounded-full bg-white transition-transform ${currentUser.privacySettings?.callRelayEnabled ? '-translate-x-5' : 'translate-x-0'}`} />
                      </button>
                    </div>

                    <div className="flex items-center justify-between gap-4 border-t border-white/5 pt-4">
                      <div className="flex-1 min-w-0">
                        <p className="text-[13px] font-bold text-white/90">إسكات مكالمات غير المعروفين</p>
                        <p className="text-[10px] text-white/30">لن يستطيع من ليس في جهات اتصالك الاتصال بك</p>
                      </div>
                      <button
                        onClick={() => updateUserSettings({ 'privacySettings.silenceUnknownCallers': !currentUser.privacySettings?.silenceUnknownCallers })}
                        className={`h-6 w-11 rounded-full p-1 transition-colors ${currentUser.privacySettings?.silenceUnknownCallers ? 'bg-blue-600' : 'bg-white/10'}`}
                      >
                        <div className={`h-4 w-4 rounded-full bg-white transition-transform ${currentUser.privacySettings?.silenceUnknownCallers ? '-translate-x-5' : 'translate-x-0'}`} />
                      </button>
                    </div>

                    <div className="border-t border-white/5 pt-4">
                      <p className="text-[13px] font-bold text-white/90">حذف الحساب تلقائياً بعد الخمول</p>
                      <p className="text-[10px] text-white/30 mb-2">إذا لم تتصل بالتطبيق طوال المدة المختارة يُحذف حسابك (تليجرام)</p>
                      <div className="flex gap-1.5">
                        {[{ l: 'إيقاف', v: 0 }, { l: 'شهر', v: 1 }, { l: '3 أشهر', v: 3 }, { l: '6 أشهر', v: 6 }, { l: 'سنة', v: 12 }].map((o) => {
                          const active = Number((currentUser as any)?.autoDeleteAfterMonths || 0) === o.v;
                          return (
                            <button
                              key={o.v}
                              onClick={async () => {
                                await updateUserSettings({ autoDeleteAfterMonths: o.v });
                                if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                                  (window as any).showGlobalToast(o.v ? `سيُحذف حسابك بعد ${o.l} من الخمول.` : 'تم إيقاف الحذف التلقائي.', 'info');
                                }
                              }}
                              className={`flex-1 py-2 rounded-xl text-[10px] font-bold border ${active ? 'bg-red-500/20 text-red-300 border-red-500/40' : 'bg-white/5 text-zinc-400 border-white/10'}`}
                            >
                              {o.l}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* NESTED VIEW: NOTIFICATION PREFERENCES */}
            {settingsSubView === 'notifications' && (
              <div className="space-y-6 text-left animate-fade-in pb-32 px-1">
                <div className="bg-white/[0.03] backdrop-blur-xl border border-white/10 rounded-[32px] p-6 shadow-xl space-y-6">
                  <span className="block text-[11px] font-bold text-white/50 border-b border-white/5 pb-2 uppercase tracking-widest font-mono">Alert System</span>
                  
                  {/* Global Alerts switch */}
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold text-white/90">General Alerts</p>
                      <p className="text-[11px] text-white/30">Enable or disable all notifications</p>
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        await updateUserSettings({
                          'notificationSettings.enabled': !currentUser.notificationSettings?.enabled
                        });
                        setSettingsSuccess('Notification preferences updated!');
                      }}
                      className={`h-6 w-11 rounded-full p-1 transition-colors duration-200 focus:outline-none ${
                        currentUser.notificationSettings?.enabled ? 'bg-blue-600' : 'bg-white/10'
                      }`}
                    >
                      <div className={`h-4 w-4 rounded-full bg-white transition-transform duration-200 ${
                        currentUser.notificationSettings?.enabled ? '-translate-x-5' : 'translate-x-0'
                      }`} />
                    </button>
                  </div>

                  {/* Group messages notifications (real: gated in the pipeline) */}
                  <div className="flex items-center justify-between gap-4 border-t border-white/5 pt-5">
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold text-white/90">إشعارات المجموعات</p>
                      <p className="text-[11px] text-white/30">تنبيه منفصل لرسائل المجموعات — يعمل حتى مع إسكات الكل</p>
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        await updateUserSettings({
                          'notificationSettings.groupMessagesEnabled': !currentUser.notificationSettings?.groupMessagesEnabled
                        });
                      }}
                      className={`h-6 w-11 rounded-full p-1 transition-colors duration-200 focus:outline-none ${
                        currentUser.notificationSettings?.groupMessagesEnabled !== false ? 'bg-blue-600' : 'bg-white/10'
                      }`}
                    >
                      <div className={`h-4 w-4 rounded-full bg-white transition-transform duration-200 ${
                        currentUser.notificationSettings?.groupMessagesEnabled !== false ? '-translate-x-5' : 'translate-x-0'
                      }`} />
                    </button>
                  </div>

                  {/* Sound on/off */}
                  <div className="flex items-center justify-between gap-4 border-t border-white/5 pt-5">
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold text-white/90">Message Sounds</p>
                      <p className="text-[11px] text-white/30">Chime for incoming messages</p>
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        await updateUserSettings({
                          'notificationSettings.soundEnabled': !currentUser.notificationSettings?.soundEnabled
                        });
                      }}
                      className={`h-6 w-11 rounded-full p-1 transition-colors duration-200 focus:outline-none ${
                        currentUser.notificationSettings?.soundEnabled ? 'bg-blue-600' : 'bg-white/10'
                      }`}
                    >
                      <div className={`h-4 w-4 rounded-full bg-white transition-transform duration-200 ${
                        currentUser.notificationSettings?.soundEnabled ? '-translate-x-5' : 'translate-x-0'
                      }`} />
                    </button>
                  </div>

                  {/* Alert Volume */}
                  <div className="space-y-3 border-t border-white/5 pt-5">
                    <div className="flex justify-between items-center px-1">
                      <p className="text-[14px] font-bold text-white/90">Alert Volume</p>
                      <span className="text-[11px] font-mono text-white/30">{currentUser.notificationSettings?.soundVolume || 80}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={currentUser.notificationSettings?.soundVolume || 80}
                      onChange={async (e) => {
                        await updateUserSettings({
                          'notificationSettings.soundVolume': parseInt(e.target.value)
                        });
                      }}
                      className="w-full h-1.5 bg-white/10 rounded-full appearance-none accent-blue-500 cursor-pointer"
                    />
                  </div>

                  {/* Notification sound choice (real: used by the notification pipeline) */}
                  <div className="space-y-3 border-t border-white/5 pt-5">
                    <p className="text-[14px] font-bold text-white/90 px-1">نغمة الإشعار</p>
                    <div className="flex gap-2 px-1">
                      {[
                        { label: 'الكلاسيكية', url: '' },
                        { label: 'هادئة', url: 'https://assets.mixkit.co/active_storage/sfx/209/209-120.wav' },
                        { label: 'معدنية', url: 'https://assets.mixkit.co/active_storage/sfx/2568/2568-120.wav' },
                      ].map((s) => {
                        const active = (currentUser.notificationSettings?.soundUrl || '') === s.url;
                        return (
                          <button
                            key={s.label}
                            onClick={async () => {
                              await updateUserSettings({ 'notificationSettings.soundUrl': s.url });
                              try { new Audio(s.url || 'https://assets.mixkit.co/active_storage/sfx/2869/2869-120.wav').play().catch(() => {}); } catch (_) {}
                            }}
                            className={`flex-1 py-2.5 rounded-xl text-xs font-bold border transition-colors ${
                              active ? 'bg-blue-500/20 text-blue-300 border-blue-500/40' : 'bg-white/5 text-zinc-400 border-white/10 hover:bg-white/10'
                            }`}
                          >
                            {s.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Quiet hours (real: enforced by the notification pipeline) */}
                  <div className="space-y-3 border-t border-white/5 pt-5">
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <p className="text-[14px] font-bold text-white/90">ساعات الهدوء</p>
                        <p className="text-[11px] text-white/30">إسكات الإشعارات تلقائياً في نطاق زمني يومي</p>
                      </div>
                      <button
                        type="button"
                        onClick={async () => {
                          const qh = (currentUser.notificationSettings as any)?.quietHours || { enabled: false, from: '23:00', to: '07:00' };
                          await updateUserSettings({ 'notificationSettings.quietHours': { ...qh, enabled: !qh.enabled } });
                        }}
                        className={`h-6 w-11 rounded-full p-1 transition-colors duration-200 focus:outline-none ${
                          (currentUser.notificationSettings as any)?.quietHours?.enabled ? 'bg-blue-600' : 'bg-white/10'
                        }`}
                      >
                        <div className={`h-4 w-4 rounded-full bg-white transition-transform duration-200 ${
                          (currentUser.notificationSettings as any)?.quietHours?.enabled ? '-translate-x-5' : 'translate-x-0'
                        }`} />
                      </button>
                    </div>
                    {(currentUser.notificationSettings as any)?.quietHours?.enabled ? (
                      <div className="flex items-center gap-2 px-1">
                        <input
                          type="time"
                          value={(currentUser.notificationSettings as any)?.quietHours?.from || '23:00'}
                          onChange={async (e) => {
                            const qh = (currentUser.notificationSettings as any)?.quietHours || {};
                            await updateUserSettings({ 'notificationSettings.quietHours': { ...qh, from: e.target.value } });
                          }}
                          className="flex-1 bg-black/30 border border-white/10 rounded-xl px-2 py-2 text-xs text-white outline-none"
                        />
                        <span className="text-zinc-500 text-xs">إلى</span>
                        <input
                          type="time"
                          value={(currentUser.notificationSettings as any)?.quietHours?.to || '07:00'}
                          onChange={async (e) => {
                            const qh = (currentUser.notificationSettings as any)?.quietHours || {};
                            await updateUserSettings({ 'notificationSettings.quietHours': { ...qh, to: e.target.value } });
                          }}
                          className="flex-1 bg-black/30 border border-white/10 rounded-xl px-2 py-2 text-xs text-white outline-none"
                        />
                      </div>
                    ) : null}
                  </div>

                  {/* Highlight words (Telegram parity — bypass mute/quiet like mentions) */}
                  <div className="space-y-2 border-t border-white/5 pt-5">
                    <p className="text-[14px] font-bold text-white/90">كلمات التنبيه</p>
                    <p className="text-[11px] text-white/30">كلمات مفصولة بفاصلة — أي رسالة تحويها تُنبّهك حتى لو كانت المحادثة مكتومة</p>
                    <input
                      type="text"
                      defaultValue={((currentUser.notificationSettings as any)?.highlightWords || []).join('، ')}
                      onBlur={async (e) => {
                        const words = e.target.value.split(/[،,]/).map((w) => w.trim()).filter(Boolean).slice(0, 20);
                        await updateUserSettings({ 'notificationSettings.highlightWords': words });
                        if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                          (window as any).showGlobalToast(`تم حفظ ${words.length} كلمة تنبيه.`, 'success');
                        }
                      }}
                      placeholder="عاجل، اجتماع، اسمك..."
                      className="w-full bg-black/30 border border-white/10 rounded-xl px-3 py-2.5 text-xs text-white outline-none focus:border-blue-500/50"
                    />
                  </div>

                  {/* Call notifications (real: gates incoming-call ringing) */}
                  <div className="flex items-center justify-between gap-4 border-t border-white/5 pt-5">
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold text-white/90">إشعارات المكالمات</p>
                      <p className="text-[11px] text-white/30">رنين المكالمات الواردة — الإيقاف يرفضها بصمت</p>
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        await updateUserSettings({
                          'notificationSettings.callNotifications': !currentUser.notificationSettings?.callNotifications
                        });
                      }}
                      className={`h-6 w-11 rounded-full p-1 transition-colors duration-200 focus:outline-none ${
                        currentUser.notificationSettings?.callNotifications !== false ? 'bg-blue-600' : 'bg-white/10'
                      }`}
                    >
                      <div className={`h-4 w-4 rounded-full bg-white transition-transform duration-200 ${
                        currentUser.notificationSettings?.callNotifications !== false ? '-translate-x-5' : 'translate-x-0'
                      }`} />
                    </button>
                  </div>

                  {/* Reset all notification settings (Telegram parity) */}
                  <div className="border-t border-white/5 pt-5">
                    <button
                      onClick={async () => {
                        if (!window.confirm('إعادة ضبط كل إعدادات الإشعارات للوضع الافتراضي؟')) return;
                        await updateUserSettings({
                          notificationSettings: {
                            enabled: true, soundEnabled: true, soundVolume: 80,
                            vibration: true, previewEnabled: true, inAppToasts: true,
                            reactionNotifications: true, callNotifications: true,
                            desktopNotifications: false, groupMessagesEnabled: true,
                          }
                        });
                        if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                          (window as any).showGlobalToast('تمت إعادة ضبط إعدادات الإشعارات.', 'success');
                        }
                      }}
                      className="w-full py-2.5 rounded-xl bg-white/5 text-zinc-300 border border-white/10 text-xs font-bold hover:bg-white/10"
                    >
                      إعادة ضبط إعدادات الإشعارات
                    </button>
                  </div>

                  {/* Call ringtone style (real: drives the WebAudio ringer) */}
                  <div className="space-y-2 border-t border-white/5 pt-5">
                    <p className="text-[14px] font-bold text-white/90">نغمة الرنين</p>
                    <div className="flex gap-1.5">
                      {[
                        { label: 'الكلاسيكية', val: '' },
                        { label: 'مزدوجة', val: 'double' },
                        { label: 'هادئة', val: 'soft' },
                      ].map((o) => {
                        const active = (currentUser.notificationSettings as any)?.ringtoneStyle === o.val || (!o.val && !(currentUser.notificationSettings as any)?.ringtoneStyle);
                        return (
                          <button
                            key={o.val || 'classic'}
                            onClick={async () => {
                              await updateUserSettings({ 'notificationSettings.ringtoneStyle': o.val });
                            }}
                            className={`flex-1 py-2 rounded-xl text-[11px] font-bold border transition-colors ${
                              active ? 'bg-blue-500/20 text-blue-300 border-blue-500/40' : 'bg-white/5 text-zinc-400 border-white/10'
                            }`}
                          >
                            {o.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Vibration */}
                  <div className="flex items-center justify-between gap-4 border-t border-white/5 pt-5">
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold text-white/90">Haptic Feedback</p>
                      <p className="text-[11px] text-white/30">Vibrate on mobile interactions</p>
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        await updateUserSettings({
                          'notificationSettings.vibration': !currentUser.notificationSettings?.vibration
                        });
                      }}
                      className={`h-6 w-11 rounded-full p-1 transition-colors duration-200 focus:outline-none ${
                        currentUser.notificationSettings?.vibration ? 'bg-orange-500' : 'bg-white/10'
                      }`}
                    >
                      <div className={`h-4 w-4 rounded-full bg-white transition-transform duration-200 ${
                        currentUser.notificationSettings?.vibration ? '-translate-x-5' : 'translate-x-0'
                      }`} />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* NESTED VIEW: APPEARANCE PREFERENCES */}
            {settingsSubView === 'appearance' && (
              <div className="space-y-6 text-left animate-fade-in pb-32 px-1">
                <div className="bg-white/[0.03] backdrop-blur-xl border border-white/10 rounded-[32px] p-6 shadow-xl space-y-6">
                  <span className="block text-[11px] font-bold text-white/50 border-b border-white/5 pb-2 uppercase tracking-widest font-mono">Visual Design</span>
                  
                  {/* Theme Select */}
                  <div className="space-y-2">
                    <p className="text-[14px] font-bold text-white/90 pl-1">Visual Theme</p>
                    <select
                      value={currentUser.appearanceSettings?.theme || 'dark'}
                      onChange={async (e) => {
                        await updateUserSettings({
                          'appearanceSettings.theme': e.target.value
                        });
                      }}
                      className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-2xl text-[13px] text-white focus:outline-none focus:border-blue-500/30 transition-all appearance-none cursor-pointer"
                    >
                      <option value="dark">Deep Charcoal Dark</option>
                      <option value="light">High Contrast Light</option>
                      <option value="system">Follow System Default</option>
                    </select>
                  </div>

                  {/* Font Size Select */}
                  <div className="space-y-2 border-t border-white/5 pt-5">
                    <p className="text-[14px] font-bold text-white/90 pl-1">Typography Size</p>
                    <select
                      value={currentUser.appearanceSettings?.fontSize || 'medium'}
                      onChange={async (e) => {
                        await updateUserSettings({
                          'appearanceSettings.fontSize': e.target.value
                        });
                      }}
                      className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-2xl text-[13px] text-white focus:outline-none focus:border-blue-500/30 transition-all appearance-none cursor-pointer"
                    >
                      <option value="small">Compact Readable</option>
                      <option value="medium">Standard Balanced</option>
                      <option value="large">Large Comfortable</option>
                    </select>
                  </div>

                  {/* Accent color (Telegram parity) — real: outgoing bubbles + active tabs */}
                  <div className="space-y-2 border-t border-white/5 pt-5">
                    <p className="text-[14px] font-bold text-white/90">لون التمييز</p>
                    <div className="flex gap-2 px-1">
                      {[
                        { label: 'زمردي', hex: '' },
                        { label: 'أزرق', hex: '#3b82f6' },
                        { label: 'بنفسجي', hex: '#8b5cf6' },
                        { label: 'وردي', hex: '#f43f5e' },
                        { label: 'كهرمان', hex: '#f59e0b' },
                        { label: 'مائي', hex: '#14b8a6' },
                      ].map((c) => {
                        const active = (currentUser.appearanceSettings?.accentColor || '') === c.hex;
                        return (
                          <button
                            key={c.label}
                            onClick={async () => {
                              await updateUserSettings({ 'appearanceSettings.accentColor': c.hex });
                            }}
                            className={`w-9 h-9 rounded-full border-2 transition-all ${active ? 'scale-110 border-white shadow-lg' : 'border-white/20 hover:scale-105'}`}
                            style={{ background: c.hex || '#10b981' }}
                            title={c.label}
                          />
                        );
                      })}
                    </div>
                  </div>

                  {/* Bubble corners */}
                  <div className="space-y-2 border-t border-white/5 pt-5">
                    <p className="text-[14px] font-bold text-white/90">شكل زوايا الفقاعات</p>
                    <div className="flex gap-1.5">
                      {[
                        { label: 'ناعمة', val: '' },
                        { label: 'حادة', val: 'sharp' },
                        { label: 'دائرية', val: 'round' },
                      ].map((o) => {
                        const active = (currentUser.appearanceSettings?.bubbleCorners || '') === o.val;
                        return (
                          <button
                            key={o.val || 'soft'}
                            onClick={async () => {
                              await updateUserSettings({ 'appearanceSettings.bubbleCorners': o.val });
                            }}
                            className={`flex-1 py-2 rounded-xl text-[11px] font-bold border transition-colors ${
                              active ? 'bg-blue-500/20 text-blue-300 border-blue-500/40' : 'bg-white/5 text-zinc-400 border-white/10'
                            }`}
                          >
                            {o.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Wallpaper dimming (WhatsApp parity) */}
                  <div className="space-y-2 border-t border-white/5 pt-5">
                    <div className="flex justify-between items-center px-1">
                      <p className="text-[14px] font-bold text-white/90">تعتيم الخلفية</p>
                      <span className="text-[11px] font-mono text-white/30">{Number((currentUser.appearanceSettings as any)?.bgDim) || 0}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="40"
                      value={Number((currentUser.appearanceSettings as any)?.bgDim) || 0}
                      onChange={async (e) => {
                        await updateUserSettings({ 'appearanceSettings.bgDim': parseInt(e.target.value) });
                      }}
                      className="w-full h-1.5 bg-white/10 rounded-full appearance-none accent-blue-500 cursor-pointer"
                    />
                  </div>

                  {/* Audio quality mode + processing (real: Opus SDP + getUserMedia) */}
                  <div className="space-y-2 border-t border-white/5 pt-5">
                    <p className="text-[14px] font-bold text-white/90">جودة صوت المكالمات</p>
                    <div className="flex gap-1.5">
                      {[
                        { label: 'توفير البيانات', val: 'dataSaver' },
                        { label: 'عادي', val: 'standard' },
                        { label: 'أعلى جودة', val: 'high' },
                      ].map((o) => {
                        const active = String(currentUser.chatSettings?.audioMode || 'standard') === o.val;
                        return (
                          <button
                            key={o.val}
                            onClick={async () => {
                              await updateUserSettings({ 'chatSettings.audioMode': o.val });
                              if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                                (window as any).showGlobalToast(o.val === 'dataSaver' ? 'وضع توفير البيانات: صوت أوضح للشبكات الضعيفة.' : o.val === 'high' ? 'أعلى جودة صوت ممكنة.' : 'وضع متوازن.', 'info');
                              }
                            }}
                            className={`flex-1 py-2 rounded-xl text-[11px] font-bold border transition-colors ${
                              active ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : 'bg-white/5 text-zinc-400 border-white/10'
                            }`}
                          >
                            {o.label}
                          </button>
                        );
                      })}
                    </div>
                    {([
                      { k: 'echoCancellation', l: 'إلغاء الصدى' },
                      { k: 'noiseSuppression', l: 'إزالة الضوضاء' },
                      { k: 'autoGainControl', l: 'رفع تلقائي للصوت' },
                    ] as const).map((p) => {
                      const cur = (currentUser.chatSettings?.audioProcessing as any)?.[p.k] !== false;
                      return (
                        <div key={p.k} className="flex items-center justify-between gap-2 border-t border-white/5 pt-3">
                          <span className="text-[12px] text-zinc-300">{p.l}</span>
                          <button
                            onClick={async () => {
                              const curProc = (currentUser.chatSettings?.audioProcessing as any) || {};
                              await updateUserSettings({ 'chatSettings.audioProcessing': { ...curProc, [p.k]: !cur } });
                            }}
                            className={`h-5 w-9 rounded-full p-0.5 transition-colors ${cur ? 'bg-blue-600' : 'bg-white/10'}`}
                          >
                            <div className={`h-4 w-4 rounded-full bg-white transition-transform ${cur ? '-translate-x-4' : 'translate-x-0'}`} />
                          </button>
                        </div>
                      );
                    })}
                  </div>

                  {/* Compact Mode */}
                  <div className="flex items-center justify-between gap-4 border-t border-white/5 pt-5">
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold text-white/90">Compact Layout</p>
                      <p className="text-[11px] text-white/30">Denser view for more content</p>
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        await updateUserSettings({
                          'appearanceSettings.compactMode': !currentUser.appearanceSettings?.compactMode
                        });
                      }}
                      className={`h-6 w-11 rounded-full p-1 transition-colors duration-200 focus:outline-none ${
                        currentUser.appearanceSettings?.compactMode ? 'bg-blue-600' : 'bg-white/10'
                      }`}
                    >
                      <div className={`h-4 w-4 rounded-full bg-white transition-transform duration-200 ${
                        currentUser.appearanceSettings?.compactMode ? '-translate-x-5' : 'translate-x-0'
                      }`} />
                    </button>
                  </div>

                </div>
              </div>
            )}

            {/* NESTED VIEW: CHAT OPTIONS */}
            {settingsSubView === 'chat' && (
              <div className="space-y-6 text-left animate-fade-in pb-32 px-1">
                <div className="bg-white/[0.03] backdrop-blur-xl border border-white/10 rounded-[32px] p-6 shadow-xl space-y-6">
                  <span className="block text-[11px] font-bold text-white/50 border-b border-white/5 pb-2 uppercase tracking-widest font-mono">Communication Config</span>
                  
                  {/* Enter key to Send */}
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold text-white/90">Instant Send</p>
                      <p className="text-[11px] text-white/30">Use "Enter" to transmit messages</p>
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        await updateUserSettings({
                          'chatSettings.enterToSend': !currentUser.chatSettings?.enterToSend
                        });
                      }}
                      className={`h-6 w-11 rounded-full p-1 transition-colors duration-200 focus:outline-none ${
                        currentUser.chatSettings?.enterToSend ? 'bg-blue-600' : 'bg-white/10'
                      }`}
                    >
                      <div className={`h-4 w-4 rounded-full bg-white transition-transform duration-200 ${
                        currentUser.chatSettings?.enterToSend ? '-translate-x-5' : 'translate-x-0'
                      }`} />
                    </button>
                  </div>

                  {/* Read Receipts — wired to the REAL enforced key
                      (privacySettings.readReceiptsEnabled; the old
                      chatSettings.readReceipts was a dead duplicate) */}
                  <div className="flex items-center justify-between gap-4 border-t border-white/5 pt-5">
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold text-white/90">Read Receipts</p>
                      <p className="text-[11px] text-white/30">Enable real-time status checkmarks</p>
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        await updateUserSettings({
                          'privacySettings.readReceiptsEnabled': currentUser.privacySettings?.readReceiptsEnabled === false
                        });
                      }}
                      className={`h-6 w-11 rounded-full p-1 transition-colors duration-200 focus:outline-none ${
                        currentUser.privacySettings?.readReceiptsEnabled !== false ? 'bg-blue-600' : 'bg-white/10'
                      }`}
                    >
                      <div className={`h-4 w-4 rounded-full bg-white transition-transform duration-200 ${
                        currentUser.privacySettings?.readReceiptsEnabled !== false ? '-translate-x-5' : 'translate-x-0'
                      }`} />
                    </button>
                  </div>

                  {/* Auto Download */}
                  <div className="flex items-center justify-between gap-4 border-t border-white/5 pt-5">
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold text-white/90">Auto Download</p>
                      <p className="text-[11px] text-white/30">Instantly save incoming media</p>
                    </div>
                  </div>
                  {/* Media auto-download matrix (WhatsApp/Telegram parity):
                      per-type × per-network, consumed by MediaGate */}
                  <div className="space-y-2">
                    {[
                      { label: 'الصور', key: 'photos' },
                      { label: 'الفيديو', key: 'videos' },
                      { label: 'الملفات', key: 'documents' },
                    ].map((row) => {
                      const matrix: any = currentUser.chatSettings?.autoDownloadMatrix || {};
                      const mode = String(matrix[row.key] || currentUser.chatSettings?.mediaAutoDownload || 'wifi');
                      return (
                        <div key={row.key} className="flex items-center gap-2">
                          <span className="w-16 text-[12px] text-zinc-300 shrink-0">{row.label}</span>
                          <div className="flex gap-1 flex-1">
                            {[
                              { label: 'دائماً', val: 'always' },
                              { label: 'واي فاي', val: 'wifi' },
                              { label: 'أبداً', val: 'never' },
                            ].map((opt) => {
                              const active = mode === opt.val;
                              return (
                                <button
                                  key={opt.val}
                                  onClick={async () => {
                                    const next = { ...matrix, [row.key]: opt.val };
                                    await updateUserSettings({ 'chatSettings.autoDownloadMatrix': next });
                                  }}
                                  className={`flex-1 py-1.5 rounded-lg text-[10px] font-bold border transition-colors ${
                                    active ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' : 'bg-white/5 text-zinc-400 border-white/10'
                                  }`}
                                >
                                  {opt.label}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  {/* Chat font size (real: zoom applied to the messages stream) */}
                  <div className="space-y-2 border-t border-white/5 pt-5">
                    <p className="text-[14px] font-bold text-white/90">حجم خط المحادثة</p>
                    <div className="flex gap-1.5">
                      {[
                        { label: 'A-', val: 'small' },
                        { label: 'A', val: 'medium' },
                        { label: 'A+', val: 'large' },
                        { label: 'A++', val: 'xlarge' },
                      ].map((opt) => {
                        const active = String(currentUser.chatSettings?.fontScale || 'medium') === opt.val;
                        return (
                          <button
                            key={opt.val}
                            onClick={async () => {
                              await updateUserSettings({ 'chatSettings.fontScale': opt.val });
                            }}
                            className={`flex-1 py-2 rounded-xl text-xs font-black border transition-colors ${
                              active ? 'bg-blue-500/20 text-blue-300 border-blue-500/40' : 'bg-white/5 text-zinc-400 border-white/10 hover:bg-white/10'
                            }`}
                          >
                            {opt.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  {/* Inline video previews (Telegram parity) */}
                  <div className="flex items-center justify-between gap-4 border-t border-white/5 pt-5">
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold text-white/90">معاينة الفيديو تلقائياً</p>
                      <p className="text-[11px] text-white/30">عرض الفيديوهات داخل المحادثة — الإيقاف يحوّلها لبطاقات تنزيل</p>
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        await updateUserSettings({
                          'chatSettings.inlineVideos': currentUser.chatSettings?.inlineVideos === false ? true : false
                        });
                      }}
                      className={`h-6 w-11 rounded-full p-1 transition-colors duration-200 focus:outline-none ${
                        currentUser.chatSettings?.inlineVideos !== false ? 'bg-blue-600' : 'bg-white/10'
                      }`}
                    >
                      <div className={`h-4 w-4 rounded-full bg-white transition-transform duration-200 ${
                        currentUser.chatSettings?.inlineVideos !== false ? '-translate-x-5' : 'translate-x-0'
                      }`} />
                    </button>
                  </div>

                  {/* Upload quality (real: drives client-side WebP compression) */}
                  <div className="space-y-2 border-t border-white/5 pt-5">
                    <p className="text-[14px] font-bold text-white/90">جودة رفع الصور</p>
                    <div className="flex gap-1.5">
                      {[
                        { label: 'عادية (أسرع)', val: 'standard' },
                        { label: 'HD (أعلى دقة)', val: 'hd' },
                      ].map((o) => {
                        const active = String(currentUser.chatSettings?.uploadQuality || 'standard') === o.val;
                        return (
                          <button
                            key={o.val}
                            onClick={async () => {
                              await updateUserSettings({ 'chatSettings.uploadQuality': o.val });
                              if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                                (window as any).showGlobalToast(o.val === 'hd' ? 'سيتم رفع الصور بجودة HD.' : 'سيتم رفع الصور بالجودة العادية.', 'info');
                              }
                            }}
                            className={`flex-1 py-2 rounded-xl text-[11px] font-bold border transition-colors ${
                              active ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' : 'bg-white/5 text-zinc-400 border-white/10'
                            }`}
                          >
                            {o.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Time format (real: used by message timestamps) */}
                  <div className="space-y-2 border-t border-white/5 pt-5">
                    <p className="text-[14px] font-bold text-white/90">تنسيق الوقت</p>
                    <div className="flex gap-1.5">
                      {[
                        { label: '12 ساعة', val: '12h' },
                        { label: '24 ساعة', val: '24h' },
                      ].map((opt) => {
                        const active = String(currentUser.chatSettings?.timeFormat || '12h') === opt.val;
                        return (
                          <button
                            key={opt.val}
                            onClick={async () => {
                              await updateUserSettings({ 'chatSettings.timeFormat': opt.val });
                            }}
                            className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-colors ${
                              active ? 'bg-blue-500/20 text-blue-300 border-blue-500/40' : 'bg-white/5 text-zinc-400 border-white/10 hover:bg-white/10'
                            }`}
                          >
                            {opt.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  {/* Chat wallpaper (real: applied to the messages area) */}
                  <div className="space-y-2 border-t border-white/5 pt-5">
                    <p className="text-[14px] font-bold text-white/90">خلفية المحادثة</p>
                    <div className="flex gap-2">
                      {[
                        { label: 'بدون', val: '' },
                        { label: 'شفق', val: 'aurora' },
                        { label: 'ليلي', val: 'midnight' },
                        { label: 'غابة', val: 'forest' },
                        { label: 'بنفسجي', val: 'plum' },
                      ].map((w) => {
                        const active = String(currentUser.chatSettings?.wallpaper || '') === w.val;
                        return (
                          <button
                            key={w.val || 'none'}
                            onClick={async () => {
                              await updateUserSettings({ 'chatSettings.wallpaper': w.val });
                            }}
                            className={`flex-1 h-10 rounded-xl text-[10px] font-bold border transition-colors ${
                              active ? 'border-blue-400 text-blue-300 ring-1 ring-blue-400/50' : 'border-white/10 text-zinc-400 hover:text-white'
                            }`}
                            style={{ background: ({
                              '': 'rgba(255,255,255,0.04)',
                              'aurora': 'linear-gradient(135deg, #0f2027 0%, #203a43 55%, #2c5364 100%)',
                              'midnight': 'linear-gradient(135deg, #141e30 0%, #243b55 100%)',
                              'forest': 'linear-gradient(135deg, #0b2e1f 0%, #14532d 60%, #052e1b 100%)',
                              'plum': 'linear-gradient(135deg, #2d1b4e 0%, #44318d 100%)',
                            } as Record<string, string>)[w.val] }}
                          >
                            {w.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>

                <div className="bg-red-500/5 backdrop-blur-xl border border-red-500/10 rounded-[32px] p-6 shadow-xl space-y-4">
                  <p className="text-[11px] font-bold text-red-400 border-b border-red-500/10 pb-2 uppercase tracking-widest font-mono">DANGER ZONE</p>
                  <button
                    onClick={async () => {
                      // REAL: wipe the on-device caches (messages/chats/outbox).
                      try {
                        await Promise.all([
                          MessagesCacheDB.clear(),
                          ChatsCacheDB.clear(),
                          OutboxDB.clear(),
                        ]);
                        if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                          (window as any).showGlobalToast('تم مسح التاريخ المحلي على هذا الجهاز. حدّث الصفحة.', 'success');
                        }
                      } catch (_) {
                        if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                          (window as any).showGlobalToast('تعذر المسح. حاول مجدداً.', 'error');
                        }
                      }
                    }}
                    className="w-full py-4 bg-red-600/10 hover:bg-red-600 text-red-500 hover:text-white border border-red-500/20 rounded-[22px] text-[13px] font-extrabold transition-all active:scale-[0.98]"
                  >
                    Clear Interaction History
                  </button>
                </div>
              </div>
            )}

            {/* NESTED VIEW: DEVICE SESSIONS */}
            {settingsSubView === 'sessions' && (
              <div className="space-y-6 text-left animate-fade-in pb-32 px-1">
                <div className="bg-white/[0.03] backdrop-blur-xl border border-white/10 rounded-[32px] p-6 shadow-xl space-y-6">
                  <span className="block text-[11px] font-bold text-white/50 border-b border-white/5 pb-2 uppercase tracking-widest font-mono">Linked Devices</span>
                  <button
                    type="button"
                    onClick={() => onOpenSessionsPanel && onOpenSessionsPanel()}
                    className="w-full py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl text-[13px] font-bold text-white/80 transition-all flex items-center justify-center gap-2"
                  >
                    إدارة الأجهزة والجلسات (إبطال الجهاز البعيد)
                  </button>
                  
                  {loadingSessions ? (
                    <div className="py-12 flex flex-col items-center justify-center gap-3">
                      <Loader2 className="w-8 h-8 animate-spin text-blue-500/50" />
                      <p className="text-[12px] text-white/30 font-mono tracking-widest text-center">Loading secure sessions...</p>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {deviceSessions.filter(s => s.isCurrent).map((sess) => (
                        <div key={sess.id} className="bg-blue-500/5 border border-blue-500/20 rounded-[24px] p-5 shadow-inner">
                          <div className="flex items-center justify-between mb-4">
                            <span className="px-3 py-1 bg-blue-500 text-slate-900 text-[10px] font-bold rounded-full">CURRENT DEVICE</span>
                            <Laptop className="w-5 h-5 text-blue-400" />
                          </div>
                          
                          <div className="space-y-2.5">
                            <div className="flex justify-between items-center">
                              <span className="text-[11px] text-white/30 uppercase font-mono tracking-tighter">Device / Browser</span>
                              <span className="text-[13px] text-white/90 font-bold">Secure Browser</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-[11px] text-white/30 uppercase font-mono tracking-tighter">Network IP</span>
                              <span className="text-[13px] text-white/90 font-mono italic">{formatDeviceIp(sess.ipAddress)}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-[11px] text-white/30 uppercase font-mono tracking-tighter">State Active</span>
                              <span className="text-[13px] text-white/90">{formatDeviceLastActive(sess.lastActive)}</span>
                            </div>
                          </div>
                        </div>
                      ))}

                      {deviceSessions.filter(s => !s.isCurrent).length > 0 ? (
                        <div className="space-y-4 pt-4 border-t border-white/5">
                          <div className="flex items-center justify-between px-1">
                            <span className="text-[11px] font-bold text-white/30 uppercase font-mono tracking-widest">Authorized Access</span>
                            <button
                              type="button"
                              onClick={handleRevokeAllOtherSessions}
                              className="text-[10px] font-bold text-red-500 hover:text-white transition-all uppercase tracking-widest border border-red-500/30 rounded-lg px-2.5 py-1"
                            >
                              Terminate All
                            </button>
                          </div>
                          
                          <div className="space-y-3">
                            {deviceSessions.filter(s => !s.isCurrent).map((sess) => (
                              <div key={sess.id} className="bg-white/[0.04] border border-white/5 rounded-[22px] p-4 flex items-center justify-between group">
                                <div className="space-y-0.5">
                                  <p className="text-[13px] font-bold text-white/80">Remote Log</p>
                                  <p className="text-[10px] text-white/20 font-mono tracking-tighter">{formatDeviceIp(sess.ipAddress)}</p>
                                  <p className="text-[10px] text-white/40">{formatDeviceLastActive(sess.lastActive)}</p>
                                </div>
                                <button 
                                  onClick={() => handleRevokeSession(sess.id)}
                                  className="p-2.5 bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white rounded-[14px] transition-all"
                                >
                                  <Ban className="w-4 h-4" />
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      ) : (
                        <div className="text-center py-6 text-white/10 text-[12px] font-bold tracking-widest uppercase italic">
                          No Secondary Auth Points
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* NESTED VIEW: CLOUD STORAGE (BYO) */}
            {settingsSubView === 'storage' && (
              <div className="space-y-6 text-left animate-fade-in pb-32 px-1">
                <StorageLinkCard />

                {/* Storage & cache management (Telegram parity) — all real IndexedDB ops */}
                <div className="bg-white/[0.03] border border-white/10 rounded-3xl p-5 space-y-4">
                  <p className="text-[11px] font-bold text-white/50 uppercase tracking-widest font-mono">التخزين والذاكرة المؤقتة</p>

                  <div className="bg-black/30 rounded-2xl px-4 py-3 flex items-center justify-between">
                    <span className="text-xs text-zinc-300">المستخدم على هذا الجهاز</span>
                    <span className="text-sm font-black text-emerald-300 font-mono">{storageEstimate}</span>
                  </div>

                  {cacheStats.length > 0 ? (
                    <div className="space-y-2 max-h-56 overflow-y-auto">
                      {cacheStats.map((s) => {
                        const label = chats.find((c: any) => c.id === s.chatId)?.name || s.chatId.slice(0, 14) + '…';
                        return (
                          <div key={s.chatId} className="flex items-center gap-3 bg-white/[0.03] rounded-xl px-3 py-2">
                            <span className="flex-1 text-xs text-zinc-200 truncate">{label}</span>
                            <span className="text-[10px] text-zinc-500 font-mono">{s.messages} رسالة</span>
                            <button
                              onClick={async () => {
                                await MessagesCacheDB.deleteChat(s.chatId);
                                await refreshCacheStats();
                                if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                                  (window as any).showGlobalToast('تم مسح كاش هذه المحادثة.', 'success');
                                }
                              }}
                              className="text-[10px] font-bold px-2 py-1 rounded-lg bg-red-500/10 text-red-300 hover:bg-red-500/20"
                            >
                              مسح
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <p className="text-[11px] text-zinc-500">لا توجد كاش محفوظ بعد — افتح محادثة لتُخزَّن.</p>
                  )}
                </div>
              </div>
            )}

            {/* NESTED VIEW: ADMIN MONITORING & SYSTEM DASHBOARD - PORTAL TO FULL SCREEN */}
            {settingsSubView === 'admin_dashboard' && createPortal(
              <div className="fixed inset-0 z-[99999] bg-black overflow-y-auto text-zinc-100 font-sans" style={{ direction: 'ltr' }}>
                 <div className="mx-auto w-full min-h-screen relative pb-10 flex flex-col">
                    <div className="sticky top-0 z-[100] bg-black/60 backdrop-blur-2xl border-b border-white/[0.05] px-6 py-4 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <button 
                          onClick={() => setSettingsSubView('main')}
                          className="p-2 bg-transparent hover:bg-white/[0.05] rounded-md text-zinc-400 transition-colors border border-transparent hover:border-white/[0.05] focus:outline-none flex items-center justify-center gap-2"
                        >
                          <ChevronRight className="w-5 h-5" />
                          <span className="text-sm font-medium">الرجوع</span>
                        </button>
                      </div>
                      <h1 className="text-base font-semibold text-zinc-200">Terminal & Operations</h1>
                    </div>
                    <div className="p-6 max-w-[1400px] w-full mx-auto align-top flex-1">
                      <AdminDashboard accessToken={accessToken} currentUser={currentUser} />
                    </div>
                 </div>
              </div>,
              document.body
            )}

          </div>
        )}

      </div>

      {/* 5. BRAND NEW PREMIUM FLOATING GLASS BOTTOM BAR */}
      <div className="bottom-nav-bar" style={{ direction: 'ltr' }}>
        
        {/* Updates button */}
        <div 
          onClick={() => { setActiveTab('updates'); }}
          className={`nav-item ${activeTab === 'updates' ? 'active' : ''}`}
        >
          <div className="nav-icon">
            <CircleDot />
          </div>
          <span className="nav-label text-[11px]">Updates</span>
        </div>

        {/* Calls button */}
        <div 
          onClick={() => { setActiveTab('calls'); }}
          className={`nav-item ${activeTab === 'calls' ? 'active' : ''}`}
        >
          <div className="nav-icon">
            <Phone />
          </div>
          <span className="nav-label text-[11px]">Calls</span>
        </div>

        {/* Communities button */}
        <div 
          onClick={() => { setActiveTab('communities'); }}
          className={`nav-item ${activeTab === 'communities' ? 'active' : ''}`}
        >
          <div className="nav-icon">
            <Users />
          </div>
          <span className="nav-label text-[11px]">Communities</span>
        </div>

        {/* Chats button with badge indicator */}
        <div 
          onClick={() => { setActiveTab('chats'); }}
          className={`nav-item ${activeTab === 'chats' ? 'active' : ''}`}
        >
          <div className="nav-icon select-none">
            <MessageCircle />
            {unreadChatsCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-[#52525b] text-white text-[9px] font-bold w-[17px] h-[17px] rounded-full flex items-center justify-center border border-[#091014] shadow-md">
                {unreadChatsCount}
              </span>
            )}
          </div>
          <span className="nav-label text-[11px]">Chats</span>
        </div>

        {/* Admin Panel button (Admins & Developers only) */}
        {currentUser && (currentUser.role === 'admin' || currentUser.role === 'developer') && (
          <div 
            onClick={onOpenModerationCenter}
            className="nav-item"
          >
            <div className="nav-icon">
              <Shield />
              {unreadReportsCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-white text-black text-[9px] font-black w-[17px] h-[17px] rounded-full flex items-center justify-center border border-black shadow-lg">
                  {unreadReportsCount}
                </span>
              )}
            </div>
            <span className="nav-label text-[11px]">Admin</span>
          </div>
        )}

        {/* Settings button */}
        <div 
          onClick={() => { setActiveTab('settings'); }}
          className={`nav-item ${activeTab === 'settings' ? 'active' : ''}`}
        >
          <div className="nav-icon">
            <Settings />
          </div>
          <span className="nav-label text-[11px]">Settings</span>
        </div>

      </div>

      {/* 6. MODAL FOR CREATING CHAT */}
      {showNewChatModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex justify-center items-center p-4 z-50 animate-fade-in" style={{ direction: 'ltr' }}>
          <div className="bg-[#1c1c1e] rounded-[32px] p-7 max-w-sm w-full shadow-2xl border border-white/10 animate-scale-in">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-[18px] font-black text-white flex items-center gap-2 tracking-tight">
                <Plus className="w-5 h-5 text-blue-500" /> New Chat
              </h3>
              <button 
                onClick={() => setShowNewChatModal(false)}
                className="p-2 hover:bg-white/5 rounded-full transition-all cursor-pointer text-white/30 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {userLoading ? (
              <div className="py-12 flex flex-col items-center justify-center gap-4">
                <Loader2 className="w-8 h-8 animate-spin text-blue-500/50" />
                <p className="text-[12px] text-white/30 font-mono tracking-widest text-center uppercase">Loading users...</p>
              </div>
            ) : availableUsers.length > 0 ? (
              <div className="max-h-64 overflow-y-auto space-y-3 scrollbar-none">
                {availableUsers.filter(user => user.id !== 'user-bot-gemini' && user.id !== 'user-bot-dirasha' && user.username !== 'nexora').map(user => (
                  <div
                    key={user.id}
                    onClick={() => !chatCreating && handleCreateChat(user.id)}
                    className="p-4 flex items-center gap-4 bg-white/[0.04] hover:bg-white/[0.08] hover:scale-[1.02] active:scale-[0.98] border border-white/5 rounded-[22px] cursor-pointer transition-all group"
                  >
                    <img
                      src={user.avatarUrl}
                      alt={user.displayName}
                      className="w-12 h-12 rounded-full object-cover border-2 border-white/10 group-hover:border-blue-500/50 transition-all"
                      referrerPolicy="no-referrer"
                    />
                    <div className="flex-1 min-w-0">
                      <h5 className="text-[14px] font-extrabold text-white truncate">{user.displayName}</h5>
                      <p className="text-[11px] text-white/30 font-mono">@{user.username}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-12 text-center text-white/20 text-[12px] font-bold tracking-widest uppercase italic">
                Isolated Network: No Peers
              </div>
            )}
          </div>
        </div>
      )}


      
      {/* Context Menu Portal Area */}
      <AnimatePresence>
        {contextMenu && (
          <>
            <div className="fixed inset-0 z-[1000]" onClick={() => setContextMenu(null)} onContextMenu={(e) => { e.preventDefault(); setContextMenu(null); }} />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: -5 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.1 }}
              style={{ 
                position: 'fixed', 
                left: Math.min(contextMenu.x, window.innerWidth - 220), 
                top: Math.min(contextMenu.y, window.innerHeight - 300),
                zIndex: 1001,
              }}
              className="w-52 bg-[#2C2C2C] border border-white/10 rounded-2xl shadow-2xl overflow-hidden py-1.5 backdrop-blur-xl"
            >
              <div className="px-3 py-2 border-b border-white/5 mb-1.5">
                 <p className="text-[11px] font-bold text-zinc-500 uppercase tracking-widest truncate">{contextMenu.chat.name}</p>
              </div>
              
              <button 
                onClick={() => {
                  if (onViewProfile && contextMenu.chat.type === 'one-to-one') {
                    onViewProfile(contextMenu.chat.otherMember.id);
                  }
                  setContextMenu(null);
                }}
                className="w-full text-left px-3 py-2.5 text-xs text-zinc-300 hover:bg-white/5 flex items-center gap-3 transition-colors"
              >
                <User className="w-4 h-4 text-zinc-500" />
                <span>عرض الملف الشخصي</span>
              </button>

              <button 
                onClick={() => {
                  // REAL per-chat mute: persisted in user_settings.chatMutes;
                  // the App notification pipeline reads it and skips sound/vibrate/toast.
                  const chatId = contextMenu.chat.id;
                  const mutes: Record<string, number> = { ...((currentUser as any)?.chatMutes || {}) };
                  delete mutes[chatId];
                  updateUserSettings({ chatMutes: mutes });
                  if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                    (window as any).showGlobalToast('تم إلغاء كتم هذه المحادثة.', 'success');
                  }
                  setContextMenu(null);
                }}
                className="w-full text-left px-3 py-2.5 text-xs text-zinc-300 hover:bg-white/5 flex items-center gap-3 transition-colors"
              >
                <Volume2 className="w-4 h-4 text-zinc-500" />
                <span>إلغاء كتم التنبيهات</span>
              </button>

              <button
                onClick={() => {
                  const chatId = contextMenu.chat.id;
                  const mutes: Record<string, number> = { ...((currentUser as any)?.chatMutes || {}) };
                  mutes[chatId] = Date.now() + 8 * 60 * 60 * 1000;
                  updateUserSettings({ chatMutes: mutes });
                  if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                    (window as any).showGlobalToast('تم كتم التنبيهات لمدة 8 ساعات.', 'info');
                  }
                  setContextMenu(null);
                }}
                className="w-full text-left px-3 py-2.5 text-xs text-zinc-300 hover:bg-white/5 flex items-center gap-3 transition-colors"
              >
                <Volume2 className="w-4 h-4 text-zinc-500" />
                <span>كتم 8 ساعات</span>
              </button>

              <button
                onClick={() => {
                  const chatId = contextMenu.chat.id;
                  const mutes: Record<string, number> = { ...((currentUser as any)?.chatMutes || {}) };
                  mutes[chatId] = Date.now() + 7 * 24 * 60 * 60 * 1000;
                  updateUserSettings({ chatMutes: mutes });
                  if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                    (window as any).showGlobalToast('تم كتم التنبيهات لمدة أسبوع.', 'info');
                  }
                  setContextMenu(null);
                }}
                className="w-full text-left px-3 py-2.5 text-xs text-zinc-300 hover:bg-white/5 flex items-center gap-3 transition-colors"
              >
                <Volume2 className="w-4 h-4 text-zinc-500" />
                <span>كتم أسبوع</span>
              </button>

              <button
                onClick={() => {
                  const chatId = contextMenu.chat.id;
                  const mutes: Record<string, number> = { ...((currentUser as any)?.chatMutes || {}) };
                  mutes[chatId] = -1;
                  updateUserSettings({ chatMutes: mutes });
                  if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                    (window as any).showGlobalToast('تم كتم التنبيهات دائماً.', 'info');
                  }
                  setContextMenu(null);
                }}
                className="w-full text-left px-3 py-2.5 text-xs text-zinc-300 hover:bg-white/5 flex items-center gap-3 transition-colors"
              >
                <Volume2 className="w-4 h-4 text-zinc-500" />
                <span>كتم دائم</span>
              </button>

              <button
                onClick={() => {
                  // REAL archive: persisted in user_settings.archivedChats; the
                  // sidebar list filter hides archived chats (toggle: الأرشيف).
                  const chatId = contextMenu.chat.id;
                  const list: string[] = [...(((currentUser as any)?.archivedChats as string[]) || [])];
                  const idx = list.indexOf(chatId);
                  if (idx >= 0) {
                    list.splice(idx, 1);
                    if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                      (window as any).showGlobalToast('تمت إزالة المحادثة من الأرشيف.', 'success');
                    }
                  } else {
                    list.push(chatId);
                    if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                      (window as any).showGlobalToast('تمت أرشفة المحادثة — تجدها من زر الأرشيف.', 'success');
                    }
                  }
                  updateUserSettings({ archivedChats: list });
                  setContextMenu(null);
                }}
                className="w-full text-left px-3 py-2.5 text-xs text-zinc-300 hover:bg-white/5 flex items-center gap-3 transition-colors"
              >
                <Database className="w-4 h-4 text-zinc-500" />
                <span>أرشفة الدردشة</span>
              </button>

              <button
                onClick={() => {
                  // REAL pin-to-top: persisted in user_settings.pinnedChats; the
                  // list sorter lifts pinned chats above everything else.
                  const chatId = contextMenu.chat.id;
                  const list: string[] = [...(((currentUser as any)?.pinnedChats as string[]) || [])];
                  const idx = list.indexOf(chatId);
                  if (idx >= 0) list.splice(idx, 1); else if (list.length < 5) list.push(chatId);
                  updateUserSettings({ pinnedChats: list });
                  if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                    (window as any).showGlobalToast(idx >= 0 ? 'تم إلغاء التثبيت.' : 'تم تثبيت المحادثة في الأعلى.', 'success');
                  }
                  setContextMenu(null);
                }}
                className="w-full text-left px-3 py-2.5 text-xs text-zinc-300 hover:bg-white/5 flex items-center gap-3 transition-colors"
              >
                <Pin className="w-4 h-4 text-zinc-500" />
                <span>{(((currentUser as any)?.pinnedChats as string[]) || []).includes(contextMenu.chat.id) ? 'إلغاء التثبيت' : 'تثبيت في الأعلى'}</span>
              </button>

              <button
                onClick={() => {
                  // REAL mark-as-unread: dot badge without opening the chat.
                  const chatId = contextMenu.chat.id;
                  const list: string[] = [...(((currentUser as any)?.unreadMarks as string[]) || [])];
                  const idx = list.indexOf(chatId);
                  if (idx >= 0) list.splice(idx, 1); else list.push(chatId);
                  updateUserSettings({ unreadMarks: list });
                  setContextMenu(null);
                }}
                className="w-full text-left px-3 py-2.5 text-xs text-zinc-300 hover:bg-white/5 flex items-center gap-3 transition-colors"
              >
                <CheckCheck className="w-4 h-4 text-zinc-500" />
                <span>{(((currentUser as any)?.unreadMarks as string[]) || []).includes(contextMenu.chat.id) ? 'وضع علامة مقروءة' : 'وضع علامة غير مقروءة'}</span>
              </button>

              {/* Chat Lock (WhatsApp parity): hides the chat behind the passcode */}
              <button
                onClick={() => {
                  const chatId = contextMenu.chat.id;
                  const list: string[] = [...(((currentUser as any)?.lockedChats as string[]) || [])];
                  const idx = list.indexOf(chatId);
                  if (idx >= 0) list.splice(idx, 1); else list.push(chatId);
                  updateUserSettings({ lockedChats: list });
                  if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                    (window as any).showGlobalToast(idx >= 0 ? 'تم فك قفل المحادثة.' : 'تم قفل المحادثة — تجدها في تبويب المقفلة 🔒.', 'success');
                  }
                  setContextMenu(null);
                }}
                className="w-full text-left px-3 py-2.5 text-xs text-zinc-300 hover:bg-white/5 flex items-center gap-3 transition-colors"
              >
                <Lock className="w-4 h-4 text-zinc-500" />
                <span>{(((currentUser as any)?.lockedChats as string[]) || []).includes(contextMenu.chat.id) ? 'فك قفل المحادثة' : 'قفل هذه المحادثة'}</span>
              </button>

              {/* Per-chat wallpaper (WhatsApp parity) — cycles presets */}
              <button
                onClick={() => {
                  const chatId = contextMenu.chat.id;
                  const map: Record<string, string> = { ...((currentUser as any)?.chatWallpapers as Record<string, string>) || {} };
                  const order = ['', 'aurora', 'midnight', 'forest', 'plum'];
                  const next = order[(order.indexOf(map[chatId] ?? '') + 1) % order.length];
                  map[chatId] = next;
                  updateUserSettings({ chatWallpapers: map });
                  if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                    (window as any).showGlobalToast(next ? 'خلفية خاصة لهذه المحادثة: ' + order[next === '' ? 0 : order.indexOf(next)] : 'خلفية عامة.', 'info');
                  }
                  setContextMenu(null);
                }}
                className="w-full text-left px-3 py-2.5 text-xs text-zinc-300 hover:bg-white/5 flex items-center gap-3 transition-colors"
              >
                <ImageIcon className="w-4 h-4 text-zinc-500" />
                <span>تغيير خلفية هذه المحادثة</span>
              </button>

              {/* Disappearing messages timer (WhatsApp parity) */}
              <button
                onClick={async () => {
                  const chatId = contextMenu.chat.id;
                  const order = ['off', '24h', '7d', '90d'] as const;
                  const labels: Record<string, string> = { off: 'إيقاف', '24h': '24 ساعة', '7d': '7 أيام', '90d': '90 يوماً' };
                  const cur = order.indexOf((contextMenu.chat as any).disappearingTimer || 'off');
                  const next = order[(cur + 1) % order.length];
                  try {
                    const res = await fetch(`/api/chats/${chatId}/disappearing`, {
                      method: 'PUT',
                      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` },
                      body: JSON.stringify({ timer: next }),
                    });
                    const d = await res.json();
                    if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                      (window as any).showGlobalToast(res.ok ? `الرسائل المتلاشية: ${labels[next]}` : (d.error || 'تعذر الضبط'), res.ok ? 'success' : 'error');
                    }
                  } catch (_) {
                    if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                      (window as any).showGlobalToast('خطأ في الاتصال.', 'error');
                    }
                  }
                  setContextMenu(null);
                }}
                className="w-full text-left px-3 py-2.5 text-xs text-zinc-300 hover:bg-white/5 flex items-center gap-3 transition-colors"
              >
                <Clock className="w-4 h-4 text-zinc-500" />
                <span>الرسائل المتلاشية (تبديل المؤقت)</span>
              </button>

              {/* Per-chat notification tone (WhatsApp parity) — cycles inherit/presets */}
              <button
                onClick={() => {
                  const chatId = contextMenu.chat.id;
                  const all: Record<string, any> = { ...((currentUser as any)?.chatNotifOverrides || {}) };
                  const cur = all[chatId]?.soundUrl ?? '';
                  const order = ['', 'https://assets.mixkit.co/active_storage/sfx/209/209-120.wav', 'https://assets.mixkit.co/active_storage/sfx/2568/2568-120.wav'];
                  const labels: Record<string, string> = { '': 'الافتراضية', [order[1]]: 'الهادئة', [order[2]]: 'المعدنية' };
                  const next = order[(order.indexOf(cur) + 1) % order.length];
                  all[chatId] = { ...(all[chatId] || {}), soundUrl: next };
                  updateUserSettings({ chatNotifOverrides: all });
                  if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                    (window as any).showGlobalToast('نغمة هذه المحادثة: ' + labels[next], 'info');
                  }
                  setContextMenu(null);
                }}
                className="w-full text-left px-3 py-2.5 text-xs text-zinc-300 hover:bg-white/5 flex items-center gap-3 transition-colors"
              >
                <Volume2 className="w-4 h-4 text-zinc-500" />
                <span>نغمة خاصة (تبديل)</span>
              </button>

              {/* Per-chat vibration (WhatsApp parity) — cycles default/on/off */}
              <button
                onClick={() => {
                  const chatId = contextMenu.chat.id;
                  const all: Record<string, any> = { ...((currentUser as any)?.chatNotifOverrides || {}) };
                  const cur = all[chatId]?.vibrate || 'default';
                  const order = ['default', 'on', 'off'] as const;
                  const labels: Record<string, string> = { default: 'الافتراضي', on: 'مضاعف', off: 'بدون' };
                  const next = order[(order.indexOf(cur as any) + 1) % order.length];
                  all[chatId] = { ...(all[chatId] || {}), vibrate: next };
                  updateUserSettings({ chatNotifOverrides: all });
                  if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                    (window as any).showGlobalToast('اهتزاز هذه المحادثة: ' + labels[next], 'info');
                  }
                  setContextMenu(null);
                }}
                className="w-full text-left px-3 py-2.5 text-xs text-zinc-300 hover:bg-white/5 flex items-center gap-3 transition-colors"
              >
                <Activity className="w-4 h-4 text-zinc-500" />
                <span>اهتزاز خاص (تبديل)</span>
              </button>

              {/* Assign to custom folder (Telegram parity) */}
              <button
                onClick={async () => {
                  const folders = [...(((currentUser as any)?.chatFolders as any[]) || [])];
                  if (folders.length === 0) {
                    if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                      (window as any).showGlobalToast('أنشئ مجلداً أولاً من زر «+ مجلد».', 'info');
                    }
                    setContextMenu(null);
                    return;
                  }
                  const folder = folders.find(f => f.chatIds.includes(contextMenu.chat.id));
                  if (folder) {
                    folder.chatIds = folder.chatIds.filter((id: string) => id !== contextMenu.chat.id);
                    updateUserSettings({ chatFolders: folders });
                    if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                      (window as any).showGlobalToast(`تمت إزالة المحادثة من مجلد «${folder.name}».`, 'success');
                    }
                  } else {
                    const names = folders.map((f, i) => `${i + 1}) ${f.name}`).join('  ');
                    const pick = window.prompt(`أضف إلى أي مجلد؟\n${names}\n\nاكتب الرقم:`);
                    const idx = Number(pick) - 1;
                    if (folders[idx]) {
                      folders[idx].chatIds.push(contextMenu.chat.id);
                      updateUserSettings({ chatFolders: folders });
                      if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                        (window as any).showGlobalToast(`أضيفت إلى مجلد «${folders[idx].name}».`, 'success');
                      }
                    }
                  }
                  setContextMenu(null);
                }}
                className="w-full text-left px-3 py-2.5 text-xs text-zinc-300 hover:bg-white/5 flex items-center gap-3 transition-colors"
              >
                <Folder className="w-4 h-4 text-zinc-500" />
                <span>إضافة/إزالة من مجلد</span>
              </button>

              {/* Clear chat history for SELF (WhatsApp parity) — real deletedFor sweep */}
              <button
                onClick={async () => {
                  const chatId = contextMenu.chat.id;
                  if (!window.confirm('مسح سجل هذه المحادثة عندك فقط؟ (سيبقى سجلها عند الطرف الآخر)')) return;
                  try {
                    const res = await fetch(`/api/chats/${chatId}/clear-me`, {
                      method: 'POST',
                      headers: { Authorization: `Bearer ${getAccessToken()}` },
                    });
                    const d = await res.json();
                    if (res.ok) {
                      await MessagesCacheDB.deleteChat(chatId);
                      if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                        (window as any).showGlobalToast(`تم مسح ${d.cleared} رسالة من سجلك لهذه المحادثة.`, 'success');
                      }
                    } else {
                      if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                        (window as any).showGlobalToast(d.error || 'تعذر المسح.', 'error');
                      }
                    }
                  } catch (_) {
                    if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                      (window as any).showGlobalToast('خطأ في الاتصال.', 'error');
                    }
                  }
                  setContextMenu(null);
                }}
                className="w-full text-left px-3 py-2.5 text-xs text-rose-400 hover:bg-rose-500/10 flex items-center gap-3 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
                <span>مسح سجل المحادثة (عندك فقط)</span>
              </button>

              {/* Channel actions (Telegram parity): invite-link copy + leave.
                  Admin management UI is NOT available inline (GroupSettingsPanel
                  is out of scope) — promote/demote stays server-side via
                  POST /api/chats/:chatId/promote which already works for channels. */}
              {contextMenu.chat.type === 'channel' && (
                <>
                  <div className="h-px bg-white/5 my-1" />
                  <button
                    onClick={async () => {
                      try {
                        const res = await fetch(`/api/chats/${contextMenu.chat.id}/invite`, {
                          method: 'POST',
                          headers: { Authorization: `Bearer ${getAccessToken()}` },
                        });
                        const d = await res.json();
                        if (!res.ok) throw new Error(d.error || 'تعذر إنشاء رابط الدعوة.');
                        try { navigator.clipboard.writeText(String(d.code || '')); } catch { /* clipboard denied */ }
                        if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                          (window as any).showGlobalToast('تم نسخ كود دعوة القناة.', 'success');
                        }
                      } catch (e: any) {
                        if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                          (window as any).showGlobalToast(e.message, 'error');
                        }
                      }
                      setContextMenu(null);
                    }}
                    className="w-full text-left px-3 py-2.5 text-xs text-emerald-300 hover:bg-emerald-500/10 flex items-center gap-3 transition-colors"
                  >
                    <Copy className="w-4 h-4" />
                    <span>نسخ رابط الدعوة</span>
                  </button>
                  <button
                    onClick={async () => {
                      const chatId = contextMenu.chat.id;
                      if (!window.confirm('مغادرة هذه القناة؟')) return;
                      try {
                        const res = await fetch(`/api/chats/${chatId}/leave`, {
                          method: 'POST',
                          headers: { Authorization: `Bearer ${getAccessToken()}` },
                        });
                        const d = await res.json();
                        if (!res.ok) throw new Error(d.error || 'تعذر مغادرة القناة.');
                        if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                          (window as any).showGlobalToast('تمت مغادرة القناة.', 'success');
                        }
                      } catch (e: any) {
                        if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                          (window as any).showGlobalToast(e.message, 'error');
                        }
                      }
                      setContextMenu(null);
                    }}
                    className="w-full text-left px-3 py-2.5 text-xs text-rose-400 hover:bg-rose-500/10 flex items-center gap-3 transition-colors"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>مغادرة القناة</span>
                  </button>
                </>
              )}

              <div className="h-px bg-white/5 my-1" />

              <button
                onClick={() => {
                  if (onReportUser && contextMenu.chat.type === 'one-to-one') {
                    onReportUser(contextMenu.chat.otherMember.id);
                  }
                  setContextMenu(null);
                }}
                className="w-full text-left px-3 py-2.5 text-xs text-rose-400 hover:bg-rose-500/10 flex items-center gap-3 transition-colors"
              >
                <ShieldAlert className="w-4 h-4" />
                <span>إبلاغ عن المستخدم</span>
              </button>

              <button 
                onClick={() => {
                   if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                    (window as any).showGlobalToast('تم حظر المستخدم بنجاح.', 'error');
                  }
                  setContextMenu(null);
                }}
                className="w-full text-left px-3 py-2.5 text-xs text-rose-500 font-bold hover:bg-rose-500/10 flex items-center gap-3 transition-colors"
              >
                <Ban className="w-4 h-4" />
                <span>حظر المستخدم</span>
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Group creation (WhatsApp-style flow) */}
      {showGroupCreate && (
        <GroupCreateModal
          onClose={() => setShowGroupCreate(false)}
          onCreated={(chatId) => {
            setShowGroupCreate(false);
            if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
              (window as any).showGlobalToast('تم إنشاء المجموعة بنجاح.', 'success');
            }
            if (typeof window !== 'undefined' && (window as any).__openDirashaChat) {
              (window as any).__openDirashaChat(chatId);
            }
          }}
        />
      )}

      {/* Channel creation (Telegram-style one-way broadcast) — inline modal */}
      {showChannelCreate && (
        <ChannelCreateModal
          onClose={() => setShowChannelCreate(false)}
          onCreated={(chatId) => {
            setShowChannelCreate(false);
            if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
              (window as any).showGlobalToast('تم إنشاء القناة بنجاح — شارك كود الدعوة لينضم المشتركون.', 'success');
            }
            if (typeof window !== 'undefined' && (window as any).__openDirashaChat) {
              (window as any).__openDirashaChat(chatId);
            }
          }}
        />
      )}

      {/* Status Media Editor removed - now handled in App.tsx main pane */}
    </div>
  );
}
export default ChatSidebar;
