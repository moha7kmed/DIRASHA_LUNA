# 🤖 DIRASHA — ملف التسليم والـ Onboarding للنموذج المستلم

> **المشروع:** ديراشة (Dirasha) — منصة محادثات فورية عربية
> **المسار:** `C:\Users\Zedan\Downloads\dirasha`
> **تاريخ التسليم:** 21 أكتوبر 2026
> **الحالة العامة:** يعمل ✅ — لكن قاعدة البيانات (Aiven) غير متصلة حالياً (تفصيل §7)
> **الجهة المستلمة:** نموذج ذكاء اصطناعي آخر (نموذج الاستلام)

---

## 0. 🎯 كيف تقرأ هذا الملف

هذا الملف مرجعك الوحيد قبل أي أمر. راجعه أولاً.

| القسم | المحتوى |
|---|---|
| §1 | هوية المشروع والغرض |
| §2 | البنية التقنية ونموذج التشغيل |
| §3 | خريطة الملفات |
| §4 | النظام المصادقي الجديد (قلب المشروع) |
| §5 | الأنظمة الفرعية الجاهزة (شات/إشراف/وسائط) |
| §5.5 | قرارات معمارية مُتخذة — ⛔ لا تنقضها |
| §6 | متغيرات البيئة + التشغيل + أدوات التشخيص |
| §7 | ⚠️ المشاكل المفتوحة (الأهم) |
| §8 | قائمة "تم / لم يتم" |
| §9 | أنماط الكود والاصطلاحات |
| §10 | الاختبارات وقائمة التحقق + خريطة API + ديبجاج |
| §11 | ⚠️ تحذيرات أمنية + حالة Git |
| §12 | الملفات المرجعية |
| §13 | رسالة ختامية + أول 3 خطوات |

---

## 1. هوية المشروع

**ديراشة** = منصة محادثات فورية، عربية بالكامل (RTL)، شبيهة بـ WhatsApp/Telegram.

**الوظائف:**
- محادثات فورية (أفراد + مجموعات) عبر WebSocket
- مرفقات (صور/فيديو) عبر **تخزين سحابي يملكه المستخدم** (BYO-Cloud)
- حالات (Statuses) — `/api/statuses`
- مكالمات WebRTC — `src/components/CallInterface.tsx`
- إشعارات Web Push — `src/server/services/push.ts`
- لوحة إشراف + مركز مراقبة + سجل تدقيق
- **نظام هوية ذاتية السيادة**: اسم مستخدم + كلمة مرور + PIN + بصمة جهاز — بدون SMS، بدون OAuth، بدون بريد

---

## 2. البنية التقنية

### 2.1 المكدس

```
الواجهة:   React 19.2.6 + Vite 6.2.3 + TailwindCSS 4.1.14 + motion/react 12
الحالة:    @tanstack/react-query 5.100
الخادم:    Node.js + Express 4.21 + ws 8.20
قاعدة:     PostgreSQL (Aiven) + محرك in-memory احتياطي
طابور:     Redis اختياري (ioredis 5.10) — يعمل بدونه
تشفير:     Node crypto (scrypt + HMAC-SHA256 pepper) — بلا اعتماديات خارجية
PWA:       Service Worker مخصص (src/service-worker.js) + manifest.json
```

### 2.2 نموذج التشغيل

```
[المتصفح] ──HTTP/JSON──> [Express :3000] ──pg──> [PostgreSQL / Aiven]
   │                            │
   │                        [ws server] ── presence/broadcast
   │                            │
   └── IndexedDB (chats/messages/outbox)   └── Redis (اختياري)
```

- `server.ts` (96KB) — نقطة الدخول الوحيدة: REST + WebSocket + Vite middleware
- `NODE_ENV !== 'production'` → Express يدمج Vite كـ middleware (HMR)
- الإنتاج → `express.static('dist')` + SPA fallback
- **مهم:** `server.ts` monolith فيه **78 مسار HTTP** + WS + bootstrap. أي route جديد يضاف هناك أو في `src/server/routes/`.

### 2.3 لا يوجد Strapi ولا أي CMS

المشروع Express أصلي بالكامل.

---


## 3. خريطة الملفات

### 3.1 الجذر

```
server.ts                 ← نقطة الدخول: 78 route + WS + bootstrap (96KB)
package.json              ← scripts: dev / build / start / lint / restore-backups
tsconfig.json             ← ES2022, bundler resolution, jsx: react-jsx, types: ["vite/client"]
vite.config.ts            ← React plugin + Tailwind + HMR toggle (DISABLE_HMR)
index.html                ← نقطة HTML (meta tags للـ PWA)
metadata.json             ← metadata التطبيق
```

### 3.2 `src/` — الواجهة

```
src/main.tsx              ← React root + QueryClientProvider (0.6KB)
src/App.tsx               ← 144.9KB ⭐ أكبر ملف واجهة: orchestrator لكل الواجهة
src/index.css             ← 33.3KB — Tailwind 4 + متغيرات الثيم
src/types.ts              ← أنواع TypeScript المشتركة (User, Chat, Message…)
src/service-worker.js     ← 8.7KB — SW: network-first للـ HTML، cache-first للأصول
src/manifest.json         ← PWA manifest
```

### 3.3 `src/components/`

```
PhoneAuthScreen.tsx   ← 33.6KB ⭐ شاشة الدخول/التسجيل/الاسترجاع (ملف الهوية)
StorageLinkCard.tsx   ← 11.4KB ربط تخزين S3/R2/B2 (BYO-Cloud)
ChatSidebar.tsx       ← 191.9KB ⭐ أكبر ملف بالمشروع — قائمة المحادثات
ChatWindow.tsx        ← 147.3KB ⭐ نافذة المحادثة (رسائل/مرفقات/مكالمات)
CallInterface.tsx     ← 29.4KB مكالمات WebRTC
ImageEditor.tsx       ← 30.7KB محرر صور
VideoStudio.tsx       ← 13.6KB استوديو فيديو
UserProfileModal.tsx  ← 14KB
ReportModal.tsx       ← 8.8KB
ToastProvider.tsx     ← 2.6KB
VerifiedBadge.tsx     ← 1.2KB
AdminDashboard.tsx    ← 30.4KB لوحة المراقبة
ModerationCenter.tsx  ← 25.8KB مركز الإشراف
components/moderation/ ← UserView(39KB) AuditLogView ReportsView VaultView ModerationShared
```

### 3.4 `src/server/`

```
database.ts            ← 114KB ⭐ أكبر ملف خادم: RelationalDatabase + in-memory fallback
logger.ts              ← logger بسيط
services/
  auth.ts              ← ⭐ الجلسات: JWT + refresh rotation + كشف سرقة الرمز
  password.ts          ← ⭐ scrypt/salt/pepper + سياسات كلمة المرور و PIN
  recovery.ts          ← ⭐ بصمة الجهاز + reset token
  storage.ts           ← BYO-Cloud presign + تشفير AES-256-GCM للمفاتيح
  push.ts              ← Web Push (VAPID)
  dashboard_stats.ts   ← 30.6KB تجميع إحصائيات اللوحة
  moderation_jobs.ts   ← مهام خلفية للإشراف
  gemini.ts            ← تكامل Gemini (اختياري)
routes/
  authClassic.ts       ← ⭐ 17.8KB: register/login/recover/password+pin change
  storage.ts           ← ⭐ روابط presign للوسائط
  status.ts            ← الحالات
  apiKeys.ts           ← مفاتيح النظام (Gemini) لمدير النظام
websocket/
  ws_server.ts         ← 37.6KB ⭐ خادم WS: غرف المحادثات، الحضور، البث
  redis_client.ts      ← Redis مع fallback in-memory
  write_queue.ts       ← طابور كتابة خلفية (تسليم بعد الاستجابة)
  ack_manager.ts       ← تأكيد الاستلام
  dedup_manager.ts     ← منع التكرار
  presence_manager.ts  ← ⭐ إدارة الحضور (online/offline)
```

### 3.5 `scripts/`

```
run-build.ps1      ← بناء الإنتاج (vite build + esbuild)
run-tsc.ps1        ← فحص TypeScript
diagnose-ui.ts     ← ⭐ تشخيص الواجهة بـ puppeteer-core (أُضيف اليوم)
env-keys.ts        ← ⭐ يعرض أسماء متغيرات .env بدون كشف القيم (أُضيف اليوم)
cleanup-orphans.ts ← حذف حسابات يتيمة من era الـ OTP
restore-backups.ts ← استرجاع بيانات من snapshots
fix-server-admin.ps1
```

### 3.6 `docs/` + الجذر

```
docs/ARCHITECTURE.md        ← 24.1KB المعمارية التفصيلية
docs/security_spec.md       ← 2.5KB مواصفات الأمان (Firestore-era، قديم جزئياً)
docs/SETUP_AR.md            ← دليل التشغيل العربي
docs/HANDOFF_AR.md          ← ⭐ هذا الملف
SECURITY_AUDIT.md           ← 18KB تدقيق أمني
README.md                   ← 2KB نظرة عامة
data/local_db_snapshot.json ← لقطة بيانات (2 مستخدمين، 2 محادثات، 4 رسائل)
```

---


## 4. ⭐ النظام المصادقي — قلب المشروع

> الشغلانة الرئيسية المنجزة في هذه الجلسة. اقرأها بالتفصيل قبل أي تعديل.

### 4.1 ما تم حذفه

| حُذف | الدليل |
|---|---|
| Google OAuth | لا `passport`/`google` في `package.json` ولا في الكود |
| تسجيل SMS/OTP | `phone_otps_ARCHIVE_DROP` (جدول مؤرشف) + `routes/phoneAuth.ts` محذوف |
| حقول email/phone | `createDefaultUser` يضع `email: ''`, `phoneNumber: ''` |

### 4.2 تدفّق التسجيل — `POST /api/auth/register`

```
1. Rate limit: 10 تسجيلات/ساعة/IP
2. فحص الحقول الأربعة: displayName, username, password, pin
3. اسم العرض:
   validateDisplayName()        → طول 3-35، لا رموز غير مرئية، لا مسافات مزدوجة، لا impersonation
   sanitizeDisplayName()         → تنظيف
   evaluateDisplayNameQuality()  → بوابة جودة (رفض «نفس»/«ب »/emoji-only/«أ أ»)
4. اسم المستخدم:
   normalizeUsername()  → lowercase + NFKC + إزالة كل ما هو خارج [a-z0-9_.]
   validateUsername()   → 3-20 حرف، [a-zA-Z0-9_.]، لا يبدأ/ينتهي بـ . أو _، لا تكرار
   فحص التفرّد EXPLICIT → 409 USERNAME_TAKEN + 4 اقتراحات
5. كلمة المرور: validatePasswordStrength() → ≥8، ≤72، حروف+أرقام، لا تحتوي اسم المستخدم، ليست شائعة
6. PIN: validatePin() → 6 أرقام بالضبط، ليست بديهية
7. hashSecret(password) + hashSecret(pin)  → scrypt متوازي
8. generateDeviceKey() → 32 bytes base64url، يُخزَّن hash فقط
9. db.createPasswordUser()  ← قيد UNIQUE ذري على username (catch كود 23505)
10. AuthService.issueSession() → JWT 15د + refresh 7أيام
11. db.logAuthAction('register') + redis publish 'user:created'
12. Response 201: { user, accessToken, refreshToken, sessionId, deviceKey }
```

> ⭐ **مهم:** الـ `deviceKey` (النص الصريح) **يُرسل مرة واحدة فقط** في رد التسجيل، ويُعرض للمستخدم كملف `dirasha-key.txt`. الخادم لا يخزّنه — يخزّن hash فقط.

### 4.3 تدفّق الدخول — `POST /api/auth/login`

```
1. Rate limit على IP + على username
2. جلب user + secrets
3. verifySecret(password) → timing-safe
4. deviceKey اختياري → knownDevice: true/false
5. issueSession() → tokens + audit log
6. إذا محظور → assertNotBanned يرمي خطأ
```

**حماية ضد تعداد الحسابات:** `getDummyHash()` يحسب hash وهمي مرة واحدة، حتى "المستخدم غير موجود" يكلّف نفس الوقت — لا يُكشف وجود الحساب من سرعة الرد.

### 4.4 الجلسات والتوكيلات

| المكوّن | التفصيل |
|---|---|
| Access token | JWT، صلاحية **15 دقيقة**، payload: `{ userId, username, displayName }` |
| Refresh token | 32 bytes عشوائية hex، صلاحية **7 أيام**، مخزَّنة في `user_sessions` |
| Rotation | كل refresh يُبطل القديم ويصدر جديداً مع **نفس sessionId** |
| كشف السرقة | إعادة استخدام refresh منتهية/ملغاة → `revokeAllUserSessions` لكل جلسات المستخدم |
| التخزين | الواجهة تحفظ access في الذاكرة + refresh في `localStorage` |

### 4.5 ⭐ نظام الاسترجاع — 3 قنوات

```
┌─ A) بصمة الجهاز (Device Key) ───────────────────────────┐
│  256-bit عشوائي يُولَّد مرة واحدة عند التسجيل            │
│  يُعرض كملف dirasha-key.txt (تحميل)                      │
│  الخادم يخزّن hash فقط (HMAC-SHA256 + pepper)            │
│  يثبت: "أنا ما زلت أملك الجهاز الأصلي"                    │
├─ B) PIN الاسترجاع ────────────────────────────────────────┤
│  6 أرقام يختارها المستخدم عند التسجيل                    │
│  scrypt-hashed، يُرفض الشائع/البديهي (000000, 123456…)   │
│  يثبت: "أنا الإنسان الذي أنشأ الحساب"                     │
└─ C) استرجاع بمساعدة الإدارة ─────────────────────────────┐
│  موثّق كمسار مستقبلي فقط — NOT implemented               │
│  لا باب خلفي في الكود                                     │
└───────────────────────────────────────────────────────────┘

A + B معاً  →  reset token (مرة واحدة)
              TTL = 10 دقائق
              single-use → يُحرق فوراً
              عند إعادة التعيين: kills ALL الجلسات القديمة
```

### 4.6 التشفير — `src/server/services/password.ts`

```
Layer 1: scrypt (N=16384, r=8, p=1, keyLen=64)  ← memory-hard KDF
Layer 2: salt عشوائي 16 bytes لكل سر
Layer 3: pepper من env (AUTH_PEPPER أو JWT_SECRET) — لا يمس الـ DB أبداً
Layer 4: crypto.timingSafeEqual للمقارنات

صيغة التخزين:  scrypt$v1$<saltBase64>$<hashBase64>
صيغة الرموز:   HMAC-SHA256(pepper, "tok:" + token) → hex  [للأسرار عالية entropy]
```

**سياسات:**
- كلمة المرور: ≥8، ≤72 (حد scrypt)، حروف إنجليزية + أرقام، لا تحتوي اسم المستخدم، ليست في قائمة الـ 15 كلمة شائعة
- PIN: 6 أرقام بالضبط، ليست بديهية
- `passwordStrengthScore()` → مقياس قوة 0-4 للواجهة

### 4.7 حماية من تعداد الحسابات — تفاصيل

| التقنية | الموقع |
|---|---|
| dummy hash ثابت | `authClassic.ts` → `getDummyHash()` |
| رسالة خطأ موحّدة | الفشل في التحقق يعطي نفس الرسالة دائماً |
| reset token عشوائي | 24 bytes base64url |

---


## 5. الأنظمة الفرعية الجاهزة

### 5.1 المحادثات (Chats)

| الميزة | الموقع |
|---|---|
| إنشاء/جلب المحادثات | `server.ts` → `/api/chats`, `/api/chats/:id/messages` |
| الرسائل | `/api/messages` (CRUD) + `/api/chats/:id/messages/sync` |
| الحذف | `delete-everyone` / `delete-me` |
| الت الحقيقي | `ws_server.ts` — غرف حسب `chatId` |
| التفاعلات | `message_reactions`, `message_pins`, `message_reads`, `message_stars` |
| المرفقات | `attachments` + BYO presign |
| الكاش المحلي | `src/lib/chats_cache_db.ts`, `messages_cache_db.ts`, `outbox_db.ts` (IndexedDB) |

**نمط WebSocket:** `src/lib/socket_client.ts` + `socket_manager.ts` (12.2KB) — يعيد الاتصال تلقائياً، outbox للرسائل غير المُرسلة.

### 5.2 الإشراف والمراقبة

| الميزة | الموقع |
|---|---|
| مركز الإشراف | `src/components/ModerationCenter.tsx` (25.8KB) |
| لوحة المراقبة | `src/components/AdminDashboard.tsx` (30.4KB) |
| تقارير المستخدمين | `/api/moderation/reports` + `ReportModal.tsx` |
| الإنفاذ | `banUser`, warnings, notes, `/api/moderation/users/:id/enforcement` |
| سجل التدقيق | `moderation_audit_logs` + `AuditLogView.tsx` |
| مهام الخلفية | `services/moderation_jobs.ts` |
| الإحصائيات | `services/dashboard_stats.ts` (30.6KB) |

**أدوار المستخدم:** `user`, `moderator`, `developer` (أدمن). `ADMIN_USERNAMES` في `.env` يحدد من يصبح developer فوراً.

### 5.3 ⭐ الوسائط — BYO-Cloud

> **مبدأ لا تنقضه:** ملفات المستخدم **لا تُخزَّن في PostgreSQL أبداً**. كل مستخدم يربط تخزينه السحابي الخاص (R2 / B2 / S3 / MinIO) من **الإعدادات ← Cloud Storage (BYO)**.

```
المستخدم يربط → تُخزَّن مفاتيحه مشفّرة AES-256-GCM في user_storage_accounts
              → الخادم يولّد presigned URL
              → الرفع يتم من المتصفح مباشرة لتخزين المستخدم
              → قاعدة بياناتنا تحتفظ بمرجع منظّم فقط (structured media reference)
```

- `src/server/services/storage.ts` (11.1KB) — المنطق + التشفير
- `src/server/routes/storage.ts` (9.4KB) — المسارات
- `src/components/StorageLinkCard.tsx` — الواجهة
- `src/lib/storageUtils.ts` — helpers
- مخزن احتياطي مشترك اختياري عبر `S3_*` في `.env`
- ⚠️ بدون ربط تخزين: تحذير في اللوق `[WARN] [Storage] No fallback bucket configured`

### 5.4 PWA والإشعارات

- `src/service-worker.js` — cache-first للأصول، **network-first لـ HTML** (تعديل اليوم: يمنع الشاشة البيضاء من كاش قديم)
- `src/App.tsx` — تسجيل SW في الإنتاج فقط (تعديل اليوم)؛ في التطوير يُلغى أي SW قديم ويُمسح الكاش تلقائياً
- `services/push.ts` + `/api/push/vapid-key` + `/api/push/subscribe` — VAPID ephemeral إذا لم تُضبط مفاتيح

---

## 5.5 قرارات معمارية مُتخذة — ⛔ لا تنقضها

| # | القرار | السبب |
|---|---|---|
| 1 | **لا SMS / لا OTP** | التكلفة + احتكاك المستخدم |
| 2 | **لا Google OAuth** | الهوية ذاتية السيادة — لا تبعية لمزود |
| 3 | **لا بريد إلكتروني** | لا حاجة لاسترجاع بالبريد |
| 4 | **الوسائط خارج PostgreSQL** | الحجم + التكلفة + BYO = ملكية المستخدم |
| 5 | **الوسائط كمرجع منظّم** | No blob في الـ DB — فقط structured reference |
| 6 | **Aiven** على Neon/Supabase | 1 GB مجاني دائم + always-on + SSL |
| 7 | **Redis اختياري** | كل شيء يعمل بدونه (in-memory fallback) |
| 8 | **scrypt** على Argon2id/bcrypt | مدمج في Node، FIPS-capable، بلا اعتماديات |
| 9 | **refresh token rotation** | كشف سرقة الجلسة |
| 10 | **server.ts monolith** | بنية موجودة؛ لا تُقسّم بدون سبب |
| 11 | **الواجهة RTL** | كل النصوص ثنائية اللغة عربي/إنجليزي |
| 12 | **الرسائل بالعربي** | كل رسائل الخطأ للمستخدم بالعربي |

---


## 6. متغيرات البيئة

الملف: `C:\Users\Zedan\Downloads\dirasha\.env` (غير مُتتبَّع في Git — لكن Git غير مُهيأ أصلاً، انظر §11.5)

### 6.1 الموجود حالياً

| المتغير | الحالة | ملاحظة |
|---|---|---|
| `JWT_SECRET` | ✅ موجود (1046 حرف) | مفتاح توقيع التوكنات |
| `DATABASE_URL` | ⚠️ موجود لكن **معطّل** | `host=pg-117ab0d1-thedarkh95-a470.f.aivencloud.com` `port=23151` `db=defaultdb` `user=avnadmin` — **DNS NXDOMAIN** (§7.1) |
| `AUTH_PEPPER` | ✅ موجود (48 حرف) | pepper التشفير |
| `ADMIN_USERNAMES` | ⚠️ **فارغ** | ضع اسم المستخدم بتاعك → يصبح developer فوراً |

### 6.2 مطلوبة قبل الإنتاج

```
DATABASE_URL=postgres://USER:PASS@HOST:PORT/defaultdb   ← إلزامي + فعّال
JWT_SECRET=<32+ bytes عشوائية>                          ← إلزامي
AUTH_PEPPER=<32+ bytes عشوائية>                         ← إلزامي
COOKIE_SECRET=<32+ bytes عشوائية>                       ← إلزامي
STORAGE_MASTER_KEY=<64 hex chars>                       ← إلزامي لتشفير مفاتيح التخزين
ADMIN_USERNAMES=your_username                           ← قائمة مفصولة بفاصلة
ADMIN_WIPE_SECRET=<secret>                              ← لمفتاح حذف النظام (اختياري)
REDIS_URL=redis://...                                    ← اختياري
VAPID_PUBLIC_KEY / VAPID_PRIVATE_KEY                     ← اختياري (وإلا ephemeral)
GEMINI_API_KEY=...                                       ← اختياري
PORT=3000  NODE_ENV=production  LOG_LEVEL=INFO
```

### 6.3 ⚠️ سلوك الفشل الآمن

كل الأسرار الحساسة ترمي `Error` في الإنتاج إن غابت:
```ts
if (!JWT_SECRET) throw new Error('FATAL: JWT_SECRET environment variable is required in production.');
```
**لا تُحذف هذه الحمايات ولا تُطوّل البدائل (fallbacks) لتصبح في الإنتاج.**

---

## 6.5 التشغيل والبناء

```bash
# تطوير (Vite HMR مدمج في Express)
npm install
npm run dev            # → http://localhost:3000

# بناء الإنتاج
npm run build          # vite build + esbuild → dist/server.cjs + dist/*
npm start              # node dist/server.cjs

# فحص الأنواع
npm run lint           # tsc --noEmit
```

**سكربتات مساعدة (Windows):** `scripts/run-build.ps1` و `scripts/run-tsc.ps1` — تُشغّل العملية في الخلفية وتكتب النتيجة في `build.log` / `tsc.log` (لأن الأوامر تتجاوز مهلة الـ 30 ثانية).

**ترتيب الإقلاع (مهم):** `src/server/database.ts` يجب أن يُستورد **قبل** تعريف الـ routes — لأن `AuthService` و `requireAuth` يعتمدان على `db` جاهزاً. الاستيراد في `server.ts` السطر 13 accomplishes ذلك.

---

## 6.8 أدوات التشخيص (أدوات اليوم)

### `scripts/diagnose-ui.ts` — تشخيص الواجهة بمتصفح حقيقي
```bash
npx tsx scripts/diagnose-ui.ts
```
يفتح `http://localhost:3000` بـ Chrome headless ويطبع:
- طول `innerHTML` للـ `#root` (4011 = healthy، 0 = شاشة بيضاء)
- نص الـ body
- كل console errors + page errors + failed requests

**هذا هو أسرع way لتشخيص "الشاشة البيضاء". استخدمه أولاً.**

### `scripts/env-keys.ts` — فحص متغيرات البيئة بأمان
```bash
npx tsx scripts/env-keys.ts
```
يطبع أسماء المتغيرات وحالتها **بدون كشف القيم** (السحر: يعرض host/db/user لكل DATABASE_URL).

> ⚠️ **لا تقرأ `.env` مباشرة بأمر `Get-Content`** — في هذه البيئة محجوب. استخدم السكربت أعلاه.

---


## 7. ⚠️ المشاكل المفتوحة (اقرأها أولاً)

### 7.1 🔴 P0 — قاعدة بيانات Aiven غير متصلة (NXDOMAIN)

**الأعراض:**
```
[Database] PostgreSQL connection unreachable at startup (Running on in-memory storage engine):
getaddrinfo ENOTFOUND pg-117ab0d1-thedarkh95-a470.f.aivencloud.com
```

**التشخيص:**
- `Resolve-DnsName` من 8.8.8.8 و 1.1.1.1 و DNS-over-HTTPS (dns.google) → كلها **Status: 3 (NXDOMAIN)**
- جُرّبت كل صيغ hostname لـ Aiven (`-a470.f.`, `.f.`, بدون `f`, `-f.`, `eu-central-1`) → كلها NXDOMAIN
- `aivencloud.com` نفسه يعمل (A records سليمة) → فالمشكلة ليست في DNS عموماً
- ⚠️ **الاستنتاج:** مشروع Aiven نفسه **محذوف أو متوقف** — الـ hostname لم يعد موجوداً

**الأثر:** التطبيق يعمل على المحرك المحلي (in-memory) → **أي بيانات تُنشأ الآن تضيع عند إغلاق السيرفر**. الدخول/التسجيل يعمل لكن لا يحفظ.

**الحل:**
1. افتح https://console.aiven.io → اختر مشروع PostgreSQL
2. إن كان محذوفاً → **Create service** بنفس الاسم (سيُولّد hostname جديد)
3. من تبويب **Service → Connection info → General** انسخ **Service URI**
4. ضعه في `.env` كـ `DATABASE_URL=` (تأكد أن `?sslmode=require` موجود)
5. أعد تشغيل السيرفر — يجب أن ترى:
   ```
   [Database] PostgreSQL connected successfully.
   [Database] PostgreSQL schema verification complete.
   ```
6. **الجداول تُنشأ تلقائياً** (21 جدول — انظر §7.4)

### 7.2 🟡 P1 — سر قاعدة البيانات مكشوف

⚠️ **سلسلة اتصال Aiven (بما فيها كلمة المرور) ظهرت في محادثة المستخدم.** يجب **تدوير كلمة المرور** من Aiven Console قبل أي نشر. ضع الـ URI الجديد في `.env` فقط، ولا تلتقطه في أي ملف أو commit.

### 7.3 🟡 P1 — لا يوجد Git repository

```
fatal: not a git repository (or any of the parent directories): .git
```
**لا يوجد أي تاريخ أو نسخة احتياطية.** أوامر مقترحة:
```bash
cd C:\Users\Zedan\Downloads\dirasha
git init
printf '.env\nnode_modules/\ndist/\n*.log\nbuild.log\ntsc.log\nserver.log\n' > .gitignore
git add -A && git commit -m "feat: classic identity auth (username+password+pin+device key)"
```
**يجب إنشاء `.gitignore` قبل أول commit** حتى لا يُرفع `.env` فيه.

### 7.4 🟢 جداول قاعدة البيانات (تُنشأ تلقائياً)

```
users                  user_profiles          user_settings
user_sessions          user_storage_accounts
chats                  chat_members           messages
attachments            message_reactions      message_pins
message_reads          message_stars          statuses
contacts               blocks                 reports
moderation_audit_logs  system_api_keys
phone_otps_ARCHIVE_DROP  ← جدول مؤرشف (مهمل، يمكن حذفه)
```

### 7.5 🟡 P2 — puppeteer-core غير مثبَّت رسمياً

`puppeteer-core` ثُبِّت بـ `--no-save` (للتشخيص فقط) فهو **ليس** في `package.json`. طبيعي. لو حبيت تُبقيه، أضفه كـ devDependency.

### 7.6 🟢 P2 — تحذيرات غير ضارة (لا تعالجها)

```
[console.warn] <meta name="apple-mobile-web-app-capable"> is deprecated
[console.error] Failed to load resource: 401 (Unauthorized)  ← طبيعي
[DOM] Input elements should have autocomplete attributes
```
الأخطاء 401 **سلوك سليم**: المتصفح يحاول تحديث جلسة منتهية → السيرفر يرفض → الواجهة ترجع لشاشة الدخول.

### 7.7 🟡 P2 — الاسترجاع بالإدارة غير منفَّذ

القناة C (مساعدة الإدارة) موثّقة في `recovery.ts` كـ future work. **مفيش باب خلفي** — هذا مقصود ومُوثّق.

### 7.8 🟡 P2 — `docs/security_spec.md` قديم

الملف يصف قواعد Firestore (من era Google/Firebase) — لم يعد يطابق المعمارية الحالية. حدّثه ليوثّق قواعد Postgres equivalents.

---


## 8. قائمة "تم / لم يتم"

### 8.1 ✅ تم إنجازه

| # | المهمة | الحالة | الدليل |
|---|---|---|---|
| 1 | حذف Google OAuth | ✅ | لا traces في الكود |
| 2 | حذف SMS/OTP | ✅ | `phoneAuth.ts` محذوف، الجدول مؤرشف |
| 3 | حذف email/phone من الـ User | ✅ | `createDefaultUser` يضعهم فارغين |
| 4 | تسجيل بـ displayName + username + password + PIN | ✅ | `POST /api/auth/register` |
| 5 | اسم مستخدم فريد مع قيد DB ذري | ✅ | UNIQUE + catch 23505 + 409 |
| 6 | اقتراحات عند اسم محجوز | ✅ | `buildUsernameSuggestions()` → 4 بدائل |
| 7 | فحوص جودة اسم العرض | ✅ | `evaluateDisplayNameQuality()` |
| 8 | منع impersonation | ✅ | `BAN_DISPLAY_NAME_PATTERNS` (20 نمط) |
| 9 | تطبيع Unicode (NFKC) | ✅ | `normalizeUsername()` |
| 10 | تشفير scrypt + salt + pepper | ✅ | `services/password.ts` |
| 11 | مقارنة timing-safe | ✅ | `crypto.timingSafeEqual` |
| 12 | منع تعداد الحسابات | ✅ | `getDummyHash()` |
| 13 | PIN استرجاع إجباري | ✅ | 6 أرقام، scrypt-hashed |
| 14 | بصمة جهاز (device key) | ✅ | `generateDeviceKey()` + ملف `dirasha-key.txt` |
| 15 | reset token مرة واحدة 10 دقائق | ✅ | `services/recovery.ts` |
| 16 | JWT 15د + refresh 7أيام | ✅ | `services/auth.ts` |
| 17 | Refresh rotation + كشف سرقة | ✅ | `rotateRefreshToken()` |
| 18 | Rate limiting على مسارات المصادقة | ✅ | `rateLimitHit()` في server.ts |
| 19 | سجل تدقيق للمصادقة | ✅ | `db.logAuthAction()` |
| 20 | اتصال Aiven + بناء الجداول | ⚠️ **جزئي** | الجداول تُنشأ، لكن الـ DNS معطّل (§7.1) |
| 21 | BYO-Cloud للوسائط | ✅ | `services/storage.ts` + `StorageLinkCard` |
| 22 | إصلاح الشاشة البيضاء | ✅ | كود يتيم في `PhoneAuthScreen.tsx` (§9.4) |
| 23 | إصلاح Service Worker | ✅ | network-first + تعطيل في التطوير |
| 24 | صفر أخطاء TypeScript | ✅ | `npm run lint` → EXIT 0 |
| 25 | بناء إنتاج ناجح | ✅ | `npm run build` → EXIT 0 |
| 26 | تشخيص الواجهة بالأدوات | ✅ | `scripts/diagnose-ui.ts` |

### 8.2 ❌ لم يتم بعد

| # | المهمة | الأولوية | ملاحظات |
|---|---|---|---|
| 1 | **إعادة ربط Aiven** | 🔴 P0 | محتاج Service URI من المستخدم (§7.1) |
| 2 | **تدوير كلمة مرور Aiven** | 🔴 P0 | §7.2 |
| 3 | **إنشاء Git repo + .gitignore** | 🟡 P1 | §7.3 |
| 4 | اختبار E2E كامل (تسجيل→دخول→استرجاع) | 🟡 P1 | يحتاج DB فعّالة |
| 5 | `COOKIE_SECRET` / `STORAGE_MASTER_KEY` في الإنتاج | 🟡 P1 | مطلوبان (fallback يعمل في التطوير فقط) |
| 6 | `ADMIN_USERNAMES` يُملأ | 🟡 P1 | حالياً فارغ |
| 7 | تحديث `docs/security_spec.md` | 🟢 P2 | ما زال يصف Firestore |
| 8 | اختبارات آلية (vitest/jest) | 🟢 P2 | مفيش أي test runner |
| 9 | CI/CD | 🟢 P2 | — |
| 10 | النشر (VPS/Docker) | 🟢 P2 | — |
| 11 | استرجاع بمساعدة الإدارة | 🟢 P3 | موثّق كـ future (§7.7) |
| 12 | Rate limiting موزّع (Redis) | 🟢 P3 | حالياً in-memory لكل عملية |
| 13 | حذف جدول `phone_otps_ARCHIVE_DROP` | 🟢 P3 | تسظيف |
| 14 | حذف `puppeteer-core` إن لم يُحتج | 🟢 P3 | ثُبِّت بـ `--no-save` |

---


## 9. أنماط الكود والاصطلاحات

### 9.1 TypeScript

- `strict` **غير مفعّل** في `tsconfig.json` — لا تفعلها فجأة (آلاف الأخطاء تظهر)
- `moduleResolution: "bundler"` + `allowImportingTsExtensions` → الاستيرادات تستخدم **الامتداد**: `import { db } from '../database.ts'`
- `jsx: "react-jsx"` → لا حاجة لـ `import React`
- `noEmit: true` → البناء عبر esbuild/vite، ليس tsc
- `types: ["vite/client"]` → لـ `import.meta.env`

### 9.2 أسلوب الخادم

```ts
// صيغة الاستجابة الموحّدة
res.status(200).json({ ok: true, user, accessToken, refreshToken, sessionId });

// كل route في try/catch مع logger.error
} catch (err: any) {
  logger.error('[Auth] login failed:', err?.message);
  res.status(500).json({ error: 'حدث خطأ غير متوقع. حاول مرة أخرى.' });
}
```

**قاعدة مهمة:** لا تُرجع تفاصيل داخلية في رسالة الخطأ للمستخدم — استخدم `logger.error` للسجل ورسالة عامة للعميل.

### 9.3 عربي + إنجليزي

- رسائل الـ API: **عربي** (بعضها بصيغة `العربي | English`)
- تعليقات الكود: إنجليزي
- أسماء المتغيرات/functions: إنجليزي

### 9.4 ⚠️ فخ مهم: كود يتيم بعد `export default`

**هذا هو سبب الشاشة البيضاء التاريخي.** عند تحرير ملف كبير، تأكد أن **لا شيء بعد `export default X;`**. كود مثل:
```tsx
export default AuthScreen;

const [newPasswordConfirm, setNewPasswordConfirm] = useState('');  // ← يتيم!
```
يعمل `useState` **خارج أي component** → `Cannot read properties of null (reading 'useState')` → التطبيق كله ميت.

**هذا الخطأ لا يلتقطه `tsc`** (القواعد النحوية سليمة) ولا الـ build — فقط تشغيل فعلي.

**بعد أي تعديل على ملفات المكونات: شغّل `scripts/diagnose-ui.ts` وتأكد أن `ROOT innerHTML length` > 0.**

### 9.5 الملفات الكبيرة

`ChatSidebar.tsx` (191.9KB) و `ChatWindow.tsx` (147.3KB) و `App.tsx` (144.9KB) و `database.ts` (114KB).
**لا تُجزّئها بدون سبب** — الترحيل الجزئي يمكن أن يكسر الواجهة. عدّل بحذر وفي نفس الملف.

### 9.6 نمط `db` الموحّد

`src/server/database.ts` يصدّر `db` كـ **object واحد** يجمع `RelationalDatabase` (Postgres) و in-memory fallback خلف واجهة واحدة. الـ routes لا تعرف أيّهما يعمل.

---


## 10. الاختبارات وقائمة التحقق

### 10.1 ⚠️ لا توجد اختبارات آلية

مفيش test runner في المشروع (لا vitest ولا jest). **التحقق يدوي عبر curl/PowerShell.**

### 10.2 سكربت تحقق سريع (انسخه)

```powershell
# 1) الصحة
(Invoke-WebRequest 'http://localhost:3000/api/health' -UseBasicParsing).Content

# 2) فحص اسم مستخدم متاح (يجب يرجع available:true)
(Invoke-WebRequest 'http://localhost:3000/api/auth/check-username?username=testuser999' -UseBasicParsing).Content

# 3) تسجيل (غيّر القيم)
$r = Invoke-RestMethod -Method Post 'http://localhost:3000/api/auth/register' `
  -Body (@{displayName='زد المستخدم';username='testuser999';password='Str0ng#Pass99';pin='483920'} | ConvertTo-Json) `
  -ContentType 'application/json'
$r | ConvertTo-Json -Depth 3
# المتوقع: accessToken + refreshToken + sessionId + deviceKey

# 4) تكرار نفس الاسم → يجب يرجع 409 USERNAME_TAKEN
try { Invoke-RestMethod -Method Post 'http://localhost:3000/api/auth/register' `
  -Body (@{displayName='زد ثان';username='testuser999';password='Str0ng#Pass99';pin='483920'} | ConvertTo-Json) `
  -ContentType 'application/json' } catch { $_.Exception.Response.StatusCode.value__ }   # → 409

# 5) دخول خاطئ → 401
try { Invoke-RestMethod -Method Post 'http://localhost:3000/api/auth/login' `
  -Body (@{username='testuser999';password='wrongpassword'} | ConvertTo-Json) `
  -ContentType 'application/json' } catch { $_.Exception.Response.StatusCode.value__ }   # → 401

# 6) دخول صحيح
$d = Invoke-RestMethod -Method Post 'http://localhost:3000/api/auth/login' `
  -Body (@{username='testuser999';password='Str0ng#Pass99'} | ConvertTo-Json) `
  -ContentType 'application/json'
$d.accessToken
```

### 10.3 قائمة التحقق الكاملة قبل التسليم

- [ ] `npm run lint` → EXIT 0
- [ ] `npm run build` → EXIT 0
- [ ] `npx tsx scripts/diagnose-ui.ts` → `ROOT innerHTML length` > 0 وصفر page errors
- [ ] `/api/health` → `{"status":"healthy"}`
- [ ] السجل يطبع `[Database] PostgreSQL connected successfully.` (لا in-memory)
- [ ] تسجيل جديد ينجح ويعيد `deviceKey`
- [ ] اسم مستخدم مكرر → 409 + اقتراحات
- [ ] كلمة مرور ضعيفة → 400 مع رسالة
- [ ] PIN بديهي → 400
- [ ] دخول خاطئ → 401 + الحساب يُقفل بعد 10 محاولات
- [ ] استرجاع بـ PIN + device key → reset token → إعادة تعيين → كل الجلسات القديمة ميتة
- [ ] `/api/auth/me` بـ token صالح → 200
- [ ] `POST /api/auth/logout` → الجلسة ملغاة
- [ ] لوحة الأدمن تفتح لمستخدم `ADMIN_USERNAMES`
- [ ] WebSocket: رسالة تصل بين حسابين
- [ ] ربط BYO-Cloud: رفع ملف → presign → الملف في تخزين المستخدم

### 10.4 حسابات التجربة

```
ziad_sm   / Ziad#2026xQ
karim_f   / NewPass#777
```
(موجودة في `data/local_db_snapshot.json` — وهى in-memory، فقدت مع إعادة التشغيل)

---


## 10.5 خريطة أوامر API

### المصادقة — `src/server/routes/authClassic.ts`
```
POST   /api/auth/register            { displayName, username, password, pin }
POST   /api/auth/login               { username, password, deviceKey? }
POST   /api/auth/recover/request     { username, pin, deviceKey } → resetToken
POST   /api/auth/recover/reset       { username, resetToken, newPassword }
POST   /api/auth/password/change     (auth) { currentPassword, newPassword }
POST   /api/auth/pin/change          (auth) { currentPin, newPin }
```

### المصادقة — `server.ts`
```
GET    /api/auth/check-username?username=...   → { available, suggestions? }
GET    /api/auth/eval-display-name?name=...    → تقييم جودة
POST   /api/auth/refresh                        → تدوير التوكن
POST   /api/auth/logout
GET    /api/auth/me          (auth)
GET    /api/auth/sessions    (auth) · GET /api/auth/sessions/check
DELETE /api/auth/sessions/:sessionId (auth) · POST /api/auth/sessions/revoke-others (auth)
```

### المستخدم
```
GET/PUT/DELETE /api/users/me (auth) · GET /api/users · GET /api/users/search
GET/PUT /api/settings (auth)
GET/POST/DELETE /api/contacts (auth) · GET/POST/DELETE /api/blocks (auth)
```

### المحادثات
```
GET/POST /api/chats (auth)
GET/POST /api/chats/:chatId/messages (auth)
POST   /api/chats/:chatId/messages/sync (auth)
POST/PUT /api/messages · POST /api/messages/:id/delete-everyone · /delete-me
GET    /api/telemetry/messages/:messageId (auth)
```

### الإشراف
```
POST   /api/moderation/reports (auth)
GET    /api/moderation/reports · /reports/:id (moderator)
POST   /api/moderation/reports/:id/status (moderator)
GET/POST /api/moderation/users/:id/{enforcement,reports,notes,warnings}
```

### الأدمن
```
GET /api/admin/dashboard/{overview,performance,queue,errors,database,redis,analytics,health,logs,search} (admin)
GET /api/admin/system/api-keys (admin) · POST /api/admin/dashboard/log-activity
GET /api/debug/queue (admin) · POST /api/debug/simulate-db-failure (admin)
```

### أخرى
```
GET /api/health · GET /api/statuses (auth) · GET /api/push/vapid-key · POST /api/push/subscribe (auth)
GET /service-worker.js · GET /manifest.json
```

### وسائط BYO
```
GET  /api/storage/config          → حالة ربط التخزين
POST /api/storage/link            → ربط bucket خاص
POST /api/storage/presign         → رابط رفع موقّع
GET  /api/storage/accounts        → الحسابات المربوطة
```

---

## 10.8 ديبجاج playbook — "الشاشة البيضاء"

**الخطوة 0:** شغّل `npx tsx scripts/diagnose-ui.ts` → يطبع رسالة الخطأ الحقيقية.

| العلامة في الكونسول | السبب | الحل |
|---|---|---|
| `Cannot read properties of null (reading 'useState')` | كود يتيم بعد `export default` (§9.4) | احذف كل ما بعد `export default` |
| `Invalid hook call` | نسختان من React | `npm ls react` — لازم نسخة واحدة |
| `Failed to fetch dynamically imported module` | خطأ بناء/استيراد | `npm run build` وراجع الأخطاء |
| `404` على asset | base path خاطئ | راجع `vite.config.ts` |
| الصفحة القديمة تظهر | SW كاش قديم | `Ctrl+Shift+R` أو احذف SW في التطوير |

**الخطوة 1:** `npm run lint` → صفر أخطاء
**الخطوة 2:** `npm run build` → EXIT 0
**الخطوة 3:** تحقق من ترتيب الإقلاع — `database.ts` قبل الـ routes
**الخطوة 4:** راجع `server.log` (شغّل السيرفر بـ `*> server.log`)
**الخطوة 5:** تأكد أن `#root` موجود في `index.html` و `main.tsx` يستدعي `document.getElementById('root')!`

### إعادة التشغيل (Windows)
```powershell
Get-Process -Name node -ErrorAction SilentlyContinue | Stop-Process -Force
cd C:\Users\Zedan\Downloads\dirasha
Start-Process powershell -ArgumentList '-NoProfile','-Command',"cd 'C:\Users\Zedan\Downloads\dirasha'; npx tsx server.ts *> server.log" -WindowStyle Hidden
Start-Sleep 20
Get-Content .\server.log -Tail 20
```

### ⏱️ حدود الأداة
أوامر `run_commands` لها **مهلة 30 ثانية**. استخدم `scripts/run-build.ps1` / `run-tsc.ps1` للأوامر الطويلة، أو `Start-Job` + `Wait-Job`.

---


## 11. ⚠️ تحذيرات أمنية

| # | التحذير |
|---|---|
| 1 | **كلمة مرور Aiven مكشوفة في محادثة** → **تدوير إلزامي** قبل الإنتاج (§7.2) |
| 2 | `.env` **لا يُرفع لـ Git** — أنشئ `.gitignore` قبل أول commit (§7.3) |
| 3 | لا تُسجّل الأسرار في اللوق ولا تردها للمستخدم |
| 4 | `JWT_SECRET` / `AUTH_PEPPER` / `COOKIE_SECRET` / `STORAGE_MASTER_KEY` **إلزامية في الإنتاج** — لا تحذف حمايات الـ fallback |
| 5 | `ADMIN_WIPE_SECRET` — لا تضعه hardcoded (يُقرأ من env فقط) |
| 6 | خطأ 500 لا يكشف تفاصيل داخلية للمستخدم |
| 7 | `ADMIN_USERNAMES` = قائمة بيضاء — لا تكتب منطق admin في الـ DB |
| 8 | استرجاع الحساب يتطلب **عاملين** (PIN + device key) — لا تُضعفه |
| 9 | راجع `SECURITY_AUDIT.md` (18KB) قبل أي تغيير أمني |
| 10 | لا تستخدم `Get-Content .env` — محجوب في هذه البيئة؛ استخدم `scripts/env-keys.ts` |

---

## 11.5 حالة Git

```
❌ لا يوجد git repository
fatal: not a git repository (or any of the parent directories): .git
```

**مهم:** كل التغييرات موجودة **على القرص فقط** — لا نسخة احتياطية ولا تاريخ.

**قبل أي عمل كبير:** أنشئ الـ repo أولاً (§7.3).

---

## 12. الملفات المرجعية

| الملف | متى تقرأه |
|---|---|
| `docs/ARCHITECTURE.md` (24KB) | قبل تعديل البنية |
| `SECURITY_AUDIT.md` (18KB) | قبل أي تغيير أمني |
| `docs/SETUP_AR.md` | دليل التشغيل |
| `README.md` | نظرة عامة سريعة |
| `src/server/services/password.ts` | أي تعديل على التشفير |
| `src/server/services/auth.ts` | أي تعديل على الجلسات |
| `src/server/services/recovery.ts` | أي تعديل على الاسترجاع |
| `src/server/routes/authClassic.ts` | أي تعديل على مسارات المصادقة |
| `src/lib/identityUtils.ts` | أي تعديل على قواعد الهوية |
| `src/components/PhoneAuthScreen.tsx` | أي تعديل على واجهة الدخول |
| `src/server/database.ts` | أي تعديل على طبقة البيانات |

---

## 13. 🎯 رسالة ختامية للنموذج المستلم

**ما أُنجز:** نظام هوية كامل من الصفر — اسم مستخدم فريد مع قواعد صارمة، تحقق من جودة اسم العرض، منع impersonation، scrypt + salt + pepper، مقارنة timing-safe، حماية من تعداد الحسابات، 3 قنوات استرجاع (2 منفّذة + 1 موثّقة)، جلسات JWT + refresh rotation مع كشف السرقة، rate limiting، سجل تدقيق كامل. وربط Aiven بـ 21 جدول.

**الحالة:** التطبيق يعمل بالكامل ✅ — `http://localhost:3000` — شاشة الدخول/التسجيل/الاسترجاع تعمل، صفر أخطاء TypeScript، صفر أخطاء runtime.

**العائق الوحيد:** الـ DNS لـ Aiven يرجع NXDOMAIN (المشروع اتقفل/اتحذف). التطبيق شغال على in-memory حالياً → البيانات مؤقتة. **محتاج Service URI جديد من المستخدم** (§7.1) — بعده كل شيء يبقى دائم.

**أول 3 خطوات عند الاستلام:**
1. اقرأ §7 (المشاكل المفتوحة) و §4 (النظام المصادقي)
2. أنشئ Git repo + `.gitignore` (§7.3) — **قبل أي تعديل**
3. شغّل `npx tsx scripts/diagnose-ui.ts` للتأكد أن كل شيء سليم، ثم ابدأ بالأوامر

**قاعدة ذهبية:** أي تعديل على `ChatSidebar.tsx` / `ChatWindow.tsx` / `App.tsx` / `PhoneAuthScreen.tsx` → **لازم** `diagnose-ui.ts` بعدها (§9.4).

---

*نهاية ملف التسليم — 21 أكتوبر 2026*

