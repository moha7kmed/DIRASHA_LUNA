/**
 * Dirasha E2EE — encrypted media/attachments (pure module, no DOM/storage deps).
 *
 * Threat model: attachment METADATA is server-visible, so it must NEVER ride
 * on the upload. Only the encrypted BLOB (ciphertext || 16B Poly1305 tag) is
 * uploaded as application/octet-stream; every decryptable fact (key, iv,
 * mime, name, size, sha256, attId) lives inside the payload object, which the
 * integration layer embeds INSIDE the encrypted message envelope later.
 *
 * Scheme (E2EE-SPEC.md media module):
 *   media key  = 32 random bytes (per attachment, never reused)
 *   encKey     = HKDF-SHA256(ikm = media key, salt = zeros(32),
 *                            info = 'DirashaMedia-v1', 32 bytes)
 *   blob       = ChaCha20-Poly1305(encKey, random 12B iv,
 *                            AAD = UTF8(`DirashaMedia-v1|${attId}`))
 *   attId      = crypto.randomUUID() (bound into the AAD)
 *   sha256     = base64(sha256(plaintext)) — integrity beyond the AEAD tag so
 *                corruption is detectable even before decryption is attempted.
 *
 * Message payload container:
 *   { kind: 'dirasha-msg-v1', text: string, files: AttachmentPayload[] }
 * serialized by buildEncryptedPayload() → passed to engine.encryptMessage().
 * parseEncryptedPayload() is the inverse; any non-conforming plaintext falls
 * back to `{ text: plaintext, files: [] }` (back-compat with pre-E2EE msgs).
 *
 * Runs identically in tests, web workers and the main thread: imports only
 * src/lib/e2ee/crypto.ts + @noble/hashes, uses globalThis.crypto for UUIDs.
 */

import { hkdf } from '@noble/hashes/hkdf';
import { sha256 } from '@noble/hashes/sha256';

import {
  aeadOpen,
  aeadSeal,
  b64decode,
  b64encode,
  randomBytes,
  utf8Encode,
} from './crypto.ts';

/* ══ Constants ══ */

/** HKDF info string for attachment encryption keys. */
export const MEDIA_INFO = 'DirashaMedia-v1';
/** `kind` discriminator of the serialized message payload. */
export const MEDIA_MSG_KIND = 'dirasha-msg-v1';
/** Media key length (bytes). */
export const MEDIA_KEY_BYTES = 32;
/** AEAD nonce length (bytes). */
export const MEDIA_IV_BYTES = 12;
/** SHA-256 digest length (bytes). */
export const MEDIA_SHA256_BYTES = 32;
/** HKDF salt: 32 zero bytes (fixed per spec). */
const MEDIA_SALT = new Uint8Array(32);

/* ══ Errors ══ */

/**
 * Integrity/verification failure for encrypted media. Same contract as the
 * engine's TamperedError (name = 'TamperedError'); defined locally because
 * this module must not depend on types.ts (worker/test portability).
 */
export class TamperedError extends Error {
  constructor(message = 'attachment failed integrity verification') {
    super(message);
    this.name = 'TamperedError';
  }
}

/* ══ Types ══ */

/**
 * Everything needed to decrypt an attachment. Serialized (JSON) inside the
 * encrypted message envelope — never sent as upload metadata.
 */
export interface AttachmentPayload {
  /** Random UUID, bound into the AEAD AAD. */
  attId: string;
  /** Media key, base64 (32 bytes). */
  key: string;
  /** ChaCha20-Poly1305 nonce, base64 (12 bytes). */
  iv: string;
  /** Original MIME type of the plaintext file. */
  mime: string;
  /** Original file name. */
  name: string;
  /** Plaintext size in bytes. */
  size: number;
  /** base64 of SHA-256 over the plaintext bytes. */
  sha256: string;
}

/** Result of {@link encryptAttachment}: upload blob + payload for the envelope. */
export interface EncryptedAttachment {
  /** ciphertext || 16B tag — upload as application/octet-stream. */
  blob: Uint8Array;
  /** Metadata to embed inside the encrypted message envelope. */
  payload: AttachmentPayload;
}

/** Result of {@link decryptAttachment}. */
export interface DecryptedAttachment {
  bytes: Uint8Array;
  mime: string;
  name: string;
}

/** Parsed message payload (what buildEncryptedPayload serializes). */
export interface EncryptedMessagePayload {
  text: string;
  files: AttachmentPayload[];
}

/* ══ Internal helpers ══ */

/** Random UUID (globalThis.crypto.randomUUID with a randomBytes fallback). */
function randomUUID(): string {
  const c = (globalThis as any).crypto;
  if (c && typeof c.randomUUID === 'function') return c.randomUUID();
  const b = randomBytes(16);
  b[6] = (b[6] & 0x0f) | 0x40; // version 4
  b[8] = (b[8] & 0x3f) | 0x80; // variant 10
  const hex = Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('');
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

/**
 * Derive the ChaCha20-Poly1305 key from the per-attachment media key.
 * encKey = HKDF-SHA256(ikm = key, salt = zeros(32), info = 'DirashaMedia-v1', 32B).
 */
function deriveMediaEncKey(mediaKey: Uint8Array): Uint8Array {
  return hkdf(sha256, mediaKey, MEDIA_SALT, utf8Encode(MEDIA_INFO), MEDIA_KEY_BYTES);
}

/** AAD binds the domain string to the specific attachment id. */
function mediaAad(attId: string): Uint8Array {
  return utf8Encode(`${MEDIA_INFO}|${attId}`);
}

/** Constant-time equality of two byte strings (equal length assumed checked). */
function timingSafeEqual(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}

/** b64-decode a payload field, enforcing an exact byte length. */
function decodeField(value: unknown, label: string, expectedBytes: number): Uint8Array {
  if (typeof value !== 'string' || value.length === 0) {
    throw new TamperedError(`attachment payload ${label} is missing or malformed`);
  }
  let decoded: Uint8Array;
  try {
    decoded = b64decode(value);
  } catch {
    throw new TamperedError(`attachment payload ${label} is not valid base64`);
  }
  if (decoded.length !== expectedBytes) {
    throw new TamperedError(`attachment payload ${label} has wrong length`);
  }
  return decoded;
}

/** Validate a parsed JSON object as an AttachmentPayload (b64 lengths included). */
function parseAttachmentPayload(raw: unknown): AttachmentPayload {
  if (typeof raw !== 'object' || raw === null) {
    throw new TamperedError('attachment payload is not an object');
  }
  const p = raw as Record<string, unknown>;
  if (typeof p.attId !== 'string' || p.attId.length === 0) {
    throw new TamperedError('attachment payload attId is missing or malformed');
  }
  decodeField(p.key, 'key', MEDIA_KEY_BYTES);
  decodeField(p.iv, 'iv', MEDIA_IV_BYTES);
  decodeField(p.sha256, 'sha256', MEDIA_SHA256_BYTES);
  if (typeof p.mime !== 'string') throw new TamperedError('attachment payload mime is malformed');
  if (typeof p.name !== 'string') throw new TamperedError('attachment payload name is malformed');
  if (typeof p.size !== 'number' || !Number.isInteger(p.size) || p.size < 0) {
    throw new TamperedError('attachment payload size is malformed');
  }
  return p as unknown as AttachmentPayload;
}

/* ══ Public API — attachments ══ */

/**
 * Encrypt one attachment. Never touches the network and never exposes
 * plaintext metadata: only `blob` is safe to upload (application/octet-stream),
 * `payload` must travel inside the encrypted message envelope.
 */
export function encryptAttachment(bytes: Uint8Array, mime: string, name: string): EncryptedAttachment {
  const attId = randomUUID();
  const mediaKey = randomBytes(MEDIA_KEY_BYTES);
  const encKey = deriveMediaEncKey(mediaKey);
  const iv = randomBytes(MEDIA_IV_BYTES);
  const blob = aeadSeal(encKey, iv, bytes, mediaAad(attId));
  const digest = sha256(bytes);
  return {
    blob,
    payload: {
      attId,
      key: b64encode(mediaKey),
      iv: b64encode(iv),
      mime,
      name,
      size: bytes.length,
      sha256: b64encode(digest),
    },
  };
}

/**
 * Decrypt one attachment. Verifies the AEAD tag (which also authenticates the
 * attId via the AAD), then the plaintext SHA-256 and declared size.
 * Any mismatch → {@link TamperedError}.
 */
export function decryptAttachment(payload: AttachmentPayload, encryptedBytes: Uint8Array): DecryptedAttachment {
  // Re-validate defensively: payloads arrive from the wire inside envelopes.
  const p = parseAttachmentPayload(payload);
  const mediaKey = decodeField(p.key, 'key', MEDIA_KEY_BYTES);
  const iv = decodeField(p.iv, 'iv', MEDIA_IV_BYTES);
  const expectedDigest = decodeField(p.sha256, 'sha256', MEDIA_SHA256_BYTES);

  let bytes: Uint8Array;
  try {
    bytes = aeadOpen(deriveMediaEncKey(mediaKey), iv, encryptedBytes, mediaAad(p.attId));
  } catch {
    // Wrong key, wrong attId/AAD, corrupted or truncated ciphertext+tag.
    throw new TamperedError('attachment AEAD verification failed');
  }

  if (bytes.length !== p.size) {
    throw new TamperedError('attachment decrypted size mismatch');
  }
  if (!timingSafeEqual(sha256(bytes), expectedDigest)) {
    throw new TamperedError('attachment sha256 mismatch');
  }

  return { bytes, mime: p.mime, name: p.name };
}

/**
 * Skip-guard for the encrypt-at-source media flow (F1/P0 fix): TRUE when an
 * attachment was ALREADY encrypted and uploaded by the composer (ChatWindow
 * pre-upload sites). Such attachments are opaque 'enc.bin' blobs carrying
 * `meta.e2ee === true`; the send wrap must NOT re-encrypt / re-upload them —
 * their decryption payload (carried in-memory on `meta.e2eePayload`, stripped
 * before the wire) passes straight through to buildEncryptedPayload.
 * Pure shape check — no crypto, safe on any wire object.
 */
export function isAlreadyEncryptedAttachment(att: unknown): boolean {
  if (typeof att !== 'object' || att === null) return false;
  const meta = (att as { meta?: unknown }).meta;
  return typeof meta === 'object' && meta !== null && (meta as { e2ee?: unknown }).e2ee === true;
}

/* ══ Public API — message payload container ══ */

/**
 * Serialize a text + attachments message into the string passed to
 * engine.encryptMessage(). `text` may be '' (attachment-only message);
 * `files` may be [] (text-only). Pure JSON — the engine treats it as opaque
 * plaintext, so the payload metadata is only ever visible after E2EE decrypt.
 */
export function buildEncryptedPayload(text: string, files: AttachmentPayload[]): string {
  return JSON.stringify({ kind: MEDIA_MSG_KIND, text, files });
}

/**
 * Inverse of {@link buildEncryptedPayload}. A plaintext that is not our
 * container (JSON parse failure, missing/foreign `kind`) is treated as pure
 * legacy text → `{ text, files: [] }` (back-compat). A plaintext that CLAIMS
 * our kind but is structurally invalid is tampering → {@link TamperedError}.
 */
export function parseEncryptedPayload(plaintext: string): EncryptedMessagePayload {
  let raw: unknown;
  try {
    raw = JSON.parse(plaintext);
  } catch {
    return { text: plaintext, files: [] };
  }
  if (typeof raw !== 'object' || raw === null) return { text: plaintext, files: [] };
  const obj = raw as Record<string, unknown>;
  if (obj.kind !== MEDIA_MSG_KIND) return { text: plaintext, files: [] };

  // Claims our kind — from here on, malformed shape is a tamper signal.
  if (typeof obj.text !== 'string') throw new TamperedError('payload text is missing or malformed');
  if (!Array.isArray(obj.files)) throw new TamperedError('payload files is missing or malformed');
  return { text: obj.text, files: obj.files.map(parseAttachmentPayload) };
}
