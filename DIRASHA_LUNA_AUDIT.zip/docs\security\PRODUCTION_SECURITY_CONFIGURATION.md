# دليل الإعداد الإنتاجي الآمن — ديراشة (PRODUCTION SECURITY CONFIGURATION)

> كل متغير إنتاجي: الغرض + التنسيق + خطوات الضبط + التحقق. بلا قيم أسرار.

## متغيرات البيئة الإلزامية (الإقلاع يرفض بدونها — fail-fast)

| المتغير | الغرض | التنسيق |
|---|---|---|
| DATABASE_URL | اتصال PostgreSQL | postgres://user:pass@host:port/db |
| JWT_SECRET | توقيع الجلسات | ≥32 حرفًا عشوائيًا |
| AUTH_PEPPER | فلفل كلمات السر | ≥32 حرفًا (خارج قواعد البيانات) |
| COOKIE_SECRET | توقيع الكوكيز | ≥32 حرفًا |
| STORAGE_MASTER_KEY | تشفير credentials_encrypted | ≥32 حرفًا |
| VAPID_PUBLIC_KEY / VAPID_PRIVATE_KEY | إشعارات الضغط | مفاتيح WebPush |

## متغيرات اختيارية موثقة

| المتغير | الغرض | غيابه |
|---|---|---|
| PG_CA_CERT | base64(PEM) لـCA مزود القاعدة → **تحقق كامل chain+hostname** | TLS مشفر + مرساة TOFU مثبتة (mode=pinned-leaf) |
| PG_DB_CERT_PEM | base64(PEM) لسلسلة شهادة المزود الملتقطة (مرساة TOFU) | يتحول unverified |
| PG_REQUIRE_DB_TLS | 1 = رفض الإقلاع بغيب CA | التحذير فقط |
| KT_SIGNING_KEY | base64 seed Ed25519 لتوقيع شفافية المفاتيح | وضع unverified (تحذير) |
| ADMIN_USERNAMES | صلاحيات الإشراف | — |
| GDRIVE_CLIENT_ID/SECRET | مزود التخزين | — |

## خطوات تفعيل تحقق هوية قاعدة البيانات الكامل (PG_CA_CERT)

1. لوحة Aiven → Service Overview → تنزيل CA certificate (ca.pem).
2. تحويله base64: في Git Bash — `base64 -w0 ca.pem`.
3. Render → Environment → إضافة `PG_CA_CERT` = القيمة → Save (إعادة تشغيل).
4. التحقق: سجل الإقلاع يظهر `[DB-TLS] mode=verified` — و**مجس سالبة**: قيمة فاسدة → رفض اتصال (لا استثناءات مؤقتة).

## التحقق من الإقلاع (السجل المتوقع)

```
[Boot Config] Production configuration checks PASSED for: JWT_SECRET, AUTH_PEPPER, COOKIE_SECRET, STORAGE_MASTER_KEY, DATABASE_URL, VAPID_PUBLIC_KEY + VAPID_PRIVATE_KEY, KT_SIGNING_KEY.
[DB-TLS] mode=verified (CA pinned, full chain + hostname verification ON)
[KT] witness signing key loaded (verified mode).
```

## التجديد والدوران
- PG_CA_CERT: عند تدوير شهادة المزود → حدّث القيمة → أعد التشغيل.
- KT_SIGNING_KEY: عند التدوير → حدّث → شفافية المفاتيح توقع بلقطة جديدة.
- مفاتيح E2EE: **لا تُدار من البيئة إطلاقًا** — في أجهزة المستخدمين (الخزنة).
