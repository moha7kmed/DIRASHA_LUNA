# DATABASE SECURITY AUDIT — تدقيق أمني لقاعدة بيانات Dirasha

> تاريخ التدقيق: 2026-11-17 — تدقيق قراءة فقط.
> المصدر الوحيد للحقيقة: `src/server/database.ts` (5565 سطر) — كل بند مصحوب بـ file:line + مقتطف + تصنيف.

---

## 1) ملخص تنفيذي

| # | الخطورة | النتيجة | الموقع | التصنيف |
|---|---------|---------|--------|---------|
| D1 | **MEDIUM** | **لا يوجد Row-Level Security إطلاقاً**: صفر استخدام لـ `ROW LEVEL SECURITY` أو `CREATE POLICY` في المشروع كله (grep = 0 نتائج). العزل على مستوى التطبيق فقط (شرط WHERE / JOIN / فحص عضوية في routes). خطأ واحد في استعلام جديد = تسريب عابر للمستخدمين | المشروع كله | VERIFIED |
| D2 | **MEDIUM** | اتصال PostgreSQL بـ `ssl: { rejectUnauthorized: false }` عند وجود sslmode=require أو نطاقات Supabase/Aiven/Neon — TLS مفروض لكن **بدون تحقق من الشهادة** (MITM ممكن نظرياً بين الخادم والـ managed DB) | database.ts:172-187 | VERIFIED (قرار موثق داخل الكود لتجاوز شهادات الـ poolers) |
| D3 | **LOW** | مفتاح تشفير snapshot المحلي مشتق من `SNAPSHOT_ENCRYPTION_KEY || AUTH_PEPPER:JWT_SECRET:dirasha-local-dev` — fallback ضعيف إذا لم تضبط المتغيرات | database.ts:28-32 | VERIFIED |
| D4 | **LOW** | مفتاح تشفير أسرار التخزين يعود تلقائياً إلى `COOKIE_SECRET` إذا غاب `STORAGE_MASTER_KEY` — مشاركة مادة المفتاح بين غرضين | services/storage.ts:100-105 | VERIFIED |
| D5 | **LOW** | اتصال PG غير صحي → الوضع يعمل على in-memory store مع snapshot محلي مشفر؛ توفر أعلى من الاتساق (فقدان بيانات ما بين snapshot و PG عند فشل مطلق) | database.ts:1859-1891 | VERIFIED (قرار معماري موثق) |
| D6 | **POSITIVE** | refresh tokens لا تُخزن أبداً كنص صريح: `refresh_token_hash VARCHAR(255) UNIQUE` | database.ts:1978 | VERIFIED |
| D7 | **POSITIVE** | أسرار BYO-Cloud مشفرة AES-256-GCM قبل الـ DB (`credentials_encrypted TEXT`) | database.ts:1941 + services/storage.ts:107-125 | VERIFIED |
| D8 | **POSITIVE** | snapshot الملف المحلي مشفر AES-256-GCM (ENC1:) ولا يُحذف أبداً كنسخة احتياطية | database.ts:21-50, :1478 | VERIFIED |
| D9 | **POSITIVE** | كل MIGRATIONS والـ bootstrap عبر SQL معاملات؛ لا حقن من migrations | database.ts:1115-1386, :1893-2153 | VERIFIED |
| D10 | **INFO** | نسخ احتياطي للـ PostgreSQL **غير موجود في المشروع** (لا pg_dump/جدولة backup) — الوضع الوحيد: snapshot محلي مشفر للذاكرة + أي backup خارجي لدى مزود الـ managed DB | grep pg_dump = 0 | VERIFIED (NOT IMPLEMENTED كنسخ مؤسسي) |

---

## 2) محرك التشغيل الفعلي: PostgreSQL + snapshot مشفر + memory fallback

- `DATABASE_URL` (env) هو مصدر الاتصال الوحيد؛ يُقَص من علامات اقتباس زائدة (database.ts:163-170) (VERIFIED).
- عند الفشل الأولي: `[Database] PostgreSQL connection unreachable at startup (Running on in-memory storage engine)` ثم health probe يعيد المحاولة (database.ts:1877-1882) (VERIFIED).
- keep-alive كل 4 دقائق + health probe يقلب `isPostgresHealthy` عند انقطاع الاتصال (database.ts:155-161, :577-588, :977-981) (VERIFIED).
- عند العودة: `importSnapshotToPostgres` + `hydrateChatDomainFromPg` (database.ts:1872-1873).
- **D5**: هذا hybrid يعني فترة (مفردة) يمكن أن تكون فيها الرسائل في الذاكرة فقط — مقبول مع encrypted snapshot، لكن يجب توثيقه في خطة الاسترجاع.

## 3) أمن الاتصال

```ts
// database.ts:177-181
const needsTls = /sslmode=require|supabase|pooler|aivencloud|neon\.tech/i.test(connStr);
const sanitized = connStr.replace(/[?&]sslmode=[^&]*/i, ...);
return new pg.Pool({
  connectionString: sanitized,
  ssl: needsTls ? { rejectUnauthorized: false } : undefined,
```
- TLS يُفرض للـ managed providers المذكورة فقط؛ **أي DATABASE_URL آخر بلا sslmode يفتح اتصالاً غير مشفر** إذا كان مزود الداتابيس خارج قائمة الـ regex ولم يحدد sslmode في الـ URL — PARTIALLY VERIFIED (يعتمد على نطاق النشر).
- `rejectUnauthorized: false` = يقبل أي شهادة → حماية من الاستماع السلبي، لا من MITM النشط — D2 (VERIFIED).
- pool: max 10, connectionTimeout 8s, idleTimeout 30s (database.ts:182-186) — VERIFIED.

## 4) من يحمل بيانات الاعتماد؟ (env فقط — لا أسرار في الكود)

| السر | المتغير env | موقع الاستخدام | سلوك الغياب في الإنتاج |
|---|---|---|---|
| DB | `DATABASE_URL` | database.ts:163 | يعمل على in-memory (توفر بلا دوام) |
| JWT | `JWT_SECRET` | services/auth.ts:19-23 | **FATAL throw** (VERIFIED) |
| Cookies | `COOKIE_SECRET` | server.ts:228-232 | **FATAL throw** (VERIFIED) |
| BYO-Cloud storage | `STORAGE_MASTER_KEY` (fallback COOKIE_SECRET) | services/storage.ts:100-104 | FATAL throw إذا كان الاثنان فارغين في الإنتاج (VERIFIED) — D4 للـ fallback |
| Managed fallback bucket | `S3_ENDPOINT/BUCKET/ACCESS_KEY_ID/SECRET_ACCESS_KEY/PUBLIC_BASE_URL` | services/storage.ts:131-147 | تعطيل الميزة (بلا أخطاء صاخبة إلا سجل boot) |
| VAPID | `VAPID_PUBLIC_KEY/PRIVATE_KEY` | services/push.ts:17-19 | **FATAL throw** في الإنتاج؛ وإلا ephemeral keys تُبطل كل الاشتراكات بعد restart |
| KT witness | `KT_SIGNING_KEY` | services/key_transparency.ts:313-336 | وضع UNVERIFIED صاخب (تواقيع فارغة) |
| إدارة | `ADMIN_USERNAMES`, `ADMIN_WIPE_SECRET`, `ALLOWED_ORIGINS`, `ALLOWED_FRAME_ANCESTORS`, `PASSKEYS_RP_ID` | server.ts:374, :3690; kt.ts:53; ws_server.ts:114; passkeys.ts:78 | بدون ADMIN_USERNAMES لا أحد admin (deny-by-default) — VERIFIED |
| Failsafe snapshot | `SNAPSHOT_ENCRYPTION_KEY` (fallback AUTH_PEPPER:JWT_SECRET) | database.ts:28-32 | مشتق من أسرار أخرى — D3 |

grep تأكيد: لا connection string ولا secret مضمن في الملفات (gitleaks موجود في CI — .github/workflows/verify.yml:36-46) — VERIFIED.

## 5) المخطط الكامل — base schema (bootstrapPostgresSchema، database.ts:1893-2153)

كل الجداول `CREATE TABLE IF NOT EXISTS` داخل سلسلة واحدة؛ PK/FK/CHECKs كما يلي:

| الجدول | المفتاح | الأعمدة الأمنية الهامة | ملاحظات |
|---|---|---|---|
| users (:1898) | id VARCHAR(128) PK | phone_number UNIQUE (ثم DROP NOT NULL :1950)، username UNIQUE، role، is_banned/banned_until/ban_reason، muted_until/...، password_hash، pin_hash، device_key_hash VARCHAR(128)، totp_secret (encrypted via encryptSnapshot)، totp_backup_hashes (hashed)، reset_token_hash+expires، login_attempts، locked_until | الأسرار hashed/encrypted — VERIFIED |
| user_storage_accounts (:1934) | user_id PK FK→users CASCADE | provider/endpoint/bucket/public_base_url، **credentials_encrypted TEXT** | D7 |
| user_profiles (:1962) / user_settings (:1970) | user_id PK FK CASCADE | settings JSONB | JSONB حر (بلا schema) |
| user_sessions (:1975) | id VARCHAR(128) PK | **refresh_token_hash** UNIQUE، ip_address VARCHAR(45)، user_agent، is_revoked، expires_at، last_active (v6) | D6 — لا نص صريح للتوكنات |
| auth_logs (:1990) + v6 (:1210) | id PK | user_id, action, ip VARCHAR(64), user_agent, metadata JSONB | audit trail للـ security alerts |
| chats (:2001) | id PK | type ('one-to-one'|'group'|'channel')، disappearing_messages_timer | — |
| chat_members (:2011) | PK (chat_id,user_id) + FKs CASCADE | role VARCHAR(16) default 'member' | مصدر حقيقة العضوية لكل الترخيص |
| messages (:2020) | id PK FK chats CASCADE | sender_id FK users، content TEXT، deleted_at، client_message_id UNIQUE، expires_at، poll JSONB (v3)، deleted_for JSONB (v1)، scheduled_at/broadcast_at (v5) | — |
| attachments (:2035) | id PK FK messages CASCADE | url TEXT | URLs فقط — لا بيانات وسائط في DB |
| message_reactions (:2045) | PK (message,user,emoji) | — | — |
| message_reads (:2053) | id PK + UNIQUE (message_id,user_id) | status | — |
| message_pins (:2063) / message_stars (:2071) | PKs مركبة | — | — |
| system_api_keys (:2078) | id PK، key_value UNIQUE | added_by | النص شبه الصريح في DB (مفاتيح Gemini) — مقنّع جزئياً في الواجهة فقط (F7 في مصفوفة API) |
| statuses (:2092) | id PK FK users CASCADE | expires_at NOT NULL، settings JSONB، is_archived | — |
| reports (:2105) | report_id PK | reporter FK SET NULL، target FK CASCADE، category، status | — |
| moderation_audit_logs (:2118) | id PK | event_type، actor/target، metadata JSONB | — |
| contacts (:2128) / blocks (:2135) | PK مركبة + FKs CASCADE | — | — |
| push_subscriptions (:2142) | endpoint PK | user_id، subscription JSONB | بلا FK على user_id (يُحذف يدوياً عبر 410/404/401/403/400 — push.ts:107-111) — INFO |

فهارس إضافية عبر MIGRATIONS v1 (:1120-1141): hot-path indexes للرسائل/العضوية/الجلسات — أداء لا أمان.

## 6) الهجرات (MIGRATIONS) v1..v11 بالكامل (database.ts:1115-1386)

تشغيلها: `runPgMigrations` عبر جدول `schema_migrations (version INT PRIMARY KEY)` مع تسجيل applied (database.ts:1403-1411) — idempotent وآمن (VERIFIED). محاولة `CREATE EXTENSION pg_trgm` + GIN index best-effort قبلها (:1395-1401).

| v | ماذا تنشئ/تغير | أثر أمني |
|---|---|---|
| v1 (:1117) | ~21 فهرس hot-path (messages/chat_members/contacts/blocks/sessions/reports/...) + أعمدة chats.group_settings/description و messages.deleted_for | deleted_for أساس خصوصية "حذف لي فقط" |
| v2 (:1150) | `idx_messages_content_prefix ON messages (left(content,32))` | بحث بدون extension (بديل trgm) |
| v3 (:1160) | messages.poll JSONB + attachments.meta JSONB + partial index | استطلاعات |
| v4 (:1173) | partial index للقنوات `WHERE type='channel'` | بلا جداول جديدة |
| v5 (:1184) | messages.scheduled_at/broadcast_at + partial indexes | الرسائل المجدولة غير المرسلة مخفية عبر predicate `(broadcast_at IS NOT NULL OR scheduled_at IS NULL)` في كل الاستعلامات (مثال database.ts:5307, :5348) — VERIFIED |
| v6 (:1200) | user_sessions.last_active + **جدول auth_logs** + index | أساس تنبيهات الدخول/الفشل |
| v7 (:1223) | **e2ee_registrations** (user_id PK FK→users CASCADE؛ مفاتيح عامة فقط) + **e2ee_one_time_prekeys** (UNIQUE(user_id,key_id)، consumed/consumed_at) + partial index على غير المستهلكة | الخادم دليل مفاتيح عامة فقط — لا أي عمود لمفتاح خاص (VERIFIED) |
| v8 (:1255) | **e2ee_device_registrations** (PK (user_id,device_id)) + **e2ee_device_one_time_prekeys** (UNIQUE (user_id,device_id,key_id)) + partial index | multi-device؛ FK CASCADE مع المستخدم |
| v9 (:1293) | **webauthn_credentials** (credential_id UNIQUE، public_key، counter) + index user | لا علاقة بمفاتيح الرسائل (موثق داخل الهجرة) |
| v10 (:1317) | أعمدة pq_prekey_pub / pq_prekey_signature (nullable) على e2ee_device_registrations | PQXDH — الخادم يفحص الأطوال فقط |
| v11 (:1334) | **kt_log** (seq BIGSERIAL PK، بلا FK عن قصد — السجل append-only لا يُمس مع حذف المستخدم)، **kt_snapshots** (tree_version PK، root_hash، signature)، **kt_mismatch_reports** + فهارس | Key Transparency؛ الحذف المتعمد للمفاتيح سينكشف عبر consistency proofs (VERIFIED تصميم) |

## 7) Row-Level Security: الإجابة الصريحة

**لا. لا يوجد أي RLS.** الفحص:

```
grep -inE "ROW LEVEL SECURITY|CREATE POLICY" src/server/database.ts  →  صفر نتائج (exit 1)
grep -rn نفس الأمر على src/server كاملة                              →  صفر نتائج
```

كل الاتصالات تمر عبر **تطبيق واحد بحساب DB مالك كامل** (DATABASE_URL واحد، pool مشترك). هذا يعني:

- الحدود بين المستخدمين تُفرض **حصراً في طبقة التطبيق**: فحوص requireAuth + عضوية chat_members + شروط `user_id = $1` في SQL.
- أي استعلام مستقبلي ينسى شرط `user_id`/العضوية يسرب بيانات فوراً (لا شبكة أمان من الـ DB).
- **التصنيف**: VERIFIED — **الخطورة MEDIUM** (مقبول لمنصة بنمط SaaS موحّد الحساب، لكنه نقطة عمى مقارنة بمعايير الدفاع المتعدد الطبقات؛ التوصية: RLS على messages/message_reads/attachments/e2ee_* بسياسة `user_id = current_setting('app.user_id')` أو على الأقل حساب DB بأقل صلاحية بدون DDL في الإنتاج).

## 8) عزل بيانات المستخدم — أين يُفرض فعلاً (أمثلة مُتحقق منها)

| المسار | الآلية | الدليل |
|---|---|---|
| بحث الرسائل العام | SQL JOIN عضوية | `JOIN chat_members cm ON cm.chat_id = m.chat_id AND cm.user_id = $1` — database.ts:5343-5345 |
| بحث داخل محادثة | شرط chat_id + فحص عضوية في route | database.ts:5303-5312 + server.ts:2419-2421 |
| الرسائل المميزة | `WHERE s.user_id = $1` | database.ts:5120-5121 |
| deleted_for | `NOT (deleted_for @> $2::jsonb)` | database.ts:5307, :5348, :5428 |
| الجلسات | user_id scope في كل الاستعلامات (getUserSessions/revokeOtherUserSessions) | database.ts (واجهة sessions) + auth.ts:242-259 |
| e2ee OPKs | كل UPDATE/SELECT بـ `user_id = $1` (ولكل جهاز device_id) | e2ee.ts:175-179, :451-480 |
| status viewers/delete | ownership في route قبل SQL | status.ts:178-188, :260-267 |
| getMessagesForChat | **بلا فلتر مستخدم** — الاعتماد الكامل على فحص العضوية في كل route مستدعٍ | server.ts:2326-2343 (والبقية) — **هشاشة النمط**: الأمان مشروط بذكر الفحص في كل route (D1) |

الذاكرة fallback تكرر نفس الفحوص (مثال database.ts:5315-5325 فحص members في وضع الذاكرة) — VERIFIED اتساق النمط.

## 9) التشفير في السكون (at rest)

1. **Snapshot المحلي** (وضع الذاكرة): AES-256-GCM، `ENC1:` + iv(12) + tag + ct؛ المفتاح HMAC-SHA256 من `SNAPSHOT_ENCRYPTION_KEY || AUTH_PEPPER:JWT_SECRET:dirasha-local-dev` (database.ts:21-50). عند فشل فك التشفير: يبدأ متجراً فارغاً (لا يفشل الإقلاع) — database.ts:444+ و logs اختبار npm test. D3: الـ fallback يربط مفتاح snapshot بأسرار أخرى — تدوير JWT_SECRET يكسر الـ snapshot القديم (PARTIALLY VERIFIED أثر).
2. **totp_secret**: مشفر بنفس encryptSnapshot (authClassic.ts:654, :673) — VERIFIED.
3. **user_storage_accounts.credentials_encrypted**: AES-256-GCM بمفتاح SHA-256 من `dirasha-storage:` + `STORAGE_MASTER_KEY || COOKIE_SECRET` (services/storage.ts:100-125) — D4.
4. **refresh_token_hash**: hash فقط (schema + createSession) — VERIFIED.
5. **kt_log**: بيانات عامة (مفاتيح عامة + commitment) — لا حاجة تشفير.
6. **system_api_keys.key_value**: نص في DB — الواجهة تقنعه جزئياً فقط (apiKeys.ts:17-20) — الخطورة LOW (admin-only).

## 10) وضع النسخ الاحتياطي (Backup posture)

- **NOT IMPLEMENTED** على مستوى المشروع: لا pg_dump، لا جدولة، لا snapshot PG→S3 (grep: صفر).
- الموجود فعلاً:
  1. snapshot ملفي مشفر للذاكرة يُكتب دورياً ويبقى **لا يُحذف أبداً** (`// The snapshot file is NEVER deleted — it stays as a backup.` — database.ts:1478) — يغطي وضع الذاكرة فقط.
  2. `backups/` directory يُقرأ عند bootstrap الذاكرة إن وجد (database.ts:444-459).
  3. أي دوام حقيقي بعد ذلك مسؤولية مزود الـ managed PostgreSQL (خارج المشروع — غير قابل للتدقيق هنا) — UNVERIFIED.
- **التوصية**: جدولة pg_dump مشفرة أو PITR مُوثق + اختبار استرجاع دوري.

## 11) نقاط إعادة الضبط والتدمير

- `POST /api/admin/reset-database` → `db.resetAndWipeAllUsersAndData()` (database.ts:2160، server.ts:3673-3706): يمسح كل المستخدمين والبيانات. الحارس: Bearer role admin/developer أو `x-admin-secret` = `ADMIN_WIPE_SECRET`. **بلا rate limit مخصص وبمقارنة غير timing-safe** (server.ts:3691) — يوصى بفرض NODE_ENV check + تأكيد ثانٍ.
- FK CASCADE على كل الجداول الفرعية ⇒ الحذف النظيف تلقائي (users→sessions/messages/e2ee_*/webauthn/storage) — VERIFIED.
- الاستثناء: `kt_log` بلا FK عن قصد (v11 — السجل التاريخي لا يمس) و `push_subscriptions.user_id` بلا FK (تنظيف حسب response codes) — VERIFIED.

## 12) الخلاصة

| المحور | الحالة |
|---|---|
| الهجرات | آمنة idempotent وموثقة بنيوياً — VERIFIED |
| الأسرار في DB | hashed/encrypted ما يلزم — VERIFIED (استثناء system_api_keys نص) |
| RLS | **غير موجود** — العزل application-level فقط — D1 MEDIUM |
| TLS للـ DB | مفروض مع rejectUnauthorized:false — D2 MEDIUM (خفض ممكن: شهادة CA موثوقة) |
| النسخ الاحتياطي | NOT IMPLEMENTED خارج مزود DB — D10 |
| الحقن (SQLi) | صفر سطح فعلي (كل المعاملات parameterized) — VERIFIED |
