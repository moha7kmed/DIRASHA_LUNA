/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * scan-secrets.cjs — lightweight secret scanner over git-tracked files.
 *
 * This is the local/fast complement to the gitleaks CI step
 * (gitleaks/gitleaks-action@v2 in .github/workflows/verify.yml). CI remains the
 * authoritative gate; this script lets developers run the same class of checks
 * locally via `npm run scan-secrets` without needing docker.
 *
 * Scans ONLY files listed by `git ls-files` (i.e. tracked files) — so
 * node_modules/, dist/ and other gitignored paths are never read.
 *
 * DIR-NEW-08 (external audit): text-like formats include PEM/KEY/CRT/CER/PUB
 * and every `.env*` basename, and the PASS line reports HONEST coverage —
 * how many files were actually content-scanned and how many were skipped
 * (declared exact-path fixtures vs non-text), never the raw listed count.
 *
 * Detection classes:
 *   1. Known key/token prefixes (AWS AKIA, Slack xox*, GoCardless rnd_,
 *      PEM private key blocks, GitHub/Google/JWT shapes).
 *   2. High-entropy literals assigned to secret-sounding identifiers
 *      (secret=..., api_key: "...", Authorization: Bearer <long token>).
 *
 * Exit codes: 0 = clean, 1 = potential secret found, 2 = tooling error.
 * Any hit fails CI.
 */

'use strict';

const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const REPO_ROOT = path.resolve(__dirname, '..');

// NOTE: the regex literals below are marked `gitleaks:allow` so that the
// gitleaks CI step never flags this scanner's own pattern definitions.
const PATTERNS = [
  {
    id: 'aws-access-key',
    re: /\b(?:AKIA|ASIA)[0-9A-Z]{16}\b/g, // gitleaks:allow
    hint: 'AWS access key id',
  },
  {
    id: 'slack-token',
    re: /\bxox[abprs]-[A-Za-z0-9-]{10,}\b/g, // gitleaks:allow
    hint: 'Slack token',
  },
  {
    id: 'gocardless-rnd',
    re: /\brnd_[A-Za-z0-9]{20,}\b/g, // gitleaks:allow
    hint: 'rnd_ prefixed API secret',
  },
  {
    id: 'github-token',
    re: /\bgh[pousr]_[A-Za-z0-9]{36,}\b/g, // gitleaks:allow
    hint: 'GitHub token',
  },
  {
    id: 'google-api-key',
    re: /\bAIza[0-9A-Za-z_-]{35}\b/g, // gitleaks:allow
    hint: 'Google API key',
  },
  {
    id: 'private-key-block',
    re: /-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP |ENCRYPTED )?PRIVATE KEY( BLOCK)?-----/g, // gitleaks:allow
    hint: 'PEM private key block',
  },
  {
    id: 'jwt-literal',
    re: /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g, // gitleaks:allow
    hint: 'Hardcoded JWT (header.payload.signature)',
  },
  {
    id: 'twilio-sid-secret',
    re: /\bSK[0-9a-fA-F]{32}\b/g, // gitleaks:allow
    hint: 'Possible Twilio-style 32-hex secret',
  },
];

// High-entropy literal bound to a secret-sounding identifier.
const SECRET_IDENTIFIERS = [
  'secret', 'api[_-]?key', 'apikey', 'access[_-]?token', 'auth[_-]?token',
  'refresh[_-]?token', 'private[_-]?key', 'passw(?:or)?d', 'bearer',
  'client[_-]?secret', 'signing[_-]?key', 'encryption[_-]?key', 'pepper',
].join('|'); // gitleaks:allow

const ASSIGNMENT_RE = new RegExp(
  `(${SECRET_IDENTIFIERS})\\s*[:=]\\s*['"]?([A-Za-z0-9+/=_-]{24,})`,
  'gi',
); // gitleaks:allow

const ENTROPY_THRESHOLD = 4.0; // Shannon entropy bits/char for base64-ish blobs
const MIN_ASSIGNMENT_ENTROPY = 3.2;

const BASE64_PLACEHOLDER_RE = /^[A-Za-z0-9+/=_-]+$/;

// Values that look secret-shaped but are obviously not.
const BENIGN_VALUES = new Set([
  'changeme', 'change-me', 'placeholder', 'example', 'sample', 'dummy',
  'todo', 'fixme', 'undefined', 'null', 'true', 'false', 'your-key-here',
]);

// DIR-NEW-08 (external audit): PEM/key material IS text — .pem/.key/.crt/.cer/.pub
// files are content-scanned like any other source file (the old list silently
// skipped them, so a committed private key never reached the detector).
const TEXT_EXTENSIONS = new Set([
  '.ts', '.tsx', '.js', '.cjs', '.mjs', '.jsx', '.json', '.md', '.txt', '.yml',
  '.yaml', '.html', '.css', '.scss', '.sh', '.ps1', '.sql', '.toml', '.xml',
  '.pem', '.key', '.crt', '.cer', '.pub',
  '.gitignore', '.gitattributes', '.prisma', '.graphql',
]);

// DIR-NEW-08: path.extname('.env.example') returns '.example' (not
// '.env.example'), so an extension-list entry can never catch dotfiles with
// a compound suffix. Env files are recognized by BASENAME instead:
// .env, .env.example, .env.production, .env.local, ...
const ENV_FILE_BASENAME_RE = /^\.env(\..+)?$/;

// DIR-NEW-08: exact-path exemptions for REVIEWED test fixtures whose content
// is deliberately a cryptographic key yet is not a real secret. Exact paths
// only — never extension-wide or basename-wide — so any other *.key file is
// still fully scanned. Adding a path here requires a review of that file.
const DECLARED_FIXTURES = new Set([
  'tests/fixtures/test-ca.key',
]);

function listFiles() {
  let gitFiles;
  try {
    gitFiles = execFileSync('git', ['ls-files', '-z'], {
      cwd: REPO_ROOT, maxBuffer: 64 * 1024 * 1024, encoding: 'buffer',
      // A missing/broken repo prints "fatal: ..." on stderr — that is the
      // expected tree-walk fallback trigger, not an operator-visible error.
      stdio: ['ignore', 'pipe', 'ignore'],
    }).toString('utf8').split('\0').filter(Boolean);
  } catch { gitFiles = null; } // no .git — clean ZIP extraction
  if (gitFiles && gitFiles.length > 0) return { files: gitFiles, mode: 'git' };
  const SKIP_DIRS = new Set(['node_modules', 'dist', 'coverage', '.git']);
  const files = [];
  (function walk(dir) {
    let es; try { es = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const e of es) {
      if (e.isDirectory()) { if (!SKIP_DIRS.has(e.name)) walk(path.join(dir, e.name)); }
      else files.push(path.relative(REPO_ROOT, path.join(dir, e.name)).split(path.sep).join('/'));
    }
  })(REPO_ROOT);
  return { files, mode: 'tree' };
}

function shannonEntropy(str) {
  if (!str.length) return 0;
  const counts = new Map();
  for (const ch of str) counts.set(ch, (counts.get(ch) || 0) + 1);
  let entropy = 0;
  for (const count of counts.values()) {
    const p = count / str.length;
    entropy -= p * Math.log2(p);
  }
  return entropy;
}

function isBenign(value) {
  const v = value.toLowerCase();
  if (BENIGN_VALUES.has(v)) return true;
  if (/^(x+|test|tests?|dummy|none|secret|token|key|password)\d*$/.test(v)) return true;
  if (v.includes('example') || v.includes('placeholder') || v.includes('<')) return true;
  // Purely low-cardinality repeats like "aaaa..." or "12345678901234567890".
  if (/^(.)\1{15,}$/.test(value)) return true;
  if (/^0123456789(0123456789)+$/.test(value)) return true;
  return false;
}

function looksLikeText(file) {
  // DIR-NEW-08: env files are matched by basename (see ENV_FILE_BASENAME_RE).
  if (ENV_FILE_BASENAME_RE.test(path.basename(file).toLowerCase())) return true;
  const ext = path.extname(file).toLowerCase();
  if (TEXT_EXTENSIONS.has(ext)) return true;
  if (!ext) return true; // Makefile, LICENSE, Dockerfile, security.txt, ...
  return false;
}

const findings = [];

function record(file, lineNo, ruleId, hint, snippet) {
  findings.push({ file, line: lineNo, rule: ruleId, hint, snippet });
}

function scanContent(file, content) {
  const lines = content.split(/\r?\n/);

  lines.forEach((line, idx) => {
    const lineNo = idx + 1;
    if (line.includes('gitleaks:allow') || line.includes('scan-secrets:allow')) return;

    for (const { id, re, hint } of PATTERNS) {
      re.lastIndex = 0;
      let m;
      while ((m = re.exec(line)) !== null) {
        if (isBenign(m[0])) continue;
        record(file, lineNo, id, hint, m[0].slice(0, 60));
      }
    }

    // High-entropy assignment heuristic.
    ASSIGNMENT_RE.lastIndex = 0;
    let am;
    while ((am = ASSIGNMENT_RE.exec(line)) !== null) {
      const literal = am[2];
      if (!literal || !BASE64_PLACEHOLDER_RE.test(literal)) continue;
      if (isBenign(literal)) continue;
      const entropy = shannonEntropy(literal);
      if (entropy < MIN_ASSIGNMENT_ENTROPY) continue;
      // URL-ish or path-ish values are configuration, not secrets.
      if (/^(?:https?|ws|wss|postgres|redis|mongodb):\/\//i.test(literal)) continue;
      record(file, lineNo, 'high-entropy-assignment',
        `entropy ${entropy.toFixed(2)} bits/char bound to "${am[1]}"`,
        literal.slice(0, 60));
    }
  });
}

function main() {
  let files, mode;
  try {
    const r = listFiles();
    files = r.files; mode = r.mode;
  } catch (err) {
    console.error('[scan-secrets] failed to list files:', err.message);
    process.exit(2);
  }

  // DIR-NEW-08 (external audit): honest coverage accounting. The old PASS line
  // reported the LISTED file count, silently inflating the number of files
  // whose content was actually read. Report scanned vs skipped (and why).
  let scanned = 0;
  let skippedDeclaredFixtures = 0;
  let skippedNonText = 0;

  for (const file of files) {
    if (DECLARED_FIXTURES.has(file)) {
      skippedDeclaredFixtures++;
      continue;
    }
    if (!looksLikeText(file)) {
      skippedNonText++;
      continue;
    }
    let content;
    try {
      content = fs.readFileSync(path.join(REPO_ROOT, file), 'utf8');
    } catch {
      continue; // unreadable / race — skip (vanishingly rare, not counted)
    }
    scanned++;
    scanContent(file, content);
  }

  if (findings.length > 0) {
    console.error(`\n[scan-secrets] FAIL — ${findings.length} potential secret(s) found:\n`);
    for (const f of findings) {
      console.error(`  ${f.file}:${f.line}  [${f.rule}] ${f.hint}`);
      console.error(`    > ${f.snippet}`);
    }
    console.error('\nIf a finding is a deliberate test fixture, mark the line with "gitleaks:allow".');
    process.exit(1);
  }

  console.log(
    `[scan-secrets] PASS — scanned ${scanned} files (skipped: ${skippedDeclaredFixtures} declared-fixture, ` +
    `${skippedNonText} non-text) across ${files.length} listed files (mode: ${mode}).`,
  );
}

main();
