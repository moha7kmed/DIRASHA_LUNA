/**
 * Dirasha E2EE — message padding (Project 6).
 *
 * Hides message-length fingerprints: plaintext is expanded to the nearest
 * size bucket BEFORE encryption, so ciphertext sizes leak only the bucket,
 * not the true length. The padding lives INSIDE the authenticated ciphertext
 * (any tampering breaks the AEAD tag — the padding needs no separate auth).
 *
 * Buckets (bytes, post-padding total including the 4-byte length prefix):
 *   512 / 1024 / 4096 / 16384 / 65536
 * Plaintext larger than the largest bucket gets minimal padding (the length
 * prefix + remainder to the next 16KB step) — documented limitation: sizes
 * above the largest bucket still leak their coarse magnitude, and message
 * TIMING/COUNT are out of scope for padding entirely.
 *
 * Wire integration: the envelope carries `p: 1` when the ciphertext is
 * padded. Legacy envelopes (no `p`) decrypt without unpadding — old clients
 * ignore the extra field; new clients handle both. Deployed atomically.
 */

/** Size buckets in bytes (the total padded length lands on one of these). */
export const PADDING_BUCKETS = [512, 1024, 4096, 16384, 65536] as const;

/** Bytes used to store the true plaintext length (little-endian uint32). */
export const PAD_LENGTH_PREFIX = 4;

/** Envelope flag marking padded ciphertext. */
export const PAD_FLAG = 1;

/**
 * Pad plaintext bytes to the nearest bucket.
 * Layout: [4-byte LE true length][plaintext][zero filler to bucket boundary].
 * If the plaintext (+prefix) already exceeds the largest bucket, the output
 * is extended to the next multiple of 16384 above it (bounded growth).
 */
export function padToBucket(plaintext: Uint8Array): Uint8Array {
  const trueLen = plaintext.length;
  const withPrefix = PAD_LENGTH_PREFIX + trueLen;
  let target = 0;
  for (const b of PADDING_BUCKETS) {
    if (withPrefix <= b) { target = b; break; }
  }
  if (target === 0) {
    // Over the largest bucket: round up to the next 16KB step above it.
    const step = 16384;
    target = Math.ceil(withPrefix / step) * step;
  }
  const out = new Uint8Array(target);
  const view = new DataView(out.buffer);
  view.setUint32(0, trueLen, true); // little-endian
  out.set(plaintext, PAD_LENGTH_PREFIX);
  // filler bytes stay zero — their content is irrelevant, only the size matters
  return out;
}

/**
 * Remove padding after AEAD decryption. Throws on structural inconsistency
 * (a length prefix that contradicts the buffer is treated as tampering —
 * though the AEAD tag already authenticates the whole padded buffer).
 */
export function unpadFromBucket(padded: Uint8Array): Uint8Array {
  if (padded.length < PAD_LENGTH_PREFIX + 1) {
    throw new Error('padding: buffer too short');
  }
  const view = new DataView(padded.buffer, padded.byteOffset, padded.byteLength);
  const trueLen = view.getUint32(0, true);
  if (trueLen > padded.length - PAD_LENGTH_PREFIX) {
    throw new Error('padding: inconsistent length prefix');
  }
  return padded.slice(PAD_LENGTH_PREFIX, PAD_LENGTH_PREFIX + trueLen);
}

/** Whether an envelope flag marks padded ciphertext (defensive: number|undefined). */
export function isPadded(flag: unknown): boolean {
  return flag === PAD_FLAG;
}
