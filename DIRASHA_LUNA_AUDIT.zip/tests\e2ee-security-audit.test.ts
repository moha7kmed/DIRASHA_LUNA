/**
 * E2EE security-audit regression tests (adversarial audit — 2026-11).
 *
 * Covers the two engine fixes applied by the audit:
 *   1. X3DH-bootstrap replay → session-rollback guard (engine.ts decryptEnvelope
 *      + SessionState.bootstrappedEk): replaying a peer's FIRST message (same
 *      ephemeral `ek`) after the session advanced used to rebuild a responder
 *      session deterministically and roll the ratchet chain back, making
 *      previously-consumed chain messages decryptable again. Fails closed now.
 *   2. Rate-limit fail-closed (engine.ts fetchPeerDevices): a 429/5xx from the
 *      bundle endpoint must NOT surface as PeerNotRegisteredError, because the
 *      App send path treats that error as a license to fall back to PLAINTEXT.
 *      Only a definitive 404 may trigger the plaintext fallback.
 *
 * NOTE: tests/e2ee-fuzz.test.ts is owned by the FP agent — do not merge these
 * tests into it. (Their `.concern REGRESSION` test covers the same rollback
 * fix from the harness side and PASSES with the guard applied.)
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';

import { DirashaE2EE } from '../src/lib/e2ee/engine.ts';
import { MemoryKVStore } from '../src/lib/e2ee/store.ts';
import { E2eeError, PeerNotRegisteredError } from '../src/lib/e2ee/types.ts';
import type { KVStore } from '../src/lib/e2ee/types.ts';
import { b64decode } from '../src/lib/e2ee/crypto.ts';

/* ── Mock server (same contract as tests/e2ee-engine.test.ts) ────────────── */

function createMockServer() {
  const regs = new Map<string, Map<string, any>>();
  const respond = (status: number, data: unknown) =>
    new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json' } });

  const fetch = async (url: any, init?: RequestInit): Promise<Response> => {
    const path = String(url).split('?')[0];
    const method = (init?.method ?? 'GET').toUpperCase();
    const body = init?.body ? JSON.parse(String(init.body)) : {};
    const headers = (init?.headers ?? {}) as Record<string, string>;
    const user = String(headers.Authorization ?? '').replace(/^Bearer\s+/, '');

    if (path === '/api/e2ee/register' && method === 'POST') {
      const deviceId = typeof body.deviceId === 'string' && body.deviceId ? body.deviceId : 'default';
      let devices = regs.get(user);
      if (!devices) {
        devices = new Map<string, any>();
        regs.set(user, devices);
      }
      devices.set(deviceId, {
        deviceId,
        identityDhPub: body.identityDhPub,
        identitySigPub: body.identitySigPub,
        signedPrekeyPub: body.signedPrekeyPub,
        prekeySignature: body.prekeySignature,
        opks: (body.oneTimePrekeys ?? []).map((o: any) => ({ id: o.id, pub: o.pub, consumed: false })),
      });
      return respond(200, { ok: true });
    }
    if (path.startsWith('/api/e2ee/bundle/') && method === 'GET') {
      const target = path.split('/').pop()!;
      const devices = regs.get(target);
      if (!devices || devices.size === 0) return respond(404, { registered: false });
      if (bundleStatusOverride !== null) return respond(bundleStatusOverride, { error: 'limited' });
      return respond(200, {
        registered: true,
        devices: [...devices.values()].map((d) => {
          const opk = d.opks.find((o: any) => !o.consumed) ?? null;
          if (opk) opk.consumed = true;
          return {
            deviceId: d.deviceId,
            identityDhPub: d.identityDhPub,
            identitySigPub: d.identitySigPub,
            signedPrekeyPub: d.signedPrekeyPub,
            prekeySignature: d.prekeySignature,
            opk: opk ? { id: opk.id, pub: opk.pub } : null,
          };
        }),
      });
    }
    if (path === '/api/e2ee/status' && method === 'GET') {
      const devices = regs.get(user);
      const remaining = devices
        ? [...devices.values()].reduce((a: number, d: any) => a + d.opks.filter((o: any) => !o.consumed).length, 0)
        : 0;
      return respond(200, { registered: !!devices && devices.size > 0, opkRemaining: remaining });
    }
    return respond(404, { error: 'not found' });
  };

  let bundleStatusOverride: number | null = null;
  return {
    fetch,
    regs,
    setBundleStatus(status: number | null) { bundleStatusOverride = status; },
  };
}

/* ── Harness ─────────────────────────────────────────────────────────────── */

let server: ReturnType<typeof createMockServer>;

function makeEngine(user: string, store?: KVStore): DirashaE2EE {
  return new DirashaE2EE({
    authHeaders: () => ({ Authorization: `Bearer ${user}` }),
    store: store ?? new MemoryKVStore(),
    selfId: user,
  });
}

beforeEach(() => {
  server = createMockServer();
  vi.stubGlobal('fetch', server.fetch as unknown as typeof fetch);
});

afterEach(() => {
  vi.unstubAllGlobals();
});

/* ── 1. X3DH-bootstrap replay / session-rollback guard ───────────────────── */

describe('X3DH bootstrap replay (session rollback guard)', () => {
  it('replaying the first message after the chain advanced FAILS CLOSED (no rollback)', async () => {
    const alice = makeEngine('alice');
    const bobStore = new MemoryKVStore();
    const bob = makeEngine('bob', bobStore);
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    // Three bootstrap-carrying messages (no reply yet → all carry the same x3dh.ek).
    const m0 = (await alice.encryptMessage('bob', 'first')).content;
    const m1 = (await alice.encryptMessage('bob', 'second')).content;
    const m2 = (await alice.encryptMessage('bob', 'third')).content;
    expect(await bob.decryptMessage('alice', m0)).toEqual({ plaintext: 'first' });
    expect(await bob.decryptMessage('alice', m1)).toEqual({ plaintext: 'second' });
    expect(await bob.decryptMessage('alice', m2)).toEqual({ plaintext: 'third' });

    // On-path attacker replays the recorded FIRST envelope.
    // VULNERABLE behavior (pre-fix): deterministic rebuild → 'first' again.
    // PATCHED behavior: TamperedError, state untouched.
    const replay = await bob.decryptMessage('alice', m0);
    expect(replay).toEqual({ error: 'TamperedError' });

    // A replay of a later chain message must also fail (no rollback re-read).
    expect(await bob.decryptMessage('alice', m1)).toEqual({ error: 'TamperedError' });
    expect(await bob.decryptMessage('alice', m2)).toEqual({ error: 'TamperedError' });

    // The session was NOT rolled back: fresh forward traffic still decrypts.
    const m3 = (await alice.encryptMessage('bob', 'fourth, post-replay')).content;
    expect(await bob.decryptMessage('alice', m3)).toEqual({ plaintext: 'fourth, post-replay' });
  });

  it('STALE PRE-REKEY bootstrap replay after the peer rekeyed → RekeyDetectedError, session survives', async () => {
    // The cross-generation rollback: u0 sends bootstrap v1 (identity N); the
    // receiver bootstraps on it; u0 then REKEYS (new identity N+1, same
    // deviceId) and its post-rekey bootstrap re-keys the receiver; a replayed
    // PRE-rekey bootstrap (identity N) must NOT rebuild a responder session —
    // that would resurrect pre-rekey ratchet state over the post-rekey session
    // and re-enable pre-rekey ciphertext. RekeyDetectedError, state intact.
    const { generateX25519, generateEd25519, ed25519Sign, SPK_SIG_PREFIX, b64encode } =
      await import('../src/lib/e2ee/crypto.ts');
    const aliceStore = new MemoryKVStore();
    const bob = makeEngine('bob');
    const alice = makeEngine('alice', aliceStore);
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    // Generation N: alice's first message bootstraps bob.
    const preRekey = (await alice.encryptMessage('bob', 'pre-rekey secret')).content;
    expect(await bob.decryptMessage('alice', preRekey)).toEqual({ plaintext: 'pre-rekey secret' });
    // Confirm both ways so pendingX3dh is cleared (like the app's real flow).
    expect(await alice.decryptMessage('bob',
      (await bob.encryptMessage('alice', 'reply')).content)).toEqual({ plaintext: 'reply' });

    // Alice REKEYS: fresh identity + SPK, same deviceId (the app's rekey flow).
    const identity = JSON.parse((await aliceStore.get('identity'))!);
    const dh = generateX25519();
    const sig = generateEd25519();
    identity.dh = { priv: b64encode(dh.priv), pub: b64encode(dh.pub) };
    identity.sig = { priv: b64encode(sig.priv), pub: b64encode(sig.pub) };
    identity.registered = false;
    await aliceStore.set('identity', JSON.stringify(identity));
    const spk = generateX25519();
    const spkSig = ed25519Sign(new TextEncoder().encode(SPK_SIG_PREFIX + b64encode(spk.pub)), sig.priv);
    await aliceStore.set('spkPriv', JSON.stringify({ priv: b64encode(spk.priv), pub: b64encode(spk.pub), sig: b64encode(spkSig) }));
    await alice.deleteSession('bob');
    await alice.ensureRegistered();

    // Post-rekey bootstrap re-keys bob onto generation N+1.
    const postRekey = (await alice.encryptMessage('bob', 'post-rekey secret')).content;
    expect(await bob.decryptMessage('alice', postRekey)).toEqual({ plaintext: 'post-rekey secret' });

    // On-path attacker replays the PRE-REKEY bootstrap (identity N). Pre-fix
    // this rebuilt a generation-N responder session OVER the N+1 session.
    // Patched: RekeyDetectedError, and the N+1 session still works.
    const res = await bob.decryptMessage('alice', preRekey);
    expect(res).toEqual({ error: 'RekeyDetectedError' });

    const followUp = (await alice.encryptMessage('bob', 'post-rekey still flows')).content;
    expect(await bob.decryptMessage('alice', followUp)).toEqual({ plaintext: 'post-rekey still flows' });
  });

  it('genuinely NEW bootstraps (different ek) still re-key after a session loss', async () => {
    const alice = makeEngine('alice');
    const bob = makeEngine('bob');
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    expect(await bob.decryptMessage('alice', (await alice.encryptMessage('bob', 'v1')).content))
      .toEqual({ plaintext: 'v1' });

    // Alice loses her session state and re-inits (the documented rekey flow);
    // the fresh X3DH init generates a FRESH ephemeral ek. Bob holds the OLD
    // session: ik matches (same identity) but the new chain cannot decrypt, so
    // the rebuild path runs — it MUST stay allowed because the ek differs from
    // the one Bob's session was bootstrapped with.
    await alice.deleteSession('bob');
    const m2 = (await alice.encryptMessage('bob', 'fresh bootstrap')).content;
    expect(await bob.decryptMessage('alice', m2)).toEqual({ plaintext: 'fresh bootstrap' });
  });
});

/* ── 2. Bundle-endpoint failure must not downgrade to plaintext ──────────── */

describe('bundle fetch failure semantics (plaintext-downgrade prevention)', () => {
  it('HTTP 429 (rate limited) → generic E2eeError, NOT PeerNotRegisteredError', async () => {
    const alice = makeEngine('alice');
    await alice.ensureRegistered();
    await makeEngine('bob').ensureRegistered(); // registered peer → override actually applies
    server.setBundleStatus(429);
    // PeerNotRegisteredError is the App's plaintext-fallback trigger — a rate
    // limit must never masquerade as it.
    await expect(alice.encryptMessage('bob', 'should abort')).rejects.toBeInstanceOf(E2eeError);
    await expect(alice.encryptMessage('bob', 'should abort')).rejects.not.toBeInstanceOf(PeerNotRegisteredError);
  });

  it('HTTP 500 → generic E2eeError, NOT PeerNotRegisteredError', async () => {
    const alice = makeEngine('alice');
    await alice.ensureRegistered();
    await makeEngine('bob').ensureRegistered(); // registered peer → override actually applies
    server.setBundleStatus(500);
    await expect(alice.encryptMessage('bob', 'should abort')).rejects.toBeInstanceOf(E2eeError);
    await expect(alice.encryptMessage('bob', 'should abort')).rejects.not.toBeInstanceOf(PeerNotRegisteredError);
  });

  it('HTTP 404 (genuinely unregistered) → PeerNotRegisteredError (plaintext fallback preserved)', async () => {
    const alice = makeEngine('alice');
    await alice.ensureRegistered();
    await expect(alice.encryptMessage('carol', 'hi')).rejects.toBeInstanceOf(PeerNotRegisteredError);
  });
});

/* ── 3. Mutual X3DH init desync (deterministic KEEPER/ADOPTER tie-break) ──── */

/**
 * Regression tests for the mutual X3DH init desync bug class: when BOTH peers
 * send first messages concurrently, each carries its own X3DH bootstrap, and
 * (pre-fix) each side's inbound bootstrap REPLACED its own un-confirmed
 * initiator session (ckR === null + pendingX3dh — the bootstrappedEk guard
 * never fires on initiator sessions). The pair ended up bound to two different
 * bootstrap generations and every subsequent message failed AEAD in both
 * directions, permanently.
 *
 * Fix (engine.ts decryptEnvelope): lexicographic comparison of the identity DH
 * pubs. The SMALLER ik is the KEEPER (keeps its initiator session, drops the
 * peer's bootstrap → one clean DecryptFailedError placeholder), the LARGER ik
 * is the ADOPTER (discards its initiator session and rebuilds as responder on
 * the keeper's bootstrap generation). Exactly ONE message is lost in the race;
 * everything after decrypts in BOTH directions, permanently.
 */
describe('mutual X3DH init desync (deterministic tie-break)', () => {
  /** Lexicographic b64-key comparison — mirrors the engine's tie-break. */
  function cmpIk(a: string, b: string): number {
    const ab = b64decode(a);
    const bb = b64decode(b);
    for (let i = 0; i < Math.min(ab.length, bb.length); i++) {
      if (ab[i] !== bb[i]) return ab[i] < bb[i] ? -1 : 1;
    }
    return 0;
  }

  it('(a) concurrent mutual init: exactly ONE keeper-drop fails as a clean error, then BOTH directions decrypt permanently (20 msgs each way)', async () => {
    const aliceStore = new MemoryKVStore();
    const bobStore = new MemoryKVStore();
    const alice = makeEngine('alice', aliceStore);
    const bob = makeEngine('bob', bobStore);
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    // The engine's rule: the SMALLER identity ik is the KEEPER.
    const aliceIk = JSON.parse((await aliceStore.get('identity'))!).dh.pub;
    const bobIk = JSON.parse((await bobStore.get('identity'))!).dh.pub;
    const aliceIsKeeper = cmpIk(aliceIk, bobIk) <= 0;

    // Both sides initiate CONCURRENTLY (neither first message delivered yet).
    const a1 = (await alice.encryptMessage('bob', 'a-first')).content;
    const b1 = (await bob.encryptMessage('alice', 'b-first')).content;

    const atBob = await bob.decryptMessage('alice', a1);
    const atAlice = await alice.decryptMessage('bob', b1);

    // Exactly ONE message (the keeper-drop) fails as a clean error...
    expect(aliceIsKeeper ? atAlice : atBob).toEqual({ error: 'DecryptFailedError' });
    // ...while the ADOPTER decrypts the keeper's bootstrap generation.
    expect(aliceIsKeeper ? atBob : atAlice).toEqual({ plaintext: aliceIsKeeper ? 'a-first' : 'b-first' });

    // ...and EVERYTHING after decrypts in BOTH directions, permanently.
    for (let i = 0; i < 20; i++) {
      const a = (await alice.encryptMessage('bob', `a-${i}`)).content;
      expect(await bob.decryptMessage('alice', a)).toEqual({ plaintext: `a-${i}` });
      const b = (await bob.encryptMessage('alice', `b-${i}`)).content;
      expect(await alice.decryptMessage('bob', b)).toEqual({ plaintext: `b-${i}` });
    }
  }, 120_000);

  it('(b) the tie-break is deterministic: same identity keys → the SAME side wins across 5 runs (fresh EKs each run)', async () => {
    const aliceStore = new MemoryKVStore();
    const bobStore = new MemoryKVStore();
    const alice = makeEngine('alice', aliceStore);
    const bob = makeEngine('bob', bobStore);
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    const aliceIk = JSON.parse((await aliceStore.get('identity'))!).dh.pub;
    const bobIk = JSON.parse((await bobStore.get('identity'))!).dh.pub;
    const aliceIsKeeper = cmpIk(aliceIk, bobIk) <= 0;

    for (let run = 0; run < 5; run++) {
      // Fresh conversation per run: both sessions wiped, so each side
      // re-initiates with a FRESH ephemeral EK — while the identity keys
      // (and therefore the winner) stay fixed.
      await alice.deleteSession('bob');
      await bob.deleteSession('alice');
      const a1 = (await alice.encryptMessage('bob', `a1-run${run}`)).content;
      const b1 = (await bob.encryptMessage('alice', `b1-run${run}`)).content;
      const atBob = await bob.decryptMessage('alice', a1);
      const atAlice = await alice.decryptMessage('bob', b1);

      // The SAME side wins every time: keeper drops, adopter decrypts.
      expect(aliceIsKeeper ? atAlice : atBob).toEqual({ error: 'DecryptFailedError' });
      expect(aliceIsKeeper ? atBob : atAlice).toEqual({ plaintext: aliceIsKeeper ? `a1-run${run}` : `b1-run${run}` });

      // And the settled generation carries traffic both ways immediately.
      expect(await bob.decryptMessage('alice', (await alice.encryptMessage('bob', `a2-run${run}`)).content))
        .toEqual({ plaintext: `a2-run${run}` });
      expect(await alice.decryptMessage('bob', (await bob.encryptMessage('alice', `b2-run${run}`)).content))
        .toEqual({ plaintext: `b2-run${run}` });
    }
  }, 120_000);
});
