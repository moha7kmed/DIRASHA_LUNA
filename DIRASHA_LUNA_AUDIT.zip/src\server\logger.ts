export enum LogLevel {
  DEBUG = 0,
  INFO = 1,
  WARN = 2,
  ERROR = 3
}

const CURRENT_LEVEL_STR = process.env.LOG_LEVEL || (process.env.NODE_ENV === 'production' ? 'INFO' : 'DEBUG');

const LEVEL_MAP: Record<string, LogLevel> = {
  'DEBUG': LogLevel.DEBUG,
  'INFO': LogLevel.INFO,
  'WARN': LogLevel.WARN,
  'ERROR': LogLevel.ERROR,
};

const currentLevel = LEVEL_MAP[CURRENT_LEVEL_STR.toUpperCase()] ?? LogLevel.INFO;

const IS_PROD = process.env.NODE_ENV === 'production';

// ---------------------------------------------------------------------------
// Secret redaction: never let credential-looking keys reach any output.
// ---------------------------------------------------------------------------
const SECRET_KEY_RE = /password|token|secret|authorization/i;
const REDACTED = '[REDACTED]';

function redactValue(value: any, depth = 0): any {
  if (depth > 6) return '[TRUNCATED]';
  if (value === null || value === undefined) return value;
  if (value instanceof Error) {
    // Errors never carry redactable plain keys reliably; keep message/stack only.
    return { name: value.name, message: value.message, stack: value.stack };
  }
  if (typeof value === 'object') {
    if (Array.isArray(value)) {
      return value.map((v) => redactValue(v, depth + 1));
    }
    const out: Record<string, any> = {};
    for (const [k, v] of Object.entries(value)) {
      out[k] = SECRET_KEY_RE.test(k) ? REDACTED : redactValue(v, depth + 1);
    }
    return out;
  }
  return value;
}

function serializeArg(arg: any): any {
  return redactValue(arg);
}

function stringifyMeta(arg: any): string {
  const v = serializeArg(arg);
  if (typeof v === 'string') return v;
  try {
    return JSON.stringify(v);
  } catch {
    return String(v);
  }
}

// ---------------------------------------------------------------------------
// In-memory ring buffer (last 500 entries) for a future admin endpoint.
// ---------------------------------------------------------------------------
const RING_SIZE = 500;
export interface LogEntry {
  ts: string;
  level: 'DEBUG' | 'INFO' | 'WARN' | 'ERROR';
  msg: string;
  [meta: string]: any;
}

const ring: LogEntry[] = [];

function pushRing(entry: LogEntry): void {
  ring.push(entry);
  if (ring.length > RING_SIZE) {
    ring.splice(0, ring.length - RING_SIZE);
  }
}

/**
 * Returns the most recent log entries (newest last), optionally filtered by
 * level. Intended for a future admin/debug endpoint; nothing wires it yet.
 * Returned entries are copies and are already secret-redacted.
 */
export function getRecentLogs(level?: string): LogEntry[] {
  if (level) {
    const wanted = level.toUpperCase();
    return ring.filter((e) => e.level === wanted).map((e) => ({ ...e }));
  }
  return ring.map((e) => ({ ...e }));
}

// ---------------------------------------------------------------------------
// Output formatting
// ---------------------------------------------------------------------------
const ANSI = {
  gray: '\x1b[90m',
  cyan: '\x1b[36m',
  yellow: '\x1b[33m',
  red: '\x1b[31m',
  reset: '\x1b[0m',
};

function colorFor(level: string): string {
  switch (level) {
    case 'DEBUG': return ANSI.gray;
    case 'INFO': return ANSI.cyan;
    case 'WARN': return ANSI.yellow;
    case 'ERROR': return ANSI.red;
    default: return '';
  }
}

function emit(level: LogLevel, message: string, args: any[]): void {
  if (currentLevel > level) return;

  const levelStr = LogLevel[level] as 'DEBUG' | 'INFO' | 'WARN' | 'ERROR';
  const ts = new Date().toISOString();
  const redactedArgs = args.map((a) => serializeArg(a));

  // Build the ring entry: single object meta is spread, otherwise listed under `args`.
  let meta: Record<string, any> = {};
  if (redactedArgs.length === 1 && typeof redactedArgs[0] === 'object' && redactedArgs[0] !== null && !Array.isArray(redactedArgs[0])) {
    meta = redactedArgs[0];
  } else if (redactedArgs.length > 0) {
    meta = { args: redactedArgs };
  }
  pushRing({ ts, level: levelStr, msg: message, ...meta });

  const write = level >= LogLevel.WARN ? (level >= LogLevel.ERROR ? console.error : console.warn) : console.log;

  if (IS_PROD) {
    // Single-line JSON per entry for machine ingestion.
    const line = JSON.stringify({ ts, level: levelStr, msg: message, ...meta });
    write(line);
  } else {
    // Human-readable colored text for local development.
    const c = colorFor(levelStr);
    const extras = redactedArgs.map((a) => stringifyMeta(a)).join(' ');
    write(`${c}[${levelStr}]${ANSI.reset} ${message}${extras ? ' ' + extras : ''}`);
  }
}

export const logger = {
  debug(message: string, ...args: any[]) {
    emit(LogLevel.DEBUG, message, args);
  },
  info(message: string, ...args: any[]) {
    emit(LogLevel.INFO, message, args);
  },
  warn(message: string, ...args: any[]) {
    emit(LogLevel.WARN, message, args);
  },
  error(message: string, ...args: any[]) {
    emit(LogLevel.ERROR, message, args);
  }
};
