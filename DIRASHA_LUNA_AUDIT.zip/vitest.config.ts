import { defineConfig } from 'vitest/config';

/**
 * Test-suite stability config.
 *
 * - testTimeout/hookTimeout raised to 30s: the heavy crypto tests (e2ee-media
 *   2MB round-trip, e2ee-engine m3/m4/m5) run ~5s on a contended machine —
 *   the previous 5s default was intermittently exceeded under CPU contention.
 * - fileParallelism: false — the suite's crypto work saturates all cores when
 *   test files run in parallel, which is exactly the contention that made
 *   1-2 tests flake per run. Running files sequentially keeps the full suite
 *   (~108 tests, 8 files) well under 4 minutes while making runs deterministic.
 */
export default defineConfig({
  test: {
    testTimeout: 30000,
    hookTimeout: 30000,
    fileParallelism: false,
  },
});
