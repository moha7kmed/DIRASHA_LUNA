/**
 * DirashaE2EE — the client crypto engine (Signal-style X3DH + Double Ratchet).
 *
 * Contract: E2EE-SPEC.md "Client lib (Agent C)" + "Integration (Agent I)".
 * Fully self-contained: only deps are @noble/* and global fetch. Auth is
 * decoupled via the injected authHeaders provider.
 *
 *   const e2ee = new DirashaE2EE({ authHeaders: () => ({ Authorization: ... }) });
 *   await e2ee.ensureRegistered();            // idempotent, fire-and-forget from App
 *   const { content } = await e2ee.encryptMessage(peerId, 'hello'); // 'DIR1:...' | 'DIRM1:...'
 *   const r = await e2ee.decryptMessage(peerId, content);           // {plaintext}|{error}
 *
 * Multi-device (Signal-style): sessions are PER PEER DEVICE —
 * kv 'session:<peerId>:<peerDeviceId>' (legacy plain 'session:<peerId>' is
 * migrated lazily on decrypt). Outgoing messages fan out to every device in
 * the peer's bundle; single-device peers keep the exact legacy DIR1 wire.
 *
 * Correctness invariants (see spec):
 *   - KDF_RK = HKDF-SHA256(ikm=DH, salt=rk, info='DirashaRoot-v1', 64B) → rk'[0:32], ck'[32:64]
 *   - KDF_CK: mk = HMAC(ck, 0x01), ck' = HMAC(ck, 0x02); MAX_SKIP = 2000 with oldest-eviction
 *   - Decrypt is atomic: all ratchet mutations happen on a clone and are persisted
 *     only after the AEAD tag verifies (derive-then-commit).
 *   - Every mutation of identity/session/opk state is persisted immediately (crash-safe).
 *   - One-time prekey hygiene (P4): a consumed OPK PRIV ('opk:<id>') is deleted
 *     ONLY after the bootstrap message verified (AEAD), the responder session
 *     was derived AND persisted — persist-session-then-delete-priv, strictly in
 *     that order. Identity keys and the active SPK priv are never touched.
 */

import {
  MemoryKVStore,
  IndexedDBKVStore,
  NamespacedKVStore,
} from './store.ts';
import {
  E2eeError,
  PeerNotRegisteredError,
  DecryptFailedError,
  SessionMissingError,
  TamperedError,
  RekeyDetectedError,
} from './types.ts';
import type {
  KVStore,
  IdentityRecord,
  SpkRecord,
  OpkRecord,
  PqPrekeyRecord,
  SessionState,
  Envelope,
  MultiEnvelope,
  PeerDevice,
} from './types.ts';
import {
  WIRE_PREFIX,
  WIRE_PREFIX_MULTI,
  WIRE_VERSION,
  SPK_SIG_PREFIX,
  PQ_SPK_SIG_PREFIX,
  MAX_SKIP,
  MAX_DEVICES,
  LEGACY_DEVICE_ID,
  NONCE_BYTES,
  KEY_BYTES,
  SIG_BYTES,
  FF32,
  ZERO32,
  PQ_PUB_BYTES,
  PQ_CT_BYTES,
  AAD_TEMPLATE,
  b64encode,
  b64decode,
  utf8Encode,
  utf8Decode,
  randomBytes,
  randomDeviceId,
  concatBytes,
  generateX25519,
  generateEd25519,
  generateMlKem768,
  x25519Shared,
  ed25519Sign,
  ed25519Verify,
  pqEncapsulate,
  pqDecapsulate,
  kdfRk,
  kdfCk,
  x3dhSk,
  x3dhSkPq,
  aadString,
  aeadSeal,
  aeadOpen,
  safetyNumber,
} from './crypto.ts';
import { padToBucket, unpadFromBucket, isPadded, PAD_FLAG } from './padding.ts';
// F7: Key Transparency client verification (dead-code revival — wired into
// fetchPeerDevices below). Browser-safe, Buffer-free mirror of the server's
// RFC-6962 proof math.
import {
  computeCommitment,
  clearKtFlag,
  resetKtVerdict,
  resetKtVerdicts,
  fetchAndVerifyFleetProofGated,
  getPeerKtVerification,
  isKtEnforced,
  fetchAndVerifyFleetProof,
  setKtFlag,
} from './kt-client.ts';

/* ── Engine tunables (protocol volumes, not wire format) ─────────────────── */

const DEVICE_CACHE_TTL_MS = 5 * 60_000; // one bundle fetch per peer per TTL (OPK + rate-limit economy)
const OPK_COUNT_ON_REGISTER = 100; // E2EE-SPEC: "OPKs: 100 X25519 one-time prekeys"
const OPK_REPLENISH_TARGET = 100;  // replenished batches refill up to this
const OPK_REPLENISH_BATCH = 50;    // per POST /api/e2ee/prekeys (server cap: 200)
const OPK_MIN_BEFORE_REPLENISH = 20;

type AuthHeadersProvider = () => Promise<Record<string, string>> | Record<string, string>;

export interface DirashaE2EEOptions {
  authHeaders: AuthHeadersProvider;
  /** Optional persistence override (tests use MemoryKVStore; browsers default to IndexedDB). */
  store?: KVStore;
  /** Multi-account isolation: prefixes all KV keys (identity/session/opk) with the account id. */
  namespace?: string;
  /**
   * The local account's user id, when known. Enables STABLE (primary-identity)
   * safety numbers for multi-device accounts: getSafetyNumber() then resolves
   * OUR primary identity from the server instead of this device's local keys.
   * Omitted → falls back to the local device identity.
   */
  selfId?: string;
}

export interface EngineStatus {
  registered: boolean;
  opkRemaining: number;
}

export type DecryptResult = { plaintext: string } | { error: string };

function jsonParse<T>(s: string | null): T | null {
  if (s === null) return null;
  try {
    return JSON.parse(s) as T;
  } catch {
    return null;
  }
}

function cloneSession(s: SessionState): SessionState {
  // SessionState is plain JSON-able (strings/numbers/records) — structural clone
  // gives us the derive-then-commit atomicity for free.
  return JSON.parse(JSON.stringify(s)) as SessionState;
}

/** Lexicographic Uint8Array comparison: a < b → -1, a > b → 1, equal → 0. */
function compareBytes(a: Uint8Array, b: Uint8Array): number {
  const n = Math.min(a.length, b.length);
  for (let i = 0; i < n; i++) {
    if (a[i] !== b[i]) return a[i] < b[i] ? -1 : 1;
  }
  if (a.length === b.length) return 0;
  return a.length < b.length ? -1 : 1;
}

/** kv key of the dropped-bootstrap ledger for a (peerId, peerDeviceId) pair. */
function droppedX3dhKey(peerId: string, peerDeviceId: string): string {
  return `x3dh-dropped:${peerId}:${peerDeviceId}`;
}

function sessionKey(peerId: string, peerDeviceId: string): string {
  return `session:${peerId}:${peerDeviceId}`;
}

/** Legacy (pre-multi-device) session key — plain, no device suffix. */
function legacySessionKey(peerId: string): string {
  return `session:${peerId}`;
}

function opkKey(id: number): string {
  return `opk:${id}`;
}

/** kv key of the ML-KEM-768 PQ prekey record (PQXDH) — vault-encrypted like all privs. */
const PQ_PREKEY_KV = 'pqpq-priv';

/**
 * F8: kv key of the per-peer PLAINTEXT-DOWNGRADE MEMORY. Set when the peer's
 * bundle fetch returns a DEFINITIVE unregistered answer (HTTP 404 /
 * registered:false) and the send falls back to plaintext; cleared on the next
 * SUCCESSFUL encryption. Surfaced via wasDowngraded() → the App renders the
 * "غير مشفرة طرف-لطرف" badge instead of the lock (no silent downgrade).
 */
function downgradedKey(peerId: string): string {
  return `e2eeDowngraded:${peerId}`;
}

/**
 * F9: kv key of the per-(peer, device) PQ-DOWNGRADE MEMORY. Set '1' the moment
 * a session with that device is established PQ-hybrid (session.pq === true) —
 * either as initiator (initSessionAsInitiator) or as responder
 * (decryptEnvelope, after the bootstrap AEAD verifies). A later classical-only
 * init for the same device (bundle advertises pq:false after we have ALREADY
 * run a hybrid session with it) is rejected with TamperedError — client-
 * enforced downgrade protection beyond the server's announcement. Cleared by
 * the explicit user actions emergencyRotate()/deleteSession() ONLY.
 */
function pqSeenKey(peerId: string, peerDeviceId: string): string {
  return `pqSeen:${peerId}:${peerDeviceId}`;
}

/** Parse + validate a DIR1 envelope. Any structural anomaly = TamperedError. */
function parseEnvelope(content: string): Envelope {
  if (!content.startsWith(WIRE_PREFIX)) throw new TamperedError('content is not a DIR1 envelope');
  let json: string;
  try {
    json = utf8Decode(b64decode(content.slice(WIRE_PREFIX.length)));
  } catch {
    throw new TamperedError('envelope is not valid base64');
  }
  let env: any;
  try {
    env = JSON.parse(json);
  } catch {
    throw new TamperedError('envelope is not valid JSON');
  }
  return validateEnvelope(env);
}

/** Parse + validate a DIRM1 multi-device container. Any structural anomaly = TamperedError. */
function parseMultiEnvelope(content: string): MultiEnvelope {
  if (!content.startsWith(WIRE_PREFIX_MULTI)) throw new TamperedError('content is not a DIRM1 envelope');
  let json: string;
  try {
    json = utf8Decode(b64decode(content.slice(WIRE_PREFIX_MULTI.length)));
  } catch {
    throw new TamperedError('envelope is not valid base64');
  }
  let multi: any;
  try {
    multi = JSON.parse(json);
  } catch {
    throw new TamperedError('envelope is not valid JSON');
  }
  if (!multi || multi.v !== WIRE_VERSION || !Array.isArray(multi.devices) || multi.devices.length === 0) {
    throw new TamperedError('DIRM1 container shape invalid');
  }
  const devices: Array<{ d: string; env: Envelope }> = [];
  for (const entry of multi.devices) {
    // env may be an inline envelope object or (tolerated) the b64 of its JSON.
    let raw = entry?.env;
    if (typeof raw === 'string') {
      try {
        raw = JSON.parse(utf8Decode(b64decode(raw)));
      } catch {
        throw new TamperedError('DIRM1 entry env is not a valid envelope');
      }
    }
    if (!entry || typeof entry.d !== 'string') throw new TamperedError('DIRM1 entry missing deviceId');
    devices.push({ d: entry.d, env: parseEnvelopeObj(raw) });
  }
  return { v: WIRE_VERSION, devices };
}

/** parseEnvelope over an already-decoded envelope object. */
function parseEnvelopeObj(env: any): Envelope {
  if (!env || typeof env !== 'object') throw new TamperedError('envelope shape invalid');
  // Reuse the wire-level validation by round-tripping through the same checks.
  return validateEnvelope(env);
}

function validateEnvelope(env: any): Envelope {
  const okShape =
    env &&
    env.v === WIRE_VERSION &&
    typeof env.ik === 'string' &&
    typeof env.hdr?.dh === 'string' &&
    Number.isInteger(env.hdr?.pn) && env.hdr.pn >= 0 &&
    Number.isInteger(env.hdr?.n) && env.hdr.n >= 0 &&
    typeof env.iv === 'string' &&
    typeof env.ct === 'string' &&
    (env.sd === undefined || typeof env.sd === 'string') &&
    (env.td === undefined || typeof env.td === 'string') &&
    (env.pq === undefined || env.pq === 1) &&
    (env.pqCt === undefined || typeof env.pqCt === 'string') &&
    (env.x3dh === undefined ||
      (typeof env.x3dh?.ek === 'string' &&
        (env.x3dh.opkId === undefined || Number.isInteger(env.x3dh.opkId)) &&
        (env.x3dh.pqCt === undefined || typeof env.x3dh.pqCt === 'string')));
  if (!okShape) throw new TamperedError('envelope shape invalid');
  if (b64decode(env.ik).length !== KEY_BYTES) throw new TamperedError('ik is not a 32-byte key');
  if (b64decode(env.hdr.dh).length !== KEY_BYTES) throw new TamperedError('hdr.dh is not a 32-byte key');
  if (b64decode(env.iv).length !== NONCE_BYTES) throw new TamperedError('iv is not 12 bytes');
  if (b64decode(env.ct).length < 16) throw new TamperedError('ct too short to carry an AEAD tag');
  // PQXDH consistency: pq:1 ⇔ pqCt present, and the ciphertext must be an
  // exact ML-KEM-768 ciphertext — anything else is TamperedError (fail closed).
  if (env.pq === 1) {
    if (typeof env.pqCt !== 'string') throw new TamperedError('pq envelope is missing pqCt');
    if (b64decode(env.pqCt).length !== PQ_CT_BYTES) throw new TamperedError('pqCt is not an ML-KEM-768 ciphertext');
  } else if (env.pqCt !== undefined) {
    throw new TamperedError('pqCt present without the pq flag');
  }
  return env as Envelope;
}

export class DirashaE2EE {
  private readonly authHeaders: AuthHeadersProvider;
  private readonly kv: KVStore;
  /** TTL cache of peer device lists — one bundle fetch per peer per TTL (OPK + rate-limit economy). */
  private readonly deviceCache = new Map<string, { devices: PeerDevice[]; fetchedAt: number }>();
  private readonly selfId?: string;
  /**
   * In-flight ensureRegistered() singleton. The login path, auth:ready and
   * token-refresh paths all fire ensureRegistered() — without dedupe, the
   * concurrent calls race: each re-runs registration and re-posts the OPK pool,
   * and an in-flight peer bundle fetch can consume an OPK whose private key a
   * later call just wiped (→ undecryptable peer envelopes → placeholders).
   * Concurrent callers SHARE one registration promise (cleared in finally so a
   * failed attempt can be retried).
   */
  private registrationInFlight: Promise<{ registered: boolean }> | null = null;
  /**
   * In-flight emergencyRotate() singleton (Project 10) — concurrent callers
   * share ONE rotation, cleared in finally so a failed attempt can be retried.
   */
  private rotationInFlight: Promise<{ newIdentity: boolean }> | null = null;

  constructor(options: DirashaE2EEOptions) {
    if (typeof options?.authHeaders !== 'function') {
      throw new TypeError('DirashaE2EE: options.authHeaders must be a function');
    }
    this.authHeaders = options.authHeaders;
    this.selfId = typeof options.selfId === 'string' && options.selfId ? options.selfId : undefined;
    const base = options.store ?? this.defaultStore();
    this.kv = options.namespace ? new NamespacedKVStore(options.namespace, base) : base;
  }

  private defaultStore(): KVStore {
    if (typeof globalThis.indexedDB !== 'undefined') return new IndexedDBKVStore();
    return new MemoryKVStore();
  }

  /* ══ Server API ══ */

  private async api(path: string, init?: RequestInit): Promise<{ ok: boolean; status: number; body: any }> {
    const extra = await this.authHeaders();
    const res = await fetch(path, {
      ...init,
      headers: {
        'Content-Type': 'application/json',
        ...extra,
        ...(init?.headers as Record<string, string> | undefined),
      },
    });
    const body = await res.json().catch(() => null);
    return { ok: res.ok, status: res.status, body };
  }

  /* ══ Local persistence helpers ══ */

  private async loadIdentity(): Promise<IdentityRecord | null> {
    return jsonParse<IdentityRecord>(await this.kv.get('identity'));
  }

  /**
   * Assign a stable deviceId to identities created before multi-device support
   * (or at first creation) and persist it immediately. Re-registration from the
   * same store reuses the id, so the server replaces this device's row only.
   */
  private async ensureDeviceId(identity: IdentityRecord): Promise<string> {
    if (!identity.deviceId) {
      identity.deviceId = randomDeviceId();
      await this.kv.set('identity', JSON.stringify(identity));
    }
    return identity.deviceId;
  }

  private async requireIdentity(): Promise<IdentityRecord> {
    const id = await this.loadIdentity();
    if (!id || !id.dh?.priv || !id.sig?.priv) {
      throw new PeerNotRegisteredError('local E2EE identity missing — call ensureRegistered() first');
    }
    await this.ensureDeviceId(id);
    return id;
  }

  private async loadSpk(): Promise<SpkRecord | null> {
    return jsonParse<SpkRecord>(await this.kv.get('spkPriv'));
  }

  /** Load the ML-KEM-768 PQ prekey record (kv 'pqpq-priv'), null on legacy stores. */
  private async loadPqPrekey(): Promise<PqPrekeyRecord | null> {
    return jsonParse<PqPrekeyRecord>(await this.kv.get(PQ_PREKEY_KV));
  }

  /**
   * Ensure the local PQ prekey exists (PQXDH, design doc §3.6): generated at
   * first registration AND on the first run of a legacy (pre-PQ) device —
   * "الأجهزة الحالية تُرحَّل فعليًا عند أول إعادة تشغيل" — then reused
   * verbatim on every re-registration. The priv is persisted BEFORE the pub is
   * advertised (crash-safe, same ordering as OPKs).
   */
  private async ensurePqPrekey(): Promise<PqPrekeyRecord> {
    const existing = await this.loadPqPrekey();
    if (existing?.priv && existing?.pub) return existing;
    const kp = generateMlKem768();
    const rec: PqPrekeyRecord = { priv: b64encode(kp.priv), pub: b64encode(kp.pub) };
    await this.kv.set(PQ_PREKEY_KV, JSON.stringify(rec));
    return rec;
  }

  /**
   * Load the session for (peerId, peerDeviceId). Legacy plain-key sessions
   * ('session:<peerId>', written by pre-multi-device versions) are still
   * honored for sd='default' traffic: on a miss for the suffixed key we read
   * the legacy key; on successful decrypt the state is written back under the
   * NEW suffixed key (lazy migration — saveSession always targets the suffix).
   */
  private async loadSession(peerId: string, peerDeviceId: string): Promise<SessionState | null> {
    const s = jsonParse<SessionState>(await this.kv.get(sessionKey(peerId, peerDeviceId)));
    if (s) return s;
    if (peerDeviceId === LEGACY_DEVICE_ID) {
      return jsonParse<SessionState>(await this.kv.get(legacySessionKey(peerId)));
    }
    return null;
  }

  private async saveSession(peerId: string, peerDeviceId: string, s: SessionState): Promise<void> {
    await this.kv.set(sessionKey(peerId, peerDeviceId), JSON.stringify(s));
  }

  /**
   * Dropped-bootstrap ledger (companion guard to the mutual-init tie-break):
   * the `x3dh.ek` values the deterministic KEEPER rejected for this
   * (peerId, senderDevice) pair. A bootstrap the keeper already refused belongs
   * to the ADOPTER's DISCARDED initiator generation — replaying or late-
   * delivering it later (e.g. server redelivery) must never rebuild that dead
   * generation over the healthy session. Kept OUT of the SessionState on
   * purpose: the keeper drops the inbound bootstrap WITHOUT mutating its
   * session. Capped at 8, newest wins.
   */
  private async getDroppedX3dh(peerId: string, peerDeviceId: string): Promise<string[]> {
    return jsonParse<string[]>(await this.kv.get(droppedX3dhKey(peerId, peerDeviceId))) ?? [];
  }

  private async recordDroppedX3dh(peerId: string, peerDeviceId: string, ek: string): Promise<void> {
    const dropped = await this.getDroppedX3dh(peerId, peerDeviceId);
    if (dropped.includes(ek)) return;
    await this.kv.set(droppedX3dhKey(peerId, peerDeviceId), JSON.stringify([...dropped, ek].slice(-8)));
  }

  private async opkIds(): Promise<number[]> {
    return (await this.kv.keys())
      .filter((k) => k.startsWith('opk:'))
      .map((k) => Number(k.slice(4)))
      .filter((n) => Number.isInteger(n));
  }

  /** Generate `count` fresh OPK pairs, persist private parts, return {id, pub} list. */
  private async generateOpks(count: number, startId: number): Promise<Array<{ id: number; pub: string }>> {
    const batch: Array<{ id: number; pub: string }> = [];
    for (let i = 0; i < count; i++) {
      const kp = generateX25519();
      const id = startId + i;
      const rec: OpkRecord = { priv: b64encode(kp.priv), pub: b64encode(kp.pub) };
      // Persist private material BEFORE advertising the public part (crash-safe:
      // an orphaned OPK priv is harmless; an advertised OPK without its priv is not).
      await this.kv.set(opkKey(id), JSON.stringify(rec));
      batch.push({ id, pub: rec.pub });
    }
    return batch;
  }

  /* ══ Registration ══ */

  /**
   * Creates the local identity (IK_dh, IK_sig, SPK, OPKs) if missing and
   * registers it with the server. Idempotent: a successfully registered local
   * identity short-circuits. Never overwrites an existing identity.
   *
   * Concurrency: concurrent callers share ONE in-flight registration (the
   * whole body — identity generation, OPK creation and the server POST — is
   * serialized behind the singleton promise), so the register endpoint is hit
   * exactly once no matter how many callers race.
   */
  async ensureRegistered(): Promise<{ registered: boolean }> {
    if (this.registrationInFlight) return this.registrationInFlight;
    this.registrationInFlight = this.ensureRegisteredInternal().finally(() => {
      this.registrationInFlight = null;
    });
    return this.registrationInFlight;
  }

  private async ensureRegisteredInternal(): Promise<{ registered: boolean }> {
    let identity = await this.loadIdentity();
    if (!identity) {
      const dh = generateX25519();
      const sig = generateEd25519();
      identity = {
        dh: { priv: b64encode(dh.priv), pub: b64encode(dh.pub) },
        sig: { priv: b64encode(sig.priv), pub: b64encode(sig.pub) },
        registered: false,
        deviceId: randomDeviceId(),
      };
      await this.kv.set('identity', JSON.stringify(identity));

      const spk = generateX25519();
      const spkSig = ed25519Sign(utf8Encode(SPK_SIG_PREFIX + b64encode(spk.pub)), b64decode(identity.sig.priv));
      await this.kv.set('spkPriv', JSON.stringify({ priv: b64encode(spk.priv), pub: b64encode(spk.pub), sig: b64encode(spkSig) }));

      const existing = await this.opkIds();
      const startId = existing.length > 0 ? Math.max(...existing) + 1 : 1;
      await this.generateOpks(OPK_COUNT_ON_REGISTER, startId);
    }
    // Legacy stores may lack a deviceId — assign one BEFORE registering so the
    // server can key this account's device row correctly. Persisted immediately.
    const deviceId = await this.ensureDeviceId(identity);

    // PQXDH (design doc §3.6): the ML-KEM-768 prekey is generated at first
    // registration and on the first run of a pre-PQ (legacy) device — the
    // subsequent (re-)registration uploads it automatically. A device that
    // already has a PQ prekey does NOT re-register just for the PQ upgrade.
    let pq = await this.loadPqPrekey();
    const pqExisted = !!(pq?.priv && pq?.pub);
    if (!pqExisted) pq = await this.ensurePqPrekey();

    if (identity.registered && pqExisted) return { registered: true };

    const spk = await this.loadSpk();
    if (!spk) throw new E2eeError('local SPK missing — registration aborted');
    const ids = await this.opkIds();
    const oneTimePrekeys = [] as Array<{ id: number; pub: string }>;
    for (const id of ids) {
      const rec = jsonParse<OpkRecord>(await this.kv.get(opkKey(id)));
      if (rec?.pub) oneTimePrekeys.push({ id, pub: rec.pub });
    }

    // Combined PQ/SPK signature (design doc §3.1): IK_sig signs the classical
    // SPK pub AND the PQ prekey pub TOGETHER, binding the quantum prekey to
    // the classical identity. Legacy servers without the PQ columns ignore
    // the extra fields (additive wire change).
    const pqSignature = ed25519Sign(
      utf8Encode(PQ_SPK_SIG_PREFIX + spk.pub + pq!.pub),
      b64decode(identity.sig.priv),
    );

    const { ok } = await this.api('/api/e2ee/register', {
      method: 'POST',
      body: JSON.stringify({
        deviceId,
        identityDhPub: identity.dh.pub,
        identitySigPub: identity.sig.pub,
        signedPrekeyPub: spk.pub,
        prekeySignature: spk.sig,
        pqPrekeyPub: pq!.pub,
        pqPrekeySignature: b64encode(pqSignature),
        oneTimePrekeys,
      }),
    });
    if (!ok) throw new E2eeError('E2EE registration failed');

    identity.registered = true;
    await this.kv.set('identity', JSON.stringify(identity));
    return { registered: true };
  }

  async isRegistered(): Promise<boolean> {
    const identity = await this.loadIdentity();
    return !!identity?.registered;
  }

  /**
   * Server-side status; fires a background OPK replenish when the pool runs low.
   */
  async getStatus(): Promise<EngineStatus> {
    const { ok, body } = await this.api('/api/e2ee/status');
    if (!ok || !body) throw new E2eeError('failed to fetch E2EE status');
    const status: EngineStatus = { registered: !!body.registered, opkRemaining: Number(body.opkRemaining ?? 0) };
    if (status.registered && status.opkRemaining < OPK_MIN_BEFORE_REPLENISH) {
      // fire-and-forget; failures are harmless (next getStatus retries)
      void this.replenishOpks().catch(() => {});
    }
    return status;
  }

  /** POST a fresh OPK batch; ids are timestamp-anchored unique integers. */
  private async replenishOpks(): Promise<void> {
    const existing = await this.opkIds();
    const nowSec = Math.floor(Date.now() / 1000);
    const startId = Math.max(existing.length ? Math.max(...existing) + 1 : 0, nowSec);
    const batch = await this.generateOpks(OPK_REPLENISH_BATCH, startId);
    const { ok } = await this.api('/api/e2ee/prekeys', {
      method: 'POST',
      body: JSON.stringify({ oneTimePrekeys: batch }),
    });
    if (!ok) throw new E2eeError('OPK replenish failed');
  }

  /* ══ Sessions ══ */

  /** True if ANY session with this peer exists (any peer device, or legacy plain key). */
  async hasSession(peerId: string): Promise<boolean> {
    const prefix = `${legacySessionKey(peerId)}:`;
    const keys = await this.kv.keys();
    return keys.some((k) => k === legacySessionKey(peerId) || k.startsWith(prefix));
  }

  /** Clears the peer-device TTL cache (call after rekey events or for tests). */
  clearDeviceCache(peerId?: string): void {
    if (peerId) this.deviceCache.delete(peerId);
    else this.deviceCache.clear();
    this.invalidateKtVerdict(peerId);
  }

  /** P1-D: cache invalidation also invalidates the KT verdict (re-verify). */
  private invalidateKtVerdict(peerId?: string): void {
    if (peerId) resetKtVerdict(peerId);
    else resetKtVerdicts();
  }

  /**
   * Deletes ALL 'session:<peerId>:*' for the peer (every peer device) + the
   * legacy plain key + the per-device PQ-downgrade memories ('pqSeen:<peer>:*',
   * F9: deleting sessions is the documented user escape hatch that re-enables
   * a classical init after a PQ-hybrid session existed).
   */
  async deleteSession(peerId: string): Promise<void> {
    this.deviceCache.delete(peerId);
    const prefix = `${legacySessionKey(peerId)}:`;
    const pqPrefix = `${pqSeenKey(peerId, '')}`;
    const keys = await this.kv.keys();
    for (const k of keys) {
      if (k === legacySessionKey(peerId) || k.startsWith(prefix) || k.startsWith(pqPrefix)) {
        await this.kv.del(k);
      }
    }
  }

  /**
   * F8: has the send path EVER fallen back to plaintext for `peerId` because
   * the peer had no E2EE bundle (definitive 404 / registered:false)? The flag
   * persists until the next SUCCESSFUL encryption (which clears it) — the App
   * surfaces it as the "غير مشفرة طرف-لطرف" chat badge in place of the lock.
   */
  async wasDowngraded(peerId: string): Promise<boolean> {
    return (await this.kv.get(downgradedKey(peerId))) === '1';
  }

  /* ══ X3DH session init ══ */

  /**
   * Fetch the peer's bundle and normalize it to per-device entries. Supports
   * both the multi-device contract ({devices:[…]}) and the legacy flat bundle
   * (single implicit 'default' device) for pre-multi-device servers.
   */
  private async fetchPeerDevices(peerId: string, opts?: { bypassCache?: boolean }): Promise<PeerDevice[]> {
    if (!opts?.bypassCache) {
      const cached = this.deviceCache.get(peerId);
      if (cached && (Date.now() - cached.fetchedAt) < DEVICE_CACHE_TTL_MS) {
        return cached.devices;
      }
    }
    const { ok, status, body } = await this.api(`/api/e2ee/bundle/${encodeURIComponent(peerId)}`);
    if (!ok || !body?.registered) {
      // SECURITY: only a DEFINITIVE unregistered answer (HTTP 404, or an
      // explicit registered:false) may surface as PeerNotRegisteredError — the
      // send path treats that as a license to fall back to PLAINTEXT. A 429
      // (bundle endpoints are rate limited: 3 fetches/10 min per peer, 30/hour
      // overall) or a 5xx must fail CLOSED, otherwise normal chatting past the
      // rate limit — or an attacker deliberately draining the requester's
      // budget — silently downgrades E2EE to plaintext.
      if (status === 404 || (ok && body && body.registered === false)) {
        throw new PeerNotRegisteredError(`peer ${peerId} has no E2EE bundle`);
      }
      throw new E2eeError(`bundle fetch for ${peerId} failed (HTTP ${status})`);
    }
    let devices: PeerDevice[];
    if (Array.isArray(body.devices) && body.devices.length > 0) {
      devices = body.devices as PeerDevice[];
    } else {
      devices = [
        {
          deviceId: LEGACY_DEVICE_ID,
          identityDhPub: body.identityDhPub,
          identitySigPub: body.identitySigPub,
          signedPrekeyPub: body.signedPrekeyPub,
          prekeySignature: body.prekeySignature,
          opk: body.opk ?? null,
        },
      ];
    }
    // Server contract: 1..8 devices; iterate whatever is returned, cached for the TTL window.
    const capped = devices.slice(0, MAX_DEVICES);
    this.deviceCache.set(peerId, { devices: capped, fetchedAt: Date.now() });
    // P1-D (external-audit E2EE-08): remember the fleet for the synchronous
    // trust gate (ensureKtVerified) — verification is no longer purely
    // fire-and-forget.
    (this as any).ktFleets = (this as any).ktFleets || new Map<string, PeerDevice[]>();
    ((this as any).ktFleets as Map<string, PeerDevice[]>).set(peerId, capped);
    // F7 (audit): Key Transparency verification — the fleet we JUST fetched is
    // proven against the peer's signed transparency-log entry. FIRE-AND-FORGET
    // and best-effort by design (availability first): the bundle is NEVER
    // blocked or delayed by it — a verification CONTRADICTION (witness
    // signature / commitment / inclusion failure) raises the loud per-peer KT
    // flag ('ktFlag:<peer>', shown by the ChatWindow header badge) instead of
    // a lockout; transport failures and unverified-witness mode raise nothing
    // (documented honest modes, see kt-client.ts).
    void this.verifyFleetTransparency(peerId, capped).catch(() => {});
    return capped;
  }

  /**
   * F7 companion: verify the fetched fleet's KT proof and manage the per-peer
   * flag. Never throws (all failures already resolve inside
   * fetchAndVerifyFleetProof); never blocks the bundle (fire-and-forget).
   */
  private async verifyFleetTransparency(peerId: string, devices: PeerDevice[]): Promise<void> {
    try {
      const commitment = computeCommitment(
        devices.map((d) => ({
          deviceId: d.deviceId,
          identityDhPub: d.identityDhPub,
          identitySigPub: d.identitySigPub ?? '',
        })),
      );
      const result = await fetchAndVerifyFleetProofGated(peerId, commitment, () => this.authHeaders());
      if (!result.ok) {
        console.warn(
          `[KT] fleet proof verification FAILED for ${peerId}: ${result.reason ?? 'unknown'} — ` +
          'the bundle remains usable (availability first) but this peer is flagged for key-transparency tampering.',
        );
        setKtFlag(peerId);
        return;
      }
      // Clear a stale flag ONLY on a positively VERIFIED proof (signature +
      // inclusion both confirmed). Unverified/unavailable outcomes leave an
      // existing flag untouched — a server losing its witness key must not
      // silently wipe earlier tampering evidence.
      if (result.mode === 'verified' && result.signatureVerified) {
        clearKtFlag(peerId);
      }
    } catch (err) {
      console.warn('[KT] transparency verification error (bundle unaffected):', (err as Error)?.message ?? err);
    }
  }

  /**
   * Initiator, PER PEER DEVICE: verify that device's SPK signature, run X3DH
   * (DH1..DH4) against its SPK/OPK, and initialize an independent Double
   * Ratchet with an immediate sending-ratchet step. Sessions for different
   * peer devices are fully independent (separate EK, ratchet and chains).
   * Persists the session before returning (persist first, then send).
   *
   * PQXDH (design doc §3.2/§3.3): when the device's bundle advertises
   * `pq: true`, the exchange MUST be PQ-hybrid — the initiator encapsulates
   * against the device's ML-KEM-768 prekey (PQ_SS) and mixes it into the
   * HKDF IKM with the PQ info string ('DirashaX3DH-PQ-v1'). NO SILENT
   * DOWNGRADE: a pq:true device with missing/invalid PQ material, a failed
   * combined-signature verification or a failed encapsulation THROWS — the
   * device's envelope fails (encryptMessage skips it; the send fails only if
   * ALL devices fail). A classical fallback for a pq:true device never runs.
   * Devices advertising pq:false (or pre-PQ bundles without the field) take
   * the unchanged classical path.
   */
  private async initSessionAsInitiator(peerId: string, device: PeerDevice): Promise<SessionState> {
    const identity = await this.requireIdentity();

    const spkPubBytes = b64decode(device.signedPrekeyPub);
    const ikSigPubBytes = b64decode(device.identitySigPub);
    if (spkPubBytes.length !== KEY_BYTES || ikSigPubBytes.length !== KEY_BYTES) {
      throw new TamperedError('bundle public keys have invalid length');
    }
    const sigBytes = b64decode(device.prekeySignature);
    if (sigBytes.length !== 64 || !ed25519Verify(sigBytes, utf8Encode(SPK_SIG_PREFIX + device.signedPrekeyPub), ikSigPubBytes)) {
      throw new TamperedError('bundle SPK signature verification failed');
    }

    // PQ-hybrid gate: the bundle advertisement is the single source of truth.
    const isPq = device.pq === true;
    let pqCt: Uint8Array | null = null;
    let pqSs: Uint8Array | null = null;
    if (isPq) {
      if (typeof device.pqPrekeyPub !== 'string' || typeof device.pqPrekeySignature !== 'string') {
        throw new TamperedError('bundle advertises pq:true but PQ prekey material is missing');
      }
      const pqPubBytes = b64decode(device.pqPrekeyPub);
      const pqSigBytes = b64decode(device.pqPrekeySignature);
      if (pqPubBytes.length !== PQ_PUB_BYTES || pqSigBytes.length !== SIG_BYTES) {
        throw new TamperedError('bundle PQ prekey material has invalid length');
      }
      // CLIENT-side verification of the combined SPK+PQ signature (design doc
      // §3.4): the quantum prekey must be bound to the classical identity by
      // IK_sig — the server checks lengths only.
      const combined = utf8Encode(PQ_SPK_SIG_PREFIX + device.signedPrekeyPub + device.pqPrekeyPub);
      if (!ed25519Verify(pqSigBytes, combined, ikSigPubBytes)) {
        throw new TamperedError('bundle SPK+PQ combined signature verification failed');
      }
      // ML-KEM-768 encapsulation against the device's PQ prekey. A failure
      // here propagates (device skipped, fail closed) — never a classical
      // fallback for a pq:true device.
      const enc = pqEncapsulate(pqPubBytes);
      pqCt = enc.ct;
      pqSs = enc.ss;
    }

    const ek = generateX25519();
    const dh1 = x25519Shared(b64decode(identity.dh.priv), spkPubBytes);        // IK_A × SPK_B
    const dh2 = x25519Shared(ek.priv, b64decode(device.identityDhPub));        // EK_A × IK_B
    const dh3 = x25519Shared(ek.priv, spkPubBytes);                            // EK_A × SPK_B
    const hasOpk = !!(device.opk && typeof device.opk.pub === 'string');
    // Hybrid IKM (design doc §3.2): F || DH1..DH4 || PQ_SS — PQ_SS appended as
    // one extra block in the single HKDF-Extract input (documented Signal
    // PQXDH pattern).
    const ikm = concatBytes(
      hasOpk ? ZERO32 : FF32,
      hasOpk
        ? concatBytes(dh1, dh2, dh3, x25519Shared(ek.priv, b64decode(device.opk.pub)))  // EK_A × OPK_B
        : concatBytes(dh1, dh2, dh3),
      ...(pqSs ? [pqSs] : []),
    );
    const sk = isPq ? x3dhSkPq(ikm) : x3dhSk(ikm);

    // Initiator ratchet init (Signal X3DH+DR): DHr = SPK_B, immediate sending ratchet.
    const ratchet = generateX25519();
    const first = kdfRk(sk, x25519Shared(ratchet.priv, spkPubBytes));
    const session: SessionState = {
      rk: b64encode(first.rk),
      dhSelfPriv: b64encode(ratchet.priv),
      dhSelfPub: b64encode(ratchet.pub),
      dhRemote: device.signedPrekeyPub,
      ckS: b64encode(first.ck),
      ckR: null,
      nS: 0,
      nR: 0,
      pn: 0,
      skipped: {},
      ikSelf: identity.dh.pub,
      ikRemote: device.identityDhPub,
      pendingX3dh: {
        ek: b64encode(ek.pub),
        ...(device.opk && typeof device.opk.id === 'number' ? { opkId: device.opk.id } : {}),
        ...(pqCt ? { pqCt: b64encode(pqCt) } : {}),
      },
      ...(isPq ? { pq: true } : {}),
      createdAt: Date.now(),
    };
    await this.saveSession(peerId, device.deviceId, session);
    if (isPq) {
      // F9: PQ-establishment memory — from now on any classical-only init for
      // this device is rejected as a downgrade (see encryptMessage).
      await this.kv.set(pqSeenKey(peerId, device.deviceId), '1');
    }
    // P4 companion: this device's bundle OPK (if any) is now CONSUMED — its
    // priv is deleted on the responder once the bootstrap is confirmed used.
    // Drop the cached device list so a later session re-init (e.g. after
    // deleteSession or a store loss) can never re-consume the SAME consumed
    // OPK pub from the TTL cache — the server never re-offers consumed OPKs,
    // so the next fetch yields a fresh, still-held one. The cache is
    // repopulated on the next fetchPeerDevices (one extra bundle fetch on the
    // rare re-init path).
    this.deviceCache.delete(peerId);
    return session;
  }

  /**
   * Responder: rebuild SK from the envelope's x3dh block using our SPK/OPK
   * private keys. Pure builder — does NOT persist (the derivation is fully
   * deterministic from stored private keys + the envelope, so a failed or
   * interrupted decrypt leaves the store untouched and stays recomputable).
   *
   * PQXDH (design doc §3.2): an envelope with `pq: 1` was bootstrapped
   * PQ-hybrid — the responder decapsulates `pqCt` with its ML-KEM-768 prekey
   * priv and mixes PQ_SS into the same IKM position the initiator used, then
   * derives SK with the PQ info string. NO SILENT DOWNGRADE: a pq:1 envelope
   * with a missing local PQ priv, a wrong-size pqCt or ANY decapsulation
   * failure fails CLOSED (DecryptFailedError / TamperedError) — a classical
   * derivation is never substituted (a tampered pqCt decapsulates to a wrong
   * secret → wrong SK → the session AEAD fails, design doc §4 test 5).
   * Envelopes without pq:1 take the unchanged classical path.
   */
  private async buildResponderSession(peerId: string, env: Envelope): Promise<SessionState> {
    const identity = await this.requireIdentity();
    const spk = await this.loadSpk();
    if (!spk) throw new DecryptFailedError('our signed prekey is missing (re-registration?)');
    const x3 = env.x3dh!;

    const ekPubBytes = b64decode(x3.ek);
    if (ekPubBytes.length !== KEY_BYTES) throw new TamperedError('x3dh.ek is not a 32-byte key');

    const isPq = env.pq === 1;
    // BATCH-7 (Agent-B condition #2 — design resolution): the PQ downgrade
    // gate stays INITIATOR-SIDE ONLY (encryptMessage pqSeen check). A
    // responder-side gate breaks the DOCUMENTED legacy escape hatch
    // (tests/crypto-hardening h3: classical re-init after the peer's explicit
    // deleteSession must succeed — session-loss recovery). The residual
    // asymmetry Agent B flagged (a peer re-appearing classically under a NEW
    // deviceId) is bounded: it requires the peer's own keys, and the peer's
    // fleet advertisement remains the capability source. Recorded as a
    // documented design boundary in DIRASHA_CRYPTOGRAPHIC_RESIDUALS.md.
    let pqSs: Uint8Array | null = null;
    if (isPq) {
      if (typeof env.pqCt !== 'string') throw new TamperedError('pq envelope is missing pqCt');
      const pqCtBytes = b64decode(env.pqCt);
      if (pqCtBytes.length !== PQ_CT_BYTES) throw new TamperedError('pqCt is not an ML-KEM-768 ciphertext');
      const pq = await this.loadPqPrekey();
      if (!pq?.priv) throw new DecryptFailedError('our PQ prekey priv is missing (legacy device receiving a pq envelope)');
      pqSs = pqDecapsulate(pqCtBytes, b64decode(pq.priv));
    }

    // The OPK private record must be fetched BEFORE deriving (needed by the canonical-F ikm).
    let opkRecord: OpkRecord | null = null;
    if (x3.opkId !== undefined) {
      opkRecord = jsonParse<OpkRecord>(await this.kv.get(opkKey(x3.opkId)));
      if (!opkRecord?.priv) throw new DecryptFailedError(`one-time prekey ${x3.opkId} unknown locally (rekey?)`);
    }

    const dh1 = x25519Shared(b64decode(spk.priv), b64decode(env.ik));          // SPK_B × IK_A
    const dh2 = x25519Shared(b64decode(identity.dh.priv), ekPubBytes);         // IK_B × EK_A
    const dh3 = x25519Shared(b64decode(spk.priv), ekPubBytes);                 // SPK_B × EK_A
    const hasOpk = x3.opkId !== undefined;
    // Hybrid IKM mirrors the initiator EXACTLY: F || DH1..DH4 || PQ_SS.
    const ikm = concatBytes(
      hasOpk ? ZERO32 : FF32,
      hasOpk
        ? concatBytes(dh1, dh2, dh3, x25519Shared(b64decode(opkRecord.priv), ekPubBytes))   // OPK_B × EK_A
        : concatBytes(dh1, dh2, dh3),
      ...(pqSs ? [pqSs] : []),
    );
    const sk = isPq ? x3dhSkPq(ikm) : x3dhSk(ikm);

    // Responder ratchet init (Signal): DHs = SPK pair, DHr = none, chains empty;
    // the first DHRatchet happens while processing the initiator's envelope.
    const session: SessionState = {
      rk: b64encode(sk),
      dhSelfPriv: spk.priv,
      dhSelfPub: spk.pub,
      dhRemote: null,
      ckS: null,
      ckR: null,
      nS: 0,
      nR: 0,
      pn: 0,
      skipped: {},
      ikSelf: identity.dh.pub,
      ikRemote: env.ik,
      bootstrappedEk: x3.ek,
      ...(isPq ? { pq: true } : {}),
      createdAt: Date.now(),
    };
    return session;
  }

  /* ══ Double Ratchet internals (all mutate the CLONE only) ══ */

  /** Store skipped message keys for the current receiving chain up to `until`. */
  private static skipMessageKeys(s: SessionState, until: number): void {
    if (s.ckR === null) return;
    if (until <= s.nR) return;
    if (until - s.nR > MAX_SKIP) throw new DecryptFailedError(`skip ${until - s.nR} exceeds MAX_SKIP ${MAX_SKIP}`);
    while (s.nR < until) {
      const derived = kdfCk(b64decode(s.ckR!));
      s.skipped[`${s.dhRemote}:${s.nR}`] = b64encode(derived.mk);
      s.ckR = b64encode(derived.ck);
      s.nR++;
      const keys = Object.keys(s.skipped);
      if (keys.length > MAX_SKIP) delete s.skipped[keys[0]]; // oldest-eviction (insertion order)
    }
  }

  /** Signal's DHRatchet: derive new receiving chain, then rotate our DH key + sending chain. */
  private static dhRatchet(s: SessionState, newRemoteDh: string): void {
    s.pn = s.nS;
    s.nS = 0;
    s.nR = 0;
    s.dhRemote = newRemoteDh;
    const recv = kdfRk(b64decode(s.rk), x25519Shared(b64decode(s.dhSelfPriv), b64decode(newRemoteDh)));
    s.rk = b64encode(recv.rk);
    s.ckR = b64encode(recv.ck);
    // We received on this session — the X3DH bootstrap has been confirmed, stop
    // attaching it to outgoing envelopes.
    delete s.pendingX3dh;
    const next = generateX25519();
    s.dhSelfPriv = b64encode(next.priv);
    s.dhSelfPub = b64encode(next.pub);
    const send = kdfRk(recv.rk, x25519Shared(next.priv, b64decode(newRemoteDh)));
    s.rk = b64encode(send.rk);
    s.ckS = b64encode(send.ck);
  }

  /** Ratchet decrypt a single envelope against (possibly mutated) state `s`. */
  private static ratchetDecrypt(s: SessionState, env: Envelope): string {
    const { dh, pn, n } = env.hdr;
    const skippedKey = `${dh}:${n}`;

    let mk: Uint8Array;
    if (Object.prototype.hasOwnProperty.call(s.skipped, skippedKey)) {
      mk = b64decode(s.skipped[skippedKey]);
      delete s.skipped[skippedKey];
    } else {
      if (dh !== s.dhRemote) {
        DirashaE2EE.skipMessageKeys(s, pn);
        DirashaE2EE.dhRatchet(s, dh);
      }
      DirashaE2EE.skipMessageKeys(s, n);
      if (s.ckR === null) throw new SessionMissingError('no receiving chain for this message');
      const derived = kdfCk(b64decode(s.ckR));
      s.ckR = b64encode(derived.ck);
      s.nR++;
      mk = derived.mk;
    }

    // AAD built ONLY via aadString() — identical construction on encrypt & decrypt
    // (grep AAD_TEMPLATE for the single source constant).
    const aad = utf8Encode(aadString(env.v, env.ik, env.hdr.dh, env.hdr.pn, env.hdr.n));
    let plaintext: Uint8Array;
    try {
      plaintext = aeadOpen(mk, b64decode(env.iv), b64decode(env.ct), aad);
    } catch {
      throw new TamperedError('AEAD verification failed');
    }
    // Project 6: remove size-bucket padding when the sender marked it
    const finalBytes = isPadded(env.p) ? unpadFromBucket(plaintext) : plaintext;
    return utf8Decode(finalBytes);
  }

  /* ══ Public messaging API ══ */

  /**
   * Encrypt `plaintext` for `peerId`, fanning out to EVERY device in the
   * peer's bundle (server contract: 1..8 devices).
   *
   * Per peer device: ensure an INDEPENDENT session 'session:<peerId>:<deviceId>'
   * (full X3DH as initiator on first send), then ratchet-encrypt. A device
   * whose session init/encrypt fails (e.g. broken SPK signature) is SKIPPED —
   * encryptMessage fails only if ALL device envelopes fail.
   *
   * Wire format:
   *   1 device  → legacy 'DIR1:' + b64(envelope JSON) (full backward compat)
   *   >1 device → 'DIRM1:' + b64({ v:1, devices:[{ d:<deviceId>, env:<envelope> }] })
   *
   * Every envelope carries `sd` = OUR deviceId. Throws PeerNotRegisteredError
   * when the peer has no bundle at all.
   */
  /**
   * P1-D (external-audit E2EE-08): SYNCHRONOUS KT trust gate — no peer bundle
   * is used for encryption until the fleet proof is VERIFIED (witness-signed
   * snapshot + inclusion). Enforcement is ON whenever a witness public key is
   * pinned (VITE_KT_ENFORCE=0 is the documented escape hatch). Unverified or
   * unknown peers fail closed with KT_UNVERIFIED_PEER.
   */
  private async ensureKtVerified(peerId: string): Promise<void> {
    if (!isKtEnforced()) return;
    const v = getPeerKtVerification(peerId);
    if (!v.known || (v.known && !v.verified)) {
      // First contact OR stale verdict: fetch + verify BEFORE any bundle use
      // (strict gate — the audit's exact requirement). PeerNotRegisteredError
      // passes through untouched (F8 downgrade flow owns that path).
      try {
        const devices = await this.fetchPeerDevices(peerId);
        try { await this.verifyFleetTransparency(peerId, devices); } catch { /* gated wrapper recorded the verdict */ }
      } catch (err) {
        if (err instanceof PeerNotRegisteredError) throw err;
        throw new E2eeError('KT_UNVERIFIED_PEER: transparency proof unavailable/failed — send blocked (fail-closed).');
      }
      const after = getPeerKtVerification(peerId);
      if (!after.known || !after.verified) {
        throw new E2eeError('KT_UNVERIFIED_PEER: transparency proof unavailable/failed — send blocked (fail-closed).');
      }
    }
  }

  async encryptMessage(peerId: string, plaintext: string, opts?: { chunked?: boolean }): Promise<{ content: string; contents?: string[] }> {
    await this.ensureKtVerified(peerId);
    if (typeof plaintext !== 'string') throw new TypeError('plaintext must be a string');
    if (!peerId) throw new TypeError('peerId must be a non-empty string');

    const identity = await this.requireIdentity();
    const myDeviceId = await this.ensureDeviceId(identity);
    let devices: PeerDevice[];
    try {
      devices = await this.fetchPeerDevices(peerId);
    } catch (err) {
      if (err instanceof PeerNotRegisteredError) {
        // F8 (audit): a DEFINITIVE peer-unregistered answer licenses the send
        // path to fall back to plaintext — but it must not happen SILENTLY.
        // Persist the per-peer downgrade memory (cleared on the next
        // successful encryption below) so the UI can surface the
        // "غير مشفرة طرف-لطرف" badge for as long as the conversation rides
        // plaintext. Scope: ONLY the peer-bundle 404/registered:false case —
        // a missing LOCAL identity (requireIdentity) is a different failure
        // and must not mark the peer as unregistered.
        await this.kv.set(downgradedKey(peerId), '1');
      }
      throw err;
    }

    const entries: Array<{ d: string; env: Envelope }> = [];
    let lastError: unknown = null;
    for (const device of devices) {
      try {
        let session = await this.loadSession(peerId, device.deviceId);
        if (!session) {
          // F9 (audit): client-enforced PQ downgrade protection beyond the
          // server's announcement. This device previously established a
          // PQ-hybrid session (pqSeen memory) and the CURRENT bundle derives
          // classical-only (pq:false) → that device's envelope is REJECTED.
          // The ratchet state may have been lost (store wipe / cleared
          // IndexedDB), but the memory survives — a fresh classical bootstrap
          // against a device we have already run PQXDH with is tampering
          // evidence, not a legacy upgrade. Escape hatch: the explicit user
          // actions deleteSession()/emergencyRotate() clear the memory.
          if (device.pq !== true && (await this.kv.get(pqSeenKey(peerId, device.deviceId))) === '1') {
            throw new TamperedError(
              'pq downgraded — this device previously established a PQ-hybrid (quantum-safe) session ' +
              'and the current bundle advertises classical-only keys. Delete the session explicitly to accept classical keys.',
            );
          }
          session = await this.initSessionAsInitiator(peerId, device);
        }
        const env = await this.encryptWithSession(peerId, device.deviceId, session, plaintext, myDeviceId);
        entries.push({ d: device.deviceId, env });
      } catch (err) {
        // Offline / broken-device tolerance: skip this device's envelope.
        lastError = err;
      }
    }

    if (entries.length === 0) {
      if (lastError instanceof E2eeError) throw lastError;
      throw new E2eeError(lastError ? 'failed to encrypt for any peer device' : 'no peer devices to encrypt for');
    }

    // F8: a SUCCESSFUL encryption clears the plaintext-downgrade memory — the
    // conversation is provably E2EE again (the App badge disappears).
    await this.kv.del(downgradedKey(peerId));

    if (entries.length === 1) {
      const single = WIRE_PREFIX + b64encode(utf8Encode(JSON.stringify(entries[0].env)));
      return opts?.chunked ? { content: single, contents: [single] } : { content: single };
    }
    if (opts?.chunked) {
      // Chunked mode: ONE small DIR1 envelope per target device — multi-KB
      // DIRM1 fan-outs were silently dropped in transit (~8KB transport
      // ceiling, live-battery finding). Each chunk decrypts independently.
      return {
        content: WIRE_PREFIX + b64encode(utf8Encode(JSON.stringify(entries[0].env))),
        contents: entries.map((e) => WIRE_PREFIX + b64encode(utf8Encode(JSON.stringify(e.env)))),
      };
    }
    const multi: MultiEnvelope = { v: WIRE_VERSION, devices: entries };
    return { content: WIRE_PREFIX_MULTI + b64encode(utf8Encode(JSON.stringify(multi))) };
  }

  /**
   * Ratchet-encrypt `plaintext` on an existing per-device session
   * (derive-then-commit: persist only after a successful seal).
   */
  private async encryptWithSession(
    peerId: string,
    peerDeviceId: string,
    session: SessionState,
    plaintext: string,
    myDeviceId: string,
  ): Promise<Envelope> {
    // Derive-then-commit: mutate the clone, persist only when done.
    const s = cloneSession(session);
    if (s.ckS === null) {
      if (!s.dhRemote) throw new SessionMissingError('cannot encrypt without a remote ratchet key');
      const next = generateX25519();
      const send = kdfRk(b64decode(s.rk), x25519Shared(next.priv, b64decode(s.dhRemote)));
      s.rk = b64encode(send.rk);
      s.ckS = b64encode(send.ck);
      s.dhSelfPriv = b64encode(next.priv);
      s.dhSelfPub = b64encode(next.pub);
      s.pn = s.nR;
      s.nS = 0;
    }

    const derived = kdfCk(b64decode(s.ckS));
    s.ckS = b64encode(derived.ck);
    const n = s.nS++;
    const iv = randomBytes(NONCE_BYTES);
    const hdr = { dh: s.dhSelfPub, pn: s.pn, n };
    const aad = utf8Encode(aadString(WIRE_VERSION, s.ikSelf, hdr.dh, hdr.pn, hdr.n));
    // Project 6: pad to a size bucket BEFORE sealing — ciphertext lengths leak
    // only the bucket, never the true length. Padding rides inside the AEAD.
    const padded = padToBucket(utf8Encode(plaintext));
    const ct = aeadSeal(derived.mk, iv, padded, aad);

    const env: Envelope = {
      v: WIRE_VERSION,
      ik: s.ikSelf,
      hdr,
      iv: b64encode(iv),
      ct: b64encode(ct),
      sd: myDeviceId,
      p: PAD_FLAG,
    };
    // Attach the X3DH bootstrap to EVERY outgoing message until the first inbound
    // message confirms the session — otherwise an out-of-order delivery of message
    // #3 before message #1 could not bootstrap the responder's session.
    if (s.pendingX3dh && s.ckR === null) {
      // PQXDH (design doc §3.3): the envelope documents its hybrid session —
      // pq:1 rides every bootstrap-carrying message until the responder
      // confirms (pendingX3dh cleared), with the ML-KEM ciphertext in the
      // ENVELOPE-level pqCt. The x3dh block itself stays PQ-free on the wire:
      // duplicating the 1088B ciphertext inside the block would add ~1.9KB
      // wire per device to every bootstrap fan-out. The pqCt inside the
      // persisted pendingX3dh is SESSION-LOCAL state only and is stripped
      // from the wire copy here (JSON.stringify drops the undefined field).
      env.x3dh = { ...s.pendingX3dh, pqCt: undefined };
      if (s.pendingX3dh.pqCt) {
        env.pq = 1;
        env.pqCt = s.pendingX3dh.pqCt;
      }
    }
    // Persist BEFORE "sending" (returning the envelope) per spec.
    await this.saveSession(peerId, peerDeviceId, s);
    return env;
  }

  /**
   * Decrypt `content`. Non-E2EE content passes through untouched.
   * Handles both the legacy single envelope ('DIR1:') and the multi-device
   * container ('DIRM1:'). Failures NEVER throw — they return
   * { error: '<ErrorName>' } so the receive path can render a placeholder +
   * keep the raw ciphertext.
   *
   * Session routing:
   *   - 'DIR1:' with sd → 'session:<peerId>:<sd>'; without sd (legacy sender)
   *     → 'session:<peerId>:default'.
   *   - 'DIRM1:' → the envelope addressed to OUR deviceId (mixed-version
   *     tolerance: a lone envelope is used even when it is not addressed to us);
   *     session keyed by the SENDER device ('…:<env.sd>').
   *   - A miss for '…:default' falls back to the legacy plain key
   *     'session:<peerId>' and is written back under the suffixed key on
   *     success (lazy migration).
   *
   * Atomicity: every ratchet mutation happens on a clone; the store is touched
   * only after the AEAD tag verifies (derive-then-commit). If the message
   * carries an X3DH bootstrap and the existing session cannot decrypt it
   * (peer re-registered / fresh bootstrap after our session loss), we retry
   * on a freshly derived responder session — again committed only on success.
   * Mutual X3DH init (BOTH peers sent first messages concurrently) is resolved
   * by a deterministic KEEPER/ADOPTER tie-break on the identity keys — see the
   * comment inside decryptEnvelope.
   */
  async decryptMessage(peerId: string, content: string): Promise<DecryptResult> {
    if (typeof content !== 'string') return { error: 'DecryptFailedError' };
    if (content.startsWith(WIRE_PREFIX_MULTI)) return this.decryptMultiDevice(peerId, content);
    if (!content.startsWith(WIRE_PREFIX)) return { plaintext: content };

    try {
      const env = parseEnvelope(content);
      // Legacy senders omit sd → 'default' (which also triggers the plain-key fallback).
      const senderDevice = typeof env.sd === 'string' && env.sd ? env.sd : LEGACY_DEVICE_ID;
      return await this.decryptEnvelope(peerId, env, senderDevice);
    } catch (err) {
      if (err instanceof E2eeError) return { error: err.name };
      return { error: 'DecryptFailedError' };
    }
  }

  /** DIRM1 container: pick the envelope for OUR device, then decrypt per sender device. */
  private async decryptMultiDevice(peerId: string, content: string): Promise<DecryptResult> {
    try {
      const multi = parseMultiEnvelope(content);
      const identity = await this.requireIdentity();
      const myDeviceId = identity.deviceId ?? LEGACY_DEVICE_ID;
      let entry = multi.devices.find((e) => e.d === myDeviceId);
      // Mixed-version tolerance: an old single-device peer may wrap a lone
      // envelope without knowing our deviceId.
      if (!entry && multi.devices.length === 1) entry = multi.devices[0];
      if (!entry) throw new SessionMissingError('no envelope addressed to this device');
      const env = validateEnvelope(entry.env);
      const senderDevice = typeof env.sd === 'string' && env.sd ? env.sd : LEGACY_DEVICE_ID;
      return await this.decryptEnvelope(peerId, env, senderDevice);
    } catch (err) {
      if (err instanceof E2eeError) return { error: err.name };
      return { error: 'DecryptFailedError' };
    }
  }

  /**
   * Identity-currency check (E1): a bootstrap-carrying envelope (env.x3dh) is
   * session-defining, so env.ik must match the peer's CURRENTLY REGISTERED
   * identity keys for the sending device — not just the keys recorded in our
   * (possibly stale) session. Fetches the peer's key directory (per-device
   * identities; legacy flat bundles map to the implicit 'default' device).
   *
   * Failure semantics:
   *   - definitive mismatch (registered ik for env.sd differs from env.ik, or
   *     a legacy envelope matches NO registered device) → RekeyDetectedError —
   *     pre-rekey traffic must NEVER be accepted as authentic post-rekey;
   *   - the sending device is no longer registered → RekeyDetectedError;
   *   - transport failure / rate limit (429/5xx/network) → returns false and
   *     the caller FAILS OPEN (availability: never block normal traffic on a
   *     currency probe; the mismatch case above remains protected).
   *
   * Cost note: the directory fetch consumes ONE of the peer's OPKs per device
   * — this is why the check runs ONLY on bootstrap-carrying envelopes, which
   * are rare (once per sender session, until the receiver replies).
   */
  private async verifyIdentityCurrency(peerId: string, env: Envelope): Promise<boolean> {
    let cur: Map<string, string> | null = null;
    try {
      const devices = await this.fetchPeerDevices(peerId, { bypassCache: true }); // currency = freshness: never trust the cache here
      const map = new Map<string, string>();
      for (const d of devices) {
        if (d && typeof d.deviceId === 'string' && typeof d.identityDhPub === 'string') {
          map.set(d.deviceId, d.identityDhPub);
        }
      }
      cur = map;
    } catch {
      return true; // transport/rate-limit failure — fail open (availability)
    }
    if (cur.size === 0) return true;
    const hasSd = typeof env.sd === 'string' && env.sd.length > 0;
    if (hasSd) {
      const registered = cur.get(env.sd!);
      return registered === undefined ? false : registered === env.ik;
    }
    // Legacy envelope (no sd): authentic if ANY currently-registered device
    // advertises this identity.
    return [...cur.values()].includes(env.ik);
  }

  /** Core per-envelope decrypt against the (peerId, senderDevice) session. */
  private async decryptEnvelope(peerId: string, env: Envelope, senderDevice: string): Promise<DecryptResult> {
    const session = await this.loadSession(peerId, senderDevice);

    // E1/E2: bootstrap-carrying envelopes are session-defining — verify env.ik
    // against the peer's CURRENT registration before anything else. This catches
    // pre-rekey traffic on a still-intact session AND pre-rekey bootstrap
    // replays (with or without a live session).
    if (env.x3dh && !(await this.verifyIdentityCurrency(peerId, env))) {
      throw new RekeyDetectedError('peer identity changed — envelope identity is not currently registered');
    }

    if (session) {
      if (env.ik !== session.ikRemote && !env.x3dh) {
        throw new RekeyDetectedError('peer identity changed — rekey needed');
      }
      if (env.ik === session.ikRemote) {
        const s = cloneSession(session);
        try {
          const plaintext = DirashaE2EE.ratchetDecrypt(s, env);
          // Always written to the SUFFIXED key: a successful decrypt on a
          // legacy plain-key session migrates it lazily.
          await this.saveSession(peerId, senderDevice, s);
          return { plaintext };
        } catch (err) {
          if (!env.x3dh) throw err;
          // fall through: try the message's own X3DH bootstrap on a fresh session
        }
      }
    }

    if (!env.x3dh) {
      throw new SessionMissingError(`no session with ${peerId} and message carries no X3DH bootstrap`);
    }

    // ── Mutual X3DH init desync: deterministic KEEPER/ADOPTER tie-break ──────
    // When BOTH peers sent their first messages concurrently, each envelope
    // carries its own X3DH bootstrap. Without a tie-break, each side's first
    // inbound bootstrap REPLACES its own un-confirmed initiator session
    // (ckR === null + pendingX3dh — the bootstrappedEk replay guard cannot
    // fire, initiator sessions never set it), leaving the pair bound to two
    // DIFFERENT bootstrap generations: every subsequent message fails AEAD in
    // BOTH directions, permanently.
    //
    // Fix — compare MY identity DH pub against env.ik lexicographically:
    //   - MY ik SMALLER (or equal — impossible, distinct keys) → KEEPER: keep
    //     the un-confirmed initiator session intact (do NOT rebuild, do NOT
    //     mutate) and drop the inbound bootstrap ({error: DecryptFailedError}
    //     → UI placeholder). The peer (ADOPTER) rebuilds as responder on OUR
    //     bootstrap generation, which was already delivered as message #1.
    //     Exactly one message (the adopter's discarded first message) is lost
    //     in this rare race — acceptable and by design.
    //   - MY ik LARGER → ADOPTER: discard the un-confirmed initiator session
    //     entirely and rebuild as responder from the inbound bootstrap via the
    //     normal flow below. ALL existing guards still run (the identity-
    //     currency check above passes because the adopted bootstrap is the
    //     winner's CURRENT bootstrap); subsequent sends automatically use the
    //     adopted responder session once the old session key is deleted.
    //
    // Scope: the tie-break applies ONLY to the mutual-init shape — an
    // UN-CONFIRMED initiator session (ckR === null + pendingX3dh) of the SAME
    // identity generation (env.ik === session.ikRemote). Every other case
    // (no session, confirmed sessions, cross-generation rekey recovery) keeps
    // the existing behavior unchanged.
    //
    // Generation-viability valve: the keeper may keep its generation only
    // while the peer can still ADOPT it — a fresh adopter rebuilds at our
    // current chain position and must stay within MAX_SKIP. Once the
    // un-confirmed initiator has sent more than MAX_SKIP messages without
    // confirmation, its bootstrap generation is unreachable for any fresh
    // adopter, and the peer's fresh bootstrap (e.g. the documented
    // session-loss re-init recovery) is the only viable way forward — adopt
    // it regardless of the ik comparison.
    let adoptPendingSession = false;
    if (session && env.ik === session.ikRemote && session.ckR === null && !!session.pendingX3dh) {
      const identity = await this.requireIdentity();
      const cmp = compareBytes(b64decode(identity.dh.pub), b64decode(env.ik));
      const generationAdoptable = session.nS <= MAX_SKIP;
      if (cmp <= 0 && generationAdoptable) {
        // KEEPER: record the rejected bootstrap's ek in the dropped-bootstrap
        // ledger (a SEPARATE kv key — the session itself stays untouched) so a
        // later replay / late delivery of this same bootstrap can never
        // rebuild the abandoned generation over the now-healthy session.
        await this.recordDroppedX3dh(peerId, senderDevice, env.x3dh.ek);
        throw new DecryptFailedError(
          'mutual X3DH init: this side keeps its initiator session (deterministic tie-break) — the peer bootstrap is dropped',
        );
      }
      // ADOPTER (ik larger) — or the keeper's own generation has grown
      // unadoptable (nS > MAX_SKIP) so the peer's fresh bootstrap is the only
      // recovery: discard the un-confirmed initiator session. The old session
      // key is deleted at commit time (below, AFTER the AEAD verifies —
      // derive-then-commit atomicity preserved).
      adoptPendingSession = true;
    }
    // Replay-rollback guard (same identity generation): an envelope carrying
    // the SAME ephemeral key this session was bootstrapped with, but failing
    // ratchet decryption, is a REPLAY of the session's first message. Rebuilding
    // a responder session from it would deterministically re-derive the original
    // SK and roll the ratchet chain back (previously-consumed chain messages
    // become decryptable again — and, once the peer has replied, the
    // rolled-back state can never resync, killing the stream in BOTH
    // directions). Fail closed instead.
    if (session && env.ik === session.ikRemote && session.bootstrappedEk === env.x3dh.ek) {
      throw new TamperedError('replayed X3DH bootstrap — session rollback attempt');
    }
    // Same-identity cross-generation replay guard (P4 companion): an ek the
    // CURRENT session's identity generation already trusted and then replaced
    // is provably an OLDER bootstrap — rebuilding from it would roll the
    // ratchet back. Rejected BEFORE any key material is read, so it fails
    // closed even when that generation's OPK priv was already deleted
    // (confirmed use) or lingers in the crash window between persist and
    // delete.
    if (session && env.ik === session.ikRemote && Array.isArray(session.retiredEks) && session.retiredEks.includes(env.x3dh.ek)) {
      throw new TamperedError('replayed X3DH bootstrap from a retired generation — session rollback attempt');
    }
    // Stale-identity guard (cross-generation rollback): when an existing
    // session knows a DIFFERENT identity for this peer, the bootstrap may be
    // either (a) the peer's legit NEW identity after a rekey, or (b) a replay
    // of a PRE-rekey bootstrap. Distinguish WITHOUT a server round trip via
    // the retired-generation ledger: any ik this session (per peer+sender
    // device) has ALREADY trusted and later replaced is provably an OLDER
    // generation — rebuilding from it would resurrect pre-rekey ratchet state
    // and re-enable pre-rekey ciphertext after the peer rekeyed. Fail with
    // RekeyDetectedError instead. Genuinely NEW generations (never trusted)
    // still rebuild — and can only be forged by the peer's own keys, because
    // the rebuild is persisted only after the AEAD verifies against our SPK.
    if (session && env.ik !== session.ikRemote && Array.isArray(session.retiredIks) && session.retiredIks.includes(env.ik)) {
      throw new RekeyDetectedError('peer identity changed — stale pre-rekey bootstrap rejected');
    }
    // Dropped-bootstrap ledger: an ek the deterministic KEEPER already refused
    // (mutual-init tie-break above) belongs to the ADOPTER's DISCARDED
    // initiator generation — rebuild from it would bind this side to a dead
    // bootstrap generation while the peer runs on ours. Fail closed.
    if ((await this.getDroppedX3dh(peerId, senderDevice)).includes(env.x3dh.ek)) {
      throw new TamperedError('replayed X3DH bootstrap previously rejected by the deterministic tie-break');
    }
    const fresh = await this.buildResponderSession(peerId, env);
    const s2 = cloneSession(fresh);
    // Retire the generation this rebuild replaces (derive-then-commit: the
    // clone is discarded if the AEAD below fails, so a failed rebuild never
    // records a retirement).
    if (session && env.ik !== session.ikRemote) {
      s2.retiredIks = [...new Set([...(session.retiredIks ?? []), session.ikRemote])].slice(-4);
    }
    // Same-identity rebuild: retire the PREVIOUS bootstrap ek so a later
    // replay of that older generation's first message is rejected by the
    // retiredEks guard above (never reaching buildResponderSession, whose
    // OPK priv may already be gone — P4 confirmed-use deletion).
    if (session && session.bootstrappedEk && session.bootstrappedEk !== env.x3dh.ek) {
      s2.retiredEks = [...new Set([...(session.retiredEks ?? []), session.bootstrappedEk])].slice(-4);
    }
    const plaintext = DirashaE2EE.ratchetDecrypt(s2, env);
    if (adoptPendingSession) {
      // ADOPTER commit: the un-confirmed initiator session is discarded in
      // favor of the adopted responder session written right after (same kv
      // key). Deleting only after the AEAD verified keeps the derive-then-
      // commit atomicity; the legacy plain-key shadow is cleared too when the
      // old session was read from it.
      await this.kv.del(sessionKey(peerId, senderDevice));
      if (senderDevice === LEGACY_DEVICE_ID) await this.kv.del(legacySessionKey(peerId));
    }
    await this.saveSession(peerId, senderDevice, s2);
    if (s2.pq) {
      // F9: responder-side PQ-establishment memory — the bootstrap AEAD just
      // verified against a PQ-hybrid derivation, so this (peer, sender device)
      // is bound to quantum-safe keys from now on (see encryptMessage).
      await this.kv.set(pqSeenKey(peerId, senderDevice), '1');
    }
    // ── P4: consumed one-time prekey priv cleanup ────────────────────────────
    // The OPK priv for this bootstrap is now CONFIRMED USED: (a) the AEAD
    // verification of the bootstrap message succeeded, (b) the responder
    // session was derived, and (c) that session state was PERSISTED above.
    // Ordering is deliberate — persist-session-then-delete-priv: a crash in
    // between leaves a harmless leftover priv (the server marked the OPK
    // consumed atomically at bundle time, so it is never re-offered; a
    // re-delivered bootstrap is rejected by the bootstrappedEk replay guard
    // ABOVE, before any key material is read, so the priv is never reused).
    //
    // Scope: ONLY the bootstrap's own OPK priv is deleted, and ONLY on this
    // fresh-responder path — the identity keys ('identity') and the signed
    // prekey priv ('spkPriv', still active for future handshakes) are never
    // touched, and privs of OPKs not yet consumed by any delivered bootstrap
    // stay until they are confirmed used. Retention-cap decision: NO oldest-
    // eviction cap is implemented, because the client cannot verify the
    // server-side consumed flag for its own OPK ids (the status endpoint
    // exposes only a remaining count) — evicting an unconsumed priv could
    // strand a future bootstrap that legitimately references that id. The
    // strict "delete on confirmed use only" policy keeps every removable
    // priv removable while never removing one that is still needed. This is
    // the single deletion point for BOTH wire paths (DIR1 and the DIRM1
    // multi-device container) — decryptEnvelope is shared by decryptMessage
    // and decryptMultiDevice.
    //
    // Best-effort: a failed delete must not turn a successful decrypt into a
    // user-visible error; the leftover priv is harmless (see above).
    const usedOpkId = env.x3dh?.opkId;
    if (usedOpkId !== undefined) {
      try {
        await this.kv.del(opkKey(usedOpkId));
      } catch {
        /* leftover OPK priv is harmless — never reused after confirmed use */
      }
    }
    return { plaintext };
  }

  /* ══ Emergency rotation (Project 10) ══ */

  /**
   * EMERGENCY KEY ROTATION — "تدوير مفاتيح الطوارئ".
   *
   * Called when the user suspects their device keys were compromised. In one
   * operation it:
   *   1. Wipes ALL ratchet sessions ('session:*' keys — both the suffixed
   *      multi-device keys and the legacy plain keys) plus the dropped-bootstrap
   *      ledgers ('x3dh-dropped:*'). No pre-rotation session may survive.
   *   2. Generates a COMPLETELY NEW identity (fresh IK_dh + IK_sig), a new SPK
   *      signed by the new IK_sig, and a fresh pool of 100 OPKs. ALL old OPK
   *      privs ('opk:<id>') are deleted first — no pre-rotation private key
   *      material survives. Any legacy identity-backup copies are removed too.
   *   3. Re-registers to the server with the SAME deviceId (upsert). The
   *      server's re-registration path detects the identity change
   *      (src/server/routes/e2ee.ts: prevIdentity !== identityDhPub for the
   *      same device row) and proactively publishes 'e2ee:rekey' to every DM
   *      partner — the client listener (App.tsx 'e2ee:rekey') then deletes the
   *      stale peer session and raises the warning banner.
   *
   * CRASH SAFETY (persist BEFORE any network call): steps 1–2 complete and are
   * fully persisted BEFORE the registration POST is attempted. If the process
   * dies (or registration fails) after step 2, the device's LOCAL state is
   * already the new identity with `registered: false`. This mid-failure state
   * SELF-HEALS: registration is an idempotent upsert per (userId, deviceId),
   * so the next ensureRegistered() call — retried automatically on every
   * login / auth:ready / token refresh, or by the user re-running the feature —
   * completes the server registration with the same deviceId. Only after the
   * server confirms (HTTP 200) does the identity flip to registered:true and
   * does this method return success; on failure it THROWS (E2eeError) and the
   * caller shows a failure toast — but the local rotation is never rolled back
   * (rolling back would resurrect the possibly-compromised keys).
   *
   * Concurrency: serialized behind its own in-flight singleton (same pattern
   * as ensureRegistered) — concurrent callers share one rotation. The final
   * registration is routed through the shared ensureRegistered() singleton so
   * concurrent login-path registrations dedupe into the same POST.
   *
   * Note on server-side OPK ids: the fresh pool is timestamp-anchored
   * (startId = max(nowSec, 1)) so new key ids can never collide with consumed
   * server rows from the old identity (the register endpoint deletes only
   * UNCONSUMED old OPKs and skips colliding ids).
   */
  async emergencyRotate(): Promise<{ newIdentity: boolean }> {
    if (this.rotationInFlight) return this.rotationInFlight;
    this.rotationInFlight = this.emergencyRotateInternal().finally(() => {
      this.rotationInFlight = null;
    });
    return this.rotationInFlight;
  }

  private async emergencyRotateInternal(): Promise<{ newIdentity: boolean }> {
    // ── Local replacement FIRST (no network touched yet) ─────────────────────

    // 1. Wipe ALL sessions ('session:*' — suffixed + legacy plain) and the
    //    dropped-bootstrap ledgers. Sessions are useless after rotation: the
    //    old ratchet state is bound to the old identity generation.
    //    F9: the PQ-downgrade memories ('pqSeen:*') are wiped too — the
    //    documented explicit-user escape hatch (rotation re-arms the fresh
    //    identity for whatever key type the peers currently advertise).
    const allKeys = await this.kv.keys();
    for (const k of allKeys) {
      if (k.startsWith('session:') || k.startsWith('x3dh-dropped:') || k.startsWith('pqSeen:')) {
        await this.kv.del(k);
      }
    }

    // 2a. Generate the completely new identity keys (IK_dh + IK_sig). The SAME
    //     deviceId is reused (or freshly assigned when the old identity lacked
    //     one) so the server replaces THIS device's row only — which is what
    //     makes its re-registration path detect the identity change and push
    //     'e2ee:rekey' to DM partners.
    const old = await this.loadIdentity();
    const deviceId = old?.deviceId && typeof old.deviceId === 'string' && old.deviceId
      ? old.deviceId
      : randomDeviceId();
    const dh = generateX25519();
    const sig = generateEd25519();
    const identity: IdentityRecord = {
      dh: { priv: b64encode(dh.priv), pub: b64encode(dh.pub) },
      sig: { priv: b64encode(sig.priv), pub: b64encode(sig.pub) },
      registered: false, // force the next ensureRegistered() to (re)register
      deviceId,
    };
    // CRASH-SAFETY ORDERING: identity → SPK → OPK wipe → OPK pool. From the
    // moment 'identity' is written the device IS the new identity; everything
    // below only completes or invalidates key material, never resurrects the old.
    await this.kv.set('identity', JSON.stringify(identity));

    // 2b. New SPK signed by the NEW IK_sig, persisted immediately.
    const spk = generateX25519();
    const spkSig = ed25519Sign(utf8Encode(SPK_SIG_PREFIX + b64encode(spk.pub)), b64decode(identity.sig.priv));
    await this.kv.set('spkPriv', JSON.stringify({ priv: b64encode(spk.priv), pub: b64encode(spk.pub), sig: b64encode(spkSig) }));

    // 2c. Delete ALL old OPK privs (fresh pool replaces the old one outright),
    //     the ML-KEM-768 PQ prekey priv (PQXDH: regenerated with the new
    //     identity by the re-registration below), then any legacy
    //     identity-record backup copies if present (none are
    //     written by current code; wiped defensively for older stores).
    for (const k of allKeys) {
      if (k.startsWith('opk:') || k === 'identity-backup' || k === 'identityBackup' || k === PQ_PREKEY_KV) {
        await this.kv.del(k);
      }
    }

    // 2d. Fresh pool of 100 OPKs, timestamp-anchored ids (see jsdoc). Each
    //     priv is persisted BEFORE its pub is advertised (generateOpks).
    await this.generateOpks(OPK_COUNT_ON_REGISTER, Math.max(Math.floor(Date.now() / 1000), 1));

    // ── Network re-registration (AFTER local state is fully persisted) ───────
    // Clear the device cache: every peer fleet must be re-fetched fresh.
    this.clearDeviceCache();
    // Route the registration through the shared ensureRegistered() singleton:
    // identity.registered === false, so it POSTs /api/e2ee/register with the
    // SAME deviceId and flips to registered:true only on HTTP 200. Concurrent
    // ensureRegistered() callers (login/auth:ready/token-refresh) share this
    // exact POST instead of racing a second one. One immediate retry covers a
    // transient network blip; a persistent failure throws (see jsdoc — the
    // state self-heals on the next login-path ensureRegistered()).
    try {
      await this.ensureRegistered();
    } catch (err) {
      try {
        await this.ensureRegistered();
      } catch {
        throw err instanceof E2eeError
          ? err
          : new E2eeError(`emergency rotation registration failed: ${(err as Error)?.message ?? 'unknown'}`);
      }
    }
    return { newIdentity: true };
  }

  /* ══ Safety number ══ */

  /** GET /api/e2ee/identity/:userId → the account's PRIMARY (oldest) identity DH pub. */
  private async fetchPrimaryIdentityPub(userId: string): Promise<string> {
    const { ok, body } = await this.api(`/api/e2ee/identity/${encodeURIComponent(userId)}`);
    if (!ok || !body?.registered || typeof body.identityDhPub !== 'string') {
      throw new PeerNotRegisteredError(`user ${userId} is not registered`);
    }
    return body.identityDhPub;
  }

  /**
   * 60-digit safety number for (self, peer) — deterministic, identical on ALL
   * devices of both accounts. Uses the identity endpoint's PRIMARY (oldest)
   * identity keys for BOTH sides: our own primary is resolved via the server
   * when `options.selfId` is known (stable across our devices); without it we
   * fall back to this device's local identity. Signature unchanged.
   * Throws PeerNotRegisteredError when the peer (or self) is unregistered.
   */
  async getSafetyNumber(peerId: string): Promise<string> {
    const identity = await this.requireIdentity();
    const peerIk = await this.fetchPrimaryIdentityPub(peerId);
    let selfIk = identity.dh.pub;
    if (this.selfId) {
      try {
        selfIk = await this.fetchPrimaryIdentityPub(this.selfId);
      } catch {
        // Keep the local identity as a fallback; the peer side is still primary.
      }
    }
    return safetyNumber(selfIk, peerIk);
  }
}

// Re-exported for grep-ability of the AAD / wire contract at the engine boundary.
export { AAD_TEMPLATE, WIRE_PREFIX, WIRE_PREFIX_MULTI, WIRE_VERSION, MAX_SKIP, LEGACY_DEVICE_ID, MAX_DEVICES };
export {
  E2eeError,
  PeerNotRegisteredError,
  DecryptFailedError,
  SessionMissingError,
  RekeyDetectedError,
  TamperedError,
};
