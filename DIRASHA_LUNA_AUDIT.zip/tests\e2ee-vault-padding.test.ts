import { describe, it, expect } from 'vitest';
import {
  VaultKVStore,
  EphemeralKekStore,
  getOrCreateKek,
} from '../src/lib/e2ee/vault.ts';
import type { KekStore } from '../src/lib/e2ee/vault.ts';
import { MemoryKVStore } from '../src/lib/e2ee/store.ts';
import { padToBucket, unpadFromBucket, isPadded, PADDING_BUCKETS } from '../src/lib/e2ee/padding.ts';
import { utf8Encode, utf8Decode } from '../src/lib/e2ee/crypto.ts';

describe('Project 3 — Local Key Vault (VaultKVStore)', () => {
  it('round-trips values and never stores plaintext in the base store', async () => {
    const base = new MemoryKVStore();
    const vault = new VaultKVStore(base, new EphemeralKekStore());
    await vault.set('identity', '{"dh":{"priv":"TOP-SECRET"}}');
    const raw = await base.get('identity');
    expect(raw).not.toBeNull();
    expect(raw).not.toContain('TOP-SECRET');
    expect(raw).toContain('"v":"enc1"');
    expect(await vault.get('identity')).toBe('{"dh":{"priv":"TOP-SECRET"}}');
  });

  it('legacy plaintext entries pass through on read and migrate on write', async () => {
    const base = new MemoryKVStore();
    await base.set('session:peer', '{"legacy":true}');
    const vault = new VaultKVStore(base, new EphemeralKekStore());
    expect(await vault.get('session:peer')).toBe('{"legacy":true}');
    await vault.set('session:peer', '{"legacy":true,"v":2}');
    const raw = await base.get('session:peer');
    expect(raw).toContain('"v":"enc1"');
    expect(await vault.get('session:peer')).toBe('{"legacy":true,"v":2}');
  });

  it('migrateExisting encrypts every legacy plaintext entry', async () => {
    const base = new MemoryKVStore();
    const kekStore = new EphemeralKekStore();
    await base.set('a', 'plain-a');
    await base.set('b', 'plain-b');
    await vaultSetEncrypted(base, 'c', kekStore, 'already-encrypted');
    const vault = new VaultKVStore(base, kekStore); // same KEK as entry c
    await vault.migrateExisting();
    for (const k of ['a', 'b', 'c']) {
      const raw = await base.get(k);
      expect(raw).toContain('"v":"enc1"');
      expect(await vault.get(k)).toBe(k === 'a' ? 'plain-a' : k === 'b' ? 'plain-b' : 'already-encrypted');
    }
  });

  it('del and keys pass through transparently', async () => {
    const base = new MemoryKVStore();
    const vault = new VaultKVStore(base, new EphemeralKekStore());
    await vault.set('k1', 'v1');
    await vault.set('k2', 'v2');
    expect((await vault.keys()).sort()).toEqual(['k1', 'k2']);
    await vault.del('k1');
    expect(await vault.get('k1')).toBeNull();
    expect(await vault.get('k2')).toBe('v2');
  });

  it('a second vault sharing the persisted KEK store decrypts the first vault values', async () => {
    const kekStore = new EphemeralKekStore();
    const base = new MemoryKVStore();
    const v1 = new VaultKVStore(base, kekStore);
    await v1.set('session:peer', '{"shared":1}');
    const v2 = new VaultKVStore(base, kekStore); // same KEK store (like a page reload)
    expect(await v2.get('session:peer')).toBe('{"shared":1}');
  });

  it('getOrCreateKek returns the SAME key object on repeat calls (no key churn)', async () => {
    const kekStore = new EphemeralKekStore();
    const k1 = await getOrCreateKek(kekStore);
    const k2 = await getOrCreateKek(kekStore);
    expect(k1).toBe(k2);
  });

  it('CONCURRENT getOrCreateKec calls converge on ONE key (vault race regression)', async () => {
    const kekStore = new EphemeralKekStore();
    const [ka, kb, kc] = await Promise.all([
      getOrCreateKek(kekStore),
      getOrCreateKek(kekStore),
      getOrCreateKek(kekStore),
    ]);
    expect(ka).toBe(kb);
    expect(kb).toBe(kc);
  });
});

async function vaultSetEncrypted(base: MemoryKVStore, key: string, kekStore: KekStore, value: string): Promise<void> {
  const vault = new VaultKVStore(base, kekStore);
  await vault.set(key, value);
}

describe('Project 6 — Message padding', () => {
  it('lands padded sizes on the defined buckets', () => {
    expect(padToBucket(new Uint8Array(300).fill(120)).length).toBe(PADDING_BUCKETS[0]); // 512
    expect(padToBucket(new Uint8Array(900).fill(120)).length).toBe(PADDING_BUCKETS[1]); // 1024
    expect(padToBucket(new Uint8Array(3000).fill(120)).length).toBe(PADDING_BUCKETS[2]); // 4096
    expect(padToBucket(new Uint8Array(10000).fill(120)).length).toBe(PADDING_BUCKETS[3]); // 16384
  });

  it('oversized plaintext rounds to the next 16KB step above the largest bucket', () => {
    const out = padToBucket(new Uint8Array(70000).fill(120));
    expect(out.length).toBeGreaterThan(PADDING_BUCKETS[PADDING_BUCKETS.length - 1]);
    expect(out.length % 16384).toBe(0);
  });

  it('round-trips exactly (padding is lossless)', () => {
    for (const size of [0, 1, 100, 507, 508, 1020, 4000, 16000]) {
      const pt = new Uint8Array(size).fill(65);
      const padded = padToBucket(pt);
      expect(padded.length).toBeGreaterThanOrEqual(PAD_MIN(size));
      expect(utf8Decode(unpadFromBucket(padded))).toBe(utf8Decode(pt));
    }
  });

  it('inconsistent length prefix throws (defense in depth beyond the AEAD tag)', () => {
    const padded = padToBucket(utf8Encode('hello'));
    padded[0] = 0xff; padded[1] = 0xff; padded[2] = 0xff; padded[3] = 0x7f; // length prefix = ~2^31 — inconsistent
    expect(() => unpadFromBucket(padded)).toThrow();
  });

  it('isPadded recognizes only the explicit flag', () => {
    expect(isPadded(1)).toBe(true);
    expect(isPadded(undefined)).toBe(false);
    expect(isPadded(0)).toBe(false);
  });
});

function PAD_MIN(size: number): number {
  const withPrefix = size + 4;
  for (const b of PADDING_BUCKETS) if (withPrefix <= b) return b;
  return Math.ceil(withPrefix / 16384) * 16384;
}
