/**
 * STATUS-01 (external audit) — unified status privacy across REST + WS.
 *
 * Test split (repo convention — server.ts boots the HTTP listener at import,
 * so in-process route tests are impossible; see tests/group-membership.test.ts):
 *
 *   1. BEHAVIORAL (pure): the REAL canViewStatus / getStatusVisibility /
 *      filterStatusFor guards (src/server/guards/statusPolicy.ts) with a mock
 *      db — owner always passes; nobody/contacts/everyone resolve from the
 *      owner's privacy settings; unknown values and lookup failures fail
 *      closed; filterStatusFor never emits text/media over a broadcast.
 *   2. STATIC-SOURCE: status.ts no longer publishes full rows to the global
 *      `presence:broadcast` channel and instead fans out pointer-only
 *      {statusId, ownerId} events per allowed recipient; canViewStatus gates
 *      the view/like/unlike/comments routes; comments/replies 'closed'
 *      settings are enforced server-side (Arabic rejections).
 *   3. STATIC-SOURCE: ws_server.ts strips any status-shaped payload crossing
 *      the global channel (defense-in-depth), socket_client.ts fetches a
 *      ticket and never logs tokens.
 *
 * Run: npx vitest run tests/status-privacy.test.ts
 */
import { describe, it, expect, beforeAll } from 'vitest';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const statusSrc = fs.readFileSync(path.join(repoRoot, 'src/server/routes/status.ts'), 'utf8');
const wsSrc = fs.readFileSync(path.join(repoRoot, 'src/server/websocket/ws_server.ts'), 'utf8');
const socketSrc = fs.readFileSync(path.join(repoRoot, 'src/lib/socket_client.ts'), 'utf8');
const policySrc = fs.readFileSync(path.join(repoRoot, 'src/server/guards/statusPolicy.ts'), 'utf8');

/* ── 1. Guard behavior (real statusPolicy code, mock db) ────────────────────── */

function mockDb(visibility: unknown, contacts: string[] = [], opts?: { throwOnContacts?: boolean; settings?: any }) {
  const settings =
    opts?.settings !== undefined
      ? opts.settings
      : visibility === undefined
        ? undefined
        : { privacySettings: { statusVisibility: visibility } };
  return {
    getUserSettings: async (_ownerId: string) => settings,
    getContacts: async (_ownerId: string) => {
      if (opts?.throwOnContacts) throw new Error('db unavailable');
      return contacts;
    },
  };
}

describe('canViewStatus — STATUS-01 unified privacy (fail-closed)', () => {
  let canViewStatus: any;
  let getStatusVisibility: any;
  beforeAll(async () => {
    const mod = await import('../src/server/guards/statusPolicy.ts');
    canViewStatus = (mod as any).canViewStatus;
    getStatusVisibility = (mod as any).getStatusVisibility;
  });

  it('the owner can ALWAYS view their own status (even when visibility=nobody)', async () => {
    const db = mockDb('nobody');
    await expect(canViewStatus(db, 'owner-1', { user_id: 'owner-1' })).resolves.toBe(true);
    await expect(canViewStatus(db, 'owner-1', { userId: 'owner-1' })).resolves.toBe(true);
  });

  it("'nobody' hides the status from every non-owner", async () => {
    const db = mockDb('nobody', ['friend-1']);
    await expect(canViewStatus(db, 'friend-1', { user_id: 'owner-1' })).resolves.toBe(false);
    await expect(canViewStatus(db, 'stranger-1', { user_id: 'owner-1' })).resolves.toBe(false);
  });

  it("'contacts' allows only the owner's contacts", async () => {
    const db = mockDb('contacts', ['friend-1']);
    await expect(canViewStatus(db, 'friend-1', { user_id: 'owner-1' })).resolves.toBe(true);
    await expect(canViewStatus(db, 'stranger-1', { user_id: 'owner-1' })).resolves.toBe(false);
  });

  it("'everyone' allows all authenticated viewers", async () => {
    const db = mockDb('everyone');
    await expect(canViewStatus(db, 'stranger-1', { user_id: 'owner-1' })).resolves.toBe(true);
  });

  it('an UNKNOWN visibility value fails closed (treated as nobody)', async () => {
    const db = mockDb('followers');
    await expect(canViewStatus(db, 'friend-1', { user_id: 'owner-1' })).resolves.toBe(false);
    await expect(canViewStatus(db, 'friend-1', { user_id: 'owner-1', settings: { visibility: 'followers' } })).resolves.toBe(false);
    await expect(getStatusVisibility(db, 'owner-1')).resolves.toBe('nobody');
  });

  it('a MISSING visibility setting keeps the codebase default (everyone)', async () => {
    await expect(getStatusVisibility(mockDb(undefined), 'owner-1')).resolves.toBe('everyone');
    await expect(canViewStatus(mockDb(undefined), 'stranger-1', { user_id: 'owner-1' })).resolves.toBe(true);
  });

  it('a contact-list lookup failure fails closed', async () => {
    const db = mockDb('contacts', [], { throwOnContacts: true });
    await expect(canViewStatus(db, 'friend-1', { user_id: 'owner-1' })).resolves.toBe(false);
  });

  it('a settings lookup failure fails closed', async () => {
    const db = { getUserSettings: async () => { throw new Error('db down'); }, getContacts: async () => ['friend-1'] };
    await expect(canViewStatus(db, 'friend-1', { user_id: 'owner-1' })).resolves.toBe(false);
  });

  it('malformed input fails closed (null status, missing owner, empty viewer)', async () => {
    const db = mockDb('everyone');
    await expect(canViewStatus(db, 'v1', null)).resolves.toBe(false);
    await expect(canViewStatus(db, 'v1', {})).resolves.toBe(false);
    await expect(canViewStatus(db, '', { user_id: 'owner-1' })).resolves.toBe(false);
    await expect(canViewStatus(db, 'v1', { user_id: 42 })).resolves.toBe(false);
  });
});

describe('filterStatusFor — broadcast payloads never carry text/media', () => {
  let filterStatusFor: any;
  beforeAll(async () => {
    const mod = await import('../src/server/guards/statusPolicy.ts');
    filterStatusFor = (mod as any).filterStatusFor;
  });

  const row = {
    id: 'status-1',
    user_id: 'owner-1',
    content_type: 'image',
    text_content: 'secret caption',
    media_url: 'https://cdn.example.com/leak.jpg',
    settings: { comments: 'open' },
    views_count: 3,
  };

  it('returns null when the viewer is not allowed', () => {
    expect(filterStatusFor(row, 'v1', false)).toBeNull();
    expect(filterStatusFor(null, 'v1', true)).toBeNull();
  });

  it('allowed viewers get the row WITHOUT the global-audience fields (text/media stripped)', () => {
    const safe = filterStatusFor(row, 'v1', true);
    expect(safe).not.toBeNull();
    expect(safe.text_content).toBeUndefined();
    expect(safe.media_url).toBeUndefined();
    expect(safe.textContent).toBeUndefined();
    expect(safe.mediaUrl).toBeUndefined();
    // Nothing else is stripped — the existing field shape survives.
    expect(safe.id).toBe('status-1');
    expect(safe.user_id).toBe('owner-1');
    expect(safe.content_type).toBe('image');
    expect(safe.settings).toEqual({ comments: 'open' });
    expect(safe.views_count).toBe(3);
  });

  it('does not mutate the original row', () => {
    const copy = { ...row };
    filterStatusFor(row, 'v1', true);
    expect(row).toEqual(copy);
    expect(row.text_content).toBe('secret caption');
  });
});

/* ── 2. status.ts static wiring (STATUS-01) ─────────────────────────────────── */

describe('status.ts — per-recipient fanout replaces the global broadcast (static)', () => {
  it('never publishes to the global presence:broadcast channel', () => {
    expect(statusSrc).not.toContain("'presence:broadcast'");
    expect(statusSrc).not.toContain('"presence:broadcast"');
  });

  it('fans out pointer-only status:new events to per-recipient user channels', () => {
    expect(statusSrc).toContain('user:updates:${recipientId}');
    expect(statusSrc).toContain("event: 'status:new'");
    expect(statusSrc).toContain('statusId: created.id');
    expect(statusSrc).toContain('ownerId: userId');
    // The pointer payload is built ONCE and must not gain content fields.
    const block = statusSrc.slice(statusSrc.indexOf('const pointerPayload'));
    expect(block).not.toMatch(/pointerPayload[^;]*text_content/);
    expect(block).not.toMatch(/pointerPayload[^;]*media_url/);
  });

  it("resolves the owner's visibility and skips the broadcast entirely for 'nobody'", () => {
    expect(statusSrc).toContain('getStatusVisibility(db, userId)');
    const block = statusSrc.slice(statusSrc.indexOf('const visibility = await getStatusVisibility'));
    expect(block).toContain("visibility === 'contacts'");
    expect(block).toContain("visibility === 'everyone'");
    expect(block).toContain("'nobody' → no broadcast");
  });

  it('re-checks canViewStatus per recipient before publishing (defense-in-depth)', () => {
    expect(statusSrc).toContain('canViewStatus(db, recipientId, created)');
  });

  it('the unified guard is imported and enforced on every status sub-route', () => {
    expect(statusSrc).toContain("from '../guards/statusPolicy.ts'");
    // GET list, view, like, unlike, POST comments, GET comments.
    const routeCalls = statusSrc.split('await canViewStatus(db, userId,').length - 1;
    expect(routeCalls).toBe(6);
  });

  it('view/like/unlike/comments routes reject non-viewers with the shared Arabic string', () => {
    const hits = statusSrc.split("'لا يمكنك الوصول إلى هذه الحالة.'").length - 1;
    expect(hits).toBe(5); // view, like, unlike, POST comments, GET comments
  });

  it("enforces the per-status comments/replies 'open'/'closed' settings server-side", () => {
    expect(statusSrc).toContain("statusSettings?.comments !== 'open'");
    expect(statusSrc).toContain("'التعليقات مغلقة على هذه الحالة.'");
    expect(statusSrc).toContain("statusSettings?.replies !== 'open'");
    expect(statusSrc).toContain("'الردود مغلقة على هذه الحالة.'");
  });

  it('reply writes validate the parent comment belongs to the same status', () => {
    expect(statusSrc).toContain("'SELECT id FROM status_comments WHERE id = $1 AND status_id = $2'");
    expect(statusSrc).toContain("'التعليق الأصلي غير موجود.'");
  });

  it('keeps the media architecture guard on status creation (data:/non-HTTPS rejected)', () => {
    expect(statusSrc).toContain("media_url.startsWith('data:')");
    expect(statusSrc).toContain('يجب رفع وسائط الحالة إلى التخزين السحابي أولاً.');
    expect(statusSrc).toContain('رابط الوسائط يجب أن يكون HTTPS من تخزين سحابي.');
  });

  it('the policy guard exports the unified API', () => {
    expect(policySrc).toContain("export type StatusVisibility = 'everyone' | 'contacts' | 'nobody'");
    expect(policySrc).toContain('export async function canViewStatus');
    expect(policySrc).toContain('export function filterStatusFor');
    expect(policySrc).toContain('export async function getStatusVisibility');
  });
});

/* ── 3. WS defense-in-depth + client ticket flow (static) ───────────────────── */

describe('ws_server.ts — global channel sanitizer + attachment allowlist (static)', () => {
  it('sanitizes EVERY payload forwarded from the global presence:broadcast channel', () => {
    expect(wsSrc).toContain('export function sanitizeStatusBroadcastPayload');
    const listener = wsSrc.slice(wsSrc.indexOf('"presence:broadcast"'));
    expect(listener).toContain('sanitizeStatusBroadcastPayload(payload?.payload)');
  });

  it('the sanitizer strips status rows down to the safe {statusId, ownerId} pointer', () => {
    const fn = wsSrc.slice(wsSrc.indexOf('export function sanitizeStatusBroadcastPayload'));
    expect(fn).toContain('statusId: nested.id ?? null');
    expect(fn).toContain('ownerId: nested.user_id ?? nested.userId ?? null');
    expect(fn).toContain('statusId: payload.statusId ?? payload.id ?? null');
    expect(fn).toContain('ownerId: payload.ownerId ?? payload.user_id ?? payload.userId ?? null');
  });

  it('msg:send rejects attachment URLs via the WS allowlist (data: + host rules)', () => {
    expect(wsSrc).toContain('export function isWsAttachmentUrlAllowed');
    const fn = wsSrc.slice(wsSrc.indexOf('export function isWsAttachmentUrlAllowed'));
    expect(fn).toContain('rawUrl.startsWith("data:")');
    expect(fn).toContain('MEDIA_HOST_ALLOWLIST');
    const gate = wsSrc.slice(wsSrc.indexOf('isWsAttachmentUrlAllowed(attUrl, ws.upgradeOrigin'));
    expect(gate).toContain('يجب رفع الملفات إلى التخزين السحابي أولاً قبل الإرسال.');
    expect(gate).toContain('مضيف الوسائط غير مسموح به — استخدم التخزين السحابي المعتمد.');
  });
});

describe('socket_client.ts — ticket-first connect, legacy fallback, no token logging (static)', () => {
  it('fetches GET /api/ws-ticket with the Bearer token in a header (never in a URL)', () => {
    expect(socketSrc).toContain('/api/ws-ticket');
    expect(socketSrc).toContain("headers: { Authorization: `Bearer ${token}` }");
    expect(socketSrc).not.toContain('ws-ticket?token=');
  });

  it('connects with ?ticket= first and falls back to the legacy ?token= path', () => {
    const ticketIdx = socketSrc.indexOf('?ticket=');
    const tokenIdx = socketSrc.indexOf('?token=');
    expect(ticketIdx).toBeGreaterThan(-1);
    expect(tokenIdx).toBeGreaterThan(ticketIdx);
    expect(socketSrc).toContain('legacy fallback');
  });

  it('treats any ticket-endpoint failure (404/network) as fallback, not a crash', () => {
    expect(socketSrc).toContain('if (!res.ok) return null;');
    expect(socketSrc.split('\r\n').join('\n')).toContain('} catch {\n      return null;\n    }');
  });

  it('never logs tokens or tickets', () => {
    expect(socketSrc).not.toMatch(/console\.(log|warn|error|info)\([^)]*(token|ticket)/i);
  });
});
