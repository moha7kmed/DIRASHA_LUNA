/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { db } from '../database.ts';
import { redisCluster } from './redis_client.ts';
import type { Message, DeliveryState } from '../../types.ts';

export class AckManager {
  /**
   * Tracks a message delivery status change, saves it to database, and publishes it globally.
   */
  public static async updateReceipt(
    chatId: string,
    messageId: string,
    userId: string,
    status: 'delivered' | 'read'
  ): Promise<void> {
    try {
      // 1. Persist the state update directly into database
      const receipt = await db.updateMessageStatus(messageId, userId, status);
      if (!receipt) return;

      const targetMessage = await db.getMessageById(messageId);
      const targetCreatedAt = targetMessage ? targetMessage.createdAt : new Date().toISOString();

      // 2. Publish state transition update to matching chat room so other subscribers synchronize
      const eventData = {
        event: 'msg:state:change',
        payload: {
          chatId,
          lastMessageId: messageId,
          userId,
          status,
          updatedAt: new Date().toISOString(),
          targetCreatedAt,
        },
      };
      await redisCluster.publish(`chat:${chatId}`, eventData);

      // ALSO broadcast to each member's private channel
      const members = await db.getChatMembers(chatId);
      for (const memb of members) {
        await redisCluster.publish(`user:updates:${memb.userId}`, eventData);
      }

      console.log(`[AckManager] Status updated to '${status}' for msg ${messageId} by user ${userId}`);
    } catch (err: any) {
      console.error('[AckManager] Error updating message receipt:', err.message);
    }
  }

  /**
   * Translates client-side messages into ordered, sorted payloads with server timestamps to avoid latency jitter.
   */
  public static generateOrderingEnvelope(message: Message): any {
    return {
      ...message,
      // Enforce strict monotonically increasing server timestamp for deterministic rendering
      serverTime: Date.now(),
      sequenceId: `${new Date(message.createdAt).getTime()}-${message.id.substring(4, 12)}`,
    };
  }
}
