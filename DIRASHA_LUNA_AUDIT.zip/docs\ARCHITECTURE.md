# وثيقة التصميم الهندسي والمعماري لمنصة المحادثات الفورية الكبيرة (dirasha Architecture Guide)
> **تأليف:** نظام هندسة الأنظمة الموزعة والمطور الرئيسي للمشروع كـ Software Architect + Senior Full Stack Engineer.

---

## 1) التحليل المعماري الكامل (Full Architectural Analysis)

تم تصميم منصة **dirasha** لتعمل كمنصة محادثة متطورة تدعم ملايين المستخدمين المتزامنين (Concurrent Connections) مع الحفاظ على زمن استجابة متدني للغاية (P99 < 50ms) للمراسلات الفورية.

### المبادئ الهندسية الأساسية المعتمدة:
1. **الفصل التام للمسؤوليات (Clean / Layered Architecture):**
   - **الطبقة الخارجية (Client Layer):** تطبيق React ويب متكامل يتعامل مع المزامنة (Direct Sync)، والمخزن المحلي، والتحديث التفاؤلي (Optimistic Updates).
   - **طبقة الاتصال والتحويل (API Gateway / Load Balancer):** تفريغ اتصالات SSL وتوجيه الطلبات عبر بروتوكولات HTTP و WebSockets.
   - **الطبقة الخدمية (Microservices & Stateless Backend):** معالجة الطلبات، التأكد من الصلاحيات والتحقق من الهوية.
   - **الطبقة الفورية (Stateful/Real-Time Connection Layer):** خوادم WebSocket مكررة أفقياً ومربوطة بـ Redis Pub/Sub للمزامنة اللحظية.
   - **طبقة البيانات والتخزين (Storage & Persistence Layer):** دمج PostgreSQL للتخزين العلائقي الصلب للرسائل والمستخدمين، مع Redis كذاكرة مؤقتة وتتبع حالات الاتصال اللحظية.

### الموازنة بين البدائل الهندسية (Trade-offs):
- **قواعد البيانات (PostgreSQL vs MongoDB/Cassandra):**
  تم اختيار **PostgreSQL** للبيانات الأساسية بسبب ضمانات ACID وصعوبة تتبع العلاقات المتشابكة للمحادثات الثنائية والجماعية في قواعد NoSQL بدون تكرار ضخم للبيانات. للمستقبل، يمكن ترحيل الرسائل القديمة (Cold Data) إلى Apache Cassandra أو ScyllaDB، بينما تظل البيانات النشطة في PostgreSQL مع تفعيل الـ Read-Replicas وتقنيات التقسيم (Partitioning).
- **نظام الاتصال الفوري (Socket.IO vs Native WebSockets):**
  تم اختيار **Native WebSockets** مع تطبيق بروتوكول تحكم مخصص وخفيف (Custom Protocol Payload). هذا يضمن تقليل حجم رأس الحزم (Header Overhead) بنسبة تتعدى 60% مقارنة بـ Socket.IO، مما يقلل بشكل مهول من استهلاك العرض الترددي (Bandwidth) وتكاليف الذاكرة لخوادم الاتصالات عند العمل على نطاق مليوني.

---

## 2) شرح البنية التحتية (Infrastructure & Topology)

```
                       [ Global CDN ]
                             │
                      [ Load Balancer ]
                 (NGINX/HAProxy/Envoy - SSL)
                    /                 \
        (HTTP Traffic)              (WebSocket Traffic)
                  /                     \
       [ Stateless Web Servers ]      [ Stateful WS Servers ] (Node.js/Go)
       (REST API Instances v1)        (Maintains Active TCP Connections)
               │                                │
               ├────── [ Redis Cluster ] ───────┤ (Pub/Sub, Sessions, Rate Limits)
               │                                │
        [ PostgreSQL Cluster ]                  │
     (Primary - Read/Write)                     │
               │                                │
     (Replica-1)  (Replica-2) ──────────────────┘
```

### وصف المكونات:
- **Load Balancer (Envoy/HAProxy):** يقوم بتوزيع الأحمال اللحظية، وتطبيق سياسة Session Affinity (اختيارياً لـ WS)، وتفريغ شهادات الأمان (SSL Termination).
- **Stateless Web API:** تخدم طلبات HTTP مثل جلب سجلات الرسائل القديمة، وتعديل الحسابات، والمصادقة.
- **Stateful WS Network:** خوادم Node.js خفيفة للغاية، مسؤوليتها الوحيدة الحفاظ على اتصالات TCP المفتوحة وإرسال واستقبال الأحداث بأقل بصمة ذاكرة ممكّنة (Memory Footprint).
- **Redis Cluster:** العصب المركزي لتنسيق الأحداث بين جميع خوادم الـ WebSocket المنفصلة (عبر آلية Pub/Sub) وحفظ ملفات الجلسات وحالات التواجد.

---

## 3) مخطط تدفق الرسائل الفورية (Message Flow Sequence)

مخطط سير رسالة من المرسل (User A) إلى المستقبل (User B):

```
User A                    WS Server 1                Redis Pub/Sub               WS Server 2                    User B
  │                             │                          │                          │                             │
  │───(1) ws_send_message ─────>│                          │                          │                             │
  │    [Client Temp ID]         │                          │                          │                             │
  │                             │───(2) Save to DB ───────>│                          │                             │
  │                             │    (PostgreSQL Authored)  │                          │                             │
  │                             │                          │                          │                             │
  │                             │───(3) publish "msg:B" ──>│                          │                             │
  │                             │                          │───(4) deliver event ────>│                             │
  │                             │                          │    to subscribed WS      │                             │
  │<──(5) ws_msg_status [Sent]──│                          │                          │───(6) ws_receive_message ──>│
  │    (Triggers Ack in UI)     │                          │                          │    [Delivered Status]       │
  │                             │                          │                          │                             │
  │                             │                          │                          │<──(7) ws_msg_status [Deliv]─│
  │                             │                          │<──(8) publish "stat:A" ──│                             │
  │                             │<──(9) deliver event ─────│                          │                             │
  │<──(10) ws_msg_status [Deliv]│                          │                          │                             │
```

---

## 4) شرح دورة حياة الاتصال (Connection Lifecycle)

1. **المصافحة والمصادقة (Handshake & Upgrade):**
   - يقوم العميل بفتح اتصال مبرمج بالخادم: `wss://api.dirasha.com/socket`.
   - يمرر الـ JWT Access Token في معامل الاستعلام (Query Param) أو عبر ترويسة فرعية لتطبيقات الويب لمنع قرصنة ترويسات WebSocket المتوافقة مع المتصفحات.
   - يتأكد خادم WebSocket من صحة الـ Token وتطابق التوقيع والمستأجر والصلاحيات. إن كان صالحاً، يسمح بالترقية من HTTP إلى WebSocket.
2. **تسجيل الحضور والجهاز (Registration):**
   - بمجرد نجاح الاتصال، يُدرج الخادم المقبس النشط (Socket Object) في جدول مرجعي محلي بالخادم (Memory Map indexed by UserId and ConnectionId).
   - يتم تحديث حالة المستخدم في Redis إلى 'online' بالإضافة إلى ربطه بالمعرف الخاص بالـ WS Server المنتمي إليه ليسهل توجيه الرسائل.
3. **نبضات القلب المستمرة (Ping/Pong Heartbeat):**
   - يتأكد الخادم من سلامة الاتصال الفعلي وإصلاح اتصالات TCP الميتة (Half-Open Sockets) عن طريق إرسال إطار `ping` كل 25 ثانية.
   - يجب على العميل الرد الفوري بإطار `pong` خلال مهلة 10 ثوانٍ كحد أقصى.
   - في حال تخطي المهلة، يدرك الخادم فوراً تعطل الاتصال من طرف العميل ويقرر إغلاق الاتصال وتحرير الموارد.
4. **الانقطاع المفاجئ وإعادة الاتصال الذاتي (Graceful/Abrupt Disconnection):**
   - عند غلق النافذة أو انقطاع الشبكة، يمسح الخادم المقبس ويُطلق حدث تحديث حالة الحضور لمشتركي المحادثة بعد مهلة مؤقتة (مثلاً 5 ثوانٍ لتجنب تذبذب الشبكة "Reconnect Flicker-debounce").

---

## 5) تصميم قاعدة البيانات (Relational Database Schemas)

لدينا هنا التصميم الأمثل لقاعدة البيانات باستخدام PostgreSQL، مجهز لكي يدعم مليارات السجلات.

```sql
-- 1. جدول المستخدمين (Users Table)
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username VARCHAR(50) UNIQUE NOT NULL,
    display_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    avatar_url VARCHAR(1024),
    online_status VARCHAR(20) DEFAULT 'offline' CHECK (online_status IN ('online', 'offline', 'away')),
    last_seen TIMESTAMP NOT NULL DEFAULT NOW(),
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);


-- 2. جدول جلسات المستخدمين وإدارة تعدد الأجهزة (User Sessions & Token Rotation)
CREATE TABLE user_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    refresh_token VARCHAR(512) UNIQUE NOT NULL,
    user_agent VARCHAR(512),
    ip_address VARCHAR(45),
    is_revoked BOOLEAN DEFAULT FALSE,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_sessions_refresh ON user_sessions(refresh_token);
CREATE INDEX idx_sessions_user ON user_sessions(user_id) WHERE is_revoked = FALSE;


-- 3. جدول المحادثات (Chats Schema)
CREATE TABLE chats (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    type VARCHAR(20) NOT NULL CHECK (type IN ('one-to-one', 'group')),
    name VARCHAR(100), -- نل في حال محادثة ثنائية
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);


-- 4. جدول الأعضاء المشتركين بمحادثة معينة (Chat Members)
CREATE TABLE chat_members (
    chat_id UUID NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    joined_at TIMESTAMP NOT NULL DEFAULT NOW(),
    PRIMARY KEY (chat_id, user_id)
);

CREATE INDEX idx_chat_members_user ON chat_members(user_id);


-- 5. جدول الرسائل الرئيسي (Messages Primary Archival Table)
-- يدعم تصميم التجزئة الجغرافية أو تقسيم الجدول (partitioned by range of created_at) لتسريع عمليات قراءة الأرشيف القديم.
CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    chat_id UUID NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
    sender_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    type VARCHAR(20) DEFAULT 'text' CHECK (type IN ('text', 'attachment')),
    attachments JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    edited_at TIMESTAMP,
    deleted_at TIMESTAMP
);

-- فهارس ضرورية جداً للتسريع الفوري لـ Pagination
CREATE INDEX idx_messages_chat_created ON messages(chat_id, created_at DESC) WHERE deleted_at IS NULL;


-- 6. جدول قراءة واستقبال الرسائل الدقيق (Message State & Receipts)
CREATE TABLE message_reads (
    message_id UUID NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    chat_id UUID NOT NULL,
    status VARCHAR(20) NOT NULL CHECK (status IN ('sending', 'sent', 'delivered', 'read')),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    PRIMARY KEY (message_id, user_id)
);

CREATE INDEX idx_message_reads_chat_user ON message_reads (chat_id, user_id, status);
```

### كيف يضمن هذا التصميم قراءة ذكية وخالية من الاختناقات (Anti-Bottlneck Strategy)؟
1. **Indexes المركبة:** يُستعمل الفهرس `(chat_id, created_at DESC)` لجلب الرسائل في المحادثة الأخيرة بـ `O(log N)` فقط بدقة مرعبة بدلاً من سحب كامل السجلات بـ `Table Scan`.
2. **Partial Indexes:** استخدام `WHERE deleted_at IS NULL` لتوفير مساحة الفهرسة واستثناء الرسائل الممحية تمامًا من المؤشرات.
3. **التخزين الخفيف لحركة الرسائل:** يتم فصل حالات تسليم الرسائل وقراءتها في جدول منفصل خفيف الحجم `message_reads`. هذا يمنع عمليات الـ Row Locking المستمرة على جدول الرسائل الأساسي الكثيف عندما يقوم 10,000 مستخدم بالتمرير وقراءة الرسائل دفعة واحدة.

---

## 6) تصميم بروتوكول وأحداث الـ WebSocket (Payload Definition)

لتحقيق سرعة قصوى وأمان في تمرير البيانات، يحتوي كل حدث يتم إرساله على شكل JSON علوي ثابت (Fixed Schema Frame):

```typescript
interface WSFrame<T = any> {
  event: string;      // اسم الحدث الفرعي الفريد
  payload: T;         // محتوى الحدث الفعلي
  traceId?: string;   // لتتبع طلبات الشبكة وحل المشكلات والأخطاء في Logs
}
```

### القائمة الكاملة لأحداث الـ WebSocket المدعومة والتفصيلية:

#### أ) من العميل إلى السيرفر (Client-to-Server EVENTS):
1. **`chat:join`**: الانضمام لغرفة المحادثة فور الدخول إليها لتلقي التنبيهات الفورية للبث الداخلي.
   - *Payload:* `{ chatId: string }`
2. **`msg:send`**: إرسال رسالة جديدة.
   - *Payload:* `{ tempMessageId: string, chatId: string, content: string, type: "text" | "attachment", attachments?: any[] }`
3. **`msg:read`**: تفيد بقراءة الرسائل في المحادثة.
   - *Payload:* `{ chatId: string, lastMessageId: string }`
4. **`presence:status`**: تغيير حالة الحضور للعميل يدوياً.
   - *Payload:* `{ status: "online" | "offline" | "away" }`
5. **`presence:typing`**: بدئ أو التوقف عن الكتابة الفورية.
   - *Payload:* `{ chatId: string, isTyping: boolean }`

#### ب) من السيرفر إلى العميل (Server-to-Client EVENTS):
1. **`auth:ready`**: فور اتصال المقبس ليعلم العميل بنجاح التحقق وهويته في النظام.
   - *Payload:* `{ user: { id: string, username: string } }`
2. **`msg:new`**: استلام رسالة جديدة تابعة لمشترك بالغرفة.
   - *Payload:* `{ messageId: string, chatId: string, senderId: string, content: string, type: string, createdAt: string }`
3. **`msg:ack`**: تأكيد السيرفر للمرسل بنجاح استلامه وحفظه للرسالة، ليربط المعالِج اللحظي معرف العميل المؤقت بـ UUID الحقيقي المخزن.
   - *Payload:* `{ tempMessageId: string, messageId: string, status: "sent", createdAt: string }`
4. **`msg:state:change`**: إبلاغ أطراف المحادثة بتغير حالات تسليم الرسائل.
   - *Payload:* `{ chatId: string, lastMessageId: string, userId: string, status: "delivered" | "read", updatedAt: string }`
5. **`presence:update`**: بث تحديث حالات حضور المستخدمين لباقي المشتركين الفعليين.
   - *Payload:* `{ userId: string, status: "online" | "offline" | "away", lastSeen: string }`
6. **`presence:typing`**: تتبع من يكتب الآن بالصورة الحية.
   - *Payload:* `{ chatId: string, userId: string, displayName: string, isTyping: boolean }`

---

## 7) استراتيجية التوسع الأفقي (Horizontal Scaling)

عند انتشار المنصة، تنهار السيرفرات إن كانت مبرمجة لحفظ المقابس فقط والتعلم بذاكرة السيرفر الفردي. لتأمين النمو لملايين المستخدمين، نطبق المخطط التالي:

```
[ Client 1 ]             [ Client 2 ]             [ Client 3 ]
     │                        │                        │
[ WS Server A ]          [ WS Server B ]          [ WS Server C ]
     │                        │                        │
     └─────────────┬──────────┴────────────────────────┘
                   │  (Unified Pub/Sub Bus)
             [ Redis Cluster ] (Event Distribution)
```

### كيف نحل مسألة تواجد العملاء بـ WS Servers مختلفة؟
- افترض أن **User A** متصل بـ **WS Server A**، و **User B** متصل بـ **WS Server B**.
- أرسل **User A** رسالة لـ **User B**.
- يقوم **WS Server A** بحفظ الرسالة بقاعدة البيانات، ثم يقوم بنشر (Publish) حدث مباشر لـ **Redis Pub/Sub** على القناة المخصصة للمستقبل: `user:room:B_USER_UUID`.
- بما أن **User B** متصل بـ **WS Server B**، يكون هذا السيرفر حتماً مشتركاً (Subscribed) فور بزوغ اتصال **User B** في القناة الخاصة به `user:room:B_USER_UUID`.
- يلتقط **WS Server B** الرسالة فوراً من Redis ويقوم بإرسالها للمقبس النشط لـ **User B** مباشرة.
- بهذه الطريقة تصبح خوادمنا خالية تماماً من الحالات المرتبطة ببعضها (Stateless in cross-communication logic) ويمكن تشغيل 100 خادم WebSocket مكررة خلف الـ Load Balancer دون الخوف من عدم وصول أي حدث للعميل المستهدف.

---

## 8) هندسة وإدارة Redis (Redis Architecture)

### تقسيم الأدوار بين Redis و SQLite / PostgreSQL:

| نوع البيانات | البيانات المحفوظة في Redis (الذاكرة المؤقتة السريعة) | البيانات المحفوظة في PostgreSQL (التخزين الدائم الصلب) |
|--------------|--------------------------------------------|------------------------------------------|
| **المستخدمون** | بيانات الجلسة النشطة والـ Metadata السريعة | بيانات المستخدم الحقيقية، كلمات المرور، التواريخ |
| **تتبع الحضور** | قائمة المعرفات المتصلة، آخر نشاط (TTL) | تاريخ آخر ظهور كامل، تفاصيل الحسابات |
| **الرسائل والروابط** | حالات الكتابة اللحظية (Typing State: 5s expir) | جميع الرسائل، المرفقات، سجل عمليات الحذف والتعديل |
| **الأمان ومكافحة السبام** | حسابات الـ Rate Limit لكل ثانية/دقيقة للمقابس | قائمة الهويات المحظورة نهائياً بقاعدة البيانات |

---

## 9) تدفق المصادقة الدقيق وتدوير الرموز (Authentication Toolchain)

```
[ Client ]                            [ Auth Service ]                        [ Postgres DB ]
    │                                        │                                       │
    │───(1) LOGIN (username / pass) ────────>│                                       │
    │                                        │───(2) Verify Hash & Accounts ────────>│
    │<──(3) SET Secure Cookie (Refresh) ─────│                                       │
    │    & Return JSON Access Token (Short)  │                                       │
    │                                        │                                       │
    │───(4) Access Private API / Connect WS ─│                                       │
    │    (Token checked in Headers/Params)   │                                       │
    │                                        │                                       │
    │───(5) Token Expired! (HTTP 401) ──────>│                                       │
    │                                        │                                       │
    │───(6) POST /api/auth/refresh ─────────>│                                       │
    │    (Sends Cookie - Rotates Refresh)    │───(7) Validate & Revoke Old-One ─────>│
    │<──(8) New Access Token + New Cookie ───│                                       │
```

- **AccessToken:** عمره قصير جداً (15 دقيقة) وتوقع توقيعه خفيف جداً، يُحفظ في ذاكرة المتصفح النشط (JS Memory).
- **RefreshToken:** عمره طويل (7 أيام)، يُخزن في الـ Web Browser كـ `HttpOnly, Secure, SameSite=Strict` Cookie لمنع هجمات XSS و CSRF.
- **تطبيق تدوير الرموز (Refresh Token Rotation):** كلما طلب العميل تحديث الـ AccessToken، يقوم الخادم بسحب الـ RefreshToken الحالي، **وإلغائه فوراً**، وربطه بجهاز العميل لتعيين رمز جديد. إن حاول مخترق إعادة استخدام نفس الرمز القديم المستهلك، يكتشف السيرفر الـ Re-use، ويقوم بإلغاء كامل الجلسات التابعة للمستخدم فاعلاً بذلك آلية الحماية القصوى والمبكرة لسرقة الرموز.

---

## 10) هندسة النشر الموزع (Deployment Model)

عند تشغيل الكود في خوادم سحابية (مثل AWS/GCP):
1. **خاويات Docker مدمجة:** يتم عزل التطبيق كلياً بصورة Stateless خفيفة وبناء حاوية Docker مع تفريغ متغيرات البيئة السرية خارج التعليمات البرمجية.
2. **Kubernetes Readiness:** تم تخصيص مخرجات خادم Node.js لتستمع للطلبات على المنفذ 3000 وتوفير واجهات `/api/health` للتحقق من سلامة الخدمة الفورية (Liveness and Readiness Probes) من قبل Kubernetes Load-Balancer، لتوجيه الاتصالات للسيرفر النشط وتفادي اختناقات الشبكة.
3. **مقاومة الهجمات (Anti-DDoS / Rate Limiting):** دمج خوارزمية Token Bucket في السيرفر لتتبع عدد الحزم الصادرة من كل معرف مستخدم أو عنوان IP، وقطع الاتصال فوريًا إن تخطت الـ WebSockets معدلات الاستهلاك المقننة لتفادي هجمات حظر الخدمة الموزعة (DDoS).

---
الان ننتقل لبناء معمارية الكود وتطبيقه بكامل طاقته ومقوماته الحقيقية الخالية من أي زيف.
