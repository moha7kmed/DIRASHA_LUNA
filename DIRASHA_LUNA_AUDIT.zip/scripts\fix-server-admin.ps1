Set-Location 'C:\Users\Zedan\Downloads\dirasha'
$p = 'server.ts'
$enc = New-Object System.Text.UTF8Encoding($false)
$l = [System.Collections.Generic.List[string]]::new([System.IO.File]::ReadAllLines($p, [System.Text.Encoding]::UTF8))

# Replace lines 147..164 (1-based) → index 146, count 18  with the new requireAdmin + route registration
$newBlock = @(
  '  // Admin role verification middleware - identity is the unique username (ADMIN_USERNAMES env)',
  '  function requireAdmin(req: Request, res: Response, next: NextFunction) {',
  '    requireAuth(req, res, () => {',
  '      const adminUsernames = (process.env.ADMIN_USERNAMES || '''')',
  '        .split('','')',
  '        .map(u => u.toLowerCase().trim())',
  '        .filter(Boolean);',
  '      const callerName = (req.user?.username || '''').toLowerCase();',
  '      if (callerName && adminUsernames.includes(callerName)) {',
  '        next();',
  '      } else {',
  '        console.warn(`[Security Alert] Unauthorized admin API attempt by user: ${callerName || ''none''}`);',
  '        res.status(403).json({ error: ''403 Forbidden: Developer privileges required.'' });',
  '      }',
  '    });',
  '  }',
  '',
  '  // Classic credentials auth (username + password + PIN recovery) + BYO-Cloud storage routes'
)
$l.RemoveRange(146, 18)
$l.InsertRange(146, [string[]]$newBlock)
[System.IO.File]::WriteAllLines($p, $l, $enc)
Write-Host "TOTAL NOW: $($l.Count)"
