/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * BATCH-6 (F-3/F-13 — adversarial review): Web-Push endpoint allowlist.
 *
 * Endpoints are treated as opaque per the Push API spec, but the SSRF gate
 * still constrains WHERE the server will blind-POST encrypted payloads.
 * Providers and their official endpoint domains (verified against vendor
 * documentation during the adversarial closure wave):
 *   - Chrome/Chromium/Edge(legacy web push): fcm.googleapis.com (Firebase Cloud Messaging)
 *   - Firefox: push.services.mozilla.com (Mozilla Autopush)
 *   - Safari: push.apple.com
 *   - Windows/Edge: *.notify.windows.com (WNS channel URIs are token subdomains)
 *
 * Matching is parsed-hostname based (WHATWG URL): exact host for the
 * registrar-controlled zones, suffix match ONLY where the vendor documents
 * token subdomains (WNS). Non-HTTPS schemes, non-ASCII/IDN hosts, ports on
 * non-default origins and trailing-dot tricks fail closed.
 */

export interface PushEndpointDecision {
  allowed: boolean;
  provider?: 'fcm' | 'mozilla' | 'apple' | 'wns';
  reason?: string;
}

/** Registrar-controlled zones → exact-host matching (a subdomain of these is NOT attacker-reachable). */
const EXACT_HOSTS: Array<{ host: string; provider: PushEndpointDecision['provider'] }> = [
  { host: 'fcm.googleapis.com', provider: 'fcm' },
  { host: 'push.apple.com', provider: 'apple' },
  { host: 'push.services.mozilla.com', provider: 'mozilla' },
];

/** Vendor-documented TOKEN-SUBDOMAIN zones → suffix matching. */
const SUFFIX_HOSTS: Array<{ suffix: string; provider: PushEndpointDecision['provider'] }> = [
  { suffix: '.notify.windows.com', provider: 'wns' },
  { suffix: '.wns.windows.com', provider: 'wns' },
];

/**
 * Decide whether a push subscription endpoint may be registered.
 * Pure function — unit-tested for the adversarial cases (lookalikes, IDN,
 * trailing dot, userinfo, port, non-HTTPS, attacker suffixes).
 */
export function decidePushEndpointAllowed(raw: unknown): PushEndpointDecision {
  if (typeof raw !== 'string' || raw.length === 0 || raw.length > 2048) {
    return { allowed: false, reason: 'missing-or-oversized' };
  }
  let u: URL;
  try {
    u = new URL(raw);
  } catch {
    return { allowed: false, reason: 'unparseable' };
  }
  if (u.protocol !== 'https:') {
    return { allowed: false, reason: 'non-https' };
  }
  if (u.username || u.password) {
    return { allowed: false, reason: 'userinfo' };
  }
  // Non-default port → not a vendor endpoint (vendors serve on 443 implicitly).
  if (u.port !== '') {
    return { allowed: false, reason: 'non-default-port' };
  }
  let host = u.hostname.toLowerCase();
  // WHATWG keeps a trailing dot in some parsers — normalize exactly one and fail closed on the rest.
  if (host.endsWith('.')) host = host.slice(0, -1);
  if (!host || host.includes('..') || !/^[a-z0-9.-]+$/.test(host) || host.startsWith('xn--') || host.includes('.xn--')) {
    return { allowed: false, reason: 'host-shape' };
  }
  for (const r of EXACT_HOSTS) {
    if (host === r.host) return { allowed: true, provider: r.provider };
  }
  for (const r of SUFFIX_HOSTS) {
    if (host.endsWith(r.suffix) && host.length > r.suffix.length) return { allowed: true, provider: r.provider };
  }
  return { allowed: false, reason: 'unknown-provider' };
}