import { Router } from 'express';
import db, { pool } from '../database.ts';
import crypto from 'crypto';

export const apiKeysRouter = Router();

// Retrieve all API keys
apiKeysRouter.get('/', async (req: any, res) => {
  try {
    const result = await pool.query('SELECT id, key_value, service_name, is_active, usage_count, daily_usage_count, usage_date, last_used, added_by, created_at, COALESCE(total_tokens, 0) as total_tokens FROM system_api_keys ORDER BY created_at ASC');
    
    // Get currently active key id to distinguish it
    const { getCurrentKeyId } = await import('../services/gemini.ts');
    const currentKeyId = getCurrentKeyId();

    // Mask API keys for security, only show first 8 chars and last 4
    const maskedRows = result.rows.map(row => {
        let masked = row.key_value;
        if (masked.length > 15) {
            masked = masked.substring(0, 8) + '...' + masked.substring(masked.length - 4);
        }
        
        // Ensure daily usage is reset functionally if date doesn't match
        const today = new Date().toISOString().split('T')[0];
        const rowDate = row.usage_date ? new Date(row.usage_date).toISOString().split('T')[0] : '';
        const daily_usage = (rowDate === today) ? row.daily_usage_count : 0;

        return { 
          ...row, 
          key_value: masked,
          daily_usage_count: daily_usage,
          is_current_active: currentKeyId === row.id || (currentKeyId === null && row.id === 'primary-env-key')
        };
    });
    res.json(maskedRows);
  } catch (error) {
    console.error('Failed to fetch api keys:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Add a new API key
apiKeysRouter.post('/', async (req: any, res) => {
  const { key_value, service_name = 'gemini' } = req.body;
  if (!key_value || typeof key_value !== 'string') {
    return res.status(400).json({ error: 'Invalid key_value' });
  }

  try {
    const userId = req.userId; // injected by requireAdmin auth middleware
    const newId = crypto.randomUUID();
    await pool.query(
        'INSERT INTO system_api_keys (id, key_value, service_name, added_by) VALUES ($1, $2, $3, $4)',
        [newId, key_value.trim(), service_name, userId]
    );

    // Notify gemini service to reload API keys
    const { reloadGeminiKeys } = await import('../services/gemini.ts');
    await reloadGeminiKeys();

    res.json({ success: true, id: newId });
  } catch (error: any) {
    console.error('Failed to add api key:', error);
    if (error.code === '23505') { // unique violation
       return res.status(400).json({ error: 'API key already exists' });
    }
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Delete an API key
apiKeysRouter.delete('/:id', async (req: any, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query('DELETE FROM system_api_keys WHERE id = $1', [id]);
    
    // Notify gemini service to reload API keys
    const { reloadGeminiKeys } = await import('../services/gemini.ts');
    await reloadGeminiKeys();
    
    res.json({ success: true, deleted: result.rowCount > 0 });
  } catch (error) {
    console.error('Failed to delete api key:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

apiKeysRouter.post('/:id/toggle', async (req: any, res) => {
    const { id } = req.params;
    const { is_active } = req.body;
    try {
      await pool.query('UPDATE system_api_keys SET is_active = $1 WHERE id = $2', [is_active, id]);
      
      // Notify gemini service to reload API keys
      const { reloadGeminiKeys } = await import('../services/gemini.ts');
      await reloadGeminiKeys();
      
      res.json({ success: true });
    } catch (error) {
      console.error('Failed to toggle api key:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });  

