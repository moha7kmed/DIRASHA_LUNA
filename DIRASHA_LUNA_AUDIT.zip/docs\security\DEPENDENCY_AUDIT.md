# DEPENDENCY_AUDIT.md — تدقيق سلسلة التوريد (Supply-Chain Audit)

> **تاريخ التنفيذ الفعلي:** 2026-11-17. كل الأرقام أدناه من أوامر **نُفِّذت فعلًا** على المستودع المحلي، ونواتجها مسجلة كما هي. لا توجد أي قيم أسرار.
> **تصنيف:** [مُنفَّذ | Executed] = أمر فعلي بناتجه؛ [مُتحقق | Verified] = قراءة ملفات/lockfile؛ [تحليل | Analysis] = استنتاج.

---

## 1. نتائج الأوامر المنفذة اليوم

| الأمر | النتيجة الفعلية | التصنيف |
|---|---|---|
| `npm audit --omit=dev` | **`found 0 vulnerabilities`** — exit 0 | [مُنفَّذ] |
| `npm run sbom` (cyclonedx-npm → sbom.json) | نجح؛ **371 component** (+ الجذر = 372)، serial: `urn:uuid:4526f72f-…` | [مُنفَّذ] |
| `npm run license-check` | `[license-check] wrote license-summary.json (203 production packages)` ثم **`PASS — no denied licenses in production dependencies`** مع تحذير واحد: `dirasha@0.0.0: UNLICENSED (private package, no license field)` — exit 0 | [مُنفَّذ] |
| `npm run scan-secrets` | **`PASS — no secrets detected across 182 tracked files`** — exit 0 | [مُنفَّذ] |
| `npm outdated` | drift موجود — انظر §5 | [مُنفَّذ] |

**ملاحظة عدّية صادقة:** lockfile يحوي **517 صفًا** (بدون الجذر) [مُتحقق — عدّ من package-lock.json: `packages` ما عدا `""`]، بينما SBOM يعدّ 371 — الفرق طبيعي (CycloneDX يدمج/يستثني بعض الصفوف مثل workspace links)، والعدّان مسجلان كما هما لتوثيق الفروق.

## 2. أعداد الاعتمادات [مُتحقق — package-lock.json]

| البند | العدد |
|---|---|
| إجمالي الصفوف في lockfile (بدون الجذر) | **517** |
| اعتمادات مباشرة production (`dependencies`) | **25** |
| اعتمادات مباشرة dev (`devDependencies`) | **25** |
| إجمالي المباشر | **50** |
| حزم production في license-summary | **203** |
| مكوّنات SBOM | **371** |

## 3. الحزم التشفيرية الحاسمة — النسخ المثبتة [مُتحقق — lockfile]

| الحزمة | المثبتة | range في package.json | الأحدث (npm outdated) | Maintainer الفعلي [مُنفَّذ — `npm view`] |
|---|---|---|---|---|
| @noble/ciphers | **1.3.0** | ^1.3.0 | 2.4.0 | paulmillr |
| @noble/curves | **1.9.7** | ^1.9.7 | 2.4.0 | paulmillr |
| @noble/hashes | **1.8.0** | ^1.8.0 | 2.4.0 | paulmillr |
| @noble/post-quantum | **0.7.1** | ^0.7.1 | — (لم يظهر في outdated مقطوع العرض) | paulmillr |
| @simplewebauthn/browser | **13.3.0** | ^13.3.0 | 14.0.0 | iamkale |
| @simplewebauthn/server | **13.3.3** | ^13.3.3 | 14.1.0 | iamkale |
| qrcode | **1.5.4** | ^1.5.4 | (1.x latest) | soldair, vigreco |

**تحليل التشذيب (typosquatting):** فُحصت **جميع الاعتمادات المباشرة الخمسين** عبر `npm view <name> maintainers` — كلها تُحل على السجل الرسمي مع maintainers معروفين (react/react-dom من fb، typescript من microsoft1es، vite من yyx990803، express من wesleytodd/ctcpip، pg من brianc، …). **لا أسماء مشتبهة، لا حزم غير موجودة، لا maintainers منفردين بأسماء عشوائية** [مُنفَّذ — القائمة الكاملة فوق أثناء التشغيل]. الحزم التشفيرية تعتمد جميعها على maintainer واحد (paulmillr) — نقطة تركيز ثقة تسلسلي (single point of trust) تستحق المراقبة عند الترقية [تحليل].

## 4. الحزم المهجورة (deprecated) [مُنفَّذ — `npm ls --all`]

`npm ls --all` لم يُظهر أي سطر `deprecated` أو `UNMET` أو `invalid`. **لا حزم مهجورة في الشجرة المثبتة حاليًا.** (ملاحظة: `qrcode@1.5.4` قديمة النشاط لكنها ليست deprecated رسميًا؛ `license-checker@25.0.1` في devDeps تعتمد شجرة قديمة لكنها خارج runtime).

## 5. الانحراف الإصداري (drift) — مقتطف من `npm outdated` الفعلي [مُنفَّذ]

| الحزمة | الحالية | الأحدث | ملاحظة |
|---|---|---|---|
| @noble/hashes | 1.8.0 | 2.4.0 | **تشفيري — ترقية major تتطلب مراجعة يدوية** |
| @noble/curves | 1.9.7 | 2.4.0 | **تشفيري — major** |
| @noble/ciphers | 1.3.0 | 2.4.0 | **تشفيري — major** |
| @simplewebauthn/server | 13.3.3 | 14.1.0 | تشفيري (WebAuthn) — major |
| express | 4.22.3 | 5.3.0 | major — عمدًا على 4.x |
| ioredis | 5.10.1 | 6.0.0 | major |
| @electric-sql/pglite | 0.5.8 | 0.5.16 | تحديث minor متاح |

**التصنيف:** drift طبيعي وليس فيه أي CVE نشط (audit = 0). مخاطر major upgrades التشفيرية تتطلب مراجعة بشرية وليست أتمتة.

## 6. التطبيق الفعلي في CI مقابل محلي (سؤال التدقيق: هل الإلزام فعليًا في CI؟) [مُتحقق — .github/workflows/verify.yml]

| البوابة | محليًا (script) | **في CI؟** | تفاصيل |
|---|---|---|---|
| gitleaks (تاريخ كامل) | — | **نعم** — `gitleaks/gitleaks-action@v2` على push/PR إلى master، fetch-depth: 0 | يفشل الـ run عند وجود نتيجة |
| scan-secrets | `npm run scan-secrets` | **نعم** — خط مستقل ("defense in depth") | بوابة فاشلة |
| npm audit --omit=dev --audit-level=high | `npm run audit-prod` | **نعم** — HIGH/CRITICAL تُفشل؛ moderate/low تحذير فقط | يعمل على push/PR + جدول أسبوعي (dependency-audit-weekly) |
| license-check | `npm run license-check` | **نعم** — يفشل على GPL/AGPL/LGPL | artifact license-summary لمدة 90 يومًا |
| SBOM (CycloneDX) | `npm run sbom` | **نعم** — artifact sbom-cyclonedx ‏90 يومًا | sbom.json gitignored ولا يُعهد للـ git |
| outdated report | `npm run outdated-report` | **أسبوعيًا فقط** (cron `0 3 * * 1`) — artifact | لا يفشل الـ build |
| typecheck + npm test + build | scripts | **نعم** على push/PR | خطوات Typecheck / Full test suite / Build |
| Build provenance (SHA256SUMS) | — | **نعم** — artifact build-provenance | التوثيق نفسه صريح: **ليست builds قابلة لإعادة الإنتاج** (لا reproducible builds بعد) |

**الخلاصة الصادقة:** الإلزام فعلًا في CI، وليس سكربتات محلية فقط — استثناء واحد: فحص outdated المعلوماتي أسبوعي فقط، ولا يوجد gate يمنع ترقية حزم تشفيرية major بدون مراجعة (يُنصح به يدويًا). CI triggers: push/PR إلى master + cron أسبوعي [verify.yml:6-15].

## 7. تواريخ آخر تدقيق

- **آخر commit لتدقيق أمني في المستودع:** `11e43c5` (2026-11-17) "feat(security): KT client verification contract + passkeys live battery" [مُتحقق — git log].
- **أوراق تدقيق سابقة في docs:** SECURITY_AUDIT_V2_AR.md، SECURITY_PRIVACY_AUDIT.md، docs/security/* (E2EE_AUDIT.md وغيرها) — جولة 2026-11 [مُتحقق — وجود الملفات].
- **تاريخ تنفيذ هذا الملف:** 2026-11-17 (أوامر audit/sbom/license/secrets/outdated كلها نُفذت في هذا اليوم).

## 8. توصيات مرتبة بالأولوية

1. **P1:** تجميد الـ ranges التشفيرية (إزالة `^` من @noble/* و@simplewebauthn/* في package.json) — الترقية تمر حاليًا بالـ lockfile فقط.
2. **P1:** إجراء مراجعة diff إلزامية لأي bump لحزم @noble/* (موثق في THREAT_MODEL §2(g)).
3. **P2:** تفعيل `npm pkg set license` لتصفية تحذير UNLICENSED في license-check.
4. **P2:** متابعة تقادم qrcode وlicense-checker (dev) واستبدالهما لاحقًا إن توقفتا.
5. **P3:** مشروع reproducible builds (موثق بالفعل في verify.yml كخطة متابعة).
