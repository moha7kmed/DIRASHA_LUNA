/**
 * Passkeys / WebAuthn Routes (Project 9) — an ADDITIONAL login method
 * -------------------------------------------------------------------
 *   POST   /api/auth/passkeys/register-options  (auth) → PublicKeyCredentialCreationOptionsJSON
 *   POST   /api/auth/passkeys/register-verify   (auth) → store the credential
 *   POST   /api/auth/passkeys/login-options             → PublicKeyCredentialRequestOptionsJSON (username-keyed)
 *   POST   /api/auth/passkeys/login-verify              → SAME session tokens as password login
 *   GET    /api/auth/passkeys                   (auth) → list own credentials
 *   DELETE /api/auth/passkeys/:credentialId     (auth) → remove own credential (ownership enforced)
 *
 * SECURITY MODEL (honest limits, mirrored in the UI text):
 *   - Passkeys protect AUTHENTICATION only. Passwords remain a first-class
 *     login path and are never removed or bypassed.
 *   - Passkeys are NOT related to the E2EE message keys: end-to-end encryption
 *     keys live exclusively in each device's IndexedDB vault (docs/E2EE-GUIDE-ar.md)
 *     and a passkey login does NOT restore or export them.
 *
 * AUTH-02 hardening:
 *   - userVerification is REQUIRED at enrollment (authenticatorSelection) and
 *     enforced at registration verification (requireUserVerification: true) —
 *     possession of the key alone is never enough.
 *   - Step-up: register-verify and credential DELETE require a FRESH
 *     authentication event — the access JWT's auth_time/iat within the last
 *     5 minutes (isFreshAuthEvent) OR an explicit body.password re-verification
 *     against the stored peppered scrypt hash (same verifySecret as the classic
 *     login). Denied attempts are audit-logged (passkey_stepup_denied).
 *   - Every new credential registration writes an audit line
 *     (passkey_registered: ip + truncated credential id + device class).
 *
 * Challenge handling (documented choice): server-side in-memory store with a
 * 5-minute TTL, one-time consumed at verify time. Acceptable for this
 * deployment model; multi-instance deployments would move it to Redis (the
 * distributed limiter's backing store) — the ChallengeStore API below is
 * shaped so that swapping the backend is a one-class change.
 *
 * Origin / RP-ID: rpID = request host without port (x-forwarded-host first,
 * then Host), overridable via PASSKEYS_RP_ID env. expectedOrigin = the
 * request's Origin header, so cross-origin assertions are rejected both by
 * the explicit originMatchesRpId() gate and by @simplewebauthn/server.
 *
 * Clone detection: the WebAuthn signature counter is strictly monotonic —
 * an assertion whose counter is <= the stored counter (for counter-capable
 * authenticators) is treated as a cloned credential: rejected AND the
 * credential is invalidated (deleted) immediately.
 */

import type { Express, Request, Response, NextFunction } from 'express';
import {
  generateRegistrationOptions,
  verifyRegistrationResponse,
  generateAuthenticationOptions,
  verifyAuthenticationResponse,
} from '@simplewebauthn/server';
import type { RegistrationResponseJSON, AuthenticationResponseJSON, AuthenticatorTransportFuture } from '@simplewebauthn/server';
import { pool } from '../database.ts';
import { AuthService } from '../services/auth.ts';
import { verifySecret } from '../services/password.ts';
import { logger } from '../logger.ts';
import { SecurityAlertsService } from '../services/securityAlerts.ts';
import type { RateLimitRuleName } from '../services/rate_limiter.ts';

interface PasskeyRouteDeps {
  requireAuth: (req: Request, res: Response, next: NextFunction) => void;
  /** Project 5: table-driven distributed limiter — true = rate limited (deny). */
  checkLimit: (rule: RateLimitRuleName, key: string) => Promise<boolean>;
}

/* ===================== Pure helpers (unit-tested) ===================== */

/**
 * AUTH-07 (external audit): hardened client IP extraction — REUSES the
 * TRUST_PROXY_HOPS-aware helpers from authClassic.ts (single source): the
 * first client-supplied XFF entry was spoofable; the trusted Nth-from-right
 * entry is used only when TRUST_PROXY_HOPS is explicitly configured
 * (Render = 1), else socket.remoteAddress. Fail-closed on degenerate cases.
 */
import { clientIp } from './authClassic.ts';
void clientIp;

/** rpID = host without port (IPv6-aware). Empty host → empty rpID (caller rejects). */
export function deriveRpIdFromHost(host: string | undefined): string {
  if (!host) return '';
  const trimmed = String(host).trim().toLowerCase();
  if (trimmed.startsWith('[')) {
    const end = trimmed.indexOf(']');
    return end === -1 ? trimmed.slice(1) : trimmed.slice(1, end);
  }
  return trimmed.split(':')[0];
}

/** The host the RP ID should be derived from (proxy-aware) or the env override. */
function requestHost(req: Request): string | undefined {
  const envRp = process.env.PASSKEYS_RP_ID;
  if (envRp) return envRp;
  const fwd = req.headers['x-forwarded-host'];
  if (typeof fwd === 'string' && fwd.length > 0) return fwd.split(',')[0].trim();
  if (Array.isArray(fwd) && fwd.length > 0) return String(fwd[0]).trim();
  return req.headers.host;
}

/**
 * Strict same-site gate: the presented Origin's hostname must EXACTLY equal
 * the rpID (no subdomain delegation — Dirasha serves from a single host).
 * Rejects non-https origins except localhost (WebAuthn allows secure-context
 * localhost for development).
 */
export function originMatchesRpId(origin: string | undefined, rpId: string): boolean {
  if (!origin || typeof origin !== 'string' || !rpId) return false;
  try {
    const u = new URL(origin);
    if (u.protocol !== 'https:' && !['localhost', '127.0.0.1', '[::1]'].includes(u.hostname)) return false;
    return u.hostname.toLowerCase() === rpId.toLowerCase();
  } catch {
    return false; // 'null' origin, garbage, opaque origins — never allowed
  }
}

/**
 * WebAuthn signature-counter monotonicity (clone detection).
 * Counter-capable authenticators MUST present a counter STRICTLY greater
 * than the stored one; anything less-or-equal (beyond the counterless
 * 0/0 case below) means the credential was cloned → reject + invalidate.
 * The stored=0 && next=0 case is the WebAuthn-spec "authenticator does not
 * maintain a counter" mode (e.g. some platform passkeys) and is accepted.
 */
export function checkCounterMonotonic(
  stored: number,
  next: number,
): { ok: boolean; clone: boolean; reason?: string } {
  if (!Number.isFinite(stored) || !Number.isFinite(next) || stored < 0 || next < 0) {
    return { ok: false, clone: true, reason: 'invalid_counter' };
  }
  if (next > stored) return { ok: true, clone: false };
  if (stored === 0 && next === 0) return { ok: true, clone: false, reason: 'counterless_authenticator' };
  return {
    ok: false,
    clone: true,
    reason: next < stored ? 'counter_regressed' : 'counter_not_increased',
  };
}

/** Ownership gate for every read/delete of a credential row. */
export function assertCredentialOwnership(rowUserId: string | null | undefined, requesterUserId: string): boolean {
  return typeof rowUserId === 'string' && rowUserId.length > 0 && rowUserId === requesterUserId;
}

/* ──────────────── AUTH-02: step-up authentication policy ──────────────── */

/**
 * How fresh an authentication event must be for a SENSITIVE passkey
 * operation (credential registration / deletion).
 */
export const STEP_UP_FRESH_WINDOW_MS = 5 * 60 * 1000; // 5 minutes

/**
 * AUTH-02 (documented policy): a mutating passkey operation must be backed by
 * a FRESH authentication event. The preferred signal is the access JWT the
 * request was authenticated with:
 *   - claims.auth_time when present (AUTH-03 stamps it on every token), else
 *     claims.iat (every JWT carries iat, so pre-AUTH-03 tokens are covered);
 *   - considered fresh when issued within STEP_UP_FRESH_WINDOW_MS (5 minutes).
 * A small forward-skew tolerance (30s) absorbs clock drift between nodes.
 * When no fresh claim exists, the route falls back to an explicit password
 * re-verification in the request body (see assertStepUp in the route block).
 */
export function isFreshAuthEvent(
  claims: { auth_time?: unknown; iat?: unknown } | null | undefined,
  now: number = Date.now(),
): boolean {
  if (!claims || typeof claims !== 'object') return false;
  const at = typeof claims.auth_time === 'number' && Number.isFinite(claims.auth_time) && claims.auth_time > 0
    ? claims.auth_time
    : (typeof claims.iat === 'number' && Number.isFinite(claims.iat) && claims.iat > 0 ? claims.iat : null);
  if (at === null) return false;
  const issuedMs = at * 1000;
  if (issuedMs > now + 30_000) return false; // future-skewed → never fresh
  return now - issuedMs <= STEP_UP_FRESH_WINDOW_MS;
}

/**
 * Server-side challenge store: 5-minute TTL, one-time consumption.
 * Keys: `reg:<userId>` for registration, `auth:<username>` for login.
 * In-memory BY DESIGN (documented above) — swap-in point for Redis if the
 * deployment grows to multiple instances.
 */
export class ChallengeStore {
  private entries = new Map<string, { challenge: string; expires: number }>();
  private gcTimer: NodeJS.Timeout | null = null;

  constructor(private ttlMs = 5 * 60 * 1000, private now: () => number = Date.now) {}

  /** Fresh single-use challenge (base64url, 32 random bytes). */
  issue(key: string): string {
    const buf = globalThis.crypto.getRandomValues(new Uint8Array(32));
    const challenge = Buffer.from(buf).toString('base64url');
    this.set(key, challenge);
    return challenge;
  }

  /** Store a challenge that was generated elsewhere (e.g. by the library's options generator). */
  set(key: string, challenge: string): void {
    this.entries.set(key, { challenge, expires: this.now() + this.ttlMs });
  }

  /** One-time consume: returns the challenge if present and unexpired, else null. */
  consume(key: string): string | null {
    const e = this.entries.get(key);
    this.entries.delete(key); // single-use regardless of outcome
    if (!e) return null;
    if (e.expires < this.now()) return null; // TTL expired
    return e.challenge;
  }

  /** Peek without consuming (kept for tests/ops introspection). */
  peek(key: string): { challenge: string; expired: boolean } | null {
    const e = this.entries.get(key);
    if (!e) return null;
    return { challenge: e.challenge, expired: e.expires < this.now() };
  }

  startGc(intervalMs = 60_000): void {
    if (this.gcTimer) return;
    this.gcTimer = setInterval(() => {
      const now = this.now();
      for (const [k, v] of this.entries) if (v.expires < now) this.entries.delete(k);
    }, intervalMs);
    this.gcTimer.unref?.();
  }

  size(): number {
    const now = this.now();
    let live = 0;
    for (const v of this.entries.values()) if (v.expires >= now) live++;
    return live;
  }
}

/** Shared module-level stores (challenges live 5 minutes max). */
const registrationChallenges = new ChallengeStore();
const authenticationChallenges = new ChallengeStore();
registrationChallenges.startGc();
authenticationChallenges.startGc();

/* ===================== Credential DB helpers ===================== */

interface PasskeyRow {
  id: number;
  user_id: string;
  credential_id: string;
  public_key: string;
  counter: number;
  transports: string | null;
  device_type: string | null;
  created_at: Date | string;
  last_used_at: Date | string | null;
}

async function listUserCredentials(userId: string): Promise<PasskeyRow[]> {
  const { rows } = await pool.query(
    `SELECT id, user_id, credential_id, public_key, counter, transports, device_type, created_at, last_used_at
       FROM webauthn_credentials WHERE user_id = $1 ORDER BY created_at DESC`,
    [userId],
  );
  return rows as PasskeyRow[];
}

async function insertCredential(userId: string, cred: {
  credentialId: string; publicKeyB64: string; counter: number; transports: string | null; deviceType: string;
}): Promise<void> {
  await pool.query(
    `INSERT INTO webauthn_credentials (user_id, credential_id, public_key, counter, transports, device_type)
     VALUES ($1, $2, $3, $4, $5, $6)`,
    [userId, cred.credentialId, cred.publicKeyB64, cred.counter, cred.transports, cred.deviceType],
  );
}

async function updateCredentialUsage(credentialId: string, newCounter: number): Promise<void> {
  await pool.query(
    `UPDATE webauthn_credentials SET counter = $2, last_used_at = now() WHERE credential_id = $1`,
    [credentialId, newCounter],
  );
}

/** Invalidate (delete) a credential — used for clone detection + user deletes. */
async function deleteCredential(credentialId: string, userId?: string): Promise<number> {
  const { rowCount } = userId
    ? await pool.query(`DELETE FROM webauthn_credentials WHERE credential_id = $1 AND user_id = $2`, [credentialId, userId])
    : await pool.query(`DELETE FROM webauthn_credentials WHERE credential_id = $1`, [credentialId]);
  return rowCount || 0;
}

function isUniqueViolation(err: unknown): boolean {
  return typeof err === 'object' && err !== null && (err as { code?: string }).code === '23505';
}

/* ===================== Route registration ===================== */

export function registerPasskeyRoutes(app: Express, deps: PasskeyRouteDeps): void {
  const { requireAuth, checkLimit } = deps;

  /** Same refresh-cookie binding as the classic auth routes (rotation parity). */
  const bindRefreshCookie = (res: Response, refreshToken: string): void => {
    res.cookie('refreshToken', refreshToken, {
      httpOnly: true,
      secure: true,
      sameSite: 'none', // required for the sandboxed-iframe preview environment
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });
  };

  /** Every WebAuthn operation is browser-only → a real Origin header is mandatory. */
  const requiredOrigin = (req: Request): string | null => {
    const origin = req.headers.origin;
    if (!origin || typeof origin !== 'string' || origin === 'null') return null;
    try { return new URL(origin).origin; } catch { return null; }
  };

  /**
   * AUTH-02 step-up gate for SENSITIVE operations (credential registration,
   * credential deletion). Policy (documented choice):
   *   1. Preferred — the request's access JWT is itself a fresh authentication
   *      event: claims.auth_time (AUTH-03) or claims.iat within the last
   *      STEP_UP_FRESH_WINDOW_MS (5 minutes).
   *   2. Fallback — an explicit password re-verification: body.password is
   *      checked against the stored scrypt hash with the SAME peppered,
   *      timing-safe verifySecret the classic login route uses (authClassic.ts).
   *      Accounts without a password (OTP-era) can only use path 1.
   * Returns true when the caller presented sufficient fresh proof.
   */
  const assertStepUp = async (req: Request, userId: string): Promise<boolean> => {
    if (isFreshAuthEvent(req.user as { auth_time?: number; iat?: number } | undefined)) return true;
    const password = String((req.body || {}).password || '');
    if (!password) return false;
    const secrets = await db.getUserSecrets(userId);
    if (!secrets?.passwordHash) return false;
    return verifySecret(password, secrets.passwordHash);
  };

  const STEP_UP_ERROR = 'عملية حساسة تتطلب تحققاً حديثاً من هويتك: سجّل الدخول من جديد أو أعد إدخال كلمة المرور.';

  /* ── POST /api/auth/passkeys/register-options (auth) ── */
  app.post('/api/auth/passkeys/register-options', requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.userId;
      // Shares the register-verify budget (10/h) — one enrollment = options + verify = 2 hits.
      if (await checkLimit('passkeys:register-verify', userId)) {
        return res.status(429).json({ error: 'محاولات تسجيل مفاتيح كثيرة. حاول بعد ساعة.' });
      }
      const origin = requiredOrigin(req);
      if (!origin) return res.status(403).json({ error: 'طلب غير صالح: Origin مطلوب لتسجيل مفاتيح المرور.' });
      const rpID = deriveRpIdFromHost(requestHost(req));
      if (!rpID) return res.status(500).json({ error: 'تعذر تحديد نطاق التطبيق لمفاتيح المرور.' });
      if (!originMatchesRpId(origin, rpID)) {
        return res.status(403).json({ error: 'Origin لا يطابق نطاق التطبيق — رُفض الطلب حمايةً من الهجمات العابرة للنطاقات.' });
      }
      const user = await db_getUser(userId);
      if (!user) return res.status(404).json({ error: 'الحساب غير موجود.' });

      const existing = await listUserCredentials(userId);
      const options = await generateRegistrationOptions({
        rpName: 'ديراشة',
        rpID,
        userID: new TextEncoder().encode(user.id),
        userName: user.username || user.id,
        userDisplayName: user.displayName || user.username || user.id,
        attestationType: 'none',
        excludeCredentials: existing.map(c => ({ id: c.credential_id })),
        // AUTH-02: userVerification is REQUIRED — enrollment (and every later
        // assertion) must prove the user's presence/biometric, not just the
        // key's possession.
        authenticatorSelection: { residentKey: 'preferred', userVerification: 'required' },
      });

      // Bind the library-generated challenge to this user (5-min TTL,
      // one-time consumed at register-verify).
      registrationChallenges.set(`reg:${userId}`, options.challenge);
      res.status(200).json(options);
    } catch (err: any) {
      logger.error('[Passkeys] register-options failed:', err?.message);
      res.status(500).json({ error: 'تعذر بدء تسجيل مفتاح المرور. حاول مرة أخرى.' });
    }
  });

  /* ── POST /api/auth/passkeys/register-verify (auth + step-up) ── */
  app.post('/api/auth/passkeys/register-verify', requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.userId;
      if (await checkLimit('passkeys:register-verify', userId)) {
        return res.status(429).json({ error: 'محاولات تسجيل مفاتيح كثيرة. حاول بعد ساعة.' });
      }
      // AUTH-02 step-up: registering a credential is sensitive — demand a
      // fresh authentication event (recent auth_time/iat) or an explicit
      // password re-verification BEFORE any WebAuthn work.
      if (!(await assertStepUp(req, userId))) {
        await logAuth(userId, 'passkey_stepup_denied', { ip: clientIp(req) });
        return res.status(401).json({ error: STEP_UP_ERROR });
      }
      const origin = requiredOrigin(req);
      if (!origin) return res.status(403).json({ error: 'طلب غير صالح: Origin مطلوب.' });
      const rpID = deriveRpIdFromHost(requestHost(req));
      if (!rpID) return res.status(500).json({ error: 'تعذر تحديد نطاق التطبيق لمفاتيح المرور.' });
      if (!originMatchesRpId(origin, rpID)) {
        return res.status(403).json({ error: 'Origin لا يطابق نطاق التطبيق — رُفض الطلب.' });
      }
      const response = (req.body || {}).response as RegistrationResponseJSON | undefined;
      if (!response || typeof response !== 'object' || !response.id || !response.response) {
        return res.status(400).json({ error: 'بيانات تسجيل مفتاح المرور ناقصة أو غير صالحة.' });
      }

      const expectedChallenge = registrationChallenges.consume(`reg:${userId}`);
      if (!expectedChallenge) {
        return res.status(401).json({ error: 'انتهت صلاحية جلسة التسجيل. ابدأ تسجيل مفتاح المرور من جديد.' });
      }

      const user = await db_getUser(userId);
      if (!user) return res.status(404).json({ error: 'الحساب غير موجود.' });

      const verification = await verifyRegistrationResponse({
        response,
        expectedChallenge,
        expectedOrigin: origin,
        expectedRPID: rpID,
        // AUTH-02: matches userVerification:'required' at options level — the
        // assertion MUST carry a user-verification flag (biometric/PIN), and
        // the library rejects registrations where UV did not happen.
        requireUserVerification: true,
      });
      if (!verification.verified || !verification.registrationInfo) {
        return res.status(401).json({ error: 'فشل التحقق من مفتاح المرور.' });
      }

      const { credential, credentialDeviceType } = verification.registrationInfo;
      const publicKeyB64 = Buffer.from(credential.publicKey as unknown as Uint8Array).toString('base64');
      const transports = Array.isArray(credential.transports) ? credential.transports.join(',') : null;

      try {
        await insertCredential(userId, {
          credentialId: credential.id,
          publicKeyB64,
          counter: credential.counter,
          transports,
          deviceType: credentialDeviceType,
        });
      } catch (e: any) {
        if (isUniqueViolation(e)) {
          return res.status(409).json({ error: 'هذا المفتاح مسجّل بالفعل على حساب آخر.' });
        }
        throw e;
      }

      // AUTH-02 audit trail for every NEW credential (no PII beyond the
      // existing pattern: ip + truncated credential id + device class only).
      await logAuth(userId, 'passkey_registered', {
        ip: clientIp(req),
        credentialId: credential.id.slice(0, 16),
        deviceType: credentialDeviceType,
      });
      res.status(200).json({ ok: true, verified: true, message: 'تم تسجيل مفتاح المرور بنجاح.' });
    } catch (err: any) {
      logger.error('[Passkeys] register-verify failed:', err?.message);
      res.status(500).json({ error: 'تعذر تأكيد تسجيل مفتاح المرور. حاول مرة أخرى.' });
    }
  });

  /* ── POST /api/auth/passkeys/login-options ── */
  app.post('/api/auth/passkeys/login-options', async (req: Request, res: Response) => {
    try {
      const username = String((req.body || {}).username || '').toLowerCase().trim();
      if (!username) return res.status(400).json({ error: 'اسم المستخدم مطلوب.' });
      if (await checkLimit('passkeys:login-options', username)) {
        return res.status(429).json({ error: 'محاولات كثيرة على هذا الحساب. انتظر قليلاً.' });
      }
      const origin = requiredOrigin(req);
      if (!origin) return res.status(403).json({ error: 'طلب غير صالح: Origin مطلوب.' });
      const rpID = deriveRpIdFromHost(requestHost(req));
      if (!rpID) return res.status(500).json({ error: 'تعذر تحديد نطاق التطبيق لمفاتيح المرور.' });
      if (!originMatchesRpId(origin, rpID)) {
        return res.status(403).json({ error: 'Origin لا يطابق نطاق التطبيق — رُفض الطلب.' });
      }

      // Anti-enumeration: unknown users AND users with zero passkeys get the
      // exact same generic 401 (bounded by the 30/min limit above).
      const user = await db_getUserByUsername(username);
      const creds = user ? await listUserCredentials(user.id) : [];
      if (!user || creds.length === 0) {
        return res.status(401).json({ error: 'لا يوجد مفتاح مرور مسجّل لهذا الحساب، أو بيانات الدخول غير صحيحة.' });
      }

      const options = await generateAuthenticationOptions({
        rpID,
        allowCredentials: creds.map(c => ({ id: c.credential_id })),
        userVerification: 'preferred',
        timeout: 60_000,
      });

      authenticationChallenges.set(`auth:${username}`, options.challenge);
      res.status(200).json(options);
    } catch (err: any) {
      logger.error('[Passkeys] login-options failed:', err?.message);
      res.status(500).json({ error: 'تعذر بدء الدخول بمفتاح المرور. حاول مرة أخرى.' });
    }
  });

  /* ── POST /api/auth/passkeys/login-verify ── */
  app.post('/api/auth/passkeys/login-verify', async (req: Request, res: Response) => {
    try {
      const ip = clientIp(req);
      const body = req.body || {};
      const username = String(body.username || '').toLowerCase().trim();
      const response = body.response as AuthenticationResponseJSON | undefined;
      if (!username || !response || typeof response !== 'object' || !response.id || !response.response) {
        return res.status(400).json({ error: 'بيانات الدخول ناقصة أو غير صالحة.' });
      }
      if (await checkLimit('passkeys:login-verify', `${username}:${ip}`)) {
        return res.status(429).json({ error: 'محاولات دخول كثيرة بمفاتيح المرور. حاول بعد ساعة.' });
      }
      const origin = requiredOrigin(req);
      if (!origin) return res.status(403).json({ error: 'طلب غير صالح: Origin مطلوب.' });
      const rpID = deriveRpIdFromHost(requestHost(req));
      if (!rpID) return res.status(500).json({ error: 'تعذر تحديد نطاق التطبيق لمفاتيح المرور.' });
      if (!originMatchesRpId(origin, rpID)) {
        return res.status(403).json({ error: 'Origin لا يطابق نطاق التطبيق — رُفض الطلب حمايةً من الهجمات العابرة للنطاقات.' });
      }

      // One-time challenge consumption (5-min TTL) — replays and stale
      // attempts die here before any crypto work.
      const expectedChallenge = authenticationChallenges.consume(`auth:${username}`);
      if (!expectedChallenge) {
        return res.status(401).json({ error: 'انتهت صلاحية جلسة الدخول. ابدأ الدخول بمفتاح المرور من جديد.' });
      }

      const user = await db_getUserByUsername(username);
      const creds = user ? await listUserCredentials(user.id) : [];
      const credRow = creds.find(c => c.credential_id === response.id);
      if (!user || !credRow) {
        return res.status(401).json({ error: 'فشل الدخول بمفتاح المرور: المفتاح غير معروف لهذا الحساب.' });
      }

      let verification;
      try {
        verification = await verifyAuthenticationResponse({
          response,
          expectedChallenge,
          expectedOrigin: origin,
          expectedRPID: rpID,
          requireUserVerification: false,
          credential: {
            id: credRow.credential_id,
            publicKey: new Uint8Array(Buffer.from(credRow.public_key, 'base64')) as unknown as Uint8Array,
            counter: Number(credRow.counter) || 0,
            transports: credRow.transports
              ? (credRow.transports.split(',') as unknown as AuthenticatorTransportFuture[])
              : undefined,
          },
        });
      } catch {
        return res.status(401).json({ error: 'فشل التحقق من مفتاح المرور (توقيع أو تحدٍّ غير صالح).' });
      }
      if (!verification.verified) {
        return res.status(401).json({ error: 'فشل الدخول بمفتاح المرور.' });
      }

      // ── Clone detection: signature counter MUST be strictly monotonic ──
      const counterCheck = checkCounterMonotonic(Number(credRow.counter) || 0, verification.authenticationInfo.newCounter);
      if (!counterCheck.ok || counterCheck.clone) {
        // Cloned credential → reject the login AND invalidate the credential.
        await deleteCredential(credRow.credential_id);
        await logAuth(user.id, 'passkey_clone_detected', {
          ip,
          credentialId: credRow.credential_id.slice(0, 16),
          reason: counterCheck.reason,
        });
        logger.error(`[Passkeys] CLONE DETECTED for user ${user.id} — credential invalidated`);
        return res.status(401).json({ error: 'تم رصد محاولة استخدام مفتاح مُستنسَخ — أُبطل المفتاح لأمانك وسجّل الدخول بكلمة المرور ثم أعد تسجيل مفتاح جديد.' });
      }

      await updateCredentialUsage(credRow.credential_id, verification.authenticationInfo.newCounter);
      await recordLogin(user.id, true);
      await logAuth(user.id, 'login_passkey', { ip, userAgent: req.headers['user-agent'] });

      let sessionBundle;
      try {
        sessionBundle = await AuthService.issueSession(user, req.headers['user-agent'] || 'unknown', ip);
      } catch (e: any) {
        return res.status(403).json({ error: e.message }); // banned
      }

      // Security-alerts parity with password login (fire-and-forget).
      void SecurityAlertsService.notifyNewLogin(user.id, {
        ip,
        userAgent: String(req.headers['user-agent'] || 'unknown'),
      }).catch(() => {});

      bindRefreshCookie(res, sessionBundle.refreshToken);
      // Refresh token rides ONLY the HttpOnly cookie (F6 parity with the
      // password-login paths) — never mirrored in the JSON body.
      res.status(200).json({
        user: sessionBundle.user,
        accessToken: sessionBundle.accessToken,
        sessionId: sessionBundle.sessionId,
        method: 'passkey',
      });
    } catch (err: any) {
      logger.error('[Passkeys] login-verify failed:', err?.message);
      res.status(500).json({ error: 'حدث خطأ أثناء الدخول بمفتاح المرور. حاول مرة أخرى.' });
    }
  });

  /* ── GET /api/auth/passkeys (auth) ── */
  app.get('/api/auth/passkeys', requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.userId;
      const rows = await listUserCredentials(userId);
      const credentials = rows.map(r => ({
        id: r.id,
        credentialId: r.credential_id,
        device: r.device_type || 'unknown',
        transports: r.transports ? r.transports.split(',') : [],
        createdAt: r.created_at,
        lastUsedAt: r.last_used_at,
      }));
      res.status(200).json({ credentials });
    } catch (err: any) {
      logger.error('[Passkeys] list failed:', err?.message);
      res.status(500).json({ error: 'تعذر تحميل قائمة مفاتيح المرور.' });
    }
  });

  /* ── DELETE /api/auth/passkeys/:credentialId (auth + step-up, ownership) ── */
  app.delete('/api/auth/passkeys/:credentialId', requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.userId;
      const credentialId = String(req.params.credentialId || '').trim();
      if (!credentialId) return res.status(400).json({ error: 'معرّف المفتاح مطلوب.' });

      // AUTH-02 step-up: removing a credential is as sensitive as adding one.
      // Fresh JWT (auth_time/iat ≤ 5 min) OR body.password re-verification.
      if (!(await assertStepUp(req, userId))) {
        await logAuth(userId, 'passkey_stepup_denied', { ip: clientIp(req) });
        return res.status(401).json({ error: STEP_UP_ERROR });
      }

      // Ownership: the delete is scoped to the caller's own rows — a foreign
      // credentialId simply matches nothing (404), never another user's row.
      const deleted = await deleteCredential(credentialId, userId);
      if (deleted === 0) {
        return res.status(404).json({ error: 'المفتاح غير موجود أو لا يملكه هذا الحساب.' });
      }
      await logAuth(userId, 'passkey_removed', { ip: clientIp(req) });
      res.status(200).json({ ok: true, message: 'تم حذف مفتاح المرور.' });
    } catch (err: any) {
      logger.error('[Passkeys] delete failed:', err?.message);
      res.status(500).json({ error: 'تعذر حذف مفتاح المرور. حاول مرة أخرى.' });
    }
  });
}

/* ===================== Small local shims (keep the route module decoupled
   from the huge database facade; direct SQL above, users read via the
   facade for parity with authClassic) ===================== */

import { db } from '../database.ts';

async function db_getUser(userId: string) {
  return db.getUserById(userId);
}
async function db_getUserByUsername(username: string) {
  return db.getUserByUsername(username);
}
async function logAuth(userId: string, action: string, metadata: Record<string, unknown>): Promise<void> {
  try { await db.logAuthAction(userId, action, metadata); } catch { /* audit is best-effort */ }
}
async function recordLogin(userId: string, success: boolean): Promise<void> {
  try { await db.recordLoginResult(userId, success); } catch { /* best-effort */ }
}
