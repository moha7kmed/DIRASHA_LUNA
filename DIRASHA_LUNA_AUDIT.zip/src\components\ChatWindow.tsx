/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { Paperclip, Check, CheckCheck, Loader2, Info, ArrowLeft, ArrowRight, Download, FileText, FileSpreadsheet, FileArchive, FileAudio, Mic, Star, Trash2, CornerUpLeft, Smile, X, MoreVertical, Play, Pause, Square, Image as ImageIcon, Edit2, Pin, Clock, AlertCircle, Phone, Video, Maximize2, Camera, MapPin, User, Users, Music, Copy, Forward, Eye, Link, ShieldAlert, RefreshCw, Search, BarChart2, Plus, Minus, Megaphone, Languages, Sticker, Bold, Italic, Strikethrough, Code, CheckSquare, Lock, Unlock } from 'lucide-react';
import { E2eeSafetyModal, e2eeVerifiedKey, e2eeRekeyFlagKey, e2eeLastSnKey, cleanSafetyNumber } from './E2eeSafetyModal.tsx';
import { motion, AnimatePresence } from 'motion/react';
import { ImageEditor } from './ImageEditor';
import { VerifiedBadge } from './VerifiedBadge';
import { uploadImageToStorage, compressAndConvertImage, uploadMediaFile, uploadFileToDrive, StorageNotLinkedError, startGdriveConsent } from '../lib/storageUtils';
import { encryptAttachment, decryptAttachment } from '../lib/e2ee/media.ts';
import type { AttachmentPayload } from '../lib/e2ee/media.ts';
import { E2eeMedia } from './E2eeMedia';
import { MediaGate } from './MediaGate';
import { GroupSettingsPanel } from './GroupSettingsPanel';
import { Virtuoso } from 'react-virtuoso';

import type { ClientMessage, DeliveryState, SearchResult, MediaItem, PollData } from '../types.ts';
import { SocketManager } from '../lib/socket_manager.ts';

/* ══ Encrypt-at-source media upload (F1/P0 fix) ═══════════════════════════════
 * In E2EE-eligible chats the PLAINTEXT original must never hit the network:
 * each pre-upload site encrypts the bytes locally (encryptAttachment) and
 * uploads ONLY the opaque ciphertext blob as application/octet-stream
 * 'enc.bin' (no real filename / mime in Drive metadata). The decryption
 * payload rides IN MEMORY on `meta.e2eePayload` so App's send wrap can embed
 * it INSIDE the encrypted message envelope (buildEncryptedPayload) — App
 * strips it from the wire attachment, so it is never serialized to the
 * server. Non-eligible (legacy/plain) chats keep the plaintext upload path. */
async function encryptAndUploadAttachment(
  bytes: Uint8Array,
  mime: string,
  name: string,
  extraMeta?: Record<string, unknown>,
): Promise<any> {
  const enc = encryptAttachment(bytes, mime || 'application/octet-stream', name || 'file');
  const uploaded = await uploadFileToDrive(
    new Blob([enc.blob as BlobPart], { type: 'application/octet-stream' }),
    'enc.bin'
  );
  return {
    id: enc.payload.attId,
    url: uploaded.url,
    mimeType: 'application/octet-stream',
    name: 'enc.bin',
    size: enc.blob.length,
    meta: { ...(extraMeta || {}), e2ee: true, attId: enc.payload.attId, e2eePayload: enc.payload },
  };
}

// High-fidelity standard WAV container encoder to bypass browser-specific codec and resampling slow-motion/pitch bugs
function writeString(view: DataView, offset: number, string: string) {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}

function floatTo16BitPCM(output: DataView, offset: number, input: Float32Array) {
  for (let i = 0; i < input.length; i++, offset += 2) {
    let s = Math.max(-1, Math.min(1, input[i]));
    output.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
  }
}

function encodeWAV(samples: Float32Array, sampleRate: number): Blob {
  const buffer = new ArrayBuffer(44 + samples.length * 2);
  const view = new DataView(buffer);

  /* RIFF identifier */
  writeString(view, 0, 'RIFF');
  /* file length */
  view.setUint32(4, 36 + samples.length * 2, true);
  /* RIFF type */
  writeString(view, 8, 'WAVE');
  /* format chunk identifier */
  writeString(view, 12, 'fmt ');
  /* format chunk length */
  view.setUint32(16, 16, true);
  /* sample format (raw PCM) */
  view.setUint16(20, 1, true);
  /* channel count (1 = mono) */
  view.setUint16(22, 1, true);
  /* sample rate */
  view.setUint32(24, sampleRate, true);
  /* byte rate (sample rate * block align) */
  view.setUint32(28, sampleRate * 2, true);
  /* block align (channel count * bytes per sample) */
  view.setUint16(32, 2, true);
  /* bits per sample (16-bit) */
  view.setUint16(34, 16, true);
  /* data chunk identifier */
  writeString(view, 36, 'data');
  /* data chunk length */
  view.setUint32(40, samples.length * 2, true);

  floatTo16BitPCM(view, 44, samples);

  return new Blob([view], { type: 'audio/wav' });
}

// Custom emoji categories with zero external dependencies representing standard Unicode groupings
const EMOJI_CATEGORIES = [
  {
    name: 'وجوه وتعابير',
    emojis: ['😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '😊', '😇', '🙂', '🙃', '😉', '😌', '😍', '🥰', '😘', '😗', '😙', '😚', '😋', '😛', '😝', '😜', '🤪', '🤨', '🧐', '🤓', '😎', '🥸', '🤩', '🥳', '😏', '😒', '😞', '😔', '😟', '😕', '🙁', '☹️', '😣', '😖', '😫', '😩', '🥺', '😢', '😭', '😤', '😠', '😡', '🤬', '🤯', '😳', '🥵', '🥶', '😱', '😨', '😰', '😥', '😓', '🤗', '🤔', '🫣', '🤭', '🫢', '🤫', '🫠', '🤥', '😶', '😐', '😑', '😬', '🙄', '😯', '😧', '😮', '😲', '🥱', '😴', '🤤', '😪', '😵', '😵‍💫', '🤐', '🥴', '🤢', '🤮', '🤧', '😷', '🤒', '🤕', '🤑', '🤠', '😈', '👿', '👹', '👺', '🤡', '💩', '👻', '💀', '☠️', '👽', '👾', '🤖', '🎃', '😺', '😸', '😹', '😻', '😼', '😽', '🙀', '😿', '😾']
  },
  {
    name: 'قلوب وأيدي',
    emojis: ['👋', '🤚', '🖐️', '✋', '🖖', '👌', '🤌', '🤏', '✌️', '🤞', '🤟', '🤘', '🤙', '👈', '👉', '👆', '🖕', '👇', '☝️', '👍', '👎', '✊', '👊', '🤛', '🤜', '👏', '🙌', '👐', '🤲', '🤝', '🙏', '✍️', '💅', '🤳', '💪', '🦾', '🦿', '🦵', '🦶', '👂', '🦻', '👃', '🧠', '🫀', '🫁', '🦷', '🦴', '👀', '👁️', '👅', '👄', '💋', '🩸', '❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔', '❤️‍🔥', '❤️‍🩹', '❣️', '💕', '💞', '💓', '💗', '💖', '💘', '💝', '💟']
  },
  {
    name: 'حيوانات وطبيعة',
    emojis: ['🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼', '🐨', '🐯', '🦁', '🐮', '🐷', '🐽', '🐸', '🐵', '🙈', '🙉', '🙊', '🐒', '🐔', '🐧', '🐦', '🐤', '🐣', '🐥', '🦆', '🦢', '🦅', '🦉', '🦤', '🪶', '🦩', '🦚', '🦜', '🐊', '🐢', '🦎', '🐍', '🐉', '🦕', '🦖', '🐳', '🐋', '🐬', '🐟', '🐠', '🐡', '🦈', '🐙', '🐚', '🐌', '🦋', '🐛', '🐜', '🐝', '🪲', '🐞', '🦗', '🕷️', '🕸️', '🦂', '🦟', '🪰', '🪱', '💐', '🌸', '💮', '🏵️', '🌹', '🥀', '🌺', '🌻', '🌼', '🌷', '🌱', '🪴', '🌲', '🌳', '🌴', '🌵', '🌾', '🌿', '☘️', '🍀', '🍁', '🍂', '🍃']
  },
  {
    name: 'طعام وشراب',
    emojis: ['🍏', '🍎', '🍐', '🍊', '🍋', '🍌', '🍉', '🍇', '🍓', '🫐', '🍈', '🍒', '🍑', '🥭', '🍍', '🥥', '🥝', '🍅', '🍆', '🥑', '🥦', '🥬', '🥒', '🌶️', '🫑', '🧅', '🧄', '🥕', '🌽', '🥔', '🍠', '🥐', '🥯', '🍞', '🥖', '🥨', '🧀', '🥚', '🍳', '🧈', '🥞', '🧇', '🥓', '🥩', '🍗', '🍖', '🌭', '🍔', '🍟', '🍕', '🥪', '🥙', '🫓', '🌮', '🌯', '🫔', '🥗', '🥘', '🍲', '🫕', '🥣', '🍿', '🧂', '🥫', '🍱', '🍘', '🍙', '🍚', '🍛', '🍜', '🍝', '🍢', '🍣', '🍤', '🍥', '🦪', '🍡', '🥟', '🥠', '🥡', '🍦', '🍧', '🍨', '🍩', '🍪', '🎂', '🍰', '🧁', '🥧', '🍫', '🍬', '🍭', '💡', '🍯', '🍼', '🥛', '☕', '🫖', '🍵', '🍶', '🍾', '🍷', '🍸', '🍹', '🍺', '🍻', '🥂', '🥃', '🥤', '🧋', '🧃', '🧉', '🧊']
  },
  {
    name: 'أنشطة وألعاب',
    emojis: ['⚽', '🏀', '🏈', '⚾', '🥎', '🎾', '🏐', '🏉', '🥏', '🎱', '🪀', '🏓', '🏑', '🏹', '🎣', '🤿', '🥊', '🥋', '🛹', '🛼', '🛷', '⛸️', '🥌', '🎿', '⛷️', '🏂', '🏋️', '🤸', '🤼', '🤽', '🤾', '🤺', '🏇', '🧘', '🏄', '🏊', '🚴', '🚵', '🧗', '🏆', '🥇', '🥈', '🥉', '🏅', '🎫', '🎟️', '🎪', '🎭', '🖼️', '🎨', '🎬', '🎤', '🎧', '🎼', '🎹', '🥁', '🎸', '🎻', '🎲', '♟️', '🎯', '🎳', '🎮', '🎰', '🧩']
  }
];

const CameraView = ({ onCapture, onClose }: { onCapture: (blob: Blob) => void; onClose: () => void }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let stream: MediaStream | null = null;
    const startCamera = async () => {
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          throw new Error('المتصفح لا يدعم الوصول إلى الكاميرا');
        }
        stream = await navigator.mediaDevices.getUserMedia({ 
          video: { 
            facingMode: 'environment', // Use back camera if available
            width: { ideal: 1920 },
            height: { ideal: 1080 }
          } 
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (err: any) {
        setError(err.message || 'تعذر الدخول إلى الكاميرا. يرجى التحقق من الأذونات.');
        console.error(err);
      }
    };
    startCamera();
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const takePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      
      // Use natural video dimensions for full resolution
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0);
        canvas.toBlob((blob) => {
          if (blob) onCapture(blob);
        }, 'image/jpeg', 0.95);
      }
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[9999] bg-black flex flex-col items-center justify-center overflow-hidden"
    >
      <button 
        type="button"
        onClick={onClose} 
        className="absolute top-8 right-6 z-[10001] text-white p-2.5 bg-black/40 backdrop-blur-md rounded-full border border-white/20 active:scale-90 transition-transform"
      >
        <X size={24} />
      </button>
      
      {error ? (
        <div className="text-white text-center p-8 bg-zinc-900 rounded-3xl border border-white/10 mx-6 max-w-sm">
          <AlertCircle size={48} className="mx-auto mb-4 text-red-500" />
          <h3 className="text-lg font-bold mb-2">خطأ في الكاميرا</h3>
          <p className="text-white/60 text-sm mb-6 leading-relaxed text-center">{error}</p>
          <button onClick={onClose} className="w-full py-3 bg-white text-black font-bold rounded-xl active:scale-95 transition-all">إغلاق</button>
        </div>
      ) : (
        <div className="relative w-full h-full flex flex-col justify-center bg-black">
          <video 
            ref={videoRef} 
            autoPlay 
            playsInline 
            muted
            className="w-full h-full object-cover" 
          />
          <canvas ref={canvasRef} className="hidden" />
          
          <div className="absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-black via-black/40 to-transparent flex items-center justify-center">
             <button 
               type="button"
               onClick={takePhoto}
               className="group relative w-20 h-20 flex items-center justify-center active:scale-90 transition-all duration-150"
             >
               <div className="absolute inset-0 rounded-full border-[4px] border-white/40 group-hover:border-white transition-colors" />
               <div className="w-[62px] h-[62px] rounded-full bg-white shadow-[0_0_20px_rgba(255,255,255,0.3)] active:bg-zinc-200 transition-colors" />
             </button>
          </div>
          
          {/* Minimalist framing guides */}
          <div className="absolute inset-0 pointer-events-none">
             <div className="absolute top-1/2 left-0 w-full h-[0.5px] bg-white/10" />
             <div className="absolute top-0 left-1/2 w-[0.5px] h-full bg-white/10" />
          </div>
        </div>
      )}
    </motion.div>
  );
};

// Custom modern voice player to replace generic bulky HTML controllers
const TypewriterText = ({ content, speed = 12, createdAt }: { content: string, speed?: number, createdAt?: string }) => {
  const [displayedContent, setDisplayedContent] = useState(() => {
    // If message is older than 30 seconds, don't animate (just show full content)
    if (createdAt) {
      const msgTime = new Date(createdAt).getTime();
      const now = Date.now();
      if (now - msgTime > 30000) return content;
    }
    return '';
  });
  const [index, setIndex] = useState(() => (displayedContent.length > 0 ? content.length : 0));

  useEffect(() => {
    if (index < content.length) {
      const timeout = setTimeout(() => {
        setDisplayedContent(prev => prev + content[index]);
        setIndex(prev => prev + 1);
      }, speed);
      return () => clearTimeout(timeout);
    }
  }, [content, index, speed]);

  return <>{displayedContent}</>;
};

/** Human-readable byte size (KB/MB) for file attachment cards. */
function formatFileSize(bytes: unknown): string {
  const n = Number(bytes);
  if (!Number.isFinite(n) || n <= 0) return '';
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

// ── Scheduled messages (Mission B) helpers ──
/** Minimum lead time for a scheduled send: now + 2 minutes. */
const SCHEDULE_MIN_MS = 2 * 60 * 1000;

/** Date → 'YYYY-MM-DDTHH:mm' in local time (value shape for datetime-local inputs). */
function toLocalInputValue(d: Date): string {
  const pad = (n: number) => n.toString().padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/** Human-readable Arabic label for a schedule timestamp (toast / armed chip). */
function formatScheduleLabel(v: string): string {
  const d = new Date(v);
  if (isNaN(d.getTime())) return v;
  return d.toLocaleString('ar', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

// ── Message translation (Mission A) helpers ──
/**
 * Dominant-script language detection for MyMemory (it needs an explicit pair):
 * Arabic-dominant text → 'ar|en', everything else → 'en|ar'.
 */
function detectLangPair(text: string): string {
  const arabic = (text.match(/[\u0600-\u06FF]/g) || []).length;
  const letters = (text.match(/[A-Za-z\u0600-\u06FF]/g) || []).length;
  return letters > 0 && arabic / letters > 0.5 ? 'ar|en' : 'en|ar';
}

/** MyMemory caps q at ~500 bytes; keep within it. */
const TRANSLATE_MAX_QUERY_CHARS = 500;
const TRANSLATE_ENDPOINT = 'https://api.mymemory.translated.net/get';
const TRANSLATE_TIMEOUT_MS = 6000;

/** File-card icon + accent color chosen by file extension. */
function fileIconFor(name: string): { Icon: any; cls: string } {
  const ext = String(name || '').split('.').pop()?.toLowerCase() || '';
  if (['xls', 'xlsx', 'csv'].includes(ext)) return { Icon: FileSpreadsheet, cls: 'text-emerald-400' };
  if (['zip', 'rar', '7z', 'tar', 'gz'].includes(ext)) return { Icon: FileArchive, cls: 'text-amber-400' };
  if (['mp3', 'wav', 'ogg', 'm4a', 'aac', 'flac'].includes(ext)) return { Icon: FileAudio, cls: 'text-pink-400' };
  if (ext === 'pdf') return { Icon: FileText, cls: 'text-red-400' };
  if (['txt', 'md'].includes(ext)) return { Icon: FileText, cls: 'text-slate-300' };
  return { Icon: FileText, cls: 'text-blue-400' };
}

// ── WhatsApp-style rich text formatting (markers stored IN the text) ─────────
// Safe tokenizer: no dangerouslySetInnerHTML, no HTML strings — the parser builds
// an array of plain strings and React elements only. Single pass by priority:
// ``` ``` code fences first, then *bold*, then _italic_, then ~strike~. No
// nesting; unterminated markers render literally (they stay as plain text).

const FORMATTING_MARKERS: Array<{
  char: string;
  render: (children: React.ReactNode[], key: string) => React.ReactNode;
}> = [
  { char: '*', render: (children, key) => <strong key={key} className="font-bold">{children}</strong> },
  { char: '_', render: (children, key) => <em key={key}>{children}</em> },
  { char: '~', render: (children, key) => <s key={key}>{children}</s> },
];

/** Plain-text segment rendering with @mention highlight (WhatsApp parity). */
function renderMentionText(part: string, keyPrefix: string): React.ReactNode[] {
  if (!part || !part.includes('@')) return part ? [part] : [];
  const pieces = part.split(/(@[a-zA-Z0-9_.]{3,20})/g);
  return pieces.map((p, i) =>
    /^@[a-zA-Z0-9_.]{3,20}$/.test(p) ? (
      <span key={`${keyPrefix}-m${i}`} className="bg-blue-500/20 text-blue-300 rounded px-0.5 font-bold">{p}</span>
    ) : (
      <span key={`${keyPrefix}-m${i}`}>{p}</span>
    )
  );
}

/**
 * Inline tokenizer for a non-code segment: applies markers by priority level
 * via an index scan (open marker → next marker = wrapped span; no closer =
 * unterminated → stays literal). Preserves literal text byte-for-byte.
 */
function tokenizeFormatting(text: string, level: number, keyPrefix: string): React.ReactNode[] {
  if (!text) return [];
  const marker = FORMATTING_MARKERS[level];
  if (!marker) return renderMentionText(text, keyPrefix);
  const nodes: React.ReactNode[] = [];
  let rest = text;
  let seq = 0;
  while (rest) {
    const open = rest.indexOf(marker.char);
    if (open === -1) {
      // No marker left in this segment — hand it to the lower-priority markers.
      nodes.push(...tokenizeFormatting(rest, level + 1, `${keyPrefix}-${level}-${seq++}`));
      break;
    }
    if (open > 0) {
      // Literal text before the marker (may itself contain lower-priority markers).
      nodes.push(...tokenizeFormatting(rest.slice(0, open), level + 1, `${keyPrefix}-${level}-${seq++}`));
    }
    const close = rest.indexOf(marker.char, open + marker.char.length);
    if (close === -1) {
      // Unterminated marker → render literally (this marker char is inert below).
      nodes.push(...tokenizeFormatting(rest.slice(open), level + 1, `${keyPrefix}-${level}-${seq++}`));
      break;
    }
    const inner = rest.slice(open + marker.char.length, close);
    if (inner.length > 0) {
      nodes.push(marker.render(
        tokenizeFormatting(inner, level + 1, `${keyPrefix}-${level}-${seq++}`),
        `${keyPrefix}-${level}-w${seq++}`
      ));
    } else {
      // Empty pair (e.g. **) — no span; markers stay as literal text.
      nodes.push(...tokenizeFormatting(marker.char + marker.char, level + 1, `${keyPrefix}-${level}-${seq++}`));
    }
    rest = rest.slice(close + marker.char.length);
  }
  return nodes;
}

/**
 * Full message text → React nodes: ``` ``` fenced blocks render as full-width
 * dark mono cards (markers are never interpreted inside code), everything else
 * goes through the inline *bold* / _italic_ / ~strike~ tokenizer.
 */
function renderFormattedText(text: string, keyPrefix: string): React.ReactNode[] {
  if (!text) return [];
  const nodes: React.ReactNode[] = [];
  const codeBlockRe = /```([\s\S]+?)```/g;
  let cursor = 0;
  let match: RegExpExecArray | null;
  let seq = 0;
  const pushInline = (seg: string, key: string) => {
    if (seg) nodes.push(...tokenizeFormatting(seg, 0, key));
  };
  while ((match = codeBlockRe.exec(text)) !== null) {
    if (match.index > cursor) pushInline(text.slice(cursor, match.index), `${keyPrefix}-s${seq}`);
    seq++;
    nodes.push(
      <code
        key={`${keyPrefix}-code${seq}`}
        dir="ltr"
        className="block w-full my-1.5 px-3 py-2.5 bg-black/40 border border-white/10 rounded-xl font-mono text-[12px] text-emerald-100/90 whitespace-pre-wrap break-words text-left"
      >
        {match[1]}
      </code>
    );
    cursor = match.index + match[0].length;
  }
  pushInline(text.slice(cursor), `${keyPrefix}-s${seq}`);
  return nodes;
}

// ── Stickers (v1) constants ──
/** Client-side recents list key (array of {url,mimeType,name}, max 30, newest first). */
const STICKERS_LS_KEY = 'dirasha_stickers';
const MAX_STICKER_RECENTS = 30;
/** Client-side sticker upload cap (WhatsApp parity: 1MB). */
const MAX_STICKER_BYTES = 1024 * 1024;

/**
 * Sticker bubble image: direct <img> (no MediaGate gate, no card chrome),
 * max 220px, tap → fullscreen, onError → small retry card.
 */
const StickerImage = ({ src, alt, name, onOpen }: { src: string; alt: string; name?: string; onOpen: () => void }) => {
  const [failed, setFailed] = useState(false);
  const [attempt, setAttempt] = useState(0);
  if (failed) {
    return (
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          setFailed(false);
          setAttempt(a => a + 1);
        }}
        className="mt-2 p-3 bg-black/30 border border-white/5 rounded-xl flex items-center gap-2 text-[11px] font-bold text-slate-300 hover:text-white transition-colors cursor-pointer"
        style={{ direction: 'rtl' }}
      >
        <RefreshCw className="w-4 h-4 text-amber-400 shrink-0" />
        <span>تعذر تحميل الملصق — اضغط لإعادة المحاولة</span>
      </button>
    );
  }
  return (
    <img
      key={attempt}
      src={src}
      alt={alt || name || 'ملصق'}
      onError={() => setFailed(true)}
      onClick={(e) => {
        e.stopPropagation();
        onOpen();
      }}
      className="mt-1 max-w-[220px] max-h-[220px] w-auto rounded-2xl cursor-pointer object-contain transition-transform hover:scale-[1.02]"
      referrerPolicy="no-referrer"
      draggable={false}
    />
  );
};

/**
 * Sticker panel thumbnail for ENCRYPTED library stickers (F1/P0
 * encrypt-at-source): the stored blob is opaque 'enc.bin' ciphertext, so the
 * panel decrypts it locally (payload persisted alongside in the recents) and
 * renders a same-origin objectURL. Plaintext never touches the network here —
 * only the ciphertext is fetched back and decrypted in memory.
 */
/* P1-H (external-audit AUTH-05): short-lived SCOPED media tokens — the
 * long-lived access JWT must never appear in media URLs (server-side policy
 * already restricts query tokens to purpose:'media' GETs). Cached 90s with an
 * in-flight guard; failures leave URLs WITHOUT a token (honest 401, no
 * silent fallback to the access JWT).
 */
let mediaTokCache: { token: string; exp: number } | null = null;
const mediaTokInflight = { p: null as Promise<string | null> | null };
async function getScopedMediaToken(accessToken: string): Promise<string | null> {
  if (mediaTokCache && mediaTokCache.exp > Date.now() + 5000) return mediaTokCache.token;
  if (mediaTokInflight.p) return mediaTokInflight.p;
  const p = (async () => {
    try {
      const res = await fetch('/api/media-token', { headers: { Authorization: 'Bearer ' + accessToken } });
      const d = await res.json().catch(() => null);
      if (!res.ok || !d?.token) return null;
      mediaTokCache = { token: String(d.token), exp: Date.now() + 90_000 };
      return mediaTokCache.token;
    } catch {
      return null;
    } finally {
      mediaTokInflight.p = null;
    }
  })();
  mediaTokInflight.p = p;
  return p;
}

const EncryptedStickerThumb = ({ url, payload, accessToken, alt }: { url: string; payload: AttachmentPayload; accessToken?: string; alt?: string }) => {
  const [src, setSrc] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    let dead = false;
    let created: string | null = null;
    (async () => {
      try {
        // P1-H: scoped media token — the access JWT never rides media URLs.
        const mt = accessToken ? await getScopedMediaToken(accessToken) : null;
        const full = url.startsWith('/api') && mt ? `${url}${url.includes('?') ? '&' : '?'}access_token=${mt}` : url;
        const res = await fetch(full);
        if (!res.ok) throw new Error(`fetch failed (${res.status})`);
        const dec = decryptAttachment(payload, new Uint8Array(await res.arrayBuffer()));
        created = URL.createObjectURL(new Blob([dec.bytes as BlobPart], { type: dec.mime || payload.mime || 'image/webp' }));
        if (!dead) setSrc(created);
      } catch {
        if (!dead) setFailed(true);
      }
    })();
    return () => {
      dead = true;
      if (created) URL.revokeObjectURL(created);
    };
  }, [url]);
  if (failed || !src) {
    return (
      <div className="w-full h-full flex items-center justify-center">
        <Lock className="w-4 h-4 text-slate-500" />
      </div>
    );
  }
  return (
    <img
      src={src}
      alt={alt || 'ملصق'}
      className="w-full h-full object-contain"
      referrerPolicy="no-referrer"
      draggable={false}
    />
  );
};

const ModernVoiceMessage = ({ url, size, isMe }: { url: string; size: number; isMe: boolean }) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(1);

  // Dynamic static-wave generation from hashing URL content
  const soundwaveBars = useRef<number[]>([]);
  if (soundwaveBars.current.length === 0) {
    let hash = 0;
    for (let i = 0; i < url.length; i++) {
      hash = url.charCodeAt(i) + ((hash << 5) - hash);
    }
    for (let i = 0; i < 24; i++) {
      const h = Math.abs(Math.sin(hash + i) * 16) + 6;
      soundwaveBars.current.push(h);
    }
  }

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);
    const handleTimeUpdate = () => setCurrentTime(audio.currentTime);
    const handleDurationChange = () => {
      if (audio.duration && !isNaN(audio.duration) && audio.duration !== Infinity) {
        setDuration(audio.duration);
      }
    };
    
    // WebM Duration Bug Workaround: Chrome/MediaRecorder generates webm with Infinity duration.
    // Setting currentTime to a huge number forces the browser to evaluate it.
    const handleLoadedMetadata = () => {
      if (audio.duration === Infinity || isNaN(audio.duration)) {
        audio.currentTime = 1e10;
        const fn = () => {
           audio.removeEventListener('timeupdate', fn);
           audio.currentTime = 0;
           if (audio.duration && audio.duration !== Infinity && !isNaN(audio.duration)) {
             setDuration(audio.duration);
           }
        };
        audio.addEventListener('timeupdate', fn);
      } else if (audio.duration && !isNaN(audio.duration)) {
        setDuration(audio.duration);
      }

      // Update Media Session Metadata for system-level controls
      if ('mediaSession' in navigator) {
        navigator.mediaSession.metadata = new MediaMetadata({
          title: 'Direct Voice Message',
          artist: 'Dirasha',
          album: 'Secured Workspace',
          artwork: [
            { src: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&h=150&q=80', sizes: '150x150', type: 'image/jpeg' }
          ]
        });
      }
    };

    const handleEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
    };

    audio.addEventListener('play', handlePlay);
    audio.addEventListener('pause', handlePause);
    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('durationchange', handleDurationChange);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('ended', handleEnded);

    // Initial check if loaded
    if (audio.readyState >= 1) handleLoadedMetadata();

    return () => {
      audio.removeEventListener('play', handlePlay);
      audio.removeEventListener('pause', handlePause);
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('durationchange', handleDurationChange);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('ended', handleEnded);
    };
  }, [url]);

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch(e => console.error("Playback error:", e));
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!audioRef.current) return;
    const seekValue = parseFloat(e.target.value);
    audioRef.current.currentTime = seekValue;
    setCurrentTime(seekValue);
  };

  const cycleSpeed = () => {
    if (!audioRef.current) return;
    let newRate = 1;
    if (playbackRate === 1) newRate = 1.5;
    else if (playbackRate === 1.5) newRate = 2;
    else newRate = 1;
    audioRef.current.playbackRate = newRate;
    setPlaybackRate(newRate);
  };

  const formatSec = (secs: number) => {
    if (isNaN(secs) || !isFinite(secs)) return '0:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const progressPercent = duration > 0 ? (currentTime / duration) : 0;
  const barsCount = soundwaveBars.current.length;
  const activeBarsLimit = Math.floor(progressPercent * barsCount);

  return (
    <div className="py-1.5 flex items-center gap-2.5 text-left w-full max-w-sm min-w-0 select-none" style={{ direction: 'ltr' }}>
      <audio ref={audioRef} src={url} className="hidden" preload="metadata" />

      {/* Play/Pause control circle */}
      <button
        type="button"
        onClick={togglePlay}
        className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 cursor-pointer transition-all active:scale-95 bg-blue-500 hover:bg-blue-600 text-white shadow-xs"
      >
        {isPlaying ? (
          <Pause className="w-3.5 h-3.5 fill-current text-white" />
        ) : (
          <Play className="w-3.5 h-3.5 fill-current translate-x-[-0.5px] text-white" />
        )}
      </button>

      {/* soundwave and track sliders */}
      <div className="flex-1 flex flex-col justify-center min-w-0">
        {/* Dynamic Wave layout with interactive seek bar */}
        <div className="flex items-end gap-[2.5px] h-6 w-full px-1 relative mb-1 justify-center">
          {soundwaveBars.current.map((height, i) => {
            const isActive = i <= activeBarsLimit;
            return (
              <div
                key={i}
                className="w-[3px] rounded-full transition-all duration-200"
                style={{
                  height: `${height}px`,
                  backgroundColor: isActive
                    ? (isMe ? '#60a5fa' : '#3b82f6')
                    : 'rgba(255, 255, 255, 0.2)'
                }}
              />
            );
          })}
          
          <input
            type="range"
            min={0}
            max={duration || 100}
            step={0.1}
            value={currentTime}
            onChange={handleSeek}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
          />
        </div>

        {/* Playback time indicator */}
        <div className="text-[9px] text-slate-400 font-mono px-0.5 text-left select-none leading-none">
          <span>{formatSec(currentTime)} / {formatSec(duration)}</span>
        </div>
      </div>

      {/* Bold speed controller bubble exactly styled next to the waves like WhatsApp */}
      <button
        type="button"
        onClick={cycleSpeed}
        className="shrink-0 px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/15 text-blue-400 font-black transition-all text-xs h-7 min-w-[38px] flex items-center justify-center cursor-pointer shadow-xs active:scale-95 text-center duration-150 border border-white/5"
        title="تغيير سرعة الصوت"
      >
        {playbackRate}x
      </button>
    </div>
  );
};

interface ChatWindowProps {
  accessToken: string;
  chatId: string;
  currentUser: any;
  allUsers: Record<string, any>; // Add allUsers to props for reactive name/avatar updates in messages
  messages: ClientMessage[];
  typingUsers: string[]; // List of displayNames currently typing in this room
  recordingUsers?: string[]; // List of displayNames currently recording a voice note
  isLoadingMessages?: boolean;
  onSendMessage: (content: string, attachments?: any[], replyTo?: { id: string; senderName: string; content?: string } | null, attachmentFiles?: any[]) => void;
  // P0-B (external-audit E2EE-03): encrypt any message-carrying text through
  // the chat's proper path (group Sender Keys / DM pairwise engine). Throws
  // when unavailable — callers fail closed.
  encryptContentForChat: (chatId: string, text: string) => Promise<string>;
  // True when this chat can encrypt (E2EE group, or DM with registered peer).
  chatSupportsE2ee: (chatId: string) => boolean;
  onEmitTyping: (isTyping: boolean) => void;
  onRecordingStatusChange?: (isRecording: boolean) => void;
  onMarkRead: (lastMessageId: string) => void;
  onLoadMoreMessages: (beforeTimestamp: string) => void;
  hasMore: boolean;
  selectedChatMeta: any;
  onBack?: () => void;
  presenceTick?: number;
  highlightMsgId?: string | null;
  onClearHighlight?: () => void;
  onViewProfile?: (userId: string) => void;
  onRetryMessage?: (messageId: string) => void;
  onStartVoiceCall?: () => void;
  onStartVideoCall?: () => void;
  onReportMessage?: (messageId: string, senderId: string, senderName: string, content: string) => void;
  onOpenStatus?: (statusId: string, userId: string) => void;
  /** E2EE (Agent I): resolves the 60-digit safety number for a safe-number modal for a DM peer. */
  onGetSafetyNumber?: (peerId: string) => Promise<string>;
  /** Opens the encrypted-conversation export panel (E2eeBackupPanel). */
  onExportChat?: () => void;
  /**
   * E2EE eligibility of the active chat, mirrored from App's engine/group
   * eligibility (1:1 DM with a resolvable e2eePeer, or a REGULAR group).
   * Drives encrypt-at-source media uploads (F1/P0): when true, composer
   * pre-uploads encrypt locally and upload ONLY the 'enc.bin' ciphertext;
   * when false, the legacy plaintext upload path is kept unchanged.
   */
  e2eeActive?: boolean;
  /**
   * F8 (audit): plaintext-downgrade memory for this DM's peer — true when the
   * engine has EVER fallen back to plaintext for this peer because they had
   * no E2EE bundle (and no successful encryption has cleared the memory yet).
   * Renders the "هذه المحادثة غير مشفرة طرف-لطرف" badge INSTEAD of the lock
   * (no silent downgrade: the send still succeeds as plaintext, but the user
   * is told).
   */
  e2eeDowngraded?: boolean;
}

export function ChatWindow({
  accessToken,
  chatId,
  currentUser,
  allUsers,
  messages,
  typingUsers,
  recordingUsers = [],
  isLoadingMessages = false,
  onSendMessage,
  encryptContentForChat,
  chatSupportsE2ee,
  onEmitTyping,
  onRecordingStatusChange,
  onMarkRead,
  onLoadMoreMessages,
  hasMore,
  selectedChatMeta,
  onBack,
  presenceTick,
  highlightMsgId,
  onClearHighlight,
  onViewProfile,
  onRetryMessage,
  onStartVoiceCall,
  onStartVideoCall,
  onReportMessage,
  onOpenStatus,
  onGetSafetyNumber,
  onExportChat,
  e2eeActive = false,
  e2eeDowngraded = false,
}: ChatWindowProps) {
  const [inputText, setInputText] = useState('');
  const isGlobalMuted = currentUser?.mutedUntil && new Date(currentUser.mutedUntil) > new Date();

  /** Time-format setting (12h/24h) applied to message timestamps. */
  const fmtChatTime = (iso: string) => {
    if (!iso) return '';
    const tf = String(currentUser?.chatSettings?.timeFormat || '12h');
    return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: tf !== '24h' });
  };
  const isMuted = isGlobalMuted;
  const [isReadingPrevious, setIsReadingPrevious] = useState(false);
  const [attachmentSim, setAttachmentSim] = useState<any[]>([]);
  const [showAttachmentMenu, setShowAttachmentMenu] = useState(false);
  const [showGroupSettings, setShowGroupSettings] = useState(false);
  const [protectedChat, setProtectedChat] = useState(false);

  // ── E2EE (Agent I) ──────────────────────────────────────────────────────────
  // Safety-number modal peer (DM header lock badge opens it). Eligible DMs are
  // 1:1 chats with a known other member.
  const [safetyModalPeer, setSafetyModalPeer] = useState<string | null>(null);
  const e2eePeerId = selectedChatMeta?.type === 'one-to-one' ? (selectedChatMeta?.otherMember?.id || null) : null;

  // ── E2EE verified state + rekey warning (Task C) ────────────────────────────
  // On chat open for eligible DMs the current safety number is fetched and
  // compared against the localStorage 'e2eeVerified:<myId>:<peerId>' reference
  // (set via the 'توثيق رقم الأمان' button in E2eeSafetyModal):
  //   - match       → the header lock badge turns solid emerald ('الطرف موثّق ✓').
  //   - mismatch    → the stale verified reference is cleared automatically
  //                   (by the App-side safety-fetch recorder) and the badge
  //                   returns to outline.
  // A 'e2eeRekey:<myId>:<peerId>' flag (set by the App receive path on
  // RekeyDetectedError or on a safety-number change) renders a persistent
  // amber banner above the messages until the user dismisses it.
  const myIdForE2ee = String(currentUser?.uid || currentUser?.id || '');
  const [currentSafetyNumber, setCurrentSafetyNumber] = useState<string | null>(null);
  const [peerVerified, setPeerVerified] = useState(false);
  const [rekeyFlagged, setRekeyFlagged] = useState(false);
  // F7 (audit): Key Transparency flag — the engine's fire-and-forget fleet
  // proof verification sets localStorage 'ktFlag:<peer>' when a VERIFIED-mode
  // proof contradicts the bundle keys it just served (witness signature /
  // commitment / inclusion failure). Read here per peer change; the header
  // shows the small 'تحذير شفافية المفاتيح' badge while it is set.
  const [ktFlagged, setKtFlagged] = useState(false);
  const readKtFlag = useCallback((peerId: string | null | undefined): boolean => {
    if (!peerId) return false;
    try { return localStorage.getItem(`ktFlag:${peerId}`) === '1'; } catch { return false; }
  }, []);

  // Fetch the peer's current safety number (App records 'e2eeLastSN' + rekey
  // detection on every successful fetch) and resolve the badge/banner flags.
  // The fetcher goes through a ref so the chat-open effect below only re-runs
  // when the PEER actually changes (App passes a fresh inline callback on
  // every render — depending on it would refetch per render).
  const onGetSafetyNumberRef = useRef(onGetSafetyNumber);
  onGetSafetyNumberRef.current = onGetSafetyNumber;
  const refreshE2eePeerState = useCallback(async () => {
    const fetchSafetyNumber = onGetSafetyNumberRef.current;
    if (!e2eePeerId || !myIdForE2ee || !fetchSafetyNumber) {
      setCurrentSafetyNumber(null);
      setPeerVerified(false);
      setRekeyFlagged(false);
      setKtFlagged(false);
      return;
    }
    let sn: string | null = null;
    try {
      sn = cleanSafetyNumber(await fetchSafetyNumber(e2eePeerId));
    } catch { sn = null; }
    setCurrentSafetyNumber(sn);
    try {
      const verified = myIdForE2ee && e2eePeerId
        ? localStorage.getItem(e2eeVerifiedKey(myIdForE2ee, e2eePeerId))
        : null;
      setPeerVerified(!!sn && !!verified && verified === sn);
      setRekeyFlagged(
        myIdForE2ee && e2eePeerId
          ? localStorage.getItem(e2eeRekeyFlagKey(myIdForE2ee, e2eePeerId)) === '1'
          : false
      );
    } catch {
      setPeerVerified(false);
      setRekeyFlagged(false);
    }
    // F7: KT flag is independent of the safety-number flow (it comes from the
    // engine's proof verification, not localStorage-scoped per account).
    setKtFlagged(readKtFlag(e2eePeerId));
  }, [e2eePeerId, myIdForE2ee, readKtFlag]);

  // Re-run on every chat open / peer change.
  useEffect(() => {
    setCurrentSafetyNumber(null);
    setPeerVerified(false);
    setRekeyFlagged(false);
    setKtFlagged(readKtFlag(e2eePeerId));
    refreshE2eePeerState();
  }, [refreshE2eePeerState, readKtFlag, e2eePeerId]);

  // 'تأكدت — إزالة التنبيه': clear the rekey flag and pin 'e2eeLastSN' to the
  // current number so the banner stays gone until the keys change again.
  const handleDismissRekey = useCallback(() => {
    if (!e2eePeerId || !myIdForE2ee) return;
    try {
      localStorage.removeItem(e2eeRekeyFlagKey(myIdForE2ee, e2eePeerId));
      if (currentSafetyNumber) {
        localStorage.setItem(e2eeLastSnKey(myIdForE2ee, e2eePeerId), currentSafetyNumber);
      }
    } catch { /* storage unavailable — state-only dismissal */ }
    setRekeyFlagged(false);
  }, [e2eePeerId, myIdForE2ee, currentSafetyNumber]);

  /**
   * Render guard: a message still carrying DIR1 (1:1) or DIRG1 (group
   * sender-key) ciphertext (not yet decrypted, or decryption failed — content
   * cleared + e2eeError) renders a small lock placeholder instead of the
   * formatted text. Never render raw ciphertext. Also guards reply previews.
   */
  const isE2eeLockedContent = (m: any): boolean => {
    return !!m && (
      (typeof m.content === 'string' && (m.content.startsWith('DIR1:') || m.content.startsWith('DIRM1:') || m.content.startsWith('DIRG1:'))) ||
      m.e2eeError === true
    );
  };

  // Protected content (Telegram parity): fetch the flag for group chats
  useEffect(() => {
    setProtectedChat(false);
    if (chatId && selectedChatMeta?.type === 'group') {
      (async () => {
        try {
          const res = await fetch(`/api/chats/${chatId}/group`, { headers: { Authorization: `Bearer ${accessToken}` } });
          if (res.ok) {
            const d = await res.json();
            setProtectedChat(Boolean(d.group?.permissions?.protectedContent));
          }
        } catch { /* default unprotected */ }
      })();
    }
  }, [chatId, selectedChatMeta?.type]);

  // ── Channels (Telegram parity): broadcast gating ──────────────────────────
  // Channels ride the exact same chat/message pipelines; only the composer and
  // header differ. Owner/admins post normally, subscribers see a broadcast
  // notice bar instead of the composer (mirrors the isMuted disable pattern).
  const isChannel = selectedChatMeta?.type === 'channel';
  const [channelInfo, setChannelInfo] = useState<{ subscriberCount: number; isAdmin: boolean } | null>(null);
  const isChannelAdmin = channelInfo?.isAdmin === true;
  const isChannelSubscriber = isChannel && !isChannelAdmin;

  // Fetch-on-open only (no channel member events exist yet): /group works for
  // channels too (same chats/chat_members tables) and returns members with
  // roles → subscriber count + my role in a single call.
  useEffect(() => {
    setChannelInfo(null);
    if (!chatId || selectedChatMeta?.type !== 'channel') return;
    (async () => {
      try {
        const res = await fetch(`/api/chats/${chatId}/group`, { headers: { Authorization: `Bearer ${accessToken}` } });
        if (!res.ok) return;
        const d = await res.json();
        const members: any[] = d.group?.members || [];
        const myId = currentUser?.uid || currentUser?.id;
        const role = members.find((m: any) => m.userId === myId)?.role;
        setChannelInfo({ subscriberCount: members.length, isAdmin: role === 'owner' || role === 'admin' });
      } catch { /* keep defaults — subscriber view is the safe fallback */ }
    })();
  }, [chatId, selectedChatMeta?.type, accessToken]);
  const [editingImageFile, setEditingImageFile] = useState<File | null>(null);
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  // P1-H: scoped media-token state (refreshed ahead of the 120s server TTL).
  const [mediaToken, setMediaToken] = useState<string>('');
  useEffect(() => {
    let live = true;
    let timer: any = null;
    const pull = async () => {
      const t = await getScopedMediaToken(accessToken);
      if (live && t) setMediaToken(t);
      if (live) timer = setTimeout(pull, 80_000);
    };
    void pull();
    return () => { live = false; if (timer) clearTimeout(timer); };
  }, [accessToken]);
  // View-once: arm-once toggle + revealed set (client honor system until server meta lands)
  const [viewOnceArmed, setViewOnceArmed] = useState(false);
  const [viewOnceRevealed, setViewOnceRevealed] = useState<Set<string>>(new Set());
  const isViewOnce = (att: any) => !!(att?.meta?.viewOnce || att?.viewOnce);
  const [fullScreenImage, setFullScreenImage] = useState<{ url: string; name: string } | null>(null);
  const [showInAppCamera, setShowInAppCamera] = useState(false);

  // ── In-chat message search (real DB search via GET /api/chats/:chatId/messages/search) ──
  const [showChatSearch, setShowChatSearch] = useState(false);
  const [chatSearchQuery, setChatSearchQuery] = useState('');
  const [chatSearchResults, setChatSearchResults] = useState<SearchResult[]>([]);
  const [isSearchingChat, setIsSearchingChat] = useState(false);
  const [searchHighlightId, setSearchHighlightId] = useState<string | null>(null);
  const [searchHighlightQuery, setSearchHighlightQuery] = useState('');
  const chatSearchDebounceRef = useRef<NodeJS.Timeout | null>(null);
  const decoratedRef = useRef<ClientMessage[]>([]);

  // ── Media gallery (GET /api/chats/:chatId/media) ──
  const [showMediaGallery, setShowMediaGallery] = useState(false);
  const [mediaTab, setMediaTab] = useState<'image' | 'file'>('image');
  const [mediaItems, setMediaItems] = useState<MediaItem[]>([]);
  const [isLoadingMedia, setIsLoadingMedia] = useState(false);
  
  // Modern Context Menu & Portaled states
  const [portalMenu, setPortalMenu] = useState<{
    message: ClientMessage;
    x: number;
    y: number;
    isMe: boolean;
    senderName: string;
  } | null>(null);

  // Message Info Modal
  const [infoMsgModal, setInfoMsgModal] = useState<ClientMessage | null>(null);
  const [infoMsgTelemetry, setInfoMsgTelemetry] = useState<any[]>([]);
  const [infoMsgReceipts, setInfoMsgReceipts] = useState<any[]>([]);
  const [isLoadingInfo, setIsLoadingInfo] = useState(false);
  const [starredMessageGlowId, setStarredMessageGlowId] = useState<string | null>(null);

  // Message Forward Modal
  const [forwardModalMsg, setForwardModalMsg] = useState<ClientMessage | null>(null);
  const [forwardChats, setForwardChats] = useState<any[]>([]);
  const [isLoadingForwardChats, setIsLoadingForwardChats] = useState(false);
  const [forwardSearch, setForwardSearch] = useState('');
  const [isForwarding, setIsForwarding] = useState(false);
  const [forwardSuccessId, setForwardSuccessId] = useState<string | null>(null);
  const [showExpandedEmojis, setShowExpandedEmojis] = useState(false);

  // Contact sharing picker (real contacts fetched on open from GET /api/contacts)
  const [showContactPicker, setShowContactPicker] = useState(false);
  const [contactsList, setContactsList] = useState<any[]>([]);
  const [isLoadingContacts, setIsLoadingContacts] = useState(false);

  // ── Polls (WhatsApp/Telegram parity) ──
  // Inline poll composer state + live vote overrides keyed by messageId.
  // Canonical poll state arrives via 'msg:poll:update' (server broadcast);
  // overrides hold optimistic votes and the latest canonical snapshot.
  const [showPollComposer, setShowPollComposer] = useState(false);
  const [pollQuestion, setPollQuestion] = useState('');
  const [pollOptions, setPollOptions] = useState<string[]>(['', '']);
  const [pollAllowMultiple, setPollAllowMultiple] = useState(false);
  const [pollOverrides, setPollOverrides] = useState<Record<string, PollData>>({});

  // ── Stickers (v1): recents-based, uploaded to the user's own Drive/storage ──
  // Recents persist client-side in localStorage (STICKERS_LS_KEY) — max 30,
  // newest first, deduped by url. Sending a sticker tags meta {sticker:true}
  // and auto-appends to the recents on send.
  // Encrypt-at-source (F1/P0): stickers uploaded while an E2EE chat is active
  // are stored as opaque 'enc.bin' ciphertext + their decryption payload. The
  // payload (per-sticker media key) persists alongside in the SAME localStorage
  // entry — the Drive-side third party only ever holds ciphertext, and a
  // machine-local attacker with the unlocked session is out of threat scope.
  const [showStickerPanel, setShowStickerPanel] = useState(false);
  const [stickerRecents, setStickerRecents] = useState<Array<{
    url: string; mimeType: string; name?: string; size?: number;
    e2ee?: boolean; attId?: string; payload?: AttachmentPayload;
  }>>([]);
  const stickerInputRef = useRef<HTMLInputElement>(null);

  // ── Multi-select messages (WhatsApp parity): checkbox per bubble + sticky
  // bottom action bar with bulk copy + bulk delete-for-me. Forward is
  // intentionally disabled in v1 (the forward modal is single-message).
  const [selectionMode, setSelectionMode] = useState(false);
  const [selectedMessageIds, setSelectedMessageIds] = useState<Set<string>>(new Set());
  const [isBulkDeleting, setIsBulkDeleting] = useState(false);

  // Formatting toolbar: ref to the composer textarea so marker buttons can
  // wrap the CURRENT selection (selectionStart/End).
  const composerTextareaRef = useRef<HTMLTextAreaElement | null>(null);

  // ── Message translation (Mission A): client-side via MyMemory, no server round-trip.
  // Component-level Map caches per-message translations so re-opening never refetches;
  // `translations` holds what is currently rendered inline, `translatingIds` guards
  // against duplicate in-flight fetches for the same message.
  const translationCacheRef = useRef<Map<string, string>>(new Map());
  const [translations, setTranslations] = useState<Record<string, string>>({});
  const [translatingIds, setTranslatingIds] = useState<Set<string>>(new Set());

  // ── Scheduled messages (Mission B): UI arms a schedule; the send intercepts
  // handleSend and posts via REST (WS msg:send ignores scheduleAt this round).
  const [scheduleArmed, setScheduleArmed] = useState(false);
  const [scheduleAt, setScheduleAt] = useState('');
  const [showScheduleBar, setShowScheduleBar] = useState(false);

  // Message interaction floating menus and reply quotes draft state
  const [activeActionId, setActiveActionId] = useState<string | null>(null);
  const [replyingToMessage, setReplyingToMessage] = useState<any | null>(null);
  const [editingMessage, setEditingMessage] = useState<any | null>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showToolsComingSoon, setShowToolsComingSoon] = useState(false);
  const [isRecordingPaused, setIsRecordingPaused] = useState(false);
  const [previewAudioUrl, setPreviewAudioUrl] = useState<string | null>(null);
  const [isPreviewPlaying, setIsPreviewPlaying] = useState(false);
  const previewAudioRef = useRef<HTMLAudioElement | null>(null);

  // Audio recording states and references using browser-native MediaRecorder for perfect pitch, speed, and CPU hygiene
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [voiceWaves, setVoiceWaves] = useState<number[]>([10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10]);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioStreamRef = useRef<MediaStream | null>(null);
  const recordingIntervalRef = useRef<any>(null);
  const speechWavesHistoryRef = useRef<number[]>([]);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const typingTimerRef = useRef<NodeJS.Timeout | null>(null);
  const isCurrentlyTypingLocalRef = useRef<boolean>(false);
  const attachmentFileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const docInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);

  // Swipe and long-press utilities
  const [activeDragMsgId, setActiveDragMsgId] = useState<string | null>(null);
  const [activeDragOffset, setActiveDragOffset] = useState<number>(0);
  const dragStartRef = useRef<number>(0);
  const isDraggingRef = useRef<boolean>(false);
  const longPressTimeoutRef = useRef<any>(null);

  const handleDragStart = (e: React.MouseEvent | React.TouchEvent, msgId: string) => {
    const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    dragStartRef.current = clientX;
    isDraggingRef.current = true;
    setActiveDragMsgId(msgId);
    setActiveDragOffset(0);
  };

  const handleDragMove = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDraggingRef.current || !activeDragMsgId) return;
    const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const diff = clientX - dragStartRef.current;
    
    // Smooth responsive cap limit (max absolute 100px shift)
    const capped = Math.min(100, Math.max(-100, diff));
    setActiveDragOffset(capped);
  };

  const handleDragEnd = (message: ClientMessage, msgSenderName: string) => {
    if (!isDraggingRef.current) return;
    isDraggingRef.current = false;
    
    // Fast swipe threshold (55px) triggers active reply draft
    if (Math.abs(activeDragOffset) >= 55) {
      setReplyingToMessage({
        id: message.id,
        senderName: msgSenderName,
        content: message.content
      });
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        navigator.vibrate(18);
      }
    }
    
    // Animate smoothly back
    setActiveDragOffset(0);
    setTimeout(() => {
      setActiveDragMsgId(null);
    }, 150);
  };

  // Local state modifiers for instant action rendering
  const [localReactions, setLocalReactions] = useState<Record<string, Record<string, string[]>>>({});
  const [localDeletedForMe, setLocalDeletedForMe] = useState<Record<string, boolean>>({});
  const [localDeletedForEveryone, setLocalDeletedForEveryone] = useState<Record<string, boolean>>({});
  const [localStarredList, setLocalStarredList] = useState<string[]>([]);

  useEffect(() => {
    if (!currentUser) return;
    const myId = currentUser.uid || currentUser.id;
    if (!myId) return;

    const updateStarred = () => {
      try {
        const stored = localStorage.getItem(`starred_messages_${myId}`);
        if (stored) {
          const parsed = JSON.parse(stored);
          setLocalStarredList(parsed.map((m: any) => m.id));
        } else {
          setLocalStarredList([]);
        }
      } catch (_) {}
    };

    updateStarred();
    window.addEventListener('starred-messages-updated', updateStarred);
    return () => window.removeEventListener('starred-messages-updated', updateStarred);
  }, [currentUser, chatId]);

  const decoratedMessages = React.useMemo(() => {
    const myId = currentUser?.uid || currentUser?.id;
    return messages.map((m) => {
      const customReactions = localReactions[m.id] || m.reactions || {};
      const isDeletedForEveryone = localDeletedForEveryone[m.id] || m.state === 'deleted';
      const isStarred = localStarredList.includes(m.id);
      
      return {
        ...m,
        reactions: customReactions,
        starred: isStarred,
        content: isDeletedForEveryone ? '🚫 تم حذف هذه الرسالة لدى الجميع' : m.content,
        attachments: isDeletedForEveryone ? [] : m.attachments,
        state: isDeletedForEveryone ? 'deleted' : (m.state || 'sent')
      };
    }).filter((m) => {
      return !localDeletedForMe[m.id] && (!m.deletedFor || !m.deletedFor.includes(myId));
    });
  }, [messages, localReactions, localDeletedForMe, localDeletedForEveryone, localStarredList, currentUser]);
  decoratedRef.current = decoratedMessages;

  // Smarter auto-scroll implementation
  const handleScroll = () => {
    if (scrollRef.current) {
      const container = scrollRef.current;
      const threshold = 100; // pixels from bottom to consider "at bottom"
      const isAtBottom = container.scrollHeight - container.scrollTop - container.clientHeight < threshold;
      setIsReadingPrevious(!isAtBottom);
    }
  };

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  };

  useEffect(() => {
    if (!isReadingPrevious) {
      scrollToBottom();
    }
  }, [decoratedMessages, typingUsers]);

  // Auto scroll smoothly to bottom when attachment menu is toggled
  useEffect(() => {
    if (scrollRef.current) {
      let startTime: number | null = null;
      const duration = 280; // Matches form container anim duration
      const scrollPosStart = scrollRef.current.scrollTop;
      let frameId: number;

      const animateScroll = (timestamp: number) => {
        if (!startTime) startTime = timestamp;
        const elapsed = timestamp - startTime;

        if (scrollRef.current) {
          const scrollPosEnd = scrollRef.current.scrollHeight - scrollRef.current.clientHeight;
          const t = Math.min(elapsed / duration, 1);
          // Cubic ease-out curve matching iOS spring feel
          const easeOutCubic = 1 - Math.pow(1 - t, 3);
          scrollRef.current.scrollTop = scrollPosStart + (scrollPosEnd - scrollPosStart) * easeOutCubic;
        }

        if (elapsed < duration) {
          frameId = requestAnimationFrame(animateScroll);
        }
      };

      const delayTimer = setTimeout(() => {
        frameId = requestAnimationFrame(animateScroll);
      }, 15); // Tiny offset to yield to initial frame render

      return () => {
        clearTimeout(delayTimer);
        cancelAnimationFrame(frameId);
      };
    }
  }, [showAttachmentMenu]);

  // Starred / search-result focus jump trigger (deep-link highlightMsgId + in-chat search share this path)
  const activeHighlightId = highlightMsgId || searchHighlightId;
  useEffect(() => {
    if (activeHighlightId && decoratedMessages.length > 0) {
      const t = setTimeout(() => {
        const element = document.getElementById(`msg-${activeHighlightId}`);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth', block: 'center' });
          element.classList.add('ring-4', 'ring-amber-500/80', 'border-amber-500', 'scale-[1.02]');
          const timer = setTimeout(() => {
            element.classList.remove('ring-4', 'ring-amber-500/80', 'border-amber-500', 'scale-[1.02]');
            if (onClearHighlight) onClearHighlight();
            setSearchHighlightId(null);
            setSearchHighlightQuery('');
          }, 3000);
        }
      }, 300);
      return () => clearTimeout(t);
    }
  }, [activeHighlightId, decoratedMessages]);

  // Reset transient search state when switching chats
  useEffect(() => {
    setShowChatSearch(false);
    setChatSearchQuery('');
    setChatSearchResults([]);
    setSearchHighlightId(null);
    setSearchHighlightQuery('');
    setShowMediaGallery(false);
    setMediaItems([]);
  }, [chatId]);

  // Debounced (400ms) real message search within this chat
  useEffect(() => {
    if (!showChatSearch) return;
    const q = chatSearchQuery.trim();
    if (chatSearchDebounceRef.current) clearTimeout(chatSearchDebounceRef.current);
    if (!q) {
      setChatSearchResults([]);
      setIsSearchingChat(false);
      return;
    }
    setIsSearchingChat(true);
    chatSearchDebounceRef.current = setTimeout(async () => {
      try {
        const res = await fetch(`/api/chats/${chatId}/messages/search?q=${encodeURIComponent(q)}&limit=30`, {
          headers: { Authorization: `Bearer ${accessToken}` }
        });
        const data = await res.json();
        setChatSearchResults(res.ok ? (data.messages || []) : []);
      } catch {
        setChatSearchResults([]);
      } finally {
        setIsSearchingChat(false);
      }
    }, 400);
    return () => {
      if (chatSearchDebounceRef.current) clearTimeout(chatSearchDebounceRef.current);
    };
  }, [chatSearchQuery, showChatSearch, chatId, accessToken]);

  // Media gallery feed (fetched per tab open/switch)
  useEffect(() => {
    if (!showMediaGallery) return;
    let cancelled = false;
    setIsLoadingMedia(true);
    fetch(`/api/chats/${chatId}/media?type=${mediaTab}&limit=200`, {
      headers: { Authorization: `Bearer ${accessToken}` }
    })
      .then(r => (r.ok ? r.json() : { media: [] }))
      .then(d => { if (!cancelled) setMediaItems(d.media || []); })
      .catch(() => { if (!cancelled) setMediaItems([]); })
      .finally(() => { if (!cancelled) setIsLoadingMedia(false); });
    return () => { cancelled = true; };
  }, [showMediaGallery, mediaTab, chatId, accessToken]);

  /**
   * Jump to a search hit: set the highlight (same ring/scroll path as the
   * deep-link highlightMsgId mechanism) and, when the message predates the
   * loaded window, page backwards through the EXISTING pagination callback
   * (onLoadMoreMessages) until it renders into the DOM.
   */
  const jumpToSearchResult = async (msgId: string, matchedQuery: string) => {
    setShowChatSearch(false);
    setSearchHighlightQuery(matchedQuery);
    setSearchHighlightId(msgId);
    for (let attempt = 0; attempt < 50; attempt++) {
      if (document.getElementById(`msg-${msgId}`)) break;
      const oldest = decoratedRef.current[0];
      if (!oldest || !hasMore) break;
      await onLoadMoreMessages(oldest.createdAt);
      // Yield a frame so the merged page can flush into decoratedMessages
      await new Promise(r => setTimeout(r, 150));
      // If pagination yielded nothing new (e.g. hasMore flipped), stop early
      const nowOldest = decoratedRef.current[0];
      if (nowOldest && nowOldest.createdAt === oldest.createdAt && !document.getElementById(`msg-${msgId}`)) break;
    }
  };

  /** First-occurrence case-insensitive <mark> highlight (plain JSX nodes only). */
  const renderMarkedContent = (text: string, query: string) => {
    const safeQuery = (query || '').trim();
    if (!safeQuery) return text;
    const idx = text.toLowerCase().indexOf(safeQuery.toLowerCase());
    if (idx === -1) return text;
    return [
      <span key="pre">{text.slice(0, idx)}</span>,
      <mark key="hit" className="bg-amber-400/80 text-black rounded px-0.5">{text.slice(idx, idx + safeQuery.length)}</mark>,
      <span key="post">{text.slice(idx + safeQuery.length)}</span>
    ];
  };

  /** Auth-gated media URLs served by this API need the access token appended. */
  const resolveMediaUrl = (url: string) => ((url || '').startsWith('/api') ? `${url}?access_token=${mediaToken}` : url);

  // Close popup menus on outer click
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (activeActionId && target && !target.closest('.msg-options-bubble') && !target.closest('.msg-options-trigger')) {
        setActiveActionId(null);
      }
      if (showEmojiPicker && target && !target.closest('.emoji-picker-container') && !target.closest('.emoji-trigger-btn')) {
        setShowEmojiPicker(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
    };
  }, [activeActionId, showEmojiPicker]);

  // Modern Portal Context Menu & Keyboard Listeners
  useEffect(() => {
    if (!portalMenu) return;
    const handleGlobalClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target && !target.closest('.portal-context-menu-wrapper')) {
        setPortalMenu(null);
      }
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setPortalMenu(null);
      }
    };
    document.addEventListener('mousedown', handleGlobalClick);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handleGlobalClick);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [portalMenu]);

  const handleToggleReaction = async (messageId: string, emoji: string) => {
    if (!currentUser) return;
    try {
      const res = await fetch(`/api/messages/${messageId}/react`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({ emoji })
      });
      if (!res.ok) throw new Error('Failed to toggle reaction');
    } catch (err) {
      console.error('[Reaction] Error:', err);
    }
    setActiveActionId(null);
  };

  const handleToggleStar = async (message: ClientMessage) => {
    if (!currentUser) return;
    try {
      const isCurrentlyStarred = message.starredBy && message.starredBy.includes(currentUser.uid || currentUser.id);
      if (!isCurrentlyStarred) {
        setStarredMessageGlowId(message.id);
        setTimeout(() => {
          setStarredMessageGlowId(null);
        }, 1500);
      }
      
      const res = await fetch(`/api/messages/${message.id}/star`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });
      if (!res.ok) throw new Error('Failed to toggle star');
      window.dispatchEvent(new Event('starred-messages-updated'));
    } catch (err) {
      console.warn('[Star] Failed mutating database:', err);
    }
    setActiveActionId(null);
  };

  const handleDeleteForMe = async (messageId: string) => {
    try {
      const res = await fetch(`/api/messages/${messageId}/delete-me`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });
      if (!res.ok) throw new Error('Failed delete for me');
      setLocalDeletedForMe((prev) => ({ ...prev, [messageId]: true }));
    } catch (err) {
      console.error('[Delete Me] Error:', err);
    }
    setActiveActionId(null);
  };

  const handleDeleteForEveryone = async (messageId: string) => {
    try {
      const res = await fetch(`/api/messages/${messageId}/delete-everyone`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });
      if (!res.ok) throw new Error('Failed delete for everyone');
    } catch (err) {
      console.error('[Delete Everyone] Error:', err);
    }
    setActiveActionId(null);
  };

  const handleTogglePin = async (messageId: string) => {
    try {
      const res = await fetch(`/api/messages/${messageId}/pin`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });
      if (!res.ok) throw new Error('Failed to toggle pin');
    } catch (err) {
      console.error('[Pin] Error:', err);
    }
    setActiveActionId(null);
  };

  // Handle marking read when opening chat or receiving fresh messages from partners
  useEffect(() => {
    if (messages.length > 0) {
      const lastMessage = messages[messages.length - 1];
      if (lastMessage && lastMessage.senderId !== currentUser.id && lastMessage.state !== 'read') {
        onMarkRead(lastMessage.id);
      }
    }
  }, [messages, chatId, currentUser.id]);

  // Clean up recording stream & MediaRecorder on chat change or unmounting
  useEffect(() => {
    return () => {
      if (recordingIntervalRef.current) {
        clearInterval(recordingIntervalRef.current);
        recordingIntervalRef.current = null;
      }
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
        animationFrameRef.current = null;
      }
      if (audioContextRef.current) {
        try {
          audioContextRef.current.close();
        } catch (e) {}
        audioContextRef.current = null;
      }
      analyserRef.current = null;
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        try {
          mediaRecorderRef.current.stop();
        } catch (e) {}
        mediaRecorderRef.current = null;
      }
      if (audioStreamRef.current) {
        audioStreamRef.current.getTracks().forEach(track => track.stop());
        audioStreamRef.current = null;
      }
      setIsRecording(false);
      setRecordingTime(0);
      audioChunksRef.current = [];
    };
  }, [chatId]);

  // Voice recording helpers using native hardware-optimized MediaRecorder
  const togglePreviewPlay = () => {
    if (!previewAudioUrl) return;
    if (!previewAudioRef.current) {
      previewAudioRef.current = new Audio(previewAudioUrl);
      previewAudioRef.current.addEventListener('ended', () => {
        setIsPreviewPlaying(false);
      });
      previewAudioRef.current.addEventListener('timeupdate', () => {
        // can track progress if needed
      });
    } else {
      if (previewAudioRef.current.src !== previewAudioUrl) {
        previewAudioRef.current.src = previewAudioUrl;
      }
    }

    if (isPreviewPlaying) {
      previewAudioRef.current.pause();
      setIsPreviewPlaying(false);
    } else {
      previewAudioRef.current.play().then(() => {
        setIsPreviewPlaying(true);
      }).catch(err => {
        console.error("Preview playback failed:", err);
      });
    }
  };

  const toggleRecordingPause = () => {
    const rec = mediaRecorderRef.current;
    if (!rec) return;
    if (rec.state === 'recording') {
      rec.pause();
      setIsRecordingPaused(true);

      // Request data chunks captured so far to assemble listening preview
      try {
        rec.requestData();
      } catch (e) {
        console.warn('requestData failed:', e);
      }

      // Generate preview URL from collected chunks with small timeout
      setTimeout(() => {
        if (audioChunksRef.current.length > 0) {
          const mimeType = rec.mimeType || 'audio/webm';
          const blob = new Blob(audioChunksRef.current, { type: mimeType });
          const url = URL.createObjectURL(blob);
          setPreviewAudioUrl(url);
        }
      }, 80);

    } else if (rec.state === 'paused') {
      // If preview is active, stop it
      if (previewAudioRef.current) {
        previewAudioRef.current.pause();
        setIsPreviewPlaying(false);
      }
      rec.resume();
      setIsRecordingPaused(false);

      if (previewAudioUrl) {
        URL.revokeObjectURL(previewAudioUrl);
        setPreviewAudioUrl(null);
      }
    }
  };

  const startRecording = async () => {
    try {
      // Clear previous historical speech waves
      speechWavesHistoryRef.current = [];
      setIsRecordingPaused(false);

      // 1. Request microphone access with high-fidelity capture parameters
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        }
      });
      audioStreamRef.current = stream;

      // Realtime Audio analyser integration for high fidelity reactive visualizer waves
      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioCtx) {
          const audioCtx = new AudioCtx();
          audioContextRef.current = audioCtx;
          const source = audioCtx.createMediaStreamSource(stream);
          const analyser = audioCtx.createAnalyser();
          analyser.fftSize = 64;
          source.connect(analyser);
          analyserRef.current = analyser;

          const dataArray = new Uint8Array(analyser.frequencyBinCount);
          let frameCount = 0;
          let lastUpdate = 0;

          const updateFrequencies = (timestamp: number = 0) => {
            if (!analyserRef.current) return;

            // If paused, keep visualizer frozen and request next frame
            if (mediaRecorderRef.current?.state === 'paused') {
              animationFrameRef.current = requestAnimationFrame(updateFrequencies);
              return;
            }

            // Throttled refresh to max 60 FPS (approx every 16ms) to bypass React's render overhead completely and prevent lag
            if (timestamp - lastUpdate >= 16) {
              lastUpdate = timestamp;
              analyser.getByteFrequencyData(dataArray);

              const points: number[] = [];
              const step = Math.ceil(dataArray.length / 20);
              let frameSum = 0;

              for (let i = 0; i < 20; i++) {
                const val = dataArray[i * step] || 0;
                frameSum += val;
                // Map 0-255 frequency to beautiful height between 4px and 28px
                const scaled = Math.max(4, Math.round((val / 255) * 24) + 4);
                points.push(scaled);
              }
              setVoiceWaves(points);

              // Sample average volume to capture message profile
              frameCount++;
              if (frameCount % 2 === 0) { // sampled every ~80ms 
                const avg = frameSum / 20;
                const sampledHeight = Math.max(4, Math.round((avg / 255) * 22) + 4);
                speechWavesHistoryRef.current.push(sampledHeight);
              }
            }

            animationFrameRef.current = requestAnimationFrame(updateFrequencies);
          };
          animationFrameRef.current = requestAnimationFrame(updateFrequencies);
        }
      } catch (e) {
        console.warn('Real-time AudioContext frequency tracking was withheld:', e);
      }

      // 2. Select optimal codec supported by platform and use high-fidelity bitrate (256 kbps)
      let options: any = { audioBitsPerSecond: 256000 };
      if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
        options = { mimeType: 'audio/webm;codecs=opus', audioBitsPerSecond: 256000 };
      } else if (MediaRecorder.isTypeSupported('audio/webm')) {
        options = { mimeType: 'audio/webm', audioBitsPerSecond: 256000 };
      } else if (MediaRecorder.isTypeSupported('audio/ogg')) {
        options = { mimeType: 'audio/ogg', audioBitsPerSecond: 256000 };
      } else if (MediaRecorder.isTypeSupported('audio/mp4')) {
        options = { mimeType: 'audio/mp4', audioBitsPerSecond: 256000 };
      }

      const mediaRecorder = new MediaRecorder(stream, options);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onerror = (e) => {
        console.error('[VoiceRecorder] MediaRecorder error:', e);
      };

      mediaRecorder.onstop = () => {
        if (audioChunksRef.current.length > 0) {
          processRecordedAudio();
        }
      };

      // Start recording with slices for maximum stability
      mediaRecorder.start(1000);

      setIsRecording(true);
      setRecordingTime(0);
      onRecordingStatusChange?.(true);

      // Start duration incrementer timer & simulated wave fallback
      let ticks = 0;
      recordingIntervalRef.current = setInterval(() => {
        if (mediaRecorderRef.current?.state === 'paused') return;
        setRecordingTime(prev => prev + 1);
        if (!analyserRef.current) {
          const fakePoints = Array.from({ length: 20 }, (_, idx) => {
            const val = Math.sin((ticks + idx) * 0.7) * Math.cos((ticks - idx) * 0.4);
            return Math.max(4, Math.round(Math.abs(val) * 22) + 6);
          });
          setVoiceWaves(fakePoints);
          ticks++;
        }
      }, 1000);

    } catch (err) {
      console.error('[VoiceRecorder] High fidelity capture initiation failed: ', err);
      alert('تعذر الوصول إلى الميكروفون. يرجى تفعيل إذن الوصول للميكروفون من إعدادات المتصفح.');
    }
  };
  const processRecordedAudio = () => {
    if (audioChunksRef.current.length > 0) {
      const rec = mediaRecorderRef.current;
      const mimeType = rec ? rec.mimeType : 'audio/webm';
      const audioBlob = new Blob(audioChunksRef.current, { type: mimeType });

      // Build historical waves
      let capturedWaves = [10, 14, 18, 12, 10, 22, 24, 16, 12, 10, 14, 18, 12, 16, 20, 14, 10, 8, 12, 16, 14, 10, 8, 12];
      const history = speechWavesHistoryRef.current;
      if (history.length > 0) {
        const targetLength = 24;
        capturedWaves = [];
        for (let i = 0; i < targetLength; i++) {
          const index = Math.floor((i / targetLength) * history.length);
          capturedWaves.push(history[index]);
        }
      }

      let fileExtension = 'webm';
      if (mimeType.includes('mp4')) fileExtension = 'mp4';
      else if (mimeType.includes('ogg')) fileExtension = 'ogg';

      // Voice notes upload to external object storage now — no base64 in the database
      (async () => {
        try {
          const fileName = `voice_${Date.now()}.${fileExtension}`;
          const displayName = `رسالة_صوتية_${new Date().toLocaleTimeString().replace(/:/g, '-')}.${fileExtension}`;
          // Encrypt-at-source (F1/P0): in E2EE chats the recording blob NEVER
          // touches the network in plaintext — encrypt locally, upload ONLY
          // the opaque 'enc.bin' ciphertext. The recorder blob stays in-memory
          // until encrypted; the decryption payload rides to App in-memory on
          // meta.e2eePayload (stripped before the wire, embedded in the
          // encrypted envelope). Renders via E2eeMedia on both sides.
          if (e2eeActive) {
            const bytes = new Uint8Array(await audioBlob.arrayBuffer());
            const encAtt = await encryptAndUploadAttachment(bytes, mimeType, displayName);
            onSendMessage('🎙️ رسالة صوتية', [encAtt], null, []);
            return;
          }
          const uploaded = await uploadMediaFile(audioBlob, fileName);
          const voiceAttachment = {
            name: displayName,
            size: uploaded.size,
            mimeType: uploaded.mimeType,
            url: uploaded.url,
            waves: capturedWaves
          };
          // Pass the raw audio blob (index-aligned) so the
          // E2EE send wrap can encrypt the bytes before upload.
          onSendMessage('🎙️ رسالة صوتية', [voiceAttachment], null, [audioBlob]);
        } catch (err: any) {
          console.error('[VoiceNote] Cloud upload failed:', err);
          if (err instanceof StorageNotLinkedError) {
            startGdriveLink();
            return;
          }
          if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
            (window as any).showGlobalToast(err?.message || 'فشل رفع الرسالة الصوتية', 'error');
          }
        }
      })();
    }
    audioChunksRef.current = [];
  };

  const stopRecording = (shouldSave: boolean) => {
    if (recordingIntervalRef.current) {
      clearInterval(recordingIntervalRef.current);
      recordingIntervalRef.current = null;
    }
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    if (audioContextRef.current) {
      try { audioContextRef.current.close(); } catch (e) {}
      audioContextRef.current = null;
    }
    analyserRef.current = null;

    const rec = mediaRecorderRef.current;
    if (rec && rec.state !== 'inactive') {
      try {
        if (!shouldSave) {
          audioChunksRef.current = [];
        }
        rec.stop();
      } catch (e) {
        console.error('[VoiceRecorder] Stop Error:', e);
      }
    }

    if (audioStreamRef.current) {
      audioStreamRef.current.getTracks().forEach(track => track.stop());
      audioStreamRef.current = null;
    }
    
    // Clean up draft preview
    if (previewAudioUrl) {
      try { URL.revokeObjectURL(previewAudioUrl); } catch (e) {}
      setPreviewAudioUrl(null);
    }
    if (previewAudioRef.current) {
      try { previewAudioRef.current.pause(); } catch (e) {}
      previewAudioRef.current = null;
    }
    setIsPreviewPlaying(false);

    setIsRecording(false);
    setRecordingTime(0);
    setIsRecordingPaused(false);
    onRecordingStatusChange?.(false);
    mediaRecorderRef.current = null;
  };

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rem = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${rem.toString().padStart(2, '0')}`;
  };

  // Typing status change handles debounce and throttle
  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>) => {
    setInputText(e.target.value);
    
    // Notify starting to type
    if (!isCurrentlyTypingLocalRef.current) {
      isCurrentlyTypingLocalRef.current = true;
      onEmitTyping(true);
    }

    // Debounce stoppage notification
    if (typingTimerRef.current) clearTimeout(typingTimerRef.current);
    
    typingTimerRef.current = setTimeout(() => {
      isCurrentlyTypingLocalRef.current = false;
      onEmitTyping(false);
    }, 2500); // 2.5 seconds threshold
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isMuted) {
      if ((window as any).showGlobalToast) {
        (window as any).showGlobalToast('تم كتم حسابك من إرسال الرسائل حالياً.', 'error');
      }
      return;
    }
    // Channel broadcast gate (client mirror of the server sendGate rule)
    if (isChannelSubscriber) {
      if ((window as any).showGlobalToast) {
        (window as any).showGlobalToast('القناة للبث فقط — المشرفون فقط ينشرون.', 'error');
      }
      return;
    }
    const trimmed = inputText.trim();
    if (!trimmed && attachmentSim.length === 0) return;

    // P0-B (external-audit E2EE-03): edited content must ride an envelope —
    // encrypt through the chat path or ABORT (never send a plaintext edit).
    let wireForEdit = trimmed;
    if (chatSupportsE2ee(chatId)) {
      try { wireForEdit = await encryptContentForChat(chatId, trimmed); }
      catch { toastError('تعذر تشفير التعديل — لن تُرسل نصًا صريحًا.'); return; }
    }
    if (editingMessage) {
      try {
        const res = await fetch(`/api/messages/${editingMessage.id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          body: JSON.stringify({ content: wireForEdit })
        });
        if (!res.ok) throw new Error('Failed to edit message');
      } catch (err) {
        console.error('[Edit Message] Error:', err);
      }
      setEditingMessage(null);
      setInputText('');
      return;
    }

    // ── Scheduled send (Mission B): WS msg:send ignores scheduleAt, so scheduled
    // messages go through REST POST /api/chats/:chatId/messages directly and
    // bypass onSendMessage (which is WS-only optimistic flow).
    // P0-B: scheduled content is stored ENCRYPTED — server never sees text.
    let wireForSchedule = trimmed;
    if (chatSupportsE2ee(chatId)) {
      try { wireForSchedule = await encryptContentForChat(chatId, trimmed); }
      catch { toastError('تعذر تشفير الجدولة — لن تُرسل نصًا صريحًا.'); return; }
    }
    if (scheduleArmed && scheduleAt) {
      const when = new Date(scheduleAt);
      if (isNaN(when.getTime()) || when.getTime() < Date.now() + SCHEDULE_MIN_MS) {
        toastError('وقت الجدولة غير صالح — اختر وقتاً بعد دقيقتين على الأقل.');
        return;
      }
      if (attachmentSim.length > 0) {
        toastError('الجدولة تدعم النص فقط حالياً.');
        return;
      }
      try {
        const res = await fetch(`/api/chats/${chatId}/messages`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          // BATCH-3 (DIR-CB-04): schedule declares the membership epoch it was
          // composed under (from the chats list) — otherwise the server's
          // MEMBERSHIP_STALE gate 409s every group schedule.
          body: JSON.stringify({
            content: wireForSchedule,
            scheduleAt: when.toISOString(),
            mv: (selectedChatMeta as any)?.membershipVersion,
          })
        });
        if (!res.ok) throw new Error('scheduled send failed');
        toastSuccess(`📅 حُدولت الرسالة لـ ${formatScheduleLabel(scheduleAt)}`);
        setInputText('');
        setAttachmentSim([]);
        setShowAttachmentMenu(false);
        setReplyingToMessage(null);
        setScheduleArmed(false);
        setScheduleAt('');
        setShowScheduleBar(false);
      } catch {
        toastError('تعذر جدولة الرسالة — تحقق من الاتصال.');
      }
      return;
    }

    const replyTo = replyingToMessage
      ? { 
          id: replyingToMessage.id, 
          senderName: replyingToMessage.senderName || 'مستعمل'
        } 
      : null;

    // Send payload
    onSendMessage(trimmed, attachmentSim, replyTo);
    setInputText('');
    setAttachmentSim([]);
    setShowAttachmentMenu(false);
    setReplyingToMessage(null); // Clear active quoted message draft

    // Instantly notify stopped typing
    if (isCurrentlyTypingLocalRef.current) {
      isCurrentlyTypingLocalRef.current = false;
      onEmitTyping(false);
    }
    if (typingTimerRef.current) clearTimeout(typingTimerRef.current);
  };

  const toastError = (msg: string) => {
    if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
      (window as any).showGlobalToast(msg, 'error');
    }
  };

  const toastSuccess = (msg: string) => {
    if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
      (window as any).showGlobalToast(msg, 'success');
    }
  };

  // Google Drive consent flow: full-page redirect. After consent the OAuth
  // callback lands the user back in the app (?storage=linked) mid-chat and
  // they simply retry the send.
  const startGdriveLink = async () => {
    try {
      await startGdriveConsent(accessToken);
    } catch (e: any) {
      if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
        (window as any).showGlobalToast(e?.message || 'تعذر بدء ربط Google Drive.', 'error');
      }
    }
  };

  // Google Drive linking returns to the app with ?storage=linked|error.
  // Greet the user with a toast, then clean the URL so refreshes don't re-toast.
  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const storageFlag = params.get('storage');
      if (!storageFlag) return;
      if (storageFlag === 'linked') {
        toastSuccess('✅ تم ربط Google Drive — أعد إرسال الوسائط');
      } else if (storageFlag === 'error') {
        toastError('تعذر ربط Google Drive — حاول مرة أخرى من الإعدادات.');
      }
      params.delete('storage');
      const rest = params.toString();
      const cleanUrl = window.location.pathname + (rest ? `?${rest}` : '') + window.location.hash;
      window.history.replaceState({}, '', cleanUrl);
    } catch { /* never block the chat on URL hygiene */ }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /**
   * Client-side translation (Mission A): MyMemory free API, no key, CORS-enabled.
   * Fetches with a 6s AbortController timeout, caches per message id, and never
   * blocks the UI — failures surface as a toast only.
   */
  const handleTranslateMessage = async (message: ClientMessage) => {
    const id = message.id;
    const cached = translationCacheRef.current.get(id);
    if (cached) {
      setTranslations(prev => ({ ...prev, [id]: cached }));
      return;
    }
    if (translatingIds.has(id)) return;
    setTranslatingIds(prev => new Set(prev).add(id));
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), TRANSLATE_TIMEOUT_MS);
    try {
      const q = String(message.content || '').trim().slice(0, TRANSLATE_MAX_QUERY_CHARS);
      const res = await fetch(
        `${TRANSLATE_ENDPOINT}?q=${encodeURIComponent(q)}&langpair=${detectLangPair(q)}`,
        { signal: controller.signal }
      );
      if (!res.ok) throw new Error('translation request failed');
      const data = await res.json();
      const translated = String(data?.responseData?.translatedText || '').trim();
      // MyMemory returns quota/warning text inside translatedText — treat as failure.
      if (!translated || /MYMEMORY WARNING|QUERY LENGTH LIMIT/i.test(translated)) {
        throw new Error('empty or invalid translation');
      }
      translationCacheRef.current.set(id, translated);
      setTranslations(prev => ({ ...prev, [id]: translated }));
    } catch {
      toastError('تعذر الترجمة — تحقق من الاتصال.');
    } finally {
      clearTimeout(timeout);
      setTranslatingIds(prev => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
    }
  };

  // ── Schedule bar (Mission B) confirm/cancel ──
  const handleConfirmSchedule = () => {
    const when = new Date(scheduleAt);
    if (!scheduleAt || isNaN(when.getTime()) || when.getTime() < Date.now() + SCHEDULE_MIN_MS) {
      toastError('اختر وقتاً بعد دقيقتين على الأقل من الآن.');
      return;
    }
    setScheduleArmed(true);
    setShowScheduleBar(false);
  };

  const handleCancelSchedule = () => {
    setScheduleArmed(false);
    setScheduleAt('');
    setShowScheduleBar(false);
  };

  // Client-side attachment cap (documents/audio) — the server enforces its own
  // per-category caps via the presign endpoint; this keeps big picks from even
  // starting an upload that is doomed to be rejected.
  const MAX_ATTACHMENT_BYTES = 25 * 1024 * 1024; // 25MB

  /**
   * REAL document/audio attachment: presigned PUT to object storage (same flow
   * as photos) then send an attachment { url, mimeType, size, name }.
   */
  const handleRealFileAttachment = async (file: File) => {
    setShowAttachmentMenu(false);
    if (file.size > MAX_ATTACHMENT_BYTES) {
      toastError(`الملف كبير جداً (${formatFileSize(file.size)}) — الحد الأقصى 25MB.`);
      return;
    }
    try {
      setIsUploadingImage(true);
      // Encrypt-at-source (F1/P0): in E2EE chats the original document bytes
      // NEVER hit the network in plaintext (real filename would persist in
      // Drive metadata) — encrypt locally, upload ONLY the 'enc.bin'
      // ciphertext, payload rides in-memory to App's send wrap.
      if (e2eeActive) {
        const bytes = new Uint8Array(await file.arrayBuffer());
        const encAtt = await encryptAndUploadAttachment(
          bytes,
          file.type || 'application/octet-stream',
          file.name || 'file',
          viewOnceArmed ? { viewOnce: true } : undefined
        );
        onSendMessage('', [encAtt], null, []);
        if (viewOnceArmed) setViewOnceArmed(false);
        return;
      }
      // Direct upload to the user's storage (Google Drive or presigned object storage) — never through our DB
      const uploaded = await uploadMediaFile(file, file.name);
      const attachment = {
        name: uploaded.name,
        size: uploaded.size,
        mimeType: uploaded.mimeType,
        url: uploaded.url,
        ...(viewOnceArmed ? { meta: { viewOnce: true } } : {})
      };
      // Raw file passed (index-aligned) for the E2EE send wrap.
      onSendMessage('', [attachment], null, [file]);
  if (viewOnceArmed) setViewOnceArmed(false);
    } catch (err: any) {
      console.error('[DocAudioUpload]', err);
      if (err instanceof StorageNotLinkedError) {
        startGdriveLink();
        return;
      }
      toastError(err?.message || 'فشل رفع الملف');
    } finally {
      setIsUploadingImage(false);
    }
  };

  /**
   * REAL location sharing: device GPS → OpenStreetMap link attachment.
   * The URL is rendered as a map card (never an <img>) so nothing is fetched
   * from a third-party host by recipients' browsers.
   */
  const handleShareLocation = () => {
    setShowAttachmentMenu(false);
    if (!navigator.geolocation) {
      toastError('تعذر تحديد موقعك — تحقق من إذن الموقع.');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        const url = `https://www.openstreetmap.org/?mlat=${lat}&mlon=${lng}#map=16/${lat}/${lng}`;
        onSendMessage('', [{
          url,
          mimeType: 'application/x-dirasha-location',
          lat,
          lng,
          name: 'موقعي',
          meta: { lat, lng },
        }]);
      },
      () => toastError('تعذر تحديد موقعك — تحقق من إذن الموقع.'),
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  // Fetch real contacts every time the picker opens
  useEffect(() => {
    if (!showContactPicker) return;
    setIsLoadingContacts(true);
    fetch('/api/contacts', { headers: { 'Authorization': `Bearer ${accessToken}` } })
      .then(res => res.json())
      .then(data => setContactsList(Array.isArray(data?.contacts) ? data.contacts : []))
      .catch(() => setContactsList([]))
      .finally(() => setIsLoadingContacts(false));
  }, [showContactPicker, accessToken]);

  /** Share a picked contact as a structured attachment + descriptive text. */
  const handleSendContact = (contact: any) => {
    const displayName = contact?.displayName || contact?.username || 'مستخدم';
    onSendMessage(`📲 شارك جهة اتصال: ${displayName}`, [{
      // No url field: attachment URLs are allowlisted server-side (same-origin /
      // bucket hosts only) — structured contact payloads carry NO url and pass.
      mimeType: 'application/x-dirasha-contact',
      name: displayName,
      contactUserId: contact?.id,
      username: contact?.username || '',
      meta: { contactUserId: contact?.id, username: contact?.username || '' },
    }]);
    setShowContactPicker(false);
  };

  // ── Polls: live updates + voting (WhatsApp parity) ──
  // Subscribe to the server's canonical 'msg:poll:update' broadcasts via the
  // window-anchored SocketManager singleton (same client App uses — no extra
  // socket). Overrides reset when switching chats.
  useEffect(() => {
    setPollOverrides({});
    // Translation cards are per-message UI state — clear on chat switch.
    // The cache Map persists (keyed by message id, ids are unique per chat).
    setTranslations({});
    // Multi-select + sticker panel are transient per-chat states — reset on switch.
    exitSelectionMode();
    setShowStickerPanel(false);
  }, [chatId]);

  useEffect(() => {
    const client = SocketManager.getInstance();
    const unsub = client.on('msg:poll:update', (p: any) => {
      if (!p?.messageId || !p?.poll) return;
      setPollOverrides(prev => ({ ...prev, [p.messageId]: p.poll }));
    });
    return unsub;
  }, []);

  /** Optimistic vote + emit over WS (REST fallback while disconnected). */
  const handlePollVote = (message: ClientMessage, poll: PollData, optionIndex: number) => {
    if (message.state === 'deleted') return;
    const myId = currentUser.uid || currentUser.id;
    const current: number[] = Array.isArray(poll.votes?.[myId]) ? poll.votes[myId] : [];
    let next: number[];
    if (poll.allowMultiple) {
      next = current.includes(optionIndex)
        ? current.filter(i => i !== optionIndex)
        : [...current, optionIndex];
    } else {
      next = current.length === 1 && current[0] === optionIndex ? [] : [optionIndex];
    }
    const votes: Record<string, number[]> = { ...(poll.votes || {}) };
    if (next.length === 0) delete votes[myId];
    else votes[myId] = next;
    setPollOverrides(prev => ({
      ...prev,
      [message.id]: { ...poll, votes }
    }));

    const payload = { chatId, messageId: message.id, optionIndexes: next };
    const client = SocketManager.getInstance();
    if (client.isConnected()) {
      client.emit('msg:poll:vote', payload);
    } else {
      fetch(`/api/messages/${message.id}/poll-vote`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({ optionIndexes: next })
      }).catch(() => { /* override stays until next canonical update */ });
    }
  };

  /** Submit the inline poll composer through the existing sendMessage path. */
  const submitPoll = () => {
    const question = pollQuestion.trim();
    const options = pollOptions.map(o => o.trim()).filter(Boolean);
    if (!question || options.length < 2) {
      toastError('التصويت يحتاج سؤالاً وخيارين على الأقل.');
      return;
    }
    if (question.length > 200 || options.some(o => o.length > 100)) {
      toastError('السؤال بحد 200 حرفاً وكل خيار بحد 100 حرف.');
      return;
    }
    // The poll rides as a structured attachment (application/x-dirasha-poll —
    // contact/location-card pattern) so it survives the App send path intact;
    // the server extracts, validates and persists it into messages.poll.
    onSendMessage(question, [{
      mimeType: 'application/x-dirasha-poll',
      name: 'تصويت',
      poll: { question, options, allowMultiple: pollAllowMultiple, votes: {} }
    }]);
    setShowPollComposer(false);
    setPollQuestion('');
    setPollOptions(['', '']);
    setPollAllowMultiple(false);
  };

  // ── Stickers (v1) ──
  /** Load the persisted recents list from localStorage (corrupt lists start fresh). */
  const loadStickerRecents = () => {
    try {
      const raw = localStorage.getItem(STICKERS_LS_KEY);
      const arr = raw ? JSON.parse(raw) : [];
      if (Array.isArray(arr)) {
        setStickerRecents(arr.filter((s: any) => s && typeof s.url === 'string'));
      }
    } catch { /* corrupted list — start fresh */ }
  };

  useEffect(() => {
    loadStickerRecents();
  }, []);

  /** Prepend a sticker to the recents (dedupe by url, max 30, newest first) and persist. */
  const addStickerToRecents = (item: { url: string; mimeType?: string; name?: string; size?: number; e2ee?: boolean; attId?: string; payload?: AttachmentPayload }) => {
    if (!item?.url) return;
    setStickerRecents(prev => {
      const next = [
        {
          url: item.url,
          mimeType: item.mimeType || 'image/webp',
          name: item.name || 'ملصق',
          size: item.size,
          ...(item.e2ee ? { e2ee: true, attId: item.attId, payload: item.payload } : {}),
        },
        ...prev.filter((s) => s?.url !== item.url),
      ].slice(0, MAX_STICKER_RECENTS);
      try {
        localStorage.setItem(STICKERS_LS_KEY, JSON.stringify(next));
      } catch { /* storage full — recents stay in-memory for the session */ }
      return next;
    });
  };

  /** Upload a picked image (≤1MB) into the user's own storage. */
  const handleStickerUpload = async (file: File) => {
    if (!file.type.startsWith('image/')) {
      toastError('الملصقات يجب أن تكون صوراً فقط.');
      return;
    }
    if (file.size > MAX_STICKER_BYTES) {
      toastError(`الملصق كبير جداً (${formatFileSize(file.size)}) — الحد الأقصى 1MB.`);
      return;
    }
    try {
      setIsUploadingImage(true);
      // Encrypt-at-source (F1/P0): with an E2EE chat active the sticker image
      // NEVER uploads in plaintext — only the opaque 'enc.bin' ciphertext goes
      // to Drive; the decryption payload persists client-side with the recents
      // so the panel can decrypt thumbnails and sends can skip re-encryption.
      if (e2eeActive) {
        const bytes = new Uint8Array(await file.arrayBuffer());
        const encAtt = await encryptAndUploadAttachment(bytes, file.type || 'image/png', file.name || 'sticker.png');
        addStickerToRecents({
          url: encAtt.url,
          mimeType: encAtt.mimeType,
          name: encAtt.name,
          size: encAtt.size,
          e2ee: true,
          attId: encAtt.id,
          payload: encAtt.meta.e2eePayload,
        });
        toastSuccess('تمت إضافة الملصق إلى مجموعتك');
        return;
      }
      const uploaded = await uploadMediaFile(file, file.name);
      addStickerToRecents(uploaded);
      toastSuccess('تمت إضافة الملصق إلى مجموعتك');
    } catch (err: any) {
      console.error('[StickerUpload]', err);
      if (err instanceof StorageNotLinkedError) {
        startGdriveLink();
        return;
      }
      toastError(err?.message || 'فشل رفع الملصق');
    } finally {
      setIsUploadingImage(false);
    }
  };

  /** Send a sticker: empty text + attachment tagged meta {sticker:true}; auto-appends to recents. */
  const handleSendSticker = async (sticker: { url: string; mimeType?: string; name?: string; size?: number; e2ee?: boolean; attId?: string; payload?: AttachmentPayload }) => {
    // Encrypt-at-source (F1/P0): an encrypted library sticker sent into an
    // E2EE chat passes its ciphertext + payload straight through — NO plaintext
    // upload, NO re-encryption (App's skip-guard takes meta.e2eePayload).
    if (sticker.e2ee && sticker.payload && e2eeActive) {
      const encAttachment = {
        id: sticker.attId || sticker.payload.attId,
        url: sticker.url,
        mimeType: 'application/octet-stream',
        name: 'enc.bin',
        size: sticker.size || 0,
        meta: {
          sticker: true,
          e2ee: true,
          attId: sticker.attId || sticker.payload.attId,
          e2eePayload: sticker.payload,
        },
      };
      onSendMessage('', [encAttachment], null, []);
      setShowStickerPanel(false);
      return;
    }
    // Encrypted library sticker sent into a LEGACY (plaintext) chat: those
    // chats are plaintext by design, so decrypt locally and upload plaintext
    // exactly like every other legacy attachment (never send ciphertext the
    // peer has no payload for).
    if (sticker.e2ee && sticker.payload && !e2eeActive) {
      try {
        setIsUploadingImage(true);
        const full = sticker.url.startsWith('/api') && accessToken
          ? `${sticker.url}${sticker.url.includes('?') ? '&' : '?'}access_token=${await getScopedMediaToken(accessToken)}`
          : sticker.url;
        const res = await fetch(full);
        if (!res.ok) throw new Error(`fetch failed (${res.status})`);
        const dec = decryptAttachment(sticker.payload, new Uint8Array(await res.arrayBuffer()));
        const plainBlob = new Blob([dec.bytes as BlobPart], { type: dec.mime || sticker.payload.mime || 'image/webp' });
        const uploaded = await uploadMediaFile(plainBlob, dec.name || sticker.payload.name || 'sticker.png');
        const attachment = {
          url: uploaded.url,
          mimeType: uploaded.mimeType,
          size: uploaded.size,
          name: uploaded.name,
          meta: { sticker: true },
        };
        onSendMessage('', [attachment], null, []);
        addStickerToRecents(attachment);
      } catch (err: any) {
        console.error('[StickerSend][legacy fallback]', err);
        toastError(err?.message || 'فشل إرسال الملصق');
      } finally {
        setIsUploadingImage(false);
      }
      setShowStickerPanel(false);
      return;
    }
    const attachment = {
      url: sticker.url,
      mimeType: sticker.mimeType || 'image/webp',
      size: sticker.size || 0,
      name: sticker.name || 'ملصق',
      meta: { sticker: true },
    };
    onSendMessage('', [attachment]);
    addStickerToRecents(attachment);
    setShowStickerPanel(false);
  };

  // ── Formatting toolbar (WhatsApp parity) ──
  /** Wrap the CURRENT textarea selection with a marker (or insert an empty pair and place the caret inside). */
  const insertFormatting = (marker: string) => {
    const ta = composerTextareaRef.current;
    const start = ta?.selectionStart ?? inputText.length;
    const end = ta?.selectionEnd ?? inputText.length;
    const selected = inputText.slice(start, end);
    const next = `${inputText.slice(0, start)}${marker}${selected}${marker}${inputText.slice(end)}`;
    setInputText(next);
    // No selection → caret inside the empty pair; selection → caret after the pair.
    const caret = start + marker.length + selected.length;
    requestAnimationFrame(() => {
      if (!ta) return;
      ta.focus();
      try { ta.setSelectionRange(caret, caret); } catch { /* controlled textarea edge */ }
    });
  };

  // ── Multi-select messages ──
  const toggleMessageSelection = (messageId: string) => {
    setSelectedMessageIds(prev => {
      const next = new Set(prev);
      if (next.has(messageId)) next.delete(messageId);
      else next.add(messageId);
      return next;
    });
  };

  const enterSelectionMode = (messageId: string) => {
    setSelectionMode(true);
    setSelectedMessageIds(new Set([messageId]));
  };

  const exitSelectionMode = () => {
    setSelectionMode(false);
    setSelectedMessageIds(new Set());
  };

  /** Bulk copy: concatenated texts of the selected messages in chronological order. */
  const handleBulkCopy = () => {
    const texts = decoratedMessages
      .filter((m) => selectedMessageIds.has(m.id))
      .map((m) => String(m.content || '').trim())
      .filter(Boolean);
    if (texts.length === 0) {
      toastError('الرسائل المحددة لا تحتوي نصاً لنسخه.');
      return;
    }
    navigator.clipboard.writeText(texts.join('\n'))
      .then(() => {
        toastSuccess(`تم نسخ ${texts.length} رسالة`);
        exitSelectionMode();
      })
      .catch(() => toastError('تعذر النسخ — تحقق من إذن الحافظة.'));
  };

  /** Bulk delete-for-me: the EXISTING per-message /delete-me endpoint, looped sequentially. */
  const handleBulkDeleteForMe = async () => {
    if (isBulkDeleting || selectedMessageIds.size === 0) return;
    if (!window.confirm(`حذف ${selectedMessageIds.size} رسالة لديك فقط؟ (لن تُحذف لدى الطرف الآخر)`)) return;
    setIsBulkDeleting(true);
    const ids = Array.from(selectedMessageIds);
    let ok = 0;
    for (const id of ids) {
      try {
        const res = await fetch(`/api/messages/${id}/delete-me`, {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${accessToken}` }
        });
        if (res.ok) {
          ok++;
          setLocalDeletedForMe(prev => ({ ...prev, [id]: true }));
        }
      } catch (err) {
        console.error('[Bulk Delete Me] Error:', err);
      }
    }
    setIsBulkDeleting(false);
    if (ok === ids.length) {
      toastSuccess(`تم حذف ${ok} رسالة لديك فقط`);
    } else {
      toastError(`تم حذف ${ok} من ${ids.length} — أعد المحاولة للباقي.`);
    }
    exitSelectionMode();
  };

  const handleImageEditorSend = async (file: File) => {
    setIsUploadingImage(true);
    try {
      let sendingFile: File | Blob = file;
      // Client-side WebP compression — quality governed by chatSettings.uploadQuality
      // (standard: 1600px/0.80 · HD: 2560px/0.95, WhatsApp parity)
      if (file.type.startsWith('image/')) {
        try {
          console.log(`[Image] Optimizing ${file.name} (original: ${(file.size / 1024 / 1024).toFixed(2)} MB)...`);
          const isHd = currentUser?.chatSettings?.uploadQuality === 'hd';
          const compressedBlob = await compressAndConvertImage(file, isHd ? 2560 : 1600, isHd ? 0.95 : 0.80);
          sendingFile = new File([compressedBlob], file.name.replace(/\.[^/.]+$/, "") + ".webp", {
            type: "image/webp"
          });
          console.log(`[Image] Optimized size: ${(sendingFile.size / 1024).toFixed(1)} KB.`);
        } catch (compressErr) {
          console.warn('[Image] Fallback to raw upload:', compressErr);
        }
      }

      // Encrypt-at-source (F1/P0): in E2EE chats the (compressed) image bytes
      // NEVER hit the network in plaintext — encrypt locally, upload ONLY the
      // opaque 'enc.bin' ciphertext; payload rides in-memory to App's send wrap.
      if (e2eeActive) {
        const encBytes = new Uint8Array(await sendingFile.arrayBuffer());
        const encAtt = await encryptAndUploadAttachment(
          encBytes,
          sendingFile.type || file.type || 'application/octet-stream',
          (sendingFile as File).name || file.name || 'image',
          viewOnceArmed ? { viewOnce: true } : undefined
        );
        // Local optimistic preview renders via E2eeMedia (payload → e2eeFiles).
        onSendMessage('', [encAtt], null, []);
        if (viewOnceArmed) setViewOnceArmed(false);
        return;
      }

      // Direct upload to the user's storage (Google Drive or presigned object storage) — never through our DB
      const uploaded = await uploadMediaFile(sendingFile, (sendingFile as File).name || file.name);

      const attachment = {
        name: uploaded.name,
        size: uploaded.size,
        mimeType: uploaded.mimeType,
        url: uploaded.url,
        ...(viewOnceArmed ? { meta: { viewOnce: true } } : {})
      };

      // Raw (compressed) file passed (index-aligned) for the E2EE send wrap.
      onSendMessage('', [attachment], null, [sendingFile]);
  if (viewOnceArmed) setViewOnceArmed(false);
    } catch (err: any) {
      console.error('[ChatWindow] Image upload failed:', err);
      if (err instanceof StorageNotLinkedError) {
        startGdriveLink();
        return;
      }
      if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
        (window as any).showGlobalToast(err?.message || 'فشل رفع الملف', 'error');
      }
    } finally {
      setIsUploadingImage(false);
      setEditingImageFile(null);
    }
  };

  const renderReceipt = (message: any) => {
    switch (message.state) {
      case 'pending':
        return (
          <Clock className="w-3.5 h-3.5 text-slate-500" />
        );
      case 'sending':
        return (
          <Loader2 className="w-3.5 h-3.5 text-slate-500 animate-spin" />
        );
      case 'failed':
        return (
          <button 
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onRetryMessage?.(message.id);
            }} 
            className="flex items-center gap-1 text-red-500 hover:text-red-400 bg-transparent border-0 p-0 cursor-pointer select-none font-bold" 
            title="فشل الإرسال. اضغط لإعادة المحاولة"
          >
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            <span className="text-[10px] shrink-0">فشل (نقرة للإعادة)</span>
          </button>
        );
      case 'sent':
        return (
          <Check className="w-[13px] h-[13px] text-zinc-500/60" strokeWidth={3} />
        );
      case 'delivered':
        return (
          <CheckCheck className="w-[14px] h-[14px] text-zinc-500/60" strokeWidth={3} />
        );
      case 'read':
        return (
          <CheckCheck className="w-[14px] h-[14px] text-[#53bdeb]" strokeWidth={3} />
        );
      default:
        return null;
    }
  };

  const openPortalMenu = (message: ClientMessage, x: number, y: number, isMe: boolean, senderName: string) => {
    // Multi-select mode: taps toggle selection instead of opening the menu.
    if (selectionMode) return;
    setPortalMenu({ message, x, y, isMe, senderName });
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate([15]);
    }
  };

  /**
   * Interactive poll card (WhatsApp parity): options as buttons with live vote
   * counts + RTL percentage bars, ✓ mark on my choices, total-voters footer.
   * Clicking an option votes optimistically and emits msg:poll:vote (REST
   * fallback while disconnected); canonical state arrives via msg:poll:update.
   */
  const renderPollCard = (message: ClientMessage, poll: PollData) => {
    const myId = currentUser.uid || currentUser.id;
    const voters = Object.entries(poll.votes || {}).filter(([, v]) => Array.isArray(v) && v.length > 0);
    const totalVoters = voters.length;
    const myVotes: number[] = Array.isArray(poll.votes?.[myId]) ? poll.votes[myId] : [];
    const isDeleted = message.state === 'deleted';
    return (
      <div className="mt-2.5 w-full min-w-[240px]" style={{ direction: 'rtl' }}>
        <div className="flex items-center gap-1.5 mb-2 text-[10px] font-bold text-emerald-400 select-none">
          <BarChart2 className="w-3.5 h-3.5" />
          <span>{poll.allowMultiple ? 'تصويت متعدد الخيارات' : 'تصويت'}</span>
        </div>
        <div className="space-y-1.5">
          {poll.options.map((opt, idx) => {
            const count = voters.filter(([, v]) => v.includes(idx)).length;
            const pct = totalVoters > 0 ? Math.round((count * 100) / totalVoters) : 0;
            const mine = myVotes.includes(idx);
            return (
              <button
                key={idx}
                type="button"
                disabled={isDeleted}
                onClick={() => handlePollVote(message, poll, idx)}
                className={`relative w-full text-start rounded-xl border px-3 py-2 transition-all duration-200 overflow-hidden select-none ${
                  isDeleted ? 'cursor-not-allowed opacity-60' : 'cursor-pointer active:scale-[0.99]'
                } ${mine ? 'border-emerald-400/40 bg-emerald-500/10' : 'border-white/10 bg-white/5 hover:bg-white/10'}`}
              >
                {/* Percentage bar (RTL: fills from the right edge) */}
                <div
                  className={`absolute inset-y-0 right-0 transition-all duration-300 pointer-events-none ${mine ? 'bg-emerald-500/20' : 'bg-white/10'}`}
                  style={{ width: `${pct}%` }}
                  aria-hidden
                />
                <div className="relative flex items-center gap-2">
                  <span className={`flex items-center justify-center w-4 h-4 rounded-full border shrink-0 text-[9px] font-black ${mine ? 'border-emerald-400 text-emerald-400 bg-emerald-500/20' : 'border-white/30 text-transparent'}`}>
                    ✓
                  </span>
                  <span className="flex-1 text-[12.5px] font-medium text-white/90 break-words leading-snug">{opt}</span>
                  <span className="text-[10px] font-bold text-white/50 shrink-0" style={{ direction: 'ltr' }}>
                    {pct}%
                  </span>
                </div>
              </button>
            );
          })}
        </div>
        <p className="mt-2 text-[10px] text-white/40 text-start select-none">
          {totalVoters > 0
            ? `${totalVoters} ${totalVoters === 1 ? 'مصوّت' : 'مصوّتين'}`
            : 'لا تصويتات بعد — كن أول مصوّت'}
        </p>
      </div>
    );
  };

  const handleOpenMessageInfo = async (message: ClientMessage) => {
    setInfoMsgModal(message);
    setInfoMsgTelemetry([]);
    setInfoMsgReceipts([]);
    setIsLoadingInfo(true);
    setPortalMenu(null);
    try {
      const res = await fetch(`/api/telemetry/messages/${message.id}`, {
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
      if (res.ok) {
        const data = await res.json();
        setInfoMsgTelemetry(data.telemetry || []);
        setInfoMsgReceipts(data.currentReceipts || []);
      }
    } catch (err) {
      console.error('[Telemetry] Failed fetching message telemetry:', err);
    } finally {
      setIsLoadingInfo(false);
    }
  };

  const handleOpenForwardModal = async (message: ClientMessage) => {
    setForwardModalMsg(message);
    setPortalMenu(null);
    setIsLoadingForwardChats(true);
    try {
      const res = await fetch('/api/chats', {
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
      if (res.ok) {
        const data = await res.json();
        setForwardChats(data.chats || []);
      }
    } catch (err) {
      console.error('[Forward] Error fetching chats:', err);
    } finally {
      setIsLoadingForwardChats(false);
    }
  };

  // P0-B: forward re-encrypts the decrypted content for the TARGET chat
  // (group → sender keys; DM → pairwise engine). Fail-closed: if the target
  // can encrypt but the re-encryption fails, the forward is aborted — no
  // plaintext ever rides REST. Attachments ride as-is (their payloads stay
  // inside the original envelope — documented limitation, no regression).
  const forwardWireFor = async (targetChatId: string, text: string): Promise<string> => {
    if (!chatSupportsE2ee(targetChatId)) return text; // non-E2EE target: legacy plaintext path
    return await encryptContentForChat(targetChatId, text);
  };
  const handleForwardAction = async (targetChatId: string) => {
    if (!forwardModalMsg) return;
    setIsForwarding(true);
    try {
      // BATCH-3 (DIR-CB-04) + BATCH-6 (ADV-04): every attempt ENCRYPTS FRESH
      // inside the closure — a 409 MEMBERSHIP_STALE means the composition
      // epoch moved, so the retry MUST re-encrypt under the refreshed keys
      // (resending the identical old-epoch ciphertext stamped with a new mv
      // is the boundary-crossing the gate exists to prevent). The await is
      // inside the async closure, so no Promise is serialized into the body.
      const sendForward = async (mv: unknown) => {
        const wire = await forwardWireFor(targetChatId, forwardModalMsg.content);
        return fetch(`/api/chats/${targetChatId}/messages`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          body: JSON.stringify({
            content: wire,
            type: forwardModalMsg.type,
            attachments: forwardModalMsg.attachments || [],
            ...(mv !== undefined && mv !== null ? { mv } : {}),
          })
        });
      };
      let res = await sendForward(targetChatId === chatId ? (selectedChatMeta as any)?.membershipVersion : undefined);
      if (res.status === 409) {
        // Epoch moved between compose and send: refresh the roster (rotate +
        // re-distribution flow), then re-encrypt under the refreshed keys.
        // Keys refresh: the membership_changed rotation flow updates the local
        // sender key before this point in the common case; if this client
        // missed it, the re-encrypt produces the same old epoch and the server
        // fails the retry CLOSED (no boundary crossing) — honest CB-06 limit.
        const stale = await res.json().catch(() => null);
        const expected = (stale as any)?.expectedVersion;
        if (expected !== undefined) res = await sendForward(expected);
      }
      if (!res.ok) throw new Error('Forward failed');
      setForwardSuccessId(targetChatId);
      setTimeout(() => {
        setForwardSuccessId(null);
        setForwardModalMsg(null);
      }, 1000);
    } catch (err: any) {
      console.error(err);
      alert('فشل إعادة التوجيه: ' + err.message);
    } finally {
      setIsForwarding(false);
    }
  };

  const resolveChatDisplayMeta = (chat: any) => {
    if (chat.type !== 'one-to-one') {
      return { name: chat.name || 'مجموعة', avatarUrl: chat.avatarUrl };
    }
    const otherMemberId = chat.memberIds?.find((mId: string) => mId !== (currentUser.uid || currentUser.id));
    const memberObj = otherMemberId ? allUsers[otherMemberId] : null;
    return {
      name: memberObj?.displayName || memberObj?.username || chat.name || 'مستخدم',
      avatarUrl: memberObj?.avatarUrl
    };
  };

  const getContextItems = (message: ClientMessage, isMe: boolean) => {
    const isDeleted = message.state === 'deleted';
    const items = [];

    // Protected content (Telegram parity): strip copy/forward/save actions
    const isProtected = protectedChat === true;

    if (!isDeleted) {
      if (message.type === 'text' && !isProtected) {
        items.push({
          label: 'نسخ الرسالة',
          icon: <Copy className="w-3.5 h-3.5 text-zinc-400" />,
          action: () => {
            navigator.clipboard.writeText(message.content);
            setPortalMenu(null);
          }
        });
      }

      // Translate (Mission A): other people's text messages only, >= 2 chars.
      // Client-side via MyMemory — result renders inline under the message body.
      if (message.type === 'text' && !isMe && !isProtected && message.content && message.content.trim().length >= 2) {
        items.push({
          label: translatingIds.has(message.id) ? 'جارٍ الترجمة…' : 'ترجمة',
          icon: <Languages className="w-3.5 h-3.5 text-sky-400" />,
          action: () => {
            setPortalMenu(null);
            handleTranslateMessage(message);
          }
        });
      }

      if (onReportMessage) {
        items.push({
          label: 'إبلاغ عن الرسالة (Report)',
          icon: <ShieldAlert className="w-3.5 h-3.5 text-red-400" />,
          action: () => {
            onReportMessage(
              message.id,
              message.senderId,
              message.senderName || portalMenu?.senderName || 'مستخدم غير معروف',
              message.content || '[مرفق وسائط]'
            );
            setPortalMenu(null);
          },
          danger: true
        });
      }
      
      items.push({
        label: 'رد على الرسالة',
        icon: <CornerUpLeft className="w-3.5 h-3.5 text-zinc-400" />,
        action: () => {
          setReplyingToMessage({
            id: message.id,
            senderName: message.senderName || portalMenu?.senderName,
            content: message.content
          });
          setPortalMenu(null);
        }
      });

      // Multi-select (WhatsApp parity): enter selection mode with this message pre-selected.
      items.push({
        label: 'تحديد رسائل',
        icon: <CheckSquare className="w-3.5 h-3.5 text-zinc-400" />,
        action: () => {
          setPortalMenu(null);
          enterSelectionMode(message.id);
        }
      });

      if (isMe && message.type === 'text') {
        items.push({
          label: 'تعديل الرسالة',
          icon: <Edit2 className="w-3.5 h-3.5 text-zinc-400" />,
          action: () => {
            setEditingMessage(message);
            setInputText(message.content);
            setReplyingToMessage(null);
            setPortalMenu(null);
          }
        });
      }

      items.push({
        label: message.isPinned ? 'إلغاء التثبيت' : 'تثبيت الرسالة',
        icon: <Pin className="w-3.5 h-3.5 text-zinc-400 rotate-45" />,
        action: () => {
          handleTogglePin(message.id);
          setPortalMenu(null);
        }
      });

      const isStarred = message.starredBy && message.starredBy.includes(currentUser.uid || currentUser.id);
      items.push({
        label: isStarred ? 'إزالة من المفضلة' : 'تمييز بنجمة',
        icon: <Star className={`w-3.5 h-3.5 ${isStarred ? 'text-amber-400 fill-amber-400/20' : 'text-zinc-400'}`} />,
        action: () => {
          handleToggleStar(message);
          setPortalMenu(null);
        }
      });

      if (!isProtected) items.push({
        label: 'إعادة توجيه',
        icon: <Forward className="w-3.5 h-3.5 text-zinc-400" />,
        action: () => {
          handleOpenForwardModal(message);
        }
      });

      if (message.type === 'attachment' && message.attachments && message.attachments.length > 0 && !isProtected) {
        items.push({
          label: 'حفظ المرفق',
          icon: <Download className="w-3.5 h-3.5 text-zinc-400" />,
          action: () => {
            message.attachments.forEach(att => {
              // BATCH-5 (DIR-2026-040): reverse-tabnabbing guard — the opened
              // page must not receive window.opener.
              window.open(att.url, '_blank', 'noopener,noreferrer');
            });
            setPortalMenu(null);
          }
        });
      }

      if (selectedChatMeta?.type === 'group' && !isProtected) {
        items.push({
          label: 'نسخ رابط الرسالة',
          icon: <Link className="w-3.5 h-3.5 text-zinc-400" />,
          action: () => {
            const link = `${window.location.origin}/?chatId=${chatId}&highlightMsgId=${message.id}`;
            navigator.clipboard.writeText(link).then(() => alert('تم نسخ رابط الرسالة!'));
            setPortalMenu(null);
          }
        });
      }
    }

    // Always show Message Info
    items.push({
      label: 'معلومات الرسالة',
      icon: <Info className="w-3.5 h-3.5 text-zinc-400" />,
      action: () => {
        handleOpenMessageInfo(message);
      }
    });

    // Delete options
    if (!isDeleted && isMe) {
      items.push({
        label: 'حذف لدى الجميع',
        icon: <Trash2 className="w-3.5 h-3.5 text-red-400" />,
        action: () => {
          handleDeleteForEveryone(message.id);
          setPortalMenu(null);
        },
        danger: true
      });
    }

    items.push({
      label: 'حذف لدي فقط',
      icon: <Trash2 className="w-3.5 h-3.5 text-red-300" />,
      action: () => {
        handleDeleteForMe(message.id);
        setPortalMenu(null);
      },
      danger: true
    });

    return items;
  };

  const [focusedIndex, setFocusedIndex] = useState(0);
  const menuItemsRef = useRef<HTMLButtonElement[]>([]);

  useEffect(() => {
    if (!portalMenu) {
      setFocusedIndex(0);
      menuItemsRef.current = [];
      return;
    }
    const items = getContextItems(portalMenu.message, portalMenu.isMe);
    const handleMenuKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setFocusedIndex(prev => (prev + 1) % items.length);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setFocusedIndex(prev => (prev - 1 + items.length) % items.length);
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (menuItemsRef.current[focusedIndex]) {
          menuItemsRef.current[focusedIndex].click();
        }
      }
    };
    document.addEventListener('keydown', handleMenuKeyDown);
    return () => {
      document.removeEventListener('keydown', handleMenuKeyDown);
    };
  }, [portalMenu, focusedIndex]);

  useEffect(() => {
    if (portalMenu && menuItemsRef.current[focusedIndex]) {
      menuItemsRef.current[focusedIndex].focus();
    }
  }, [focusedIndex, portalMenu]);

  // Dynamic portalCoordinates position boundaries
  const getPortalCoordinates = () => {
    if (!portalMenu) return { left: 0, top: 0 };
    const menuWidth = 240;
    const actionItemsCount = getContextItems(portalMenu.message, portalMenu.isMe).length;
    const menuHeight = actionItemsCount * 38 + 70; // approx height of emojis + menu list
    
    let left = portalMenu.x;
    let top = portalMenu.y;
    
    if (portalMenu.x + menuWidth > window.innerWidth) {
      left = portalMenu.x - menuWidth;
    }
    if (portalMenu.y + menuHeight > window.innerHeight) {
      top = portalMenu.y - menuHeight;
    }
    return {
      left: Math.max(16, Math.min(left, window.innerWidth - menuWidth - 16)),
      top: Math.max(16, Math.min(top, window.innerHeight - menuHeight - 16))
    };
  };

  const portalCoordinates = getPortalCoordinates();

  return (
    <div className="chat-view-panel" style={{ direction: 'ltr' }}>
      
      {/* 1. Recipient Profile Header (Aligned exactly with top-bar in index.css) */}
      <div className="top-bar select-none">
        <div className="top-bar-inner">
          {onBack && (
            <div 
              onClick={onBack}
              className="btn-circle md:hidden text-zinc-200"
              title="Go back"
            >
              <ArrowLeft className="w-5 h-5" />
            </div>
          )}

          <div 
            onClick={() => {
              if (onViewProfile && selectedChatMeta.type === 'one-to-one' && selectedChatMeta.otherMember?.id) {
                onViewProfile(selectedChatMeta.otherMember.id);
              }
            }}
            className="profile-card"
          >
            <div className="avatar-wrap">
              <span className="avatar-glow"></span>
              <div className="avatar-img-wrap">
                <img 
                  src={selectedChatMeta.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop'} 
                  alt={selectedChatMeta.name}
                  className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                {selectedChatMeta.type === 'one-to-one' && (allUsers[selectedChatMeta.otherMember?.id]?.onlineStatus === 'online' || selectedChatMeta.otherMember?.onlineStatus === 'online') && (
                  <span className="online-indicator online-indicator-pulse !w-2.5 !h-2.5"></span>
                )}
              </div>
            </div>

            <div className="profile-text text-left">
              <div className="flex items-center gap-1.5 justify-start">
                <span className="profile-name">
                  {selectedChatMeta.name}
                </span>
                {selectedChatMeta.type === 'one-to-one' && selectedChatMeta.otherMember?.verified && (
                  <VerifiedBadge className="w-3.5 h-3.5 shrink-0" />
                )}
              </div>
              <span className="profile-sub">
                {(() => {
                  if (selectedChatMeta.type === 'channel') {
                    return `قناة • ${channelInfo?.subscriberCount ?? (selectedChatMeta.subscriberCount ?? 0)} مشترك`;
                  }
                  if (selectedChatMeta.type !== 'one-to-one') {
                    if (typingUsers.length > 0) return `Typing: ${typingUsers.join(', ')}`;
                    if (recordingUsers.length > 0) return `Recording: ${recordingUsers.join(', ')}`;
                    return 'Secure Encrypted Group';
                  }
                  
                  const otherMember = selectedChatMeta.otherMember;
                  if (!otherMember) return 'Secure Encrypted Chat';

                  // Use live allUsers state for real-time reactivity
                  const userStatusData = allUsers[otherMember.id];
                  const status = userStatusData?.onlineStatus || otherMember.onlineStatus;
                  const lastSeen = userStatusData?.lastSeen || otherMember.lastSeen;

                  if (typingUsers.length > 0) return 'typing...';
                  if (recordingUsers.length > 0) return 'recording audio...';
                  
                  if (status === 'online') return <span className="text-blue-400 font-bold">Online</span>;
                  
                  if (lastSeen) {
                    const diffS = Math.floor((Date.now() - new Date(lastSeen).getTime()) / 1000);
                    if (diffS < 60) return 'last seen recently';
                    if (diffS < 3600) return `last seen ${Math.floor(diffS / 60)}m ago`;
                    if (diffS < 86400) return `last seen ${Math.floor(diffS / 3600)}h ago`;
                    return `last seen ${new Date(lastSeen).toLocaleDateString()}`;
                  }
                  
                  return 'Secure Encrypted Chat';
                })()}
              </span>
            </div>
          </div>

            <div className="flex items-center gap-1.5 ml-auto">
              {/* E2EE lock badge (eligible DMs) → opens the safety-number modal.
                  Verified state (Task C): when the current safety number still
                  matches the stored 'e2eeVerified' reference the badge turns
                  solid emerald with a 'الطرف موثّق ✓' tooltip.
                  F8 (audit): when the plaintext-downgrade memory is set for
                  this peer (they have no E2EE bundle and the conversation is
                  riding plaintext) the lock is REPLACED by the amber
                  "غير مشفرة طرف-لطرف" badge — no silent downgrade. */}
              {e2eePeerId && e2eeDowngraded ? (
                <span
                  className="btn-circle cursor-default"
                  title="هذه المحادثة غير مشفرة طرف-لطرف (الطرف غير مسجل)"
                  aria-label="هذه المحادثة غير مشفرة طرف-لطرف (الطرف غير مسجل)"
                >
                  <Unlock className="w-4 h-4 text-amber-400/90 pointer-events-none" />
                </span>
              ) : e2eePeerId && (
                <button
                  onClick={() => setSafetyModalPeer(e2eePeerId)}
                  className="btn-circle cursor-pointer hover:bg-white/10 active:scale-95 transition-all"
                  title={peerVerified ? 'الطرف موثّق ✓' : 'التشفير طرف-لطرف'}
                  aria-label="التحقق من التشفير"
                >
                  <Lock
                    className={`w-4 h-4 pointer-events-none ${peerVerified ? 'text-emerald-300 fill-emerald-400/70' : 'text-emerald-400/90'}`}
                  />
                </button>
              )}
              {/* F7 (audit): Key Transparency warning — the engine's fleet-proof
                  verification found a VERIFIED-mode contradiction for this peer
                  (witness signature / commitment / inclusion failure). Small
                  badge only; the bundle is never blocked (availability first). */}
              {e2eePeerId && ktFlagged && (
                <span
                  className="btn-circle cursor-default"
                  title="تحذير شفافية المفاتيح"
                  aria-label="تحذير شفافية المفاتيح"
                >
                  <ShieldAlert className="w-4 h-4 text-amber-400/90 pointer-events-none" />
                </span>
              )}
              {/* GROUP E2EE lock badge (regular groups): static tooltip instead
                  of the safety-number modal (that flow is 1:1-only). */}
              {selectedChatMeta?.type === 'group' && (
                <span
                  className="btn-circle cursor-default"
                  title="التشفير جماعي مفعّل"
                  aria-label="التشفير جماعي مفعّل"
                >
                  <Lock className="w-4 h-4 text-emerald-400/90 pointer-events-none" />
                </span>
              )}
              {/* F20 (audit): honest channel classification. Channels are NOT
                  E2EE by design (sender keys cover regular groups only; the
                  server stores channel content readable). This neutral badge
                  states that explicitly — no lock, no encryption implication.
                  Verified: the DM lock / F8 amber badge require
                  type==='one-to-one' (e2eePeerId is 1:1-only) and the group
                  badge requires type==='group', so no channel path renders a
                  lock badge; this pill replaces the implication with the truth. */}
              {selectedChatMeta?.type === 'channel' && (
                <span
                  className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-[10px] font-bold text-slate-300 cursor-default select-none whitespace-nowrap"
                  title="رسائل القنوات محمية أثناء النقل (TLS) لكن السيرفر يستطيع قراءتها"
                  aria-label="قناة — بلا تشفير طرف-لطرف"
                >
                  <Megaphone className="w-3 h-3 text-slate-400/90 pointer-events-none" />
                  قناة — بلا تشفير طرف-لطرف
                </span>
              )}
              {/* Encrypted-conversation export (E2EE backups) — all chat types */}
              <button
                onClick={() => onExportChat && onExportChat()}
                className="btn-circle cursor-pointer hover:bg-white/10 active:scale-95 transition-all"
                title="تصدير المحادثة (نسخة مشفرة)"
                aria-label="تصدير المحادثة (نسخة مشفرة)"
              >
                <Download className="w-4 h-4 text-sky-300/90 pointer-events-none" />
              </button>
                            {/* In-chat message search + media gallery (all chat types) */}
              <button
                onClick={() => setShowChatSearch(v => !v)}
                className="btn-circle cursor-pointer hover:bg-white/10 active:scale-95 transition-all"
                title="بحث في المحادثة"
              >
                <Search className="w-4 h-4 text-zinc-300" />
              </button>
              <button
                onClick={() => setShowMediaGallery(true)}
                className="btn-circle cursor-pointer hover:bg-white/10 active:scale-95 transition-all"
                title="الوسائط"
              >
                <ImageIcon className="w-4 h-4 text-zinc-300" />
              </button>
              {selectedChatMeta?.type === 'group' && (
                <button
                  onClick={() => setShowGroupSettings(true)}
                  className="btn-circle cursor-pointer hover:bg-white/10 active:scale-95 transition-all"
                  title="إعدادات المجموعة"
                >
                  <Users className="w-4 h-4 text-zinc-300" />
                </button>
              )}
              {selectedChatMeta?.type === 'one-to-one' && (
                <>
                  <div 
                    onClick={onStartVoiceCall} 
                    className="btn-circle cursor-pointer hover:bg-white/10 active:scale-95 transition-all" 
                    title="Audio Call"
                  >
                    <Phone className="w-4 h-4 text-zinc-300 pointer-events-none" />
                  </div>

                  <div 
                    onClick={onStartVideoCall} 
                    className="btn-circle cursor-pointer hover:bg-white/10 active:scale-95 transition-all" 
                    title="Video Call"
                  >
                    <Video className="w-4 h-4 text-zinc-300 pointer-events-none" />
                  </div>
                </>
              )}
            </div>
        </div>
      </div>

      {/* In-chat message search bar + results dropdown */}
      <AnimatePresence>
        {showChatSearch && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="relative shrink-0 z-30 bg-black/30 border-b border-white/10 backdrop-blur-xl overflow-hidden"
          >
            <div className="flex items-center gap-2 px-3 py-2" style={{ direction: 'rtl' }}>
              <Search className="w-4 h-4 text-zinc-400 shrink-0" />
              <input
                autoFocus
                value={chatSearchQuery}
                onChange={(e) => setChatSearchQuery(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Escape') { setShowChatSearch(false); setChatSearchQuery(''); setChatSearchResults([]); } }}
                placeholder="ابحث في رسائل هذه المحادثة..."
                className="flex-1 bg-transparent text-sm text-zinc-100 placeholder-zinc-500 outline-none min-w-0"
                dir="auto"
              />
              {isSearchingChat && <Loader2 className="w-4 h-4 text-zinc-400 animate-spin shrink-0" />}
              <button
                onClick={() => { setShowChatSearch(false); setChatSearchQuery(''); setChatSearchResults([]); }}
                className="text-xs text-zinc-400 hover:text-red-400 font-bold px-2 cursor-pointer shrink-0 transition-colors"
              >
                إغلاق
              </button>
            </div>
            {chatSearchQuery.trim() && (
              <div className="max-h-72 overflow-y-auto border-t border-white/5" style={{ direction: 'rtl' }}>
                {chatSearchResults.length === 0 ? (
                  <div className="px-4 py-4 text-xs text-zinc-500 text-center select-none">
                    {isSearchingChat ? 'جارٍ البحث...' : 'لا توجد نتائج مطابقة'}
                  </div>
                ) : (
                  chatSearchResults.map((r) => (
                    <div
                      key={r.id}
                      onClick={() => jumpToSearchResult(r.id, chatSearchQuery.trim())}
                      className="px-3 py-2.5 hover:bg-white/5 active:bg-white/10 cursor-pointer border-b border-white/5 text-right transition-colors"
                    >
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="text-[11px] font-bold text-emerald-400 truncate">{r.senderName || 'مستخدم'}</span>
                        <span className="text-[10px] text-zinc-500 shrink-0 font-mono">
                          {new Date(r.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-xs text-zinc-300 line-clamp-2 break-words leading-relaxed" dir="auto">
                        {renderMarkedContent(String(r.content || ''), chatSearchQuery.trim())}
                      </p>
                    </div>
                  ))
                )}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Pinned Messages Banner */}
      <AnimatePresence>
        {messages.some(m => m.isPinned && m.deletedAt === null) && (() => {
          const pinnedMsg = messages.filter(m => m.isPinned && m.deletedAt === null).slice(-1)[0];
          return (
            <motion.div 
              initial={{ opacity: 0, height: 0, y: -10 }}
              animate={{ opacity: 1, height: 'auto', y: 0 }}
              exit={{ opacity: 0, height: 0, y: -10 }}
              transition={{ type: 'spring', stiffness: 350, damping: 28 }}
              className="bg-black/20 border-b border-white/5 py-2 px-4.5 flex items-center justify-between gap-3 text-left shrink-0 select-none relative z-20 shadow-sm backdrop-blur-xl overflow-hidden"
            >
              <div className="flex items-center gap-2.5 flex-1 min-w-0 pr-1">
                <Pin className="w-3.5 h-3.5 text-zinc-400 rotate-45 shrink-0" />
                <div className="flex-1 min-w-0 text-left">
                  <span className="text-[9px] text-zinc-400 tracking-wider font-extrabold uppercase block select-none">
                    رسالة مثبتة
                  </span>
                  <p className="text-xs text-zinc-300 truncate max-w-2xl font-normal leading-tight font-sans mt-0.5">
                    {pinnedMsg.content || '[وسائط متعددة]'}
                  </p>
                </div>
              </div>
              <button 
                onClick={() => handleTogglePin(pinnedMsg.id)}
                className="p-1 rounded-full text-zinc-500 hover:text-zinc-200 hover:bg-white/5 transition-all cursor-pointer"
                title="إلغاء التثبيت"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </motion.div>
          );
        })()}
      </AnimatePresence>

      {/* 2. Messages Stream Grid */}
      <div
        className="chat-area"
        ref={scrollRef}
        onScroll={handleScroll}
        onCopy={protectedChat ? (e) => e.preventDefault() : undefined}
        onContextMenu={protectedChat ? (e) => e.preventDefault() : undefined}
        style={{ direction: 'ltr', userSelect: protectedChat ? 'none' : undefined, zoom: ({ small: 0.85, medium: 1, large: 1.15, xlarge: 1.3 } as Record<string, number>)[String(currentUser?.chatSettings?.fontScale || 'medium')] || 1 }}
      >
        <div
          className="chat-area-inner"
          style={{
            background: ({
              '': '',
              'aurora': 'linear-gradient(135deg, #0f2027 0%, #203a43 55%, #2c5364 100%)',
              'midnight': 'linear-gradient(135deg, #141e30 0%, #243b55 100%)',
              'forest': 'linear-gradient(135deg, #0b2e1f 0%, #14532d 60%, #052e1b 100%)',
              'plum': 'linear-gradient(135deg, #2d1b4e 0%, #44318d 100%)',
            } as Record<string, string>)[String(
              // Per-chat wallpaper overrides the global one (WhatsApp parity)
              ((currentUser as any)?.chatWallpapers as Record<string, string>)?.[chatId]
              ?? currentUser?.chatSettings?.wallpaper
              ?? ''
            )] || undefined,
            // Wallpaper dimming (WhatsApp parity): inset overlay over the background
            boxShadow: `inset 0 0 0 9999px rgba(0,0,0,${(Number((currentUser as any)?.appearanceSettings?.bgDim) || 0) / 100})`,
          }}
        >
        
        {/* E2EE rekey warning (Task C): persistent amber banner for eligible
            DMs whose peer identity changed since the last recorded safety
            number. Stays until the user verifies and dismisses it. */}
        {e2eePeerId && rekeyFlagged && (
          <div
            className="mx-3 mt-2 p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex flex-col gap-2 select-none"
            style={{ direction: 'rtl' }}
          >
            <div className="flex items-start gap-2">
              <ShieldAlert size={16} className="text-amber-400 shrink-0 mt-0.5" />
              <span className="text-amber-300 text-xs font-bold leading-relaxed">
                ⚠️ تغيّرت مفاتيح التشفير لهذا المستخدم — تحقق من رقم الأمان معه
              </span>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={() => setSafetyModalPeer(e2eePeerId)}
                className="px-3 py-1.5 rounded-xl bg-amber-500 text-black font-black text-[11px] hover:bg-amber-400 transition-colors cursor-pointer"
              >
                فحص رقم الأمان
              </button>
              <button
                onClick={handleDismissRekey}
                className="px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 text-zinc-300 font-bold text-[11px] hover:bg-white/10 transition-colors cursor-pointer"
              >
                تأكدت — إزالة التنبيه
              </button>
            </div>
          </div>
        )}

        {/* Lazy Loading Pagination Button */}
        {hasMore && decoratedMessages.length > 0 && (
          <div className="text-center py-2 select-none">
            <button
              onClick={() => onLoadMoreMessages(decoratedMessages[0].createdAt)}
              className="px-4 py-1.5 bg-white/5 border border-white/10 text-zinc-300 hover:text-white rounded-lg text-xs font-bold cursor-pointer hover:bg-white/10 transition-all"
            >
              Load previous messages
            </button>
          </div>
        )}

        {isLoadingMessages && messages.length === 0 ? (
          <div className="py-24 px-6 text-center flex flex-col items-center justify-center">
            <div className="relative w-12 h-12 mb-6">
              {/* Spinning glass ring */}
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                className="absolute inset-0 border border-white/5 border-t-white/30 rounded-full"
              />
              {/* Center dot */}
              <div className="absolute inset-0 flex items-center justify-center">
                <motion.div 
                  animate={{ opacity: [0.3, 0.6, 0.3] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="w-1.5 h-1.5 bg-white/40 rounded-full"
                />
              </div>
            </div>
            <p className="text-[10px] font-medium text-zinc-500 uppercase tracking-[0.4em] select-none">
              Syncing
            </p>
          </div>
        ) : decoratedMessages.length > 0 ? (
          decoratedMessages.map((message) => {
              const isMe = message.senderId === currentUser.id;
              // RESOLVE LATEST SENDER DATA: Use the global allUsers map to keep names/avatars reactive
              const sender = allUsers[message.senderId];
              const senderName = isMe ? 'You' : (sender?.displayName || message.senderName || 'User');

              // Group system event messages render as centered pills (WhatsApp parity)
              if ((message as any).metadata?.isSystem || (message as any).type === 'system') {
                return (
                  <div key={message.id} className="flex justify-center py-1 select-none">
                    <span className="px-3 py-1 rounded-full bg-white/[0.06] border border-white/10 text-[10px] text-zinc-400 text-center max-w-[80%]">
                      {String(message.content || (message as any).body || '')}
                    </span>
                  </div>
                );
              }
              const avatarUrl = sender?.avatarUrl || sender?.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop';
              // Poll resolution: live override (msg:poll:update / optimistic vote)
              // → persisted messages.poll → the structured poll attachment that
              // rides the optimistic send path before the server echoes back.
              const pollData: PollData | null = pollOverrides[message.id]
                || (message as any).poll
                || ((message.attachments && (message.attachments[0] as any)?.mimeType === 'application/x-dirasha-poll')
                  ? (message.attachments[0] as any).poll
                  : null) || null;
              
              return (
                <div 
                  key={message.id} 
                  className={`w-full flex ${isMe ? 'justify-end' : 'justify-start'}`}
                  style={{ direction: 'ltr' }}
                >
                  <div
                    id={`msg-${message.id}`}
                    onDoubleClick={(e) => {
                      if (message.state === 'deleted') return;
                      e.preventDefault();
                      openPortalMenu(message, e.clientX || window.innerWidth / 2, e.clientY || window.innerHeight / 2, isMe, senderName);
                    }}
                    onContextMenu={(e) => {
                      e.preventDefault();
                      openPortalMenu(message, e.clientX, e.clientY, isMe, senderName);
                    }}
                    onTouchStart={(e) => {
                      if (message.state === 'deleted') return;
                      handleDragStart(e, message.id);
                      const touch = e.touches[0];
                      const cx = touch.clientX;
                      const cy = touch.clientY;
                      longPressTimeoutRef.current = setTimeout(() => {
                        openPortalMenu(message, cx, cy, isMe, senderName);
                      }, 500);
                    }}
                    onTouchMove={(e) => {
                      handleDragMove(e);
                      if (longPressTimeoutRef.current) {
                        clearTimeout(longPressTimeoutRef.current);
                        longPressTimeoutRef.current = null;
                      }
                    }}
                    onTouchEnd={() => {
                      handleDragEnd(message, message.senderName || senderName);
                      if (longPressTimeoutRef.current) {
                        clearTimeout(longPressTimeoutRef.current);
                        longPressTimeoutRef.current = null;
                      }
                    }}
                    onMouseDown={(e) => {
                      if (e.button === 0) { // left click drag
                        if (message.state === 'deleted') return;
                        handleDragStart(e, message.id);
                        const cx = e.clientX;
                        const cy = e.clientY;
                        longPressTimeoutRef.current = setTimeout(() => {
                          openPortalMenu(message, cx, cy, isMe, senderName);
                        }, 500);
                      }
                    }}
                    onMouseMove={(e) => {
                      handleDragMove(e);
                      if (longPressTimeoutRef.current) {
                        clearTimeout(longPressTimeoutRef.current);
                        longPressTimeoutRef.current = null;
                      }
                    }}
                    onMouseUp={() => {
                      handleDragEnd(message, message.senderName || senderName);
                      if (longPressTimeoutRef.current) {
                        clearTimeout(longPressTimeoutRef.current);
                        longPressTimeoutRef.current = null;
                      }
                    }}
                    onMouseLeave={() => {
                      if (isDraggingRef.current) {
                        handleDragEnd(message, message.senderName || senderName);
                      }
                      if (longPressTimeoutRef.current) {
                        clearTimeout(longPressTimeoutRef.current);
                        longPressTimeoutRef.current = null;
                      }
                    }}
                    onClick={(e) => {
                      // Multi-select mode: tapping a bubble toggles its checkbox.
                      if (!selectionMode || message.state === 'deleted') return;
                      e.stopPropagation();
                      toggleMessageSelection(message.id);
                    }}
                  className={`flex items-end gap-1.5 group relative transition-all duration-300 border-2 border-transparent py-0.5 select-none w-fit max-w-[85%] sm:max-w-[78%] md:max-w-[72%] ${
                    isMe ? 'flex-row-reverse' : 'flex-row'
                  } ${activeActionId === message.id ? 'z-50' : 'z-10'}`}
                  style={{
                    transform: activeDragMsgId === message.id ? `translateX(${activeDragOffset}px)` : 'translateX(0px)',
                    transition: activeDragMsgId === message.id ? 'none' : 'transform 0.25s cubic-bezier(0.18, 0.89, 0.32, 1.28)'
                  }}
                >
                  {/* Multi-select checkbox (WhatsApp parity): first child → outer side of the bubble
                      (rightmost for own flex-row-reverse rows, leftmost for incoming rows). */}
                  {selectionMode && message.state !== 'deleted' && (
                    <button
                      type="button"
                      onClick={(e) => { e.stopPropagation(); toggleMessageSelection(message.id); }}
                      onMouseDown={(e) => e.stopPropagation()}
                      onTouchStart={(e) => e.stopPropagation()}
                      onDoubleClick={(e) => e.stopPropagation()}
                      onContextMenu={(e) => e.preventDefault()}
                      aria-checked={selectedMessageIds.has(message.id)}
                      role="checkbox"
                      className={`w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0 mb-1 transition-all cursor-pointer ${
                        selectedMessageIds.has(message.id)
                          ? 'bg-emerald-500 border-emerald-400 text-white'
                          : 'border-white/40 bg-black/30 text-transparent hover:border-emerald-400/60'
                      }`}
                      title={selectedMessageIds.has(message.id) ? 'إلغاء التحديد' : 'تحديد الرسالة'}
                    >
                      <Check className="w-3.5 h-3.5" />
                    </button>
                  )}
                  {/* Visual Swipe Signal indicator */}
                  {activeDragMsgId === message.id && Math.abs(activeDragOffset) > 15 && (
                    <div 
                      className={`absolute top-1/2 -translate-y-1/2 flex items-center justify-center p-1.5 rounded-full bg-blue-500/15 border border-blue-500/35 text-blue-400 transition-all ${
                        activeDragOffset > 0 ? 'left-[-45px]' : 'right-[-45px]'
                      }`}
                      style={{
                        opacity: Math.min(1, (Math.abs(activeDragOffset) - 15) / 40),
                        transform: `translateY(-50%) scale(${Math.min(1.15, 0.7 + Math.abs(activeDragOffset) / 80)})`
                      }}
                    >
                      <CornerUpLeft className="w-3.5 h-3.5 text-blue-400" />
                    </div>
                  )}

                  {/* Standard Message Bubble Core Container */}
                  <div className={`flex flex-col relative w-full min-w-0 ${message.type === 'call' ? '!max-w-full items-center mx-auto text-center' : `${isMe ? 'items-end' : 'items-start'}`}`}>
                    {/* Sender Name in group chats and channel posts */}
                    {!isMe && message.type !== 'call' && (selectedChatMeta.type === 'group' || selectedChatMeta.type === 'channel') && (
                      <span 
                        onClick={() => {
                          if (onViewProfile && message.senderId) {
                            onViewProfile(message.senderId);
                          }
                        }}
                        className="text-[11px] text-[#38bdf8] hover:text-[#53bdeb] font-bold mb-0.5 px-2 flex items-center gap-1.5 justify-start cursor-pointer hover:underline transition-all active:scale-95"
                      >
                        {message.sender?.verified && (
                          <VerifiedBadge className="w-3.5 h-3.5 shrink-0" />
                        )}
                        <span>{senderName}</span>
                      </span>
                    )}

                    {message.type === 'call' ? (
                      <div className="my-3 w-full flex justify-center pb-2">
                        <div className="bg-white/5 border border-white/10 shadow-[0_8px_32px_0_rgba(0,0,0,0.4)] backdrop-blur-3xl rounded-full px-5 py-2.5 flex items-center gap-3 transition-all hover:bg-white/10 select-none">
                          <div className={`p-1.5 rounded-full flex-shrink-0 ${message.content.includes('فائتة') || message.content.includes('مرفوضة') || message.content.includes('Missed') ? 'bg-red-500/20 text-red-400' : 'bg-[#007aff]/20 text-[#007aff]'}`}>
                            {message.content.includes('فيديو') || message.content.includes('Video') ? (
                              <Video className="w-4 h-4 fill-current" />
                            ) : (
                              <Phone className="w-4 h-4 fill-current" />
                            )}
                          </div>
                          <div className="flex items-center justify-between gap-4" style={{ direction: 'ltr' }}>
                            <span className="text-[14px] font-medium text-white/95 truncate tracking-tight">
                              {message.content}
                            </span>
                            <span className="text-[11px] text-white/30 font-medium tracking-wide">
                              {fmtChatTime(message.createdAt)}
                            </span>
                          </div>
                        </div>
                      </div>
                    ) : (
                    <>
                      {/* Message Bubble Card with customized theme classes */}
                      <div
                        className={`${
                        message.attachments && 
                        message.attachments.length > 0 && 
                        message.attachments[0].mimeType && message.attachments[0].mimeType.startsWith('image/') && 
                        !message.content
                          ? 'message-bubble-raw'
                          : `message-bubble ${isMe ? 'outgoing' : 'incoming'}`
                      } ${
                        message.state === 'deleted' ? 'opacity-50' : 'opacity-100'
                      } ${
                        starredMessageGlowId === message.id 
                          ? 'ring-2 ring-amber-500/50 shadow-lg shadow-amber-500/20 scale-[1.01] transition-all duration-300' 
                          : 'transition-all duration-300'
                      } relative`}
                      >
                      <AnimatePresence>
                        {starredMessageGlowId === message.id && (
                          <motion.div
                            initial={{ scale: 0, opacity: 0, rotate: -45 }}
                            animate={{ scale: [0, 1.4, 1], opacity: [0, 1, 0], rotate: 0 }}
                            exit={{ scale: 0, opacity: 0 }}
                            transition={{ duration: 0.8, ease: "easeOut" }}
                            className="absolute inset-0 flex items-center justify-center pointer-events-none z-50 bg-amber-500/10 rounded-2xl"
                          >
                            <Star className="w-12 h-12 text-amber-400 fill-amber-400 drop-shadow-[0_0_12px_rgba(251,191,36,0.8)]" />
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {/* Quoted Reply Display block (Status Forward) */}
                      {message.metadata?.is_status_forward && (
                        <motion.div 
                          whileHover={{ scale: 1.01 }}
                          whileTap={{ scale: 0.99 }}
                          onClick={() => {
                            if (onOpenStatus && message.metadata.status_id) {
                              onOpenStatus(message.metadata.status_id, message.metadata.owner_id);
                            }
                          }}
                          className="mb-3 p-4 bg-white/10 hover:bg-white/[0.15] rounded-[24px] border border-white/20 cursor-pointer overflow-hidden transition-all group/status shadow-xl backdrop-blur-md"
                        >
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-2">
                               <div className="w-7 h-7 rounded-full bg-white/10 flex items-center justify-center border border-white/10">
                                  <RefreshCw className="w-4 h-4 text-white" />
                               </div>
                               <span className="text-[12px] font-black text-white/90 tracking-tight uppercase">Status Forward</span>
                            </div>
                            <div className="flex items-center gap-1.5 bg-white/10 px-2 py-0.5 rounded-full border border-white/10">
                               <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                               <span className="text-[9px] font-bold text-white/60">LIVE</span>
                            </div>
                          </div>
                          
                          {message.attachments && message.attachments[0] && (
                            <div className="relative aspect-video rounded-2xl overflow-hidden mb-3 bg-black/40 ring-1 ring-white/10">
                               {message.attachments[0].meta?.e2ee === true ? (
                                 /* E2EE guard: encrypted media never renders raw —
                                    lock card (payloads never travel with forwards). */
                                 <E2eeMedia att={message.attachments[0]} payload={null} accessToken={accessToken} />
                               ) : message.attachments[0].mimeType?.startsWith('video/') ? (
                                 <video 
                                   src={message.attachments[0].url.startsWith('/api') ? `${message.attachments[0].url}?access_token=${mediaToken}` : message.attachments[0].url} 
                                   className="w-full h-full object-cover opacity-80"
                                   muted
                                   playsInline
                                 />
                               ) : (
                                 <img 
                                   src={message.attachments[0].url.startsWith('/api') ? `${message.attachments[0].url}?access_token=${mediaToken}` : message.attachments[0].url} 
                                   className="w-full h-full object-cover opacity-80"
                                 />
                               )}
                               <div className="absolute inset-0 flex items-center justify-center bg-black/20 group-hover/status:bg-black/10 transition-colors">
                                  <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-xl border border-white/30 flex items-center justify-center group-hover/status:scale-110 transition-transform shadow-2xl">
                                     <Play className="w-6 h-6 text-white fill-white" />
                                  </div>
                               </div>
                            </div>
                          )}
                          
                          <div className="space-y-1">
                            <p className="text-[13px] text-white/90 font-medium line-clamp-2 leading-relaxed">{message.content}</p>
                            <div className="flex items-center gap-2 text-[10px] text-white/40 font-bold uppercase tracking-widest pt-1">
                               <Eye className="w-3 h-3" />
                               <span>Click to view full story</span>
                            </div>
                          </div>
                        </motion.div>
                      )}

                      {message.replyTo && (
                        <div 
                          onClick={() => {
                            const targetId = message.replyTo?.id;
                            if (targetId) {
                              const element = document.getElementById(`msg-${targetId}`);
                              if (element) {
                                element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                element.classList.add('ring-4', 'ring-amber-500/80', 'scale-[1.02]');
                                setTimeout(() => {
                                  element.classList.remove('ring-4', 'ring-amber-500/80', 'scale-[1.02]');
                                }, 2500);
                              }
                            }
                          }}
                          dir="auto"
                          className="mb-2 p-2 bg-black/25 hover:bg-black/40 rounded-lg border-s-4 border-sky-400 cursor-pointer text-start text-[11.5px] transition-all select-none w-full min-w-0"
                        >
                          <div className="font-bold text-sky-400 mb-0.5 truncate">{message.replyTo.senderName}</div>
                          <p className="text-zinc-300 truncate max-w-xs">
                            {(() => {
                              const orig = (messages || []).find((m: any) => m.id === message.replyTo.id);
                              if (orig) return typeof orig.content === 'string' ? orig.content : 'مرفق مشفر';
                              // Legacy quotes (pre-P0-B) keep their stored preview;
                              // new quotes carry no plaintext — id-only lookup only.
                              return typeof message.replyTo.content === 'string' ? message.replyTo.content : 'الرسالة الأصلية غير متوفرة';
                            })()}
                          </p>
                        </div>
                      )}

                      {/* Message body - only show if there is text content and NOT a status forward */}
                      {/* E2EE: also admit failed-decrypt messages (content cleared, e2eeError set) so the lock placeholder renders */}
                      {(message.content || (message as any).e2eeError) && !message.metadata?.is_status_forward && !(message.attachments && message.attachments.length > 0 && message.attachments[0].mimeType && message.attachments[0].mimeType.startsWith('audio/')) && (
                        <div 
                          dir="auto"
                          className={`text-[13.5px] sm:text-[14px] leading-relaxed whitespace-pre-wrap break-words overflow-hidden w-full text-start select-text ${
                            message.state === 'deleted' ? 'italic text-zinc-400/80' : 'text-inherit'
                          }`}
                          style={{
                            overflowWrap: 'anywhere',
                            wordBreak: 'normal',
                            unicodeBidi: 'plaintext'
                          }}
                        >
                          {(() => {
                            const text = String(message.content || '');
                            // E2EE render guard: never render raw DIR1 ciphertext
                            // (undecrypted or failed) — show the lock placeholder.
                            if (isE2eeLockedContent(message)) {
                              return (
                                <span
                                  className="inline-flex items-center gap-1.5 text-[12px] italic text-zinc-400/80 select-none"
                                  dir="rtl"
                                  title={(message as any).e2eeError ? 'تعذر فك تشفير هذه الرسالة' : 'جارٍ فك التشفير...'}
                                >
                                  <Lock className="w-3 h-3 shrink-0" />
                                  {(message as any).e2eeError ? 'تعذر فك تشفير الرسالة' : 'رسالة مشفرة...'}
                                </span>
                              );
                            }
                            // Search-hit highlight keeps its own plain-text <mark> path
                            // (first occurrence of the active query).
                            if (message.id === activeHighlightId && searchHighlightQuery) {
                              return renderMarkedContent(text, searchHighlightQuery);
                            }
                            // WhatsApp-style formatting: *bold* / _italic_ / ~strike~ /
                            // ``` ``` mono cards + @mention highlight — safe tokenizer.
                            return renderFormattedText(text, `fmt-${message.id}`);
                          })()}
                        </div>
                      )}

                      {/* Inline translation card (Mission A) — plain text, client-side MyMemory result */}
                      {translations[message.id] && message.content && !message.metadata?.is_status_forward && message.state !== 'deleted' && (
                        <div
                          className="mt-2 p-2.5 bg-white/[0.04] border border-white/10 rounded-xl w-full min-w-0"
                          style={{ direction: 'rtl' }}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <p
                              className="flex-1 min-w-0 text-[12px] leading-relaxed text-white/85 whitespace-pre-wrap break-words overflow-hidden"
                              style={{ overflowWrap: 'anywhere' }}
                            >
                              <span className="text-sky-400 font-bold">🌐 الترجمة: </span>
                              {translations[message.id]}
                            </p>
                            <button
                              type="button"
                              onClick={() => setTranslations(prev => {
                                const next = { ...prev };
                                delete next[message.id];
                                return next;
                              })}
                              aria-label="إخفاء الترجمة"
                              className="shrink-0 text-white/40 hover:text-white/80 transition-colors cursor-pointer"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      )}

                      {/* Interactive poll card (WhatsApp parity) — replaces the media chain on poll messages */}
                      {pollData && message.state !== 'deleted' && renderPollCard(message, pollData)}

                      {/* Attachment displays (Hidden for status forwards as they have their own preview; poll pseudo-attachments render via the poll card above) */}
                      {message.state !== 'deleted' && !message.metadata?.is_status_forward && message.attachments && message.attachments.length > 0 && message.attachments[0].mimeType !== 'application/x-dirasha-poll' && (
                        /* E2EE encrypted attachment (media E2EE) — FIRST branch: meta.e2ee
                           attachments are opaque 'enc.bin' blobs; decrypt + render via
                           E2eeMedia using the payload from message.e2eeFiles. When the
                           payload is missing (own-echo loss / parse failure) E2eeMedia
                           renders the muted 'مرفق مشفر' lock card. */
                        message.attachments[0].meta?.e2ee === true ? (
                          (() => {
                            const att: any = message.attachments[0];
                            const e2eeFiles = (message as any).e2eeFiles;
                            const payload = Array.isArray(e2eeFiles)
                              ? (e2eeFiles.find((p: any) => p?.attId === att.id) || null)
                              : null;
                            return (
                              <E2eeMedia
                                att={att}
                                payload={payload}
                                accessToken={accessToken}
                                onOpenImage={(url: string, name: string) => setFullScreenImage({ url, name })}
                              />
                            );
                          })()
                        ) : /* Sticker (WhatsApp parity v1): meta.sticker image → direct <img> */
                          (message.attachments[0].meta?.sticker === true && message.attachments[0].mimeType && message.attachments[0].mimeType.startsWith('image/')) ? (
                          (() => {
                            const att = message.attachments[0];
                            return (
                              <StickerImage
                                src={att.url.startsWith('/api') ? `${att.url}?access_token=${mediaToken}` : att.url}
                                alt={att.name || 'ملصق'}
                                name={att.name}
                                onOpen={() => {
                                  if (selectionMode) {
                                    toggleMessageSelection(message.id);
                                    return;
                                  }
                                  setFullScreenImage({
                                    url: att.url.startsWith('/api') ? `${att.url}?access_token=${mediaToken}` : att.url,
                                    name: att.name || 'ملصق'
                                  });
                                }}
                              />
                            );
                          })()
                        ) : message.attachments[0].mimeType === 'application/x-dirasha-location' ? (
                          /* Real shared location — card + external map link (never an <img>) */
                          (() => {
                            const att: any = message.attachments[0];
                            // Coordinates survive reload via the OSM share-link itself
                            let lat = typeof att.lat === 'number' ? att.lat : NaN;
                            let lng = typeof att.lng === 'number' ? att.lng : NaN;
                            if (!Number.isFinite(lat) && typeof att.url === 'string') {
                              try {
                                const u = new URL(att.url);
                                lat = parseFloat(u.searchParams.get('mlat') || '');
                                lng = parseFloat(u.searchParams.get('mlon') || '');
                              } catch { /* keep NaN */ }
                            }
                            const hasCoords = Number.isFinite(lat) && Number.isFinite(lng);
                            return (
                              <div className="mt-2.5 p-3 bg-black/30 border border-white/5 rounded-2xl flex items-center gap-3 text-left min-w-[230px]" style={{ direction: 'rtl' }}>
                                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center shrink-0">
                                  <MapPin className="w-5 h-5 text-emerald-400" />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className="text-[12px] font-bold text-white truncate">📍 {att.name || 'موقعي'}</p>
                                  {hasCoords && (
                                    <p className="text-[10px] text-slate-400 truncate" style={{ direction: 'ltr', textAlign: 'right' }}>
                                      {lat.toFixed(5)}, {lng.toFixed(5)}
                                    </p>
                                  )}
                                  <a
                                    href={att.url}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="inline-flex items-center gap-1 mt-1 text-[11px] font-bold text-emerald-400 hover:text-emerald-300 transition-colors cursor-pointer"
                                  >
                                    <MapPin className="w-3 h-3" />
                                    افتح الخريطة
                                  </a>
                                </div>
                              </div>
                            );
                          })()
                        ) : message.attachments[0].mimeType === 'application/x-dirasha-contact' ? (
                          /* Shared contact card — avatar initial + name + @username + open-chat action */
                          (() => {
                            const att: any = message.attachments[0];
                            const mta: any = (att as any).meta || {};
                            const cName = String(att.name || mta.username || 'مستخدم');
                            const cUser = String(att.username ?? mta.username ?? '');
                            return (
                              <div className="mt-2.5 p-3 bg-black/30 border border-white/5 rounded-2xl flex items-center gap-3 text-left min-w-[230px]" style={{ direction: 'rtl' }}>
                                <div className="w-10 h-10 rounded-full bg-indigo-500/20 border border-indigo-400/20 flex items-center justify-center font-bold text-indigo-300 shrink-0 text-sm">
                                  {cName.charAt(0)}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className="text-[12px] font-bold text-white truncate">{cName}</p>
                                  {cUser && (
                                    <p className="text-[10px] text-slate-400 truncate" style={{ direction: 'ltr', textAlign: 'right' }}>@{cUser}</p>
                                  )}
                                </div>
                                {(att.contactUserId ?? mta.contactUserId) && onViewProfile && (
                                  <button
                                    type="button"
                                    onClick={() => onViewProfile(String(att.contactUserId ?? mta.contactUserId))}
                                    className="px-3 py-1.5 rounded-full bg-indigo-500/20 text-indigo-300 hover:bg-indigo-500/30 hover:text-indigo-200 text-[10px] font-bold transition-all cursor-pointer shrink-0"
                                  >
                                    فتح المحادثة
                                  </button>
                                )}
                              </div>
                            );
                          })()
                        ) : message.attachments[0].mimeType && message.attachments[0].mimeType.startsWith('audio/') && !(message.attachments[0] as any).waves ? (
                          /* Real audio file (music/clip) — native player card (voice notes keep the waveform UI via `waves`) */
                          (() => {
                            const att = message.attachments[0];
                            const src = att.url.startsWith('/api') ? `${att.url}?access_token=${mediaToken}` : att.url;
                            return (
                              <div className="mt-2.5 p-3 bg-black/30 border border-white/5 rounded-2xl min-w-[230px] text-left">
                                <div className="flex items-center gap-2 mb-2" style={{ direction: 'rtl' }}>
                                  <Music className="w-4 h-4 text-pink-400 shrink-0" />
                                  <p className="text-[11px] font-bold text-white truncate flex-1">{att.name || 'ملف صوتي'}</p>
                                  {formatFileSize(att.size) && <span className="text-[9px] text-slate-400 shrink-0">{formatFileSize(att.size)}</span>}
                                </div>
                                <audio src={src} controls preload="metadata" className="w-full h-9" />
                              </div>
                            );
                          })()
                        ) : message.attachments[0].mimeType && message.attachments[0].mimeType.startsWith('audio/') ? (
                          <ModernVoiceMessage
                            url={message.attachments[0].url.startsWith('/api') ? `${message.attachments[0].url}?access_token=${mediaToken}` : message.attachments[0].url}
                            size={message.attachments[0].size}
                            isMe={isMe}
                          />
                        ) : isViewOnce(message.attachments[0]) ? (
                          /* View-once media (client honor system): blurred until tapped */
                          (() => {
                            const att: any = message.attachments[0];
                            const vsrc = att.url.startsWith('/api') ? att.url + '?access_token=' + mediaToken : att.url;
                            const revealed = viewOnceRevealed.has(message.id);
                            return (
                              <div className='raw-image-container mt-2 relative'>
                                {revealed ? (
                                  <MediaGate
                                    src={vsrc}
                                    alt={att.name || 'صورة'}
                                    autoDownload='always'
                                    onOpen={() => setFullScreenImage({ url: vsrc, name: att.name })}
                                  />
                                ) : (
                                  <div onClick={() => setViewOnceRevealed(prev => new Set(prev).add(message.id))} className='relative rounded-2xl overflow-hidden bg-black/40 border border-amber-400/20 cursor-pointer'>
                                    <div className='h-56 w-full bg-gradient-to-br from-amber-500/10 to-amber-600/5 flex flex-col items-center justify-center gap-2'>
                                      <Eye className='w-8 h-8 text-amber-400/70' />
                                      <p className='text-[12px] font-bold text-amber-200/80'>رسالة تُعرض مرة واحدة</p>
                                  <p className='text-[10px] text-amber-200/50'>اضغط للعرض</p>
                                    </div>
                                  </div>
                                )}
                              </div>
                            );
                          })()
                        ) : message.attachments[0].mimeType && message.attachments[0].mimeType.startsWith('image/') ? (
                          <div className="raw-image-container mt-2">
                             <MediaGate
                              src={message.attachments[0].url.startsWith('/api') ? `${message.attachments[0].url}?access_token=${mediaToken}` : message.attachments[0].url}
                              alt={message.attachments[0].name}
                              autoDownload={(() => {
                                // WhatsApp-parity: media auto-loads immediately for
                                // everyone by default. Only an EXPLICIT user choice
                                // ('never' / data-saver) gates it.
                                const matrix = (currentUser as any)?.chatSettings?.autoDownloadMatrix;
                                if (matrix?.photos === 'never') return 'never';
                                const raw = currentUser?.chatSettings?.mediaAutoDownload;
                                if (raw === false) return 'never';
                                return 'always';
                              })()}
                              onOpen={() => setFullScreenImage({
                                url: message.attachments[0].url.startsWith('/api') ? `${message.attachments[0].url}?access_token=${mediaToken}` : message.attachments[0].url,
                                name: message.attachments[0].name
                              })}
                            />
                          </div>
                        ) : message.attachments[0].mimeType && message.attachments[0].mimeType.startsWith('video/') && currentUser?.chatSettings?.inlineVideos !== false ? (
                          // Inline video preview (Telegram parity) — gated by chatSettings.inlineVideos
                          <div className="raw-image-container mt-2">
                            <video
                              src={message.attachments[0].url.startsWith('/api') ? `${message.attachments[0].url}?access_token=${mediaToken}` : message.attachments[0].url}
                              controls
                              preload="metadata"
                              playsInline
                              className="max-h-[400px] w-full rounded-2xl"
                            />
                          </div>
                        ) : (
                          /* Document / generic file card — extension icon, name, human size, open/download */
                          (() => {
                            const att = message.attachments[0];
                            const { Icon, cls } = fileIconFor(String(att.name || ''));
                            const src = att.url && att.url.startsWith('/api') ? `${att.url}?access_token=${mediaToken}` : (att.url || '#');
                            const ext = String(att.name || '').split('.').pop()?.toUpperCase() || '';
                            return (
                              <div className="mt-2.5 p-3 bg-black/30 border border-white/5 rounded-xl flex items-center gap-3 text-slate-200 text-left min-w-[230px]" style={{ direction: 'rtl' }}>
                                <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center shrink-0">
                                  <Icon className={`w-5 h-5 ${cls}`} />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className="text-[12px] font-bold truncate text-white">{att.name || 'ملف'}</p>
                                  <span className="text-[10px] text-slate-400">
                                    {[ext, formatFileSize(att.size)].filter(Boolean).join(' · ')}
                                  </span>
                                </div>
                                <a
                                  href={src}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  title="فتح / تنزيل"
                                  className="p-2 hover:bg-white/5 rounded-lg text-slate-300 hover:text-blue-400 transition-all shrink-0"
                                >
                                  <Download className="w-4 h-4" />
                                </a>
                              </div>
                            );
                          })()
                        )
                      )}

                      {/* Emojis Reactions list display */}
                      {message.state !== 'deleted' && message.reactions && Object.keys(message.reactions).length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2 justify-end" style={{ direction: 'ltr' }}>
                          {Object.entries(message.reactions).map(([emoji, list]: any) => {
                            const listArray = list as string[];
                            if (!listArray || listArray.length === 0) return null;
                            const hasReacted = listArray.includes(currentUser.uid || currentUser.id);
                            return (
                              <button
                                key={emoji}
                                onClick={() => handleToggleReaction(message.id, emoji)}
                                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10.5px] font-bold border transition-all duration-200 cursor-pointer ${
                                  hasReacted 
                                    ? 'bg-zinc-700/80 border-zinc-500/40 text-white backdrop-blur-md shadow-[inset_0_1px_1px_rgba(255,255,255,0.15),_0_3px_8px_rgba(0,0,0,0.2)] hover:bg-zinc-600/90' 
                                    : 'bg-white/5 border-white/5 text-slate-400 hover:bg-white/10 hover:border-white/10 hover:text-slate-200'
                                }`}
                              >
                                <span>{emoji}</span>
                                <span>{listArray.length}</span>
                              </button>
                            );
                          })}
                        </div>
                      )}

                      {/* Bubble Footer containing timing, star badge, and delivery tickers */}
                      <div className="flex items-center justify-end gap-1.5 mt-1 select-none shrink-0" style={{ direction: 'ltr' }}>
                        <span className="text-[10px] text-white/50 select-none">
                          {fmtChatTime(message.createdAt)}
                        </span>
                        {message.starredBy && message.starredBy.includes(currentUser.uid || currentUser.id) && (
                          <Star className="w-3 h-3 text-amber-500 fill-amber-500 select-none" />
                        )}
                        {isMe && renderReceipt(message)}
                      </div>
                    </div>
                    </>)}
                  </div>

                  {/* 3-dots button OUTSIDE of the bubble. Only shown on hover => Opens Portal context menu */}
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-150 flex items-center shrink-0">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        openPortalMenu(message, e.clientX || (window.innerWidth / 2), e.clientY || (window.innerHeight / 2), isMe, message.senderName || senderName);
                      }}
                      className="msg-options-trigger p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/15 transition-all cursor-pointer"
                      title="خيارات الرسالة"
                    >
                      <MoreVertical className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="py-12 px-6 text-center text-zinc-400 bg-white/5 rounded-2xl p-6 border border-white/10 max-w-sm mx-auto my-12 shadow-sm select-none">
            <svg className="w-10 h-10 text-sky-400 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
            <p className="text-xs font-bold text-white mb-1.5">Secure encrypted workspace</p>
            <p className="text-[11px] text-zinc-400 leading-relaxed">Send messaging, images, mock PDFs and instant high-fidelity WAV voice messages safely.</p>
          </div>
        )}

        {typingUsers && typingUsers.length > 0 && (
          <div className="flex items-center gap-2 w-fit ml-4 mt-2 mb-6 select-none animate-fade-in" style={{ direction: 'ltr' }}>
            <div className="shining-text flex items-center gap-2">
              <span>{typingUsers.join(', ')} is typing...</span>
            </div>
          </div>
        )}

        {recordingUsers && recordingUsers.length > 0 && (
          <div className="flex items-center gap-2 text-xs text-zinc-300 w-fit ml-2 select-none animate-fade-in mb-1.5" style={{ direction: 'ltr' }}>
            <div className="flex items-center gap-1.5 bg-white/5 px-3 py-2 rounded-xl border border-red-500/20 shadow-md">
              <Mic className="w-3.5 h-3.5 text-red-500 animate-[pulse_1s_infinite]" />
              <div className="flex items-center gap-1 shrink-0">
                <span className="w-1 h-1 bg-red-400 rounded-full animate-ping delay-[0ms]"></span>
                <span className="w-1 h-1 bg-red-400 rounded-full animate-ping delay-[200ms]"></span>
              </div>
            </div>
            <span className="font-bold text-[10px] text-red-400 bg-red-500/10 px-2.5 py-1 rounded-full border border-red-500/15">
              {recordingUsers.join(', ')} recording voice...
            </span>
          </div>
        )}
      </div>
    </div>
      <div className="chat-input-bar-container">
        
        {/* Sim-Attachments Queue banner */}
        {attachmentSim.length > 0 && (
          <div className="w-[calc(100%-32px)] max-w-[720px] mx-auto p-1.5 px-3 mb-2 bg-blue-500/10 text-blue-400 text-[11px] rounded-xl border border-blue-500/20 flex items-center justify-between font-bold select-none animate-fade-in" style={{ direction: 'ltr' }}>
            <span>📎 Attachment ready: {attachmentSim[0].name}</span>
            <button 
              onClick={() => setAttachmentSim([])} 
              className="text-red-400 text-xs font-bold hover:underline cursor-pointer"
            >
              [Cancel]
            </button>
          </div>
        )}

        {/* Quoted Reply draft banner */}
        <AnimatePresence>
          {replyingToMessage && (
            <motion.div 
              initial={{ opacity: 0, height: 0, y: 10 }}
              animate={{ opacity: 1, height: 'auto', y: 0 }}
              exit={{ opacity: 0, height: 0, y: 10 }}
              transition={{ type: 'spring', stiffness: 420, damping: 33 }}
              className="w-[calc(100%-32px)] max-w-[720px] mx-auto p-3 mb-2 px-4 bg-[#1e252a]/40 backdrop-blur-xl border border-white/5 rounded-2xl flex items-center justify-between select-none text-left overflow-hidden shadow-sm"
              style={{ direction: 'ltr' }}
            >
              <div className="flex-1 min-w-0 pr-1 border-l-2 border-zinc-500/40 pl-3">
                <span className="text-[10px] text-zinc-400 font-bold tracking-wide uppercase font-mono block select-none">
                  الرد على {replyingToMessage.senderName}
                </span>
                <p className="text-[11px] text-zinc-300 truncate max-w-md font-sans mt-0.5 font-light leading-snug">
                  {replyingToMessage.content || '[وسائط متعددة]'}
                </p>
              </div>
              <button 
                onClick={() => setReplyingToMessage(null)} 
                className="p-1 rounded-full text-zinc-500 hover:text-zinc-200 hover:bg-white/5 transition-all cursor-pointer ml-3 shrink-0"
                title="إلغاء الرد"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="input-box-wrapper">
          <motion.div 
            layout
            transition={{ type: "spring", stiffness: 400, damping: 32, mass: 0.8 }}
            className="input-box min-h-[50px] relative"
          >
            <AnimatePresence mode="wait">
              {isRecording ? (
                <motion.div
                  key="voice-recording-ui"
                  initial={{ opacity: 0, scale: 0.98, y: 5 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.98, y: -5 }}
                  transition={{ type: "spring", stiffness: 400, damping: 30 }}
                  className="w-full flex flex-col items-center justify-between p-2 min-h-[120px] relative overflow-hidden"
                  style={{ direction: 'ltr' }}
                >
                  {/* Background Ambient Glow */}
                  <div className="absolute inset-0 bg-gradient-to-b from-red-500/5 to-transparent pointer-events-none" />
                  
                  <div className="flex items-center justify-between w-full mb-4 relative z-10 px-2">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <motion.div 
                          animate={{ 
                            scale: isRecordingPaused ? 1 : [1, 1.4, 1],
                            opacity: isRecordingPaused ? 0.3 : [0.3, 0.6, 0.3]
                          }} 
                          transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
                          className="absolute -inset-1 rounded-full bg-red-500/40 blur-sm"
                        />
                        <div className={`w-2.5 h-2.5 rounded-full relative z-10 ${isRecordingPaused ? 'bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.5)]' : 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.5)]'} transition-colors duration-300`} />
                      </div>
                      <div className="flex flex-col">
                        <span className="text-white font-mono font-medium tracking-tight text-base leading-none">{formatTime(recordingTime)}</span>
                        <span className="text-[9px] uppercase tracking-widest text-white/40 font-bold mt-1">
                          {isRecordingPaused ? 'Recording Paused' : 'Live Capture'}
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={toggleRecordingPause}
                        className="w-9 h-9 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white hover:bg-white/15 active:scale-90 transition-all backdrop-blur-md shadow-inner"
                      >
                        {isRecordingPaused ? <Play size={16} className="fill-current ml-0.5" /> : <Pause size={16} className="fill-current" />}
                      </button>
                    </div>
                  </div>

                  <div className="flex-1 w-full flex items-center justify-center gap-[4px] h-14 px-4 relative z-10">
                    {voiceWaves.map((height, i) => (
                      <motion.div
                        key={i}
                        animate={{ 
                          height: isRecordingPaused ? Math.max(height * 0.3, 4) : height,
                          opacity: isRecordingPaused ? 0.4 : 1
                        }}
                        transition={{ type: "spring", stiffness: 300, damping: 20 }}
                        className={`w-1 rounded-full transition-colors duration-500 ${
                          isRecordingPaused 
                            ? 'bg-zinc-500' 
                            : i % 3 === 0 ? 'bg-blue-400' : i % 2 === 0 ? 'bg-indigo-400' : 'bg-sky-400'
                        } shadow-[0_0_10px_rgba(56,189,248,0.1)]`}
                      />
                    ))}
                  </div>

                  <div className="w-full flex items-center justify-between mt-4 pt-4 border-t border-white/10 relative z-10">
                    <button
                      type="button"
                      onClick={() => stopRecording(false)}
                      className="px-4 py-2 rounded-2xl text-[11px] font-bold text-white/40 hover:text-white hover:bg-white/5 transition-all uppercase tracking-widest"
                    >
                      Discard
                    </button>
                    
                    <div className="flex items-center gap-3">
                      {isRecordingPaused && previewAudioUrl && (
                         <button
                           type="button"
                           onClick={togglePreviewPlay}
                           className="flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 text-blue-400 border border-blue-400/20 text-[10px] font-bold uppercase tracking-widest hover:bg-blue-500/20 transition-all active:scale-95"
                         >
                           {isPreviewPlaying ? <Square size={12} className="fill-current" /> : <Play size={12} className="fill-current" />}
                           {isPreviewPlaying ? 'Stop' : 'Review'}
                         </button>
                      )}
                      <button
                        type="button"
                        onClick={() => stopRecording(true)}
                        className="send-btn group !w-12 !h-12 shadow-[0_8px_20px_rgba(255,255,255,0.05)]"
                      >
                        <svg width="13" height="14" viewBox="0 0 13 14" fill="none" className="group-hover:-translate-y-0.5 transition-transform">
                          <line x1="6.5" y1="13" x2="6.5" y2="3" stroke="white" strokeWidth="1.8" strokeLinecap="round"/>
                          <polyline points="2.5,7 6.5,2.5 10.5,7" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      </button>
                    </div>
                  </div>
                </motion.div>
              ) : showToolsComingSoon ? (
                  <motion.div
                    key="tools-coming-soon"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ type: "spring", stiffness: 400, damping: 30 }}
                    className="w-full py-8 flex flex-col items-center justify-center text-center bg-white/5 rounded-2xl border border-dashed border-white/10"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-zinc-800 flex items-center justify-center mb-3 shadow-inner">
                      <Clock className="text-zinc-500 animate-spin-slow" size={24} />
                    </div>
                    <h4 className="text-sm font-black text-white tracking-widest uppercase mb-1">Coming Soon</h4>
                    <p className="text-[10px] text-zinc-500 font-bold max-w-[200px] leading-relaxed">
                      Advanced workspace tools are currently under deployment. Stay tuned!
                    </p>
                    <button 
                      onClick={() => setShowToolsComingSoon(false)}
                      className="mt-4 px-5 py-2 bg-white/5 rounded-full text-[10px] font-black text-white/40 hover:text-white hover:bg-white/10 transition-all border border-white/5 uppercase tracking-widest"
                    >
                      Dismiss
                    </button>
                  </motion.div>
                ) : isChannelSubscriber ? (
                  <motion.div
                    key="channel-broadcast-notice"
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -6 }}
                    transition={{ type: "spring", stiffness: 400, damping: 32 }}
                    className="w-full py-3.5 px-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/25 flex items-center gap-3 select-none"
                    style={{ direction: 'rtl' }}
                  >
                    <Megaphone className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span className="text-xs font-bold text-emerald-300 flex-1">
                      📢 قناة بث — المشرفون فقط ينشرون
                    </span>
                    <button
                      type="button"
                      onClick={async () => {
                        try {
                          const res = await fetch(`/api/chats/${chatId}/leave`, {
                            method: 'POST',
                            headers: { Authorization: `Bearer ${accessToken}` },
                          });
                          if (res.ok) {
                            if ((window as any).showGlobalToast) {
                              (window as any).showGlobalToast('تمت مغادرة القناة.', 'success');
                            }
                          } else {
                            const d = await res.json().catch(() => ({}));
                            if ((window as any).showGlobalToast) {
                              (window as any).showGlobalToast(d.error || 'تعذر مغادرة القناة.', 'error');
                            }
                          }
                        } catch {
                          if ((window as any).showGlobalToast) {
                            (window as any).showGlobalToast('خطأ في الاتصال.', 'error');
                          }
                        }
                      }}
                      className="text-[11px] font-bold text-rose-300 hover:text-rose-200 px-2.5 py-1 rounded-lg bg-rose-500/10 border border-rose-500/20 shrink-0 transition-colors"
                    >
                      مغادرة القناة
                    </button>
                  </motion.div>
                ) : (
                  <motion.form
                    key="normal-form"
                    onSubmit={handleSend} 
                    layout 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ type: "spring", stiffness: 400, damping: 34, mass: 0.8 }}
                    className="w-full flex flex-col pt-1"
                  >
                    {/* Hidden File Inputs for real actions */}
                    <input 
                      type="file" 
                      ref={attachmentFileInputRef}
                      accept="image/*,video/mp4,video/webm,video/quicktime"
                      className="hidden" 
                      onChange={async (e) => {
                        if (e.target.files && e.target.files[0]) {
                          const file = e.target.files[0];
                          if (file.type.startsWith('video/')) {
                            // Upload video directly
                            try {
                              setIsUploadingImage(true);
                              // Encrypt-at-source (F1/P0): in E2EE chats the video bytes
                              // NEVER hit the network in plaintext — encrypt locally, upload
                              // ONLY the opaque 'enc.bin' ciphertext; payload rides in-memory
                              // to App's send wrap. Renders via E2eeMedia on both sides.
                              if (e2eeActive) {
                                const encBytes = new Uint8Array(await file.arrayBuffer());
                                const encAtt = await encryptAndUploadAttachment(
                                  encBytes,
                                  file.type || 'application/octet-stream',
                                  file.name || 'video',
                                  viewOnceArmed ? { viewOnce: true } : undefined
                                );
                                onSendMessage('', [encAtt], null, []);
                                if (viewOnceArmed) setViewOnceArmed(false);
                                return;
                              }
                              // Direct upload to the user's storage (Google Drive or presigned object storage)
                              const uploaded = await uploadMediaFile(file, file.name);
                              const attachment = {
                                name: uploaded.name,
                                size: uploaded.size,
                                mimeType: uploaded.mimeType,
                                url: uploaded.url,
                              ...(viewOnceArmed ? { meta: { viewOnce: true } } : {})
                              };
                              // Raw video file passed (index-aligned) for the E2EE send wrap.
                              onSendMessage('', [attachment], null, [file]);
  if (viewOnceArmed) setViewOnceArmed(false);
                            } catch (err: any) {
                              console.error('[VideoUpload]', err);
                              if (err instanceof StorageNotLinkedError) {
                                startGdriveLink();
                                return;
                              }
                              if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                                (window as any).showGlobalToast(err?.message || 'فشل رفع الفيديو', 'error');
                              }
                            } finally {
                              setIsUploadingImage(false);
                            }
                          } else {
                            setEditingImageFile(file);
                          }
                          setShowAttachmentMenu(false);
                        }
                        e.target.value = '';
                      }}
                    />
                    <input 
                      type="file" 
                      ref={cameraInputRef}
                      accept="image/*" 
                      capture="environment"
                      className="hidden" 
                      onChange={(e) => {
                        if (e.target.files && e.target.files[0]) {
                          setEditingImageFile(e.target.files[0]);
                          setShowAttachmentMenu(false);
                        }
                        e.target.value = '';
                      }}
                    />
                    <input 
                      type="file" 
                      ref={docInputRef}
                      accept=".pdf,.txt,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.zip,application/pdf,text/plain,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/zip"
                      className="hidden"
                      onChange={(e) => {
                        if (e.target.files && e.target.files[0]) {
                          handleRealFileAttachment(e.target.files[0]);
                        }
                        e.target.value = '';
                      }}
                    />
                    <input 
                      type="file" 
                      ref={audioInputRef}
                      accept="audio/*"
                      className="hidden"
                      onChange={(e) => {
                        if (e.target.files && e.target.files[0]) {
                          handleRealFileAttachment(e.target.files[0]);
                        }
                        e.target.value = '';
                      }}
                    />

                    {/* Smooth fluid height wrapper for inner state elements */}
                    <div className="w-full relative flex flex-col justify-start">
                      {/* Schedule bar (Mission B) — armed chip or datetime picker above the composer */}
                      {(showScheduleBar || scheduleArmed) && (
                        <div
                          className="w-full mb-2 p-2.5 bg-[#0b141a]/80 border border-white/10 rounded-xl flex items-center gap-2 flex-wrap"
                          style={{ direction: 'rtl' }}
                        >
                          {scheduleArmed ? (
                            <>
                              <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                              <span className="flex-1 min-w-0 text-[11px] font-bold text-amber-300 truncate">
                                ⏰ الإرسال مجدول لـ {formatScheduleLabel(scheduleAt)}
                              </span>
                              <button
                                type="button"
                                onClick={handleCancelSchedule}
                                className="shrink-0 px-2.5 py-1 rounded-full bg-red-500/15 text-red-300 hover:bg-red-500/25 text-[10px] font-bold transition-colors cursor-pointer"
                              >
                                إلغاء الجدولة
                              </button>
                            </>
                          ) : (
                            <>
                              <Clock className="w-4 h-4 text-sky-400 shrink-0" />
                              <input
                                type="datetime-local"
                                value={scheduleAt}
                                min={toLocalInputValue(new Date(Date.now() + SCHEDULE_MIN_MS))}
                                onChange={(e) => setScheduleAt(e.target.value)}
                                className="flex-1 min-w-[150px] h-8 px-2 rounded-lg bg-black/40 border border-white/10 text-[11px] text-white/90 outline-none focus:border-sky-400/50 transition-colors"
                                style={{ colorScheme: 'dark' }}
                              />
                              <button
                                type="button"
                                onClick={handleConfirmSchedule}
                                disabled={!scheduleAt}
                                className="shrink-0 px-3 py-1 rounded-full bg-sky-500/20 text-sky-300 hover:bg-sky-500/30 disabled:opacity-40 disabled:cursor-not-allowed text-[10px] font-bold transition-colors cursor-pointer"
                              >
                                تأكيد
                              </button>
                              <button
                                type="button"
                                onClick={handleCancelSchedule}
                                className="shrink-0 px-3 py-1 rounded-full bg-white/5 text-white/60 hover:bg-white/10 text-[10px] font-bold transition-colors cursor-pointer"
                              >
                                إلغاء
                              </button>
                            </>
                          )}
                        </div>
                      )}
                      {/* Textarea state container */}
                      <motion.div
                        initial={false}
                        animate={{
                          height: !showAttachmentMenu ? "auto" : 0,
                          opacity: !showAttachmentMenu ? 1 : 0,
                          pointerEvents: !showAttachmentMenu ? "auto" : "none",
                          marginBottom: !showAttachmentMenu ? 8 : 0
                        }}
                        transition={{ type: "spring", stiffness: 400, damping: 32, mass: 0.8 }}
                        className="w-full flex overflow-hidden origin-top relative"
                      >
                        {isMuted && (
                          <div
                            className="absolute inset-0 z-20 cursor-not-allowed"
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              if ((window as any).showGlobalToast) {
                                (window as any).showGlobalToast('تم كتم حسابك من إرسال الرسائل حالياً.', 'error');
                              }
                            }}
                          />
                        )}
                        {/* Formatting toolbar (WhatsApp parity) — inserts markers around the
                            CURRENT textarea selection; raw markers stay stored in the text. */}
                        <div className="flex items-center gap-1.5 mb-1.5 px-1 flex-wrap" style={{ direction: 'rtl' }}>
                          {[
                            { id: 'bold', label: '*بولد*', icon: Bold, marker: '*' },
                            { id: 'italic', label: '_مائل_', icon: Italic, marker: '_' },
                            { id: 'strike', label: '~شطب~', icon: Strikethrough, marker: '~' },
                            { id: 'mono', label: '```كود```', icon: Code, marker: '```' },
                          ].map((f) => {
                            const FIcon = f.icon;
                            return (
                              <button
                                key={f.id}
                                type="button"
                                disabled={isMuted}
                                onMouseDown={(e) => e.preventDefault()}
                                onClick={() => insertFormatting(f.marker)}
                                title={`تنسيق ${f.label}`}
                                className="flex items-center gap-1 px-2 py-1 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 hover:border-emerald-400/30 text-zinc-300 hover:text-emerald-300 disabled:opacity-40 disabled:cursor-not-allowed transition-all cursor-pointer"
                              >
                                <FIcon className="w-3.5 h-3.5" />
                                <span className="text-[10px] font-bold font-sans">{f.label}</span>
                              </button>
                            );
                          })}
                        </div>
                        <textarea
                          ref={composerTextareaRef}
                          className="input-textarea"
                          required={attachmentSim.length === 0}
                          value={inputText}
                          onChange={handleInputChange}
                          disabled={isMuted}
                          onKeyDown={(e) => {
                            // chatSettings.enterToSend: Enter sends when enabled (default);
                            // when disabled, Enter inserts a newline and sending is button-only.
                            const enterSends = currentUser?.chatSettings?.enterToSend !== false;
                            if (e.key === 'Enter' && !e.shiftKey && enterSends) {
                              e.preventDefault();
                              handleSend(e);
                            }
                          }}
                          placeholder={isMuted ? "تم تقييد حسابك من إرسال الرسائل حالياً." : (isChannelAdmin ? "النشر إلى القناة…" : "Type a message...")}
                          style={{ 
                            direction: 'ltr', 
                            textAlign: 'left' 
                            }}
                          rows={2}
                          enterKeyHint="send"
                        />
                      </motion.div>

                        <motion.div
                          initial={false}
                          animate={{
                            height: showAttachmentMenu ? 88 : 0,
                            opacity: showAttachmentMenu ? 1 : 0,
                            pointerEvents: showAttachmentMenu ? "auto" : "none",
                            marginBottom: showAttachmentMenu ? 8 : 0
                          }}
                          transition={{ type: "spring", stiffness: 400, damping: 32, mass: 0.8 }}
                          className="w-full flex items-center justify-start gap-4 overflow-x-auto scrollbar-none py-1 px-1 origin-bottom"
                          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
                        >
                        {[
                          { id: 'photos', label: 'Photos', icon: ImageIcon, gradient: 'from-[#007AFF] to-[#0056C6]', action: () => attachmentFileInputRef.current?.click() },
                          { id: 'camera', label: 'Camera', icon: Camera, gradient: 'from-[#8E8E93] to-[#636366]', action: () => setShowInAppCamera(true) },
                          { id: 'docs', label: 'Document', icon: FileText, gradient: 'from-[#FF9500] to-[#C67300]', action: () => docInputRef.current?.click() },
                          { id: 'audio', label: 'Audio', icon: Music, gradient: 'from-[#FF2D55] to-[#D0003C]', action: () => audioInputRef.current?.click() },
                          { id: 'location', label: 'Location', icon: MapPin, gradient: 'from-[#34C759] to-[#1E9E3B]', action: () => handleShareLocation() },
                          { id: 'contact', label: 'Contact', icon: User, gradient: 'from-[#5856D6] to-[#3B3A98]', action: () => { setShowAttachmentMenu(false); setShowContactPicker(true); } },
                          { id: 'stickers', label: 'ملصقات', icon: Sticker, gradient: 'from-[#D946EF] to-[#9D174D]', action: () => { setShowAttachmentMenu(false); setShowStickerPanel(true); } },
                          { id: 'viewonce', label: 'رؤية واحدة', icon: Eye, gradient: viewOnceArmed ? 'from-amber-400 to-amber-600' : 'from-[#F59E0B] to-[#B45309]', action: () => setViewOnceArmed(!viewOnceArmed) },
                          { id: 'poll', label: 'تصويت', icon: BarChart2, gradient: 'from-[#10B981] to-[#047857]', action: () => { setShowAttachmentMenu(false); setShowPollComposer(true); } },
                          { id: 'schedule', label: 'جدولة', icon: Clock, gradient: scheduleArmed ? 'from-amber-400 to-amber-600' : 'from-[#0EA5E9] to-[#0369A1]', action: () => { setShowAttachmentMenu(false); if (!scheduleArmed) setShowScheduleBar(true); } },
                        ].map((act) => {
          const IconComp = act.icon;
          return (
            <motion.button
              key={act.id}
                              type="button"
                              onClick={act.action}
                              whileHover={{ scale: 1.08, y: -3 }}
                              whileTap={{ scale: 0.94 }}
                              className="flex flex-col items-center justify-center shrink-0 w-16 gap-1.5 cursor-pointer group outline-none bg-transparent border-none p-0 focus:outline-none"
                            >
                              <div className={`w-12 h-12 rounded-[14px] flex items-center justify-center relative bg-gradient-to-br ${act.gradient} shadow-[0_5px_15px_rgba(0,0,0,0.35),inset_0_1px_1px_rgba(255,255,255,0.35)] transition-all duration-300 before:absolute before:inset-0 before:rounded-[14px] before:bg-white/10 before:opacity-0 group-hover:before:opacity-100`}>
                                <div className="absolute inset-x-0 top-0 h-[45%] bg-white/20 rounded-t-[13px] opacity-40 pointer-events-none" />
                                <IconComp className="w-5.5 h-5.5 text-white filter drop-shadow-[0_1px_2px_rgba(0,0,0,0.3)] transition-transform duration-300 group-hover:scale-105" />
                              </div>
                              <span className="text-[10px] font-bold text-white/40 tracking-wide transition-colors duration-300 group-hover:text-white/80 select-none font-sans">
                                {act.label}
                              </span>
                            </motion.button>
                          );
                        })}
                      </motion.div>
                    </div>
                    
                    <div className="controls-row">
                      {/* Plus Circle Button - Animates and Rotates smoothly */}
                      <div className="relative shrink-0 flex items-center">
                        <motion.button 
                          type="button" 
                          className="ctrl-circle" 
                          disabled={isMuted}
                          onClick={() => {
                            if (isMuted) return;
                            setShowAttachmentMenu(!showAttachmentMenu);
                            setShowEmojiPicker(false);
                            setShowToolsComingSoon(false);
                          }}
                          animate={{ rotate: showAttachmentMenu ? 135 : 0 }}
                          transition={{ type: "spring", stiffness: 350, damping: 20 }}
                        >
                          <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
                            <line x1="6.5" y1="1" x2="6.5" y2="12" stroke="white" strokeWidth="1.6" strokeLinecap="round"/>
                            <line x1="1" y1="6.5" x2="12" y2="6.5" stroke="white" strokeWidth="1.6" strokeLinecap="round"/>
                          </svg>
                        </motion.button>
                      </div>

                      {/* Emoji Trigger Button */}
                      <AnimatePresence>
                        {!showAttachmentMenu && (
                          <motion.div
                            initial={{ opacity: 0, scale: 0.8, marginLeft: 0 }}
                            animate={{ opacity: 1, scale: 1, marginLeft: 7 }}
                            exit={{ opacity: 0, scale: 0.8, marginLeft: 0 }}
                            transition={{ type: "spring", stiffness: 380, damping: 28 }}
                            className="relative shrink-0 flex items-center"
                          >
                            <button 
                              type="button" 
                              className={`ctrl-circle emoji-trigger-btn ${showEmojiPicker ? 'bg-blue-500 shadow-lg' : ''}`}
                              disabled={isMuted}
                              onClick={() => {
                                if (isMuted) return;
                                setShowEmojiPicker(!showEmojiPicker);
                                setShowAttachmentMenu(false);
                                setShowToolsComingSoon(false);
                              }}
                            >
                              <Smile className={`w-4.5 h-4.5 ${showEmojiPicker ? 'text-white' : 'text-white/70'}`} />
                            </button>
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {/* Tools / Emoji Pill Button */}
                      <AnimatePresence>
                        {!showAttachmentMenu && (
                          <motion.div 
                            initial={{ opacity: 0, scale: 0.8, width: 0, marginRight: 0 }}
                            animate={{ opacity: 1, scale: 1, width: 'auto', marginRight: 7 }}
                            exit={{ opacity: 0, scale: 0.8, width: 0, marginRight: 0 }}
                            transition={{ type: "spring", stiffness: 380, damping: 28 }}
                            className="relative shrink-0 flex items-center overflow-hidden"
                          >
                            <button 
                              type="button" 
                              className="ctrl-pill" 
                              onClick={() => {
                                setShowToolsComingSoon(true);
                                setShowAttachmentMenu(false);
                                setShowEmojiPicker(false);
                              }}
                            >
                              <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                                <line x1="1.5" y1="4" x2="8.5" y2="4" stroke="white" strokeWidth="1.3" strokeLinecap="round" opacity="0.9"/>
                                <circle cx="11" cy="4" r="1.8" stroke="white" strokeWidth="1.3" fill="none" opacity="0.9"/>
                                <line x1="5.5" y1="10" x2="12.5" y2="10" stroke="white" strokeWidth="1.3" strokeLinecap="round" opacity="0.9"/>
                                <circle cx="3"  cy="10" r="1.8" stroke="white" strokeWidth="1.3" fill="none" opacity="0.9"/>
                              </svg>
                              <span className="ctrl-pill-label">Tools</span>
                            </button>
                          </motion.div>
                        )}
                      </AnimatePresence>

                      <div className="spacer"></div>

                      {/* Voice Pill Button */}
                      <AnimatePresence>
                        {!showAttachmentMenu && (
                          <motion.button 
                            type="button" 
                            initial={{ opacity: 0, scale: 0.8, width: 0, marginLeft: 0 }}
                            animate={{ opacity: 1, scale: 1, width: 'auto', marginLeft: 7 }}
                            exit={{ opacity: 0, scale: 0.8, width: 0, marginLeft: 0 }}
                            transition={{ type: "spring", stiffness: 380, damping: 28 }}
                            className="ctrl-pill flex items-center overflow-hidden shrink-0" 
                            disabled={isMuted}
                            onClick={() => {
                              if (isMuted) return;
                              startRecording();
                              setShowAttachmentMenu(false);
                              setShowEmojiPicker(false);
                            }}
                          >
                            <svg width="20" height="14" viewBox="0 0 20 14" fill="none">
                              <rect x="0"    y="6"   width="2.2" height="3.5" rx="1.1" fill="white" opacity="0.75"/>
                              <rect x="3.5"  y="4"   width="2.2" height="8"   rx="1.1" fill="white" opacity="0.9"/>
                              <rect x="7"    y="5.5" width="2.2" height="4.5" rx="1.1" fill="white" opacity="0.82"/>
                              <rect x="10.5" y="1"   width="2.2" height="12"  rx="1.1" fill="white" opacity="0.9"/>
                              <rect x="14"   y="3.5" width="2.2" height="7.5" rx="1.1" fill="white" opacity="0.82"/>
                              <rect x="17.5" y="6"   width="2.2" height="3.5" rx="1.1" fill="white" opacity="0.65"/>
                            </svg>
                            <span className="ctrl-pill-label">Voice</span>
                          </motion.button>
                        )}
                      </AnimatePresence>

                      {/* Send Button */}
                      <button type="submit" className="send-btn" id="send-msg-btn" disabled={isMuted || (showAttachmentMenu && inputText.trim() === '')}>
                        <svg width="13" height="14" viewBox="0 0 13 14" fill="none">
                          <line x1="6.5" y1="13" x2="6.5" y2="3" stroke="white" strokeWidth="1.8" strokeLinecap="round"/>
                          <polyline points="2.5,7 6.5,2.5 10.5,7" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      </button>
                    </div>

                    {/* Emoji Picker Popup positioned relative to input-box */}
                    {showEmojiPicker && (
                      <div className="emoji-picker-container absolute bottom-12 left-10 bg-[#091014] border border-white/10 rounded-2xl shadow-2xl p-3 w-72 sm:w-80 h-64 flex flex-col z-50 text-left animate-scale-in" style={{ direction: 'ltr' }}>
                        <div className="text-xs font-black text-zinc-300 mb-2 pb-1 border-b border-white/5 flex items-center justify-between">
                          <span>Emojis</span>
                          <button
                            type="button"
                            onClick={() => setShowEmojiPicker(false)}
                            className="text-xs text-red-500 hover:text-red-400 font-bold"
                          >
                            Close
                          </button>
                        </div>
                        <div className="flex-1 overflow-y-auto pr-1 space-y-3">
                          {EMOJI_CATEGORIES.map((category) => (
                            <div key={category.name}>
                              <span className="text-[10px] text-sky-400 font-bold block mb-1">{category.name}</span>
                              <div className="grid grid-cols-7 sm:grid-cols-8 gap-1">
                                {category.emojis.map((emoji) => (
                                  <button
                                    key={emoji}
                                    type="button"
                                    onClick={() => {
                                      setInputText(prev => prev + emoji);
                                      if (!isCurrentlyTypingLocalRef.current) {
                                        isCurrentlyTypingLocalRef.current = true;
                                        onEmitTyping(true);
                                      }
                                      if (typingTimerRef.current) clearTimeout(typingTimerRef.current);
                                      typingTimerRef.current = setTimeout(() => {
                                        isCurrentlyTypingLocalRef.current = false;
                                        onEmitTyping(false);
                                      }, 2000);
                                    }}
                                    className="text-lg hover:bg-white/10 p-1 rounded transition-all active:scale-90 flex items-center justify-center cursor-pointer"
                                  >
                                    {emoji}
                                  </button>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Poll Composer Popup (WhatsApp parity) */}
                    {showPollComposer && (
                      <div className="absolute bottom-12 left-2 right-2 sm:left-10 sm:right-auto bg-[#091014] border border-white/10 rounded-2xl shadow-2xl p-4 w-full sm:w-96 flex flex-col z-50 text-right animate-scale-in max-h-[440px]" style={{ direction: 'rtl' }}>
                        <div className="text-xs font-black text-zinc-300 mb-3 pb-2 border-b border-white/5 flex items-center justify-between">
                          <span className="flex items-center gap-1.5">
                            <BarChart2 className="w-4 h-4 text-emerald-400" />
                            تصويت جديد
                          </span>
                          <button
                            type="button"
                            onClick={() => setShowPollComposer(false)}
                            className="text-xs text-red-500 hover:text-red-400 font-bold cursor-pointer"
                          >
                            إغلاق
                          </button>
                        </div>
                        <div className="flex-1 overflow-y-auto pl-1 space-y-2.5 min-h-0">
                          <input
                            type="text"
                            value={pollQuestion}
                            onChange={(e) => setPollQuestion(e.target.value)}
                            placeholder="اكتب سؤال التصويت..."
                            maxLength={200}
                            className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 text-[13px] text-white placeholder-white/30 outline-none focus:border-emerald-400/50 transition-colors"
                          />
                          {pollOptions.map((opt, idx) => (
                            <div key={idx} className="flex items-center gap-2">
                              <input
                                type="text"
                                value={opt}
                                onChange={(e) => setPollOptions(prev => prev.map((o, i) => i === idx ? e.target.value : o))}
                                placeholder={`الخيار ${idx + 1}`}
                                maxLength={100}
                                className="flex-1 bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-[12.5px] text-white placeholder-white/30 outline-none focus:border-emerald-400/50 transition-colors min-w-0"
                              />
                              <button
                                type="button"
                                disabled={pollOptions.length <= 2}
                                onClick={() => setPollOptions(prev => prev.filter((_, i) => i !== idx))}
                                className={`p-2 rounded-lg border border-white/10 shrink-0 transition-all cursor-pointer ${pollOptions.length <= 2 ? 'opacity-30 cursor-not-allowed text-white/40' : 'text-red-400 hover:bg-red-500/10 hover:border-red-400/30'}`}
                                title="حذف الخيار"
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ))}
                          {pollOptions.length < 10 && (
                            <button
                              type="button"
                              onClick={() => setPollOptions(prev => [...prev, ''])}
                              className="w-full py-2 rounded-xl border border-dashed border-white/15 text-[11px] font-bold text-emerald-400 hover:bg-emerald-500/10 hover:border-emerald-400/40 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                            >
                              <Plus className="w-3.5 h-3.5" />
                              إضافة خيار ({pollOptions.length}/10)
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => setPollAllowMultiple(prev => !prev)}
                            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl border transition-all cursor-pointer ${pollAllowMultiple ? 'border-emerald-400/40 bg-emerald-500/10' : 'border-white/10 bg-white/5 hover:bg-white/10'}`}
                          >
                            <span className="text-[12px] font-bold text-white/80">السماح باختيار أكثر من خيار</span>
                            <span className={`w-9 h-5 rounded-full relative transition-colors shrink-0 ${pollAllowMultiple ? 'bg-emerald-500' : 'bg-white/20'}`}>
                              <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all ${pollAllowMultiple ? 'right-0.5' : 'right-[18px]'}`} />
                            </span>
                          </button>
                        </div>
                        <button
                          type="button"
                          onClick={submitPoll}
                          disabled={!pollQuestion.trim() || pollOptions.map(o => o.trim()).filter(Boolean).length < 2}
                          className="mt-3 w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:cursor-not-allowed text-white text-[13px] font-black transition-all active:scale-[0.98] flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <BarChart2 className="w-4 h-4" />
                          إرسال التصويت
                        </button>
                      </div>
                    )}
                  </motion.form>
                )}
              </AnimatePresence>
            </motion.div>
          </div>
        </div>
      {editingImageFile && (
        <ImageEditor
          file={editingImageFile}
          onCancel={() => setEditingImageFile(null)}
          onSend={handleImageEditorSend}
        />
      )}

      {isUploadingImage && (
        <div className="fixed inset-0 z-[250] bg-black/60 backdrop-blur-[40px] flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="p-10 rounded-[32px] bg-black/40 border border-white/10 shadow-[0_20px_80px_rgba(0,0,0,0.8)] backdrop-blur-2xl flex flex-col items-center justify-center text-center max-w-sm w-full animate-in zoom-in-95 duration-400 ease-[cubic-bezier(0.23,1,0.32,1)] relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-t from-white/5 to-transparent pointer-events-none" />
            <div className="relative">
               <div className="w-16 h-16 rounded-full border border-white/10 flex items-center justify-center relative bg-white/5 backdrop-blur-md mb-6 shadow-inner">
                  <div className="absolute inset-0 border-t-2 border-white rounded-full animate-spin"></div>
                  <Loader2 className="w-8 h-8 text-white animate-pulse" />
               </div>
            </div>
            <span className="text-sm font-black text-white tracking-widest uppercase drop-shadow-md">Sending...</span>
          </div>
        </div>
      )}

      {/* Media gallery side panel (الوسائط): images grid / files list */}
      {showMediaGallery && (
        <div
          className="fixed inset-0 z-[150] bg-black/50 backdrop-blur-sm animate-in fade-in duration-200"
          onClick={() => setShowMediaGallery(false)}
        >
          <div
            className="absolute top-0 right-0 h-full w-full max-w-md bg-[#0b1116]/95 border-l border-white/10 shadow-2xl flex flex-col animate-in slide-in-from-right duration-300"
            onClick={(e) => e.stopPropagation()}
            style={{ direction: 'rtl' }}
          >
            {/* Panel header */}
            <div className="flex items-center justify-between px-4 py-3.5 border-b border-white/10 shrink-0">
              <div className="flex items-center gap-2">
                <ImageIcon className="w-5 h-5 text-emerald-400" />
                <span className="text-sm font-black text-white">الوسائط</span>
              </div>
              <button
                onClick={() => setShowMediaGallery(false)}
                className="w-8 h-8 flex items-center justify-center rounded-full bg-white/5 hover:bg-white/10 text-zinc-300 active:scale-90 transition-all cursor-pointer"
                title="إغلاق"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Tabs: الصور | الملفات */}
            <div className="flex gap-2 px-4 py-3 border-b border-white/5 shrink-0">
              <button
                onClick={() => setMediaTab('image')}
                className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer border ${
                  mediaTab === 'image'
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                    : 'bg-white/5 text-zinc-400 border-white/10 hover:text-zinc-200'
                }`}
              >
                الصور
              </button>
              <button
                onClick={() => setMediaTab('file')}
                className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer border ${
                  mediaTab === 'file'
                    ? 'bg-sky-500/20 text-sky-300 border-sky-500/30'
                    : 'bg-white/5 text-zinc-400 border-white/10 hover:text-zinc-200'
                }`}
              >
                الملفات
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto">
              {isLoadingMedia ? (
                <div className="py-16 flex flex-col items-center justify-center gap-3">
                  <Loader2 className="w-6 h-6 text-zinc-400 animate-spin" />
                  <span className="text-xs text-zinc-500">جارٍ التحميل...</span>
                </div>
              ) : mediaItems.length === 0 ? (
                <div className="py-16 px-6 text-center flex flex-col items-center justify-center gap-3">
                  <div className="p-4 rounded-full bg-white/5">
                    <ImageIcon className="w-7 h-7 text-zinc-500" />
                  </div>
                  <p className="text-xs text-zinc-500">لا توجد {mediaTab === 'image' ? 'صور' : 'ملفات'} في هذه المحادثة بعد</p>
                </div>
              ) : mediaTab === 'image' ? (
                <div className="grid grid-cols-3 gap-1.5 p-3">
                  {mediaItems.map((it) => (
                    <button
                      key={it.id}
                      onClick={() => setFullScreenImage({ url: resolveMediaUrl(it.url), name: it.name })}
                      className="aspect-square rounded-xl overflow-hidden bg-white/5 border border-white/5 hover:border-emerald-500/40 active:scale-95 transition-all cursor-pointer"
                      title={it.name}
                    >
                      <img
                        src={resolveMediaUrl(it.url)}
                        alt={it.name}
                        loading="lazy"
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </button>
                  ))}
                </div>
              ) : (
                <div className="p-3 space-y-2">
                  {mediaItems.map((it) => (
                    <a
                      key={it.id}
                      href={it.name === 'enc.bin' ? undefined : resolveMediaUrl(it.url)}
                      target={it.name === 'enc.bin' ? undefined : '_blank'}
                      rel="noopener noreferrer"
                      className={`flex items-center gap-3 p-3 rounded-2xl border transition-all ${
                        it.name === 'enc.bin'
                          ? 'bg-white/5 border-white/5 opacity-70'
                          : 'bg-white/5 hover:bg-white/10 border-white/5'
                      }`}
                    >
                      {it.name === 'enc.bin' ? (
                        <Lock className="w-5 h-5 text-slate-500 shrink-0" />
                      ) : (
                        <FileText className="w-5 h-5 text-sky-400 shrink-0" />
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-white truncate">
                          {/* E2EE guard: opaque ciphertext blobs are not downloadable */}
                          {it.name === 'enc.bin' ? 'مرفق مشفر' : it.name}
                        </p>
                        <p className="text-[10px] text-zinc-500 mt-0.5">
                          {it.name === 'enc.bin' ? new Date(it.createdAt).toLocaleDateString() : `${formatFileSize(it.size)} · ${new Date(it.createdAt).toLocaleDateString()}`}
                        </p>
                      </div>
                      {it.name !== 'enc.bin' && <Download className="w-4 h-4 text-zinc-500 shrink-0" />}
                    </a>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {fullScreenImage && (
        <div className="fixed inset-0 z-[200] bg-black/80 flex items-center justify-center p-4 flex-col backdrop-blur-[40px] transition-all animate-in fade-in duration-400 select-none">
          {/* Glass header toolbar top - iOS style floating bar */}
          <div className="absolute top-0 left-0 right-0 h-24 pt-safe-top bg-gradient-to-b from-black/60 to-transparent z-50 flex items-start justify-between px-6 pt-6">
            <button 
              onClick={() => setFullScreenImage(null)} 
              className="w-10 h-10 flex items-center justify-center rounded-full bg-white/10 border border-white/10 backdrop-blur-md text-white shadow-lg active:scale-90 transition-all hover:bg-white/20" 
              title="Close image"
            >
              <X className="w-5 h-5 cursor-pointer" />
            </button>

            <div className="flex bg-black/40 border border-white/10 rounded-full p-1 backdrop-blur-xl shadow-xl">
              <a 
                href={fullScreenImage.url} 
                download={fullScreenImage.name || 'image.png'} 
                className="w-10 h-10 flex items-center justify-center hover:bg-white/10 active:scale-90 rounded-full transition-all text-white/70 hover:text-white" 
                title="Download original image"
                target="_blank"
                rel="noreferrer"
              >
                <Download className="w-4 h-4 pointer-events-none" />
              </a>
              <a
                href={fullScreenImage.url}
                target="_blank"
                rel="noreferrer"
                className="w-10 h-10 flex items-center justify-center hover:bg-white/10 active:scale-90 rounded-full transition-all text-white/70 hover:text-white"
                title="Open image in new window"
              >
                <Maximize2 className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Centered Image with frosted depth */}
          <div className="relative w-full h-full max-w-6xl max-h-[85vh] flex items-center justify-center animate-in zoom-in-95 duration-400 ease-[cubic-bezier(0.23,1,0.32,1)] pt-10">
            <img 
              src={fullScreenImage.url} 
              alt={fullScreenImage.name || 'Lightbox View'} 
              className="max-w-full max-h-[80vh] object-contain shadow-[0_30px_90px_rgba(0,0,0,0.8)] rounded-[24px] border border-white/10 select-all" 
              draggable={false}
            />
          </div>
        </div>
      )}

      {/* Real in-app camera modal overlay - Direct hardware access */}
      <AnimatePresence>
        {showInAppCamera && (
          <CameraView 
            onClose={() => setShowInAppCamera(false)}
            onCapture={(blob) => {
              const file = new File([blob], `camera_capture_${Date.now()}.jpg`, { type: 'image/jpeg' });
              setEditingImageFile(file);
              setShowInAppCamera(false);
              setShowAttachmentMenu(false);
            }}
          />
        )}
      </AnimatePresence>

      {/* ========================================== */}
      {/* 2. Brand New Portaled Context Menu & Reactions */}
      {/* ========================================== */}
      {portalMenu && createPortal(
        <div 
          className="portal-context-menu-wrapper fixed inset-0 z-[300] select-none text-zinc-100 font-sans" 
          style={{ direction: 'rtl' }}
        >
          {/* Backdrop blur click target */}
          <div 
            className="absolute inset-0 bg-black/25 backdrop-blur-[2px] transition-all" 
            onClick={() => setPortalMenu(null)}
          />

          {/* Context Bubble container positioned intelligently */}
          <div 
            className="absolute flex flex-col gap-2 w-60 z-50 select-text" 
            style={{
              left: `${portalCoordinates.left}px`,
              top: `${portalCoordinates.top}px`,
            }}
          >
            {/* Emojis Bubble (WhatsApp/Telegram Style bubble) */}
            {portalMenu.message.state !== 'deleted' && (
              <motion.div 
                initial={{ scale: 0.85, opacity: 0, y: 10 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                transition={{ duration: 0.15 }}
                className="bg-black/85 backdrop-blur-md border border-white/10 rounded-full py-1.5 px-3 shadow-xl flex items-center justify-between gap-1"
                style={{ direction: 'ltr' }}
              >
                {['👍', '❤️', '😂', '😮', '😢', '🙏'].map(emoji => (
                  <button
                    key={emoji}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleToggleReaction(portalMenu.message.id, emoji);
                      setPortalMenu(null);
                    }}
                    className="hover:scale-130 transition-all duration-150 active:scale-95 cursor-pointer text-lg p-0.5 hover:bg-white/5 rounded-full"
                    title={`React with ${emoji}`}
                  >
                    {emoji}
                  </button>
                ))}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowExpandedEmojis(!showExpandedEmojis);
                  }}
                  className="w-7 h-7 flex items-center justify-center text-zinc-400 bg-white/5 hover:bg-white/10 border border-white/5 rounded-full cursor-pointer transition-all duration-150 shrink-0"
                  title={showExpandedEmojis ? "إغلاق التفاعلات" : "المزيد من التفاعلات"}
                >
                  {showExpandedEmojis ? <X className="w-3.5 h-3.5 text-zinc-450" /> : '➕'}
                </button>
              </motion.div>
            )}

            {/* Extra emojis if toggled */}
            {showExpandedEmojis && portalMenu.message.state !== 'deleted' && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9, y: -5 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                transition={{ duration: 0.12 }}
                className="bg-black/90 backdrop-blur-md border border-white/10 rounded-2xl py-2 px-3 shadow-xl flex items-center justify-around gap-1"
                style={{ direction: 'ltr' }}
              >
                {['🔥', '👏', '🎉', '💡', '🚀', '👀'].map(emoji => (
                  <button
                    key={emoji}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleToggleReaction(portalMenu.message.id, emoji);
                      setPortalMenu(null);
                    }}
                    className="hover:scale-130 transition-all duration-150 active:scale-95 cursor-pointer text-base p-1 hover:bg-white/5 rounded-full"
                  >
                    {emoji}
                  </button>
                ))}
              </motion.div>
            )}

            {/* Elegant glassmorphism context list panel */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 5 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              transition={{ duration: 0.15 }}
              className="bg-black/85 backdrop-blur-md border border-white/10 rounded-2xl py-1.5 shadow-2xl text-right overflow-hidden flex flex-col"
            >
              {getContextItems(portalMenu.message, portalMenu.isMe).map((item, idx) => (
                <button
                  key={idx}
                  ref={(el) => { if (el) menuItemsRef.current[idx] = el; }}
                  onClick={(e) => {
                    e.stopPropagation();
                    item.action();
                  }}
                  className={`w-full px-4 py-2 hover:bg-white/5 text-xs flex items-center justify-between gap-3 text-right cursor-pointer transition-all duration-150 outline-none focus:bg-white/10 ${
                    item.danger ? 'text-red-400 hover:text-red-350 focus:bg-red-500/10' : 'text-zinc-200 hover:text-white'
                  }`}
                  role="menuitem"
                  tabIndex={focusedIndex === idx ? 0 : -1}
                  aria-label={item.label}
                >
                  <span className="font-medium text-xs text-right w-full">{item.label}</span>
                  <span className="shrink-0">{item.icon}</span>
                </button>
              ))}
            </motion.div>
          </div>
        </div>,
        document.body
      )}

      {/* ========================================== */}
      {/* 3. Message Info Sheet Modal */}
      {/* ========================================== */}
      <AnimatePresence>
        {infoMsgModal && (
          <div className="fixed inset-0 z-[250] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" style={{ direction: 'rtl' }}>
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              transition={{ duration: 0.18 }}
              className="bg-[#182229]/95 backdrop-blur-lg border border-white/10 p-6 rounded-3xl w-full max-w-md shadow-2xl text-white select-text font-sans"
            >
              {/* Header */}
              <div className="flex justify-between items-center border-b border-white/5 pb-3 mb-4">
                <h3 className="text-sm font-bold flex items-center gap-2 text-zinc-200 font-sans">
                  <Info className="w-4 h-4 text-zinc-400" />
                  تفاصيل ومعلومات الرسالة
                </h3>
                <button onClick={() => setInfoMsgModal(null)} className="text-zinc-400 hover:text-white transition-colors cursor-pointer">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Message Payload Body */}
              <div className="space-y-4 text-xs font-sans">
                {/* 1. Message content review */}
                <div className="bg-white/5 border border-white/5 p-3 rounded-2xl select-text">
                  <p className="text-[10px] text-zinc-400 uppercase tracking-wider font-bold mb-1 select-none font-sans">محتوى الرسالة</p>
                  <p className="text-zinc-200 select-all font-sans break-words">{infoMsgModal.content || '[محتوى وسائط أو فارغ]'}</p>
                </div>

                {/* Grid info stats */}
                <div className="grid grid-cols-2 gap-3 font-sans">
                  <div className="bg-white/5 p-2.5 rounded-xl border border-white/5">
                    <span className="text-[10px] text-zinc-400 block mb-0.5 select-none font-sans">كود التعرف (ID)</span>
                    <span className="text-[9px] text-zinc-350 block select-all truncate font-mono">{infoMsgModal.id}</span>
                  </div>
                  <div className="bg-white/5 p-2.5 rounded-xl border border-white/5">
                    <span className="text-[10px] text-zinc-400 block mb-0.5 select-none font-sans">الحالة الحالية</span>
                    <span className="text-xs text-zinc-300 font-bold font-sans">
                      {infoMsgModal.state === 'read' ? '✓✓ مقروءة' : infoMsgModal.state === 'delivered' ? '✓✓ مستلمة' : infoMsgModal.state === 'sent' ? '✓ مرسلة' : infoMsgModal.state}
                    </span>
                  </div>
                  <div className="bg-white/5 p-2.5 rounded-xl border border-white/5">
                    <span className="text-[10px] text-zinc-400 block mb-0.5 select-none font-sans">وقت الإرسال</span>
                    <span className="text-[10px] text-zinc-350 block font-mono">{new Date(infoMsgModal.createdAt).toLocaleString()}</span>
                  </div>
                  <div className="bg-white/5 p-2.5 rounded-xl border border-white/5">
                    <span className="text-[10px] text-zinc-400 block mb-0.5 select-none font-sans">ريأكشنات التفاعل</span>
                    <span className="text-xs text-zinc-300 font-bold block font-sans">
                      {infoMsgModal.reactions ? Object.values(infoMsgModal.reactions).flat().length : 0} تفاعلات
                    </span>
                  </div>
                </div>

                {/* Group chat "Seen By" receipt statuses */}
                {selectedChatMeta?.type === 'group' && (
                  <div className="bg-white/5 p-3.5 rounded-2xl border border-white/5">
                    <p className="text-[10px] text-zinc-400 uppercase tracking-wider font-bold mb-2 select-none font-sans">شوهدت بواسطة (Seen By)</p>
                    {isLoadingInfo ? (
                      <div className="flex justify-center py-4">
                        <Loader2 className="w-4 h-4 text-zinc-500 animate-spin" />
                      </div>
                    ) : infoMsgReceipts.length > 0 ? (
                      <div className="space-y-1.5 max-h-32 overflow-y-auto custom-scrollbar">
                        {infoMsgReceipts.map((rcpt: any, idx: number) => {
                          const reader = allUsers[rcpt.userId];
                          return (
                            <div key={idx} className="flex justify-between items-center text-[11px] text-zinc-300 border-b border-white/5 pb-1">
                              <span className="font-semibold">{reader?.displayName || reader?.username || 'مشارك'}</span>
                              <span className="text-[9px] text-zinc-500 font-mono">
                                {rcpt.updatedAt ? fmtChatTime(rcpt.updatedAt) : 'مكتمل'}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="text-center py-2 text-zinc-500 text-[11px] font-sans">لا توجد مؤشرات قراءة متوفرة بعد</div>
                    )}
                  </div>
                )}

                {/* Attachment detail if present */}
                {infoMsgModal.attachments && infoMsgModal.attachments.length > 0 && (
                  <div className="bg-white/5 p-3.5 rounded-2xl border border-white/5 font-sans">
                    <p className="text-[10px] text-zinc-400 uppercase tracking-wider font-bold mb-2 font-sans">بيانات المرفقات</p>
                    {infoMsgModal.attachments.map((att: any, idx: number) => (
                      <div key={idx} className="flex justify-between items-center text-[10px] gap-2 font-mono">
                        <span className="text-zinc-350 truncate max-w-[180px] select-all font-sans">
                          {/* E2EE guard: never disclose the opaque enc.bin name */}
                          {att.meta?.e2ee === true ? 'مرفق مشفر' : att.name}
                        </span>
                        <span className="text-zinc-500 shrink-0">
                          {att.meta?.e2ee === true ? '—' : `${(att.size / (1024 * 1024)).toFixed(2)} MB`}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ========================================== */}
      {/* 4. Elegant Telegram Style Forwarding Modal */}
      {/* ========================================== */}
      <AnimatePresence>
        {forwardModalMsg && (
          <div className="fixed inset-0 z-[350] bg-black/60 backdrop-blur-md flex items-center justify-center p-4" style={{ direction: 'rtl' }}>
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              transition={{ duration: 0.18 }}
              className="bg-zinc-900/65 backdrop-blur-2xl border border-white/10 p-6 rounded-[28px] w-full max-w-sm shadow-2xl text-white select-none font-sans relative overflow-hidden shadow-[inset_0_1px_1px_rgba(255,255,255,0.1),_0_25px_50px_-12px_rgba(0,0,0,0.5)]"
            >
              {/* Header */}
              <div className="flex justify-between items-center border-b border-white/10 pb-3 mb-4">
                <h3 className="text-sm font-bold flex items-center gap-2 text-zinc-200 font-sans">
                  <Forward className="w-4 h-4 text-zinc-400 rotate-180" />
                  إعادة توجيه الرسالة
                </h3>
                <button onClick={() => setForwardModalMsg(null)} className="text-zinc-400 hover:text-white transition-colors cursor-pointer p-1 rounded-full hover:bg-white/5">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Message Preview Quote wrapper */}
              <div className="bg-white/5 border border-white/5 border-r-2 border-zinc-500/60 p-3 text-right rounded-2xl mb-4 text-[11px] select-text">
                <span className="block font-bold text-zinc-450 select-none mb-1">الرسالة المحدد توجيهها:</span>
                <span className="text-zinc-300 truncate block font-sans">{forwardModalMsg.content || '[وسائط متعددة]'}</span>
              </div>

              {/* Search Bar input */}
              <input
                type="text"
                placeholder="ابحث باسم المحادثة..."
                value={forwardSearch}
                onChange={(e) => setForwardSearch(e.target.value)}
                className="w-full bg-black/40 border border-white/10 hover:border-white/15 focus:border-zinc-500 rounded-2xl px-4 py-3 text-xs mb-4 focus:outline-none text-white placeholder:text-zinc-500 font-sans transition-all duration-200"
              />

              {/* Chats listings viewport scroll */}
              <div className="max-h-60 overflow-y-auto space-y-1.5 pr-1 custom-scrollbar">
                {isLoadingForwardChats ? (
                  <div className="py-8 flex justify-center items-center">
                    <Loader2 className="w-5 h-5 animate-spin text-zinc-500" />
                  </div>
                ) : forwardChats.length > 0 ? (
                  forwardChats
                    .filter(c => {
                       const isBot = c.members?.some((m: any) => m.id === 'user-bot-dirasha' || m.username === 'dirasha_system') || c.id.includes('bot-dirasha') || c.otherMember?.id === 'user-bot-dirasha';
                       if (isBot) return false;
                       const meta = resolveChatDisplayMeta(c);
                       return meta.name.toLowerCase().includes(forwardSearch.toLowerCase());
                    })
                    .map((chat) => {
                      const meta = resolveChatDisplayMeta(chat);
                      const isSuccess = forwardSuccessId === chat.id;
                      return (
                        <button
                          key={chat.id}
                          onClick={() => handleForwardAction(chat.id)}
                          disabled={isSuccess || isForwarding}
                          className="w-full flex items-center justify-between p-3 rounded-2xl hover:bg-white/10 active:bg-white/15 transition-all text-right text-xs text-zinc-300 focus:outline-none cursor-pointer font-sans"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-full bg-zinc-800 flex items-center justify-center font-bold text-zinc-300 overflow-hidden shrink-0 border border-white/10 shadow-sm">
                              {meta.avatarUrl ? (
                                <img src={meta.avatarUrl} alt={meta.name} className="w-full h-full object-cover" />
                              ) : (
                                (meta.name || 'G').charAt(0)
                              )}
                            </div>
                            <div className="text-right">
                              <div className="font-bold text-zinc-250">{meta.name}</div>
                              <div className="text-[9px] text-zinc-500">{chat.type === 'group' ? 'مجموعة' : 'محادثة خاصة'}</div>
                            </div>
                          </div>
                          {isSuccess ? (
                            <span className="text-emerald-400 font-bold font-sans">✓ تم الإرسال</span>
                          ) : (
                            <Forward className="w-3.5 h-3.5 text-zinc-400 hover:text-white shrink-0 rotate-180" />
                          )}
                        </button>
                      );
                    })
                ) : (
                  <div className="py-6 text-center text-xs text-zinc-500 font-sans">لا توجد محادثات نشطة حالياً</div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Contact sharing picker — real contacts fetched on open from GET /api/contacts */}
      {showContactPicker && (
        <div className="fixed inset-0 z-[350] bg-black/60 backdrop-blur-md flex items-center justify-center p-4" style={{ direction: 'rtl' }}>
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="bg-zinc-900/65 backdrop-blur-2xl border border-white/10 p-6 rounded-[28px] w-full max-w-sm shadow-2xl text-white select-none font-sans relative overflow-hidden shadow-[inset_0_1px_1px_rgba(255,255,255,0.1),_0_25px_50px_-12px_rgba(0,0,0,0.5)]"
          >
            {/* Header */}
            <div className="flex justify-between items-center border-b border-white/10 pb-3 mb-4">
              <h3 className="text-sm font-bold flex items-center gap-2 text-zinc-200 font-sans">
                <User className="w-4 h-4 text-indigo-400" />
                مشاركة جهة اتصال
              </h3>
              <button onClick={() => setShowContactPicker(false)} className="text-zinc-400 hover:text-white transition-colors cursor-pointer p-1 rounded-full hover:bg-white/5">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Contacts viewport */}
            <div className="max-h-72 overflow-y-auto space-y-1.5 pr-1 custom-scrollbar">
              {isLoadingContacts ? (
                <div className="py-8 flex justify-center items-center">
                  <Loader2 className="w-5 h-5 animate-spin text-zinc-500" />
                </div>
              ) : contactsList.length > 0 ? (
                contactsList.map((c: any) => {
                  const cName = String(c?.displayName || c?.username || 'مستخدم');
                  const cUser = String(c?.username || '');
                  return (
                    <button
                      key={String(c?.id)}
                      type="button"
                      onClick={() => handleSendContact(c)}
                      className="w-full flex items-center justify-between p-3 rounded-2xl hover:bg-white/10 active:bg-white/15 transition-all text-right text-xs text-zinc-300 focus:outline-none cursor-pointer font-sans"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-indigo-500/20 border border-indigo-400/20 flex items-center justify-center font-bold text-indigo-300 overflow-hidden shrink-0">
                          {c?.avatarUrl ? (
                            <img src={c.avatarUrl} alt={cName} className="w-full h-full object-cover" />
                          ) : (
                            cName.charAt(0)
                          )}
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-zinc-200">{cName}</div>
                          {cUser && <div className="text-[9px] text-zinc-500" style={{ direction: 'ltr' }}>@{cUser}</div>}
                        </div>
                      </div>
                      <span className="text-[10px] font-bold text-indigo-300 bg-indigo-500/20 px-3 py-1.5 rounded-full">مشاركة</span>
                    </button>
                  );
                })
              ) : (
                <div className="py-6 text-center text-xs text-zinc-500 font-sans">لا توجد جهات اتصال محفوظة بعد</div>
              )}
            </div>
          </motion.div>
        </div>
      )}

      {/* ========================================== */}
      {/* Sticker panel (v1): recents grid + upload — stored on the user's own Drive */}
      {/* ========================================== */}
      {showStickerPanel && (
        <div className="fixed inset-0 z-[350] bg-black/60 backdrop-blur-md flex items-center justify-center p-4" style={{ direction: 'rtl' }}>
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="bg-zinc-900/65 backdrop-blur-2xl border border-white/10 p-6 rounded-[28px] w-full max-w-sm shadow-2xl text-white select-none font-sans relative overflow-hidden shadow-[inset_0_1px_1px_rgba(255,255,255,0.1),_0_25px_50px_-12px_rgba(0,0,0,0.5)]"
          >
            {/* Header */}
            <div className="flex justify-between items-center border-b border-white/10 pb-3 mb-4">
              <h3 className="text-sm font-bold flex items-center gap-2 text-zinc-200 font-sans">
                <Sticker className="w-4 h-4 text-fuchsia-400" />
                الملصقات
              </h3>
              <button onClick={() => setShowStickerPanel(false)} className="text-zinc-400 hover:text-white transition-colors cursor-pointer p-1 rounded-full hover:bg-white/5">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Recents grid — newest first, max 30 */}
            <div className="max-h-64 overflow-y-auto custom-scrollbar mb-4">
              {stickerRecents.length > 0 ? (
                <div className="grid grid-cols-3 gap-2">
                  {stickerRecents.map((s, idx) => (
                    <button
                      key={`${s.url}-${idx}`}
                      type="button"
                      onClick={() => handleSendSticker(s)}
                      className="aspect-square rounded-xl overflow-hidden bg-white/5 border border-white/5 hover:border-fuchsia-500/40 active:scale-95 transition-all cursor-pointer p-1"
                      title={s.name || 'ملصق'}
                    >
                      {s.e2ee && s.payload ? (
                        <EncryptedStickerThumb url={s.url} payload={s.payload} accessToken={accessToken} alt={s.name || 'ملصق'} />
                      ) : (
                        <img
                          src={resolveMediaUrl(s.url)}
                          alt={s.name || 'ملصق'}
                          loading="lazy"
                          className="w-full h-full object-contain"
                          referrerPolicy="no-referrer"
                        />
                      )}
                    </button>
                  ))}
                </div>
              ) : (
                <div className="py-8 px-4 text-center flex flex-col items-center justify-center gap-2">
                  <div className="p-3 rounded-full bg-white/5">
                    <Sticker className="w-6 h-6 text-zinc-500" />
                  </div>
                  <p className="text-xs text-zinc-500 font-sans">لا توجد ملصقات بعد — أضف أول ملصق</p>
                </div>
              )}
            </div>

            {/* Hidden upload input (images only, 1MB cap enforced in the handler) */}
            <input
              type="file"
              ref={stickerInputRef}
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                if (e.target.files && e.target.files[0]) {
                  handleStickerUpload(e.target.files[0]);
                }
                e.target.value = '';
              }}
            />
            <button
              type="button"
              onClick={() => stickerInputRef.current?.click()}
              className="w-full py-2.5 rounded-xl border border-dashed border-fuchsia-400/30 bg-fuchsia-500/10 hover:bg-fuchsia-500/20 text-[12px] font-black text-fuchsia-300 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              إضافة ملصق
            </button>
          </motion.div>
        </div>
      )}

      {/* ========================================== */}
      {/* Multi-select sticky bottom action bar (WhatsApp parity) */}
      {/* Forward is disabled in v1 — the forward modal is single-message. */}
      {/* ========================================== */}
      {selectionMode && (
        <div className="fixed inset-x-0 bottom-24 z-[140] flex justify-center px-4 pointer-events-none" style={{ direction: 'rtl' }}>
          <div className="pointer-events-auto w-full max-w-md bg-[#0b141a]/90 backdrop-blur-xl border border-white/10 rounded-2xl shadow-[0_20px_60px_rgba(0,0,0,0.6)] px-4 py-2.5 flex items-center gap-2">
            <span className="text-[12px] font-black text-emerald-300 shrink-0 select-none">{selectedMessageIds.size} محدد</span>
            <div className="flex-1" />
            <button
              type="button"
              onClick={handleBulkCopy}
              disabled={selectedMessageIds.size === 0}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/15 border border-emerald-400/25 text-emerald-300 hover:bg-emerald-500/25 disabled:opacity-40 disabled:cursor-not-allowed text-[11px] font-bold transition-all cursor-pointer"
            >
              <Copy className="w-3.5 h-3.5" />
              نسخ
            </button>
            <button
              type="button"
              onClick={handleBulkDeleteForMe}
              disabled={isBulkDeleting || selectedMessageIds.size === 0}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-red-500/15 border border-red-400/25 text-red-300 hover:bg-red-500/25 disabled:opacity-40 disabled:cursor-not-allowed text-[11px] font-bold transition-all cursor-pointer"
            >
              {isBulkDeleting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
              حذف
            </button>
            <button
              type="button"
              onClick={exitSelectionMode}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-zinc-300 hover:bg-white/10 hover:text-white text-[11px] font-bold transition-all cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
              إلغاء
            </button>
          </div>
        </div>
      )}

      {showGroupSettings && selectedChatMeta?.id && (
        <GroupSettingsPanel
          chatId={selectedChatMeta.id}
          onClose={() => setShowGroupSettings(false)}
          onLeft={() => setShowGroupSettings(false)}
        />
      )}

      {/* E2EE safety-number modal (Agent I): opened from the DM header lock badge
          (and from the rekey warning banner). Closing re-resolves the verified
          badge / rekey banner so a just-tapped 'توثيق رقم الأمان' reflects instantly. */}
      <E2eeSafetyModal
        open={!!safetyModalPeer}
        peerId={safetyModalPeer}
        peerName={safetyModalPeer ? selectedChatMeta?.name : undefined}
        getSafetyNumber={onGetSafetyNumber ?? (async () => { throw new Error('E2EE unavailable'); })}
        myId={myIdForE2ee || null}
        onClose={() => {
          setSafetyModalPeer(null);
          refreshE2eePeerState();
        }}
      />
    </div>
  );
}

export default ChatWindow;
