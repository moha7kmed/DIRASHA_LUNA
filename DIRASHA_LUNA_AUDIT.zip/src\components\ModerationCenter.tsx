import React, { useState, useEffect, Component, ReactNode } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, Shield, AlertTriangle, Search, Loader2, 
  Flag, Users, Database, ShieldCheck, 
  Filter, ChevronLeft, LayoutDashboard
} from 'lucide-react';
import { User } from '../types.ts';

// Sub-views
import { UserListView, UserDetailsView } from './moderation/UserView.tsx';
import { ReportsView } from './moderation/ReportsView.tsx';
import { AuditLogView } from './moderation/AuditLogView.tsx';
import { VaultView } from './moderation/VaultView.tsx';

interface ModerationCenterProps {
  isOpen: boolean;
  onClose: () => void;
  accessToken: string;
  currentUser: User | null;
}

export class ModerationErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean, errorMsg: string }> {
  state = { hasError: false, errorMsg: '' };
  
  constructor(props: { children: ReactNode }) {
    super(props);
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, errorMsg: error.message };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error('ModerationCenter Error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center h-full p-10 text-center space-y-6">
          <div className="p-4 bg-rose-500/10 rounded-full">
            <AlertTriangle className="w-12 h-12 text-rose-500" />
          </div>
          <div className="space-y-2">
            <h2 className="text-xl font-bold text-zinc-100">System Error</h2>
            <p className="text-sm text-zinc-400 max-w-sm">{this.state.errorMsg || 'Failed to initialize moderation services.'}</p>
          </div>
          <button 
            onClick={() => this.setState({ hasError: false, errorMsg: '' })} 
            className="px-6 py-3 bg-white text-black text-xs font-black uppercase tracking-widest rounded-2xl hover:bg-zinc-200 transition-all shadow-xl"
          >
            Reboot Service
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

type TabType = 'reports' | 'users' | 'vault' | 'logs';

export function ModerationCenter({ isOpen, onClose, accessToken, currentUser }: ModerationCenterProps) {
  const [activeTab, setActiveTab] = useState<TabType>('reports');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Data States
  const [reports, setReports] = useState<any[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [vaultItems, setVaultItems] = useState<any[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);

  // User details state
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [userStats, setUserStats] = useState<any>(null);
  const [loadingUserStats, setLoadingUserStats] = useState(false);
  const [userNotes, setUserNotes] = useState<any[]>([]);
  const [userWarnings, setUserWarnings] = useState<any[]>([]);
  const [enforcementHistory, setEnforcementHistory] = useState<any[]>([]);
  const [userReports, setUserReports] = useState<any[]>([]);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [userFilter, setUserFilter] = useState<'all' | 'banned' | 'muted' | 'admin'>('all');

  // Authorization check for role management
  const canManageRoles = currentUser?.email.toLowerCase() === 'thedarkh95@gmail.com';

  useEffect(() => {
    if (isOpen) {
      if (selectedUser) {
        fetchUserStats(selectedUser.id);
        fetchUserDetailsData(selectedUser.id);
      } else {
        fetchTabData();
      }
    }
  }, [isOpen, activeTab, userFilter, selectedUser]);

  const fetchTabData = async () => {
    setLoading(true);
    setError(null);
    try {
      if (activeTab === 'reports') {
        const response = await fetch('/api/moderation/reports?status=Pending', {
          headers: { 'Authorization': `Bearer ${accessToken}` }
        });
        const data = await response.json();
        setReports(data.reports || []);
      } else if (activeTab === 'users') {
        const filterQuery = userFilter !== 'all' ? `&filter=${userFilter}` : '';
        const response = await fetch(`/api/moderation/users?limit=50${filterQuery}`, {
          headers: { 'Authorization': `Bearer ${accessToken}` }
        });
        const data = await response.json();
        setUsers(data || []);
      } else if (activeTab === 'vault') {
        const response = await fetch('/api/moderation/vault', {
          headers: { 'Authorization': `Bearer ${accessToken}` }
        });
        const data = await response.json();
        setVaultItems(data.deletedMessages || []);
      } else if (activeTab === 'logs') {
        const response = await fetch('/api/moderation/audit-logs', {
          headers: { 'Authorization': `Bearer ${accessToken}` }
        });
        const data = await response.json();
        setAuditLogs(data.auditLogs || []);
      }
    } catch (err: any) {
      setError(err.message || 'Moderation node connection failure.');
    } finally {
      setLoading(false);
    }
  };

  const fetchUserDetailsData = async (userId: string) => {
    try {
      const [notesRes, warnsRes, historyRes, reportsRes] = await Promise.all([
        fetch(`/api/moderation/users/${userId}/notes`, { headers: { 'Authorization': `Bearer ${accessToken}` } }),
        fetch(`/api/moderation/users/${userId}/warnings`, { headers: { 'Authorization': `Bearer ${accessToken}` } }),
        fetch(`/api/moderation/users/${userId}/enforcement`, { headers: { 'Authorization': `Bearer ${accessToken}` } }),
        fetch(`/api/moderation/users/${userId}/reports`, { headers: { 'Authorization': `Bearer ${accessToken}` } })
      ]);
      
      const [notesData, warnsData, historyData, reportsData] = await Promise.all([
        notesRes.json(),
        warnsRes.json(),
        historyRes.json(),
        reportsRes.json()
      ]);
      
      setUserNotes(notesData || []);
      setUserWarnings(warnsData || []);
      setEnforcementHistory(historyData || []);
      setUserReports(reportsData || []);
    } catch (err) {
      console.error('Failed to fetch user details data:', err);
    }
  };

  const fetchUserStats = async (userId: string) => {
    setLoadingUserStats(true);
    try {
      const response = await fetch(`/api/moderation/users/${userId}/stats`, {
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
      const data = await response.json();
      setUserStats(data);
    } catch (err: any) {
      console.error('Failed to fetch user stats:', err);
    } finally {
      setLoadingUserStats(false);
    }
  };

  const handleUpdateStatus = async (userId: string, update: { role?: string, isVerified?: boolean }) => {
    try {
      const res = await fetch(`/api/moderation/users/${userId}/role`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify(update)
      });
      
      if (res.ok) {
        setUsers(prev => prev.map(u => u.id === userId ? { ...u, ...update } : u) as User[]);
        if (selectedUser?.id === userId) {
          setSelectedUser(prev => (prev ? { ...prev, ...update } : null) as User | null);
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleMuteUser = async (hours: number, reason: string) => {
    if (!selectedUser) return;
    try {
      const response = await fetch(`/api/moderation/users/${selectedUser.id}/mute`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({ durationHours: hours, reason })
      });
      
      if (!response.ok) {
        let errorMsg = 'فشل تنفيذ الكتم';
        try {
          const errData = await response.json();
          errorMsg = errData.error || errorMsg;
        } catch (_) {}
        throw new Error(errorMsg);
      }
      
      const updatedUser = { ...selectedUser };
      const hoursToAdd = hours === -1 ? 999999 : hours;
      const until = new Date();
      until.setHours(until.getHours() + hoursToAdd);
      updatedUser.mutedUntil = until.toISOString();
      updatedUser.muteReason = reason;
      setSelectedUser(updatedUser);
      
      if ((window as any).showGlobalToast) (window as any).showGlobalToast('تم تطبيق الكتم بنجاح.', 'success');
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleUnmuteUser = async () => {
    if (!selectedUser) return;
    try {
      const response = await fetch(`/api/moderation/users/${selectedUser.id}/unmute`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
      if (!response.ok) {
        let errorMsg = 'Unmute failed';
        try {
          const errData = await response.json();
          errorMsg = errData.error || errorMsg;
        } catch (_) {}
        throw new Error(errorMsg);
      }
      
      const updatedUser = { ...selectedUser };
      updatedUser.mutedUntil = undefined;
      updatedUser.muteReason = undefined;
      setSelectedUser(updatedUser);
      if ((window as any).showGlobalToast) (window as any).showGlobalToast('User restriction lifted.', 'success');
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleBanUser = async (durationHours: number, reason: string) => {
    if (!selectedUser) return;
    try {
      const response = await fetch(`/api/moderation/users/${selectedUser.id}/ban`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({ durationHours, reason })
      });
      if (!response.ok) {
        let errorMsg = 'Ban execution failed';
        try {
          const errData = await response.json();
          errorMsg = errData.error || errorMsg;
        } catch (_) {}
        throw new Error(errorMsg);
      }
      
      const hoursToAdd = durationHours === -1 ? 999999 : durationHours;
      const until = new Date();
      until.setHours(until.getHours() + hoursToAdd);

      const updatedUser = { ...selectedUser, isBanned: true, bannedUntil: until.toISOString(), banReason: reason };
      setSelectedUser(updatedUser);
      if ((window as any).showGlobalToast) (window as any).showGlobalToast('Account banned successfully.', 'error');
      
      // Refresh enforcement history
      fetchUserDetailsData(selectedUser.id);
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleUnbanUser = async () => {
    if (!selectedUser) return;
    try {
      const response = await fetch(`/api/moderation/users/${selectedUser.id}/unban`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
      if (!response.ok) {
        let errorMsg = 'Unban failed';
        try {
          const errData = await response.json();
          errorMsg = errData.error || errorMsg;
        } catch (_) {}
        throw new Error(errorMsg);
      }
      
      const updatedUser = { ...selectedUser, isBanned: false, bannedUntil: undefined, banReason: undefined };
      setSelectedUser(updatedUser);
      if ((window as any).showGlobalToast) (window as any).showGlobalToast('Account ban revoked.', 'success');
      
      // Refresh enforcement history
      fetchUserDetailsData(selectedUser.id);
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleResolveReport = async (reportId: string) => {
    try {
      const res = await fetch(`/api/moderation/reports/${reportId}/status`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({ status: 'Resolved' })
      });
      if (!res.ok) {
        let errorMsg = 'Failed to resolve report';
        try {
          const errData = await res.json();
          errorMsg = errData.error || errorMsg;
        } catch (_) {}
        throw new Error(errorMsg);
      }
      setReports(prev => prev.filter(r => r.reportId !== reportId));
      if ((window as any).showGlobalToast) (window as any).showGlobalToast('Report resolved.', 'success');
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleRejectReport = async (reportId: string) => {
    try {
      const res = await fetch(`/api/moderation/reports/${reportId}/status`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({ status: 'Rejected' })
      });
      if (!res.ok) {
        let errorMsg = 'Failed to reject report';
        try {
          const errData = await res.json();
          errorMsg = errData.error || errorMsg;
        } catch (_) {}
        throw new Error(errorMsg);
      }
      setReports(prev => prev.filter(r => r.reportId !== reportId));
      if ((window as any).showGlobalToast) (window as any).showGlobalToast('Report dismissed.', 'info');
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleAddNote = async (content: string) => {
    if (!selectedUser) return;
    try {
      const res = await fetch(`/api/moderation/users/${selectedUser.id}/notes`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({ content })
      });
      if (res.ok) {
        fetchUserDetailsData(selectedUser.id);
      }
    } catch (err) { console.error(err); }
  };

  const handleAddWarning = async (reason: string, severity: number) => {
    if (!selectedUser) return;
    try {
      const res = await fetch(`/api/moderation/users/${selectedUser.id}/warnings`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({ reason, severity })
      });
      if (res.ok) {
        fetchUserDetailsData(selectedUser.id);
        fetchUserStats(selectedUser.id);
      }
    } catch (err) { console.error(err); }
  };

  const handleClearWarnings = async () => {
    if (!selectedUser) return;
    try {
      const res = await fetch(`/api/moderation/users/${selectedUser.id}/warnings`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
      if (res.ok) {
        fetchUserDetailsData(selectedUser.id);
        fetchUserStats(selectedUser.id);
      }
    } catch (err) { console.error(err); }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[200] flex items-center justify-center font-sans overflow-hidden bg-black/60 backdrop-blur-[20px]" dir="ltr">
        <motion.div 
          initial={{ opacity: 0 }} 
          animate={{ opacity: 1 }} 
          exit={{ opacity: 0 }} 
          onClick={onClose} 
          className="absolute inset-0" 
        />

        <motion.div
           initial={{ opacity: 0, scale: 0.95, y: 30 }}
           animate={{ opacity: 1, scale: 1, y: 0 }}
           exit={{ opacity: 0, scale: 0.95, y: 30 }}
           transition={{ type: "spring", damping: 30, stiffness: 400 }}
           className="relative w-full h-full md:max-w-6xl md:h-[90vh] bg-zinc-950/70 md:border md:border-white/10 md:rounded-[48px] shadow-[0_0_120px_rgba(0,0,0,0.7)] backdrop-blur-3xl overflow-hidden flex flex-col z-10"
        >
          {/* Header */}
          <div className="flex items-center justify-between px-8 md:px-12 py-6 border-b border-white/5 bg-white/[0.02] backdrop-blur-md shrink-0">
            <div className="flex items-center gap-6">
               <button 
                 onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                 className="md:hidden p-3 bg-white/5 text-zinc-400 hover:text-white rounded-2xl border border-white/10 transition-all"
               >
                 <Filter className="w-5 h-5" />
               </button>
               <div className="p-3 bg-indigo-500/10 rounded-2xl border border-indigo-500/20 hidden sm:flex items-center justify-center">
                 <Shield className="w-5 h-5 text-indigo-400" />
               </div>
               <div>
                 <h1 className="text-lg font-black text-white tracking-tight leading-none">Command Hub</h1>
                 <p className="hidden xs:block text-[10px] text-zinc-500 font-black uppercase tracking-widest mt-1.5 opacity-60">Authentication & Oversight v5.0</p>
               </div>
            </div>

            <div className="flex items-center gap-5">
               <button 
                 onClick={onClose} 
                 className="p-3 bg-white/5 hover:bg-rose-500/10 rounded-2xl text-zinc-400 hover:text-rose-400 transition-all border border-white/10 hover:border-rose-500/30 group"
               >
                 <X className="w-6 h-6 group-hover:scale-110 transition-transform" />
               </button>
            </div>
          </div>

          <div className="flex-1 flex overflow-hidden relative">
            {/* Sidebar Navigation */}
            <div className={`
              absolute md:relative inset-y-0 left-0 w-80 bg-black/20 border-r border-white/5 z-20 backdrop-blur-2xl transition-transform duration-500 ease-[cubic-bezier(0.23,1,0.32,1)] md:translate-x-0
              ${isSidebarOpen ? 'translate-x-0 shadow-2xl shadow-black' : '-translate-x-full md:translate-x-0'}
            `}>
               <div className="p-10 h-full flex flex-col gap-10">
                  <div className="space-y-3 font-bold">
                    <NavButton 
                      icon={<Flag className="w-5 h-5" />} 
                      label="Reports Ledger" 
                      active={activeTab === 'reports'} 
                      onClick={() => { setActiveTab('reports'); setSelectedUser(null); setIsSidebarOpen(false); }} 
                    />
                    <NavButton 
                      icon={<Users className="w-5 h-5" />} 
                      label="Citizen Registry" 
                      active={activeTab === 'users'} 
                      onClick={() => { setActiveTab('users'); setSelectedUser(null); setIsSidebarOpen(false); }} 
                    />
                    <NavButton 
                      icon={<Database className="w-5 h-5" />} 
                      label="Forensic Vault" 
                      active={activeTab === 'vault'} 
                      onClick={() => { setActiveTab('vault'); setSelectedUser(null); setIsSidebarOpen(false); }} 
                    />
                    <NavButton 
                      icon={<LayoutDashboard className="w-5 h-5" />} 
                      label="Event Sequence" 
                      active={activeTab === 'logs'} 
                      onClick={() => { setActiveTab('logs'); setSelectedUser(null); setIsSidebarOpen(false); }} 
                    />
                  </div>

                  <div className="mt-auto p-6 bg-indigo-500/5 border border-indigo-500/10 rounded-[32px] space-y-4">
                     <div className="flex items-center gap-3">
                        <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_10px_rgba(16,185,129,0.5)]" />
                        <span className="text-[11px] font-black text-emerald-500 uppercase tracking-widest">Linked Node</span>
                     </div>
                     <p className="text-[11px] text-zinc-500 leading-relaxed font-bold uppercase tracking-wider opacity-70">
                       Encrypted channel active. 
                       Oversight protocols initialized.
                     </p>
                  </div>
               </div>
            </div>

            {/* Main Content Area */}
            <div className="flex-1 overflow-y-auto p-6 md:p-10 lg:p-12 custom-scrollbar bg-transparent">
              <ModerationErrorBoundary>
                {/* Search / Filters Bar (Only if not viewing details) */}
                {!selectedUser && (
                   <div className="mb-10 flex flex-col xl:flex-row items-stretch xl:items-center gap-6">
                      <div className="flex-1 relative group">
                        <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600 group-focus-within:text-indigo-400 transition-colors" />
                        <input 
                          type="text" 
                          placeholder="Search identity..." 
                          className="w-full bg-white/[0.03] border border-white/5 rounded-2xl py-4 pl-14 pr-6 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:border-indigo-500/30 focus:bg-white/[0.05] transition-all font-medium backdrop-blur-xl"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                        />
                      </div>
                      
                      {activeTab === 'users' && (
                        <div className="flex items-center gap-2 p-2 bg-white/5 rounded-[32px] border border-white/10 overflow-x-auto no-scrollbar shrink-0 backdrop-blur-xl">
                           {(['all', 'banned', 'muted', 'admin'] as const).map(f => (
                             <button 
                                key={f} 
                                onClick={() => setUserFilter(f)} 
                                className={`px-6 py-3 rounded-[24px] text-[11px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${userFilter === f ? 'bg-indigo-500 text-white shadow-[0_4px_20px_rgba(99,102,241,0.4)]' : 'text-zinc-500 hover:text-zinc-200 hover:bg-white/5'}`}
                             >
                                {f}
                             </button>
                           ))}
                        </div>
                      )}
                   </div>
                )}

                {loading ? (
                  <div className="flex flex-col items-center justify-center py-32 space-y-4">
                    <Loader2 className="w-10 h-10 text-indigo-500 animate-spin" />
                    <p className="text-[10px] text-zinc-500 font-black uppercase tracking-widest animate-pulse">Syncing Control Data...</p>
                  </div>
                ) : (
                  <>
                    {activeTab === 'reports' && !selectedUser && (
                      <ReportsView 
                        reports={reports} 
                        loading={loading} 
                        onResolve={handleResolveReport} 
                        onReject={handleRejectReport} 
                        onViewDetails={() => {}} 
                      />
                    )}

                    {activeTab === 'users' && !selectedUser && (
                      <UserListView 
                        users={users.filter(u => 
                          u.displayName.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          u.username.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          u.email.toLowerCase().includes(searchQuery.toLowerCase())
                        )} 
                        loading={loading} 
                        onSelectUser={setSelectedUser} 
                      />
                    )}

                    {activeTab === 'users' && selectedUser && (
                      <UserDetailsView 
                        user={selectedUser} 
                        stats={userStats} 
                        loadingStats={loadingUserStats} 
                        canManageRoles={canManageRoles}
                        notes={userNotes}
                        warnings={userWarnings}
                        enforcementHistory={enforcementHistory}
                        reports={userReports}
                        onUpdateRole={(role) => handleUpdateStatus(selectedUser.id, { role })}
                        onUpdateVerified={(verified) => handleUpdateStatus(selectedUser.id, { isVerified: verified })}
                        onMute={handleMuteUser}
                        onUnmute={handleUnmuteUser}
                        onBan={handleBanUser}
                        onUnban={handleUnbanUser}
                        onAddNote={handleAddNote}
                        onAddWarning={handleAddWarning}
                        onClearWarnings={handleClearWarnings}
                        onBack={() => setSelectedUser(null)}
                      />
                    )}

                    {activeTab === 'vault' && (
                      <VaultView items={vaultItems} loading={loading} />
                    )}

                    {activeTab === 'logs' && (
                      <AuditLogView logs={auditLogs} loading={loading} />
                    )}
                  </>
                )}
              </ModerationErrorBoundary>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}

function NavButton({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`w-full flex items-center gap-4 px-6 py-3.5 rounded-2xl transition-all duration-300 relative group font-black uppercase tracking-widest ${
        active 
        ? 'bg-white/5 text-white border border-white/10 shadow-lg' 
        : 'text-zinc-600 hover:text-zinc-300 hover:bg-white/[0.02]'
      }`}
    >
      <div className={`transition-colors duration-300 ${active ? 'text-indigo-400' : 'text-zinc-700 group-hover:text-zinc-500'}`}>
        {icon}
      </div>
      <span className="text-[10px]">{label}</span>
      {active && (
        <motion.div 
          layoutId="nav-glow" 
          className="absolute right-3 w-1 h-1 rounded-full bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.6)]" 
        />
      )}
    </button>
  );
}
