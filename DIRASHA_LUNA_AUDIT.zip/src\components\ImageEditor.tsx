import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, Crop as CropIcon, Paintbrush, Undo2, Trash2, Send, Sliders, Type as TypeIcon,
  Unlock, Lock, RotateCw, Palette, Layers, Plus
} from 'lucide-react';
import ReactCrop, { type Crop, type PixelCrop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';

interface ImageEditorProps {
  file: File;
  onCancel: () => void;
  onSend: (file: File) => void;
  cropAspect?: number; 
  submitLabel?: string;
  submitIcon?: any;
  isSubmitting?: boolean;
}

type Mode = 'paint' | 'crop' | 'text' | 'filters';

interface TextOverlay {
  id: string;
  text: string;
  color: string;
  font: string;
  x: number;
  y: number;
  fontSize: number;
}

interface DrawLine {
  points: { x: number; y: number }[];
  color: string;
  size: number;
  isHighlighter: boolean;
}

const FONTS = [
  { name: 'افتراضي / System', value: 'system-ui, sans-serif' },
  { name: 'إنتر / Inter', value: 'Inter, sans-serif' },
  { name: 'جيت برينز / Mono', value: 'JetBrains Mono, monospace' },
  { name: 'الظاهر / Cairo', value: 'Cairo, sans-serif' },
  { name: 'المراعي / Almarai', value: 'Almarai, sans-serif' },
  { name: 'التجوال / Tajawal', value: 'Tajawal, sans-serif' },
  { name: 'أميري / Amiri', value: 'Amiri, serif' }
];

const PREDEFINED_COLORS = [
  '#ffffff', '#000000', '#ff3b30', '#34c759', '#007aff', '#ffcc00', '#af52de', '#4cd964', '#5ac8fa'
];

const FILTERS = [
  { name: 'Original', value: 'none' },
  { name: 'Cinematic', value: 'contrast(1.15) brightness(1.1) saturate(1.2)' },
  { name: 'Noir', value: 'grayscale(1) contrast(1.25)' },
  { name: 'Vintage', value: 'sepia(0.35) contrast(0.95) brightness(1.05)' },
  { name: 'Vibrant', value: 'saturate(1.8)' },
  { name: 'Warm', value: 'sepia(0.15) saturate(1.25) hue-rotate(-5deg)' },
  { name: 'Cool', value: 'saturate(1.1) hue-rotate(10deg) brightness(0.95)' },
  { name: 'Muted', value: 'saturate(0.4) contrast(0.85)' },
];

export function ImageEditor({ 
  file, 
  onCancel, 
  onSend, 
  cropAspect: initialAspect, 
  submitLabel = 'SEND', 
  submitIcon: SubmitIconComponent = Send,
  isSubmitting = false
}: ImageEditorProps) {
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [mode, setMode] = useState<Mode>('paint');
  
  // Quality
  const [quality, setQuality] = useState<'SD' | 'FHD'>('SD');
  const [canFHD, setCanFHD] = useState(false);
  const [originalRes, setOriginalRes] = useState<{width: number, height: number} | null>(null);

  // Crop States
  const [crop, setCrop] = useState<Crop>();
  const [completedCrop, setCompletedCrop] = useState<PixelCrop | null>(null);
  const [aspect, setAspect] = useState<number | undefined>(initialAspect); 
  
  // Paint States
  const [drawLines, setDrawLines] = useState<DrawLine[]>([]);
  const [activeDrawColor, setActiveDrawColor] = useState('#ff3b30');
  const [brushSize] = useState(6);
  const [paintTool, setPaintTool] = useState<'pencil' | 'highlighter'>('pencil');
  
  // Filter States
  const [filter, setFilter] = useState('none');

  // Text States
  const [texts, setTexts] = useState<TextOverlay[]>([]);
  const [selectedTextId, setSelectedTextId] = useState<string | null>(null);
  const [activeFont, setActiveFont] = useState(FONTS[0].value);

  const containerRef = useRef<HTMLDivElement>(null);
  const previewImageRef = useRef<HTMLImageElement>(null);
  const drawingCanvasRef = useRef<HTMLCanvasElement>(null);
  const [imageDimensions, setImageDimensions] = useState<{ width: number; height: number } | null>(null);
  const isDrawingRef = useRef(false);

  useEffect(() => {
    const url = URL.createObjectURL(file);
    setImageSrc(url);
    
    // Auto-detect FHD support for first load
    const img = new Image();
    img.onload = () => {
      if (!originalRes) {
        setOriginalRes({ width: img.width, height: img.height });
        if (img.width > 1200 || img.height > 1200) {
          setCanFHD(true);
          setQuality('FHD');
        } else {
          setCanFHD(false);
          setQuality('SD');
        }
      }
    };
    img.src = url;

    return () => URL.revokeObjectURL(url);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [file]);

  const syncDimensions = useCallback(() => {
    if (previewImageRef.current) {
      const { clientWidth, clientHeight } = previewImageRef.current;
      setImageDimensions({ width: clientWidth, height: clientHeight });
    }
  }, []);

  useEffect(() => {
    if (imageSrc) {
      const timer = setTimeout(syncDimensions, 150);
      return () => clearTimeout(timer);
    }
  }, [imageSrc, mode, syncDimensions]);

  // Drawing Logic
  const getCoords = (e: any) => {
    const canvas = drawingCanvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    return {
      x: ((clientX - rect.left) / rect.width) * canvas.width,
      y: ((clientY - rect.top) / rect.height) * canvas.height
    };
  };

  const startDraw = (e: any) => {
    const coords = getCoords(e);
    if (!coords) return;
    isDrawingRef.current = true;
    setDrawLines(prev => [...prev, { points: [coords], color: activeDrawColor, size: brushSize, isHighlighter: paintTool === 'highlighter' }]);
  };

  const onDraw = (e: any) => {
    if (!isDrawingRef.current) return;
    const coords = getCoords(e);
    if (!coords) return;
    setDrawLines(prev => {
      const last = prev[prev.length - 1];
      const updated = { ...last, points: [...last.points, coords] };
      return [...prev.slice(0, -1), updated];
    });
  };

  useEffect(() => {
    const canvas = drawingCanvasRef.current;
    if (!canvas || !imageDimensions) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawLines.forEach(line => {
      ctx.beginPath();
      ctx.strokeStyle = line.color;
      ctx.lineWidth = line.size;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.globalAlpha = line.isHighlighter ? 0.4 : 1;
      ctx.moveTo(line.points[0].x, line.points[0].y);
      line.points.forEach(p => ctx.lineTo(p.x, p.y));
      ctx.stroke();
    });
  }, [drawLines, imageDimensions]);

  const applyCrop = async () => {
    if (!completedCrop || !imageSrc || !previewImageRef.current || completedCrop.width === 0 || completedCrop.height === 0) {
      setMode('paint');
      return;
    }
    const image = previewImageRef.current;
    const canvas = document.createElement('canvas');
    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;

    canvas.width = completedCrop.width * scaleX;
    canvas.height = completedCrop.height * scaleY;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(
      image,
      completedCrop.x * scaleX,
      completedCrop.y * scaleY,
      completedCrop.width * scaleX,
      completedCrop.height * scaleY,
      0,
      0,
      completedCrop.width * scaleX,
      completedCrop.height * scaleY
    );

    setImageSrc(canvas.toDataURL('image/png'));
    setCrop(undefined); 
    setMode('paint'); 
  };

  const finalizeImage = async () => {
    const img = new Image();
    img.src = imageSrc!;
    await img.decode();
    const canvas = document.createElement('canvas');
    const scale = quality === 'FHD' ? 1.5 : 1;
    canvas.width = (imageDimensions?.width || img.width) * scale;
    canvas.height = (imageDimensions?.height || img.height) * scale;
    const ctx = canvas.getContext('2d')!;
    
    // Apply filters
    ctx.filter = filter !== 'none' ? filter : 'none';
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    ctx.filter = 'none';

    // Draw lines
    const ratio = canvas.width / (imageDimensions?.width || 1);
    drawLines.forEach(line => {
      ctx.beginPath();
      ctx.strokeStyle = line.color;
      ctx.lineWidth = line.size * ratio;
      ctx.globalAlpha = line.isHighlighter ? 0.4 : 1;
      ctx.moveTo(line.points[0].x * ratio, line.points[0].y * ratio);
      line.points.forEach(p => ctx.lineTo(p.x * ratio, p.y * ratio));
      ctx.stroke();
    });

    // Draw texts
    texts.forEach(t => {
      ctx.font = `bold ${t.fontSize * ratio}px ${t.font}`;
      ctx.fillStyle = t.color;
      ctx.textAlign = 'center';
      ctx.fillText(t.text, (t.x / 100) * canvas.width, (t.y / 100) * canvas.height);
    });

    canvas.toBlob(blob => blob && onSend(new File([blob], 'edited_image.png', { type: 'image/png' })), 'image/png', quality === 'FHD' ? 0.95 : 0.85);
  };

  const addText = () => {
    setTexts([...texts, { id: Math.random().toString(), text: 'أكتب هنا / Type...', color: '#ffffff', font: activeFont, x: 50, y: 50, fontSize: Math.max(18, Math.min(26, window.innerWidth > 768 ? 24 : 20)) }]);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }}
      className="absolute inset-0 z-50 bg-black flex flex-col md:flex-row items-stretch justify-center backdrop-blur-3xl overflow-hidden font-sans"
    >
      {/* Mobile Top Header */}
      <div className="absolute top-0 left-0 right-0 p-4 z-[60] flex justify-between items-center bg-gradient-to-b from-black/60 to-transparent md:hidden">
        <button onClick={onCancel} className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-full transition-all">
          <X className="w-6 h-6" />
        </button>
        <span className="text-white font-black uppercase tracking-widest text-sm">تعديل الصورة</span>
      </div>

      {/* Main Preview (Left on Desktop, Top on Mobile) */}
      <div className="flex-1 min-h-0 relative flex items-center justify-center p-4 md:p-8 pt-16 md:pt-8 bg-zinc-950/20">
        <div ref={containerRef} className="relative w-full h-full max-w-2xl flex items-center justify-center max-h-[50vh] md:max-h-full">
          <AnimatePresence mode="wait">
            {mode === 'crop' ? (
              <motion.div 
                key="crop"
                initial={{ opacity: 0, scale: 0.98 }} 
                animate={{ opacity: 1, scale: 1 }} 
                exit={{ opacity: 0, scale: 0.98 }}
                className="relative w-full h-full flex items-center justify-center"
              >
                <ReactCrop
                  crop={crop}
                  onChange={(_, percentCrop) => setCrop(percentCrop)}
                  onComplete={(c) => setCompletedCrop(c)}
                  aspect={aspect}
                  className="max-h-full flex items-center justify-center border border-white/5 rounded-[24px] shadow-2xl overflow-hidden"
                >
                  <img 
                    ref={previewImageRef}
                    src={imageSrc!} 
                    className="max-h-[50vh] md:max-h-[80vh] w-auto object-contain select-none pointer-events-none" 
                    alt="Crop preview" 
                    draggable={false}
                  />
                </ReactCrop>
              </motion.div>
            ) : (
              <motion.div 
                key="view"
                initial={{ opacity: 0, scale: 0.98 }} 
                animate={{ opacity: 1, scale: 1 }} 
                exit={{ opacity: 0, scale: 0.98 }}
                className="relative flex items-center justify-center w-full h-full"
              >
                <img 
                  ref={previewImageRef} 
                  src={imageSrc!} 
                  alt="Preview" 
                  className="max-w-full max-h-[50vh] md:max-h-[80vh] rounded-[24px] shadow-[0_20px_60px_rgba(0,0,0,0.6)] object-contain border border-white/10"
                  style={{ filter: filter !== 'none' ? filter : '' }}
                  draggable={false}
                />
                
                {mode === 'paint' && imageDimensions && (
                  <canvas
                    ref={drawingCanvasRef}
                    width={imageDimensions.width} 
                    height={imageDimensions.height}
                    className="absolute inset-0 m-auto cursor-crosshair z-20 touch-none"
                    onMouseDown={startDraw} 
                    onMouseMove={onDraw} 
                    onMouseUp={() => isDrawingRef.current = false}
                    onTouchStart={startDraw} 
                    onTouchMove={onDraw} 
                    onTouchEnd={() => isDrawingRef.current = false}
                    style={{ width: imageDimensions.width, height: imageDimensions.height }}
                  />
                )}

                {/* Passive Line Rendering */}
                {mode !== 'paint' && imageDimensions && drawLines.length > 0 && (
                  <svg className="absolute inset-0 m-auto pointer-events-none z-10" width={imageDimensions.width} height={imageDimensions.height} style={{ width: imageDimensions.width, height: imageDimensions.height }}>
                    {drawLines.map((l, i) => (
                      <path key={i} d={`M ${l.points[0].x} ${l.points[0].y} ` + l.points.slice(1).map(p => `L ${p.x} ${p.y}`).join(' ')} fill="none" stroke={l.color} strokeWidth={l.size} strokeLinecap="round" opacity={l.isHighlighter ? 0.4 : 1} />
                    ))}
                  </svg>
                )}

                {/* Text Overlays */}
                {texts.map(t => (
                  <div 
                    key={t.id} 
                    className={`absolute cursor-pointer select-none px-4 py-2 rounded-2xl transition-all duration-200 z-30 ${selectedTextId === t.id ? 'ring-2 ring-white bg-black/70 backdrop-blur-md shadow-2xl scale-105' : 'hover:bg-white/10'}`}
                    style={{ left: `${t.x}%`, top: `${t.y}%`, transform: 'translate(-50%, -50%)', color: t.color, fontFamily: t.font, fontSize: `${t.fontSize}px`, fontWeight: 'bold' }}
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      if (mode === 'text') setSelectedTextId(t.id);
                      const handleMove = (ev: MouseEvent) => {
                        if(!previewImageRef.current) return;
                        const rect = previewImageRef.current.getBoundingClientRect();
                        setTexts(prev => prev.map(txt => txt.id === t.id ? { ...txt, x: Math.max(5, Math.min(95, ((ev.clientX - rect.left)/rect.width)*100)), y: Math.max(5, Math.min(95, ((ev.clientY - rect.top)/rect.height)*100)) } : txt));
                      };
                      window.addEventListener('mousemove', handleMove);
                      window.addEventListener('mouseup', () => window.removeEventListener('mousemove', handleMove), { once: true });
                    }}
                    onTouchStart={(e) => {
                      e.stopPropagation();
                      if (mode === 'text') setSelectedTextId(t.id);
                      const handleMove = (ev: TouchEvent) => {
                        if(!previewImageRef.current) return;
                        const rect = previewImageRef.current.getBoundingClientRect();
                        setTexts(prev => prev.map(txt => txt.id === t.id ? { ...txt, x: Math.max(5, Math.min(95, ((ev.touches[0].clientX - rect.left)/rect.width)*100)), y: Math.max(5, Math.min(95, ((ev.touches[0].clientY - rect.top)/rect.height)*100)) } : txt));
                      };
                      window.addEventListener('touchmove', handleMove, { passive: false });
                      window.addEventListener('touchend', () => window.removeEventListener('touchmove', handleMove), { once: true });
                    }}
                  >
                    {selectedTextId === t.id ? (
                      <div className="flex items-center gap-1.5 min-w-[120px]">
                        <input 
                          autoFocus 
                          value={t.text} 
                          onChange={(e) => setTexts(prev => prev.map(txt => txt.id === t.id ? { ...txt, text: e.target.value } : txt))} 
                          className="bg-transparent border-none outline-none text-center w-full placeholder:text-white/40 text-white font-bold" 
                          placeholder="Type..." 
                          onKeyDown={(e) => e.key === 'Enter' && setSelectedTextId(null)}
                        />
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            setTexts(prev => prev.filter(txt => txt.id !== t.id));
                            setSelectedTextId(null);
                          }}
                          className="p-1 rounded bg-rose-500/20 text-rose-400 hover:bg-rose-500 hover:text-white transition-all shrink-0"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    ) : t.text}
                  </div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Editor Sidebar (Right on Desktop, Bottom on Mobile) */}
      <div 
        className="w-full md:w-[380px] h-[45vh] md:h-full bg-zinc-950 md:bg-white/[0.03] backdrop-blur-3xl border-t md:border-t-0 md:border-l border-white/10 p-5 flex flex-col gap-5 z-50 overflow-y-auto shrink-0 pb-safe-bottom"
        style={{ direction: 'rtl' }}
      >
        {/* Desktop Header */}
        <div className="hidden md:flex justify-between items-center mb-1">
          <h2 className="text-white font-black uppercase tracking-widest text-md">استوديو الصور</h2>
          <button onClick={onCancel} className="p-2 text-white/50 hover:text-white rounded-full hover:bg-white/5 transition-all">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Global Toolbar Tabs */}
        <div className="flex bg-white/5 p-1 rounded-2xl border border-white/10">
          {[
            { id: 'paint', icon: Paintbrush, label: 'رسم وتوهج' },
            { id: 'crop', icon: CropIcon, label: 'قص الزوايا' },
            { id: 'text', icon: TypeIcon, label: 'نص إضافي' },
            { id: 'filters', icon: Sliders, label: 'الفلاتر' }
          ].map(tab => {
             const Icon = tab.icon;
             return (
               <button
                 key={tab.id}
                 onClick={() => setMode(tab.id as Mode)}
                 className={`flex-1 flex flex-col items-center justify-center py-2 rounded-xl transition-all ${mode === tab.id ? 'bg-white text-black shadow-md font-bold' : 'text-white/60 hover:text-white hover:bg-white/5'}`}
               >
                 <Icon className="w-4 h-4 mb-1" />
                 <span className="text-[10px]">{tab.label}</span>
               </button>
             );
          })}
        </div>

        {/* Quality Selector inside list */}
        {canFHD && (
          <div className="flex justify-between items-center py-2 px-1 border-b border-white/5">
            <span className="text-white/70 text-xs font-semibold">دقة جودة الصورة</span>
            <div className="flex bg-white/5 border border-white/10 rounded-full p-0.5">
              <button 
                onClick={() => setQuality('SD')}
                className={`px-3 py-1 rounded-full text-[10px] font-bold transition-all ${quality === 'SD' ? 'bg-white text-black shadow-xs' : 'text-white/50 hover:text-white'}`}
              >SD</button>
              <button 
                onClick={() => setQuality('FHD')}
                className={`px-3 py-1 rounded-full text-[10px] font-bold transition-all ${quality === 'FHD' ? 'bg-white text-black shadow-xs' : 'text-white/50 hover:text-white'}`}
              >FHD</button>
            </div>
          </div>
        )}

        {/* Dynamic Controls Segment Based on Active Mode */}
        <div className="flex-1">
          <AnimatePresence mode="wait">
            {mode === 'crop' && (
              <motion.div 
                key="crop-ctrl" 
                initial={{ opacity: 0, y: 10 }} 
                animate={{ opacity: 1, y: 0 }} 
                exit={{ opacity: 0, y: 10 }} 
                className="flex flex-col gap-4"
              >
                <div className="flex flex-col gap-2">
                  <span className="text-white/80 text-xs font-bold">أبعاد القص المناسبة</span>
                  <div className="flex gap-1.5 p-1 bg-white/5 rounded-full border border-white/10">
                     {[
                       { name: 'حر / Free', val: undefined, icon: <Unlock className="w-3.5 h-3.5" /> },
                       { name: 'مربع / 1:1', val: 1, icon: <Lock className="w-3.5 h-3.5" /> },
                       { name: 'ستوري / 9:16', val: 9/16, icon: <RotateCw className="w-3.5 h-3.5" /> }
                     ].map(opt => (
                       <button 
                         key={opt.name} 
                         onClick={() => setAspect(opt.val)} 
                         className={`flex-1 flex justify-center py-2 rounded-lg text-[10px] font-bold items-center gap-1 transition-all ${aspect === opt.val ? 'bg-white text-black shadow-sm' : 'text-white/60 hover:text-white'}`}
                       >
                          {opt.icon}
                          <span>{opt.name}</span>
                       </button>
                     ))}
                  </div>
                </div>

                <button 
                  onClick={applyCrop} 
                  className="w-full bg-sky-500 hover:bg-sky-600 text-white font-bold py-3.5 rounded-xl transition-all shadow-lg text-xs mt-2"
                >
                  حفظ وتطبيق القص الحالي
                </button>
              </motion.div>
            )}

            {mode === 'paint' && (
              <motion.div 
                key="paint-ctrl" 
                initial={{ opacity: 0, y: 10 }} 
                animate={{ opacity: 1, y: 0 }} 
                exit={{ opacity: 0, y: 10 }} 
                className="flex flex-col gap-4"
              >
                <div className="flex justify-between items-center px-1">
                  <span className="text-white/80 text-xs font-bold">ألوان ريشة الرسم</span>
                  <div className="flex gap-1">
                    <button 
                      onClick={() => setDrawLines(prev => prev.slice(0, -1))} 
                      className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-white/70 hover:text-white transition-all border border-white/5"
                      title="Undo"
                    >
                      <Undo2 className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => setDrawLines([])} 
                      className="p-1.5 rounded-lg bg-white/5 hover:bg-rose-500/20 text-white/70 hover:text-rose-400 transition-all border border-white/5"
                      title="Clear All"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="flex gap-1.5 bg-white/5 p-2 rounded-2xl border border-white/10 overflow-x-auto scrollbar-none items-center">
                  <label className="relative w-8 h-8 rounded-full shrink-0 border border-white/25 transition-all hover:scale-110 flex items-center justify-center cursor-pointer overflow-hidden bg-gradient-to-tr from-pink-500 via-red-500 to-yellow-500 shadow-md">
                    <Palette className="w-3.5 h-3.5 text-white drop-shadow-md pointer-events-none" />
                    <input type="color" value={activeDrawColor} onChange={(e) => setActiveDrawColor(e.target.value)} className="absolute opacity-0 w-24 h-24 cursor-pointer" />
                  </label>
                  
                  <div className="w-px h-5 bg-white/20 mx-1 shrink-0" />

                  {PREDEFINED_COLORS.map(c => (
                    <button 
                      key={c} 
                      onClick={() => setActiveDrawColor(c)} 
                      className={`w-7 h-7 rounded-full border-2 transition-all shrink-0 ${activeDrawColor === c ? 'border-white scale-110 shadow-lg' : 'border-transparent hover:scale-105'}`} 
                      style={{ backgroundColor: c }} 
                    />
                  ))}
                </div>

                <div className="flex bg-white/5 p-1 rounded-full border border-white/10">
                  <button 
                    onClick={() => setPaintTool('pencil')} 
                    className={`flex-1 py-1.5 rounded-lg text-[11px] font-bold transition-all ${paintTool === 'pencil' ? 'bg-white text-black shadow-xs' : 'text-white/50 hover:text-white'}`}
                  >
                    قلم عادي / Draw
                  </button>
                  <button 
                    onClick={() => setPaintTool('highlighter')} 
                    className={`flex-1 py-1.5 rounded-lg text-[11px] font-bold transition-all ${paintTool === 'highlighter' ? 'bg-white text-black shadow-xs' : 'text-white/50 hover:text-white'}`}
                  >
                    توهج نيون / Glow
                  </button>
                </div>
              </motion.div>
            )}

            {mode === 'text' && (
              <motion.div 
                key="text-ctrl" 
                initial={{ opacity: 0, y: 10 }} 
                animate={{ opacity: 1, y: 0 }} 
                exit={{ opacity: 0, y: 10 }} 
                className="flex flex-col gap-4"
              >
                <button 
                  onClick={addText} 
                  className="w-full py-3.5 bg-white hover:bg-white/90 text-black rounded-xl font-bold text-xs shadow-lg transition-all"
                >
                  إضافة نص جديد للكواشف
                </button>
                
                <div className="flex flex-col gap-1.5">
                  <span className="text-white/80 text-[11px] font-bold px-1">نمط ونوع الخط</span>
                  <select 
                    value={activeFont} 
                    onChange={e => {
                      setActiveFont(e.target.value);
                      if (selectedTextId) setTexts(prev => prev.map(t => t.id === selectedTextId ? { ...t, font: e.target.value } : t));
                    }}
                    className="bg-white/5 border border-white/10 rounded-xl text-white font-bold text-xs outline-none px-4 py-3 shrink-0 backdrop-blur-md cursor-pointer"
                  >
                    {FONTS.map(f => <option key={f.value} value={f.value} className="bg-zinc-950 text-white">{f.name}</option>)}
                  </select>
                </div>

                <div className="flex flex-col gap-1.5">
                  <span className="text-white/80 text-[11px] font-bold px-1">تلوين الكلمات المحددة</span>
                  <div className="flex gap-1.5 bg-white/5 p-2 rounded-2xl border border-white/10 overflow-x-auto scrollbar-none items-center">
                    <label className="relative w-8 h-8 rounded-full shrink-0 border border-white/25 transition-all hover:scale-110 flex items-center justify-center cursor-pointer overflow-hidden bg-gradient-to-tr from-pink-500 via-red-500 to-yellow-500 shadow-md">
                      <Palette className="w-3.5 h-3.5 text-white drop-shadow-md pointer-events-none" />
                      <input 
                        type="color" 
                        onChange={(e) => {
                          const val = e.target.value;
                          if (selectedTextId) setTexts(prev => prev.map(t => t.id === selectedTextId ? { ...t, color: val } : t));
                        }} 
                        className="absolute opacity-0 w-24 h-24 cursor-pointer" 
                      />
                    </label>
                    
                    <div className="w-px h-5 bg-white/20 mx-1 shrink-0" />

                    {PREDEFINED_COLORS.map(c => (
                      <button 
                        key={c} 
                        onClick={() => {
                          if (selectedTextId) setTexts(prev => prev.map(t => t.id === selectedTextId ? { ...t, color: c } : t));
                        }} 
                        className="w-7 h-7 rounded-full shrink-0 border border-transparent hover:scale-110 transition-all shadow-sm" 
                        style={{ backgroundColor: c }} 
                      />
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {mode === 'filters' && (
              <motion.div 
                key="filters-ctrl" 
                initial={{ opacity: 0, y: 10 }} 
                animate={{ opacity: 1, y: 0 }} 
                exit={{ opacity: 0, y: 10 }} 
                className="flex flex-col gap-3"
              >
                <span className="text-white/80 text-xs font-bold px-1">أنواع الفلاتر السينمائية</span>
                <div className="grid grid-cols-4 gap-1.5 max-h-[140px] md:max-h-full overflow-y-auto">
                  {FILTERS.map(f => (
                    <button 
                      key={f.name} 
                      onClick={() => setFilter(f.value)} 
                      className="flex flex-col items-center gap-1 p-1 rounded-lg hover:bg-white/5 transition-all"
                    >
                      <div className={`w-full aspect-square rounded-[8px] overflow-hidden border-2 transition-all duration-300 ${filter === f.value ? 'border-sky-400 scale-105 shadow-md' : 'border-transparent opacity-65'}`}>
                        <img src={imageSrc!} className="w-full h-full object-cover" style={{ filter: f.value }} alt={f.name} />
                      </div>
                      <span className={`text-[8px] font-black uppercase transition-all tracking-tight ${filter === f.value ? 'text-sky-300' : 'text-white/40'}`}>{f.name}</span>
                    </button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Footer Segment - Complete Action */}
        <div className="mt-auto px-1">
          <button
            onClick={finalizeImage}
            disabled={isSubmitting}
            className="w-full h-14 bg-white text-black rounded-xl flex items-center justify-center gap-2 font-black uppercase tracking-widest text-xs hover:scale-[1.01] active:scale-95 transition-all shadow-xl shadow-white/5 disabled:opacity-50 disabled:pointer-events-none"
          >
            {isSubmitting ? (
              <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" />
            ) : (
              <SubmitIconComponent className="w-5 h-5" />
            )}
            <span>{isSubmitting ? 'UPLOADING...' : (submitLabel === 'SEND' ? 'نشر الحالة الآن' : submitLabel)}</span>
          </button>
        </div>

      </div>
    </motion.div>
  );
}
