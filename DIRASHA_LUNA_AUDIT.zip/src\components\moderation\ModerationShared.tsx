import React from 'react';
import { User } from '../../types.ts';
import { Shield, ShieldAlert, ShieldCheck, User as UserIcon } from 'lucide-react';

export function UserBadge({ user, size = 'md', hideRole = false }: { user: Partial<User>, size?: 'sm' | 'md' | 'lg', hideRole?: boolean }) {
  const avatarSize = size === 'sm' ? 'w-6 h-6' : size === 'md' ? 'w-10 h-10' : 'w-16 h-16';
  const fontSize = size === 'sm' ? 'text-[10px]' : size === 'md' ? 'text-xs' : 'text-sm';
  
  return (
    <div className="flex items-center gap-3 min-w-0">
      <div className="relative shrink-0">
        <img 
          src={user.avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.displayName || 'U')}&background=random`} 
          className={`${avatarSize} rounded-full object-cover border border-white/10 aspect-square`} 
          alt={user.displayName}
          referrerPolicy="no-referrer"
        />
        {!hideRole && (user.role === 'admin' || user.role === 'developer') && (
          <div className="absolute -bottom-1 -right-1 bg-amber-500 rounded-full p-0.5 border border-[#1a1a1a]">
            <ShieldAlert className="w-2.5 h-2.5 text-white" />
          </div>
        )}
      </div>
      <div className="flex flex-col">
        <span className={`${fontSize} font-bold text-zinc-100`}>{user.displayName}</span>
        {user.username && <span className="text-[10px] text-zinc-500">@{user.username}</span>}
      </div>
    </div>
  );
}

export function StatusBadge({ status, label }: { status: string, label: string }) {
  const colors: Record<string, string> = {
    'Pending': 'bg-white/5 text-zinc-400 border-white/10',
    'Resolved': 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
    'Rejected': 'bg-rose-500/10 text-rose-500 border-rose-500/20',
    'Under Review': 'bg-white/10 text-zinc-300 border-white/20',
    'admin': 'bg-white/10 text-zinc-100 border-white/20',
    'developer': 'bg-white text-black border-white',
    'user': 'bg-white/[0.03] text-zinc-600 border-white/5',
    'banned': 'bg-rose-500/10 text-rose-500 border-rose-500/20',
    'muted': 'bg-amber-500/10 text-amber-500 border-amber-500/20'
  };

  return (
    <span className={`px-2.5 py-1 rounded-lg border text-[8px] font-black uppercase tracking-wider backdrop-blur-md transition-all ${colors[status] || colors['user']}`}>
      {label}
    </span>
  );
}
