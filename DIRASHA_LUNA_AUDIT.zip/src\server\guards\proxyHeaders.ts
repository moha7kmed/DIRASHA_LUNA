/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * BATCH-6 (B5-F1 — adversarial review): Drive-proxy header decision.
 *
 * The media proxy serves bytes fetched with the SENDER's Drive token onto the
 * app origin. The previous implementation allowed any `image/*`/`audio/*`/
 * `video/*` upstream type inline — which admits `image/svg+xml` (an attacker
 * can upload an SVG directly to their linked Drive, bypassing the app's
 * upload MIME gate, then serve it same-origin through the proxy). This guard
 * closes that: inline serving requires the type to be in the EXACT same
 * server-side allowlist the upload path enforces — no wildcard families.
 *
 * Rules (fail-closed):
 *   - Unknown / missing / manipulated / parameterized types: normalized to
 *     base type, lowercase. Inline ONLY if the base type is allowlisted.
 *   - Everything else → application/octet-stream + attachment (forced
 *     download; nosniff is set by the route for every response).
 */

export interface ProxyHeadersDecision {
  /** The Content-Type the proxy must serve (normalized). */
  contentType: string;
  /** 'inline' when the type is allowlisted; 'attachment' otherwise. */
  contentDisposition: 'inline' | 'attachment';
}

/** MIME types that may be served inline on the app origin (mirror of the upload allowlist). */
const INLINE_MIME = new Set([
  'image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif',
  'audio/mpeg', 'audio/ogg', 'audio/webm', 'audio/mp4', 'audio/wav', 'audio/aac',
  'video/mp4', 'video/webm', 'video/quicktime',
  'application/pdf',
  'text/plain',
  'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'application/zip',
]);

const OCTET_STREAM = 'application/octet-stream';

/**
 * Decide the proxy response headers for an upstream Content-Type.
 * Pure function — unit-tested for every adversarial case.
 */
export function decideProxyHeaders(upstreamContentType: string | null | undefined): ProxyHeadersDecision {
  const baseType = String(upstreamContentType ?? '')
    .split(';')[0]
    .trim()
    .toLowerCase();

  const inline = INLINE_MIME.has(baseType);
  return {
    contentType: inline ? baseType : OCTET_STREAM,
    contentDisposition: inline ? 'inline' : 'attachment',
  };
}