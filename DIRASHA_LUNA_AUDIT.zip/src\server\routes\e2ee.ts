/**
 * E2EE Key-Directory Routes (Signal-style, 1:1 DMs only — spec v1)
 * ----------------------------------------------------------------
 *   POST /api/e2ee/register        → upsert this user's public-key registration
 *                                    (optional deviceId → linked-device path, v8
 *                                    tables; absent → legacy v7 tables unchanged)
 *   GET  /api/e2ee/bundle/:userId  → fetch a peer's bundle for ALL devices
 *                                    (consumes ONE OPK PER DEVICE atomically)
 *   POST /api/e2ee/prekeys         → append a batch of fresh one-time prekeys
 *   GET  /api/e2ee/status          → self registration + remaining-OPK count
 *   GET  /api/e2ee/identity/:userId→ peer identity keys (safety-number display)
 *
 * The server is a DUMB KEY DIRECTORY: it stores and returns PUBLIC keys only.
 * Private keys never reach this code — any request field that looks like a
 * private key slot simply does not exist in the schema. All validated inputs
 * are plain base64 (std alphabet, padded); X25519 pubs decode to exactly
 * 32 bytes, Ed25519 signatures to exactly 64 bytes.
 */

import type { Express, Request, Response, NextFunction } from 'express';
import { pool } from '../database.ts';
import { logger } from '../logger.ts';
import { redisCluster } from '../websocket/redis_client.ts';
import { appendKeyChange, computeFleetCommitment } from '../services/key_transparency.ts';
import { RATE_LIMIT_RULES, type RateLimitRuleName } from '../services/rate_limiter.ts';

interface E2eeRouteDeps {
  requireAuth: (req: Request, res: Response, next: NextFunction) => void;
  /** Project 5: table-driven distributed limiter — true = rate limited (deny). */
  checkLimit: (rule: RateLimitRuleName, key: string) => Promise<boolean>;
}

/* ===================== Validation helpers (pure, unit-tested) ===================== */

/** Strict standard-alphabet, padded base64 (no URL-safe chars, no whitespace). */
const B64_STD_RE = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/;

export function isValidBase64(value: unknown): value is string {
  return typeof value === 'string' && value.length > 0 && B64_STD_RE.test(value);
}

/** Decoded byte length of a (already format-validated) base64 string, -1 if undecodable. */
export function b64DecodedLength(value: string): number {
  if (!isValidBase64(value)) return -1;
  try {
    return Buffer.from(value, 'base64').length;
  } catch {
    return -1;
  }
}

/** X25519 public key: std base64 decoding to exactly 32 bytes. */
export function isValidX25519Pub(value: unknown): boolean {
  return isValidBase64(value) && b64DecodedLength(value) === 32;
}

/** Ed25519 signature: std base64 decoding to exactly 64 bytes. */
export function isValidEd25519Signature(value: unknown): boolean {
  return isValidBase64(value) && b64DecodedLength(value) === 64;
}

/** ML-KEM-768 (FIPS-203) encapsulation key: std base64 decoding to exactly 1184 bytes. */
export const PQ_PREKEY_PUB_BYTES = 1184;
export function isValidMlKem768Pub(value: unknown): boolean {
  return isValidBase64(value) && b64DecodedLength(value) === PQ_PREKEY_PUB_BYTES;
}

/** OPK key ids are INTEGER-typed in PG: 0 .. 2^31-1. */
const MAX_KEY_ID = 2147483647;
export function isValidKeyId(value: unknown): value is number {
  return typeof value === 'number' && Number.isInteger(value) && value >= 0 && value <= MAX_KEY_ID;
}

/** user ids are VARCHAR(128) (opaque alphanumeric tokens). */
const USER_ID_RE = /^[A-Za-z0-9_-]{1,128}$/;
export function isValidUserId(value: unknown): value is string {
  return typeof value === 'string' && USER_ID_RE.test(value);
}

/** Linked-device ids are VARCHAR(64) (opaque url-safe tokens). */
const DEVICE_ID_RE = /^[A-Za-z0-9_-]{1,64}$/;
export function isValidDeviceId(value: unknown): value is string {
  return typeof value === 'string' && DEVICE_ID_RE.test(value);
}

/** Signal parity: a user may link at most 8 devices (re-registering an
 * existing device never counts against the cap). */
export const MAX_DEVICES_PER_USER = 6; // transport ceiling ~8KB: worst-case first-message fan-out (6 x 1.2KB bootstraps) must fit

export interface OpkEntry { keyId: number; pub: string }

const MAX_OPK_BATCH = 200;

/** Validate a oneTimePrekeys batch: array ≤200 of {id,pub} with unique ids. */
export function parseOpkBatch(input: unknown): { ok: true; batch: OpkEntry[] } | { ok: false; error: string } {
  if (!Array.isArray(input)) return { ok: false, error: 'oneTimePrekeys must be an array.' };
  if (input.length > MAX_OPK_BATCH) return { ok: false, error: `oneTimePrekeys batch too large (max ${MAX_OPK_BATCH}).` };
  const seen = new Set<number>();
  const batch: OpkEntry[] = [];
  for (const entry of input) {
    if (!entry || typeof entry !== 'object') return { ok: false, error: 'oneTimePrekeys entries must be objects.' };
    const { id, pub } = entry as Record<string, unknown>;
    if (!isValidKeyId(id)) return { ok: false, error: 'oneTimePrekeys id must be an integer 0..2147483647.' };
    if (!isValidX25519Pub(pub)) return { ok: false, error: 'oneTimePrekeys pub must be base64 X25519 (32 bytes).' };
    if (seen.has(id)) return { ok: false, error: 'oneTimePrekeys contains duplicate ids.' };
    seen.add(id);
    batch.push({ keyId: id, pub: pub as string });
  }
  return { ok: true, batch };
}

/** PG unique-violation → respond gracefully instead of a raw 500. */
function isUniqueViolation(err: unknown): boolean {
  return typeof err === 'object' && err !== null && (err as { code?: string }).code === '23505';
}

/* ===================== Route registration ===================== */

export function registerE2eeRoutes(app: Express, deps: E2eeRouteDeps): void {
  const { requireAuth, checkLimit } = deps;

  /** Rate limits (all per-user). Project 5: every limit routes through the
   * central RATE_LIMIT_RULES table via the distributed limiter (Redis atomic
   * EVAL; per-process Map only as a loud, last-resort outage fallback). */

  const bundleWatch = new Map<string, { count: number; resetAt: number }>();
  setInterval(() => {
    const now = Date.now();
    for (const [k, v] of bundleWatch) if (v.resetAt < now) bundleWatch.delete(k);
  }, 60000).unref();

  const E2EE_REGISTER_LIMIT = RATE_LIMIT_RULES['e2ee:register'].limit;      // 30/hour/user (multi-device logins + rekeys need headroom)
  const E2EE_BUNDLE_LIMIT = RATE_LIMIT_RULES['e2ee:bundle'].limit;          // 120/hour/user (group sender-key distribution bursts need headroom)
  const E2EE_IDENTITY_LIMIT = RATE_LIMIT_RULES['e2ee:identity'].limit;      // 60/hour/user (requester-based)
  const E2EE_STATUS_LIMIT = RATE_LIMIT_RULES['e2ee:status'].limit;          // 30/min/user  (self endpoint)
  const E2EE_PREKEYS_LIMIT = RATE_LIMIT_RULES['e2ee:prekeys'].limit;        // 10/hour/user
  const E2EE_BUNDLE_PEER_LIMIT = RATE_LIMIT_RULES['e2ee:bundlepeer'].limit; // per-target cooldown (was 3 — multi-device bypass-probes need headroom)
  const E2EE_BUNDLE_PEER_WINDOW_MS = RATE_LIMIT_RULES['e2ee:bundlepeer'].windowMs;

  const e2eeRegisterLimitHit = (userId: string): Promise<boolean> =>
    checkLimit('e2ee:register', userId);
  const e2eeBundleLimitHit = (requesterId: string): Promise<boolean> =>
    checkLimit('e2ee:bundle', requesterId);
  const e2eeIdentityLimitHit = (requesterId: string): Promise<boolean> =>
    checkLimit('e2ee:identity', requesterId);
  const e2eeStatusLimitHit = (userId: string): Promise<boolean> =>
    checkLimit('e2ee:status', userId);
  const e2eePrekeysLimitHit = (userId: string): Promise<boolean> =>
    checkLimit('e2ee:prekeys', userId);
  /** Per-target bundle-fetch cooldown: the SAME requester fetching the SAME
   * target more than 3 times in 10 minutes → blocked (stops single-peer OPK
   * draining while allowing normal multi-device/rekey flows, which need ~1
   * fetch per session init). */
  const e2eeBundlePeerCooldownHit = (requesterId: string, targetUserId: string): Promise<boolean> =>
    checkLimit('e2ee:bundlepeer', `${requesterId}:${targetUserId}`);

  /** Drain-attempt signal: WARN once when a requester crosses 50% of the
   * bundle limit within its hour window. Local-only counter (the shared
   * limiter does not expose counts); reset with the same window. */
  const BUNDLE_WARN_AT = Math.floor(E2EE_BUNDLE_LIMIT / 2) + 1; // 16th fetch in the window
  const noteBundleFetch = (requesterId: string): void => {
    const now = Date.now();
    let w = bundleWatch.get(requesterId);
    if (!w || w.resetAt < now) {
      w = { count: 0, resetAt: now + 60 * 60 * 1000 };
      bundleWatch.set(requesterId, w);
    }
    w.count++;
    if (w.count === BUNDLE_WARN_AT) {
      logger.warn(`[E2EE] bundle drain signal: requester ${requesterId} exceeded 50% of the bundle limit (${w.count}/${E2EE_BUNDLE_LIMIT} in the last hour)`);
    }
  };

  const countUnconsumedOpks = async (userId: string): Promise<number> => {
    const res = await pool.query(
      'SELECT COUNT(*)::int AS n FROM e2ee_one_time_prekeys WHERE user_id = $1 AND consumed = false',
      [userId],
    );
    return res.rows[0]?.n || 0;
  };

  /* ===================== REGISTER (upsert identity + replace unconsumed OPKs) ===================== */
  app.post('/api/e2ee/register', requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.userId;
      if (await e2eeRegisterLimitHit(userId)) {
        return res.status(429).json({ error: 'تجاوزت حد إعادة تسجيل مفاتيح التشفير المسموح. حاول لاحقاً.' });
      }

      const { identityDhPub, identitySigPub, signedPrekeyPub, prekeySignature, oneTimePrekeys, deviceId, pqPrekeyPub, pqPrekeySignature } = req.body || {};
      // Optional linked-device id: when absent the LEGACY path (v7 tables) runs
      // unchanged so old clients keep working.
      const hasDeviceId = deviceId !== undefined && deviceId !== null;
      if (hasDeviceId && !isValidDeviceId(deviceId)) {
        return res.status(400).json({ error: 'deviceId must be 1-64 url-safe characters ([A-Za-z0-9_-]).' });
      }
      if (!isValidX25519Pub(identityDhPub)) {
        return res.status(400).json({ error: 'identityDhPub must be base64 X25519 (32 bytes).' });
      }
      if (!isValidX25519Pub(identitySigPub)) {
        return res.status(400).json({ error: 'identitySigPub must be base64 Ed25519 public key (32 bytes).' });
      }
      if (!isValidX25519Pub(signedPrekeyPub)) {
        return res.status(400).json({ error: 'signedPrekeyPub must be base64 X25519 (32 bytes).' });
      }
      if (!isValidEd25519Signature(prekeySignature)) {
        return res.status(400).json({ error: 'prekeySignature must be base64 Ed25519 signature (64 bytes).' });
      }
      // PQXDH (v10): OPTIONAL ML-KEM-768 quantum prekey. Both fields arrive
      // together (or not at all — legacy devices without PQ keep the classical
      // path). The server verifies LENGTHS only; the combined
      // 'DirashaPQSPK-v1:' + spk + pq signature is verified by the CLIENT
      // against identitySigPub at bundle fetch.
      const hasPqPrekey = pqPrekeyPub !== undefined && pqPrekeyPub !== null;
      const hasPqSignature = pqPrekeySignature !== undefined && pqPrekeySignature !== null;
      if (hasPqPrekey !== hasPqSignature) {
        return res.status(400).json({ error: 'pqPrekeyPub and pqPrekeySignature must be provided together.' });
      }
      if (hasPqPrekey && !isValidMlKem768Pub(pqPrekeyPub)) {
        return res.status(400).json({ error: 'pqPrekeyPub must be base64 ML-KEM-768 (1184 bytes).' });
      }
      if (hasPqSignature && !isValidEd25519Signature(pqPrekeySignature)) {
        return res.status(400).json({ error: 'pqPrekeySignature must be base64 Ed25519 signature (64 bytes).' });
      }
      const opkCheck = parseOpkBatch(oneTimePrekeys);
      if (opkCheck.ok === false) {
        return res.status(400).json({ error: opkCheck.error });
      }

      // Transaction: upsert registration, drop stale unconsumed OPKs, insert
      // the new batch. Consumed OPKs are kept (they may still be referenced by
      // in-flight sessions) — colliding key-id rows are skipped.
      let deviceWasNew = false;
      let prevIdentity: string | null = null;
      let prevIdentityLegacy: string | null = null;
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        if (hasDeviceId) {
          const prevDeviceRow = await client.query('SELECT identity_dh_pub FROM e2ee_device_registrations WHERE user_id = $1 AND device_id = $2', [userId, deviceId]);
          prevIdentity = prevDeviceRow.rows[0]?.identity_dh_pub || null;
          // ── Linked-device path (v8 tables) ──
          // Serialize per-user device registrations so the 8-device cap cannot
          // be raced past by concurrent first registrations of new devices.
          await client.query('SELECT pg_advisory_xact_lock(hashtext($1)::bigint)', [userId]);
          const existing = await client.query(
            'SELECT device_id FROM e2ee_device_registrations WHERE user_id = $1',
            [userId],
          );
          const isReRegistration = existing.rows.some((r: any) => r.device_id === deviceId);
          deviceWasNew = !isReRegistration;
          if (!isReRegistration && existing.rows.length >= MAX_DEVICES_PER_USER) {
            // Fleet saturated: evict the OLDEST device (registered_at) so live
            // devices can always join — dead battery-ghost devices must never
            // choke the fleet (SEC finding #7 + live-battery finding).
            const oldest = await client.query(
              'SELECT device_id FROM e2ee_device_registrations WHERE user_id = $1 ORDER BY registered_at ASC LIMIT 1',
              [userId],
            );
            const evictId = oldest.rows[0]?.device_id;
            if (evictId) {
              await client.query('DELETE FROM e2ee_device_registrations WHERE user_id = $1 AND device_id = $2', [userId, evictId]);
              await client.query('DELETE FROM e2ee_device_one_time_prekeys WHERE user_id = $1 AND device_id = $2', [userId, evictId]);
              logger.warn(`[E2EE] evicted oldest device ${evictId} for user ${userId} (fleet cap)`);
            }
          }
          await client.query(
            `INSERT INTO e2ee_device_registrations
               (user_id, device_id, identity_dh_pub, identity_sig_pub, signed_prekey_pub, prekey_signature, pq_prekey_pub, pq_prekey_signature, registered_at)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, now())
             ON CONFLICT (user_id, device_id) DO UPDATE
             SET identity_dh_pub = $3, identity_sig_pub = $4, signed_prekey_pub = $5,
                 prekey_signature = $6, pq_prekey_pub = $7, pq_prekey_signature = $8, registered_at = now()`,
            // PQ columns are nullable: absent on the request → NULL (legacy
            // classical device). A re-registration WITH PQ keys replaces a
            // NULL pair; one WITHOUT them clears a stale pair (keys always
            // mirror the latest registration).
            [userId, deviceId, identityDhPub, identitySigPub, signedPrekeyPub, prekeySignature,
              hasPqPrekey ? pqPrekeyPub : null, hasPqSignature ? pqPrekeySignature : null],
          );
          await client.query(
            'DELETE FROM e2ee_device_one_time_prekeys WHERE user_id = $1 AND device_id = $2 AND consumed = false',
            [userId, deviceId],
          );
          if (opkCheck.batch.length > 0) {
            const values = opkCheck.batch.map((_, i) => `($1, $2, $${i * 2 + 3}, $${i * 2 + 4}, false)`).join(', ');
            const params: any[] = [userId, deviceId];
            for (const opk of opkCheck.batch) params.push(opk.keyId, opk.pub);
            await client.query(
              `INSERT INTO e2ee_device_one_time_prekeys (user_id, device_id, key_id, public_key, consumed)
               VALUES ${values} ON CONFLICT (user_id, device_id, key_id) DO NOTHING`,
              params,
            );
          }
        } else {
          const prevLegacyRow = await client.query('SELECT identity_dh_pub FROM e2ee_registrations WHERE user_id = $1', [userId]);
          prevIdentityLegacy = prevLegacyRow.rows[0]?.identity_dh_pub || null;
          // ── Legacy path (v7 tables) — unchanged behavior for old clients ──
          await client.query(
            `INSERT INTO e2ee_registrations (user_id, identity_dh_pub, identity_sig_pub, signed_prekey_pub, prekey_signature, registered_at)
             VALUES ($1, $2, $3, $4, $5, now())
             ON CONFLICT (user_id) DO UPDATE
             SET identity_dh_pub = $2, identity_sig_pub = $3, signed_prekey_pub = $4,
                 prekey_signature = $5, registered_at = now()`,
            [userId, identityDhPub, identitySigPub, signedPrekeyPub, prekeySignature],
          );
          await client.query(
            'DELETE FROM e2ee_one_time_prekeys WHERE user_id = $1 AND consumed = false',
            [userId],
          );
          if (opkCheck.batch.length > 0) {
            const values = opkCheck.batch.map((_, i) => `($1, $${i * 2 + 2}, $${i * 2 + 3}, false)`).join(', ');
            const params: any[] = [userId];
            for (const opk of opkCheck.batch) params.push(opk.keyId, opk.pub);
            await client.query(
              `INSERT INTO e2ee_one_time_prekeys (user_id, key_id, public_key, consumed)
               VALUES ${values} ON CONFLICT (user_id, key_id) DO NOTHING`,
              params,
            );
          }
        }
        await client.query('COMMIT');
      } catch (txErr) {
        await (client as any).query('ROLLBACK').catch(() => {});
        throw txErr;
      } finally {
        (client as any).release();
      }

      // KT (Project 2): transparency log entry for every identity/fleet change.
      // Commitment = hash of the user's CURRENT fleet (legacy row + all devices).
      try {
        const fleet = await pool.query(
          `SELECT 'default' AS "deviceId", identity_dh_pub AS "identityDhPub", identity_sig_pub AS "identitySigPub" FROM e2ee_registrations WHERE user_id = $1
           UNION ALL
           SELECT device_id AS "deviceId", identity_dh_pub AS "identityDhPub", identity_sig_pub AS "identitySigPub" FROM e2ee_device_registrations WHERE user_id = $1`,
          [userId],
        );
        void appendKeyChange(userId, computeFleetCommitment(fleet.rows)).catch(() => {});
      } catch (ktErr) {
        logger.warn('[KT] append failed:', ktErr?.message);
      }

      // Identity re-registration (same device, NEW identity keys) = safety-
      // number change: proactively push e2ee:rekey to DM partners so they
      // drop stale sessions immediately (the client listener clears the
      // peer session + raises the persistent warning banner).
      const identityChanged = !!(hasDeviceId && prevIdentity && prevIdentity !== identityDhPub) ||
        !!(!hasDeviceId && prevIdentityLegacy && prevIdentityLegacy !== identityDhPub);
      if (identityChanged) {
        try {
          const partners2 = await pool.query(
            `SELECT DISTINCT cm2.user_id AS partner_id
               FROM chat_members cm1
               JOIN chat_members cm2 ON cm2.chat_id = cm1.chat_id AND cm2.user_id <> cm1.user_id
               JOIN chats c ON c.id = cm1.chat_id AND c.type = 'one-to-one'
              WHERE cm1.user_id = $1`,
            [userId],
          );
          for (const p of partners2.rows) {
            void redisCluster.publish('user:updates:' + p.partner_id, {
              event: 'e2ee:rekey',
              payload: { userId },
            }).catch(() => {});
          }
          logger.warn(`[E2EE] identity rekey: notified ${partners2.rows.length} partners of ${userId}`);
        } catch (notifyErr) {
          logger.warn('[E2EE] rekey notify failed:', notifyErr?.message);
        }
      }

      // Multi-device: when a NEW device registers, DM partners must refresh
      // their peer-device caches — otherwise in-flight sends target only the
      // stale device fleet and the new device receives no envelope.
      if (deviceWasNew) {
        try {
          const partners = await pool.query(
            `SELECT DISTINCT cm2.user_id AS partner_id
               FROM chat_members cm1
               JOIN chat_members cm2 ON cm2.chat_id = cm1.chat_id AND cm2.user_id <> cm1.user_id
               JOIN chats c ON c.id = cm1.chat_id AND c.type = 'one-to-one'
              WHERE cm1.user_id = $1`,
            [userId],
          );
          for (const p of partners.rows) {
            void redisCluster.publish('user:updates:' + p.partner_id, {
              event: 'e2ee:devices_changed',
              payload: { userId },
            }).catch(() => {});
          }
          logger.info(`[E2EE] devices_changed notified ${partners.rows.length} DM partners of ${userId}`);
          } catch (notifyErr) {
          logger.warn('[E2EE] devices_changed notify failed:', notifyErr?.message);
        }
      }
      // WS 'e2ee:rekey' fan-out intentionally omitted: ws_server.ts exports no
      // standalone broadcast-to-user helper (only the WebSocketChatServer class)
      // and refactoring it is out of scope — the client protocol tolerates
      // missing rekey events (next send re-inits the session).

      logger.info(`[E2EE] User ${userId} registered ${hasDeviceId ? `device ${deviceId} keys` : 'identity keys'} (${opkCheck.batch.length} OPKs)`);
      res.status(200).json({ ok: true });
    } catch (err: any) {
      if (isUniqueViolation(err)) {
        return res.status(409).json({ error: 'E2EE_KEY_ID_CONFLICT' });
      }
      logger.error('[E2EE] register failed:', err?.message);
      res.status(500).json({ error: 'تعذر تسجيل مفاتيح التشفير. حاول مجدداً.' });
    }
  });

  /* ===================== BUNDLE (atomic OPK consumption) ===================== */
  app.get('/api/e2ee/bundle/:userId', requireAuth, async (req: Request, res: Response) => {
    try {
      const targetUserId = String(req.params.userId || '');
      if (!isValidUserId(targetUserId)) {
        return res.status(400).json({ error: 'معرّف مستخدم غير صالح.' });
      }
      const requesterId = req.user!.userId;
      if (await e2eeBundleLimitHit(requesterId)) {
        return res.status(429).json({ error: 'تجاوزت حد جلب حزم المفاتيح المسموح. حاول لاحقاً.' });
      }
      if (await e2eeBundlePeerCooldownHit(requesterId, targetUserId)) {
        return res.status(429).json({ error: 'تجاوزت حد جلب مفاتيح هذا المستخدم.' });
      }
      noteBundleFetch(requesterId);
      logger.info(`[E2EE] bundle fetch ${requesterId} → ${targetUserId}`);

      // Gather ALL devices of the target: the legacy v7 registration (reported
      // as deviceId 'default', first) plus every v8 device-table row ordered by
      // registration time. One bundle fetch covers the whole device fleet.
      const legacyRes = await pool.query(
        'SELECT identity_dh_pub, identity_sig_pub, signed_prekey_pub, prekey_signature FROM e2ee_registrations WHERE user_id = $1',
        [targetUserId],
      );
      const deviceRes = await pool.query(
        `SELECT device_id, identity_dh_pub, identity_sig_pub, signed_prekey_pub, prekey_signature,
                pq_prekey_pub, pq_prekey_signature
         FROM e2ee_device_registrations WHERE user_id = $1
         ORDER BY registered_at DESC LIMIT 6`,
        [targetUserId],
      );
      const legacyRow = deviceRes.rows.length > 0 ? null : legacyRes.rows[0]; // ghost 'default' excluded once real devices exist
      if (!legacyRow && deviceRes.rows.length === 0) {
        return res.status(404).json({ registered: false });
      }

      // Atomic one-shot OPK consumption PER DEVICE: the FOR UPDATE SKIP LOCKED
      // subquery guarantees concurrent bundle fetches never hand out the same
      // OPK for the same device.
      const consumeLegacyOpk = async (uid: string): Promise<{ id: number; pub: string } | null> => {
        const r = await pool.query(
          `UPDATE e2ee_one_time_prekeys
           SET consumed = true, consumed_at = now()
           WHERE id = (
             SELECT id FROM e2ee_one_time_prekeys
             WHERE user_id = $1 AND consumed = false
             ORDER BY id LIMIT 1 FOR UPDATE SKIP LOCKED
           )
           RETURNING key_id, public_key`,
          [uid],
        );
        const o = r.rows[0];
        return o ? { id: o.key_id, pub: o.public_key } : null;
      };
      const consumeDeviceOpk = async (uid: string, devId: string): Promise<{ id: number; pub: string } | null> => {
        const r = await pool.query(
          `UPDATE e2ee_device_one_time_prekeys
           SET consumed = true, consumed_at = now()
           WHERE id = (
             SELECT id FROM e2ee_device_one_time_prekeys
             WHERE user_id = $1 AND device_id = $2 AND consumed = false
             ORDER BY id LIMIT 1 FOR UPDATE SKIP LOCKED
           )
           RETURNING key_id, public_key`,
          [uid, devId],
        );
        const o = r.rows[0];
        return o ? { id: o.key_id, pub: o.public_key } : null;
      };

      const devices: Array<{
        deviceId: string;
        identityDhPub: string;
        identitySigPub: string;
        signedPrekeyPub: string;
        prekeySignature: string;
        opk: { id: number; pub: string } | null;
        /** PQXDH: true iff the device registered a quantum prekey (v10 columns). */
        pq: boolean;
        pqPrekeyPub?: string;
        pqPrekeySignature?: string;
      }> = [];
      if (legacyRow) {
        devices.push({
          deviceId: 'default',
          identityDhPub: legacyRow.identity_dh_pub,
          identitySigPub: legacyRow.identity_sig_pub,
          signedPrekeyPub: legacyRow.signed_prekey_pub,
          prekeySignature: legacyRow.prekey_signature,
          opk: await consumeLegacyOpk(targetUserId),
          pq: false, // legacy v7 table carries no PQ columns — classical device
        });
      }
      for (const d of deviceRes.rows) {
        devices.push({
          deviceId: d.device_id,
          identityDhPub: d.identity_dh_pub,
          identitySigPub: d.identity_sig_pub,
          signedPrekeyPub: d.signed_prekey_pub,
          prekeySignature: d.prekey_signature,
          opk: await consumeDeviceOpk(targetUserId, d.device_id),
          // NULL columns → pre-PQ (legacy) device: the initiator keeps the
          // classical path for it; non-null → the initiator MUST run hybrid.
          pq: !!(d.pq_prekey_pub && d.pq_prekey_signature),
          ...(d.pq_prekey_pub && d.pq_prekey_signature
            ? { pqPrekeyPub: d.pq_prekey_pub, pqPrekeySignature: d.pq_prekey_signature }
            : {}),
        });
      }

      res.status(200).json({
        registered: true,
        devices,
        // Legacy flat fields (primary = 'default' when present, else the oldest
        // device) keep pre-multi-device clients working unchanged.
        identityDhPub: devices[0].identityDhPub,
        identitySigPub: devices[0].identitySigPub,
        signedPrekeyPub: devices[0].signedPrekeyPub,
        prekeySignature: devices[0].prekeySignature,
        opk: devices[0].opk,
        pq: devices[0].pq,
        ...(devices[0].pqPrekeyPub ? { pqPrekeyPub: devices[0].pqPrekeyPub } : {}),
        ...(devices[0].pqPrekeySignature ? { pqPrekeySignature: devices[0].pqPrekeySignature } : {}),
      });
    } catch (err: any) {
      logger.error('[E2EE] bundle fetch failed:', err?.message);
      res.status(500).json({ error: 'تعذر جلب حزمة المفاتيح. حاول مجدداً.' });
    }
  });

  /* ===================== PREKEYS (append batch) ===================== */
  app.post('/api/e2ee/prekeys', requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.userId;
      if (await e2eePrekeysLimitHit(userId)) {
        return res.status(429).json({ error: 'تجاوزت حد إضافة مفاتيح الطلمبة المسموح. حاول لاحقاً.' });
      }
      const { oneTimePrekeys } = req.body || {};
      const opkCheck = parseOpkBatch(oneTimePrekeys);
      if (opkCheck.ok === false) {
        return res.status(400).json({ error: opkCheck.error });
      }
      if (opkCheck.batch.length === 0) {
        return res.status(400).json({ error: 'oneTimePrekeys must contain at least one key.' });
      }

      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const values = opkCheck.batch.map((_, i) => `($1, $${i * 2 + 2}, $${i * 2 + 3}, false)`).join(', ');
        const params: any[] = [userId];
        for (const opk of opkCheck.batch) params.push(opk.keyId, opk.pub);
        await client.query(
          `INSERT INTO e2ee_one_time_prekeys (user_id, key_id, public_key, consumed)
           VALUES ${values} ON CONFLICT (user_id, key_id) DO NOTHING`,
          params,
        );
        await client.query('COMMIT');
      } catch (txErr) {
        await (client as any).query('ROLLBACK').catch(() => {});
        throw txErr;
      } finally {
        (client as any).release();
      }

      const opkRemaining = await countUnconsumedOpks(userId);
      res.status(200).json({ ok: true, opkRemaining });
    } catch (err: any) {
      if (isUniqueViolation(err)) {
        return res.status(409).json({ error: 'E2EE_KEY_ID_CONFLICT' });
      }
      logger.error('[E2EE] prekeys append failed:', err?.message);
      res.status(500).json({ error: 'تعذر إضافة مفاتيح الطلمبة. حاول مجدداً.' });
    }
  });

  /* ===================== STATUS (self, no consumption) ===================== */
  app.get('/api/e2ee/status', requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.userId;
      if (await e2eeStatusLimitHit(userId)) {
        return res.status(429).json({ error: 'تجاوزت حد طلبات حالة التشفير المسموح. حاول لاحقاً.' });
      }
      const reg = await pool.query('SELECT 1 FROM e2ee_registrations WHERE user_id = $1', [userId]);
      const opkRemaining = await countUnconsumedOpks(userId);
      res.status(200).json({ registered: reg.rows.length > 0, opkRemaining });
    } catch (err: any) {
      logger.error('[E2EE] status failed:', err?.message);
      res.status(500).json({ error: 'تعذر جلب حالة التشفير.' });
    }
  });

  /* ===================== IDENTITY (peer, safety number — no OPK touch) ===================== */
  app.get('/api/e2ee/identity/:userId', requireAuth, async (req: Request, res: Response) => {
    try {
      const targetUserId = String(req.params.userId || '');
      if (!isValidUserId(targetUserId)) {
        return res.status(400).json({ error: 'معرّف مستخدم غير صالح.' });
      }
      if (await e2eeIdentityLimitHit(req.user!.userId)) {
        return res.status(429).json({ error: 'تجاوزت حد جلب هويات المستخدمين المسموح. حاول لاحقاً.' });
      }
      // Primary identity = the OLDEST registration across legacy + device rows
      // (MIN(registered_at)). This keeps safety numbers STABLE while any device
      // other than the first-registered one re-keys.
      const legacyRes = await pool.query(
        'SELECT identity_dh_pub, identity_sig_pub, registered_at FROM e2ee_registrations WHERE user_id = $1',
        [targetUserId],
      );
      const deviceRes = await pool.query(
        'SELECT identity_dh_pub, identity_sig_pub, registered_at FROM e2ee_device_registrations WHERE user_id = $1',
        [targetUserId],
      );
      const legacyRow = legacyRes.rows[0];
      if (!legacyRow && deviceRes.rows.length === 0) {
        return res.status(404).json({ registered: false });
      }
      let primary = legacyRow as any;
      for (const d of deviceRes.rows) {
        if (!primary || new Date(d.registered_at) < new Date(primary.registered_at)) primary = d;
      }
      const deviceCount = (legacyRow ? 1 : 0) + deviceRes.rows.length;
      res.status(200).json({
        registered: true,
        identityDhPub: primary.identity_dh_pub,
        identitySigPub: primary.identity_sig_pub,
        deviceCount,
      });
    } catch (err: any) {
      logger.error('[E2EE] identity fetch failed:', err?.message);
      res.status(500).json({ error: 'تعذر جلب هوية المستخدم.' });
    }
  });
}
