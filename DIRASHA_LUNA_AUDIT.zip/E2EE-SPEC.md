# Dirasha E2EE Spec v1 — Signal-style (X3DH + Double Ratchet), 1:1 DMs only

Scope: 1:1 direct messages ONLY. Groups = phase 2 (sender keys). Media/attachment BYTES stay
server-stored (phase 2); only text `content` is encrypted in v1. Polls/attachments metadata
(attachment URLs, poll payloads) remain plaintext metadata in v1 — documented trade-off.

## Identity & keys (per user account, v1 = one active device identity)
- IK_dh: X25519 keypair — identity DH key (b64url NOT used; plain base64 std everywhere).
- IK_sig: Ed25519 keypair — identity signing key.
- SPK: X25519 signed prekey, signed by IK_sig over UTF8("DirashaSPK-v1:" + b64(spkPub)).
- OPKs: 100 X25519 one-time prekeys, ids = integers 1..N per registration batch.

## Server (Agent S)
New file src/server/routes/e2ee.ts exporting `registerE2eeRoutes(app)`, mounted in server.ts
after storage routes: `registerE2eeRoutes(app)`. Migration v7 in src/server/database.ts
(append to existing migrations array, next version number after the last one):
```sql
CREATE TABLE IF NOT EXISTS e2ee_registrations (
  user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  identity_dh_pub TEXT NOT NULL,
  identity_sig_pub TEXT NOT NULL,
  signed_prekey_pub TEXT,          -- nullable only for legacy rows; new rows must have it
  prekey_signature TEXT NOT NULL,
  registered_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS e2ee_one_time_prekeys (
  id BIGSERIAL PRIMARY KEY, user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  key_id INTEGER NOT NULL, public_key TEXT NOT NULL,
  consumed BOOLEAN NOT NULL DEFAULT false, consumed_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, key_id)
);
```
Endpoints (all requireAuth, JSON; validate sizes: pubs 32B b64, sigs 64B b64, <=200 OPKs/batch):
- POST /api/e2ee/register  body {identityDhPub, identitySigPub, signedPrekeyPub, prekeySignature, oneTimePrekeys:[{id,pub}]}
  → upsert registration, DELETE existing unconsumed OPKs then insert batch (transaction).
  After success: emit WS event 'e2ee:rekey' to that user's other sockets (ws server export a
  broadcastToUser(userId, event, payload) if exists, else skip — do NOT break build).
  Respond {ok:true}.
- GET /api/e2ee/bundle/:userId → { registered:false } 404-style if none. Else atomically consume
  one OPK: UPDATE ... WHERE id = (SELECT id FROM e2ee_one_time_prekeys WHERE user_id=$1 AND
  consumed=false ORDER BY id LIMIT 1 FOR UPDATE SKIP LOCKED) SET consumed=true, consumed_at=now()
  RETURNING key_id, public_key; if no row → opk:null. Response:
  { registered:true, identityDhPub, identitySigPub, signedPrekeyPub, prekeySignature, opk:{id,pub}|null }
- POST /api/e2ee/prekeys body {oneTimePrekeys:[{id,pub}]} → append batch (max 200), respond {ok, opkRemaining}.
- GET /api/e2ee/status → { registered, opkRemaining } for SELF (no consumption).
- GET /api/e2ee/identity/:userId → { registered, identityDhPub, identitySigPub } (no OPK consumption; for safety number).
- Rate limit register: 6/hour/user (reuse existing rate-limit helper if any; else simple PG counter in auth_logs-like table or in-memory Map keyed user+hour).
- NEVER return private keys; server stores public keys only.

## Client lib (Agent C) — src/lib/e2ee/
- Deps: add @noble/ciphers, @noble/curves, @noble/hashes (latest 1.x) to package.json dependencies.
- types.ts: SessionState, Envelope, KeyPair, persisted shapes. Engine class in engine.ts.
- store.ts: KVStore interface { get(k), set(k,v), del(k), keys() } with MemoryKVStore + IndexedDBKVStore
  ('dirasha-e2ee', object stores: 'kv' only — store sessions/identity/opkPrivs as kv entries:
  'identity', 'opk:<keyId>', 'session:<peerUserId>').
- Crypto primitives (crypto.ts): x25519 (noble/curves), ed25519 sign/verify (noble/curves), HKDF-SHA256,
  HMAC-SHA256 (@noble/hashes), ChaCha20-Poly1305 (@noble/ciphers) with random 12B nonce.
- Constants: KDF_RK: HKDF(ikm=dhOut, salt=rk, info=ASCII 'DirashaRoot-v1', 64B) → rk'=out[0:32], ckS'=out[32:64]... 
  NOTE: standard Double Ratchet KDF_RK returns (rk', ck') where ck' seeds BOTH chains — on DH ratchet step,
  each party derives its own chain from same (rk', ck'): sender-side uses ck' as new ckS... NO — follow Signal spec:
  KDF_RK(rk, dh) → (rk', ck') 64 bytes; rk'=out[0..32], ck'=out[32..64]. After a DH ratchet step the NEW rk'/ck' pair
  is written to state; ck' becomes ckR (if we received first) or ckS (if we sent first) per Double Ratchet algorithm
  (Signal docs). Follow Signal's Double Ratchet spec exactly.
  KDF_CK(ck): mk = HMAC(ck, 0x01), ck' = HMAC(ck, 0x0X); MAX_SKIP=2000.
- X3DH initiator (on first send to peer without session): fetch bundle, verify prekeySignature with IK_sig
  (verify Ed25519 over UTF8('DirashaSPK-v1:'+b64(spkPub))), then DH1=DH(IK_dh_privA, SPK_B), DH2=DH(EK_A_priv, IK_dh_B_pub),
  DH3=DH(EK_A_priv, SPK_B), DH4=DH(EK_A_priv, OPK_B_pub) if opk. SK=HKDF(F || 0xFF...0xFF if no-DH4? NO —
  Signal concatenates DH1||DH2||DH3||DH4 (omit DH4 if absent), F=32×0xFF when OPK absent per spec,
  salt=zeros(32), info='DirashaX3DH-v1', 32B root key. AD = b64(IK_dh_pubA) || ':' || b64(IK_dh_pubB) string (canonical: sorted? NO — AD = initiator_ik_pub + ':' + responder_ik_pub in envelope order).
  Generate EK fresh per session init. Store session BEFORE sending (persist first, then emit).
  Persist mapping opkId → keep opkPriv for responder side... (responder needs own OPK priv).
- Responder side: on first received DIR1 with x3dh block: recompute DH1' = DH(SPK_priv_B, IK_dh_A_pub),
  DH2' = DH(IK_dh_priv_B, EK_A_pub), DH3' = DH(SPK_priv_B, EK_A_pub), DH4' = DH(opkPriv[opkId], EK_A_pub) if opkId present;
  SK = HKDF(F||... same derivation) → session; then process envelope with ratchet.
  Note: responder must ALSO have their own SPK privkey locally ('spkPriv' kv entry).
  Opk privs never leave device; delete OPK priv after first successful use? Keep (harmless).
- Double Ratchet state per peer: { rk, dhSelf{priv,pub}, dhRemote, ckS, ckR, nS, nR, pn, skipped: Record<'dhB64:n', mk> },
  cap skipped at 2000 (evict oldest by insertion order).
- Wire format: content = 'DIR1:' + base64(JSON.stringify({ v:1, ik: b64(sender IK_dh_pub), x3dh?: { ek: b64, opkId?: number },
  hdr: { dh: b64(current dhSelf.pub), pn, n }, iv: b64(12B), ct: b64 })). AD = UTF8(`${v}|${ik}|${dh}|${pn}|${n}`).
  AEAD: chacha20poly1305(mk, nonce=iv). AAD must EXACTLY equal on both sides: `${v}|${ik}|${hdr.dh}|${hdr.pn}|${hdr.n}`.
  'ik' = sender's IDENTITY DH pub (constant across session), hdr.dh = current ratchet pub.
- Decrypt path: parse DIR1 → if x3dh present and no session → build session (responder) → ratchetDecrypt.
  RatchetDecrypt: if hdr.dh != dhRemote → new receiver chain: pn,ckR skip-store, rk/ckR = KDF_RK(rk, DH(dhSelf.priv, hdr.dh)), dhRemote=hdr.dh, n=0, pn=nS. Then try skipped keys (hdr.dh:n) first, else derive mk=KDF_CK(ckR, n) advancing.
  On success: persist session. On failure: DO NOT persist advancement beyond failed index (keep skipped-key fallback; errors propagate).
  IMPORTANT decrypt idempotency: failed decrypt must not destroy state — derive keys WITHOUT committing chain advance until AEAD verify succeeds (clone state or derive-then-commit).
  Cap: if n > lastChecked+MAX_SKIP → error.
- Safety number: sha256(UTF8(sorted([ikA, ikB]).join(':'))) hex → take first 30 hex chars → 60 digits via
  parseInt per 5-hex-chunk % 100000 padded — deterministic, must match on both devices.
  (Any deterministic scheme OK as long as it's implemented identically on both sides — single shared function.)
- Failure UX contract (for Agent I): engine throws typed errors:
  PeerNotRegisteredError, DecryptFailedError, SessionMissingError, TamperedError.
- Engine API for Agent I:
  - ensureRegistered(): Promise<{registered:boolean}> — creates identity/SPK/OPKs if missing, POSTs /api/e2ee/register; idempotent.
  - isRegistered(): Promise<boolean>
  - getStatus(): {registered, opkRemaining} (fetch /api/e2ee/status; replenish OPKs if <20, fire-and-forget).
  - hasSession(peerId): Promise<boolean>
  - encryptMessage(peerId, plaintext): Promise<{content:string}> returns 'DIR1:...' string (handles session init + X3DH + ratchet).
  - decryptMessage(peerId, content): Promise<{plaintext:string} | {error:string}> — DIR1 parse; non-DIR1 passthrough {plaintext:content}.
  - getSafetyNumber(peerId): Promise<string> — fetches /api/e2ee/identity/:userId, 60-digit string.
  - PeerNotRegisteredError when bundle 404 {registered:false}.
  - All engine calls take an authHeaders() provider function ( injected token provider so lib has no auth coupling: `new DirashaE2EE({ authHeaders })`).
  - Replenish: after successful register/bundle ops, if opkRemaining<20 fire-and-forget POST /api/e2ee/prekeys with new batch (ids = timestamp-based unique ints).
  - Persist EVERY mutation of identity/session/opk state immediately (crash-safe).
  - No global singletons required; App will hold one engine instance (Agent I wires it).
  - Multi-device v1 limitation: re-registration replaces keys; old sessions fail → DecryptFailedError; UI shows rekey hint.

## Integration (Agent I — later)
- Registration: after login/auth:ready in App.tsx, `ensureRegistered()` fire-and-forget.
- Eligibility: chat is 1:1 DM (has otherMember) AND peer registered.
- Send wrap in handleSendMessage: if eligible DM and content non-empty: try encrypt → content='DIR1:...';
  PeerNotRegistered → send plaintext as today; other errors → toast 'تعذر تشفير الرسالة' + abort send.
  type stays 'text'.
- Receive: 'msg:new' handler: if content startsWith('DIR1:') → decrypt → replace content (plaintext) else
  placeholder '🔒 تعذر فك تشفير الرسالة' + keep ciphertext in msg.e2eeRaw for retry. msg.e2ee = true flag.
- History fetch path (ChatWindow/App fetches /api/chats/:chatId/messages): after fetch, decrypt any DIR1
  contents async then apply — decrypt ONLY in the chat-window path.
- Previews (ChatSidebar): DIR1: prefix → display '🔒 رسالة مشفرة' WITHOUT decrypting (never decrypt in sidebar).
- Render guard in ChatWindow renderFormattedText/renderMessageContent: content DIR1: → render lock placeholder (until decrypted content present).
- Safety number UI: in chat header menu / DM info: 'التشفير' info modal: safety number (60 digits, 6 blocks), copy button, plus explanation text (Arabic).
- Badge: DM chat header shows lock icon when peer registered & session active; tooltip 'التشفير طرف-لطرف مفعّل'.
- 'e2ee:rekey' WS event → clear local session for that peer (engine.deleteSession) → next send re-inits.
- Edit path: editing a DIR1 message encrypts new content the same way (or disable edit for E2EE msgs v1 — choose: allow, encrypt replacement).
- Search: server-side search won't match DIR1 ciphertext — acceptable (client-side filter for E2EE chats optional, skip v1).

## Phase 2 module contracts (built by agents M/G/B as pure modules; wiring by lead)

- Media (src/lib/e2ee/media.ts): encryptAttachment(bytes,mime,name) -> {blob,payload{attId,key,iv,mime,name,size,sha256}}; encKey=HKDF(key, info=DirashaMedia-v1); AEAD=chacha20poly1305; AAD=DirashaMedia-v1|<attId>; encrypted blob uploads as application/octet-stream; decryptAttachment(payload,bytes); buildEncryptedPayload(text,files) / parseEncryptedPayload -> {kind:dirasha-msg-v1,text,files} JSON rides INSIDE the DIR1 envelope (metadata never server-visible).
- Groups (src/lib/e2ee/group.ts): Signal Sender Keys per (member,group); symmetric chain mk_n=HKDF(sk, info=DirashaGroupChain-v1|n); wire DIRG1: {v,skId,n,iv,ct} AAD=v|groupId|skId|n; distribution via pairwise DIR1 ctrl payloads kind=dirasha-ctrl-v1; rotation on membership change; kv keys gsk:<groupId> (own) + gmi:<groupId>:<peerId> (members).
- Backup (src/lib/e2ee/backup.ts): export decrypted JSON -> scrypt(passphrase,salt) -> chacha20poly1305 -> .dirasha-backup (magic DIRBK1:); importChats verifies + restores; passphrase never stored.
- Engine v1.1: canonical X3DH F (FF32 no-OPK / ZERO32 with-OPK) + NamespacedKVStore (namespace=account uid) for multi-account isolation.
