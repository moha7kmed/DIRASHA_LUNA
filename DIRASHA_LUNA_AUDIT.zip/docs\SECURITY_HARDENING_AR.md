# ديراشة — سجل التقوية الأمنية (أكتوبر 2026)

النطاق: تمريرة التقوية P0–P4. المنهجية: `CHAT_APP_SECURITY_SKILLS.md`.

## 1. الملخص

- 11 بنداً أمنياً مغلقاً ومُتحقق منه.
- tsc = 0، بناء EXIT 0، 9/9 اختبارات آلية، 6/6 اختبارات WS حية، npm audit = 0 ثغرات.
- 4 بنود متبقية موثقة صراحة (E2EE تنفيذاً، CI، ضبط SameSite عند النشر، اختبار اختراق خارجي).

## 2. البنود المغلقة

| # | البند | الخطورة | الإصلاح | التحقق |
|---|---|---|---|---|
| 1 | WS بلا حد frame (افتراضي 100MiB) | 🔴 | maxPayload 128KB | حي: frame 200KB → إغلاق 1009 |
| 2 | WS بلا rate limit | 🔴 | token-bucket لكل مستخدم+حدث + طرد بعد 3 مخالفات | حي: flood 45 → throttle ثم قطع |
| 3 | رؤوس أمان غايبة + CORS `*` | 🔴 | CSP + HSTS + nosniff + CORS allowlist | حي: الرؤوس الستة تظهر |
| 4 | التوكنات في localStorage | 🔴 | HttpOnly cookie + خزنة ذاكرة + هجرة آلية | حي: Set-Cookie HttpOnly + اختبار آلي |
| 5 | بلا حد لطول الرسالة | 🟡 | 8000 حرف (WS+REST) | حي: 9000 → رفض عربي |
| 6 | توكن كامل في URL | 🟡 | media token 120s GET-scoped | حي: GET=200/POST=401/كامل=401 |
| 7 | بلا حد اتصالات | 🟡 | cap 6/مستخدم | حي: السابع → 403 |
| 8 | بلا Origin gate لـ WS | 🟡 | فحص Origin على الـ upgrade | كود؛ مربوط بـ ALLOWED_ORIGINS |
| 9 | بحث بلا rate limit | 🟢 | 60/دقيقة | كود |
| 10 | snapshot نصي | 🟡 | تشفير ENC1 (AES-256-GCM) | حي + اختبار roundtrip/tamper |
| 11 | 6 ثغرات اعتماديات (1 critical) | 🔴 | npm audit fix | re-audit = 0 |

## 3. البنية بسبع طبقات

```
L7 العملية   │ git + تدوير أسرار سابقة الكشف (يدوي)
L6 المراقبة  │ سجلات أمنية + audit trail
L5 E2EE      │ تصميم معتمد — تنفيذ مستقبلي بمكتبة مُراجَعة
L4 البيانات  │ snapshot مشفر + push بلا محتوى
L3 الإساءة   │ token-bucket + طرد تدريجي + حد 8000 + cap 6
L2 الجلسات   │ HttpOnly cookie + rotation + كشف سرقة + media token 120s
L1 الحدود    │ CSP + HSTS + nosniff + CORS allowlist + WS Origin gate + maxPayload
```

## 4. الملفات المتغيرة

| الملف | التغيير |
|---|---|
| server.ts | رؤوس أمان + CORS allowlist + media-token + حد رسالة REST + limiter بحث |
| ws_server.ts | maxPayload + حد 8000 + cap 6 + token-bucket + Origin gate + تنظيف buckets |
| services/auth.ts | generateMediaToken/isMediaToken + إصلاح exp |
| database.ts | تشفير snapshot ENC1 + ترقية كسولة |
| routes/authClassic.ts | bindRefreshCookie (register/login/recover-reset) |
| الواجهة (5 ملفات) | خزنة توكن + هجرة آلية + same-origin |
| token_vault.ts | جديد — الخزنة + الهجرة |
| tests/security.test.ts | 9 اختبارات آلية |
| diagnose-ui.ts | إصلاح نوعين |
| .env.example | 3 متغيرات جديدة |
| shield.js + index.html | سكريبت خارجي (شرط CSP) |
| package.json | vitest + puppeteer-core devDeps |

## 5. النتائج

| الأمر | النتيجة |
|---|---|
| npm run lint | EXIT 0 |
| npm run build | EXIT 0 |
| npm test | 9/9 PASS |
| اختبارات WS الحية | 6/6 |
| npm audit | 0 vulnerabilities |

## 6. الأسرار الواجب تدويرها

| السر | الإجراء |
|---|---|
| كلمة مرور Aiven | مكشوفة سابقاً — تدوير إلزامي قبل النشر |
| JWT_SECRET / AUTH_PEPPER | تُدوَّر عند النشر الأول |
| SNAPSHOT_ENCRYPTION_KEY | تُضبط مستقلة عند النشر |

## 7. المخاطر المتبقية (صراحة)

1. السيرفر يظل قادراً قراءة الرسائل حتى E2EE.
2. SameSite=None على الكوكي (بيئة iframe) — يُضيّق عند النشر المستقل.
3. لم تُنفذ اختبارات اختراق خارجية — ما تم: اختبارات حية صغيرة + آلية.
4. env-based admin (ADMIN_USERNAMES) — مقصود وموثق.

## 8. الخطوات التالية

1. تدوير كلمة مرور Aiven + DATABASE_URL جديد (إلزامي قبل النشر).
2. ALLOWED_ORIGINS بدقة عند النشر + أسرار مستقلة.
3. CI: lint + test + audit على كل PR.
4. E1: تكامل libsignal (E2EE 1:1) وفق docs/E2EE_DESIGN_AR.md.
