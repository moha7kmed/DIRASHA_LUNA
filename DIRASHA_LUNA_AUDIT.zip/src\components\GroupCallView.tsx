/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * GroupCallView — full-screen mesh group-call overlay (≤4 participants).
 * Presentational only (same split as CallInterface): App owns the
 * GroupCallMesh, media streams and signaling; this component renders the
 * participant-tile grid, local PiP video, per-peer audio sinks and the
 * controls bar in the app's glass/dark Arabic style.
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Mic, MicOff, PhoneOff, Video, VideoOff, Users, Loader2, Shield, Monitor, MonitorOff, PictureInPicture2 } from 'lucide-react';
import { motion } from 'motion/react';
import { formatCallDuration } from '../lib/callUiHelpers';

export interface GroupCallTile {
  userId: string;
  displayName: string;
  avatarUrl?: string;
  state: 'connecting' | 'connected' | 'left';
}

interface GroupCallViewProps {
  call: {
    groupCallId: string;
    chatName: string;
    initiatorId: string;
    type: 'voice' | 'video';
    status: 'joining' | 'connecting' | 'connected' | 'ended';
  };
  myId: string;
  participants: GroupCallTile[];
  remoteStreams: Record<string, MediaStream>;
  localStream: MediaStream | null;
  isMuted: boolean;
  isCameraOff: boolean;
  /** Screen stream while this client is sharing (drives the self tile preview). */
  screenStream: MediaStream | null;
  isScreenSharing: boolean;
  onToggleMute: () => void;
  onToggleCamera: () => void;
  onToggleScreenShare: () => void;
  onLeave: () => void;
}

/** Hidden <audio> sink for one remote peer's stream. */
function RemoteAudioSink({ stream }: { stream: MediaStream | null }) {
  const ref = useRef<HTMLAudioElement | null>(null);
  useEffect(() => {
    if (ref.current && stream) {
      ref.current.srcObject = stream;
      ref.current.play().catch(() => { /* autoplay guard */ });
    }
  }, [stream]);
  return <audio ref={ref} autoPlay className="hidden" />;
}

function getInitials(name: string): string {
  const trimmed = (name || '').trim();
  return trimmed ? trimmed.slice(0, 2) : '؟';
}

/** Participant tile: avatar (or remote video), name + connection/mute pills. */
function RemoteTile({
  tile,
  stream,
  isVideoCall,
  onVideoElChange,
}: {
  tile: GroupCallTile;
  stream: MediaStream | null;
  isVideoCall: boolean;
  /** Reports the tile's remote <video> element (or null on unmount) to the parent for PiP. */
  onVideoElChange?: (userId: string, el: HTMLVideoElement | null) => void;
}) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [remoteMuted, setRemoteMuted] = useState(false);
  const [remoteCamOff, setRemoteCamOff] = useState(!isVideoCall);

  // Bind the remote video to the tile viewport
  useEffect(() => {
    if (videoRef.current && stream && isVideoCall) {
      videoRef.current.srcObject = stream;
      videoRef.current.play().catch(() => { /* autoplay guard */ });
    }
  }, [stream, isVideoCall]);

  // Poll track enabled flags (the remote side toggles them locally)
  useEffect(() => {
    if (!stream) {
      setRemoteCamOff(!isVideoCall);
      return;
    }
    const poll = () => {
      const audioTrack = stream.getAudioTracks()[0];
      if (audioTrack) setRemoteMuted(!audioTrack.enabled);
      const videoTrack = stream.getVideoTracks()[0];
      if (videoTrack) setRemoteCamOff(!videoTrack.enabled);
    };
    poll();
    const interval = setInterval(poll, 1200);
    return () => clearInterval(interval);
  }, [stream, isVideoCall]);

  const showVideo = isVideoCall && stream && !remoteCamOff;
  const stateLabel =
    tile.state === 'connected' ? 'متصل'
    : tile.state === 'left' ? 'غادر المكالمة'
    : 'جاري الاتصال...';

  return (
    <div
      className={`relative aspect-video rounded-2xl overflow-hidden border transition-all duration-300 ${
        tile.state === 'left'
          ? 'border-white/5 bg-white/[0.02] opacity-50'
          : tile.state === 'connected'
          ? 'border-emerald-500/25 bg-white/5'
          : 'border-white/10 bg-white/5'
      }`}
    >
      {showVideo ? (
        <video
          ref={(el) => {
            videoRef.current = el;
            onVideoElChange?.(tile.userId, el);
          }}
          autoPlay
          playsInline
          className="w-full h-full object-cover bg-black"
        />
      ) : (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-black/40">
          {tile.avatarUrl ? (
            <img
              src={tile.avatarUrl}
              alt={tile.displayName}
              referrerPolicy="no-referrer"
              className="w-14 h-14 rounded-full border border-white/10 object-cover"
            />
          ) : (
            <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-emerald-600 to-emerald-400 flex items-center justify-center text-white text-sm font-bold border border-white/10">
              {getInitials(tile.displayName)}
            </div>
          )}
        </div>
      )}

      {/* Bottom info bar */}
      <div className="absolute bottom-0 left-0 right-0 bg-black/55 backdrop-blur-md px-2.5 py-1.5 flex items-center justify-between gap-2">
        <span className="text-[11px] font-bold text-white truncate max-w-[55%]">{tile.displayName}</span>
        <div className="flex items-center gap-1 shrink-0">
          {remoteMuted && (
            <span className="flex items-center gap-0.5 text-[9px] font-bold text-rose-300 bg-rose-500/15 border border-rose-500/25 rounded-full px-1.5 py-0.5" title="مكتوم">
              <MicOff className="w-2.5 h-2.5" /> مكتوم
            </span>
          )}
          <span
            className={`text-[9px] font-bold rounded-full px-1.5 py-0.5 border ${
              tile.state === 'connected'
                ? 'text-emerald-300 bg-emerald-500/10 border-emerald-500/25'
                : tile.state === 'left'
                ? 'text-zinc-400 bg-white/5 border-white/10'
                : 'text-amber-300 bg-amber-500/10 border-amber-500/25'
            }`}
          >
            {tile.state === 'connecting' && <Loader2 className="w-2 h-2 inline animate-spin ml-0.5" />}
            {stateLabel}
          </span>
        </div>
      </div>
    </div>
  );
}

export function GroupCallView({
  call,
  myId,
  participants,
  remoteStreams,
  localStream,
  isMuted,
  isCameraOff,
  screenStream,
  isScreenSharing,
  onToggleMute,
  onToggleCamera,
  onToggleScreenShare,
  onLeave,
}: GroupCallViewProps) {
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const [duration, setDuration] = useState(0);
  const isVideoCall = call.type === 'video';
  // getDisplayMedia feature detection (button hidden when unsupported).
  const canScreenShare = typeof navigator !== 'undefined'
    && !!navigator.mediaDevices
    && typeof (navigator.mediaDevices as MediaDevices & { getDisplayMedia?: unknown }).getDisplayMedia === 'function';

  // ── Picture-in-Picture (first active remote tile video) ───────────────────
  // Remote tile <video> elements are registered via their callback ref; the
  // PiP button targets the first tile that actually has flowing video data.
  // requestPictureInPicture() runs inside the click handler (user gesture).
  const remoteTileVideosRef = useRef<Map<string, HTMLVideoElement>>(new Map());
  const handleTileVideoEl = useCallback((userId: string, el: HTMLVideoElement | null) => {
    if (el) remoteTileVideosRef.current.set(userId, el);
    else remoteTileVideosRef.current.delete(userId);
  }, []);

  const canPip = typeof document !== 'undefined'
    && 'pictureInPictureEnabled' in document
    && !!document.pictureInPictureEnabled;
  const canGroupPip = isVideoCall && participants.some(p => p.state === 'connected') && canPip;

  const toggleGroupPip = async () => {
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
        return;
      }
      const target = Array.from(remoteTileVideosRef.current.values())
        .find((v) => v.isConnected && v.videoWidth > 0);
      await target?.requestPictureInPicture();
    } catch (_) {
      // Failures (no flowing video yet, gesture lost) are silent.
    }
  };

  // Auto-exit PiP when the call ends and on unmount (leave/cleanup).
  useEffect(() => {
    if (call.status === 'ended' && document.pictureInPictureElement) {
      document.exitPictureInPicture().catch(() => {});
    }
  }, [call.status]);
  useEffect(() => () => {
    if (document.pictureInPictureElement) {
      document.exitPictureInPicture().catch(() => {});
    }
  }, []);

  // Local video preview binding. While screen sharing, the self tile swaps to
  // the screen stream (un-mirrored); otherwise it shows the camera stream.
  useEffect(() => {
    const activeStream = (isScreenSharing && screenStream) ? screenStream : localStream;
    if (localVideoRef.current && activeStream && isVideoCall) {
      localVideoRef.current.srcObject = activeStream;
      localVideoRef.current.play().catch(() => { /* autoplay guard */ });
    }
  }, [localStream, screenStream, isScreenSharing, isVideoCall]);

  // Call duration counter (runs while the mesh is connected)
  useEffect(() => {
    if (call.status !== 'connected') {
      setDuration(0);
      return;
    }
    const timer = setInterval(() => setDuration(prev => prev + 1), 1000);
    return () => clearInterval(timer);
  }, [call.status]);

  const activePeers = participants.filter(p => p.state !== 'left');
  const anyConnected = participants.some(p => p.state === 'connected');

  const statusText =
    call.status === 'joining' ? 'جاري الانضمام...'
    : call.status === 'connecting' ? 'جاري الاتصال بالمشاركين...'
    : call.status === 'ended' ? 'انتهت المكالمة'
    : 'المكالمة الجماعية متصلة';

  const selfTileMuted = isMuted;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.97 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.97 }}
      transition={{ type: 'spring', damping: 25, stiffness: 150 }}
      className="fixed inset-0 z-[9999] bg-[#030304]/95 backdrop-blur-xl flex flex-col"
      style={{ direction: 'rtl' }}
    >
      {/* Per-peer remote audio sinks (voice always audible even in video mode) */}
      {Object.entries(remoteStreams).map(([peerId, stream]) => (
        <RemoteAudioSink key={peerId} stream={stream} />
      ))}

      {/* Header */}
      <div className="shrink-0 pt-5 px-6 flex flex-col items-center gap-1.5">
        <div className="flex items-center gap-1.5 py-1 px-3 bg-white/5 border border-white/5 rounded-full">
          <Shield className="w-3 text-sky-400" />
          <span className="text-[10px] text-zinc-400 font-medium">مكالمة مجموعة مشفرة (P2P WebRTC)</span>
        </div>
        <h2 className="text-lg font-bold text-white tracking-wide flex items-center gap-2">
          <Users className="w-4 h-4 text-emerald-400" />
          {call.chatName || 'مكالمة جماعية'}
        </h2>
        <div className="flex items-center gap-2">
          {call.status !== 'connected' && call.status !== 'ended' && (
            <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-400" />
          )}
          <span className={`text-xs font-semibold tracking-wider ${anyConnected ? 'text-green-400' : 'text-zinc-400'}`}>
            {statusText}
          </span>
          {call.status === 'connected' && duration > 0 && (
            <span className="text-xs font-mono text-zinc-300 bg-white/5 border border-white/5 px-2.5 py-0.5 rounded-full">
              {formatCallDuration(duration)}
            </span>
          )}
        </div>
      </div>

      {/* Participant tiles grid (up to 3 remote + self = 4) */}
      <div className="flex-1 w-full max-w-3xl mx-auto px-4 py-4 min-h-0 overflow-y-auto">
        <div className="grid grid-cols-2 gap-3 h-full place-content-start">
          {/* Remote peers */}
          {participants.map(tile => (
            <RemoteTile
              key={tile.userId}
              tile={tile}
              stream={remoteStreams[tile.userId] || null}
              isVideoCall={isVideoCall}
              onVideoElChange={handleTileVideoEl}
            />
          ))}

          {/* Self tile */}
          <div className="relative aspect-video rounded-2xl overflow-hidden border border-white/10 bg-white/5">
            {isVideoCall && (isScreenSharing || (localStream && !isCameraOff)) ? (
              <>
                <video
                  ref={localVideoRef}
                  autoPlay
                  playsInline
                  muted
                  disablePictureInPicture
                  className="w-full h-full object-cover bg-black"
                  style={isScreenSharing ? undefined : { transform: 'scaleX(-1)' }}
                />
                {isScreenSharing && (
                  <span className="absolute top-2 left-2 flex items-center gap-1 text-[9px] font-bold text-sky-300 bg-sky-500/15 border border-sky-500/25 rounded-full px-1.5 py-0.5">
                    <Monitor className="w-2.5 h-2.5" /> مشاركة الشاشة
                  </span>
                )}
              </>
            ) : (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-black/40">
                <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-sky-600 to-blue-400 flex items-center justify-center text-white text-sm font-bold border border-white/10">
                  أنت
                </div>
                {isVideoCall && isCameraOff && !isScreenSharing && (
                  <span className="flex items-center gap-1 text-[9px] text-zinc-400">
                    <VideoOff className="w-3 h-3" /> الكاميرا معطلة
                  </span>
                )}
              </div>
            )}
            <div className="absolute bottom-0 left-0 right-0 bg-black/55 backdrop-blur-md px-2.5 py-1.5 flex items-center justify-between gap-2">
              <span className="text-[11px] font-bold text-white truncate">أنت</span>
              {selfTileMuted && (
                <span className="flex items-center gap-0.5 text-[9px] font-bold text-rose-300 bg-rose-500/15 border border-rose-500/25 rounded-full px-1.5 py-0.5">
                  <MicOff className="w-2.5 h-2.5" /> مكتوم
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Controls bar */}
      <div className="shrink-0 pb-8 pt-2 flex items-center justify-center">
        <div className="flex items-center gap-5 bg-black/45 backdrop-blur-lg border border-white/10 rounded-full py-2.5 px-6 shadow-xl">
          <button
            type="button"
            onClick={onToggleMute}
            className={`w-11 h-11 rounded-full flex items-center justify-center transition-all duration-150 active:scale-95 border cursor-pointer ${
              isMuted
                ? 'bg-rose-500/15 border-rose-500/35 text-rose-500 hover:bg-rose-500/25'
                : 'bg-white/5 border-white/10 text-zinc-300 hover:bg-white/10'
            }`}
            title={isMuted ? 'إلغاء كتم الميكروفون' : 'كتم الميكروفون'}
          >
            {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {isVideoCall && (
            <button
              type="button"
              onClick={onToggleCamera}
              className={`w-11 h-11 rounded-full flex items-center justify-center transition-all duration-150 active:scale-95 border cursor-pointer ${
                isCameraOff && !isScreenSharing
                  ? 'bg-rose-500/15 border-rose-500/35 text-rose-500 hover:bg-rose-500/25'
                  : 'bg-white/5 border-white/10 text-zinc-300 hover:bg-white/10'
              }`}
              title={isCameraOff ? 'تشغيل الكاميرا' : 'إيقاف الكاميرا'}
            >
              {isCameraOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
            </button>
          )}

          {/* Screen share toggle (video calls with getDisplayMedia support) */}
          {isVideoCall && canScreenShare && (
            <button
              type="button"
              onClick={onToggleScreenShare}
              className={`w-11 h-11 rounded-full flex items-center justify-center transition-all duration-150 active:scale-95 border cursor-pointer ${
                isScreenSharing
                  ? 'bg-sky-500/15 border-sky-500/35 text-sky-400 hover:bg-sky-500/25'
                  : 'bg-white/5 border-white/10 text-zinc-300 hover:bg-white/10'
              }`}
              title={isScreenSharing ? 'إيقاف مشاركة الشاشة' : 'مشاركة الشاشة'}
            >
              {isScreenSharing ? <MonitorOff className="w-5 h-5" /> : <Monitor className="w-5 h-5" />}
            </button>
          )}

          {/* Picture-in-Picture on the first active remote tile video */}
          {canGroupPip && (
            <button
              type="button"
              onClick={toggleGroupPip}
              className="w-11 h-11 rounded-full flex items-center justify-center transition-all duration-150 active:scale-95 border bg-white/5 border-white/10 text-zinc-300 hover:bg-white/10 cursor-pointer"
              title="نافذة عائمة (PiP)"
            >
              <PictureInPicture2 className="w-5 h-5" />
            </button>
          )}

          <button
            type="button"
            onClick={onLeave}
            className="w-12 h-12 rounded-full bg-rose-500 hover:bg-rose-600 text-white flex items-center justify-center transition-all duration-150 active:scale-95 shadow-[0_10px_20px_rgba(244,63,94,0.3)] hover:shadow-[0_10px_25px_rgba(244,63,94,0.5)] cursor-pointer"
            title="مغادرة المكالمة"
          >
            <PhoneOff className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>

      {/* Participant count footer */}
      <div className="shrink-0 pb-3 text-center">
        <span className="text-[10px] text-zinc-500 font-medium">
          {activePeers.length + 1} / 4 مشاركين
        </span>
      </div>
    </motion.div>
  );
}
