/**
 * P1-hardening: token vault — credentials never touch localStorage again.
 *
 * - Refresh token travels exclusively in the server-set HttpOnly `refreshToken`
 *   cookie (register/login/refresh all bind it now).
 * - Access token (15-min JWT) lives in React state, mirrored here in module
 *   memory for non-React consumers (StorageLinkCard, session revoke calls).
 * - Legacy tokens found in localStorage are absorbed exactly once at startup,
 *   then wiped: the legacy refresh token is handed to /api/auth/refresh one
 *   final time while the server migrates the session onto the cookie.
 */

const LS_ACCESS = 'dirasha_token';
const LS_REFRESH = 'dirasha_refresh_token';
const LS_SESSION = 'dirasha_session_id';

let accessToken: string | null = null;
let sessionId: string | null = null;
let legacyRefreshToken: string | null = null;
let legacyAbsorbed = false;

/** One-time migration: pick up pre-hardening tokens, then scrub localStorage. */
function absorbLegacy(): void {
  if (legacyAbsorbed) return;
  legacyAbsorbed = true;
  try {
    legacyRefreshToken = localStorage.getItem(LS_REFRESH);
    const access = localStorage.getItem(LS_ACCESS);
    const sess = localStorage.getItem(LS_SESSION);
    if (access && !accessToken) accessToken = access;
    if (sess && !sessionId) sessionId = sess;
    localStorage.removeItem(LS_REFRESH); // the refresh token now lives only in the HttpOnly cookie
    localStorage.removeItem(LS_ACCESS);
    localStorage.removeItem(LS_SESSION);
  } catch {
    /* storage unavailable — nothing to migrate */
  }
}

export function getAccessToken(): string {
  if (!accessToken) absorbLegacy();
  return accessToken || '';
}

export function setAccessToken(token: string): void {
  accessToken = token;
}

export function getSessionId(): string | null {
  if (!sessionId) absorbLegacy();
  return sessionId;
}

export function setSessionId(id: string | null): void {
  sessionId = id;
}

/**
 * Legacy refresh token for the one-time migration request. Kept in memory until
 * clearLegacyRefreshToken() confirms the migration outcome (rotated onto the
 * HttpOnly cookie, or confirmed dead by the server).
 */
export function getLegacyRefreshToken(): string | null {
  absorbLegacy();
  return legacyRefreshToken;
}

/** Migration completed — discard the legacy token (it is rotated or revoked server-side). */
export function clearLegacyRefreshToken(): void {
  legacyRefreshToken = null;
}

export function clearVault(): void {
  accessToken = null;
  sessionId = null;
}

export function authHeaders(): Record<string, string> {
  const t = getAccessToken();
  return t ? { Authorization: `Bearer ${t}` } : {};
}
