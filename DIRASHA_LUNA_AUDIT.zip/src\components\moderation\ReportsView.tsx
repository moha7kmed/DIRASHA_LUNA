import { Flag, MessageSquare, AlertCircle, CheckCircle, XCircle, Calendar, ShieldAlert, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';
import { UserBadge, StatusBadge } from './ModerationShared.tsx';

interface Report {
  reportId: string;
  reporterId: string;
  reporterName?: string;
  reporterAvatar?: string;
  targetUserId: string;
  targetUserName?: string;
  targetUserAvatar?: string;
  targetMessageId?: string;
  category: string;
  description?: string;
  status: string;
  targetType: string;
  createdAt: string;
}

interface ReportsViewProps {
  reports: Report[];
  loading: boolean;
  onResolve: (id: string) => void;
  onReject: (id: string) => void;
  onViewDetails: (report: Report) => void;
}

export function ReportsView({ reports, loading, onResolve, onReject, onViewDetails }: ReportsViewProps) {
  if (loading && reports.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-32 text-zinc-500">
        <ShieldAlert className="w-10 h-10 animate-pulse mb-4 text-indigo-400/40" />
        <span className="text-[11px] font-black uppercase tracking-widest text-zinc-600">Scanning incoming reports...</span>
      </div>
    );
  }

  if (reports.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-32 text-zinc-500 rounded-[40px] border border-dashed border-white/5 bg-white/[0.01]">
        <CheckCircle className="w-12 h-12 mb-4 opacity-5 text-emerald-500" />
        <span className="text-[11px] font-black uppercase tracking-widest opacity-40">Clear inbox, no pending reports</span>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-20">
      {reports.map((report) => (
        <motion.div
          key={report.reportId}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/[0.02] border border-white/10 rounded-[40px] overflow-hidden group hover:border-white/20 hover:bg-white/[0.04] transition-all backdrop-blur-md"
        >
          <div className="p-6 md:p-8 flex flex-col lg:flex-row gap-8 lg:gap-10">
             <div className="flex-1 space-y-6 min-w-0">
                <div className="flex flex-wrap items-center gap-3">
                   <StatusBadge status="Pending" label={report.category} />
                   {report.targetMessageId && (
                     <div className="flex items-center gap-2 text-[8px] font-black uppercase tracking-widest text-indigo-400 bg-indigo-500/5 px-2.5 py-1 rounded-lg border border-indigo-500/5">
                        <MessageSquare className="w-3 h-3" />
                        MESSAGE VIOLATION
                     </div>
                   )}
                </div>
                
                <div className="flex flex-col sm:flex-row sm:items-center gap-6 sm:gap-10">
                   <div className="space-y-2 shrink-0">
                     <p className="text-[8px] font-black text-zinc-600 uppercase tracking-widest px-1 opacity-50">Reporter</p>
                     <UserBadge 
                       user={{ 
                         id: report.reporterId, 
                         displayName: report.reporterName || 'Reporter',
                         avatarUrl: report.reporterAvatar
                       }} 
                       size="sm"
                     />
                   </div>
                   
                   <ArrowRight className="w-3 w-3 text-zinc-800 rotate-90 sm:rotate-0 mx-auto sm:mx-0 opacity-20 shrink-0" />
                   
                   <div className="p-3.5 bg-rose-500/5 border border-rose-500/5 rounded-[24px] flex flex-col gap-1.5 transition-colors group-hover:border-rose-500/10 min-w-0 flex-1">
                      <p className="text-[8px] font-black text-rose-500/50 uppercase tracking-widest px-1">Case Subject</p>
                      <UserBadge 
                        user={{ 
                          id: report.targetUserId, 
                          displayName: report.targetUserName || 'Target',
                          avatarUrl: report.targetUserAvatar
                        }} 
                        size="sm"
                      />
                   </div>
                </div>
                
                {report.description && (
                  <div className="p-5 bg-black/40 border border-white/5 rounded-[24px] relative overflow-hidden group-hover:border-white/10 transition-colors">
                    <p className="text-[11px] text-zinc-400 leading-relaxed font-semibold relative z-10">
                      {report.description}
                    </p>
                    <AlertCircle className="absolute -bottom-4 -right-4 w-10 h-10 opacity-[0.01] rotate-12" />
                  </div>
                )}

                <div className="flex items-center gap-6 text-[9px] text-zinc-600 font-bold uppercase tracking-widest px-1">
                   <div className="flex items-center gap-2">
                      <Calendar className="w-3 h-3 opacity-30" />
                      {new Date(report.createdAt).toLocaleString('en-US', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                   </div>
                </div>
             </div>

             <div className="flex flex-row lg:flex-col gap-2.5 pt-6 lg:pt-0 border-t lg:border-t-0 lg:border-l border-white/5 lg:pl-8 shrink-0">
                <button 
                  onClick={() => onResolve(report.reportId)}
                  className="flex-1 lg:w-32 py-3 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 rounded-xl transition-all flex items-center justify-center gap-2 border border-emerald-500/10 font-black text-[9px] uppercase tracking-widest active:scale-95"
                >
                  <CheckCircle className="w-3.5 h-3.5" />
                  Resolve
                </button>
                <button 
                  onClick={() => onReject(report.reportId)}
                  className="flex-1 lg:w-32 py-3 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 rounded-xl transition-all flex items-center justify-center gap-2 border border-rose-500/10 font-black text-[9px] uppercase tracking-widest active:scale-95"
                >
                  <XCircle className="w-3.5 h-3.5" />
                  Dismiss
                </button>
             </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}

