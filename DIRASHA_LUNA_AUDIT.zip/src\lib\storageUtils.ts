/**
 * Media Upload Utilities — External Object Storage era
 * ------------------------------------------------------
 * Media NEVER flows through our API server or database anymore:
 *   1. POST /api/storage/presign  → short-lived PUT URL (server-side signature)
 *   2. fetch(uploadUrl, { PUT })  → bytes go straight to the bucket (user's own
 *      cloud when linked, otherwise our capped managed fallback)
 *   3. The chat stores only the resulting public HTTPS URL + metadata.
 *
 * Google Drive era ("movie-site streaming pattern"):
 *   uploadMediaFile() is the new entry point — when the user linked Google
 *   Drive, bytes go browser → Google directly (multipart upload) into the
 *   user's own 15GB, then the file is shared "anyone with link" and served
 *   via drive.usercontent.google.com (Range-capable streaming URLs).
 */

import { getAccessToken } from './token_vault.ts';

export interface UploadedMedia {
  url: string;
  mimeType: string;
  size: number;
  name: string;
}

/**
 * Typed error thrown when the user has no usable storage path (no Google
 * Drive link, no linked S3 bucket, no managed fallback). Callers should
 * redirect to `gdriveStartUrl` to trigger the consent flow.
 */
export class StorageNotLinkedError extends Error {
  readonly gdriveStartUrl: string;
  constructor(message: string, gdriveStartUrl = '/api/storage/gdrive/start') {
    super(message);
    this.name = 'StorageNotLinkedError';
    this.gdriveStartUrl = gdriveStartUrl;
  }
}

/* ===================== Google Drive direct upload ===================== */

const GDRIVE_UPLOAD_ENDPOINT =
  'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id';
const GDRIVE_STREAM_URL_BASE = 'https://drive.usercontent.google.com/download';

/**
 * Direct browser → Google Drive multipart upload (metadata + content in one
 * request). The file lands in the user's 'Dirasha Media' folder and is then
 * shared with "anyone with the link" so recipients can stream it.
 *
 * Returns the SAME { url, mimeType, size, name } shape as uploadFileToCloud,
 * so every call site stays identical.
 */
export async function uploadFileToDrive(
  file: Blob | File,
  fileName: string,
  onProgress?: (percent: number) => void,
): Promise<UploadedMedia> {
  const mimeType = (file.type || 'application/octet-stream').toLowerCase();
  const token = getAccessToken();

  // 1. Upload ticket (server refreshes the OAuth access token server-side).
  const ticketRes = await fetch('/api/storage/gdrive/upload-ticket', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
    body: JSON.stringify({ fileName, mimeType, sizeBytes: file.size }),
  });
  if (!ticketRes.ok) {
    const err = await ticketRes.json().catch(() => ({}));
    if (err?.error === 'STORAGE_NOT_LINKED' || err?.error === 'GDRIVE_LINK_BROKEN') {
      throw new StorageNotLinkedError(err?.message || 'اربط حساب Google أولاً.');
    }
    if (err?.error === 'GDRIVE_NOT_CONFIGURED') {
      throw new Error(err?.message || 'ربط Google غير مهيأ بعد.');
    }
    throw new Error(err?.error || 'تعذر تجهيز الرفع إلى Google Drive. حاول مرة أخرى.');
  }
  const { accessToken, folderId } = await ticketRes.json();

  // 2. Multipart body: JSON metadata part + raw file part (manual boundary).
  const boundary = `dirasha_gdrive_${Math.random().toString(36).slice(2)}`;
  const metadata = JSON.stringify({
    name: fileName,
    parents: [folderId],
    mimeType,
  });
  const body = new Blob(
    [
      `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${metadata}\r\n`,
      `--${boundary}\r\nContent-Type: ${mimeType}\r\n\r\n`,
      file,
      `\r\n--${boundary}--\r\n`,
    ],
    { type: `multipart/related; boundary=${boundary}` },
  );

  // 3. Upload via XHR so we can report progress (fetch cannot).
  const fileId = await new Promise<string>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', GDRIVE_UPLOAD_ENDPOINT, true);
    xhr.setRequestHeader('Authorization', `Bearer ${accessToken}`);
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable && onProgress) {
        onProgress(Math.round((e.loaded / e.total) * 100));
      }
    };
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          const json = JSON.parse(xhr.responseText);
          if (json?.id) resolve(String(json.id));
          else reject(new Error('تعذر تحديد هوية الملف على Google Drive.'));
        } catch {
          reject(new Error('رد غير صالح من Google Drive.'));
        }
      } else if (xhr.status === 401 || xhr.status === 403) {
        reject(new StorageNotLinkedError('انقطع ربط حساب Google — أعد الربط.'));
      } else {
        reject(new Error('فشل الرفع إلى Google Drive. تحقق من اتصالك وحاول مرة أخرى.'));
      }
    };
    xhr.onerror = () => reject(new Error('فشل الاتصال بـ Google Drive.'));
    xhr.ontimeout = () => reject(new Error('انتهت مهلة الرفع إلى Google Drive.'));
    xhr.send(body);
  });

  // 4. Store a SAME-ORIGIN proxy URL: the recipient's browser fetches the
  //    media from dirasha.onrender.com (which streams it from the sender's
  //    Drive with the sender's token). No third-party host in <img>/<video>,
  //    no CORS, no extension/VPN interference, files stay PRIVATE on Drive.
  // Path-style (no query string) — renderers append ?access_token= and a
  // double-'?' join would corrupt the id into the token parameter.
  const url = '/api/media/gdrive/' + encodeURIComponent(fileId);
  return { url, mimeType, size: file.size, name: fileName };
}

/* ===================== Dispatcher ===================== */

interface StorageStatusShape {
  linked: boolean;
  provider: string | null;
  gdrive?: boolean;
  gdriveSupported?: boolean;
  fallbackActive?: boolean;
}

/** Short-lived cache so bursts of uploads don't hammer the status endpoint. */
let statusCache: { status: StorageStatusShape; exp: number } | null = null;
const STATUS_CACHE_MS = 30_000;

async function fetchStorageStatus(): Promise<StorageStatusShape> {
  if (statusCache && statusCache.exp > Date.now()) return statusCache.status;
  const token = getAccessToken();
  const res = await fetch('/api/storage/status', {
    headers: { 'Authorization': `Bearer ${token}` },
  });
  if (!res.ok) throw new Error('تعذر التحقق من إعدادات التخزين.');
  const status: StorageStatusShape = await res.json();
  statusCache = { status, exp: Date.now() + STATUS_CACHE_MS };
  return status;
}

/**
 * THE media upload entry point for chat call sites.
 *   - linked Google Drive → direct browser → Drive multipart upload
 *   - otherwise           → legacy presign path (BYO S3 bucket or managed fallback)
 * Throws StorageNotLinkedError when neither path is available; catch it and
 * redirect to err.gdriveStartUrl to start the Google consent flow.
 */
export async function uploadMediaFile(
  file: Blob | File,
  fileName: string,
  onProgress?: (percent: number) => void,
): Promise<UploadedMedia> {
  let status: StorageStatusShape;
  try {
    status = await fetchStorageStatus();
  } catch {
    // Status endpoint unreachable — try the legacy path as a safe default.
    return uploadFileToCloud(file, fileName);
  }
  if (status.gdrive || (status.linked && status.provider === 'gdrive')) {
    return uploadFileToDrive(file, fileName, onProgress);
  }
  if (status.linked || status.fallbackActive) {
    return uploadFileToCloud(file, fileName);
  }
  throw new StorageNotLinkedError('اربط مساحتك المجانية بحساب Google أولاً لإرسال الوسائط.');
}

/**
 * Core uploader: presign → direct PUT. Throws a user-facing Arabic error
 * when no storage is configured (user must link a bucket in settings).
 */
export async function uploadFileToCloud(file: Blob, fileName: string): Promise<UploadedMedia> {
  const mimeType = (file.type || 'application/octet-stream').toLowerCase();
  const token = getAccessToken();

  const presignRes = await fetch('/api/storage/presign', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
    body: JSON.stringify({ fileName, mimeType, sizeBytes: file.size }),
  });

  if (!presignRes.ok) {
    const err = await presignRes.json().catch(() => ({}));
    if (err?.error === 'STORAGE_NOT_CONFIGURED') {
      throw new Error('اربط تخزينك السحابي من الإعدادات أولاً لإرسال الصور والفيديوهات.');
    }
    throw new Error(err?.error || 'تعذر تجهيز رابط الرفع. حاول مرة أخرى.');
  }

  const { uploadUrl, publicUrl } = await presignRes.json();

  const putRes = await fetch(uploadUrl, {
    method: 'PUT',
    headers: { 'Content-Type': mimeType },
    body: file,
  });

  if (!putRes.ok) {
    throw new Error('فشل الرفع إلى التخزين السحابي. تحقق من اتصالك وإعدادات التخزين.');
  }

  return { url: publicUrl, mimeType, size: file.size, name: fileName };
}

/**
 * Compresses an image file and converts it to WebP format with extremely high quality.
 */
export async function compressAndConvertImage(file: File, maxDimension = 1600, quality = 0.85): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const objectUrl = URL.createObjectURL(file);
    img.src = objectUrl;

    img.onload = () => {
      URL.revokeObjectURL(objectUrl);
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Canvas 2D context is not supported'));
        return;
      }

      let width = img.naturalWidth || img.width;
      let height = img.naturalHeight || img.height;

      if (width > maxDimension || height > maxDimension) {
        const ratio = Math.min(maxDimension / width, maxDimension / height);
        width = Math.round(width * ratio);
        height = Math.round(height * ratio);
      }

      canvas.width = width;
      canvas.height = height;
      ctx.drawImage(img, 0, 0, width, height);

      canvas.toBlob((blob) => {
        if (blob) {
          resolve(blob);
        } else {
          canvas.toBlob((fallbackBlob) => {
            if (fallbackBlob) {
              resolve(fallbackBlob);
            } else {
              reject(new Error('Image compression failed'));
            }
          }, 'image/jpeg', quality);
        }
      }, 'image/webp', quality);
    };

    img.onerror = (err) => {
      URL.revokeObjectURL(objectUrl);
      reject(err);
    };
  });
}

/**
 * Compresses an image client-side (WebP) then uploads it to object storage.
 * Returns the PUBLIC HTTPS URL (never a base64 data-url anymore).
 * Drop-in replacement for the legacy base64 uploader — signature unchanged.
 */
export async function uploadImageToStorage(file: File, path: string, maxDimension = 1600, quality = 0.85): Promise<string> {
  let uploadBlob: Blob = file;
  let mime = file.type;
  if (file.type.startsWith('image/') && !file.type.includes('gif')) {
    uploadBlob = await compressAndConvertImage(file, maxDimension, quality);
    mime = uploadBlob.type || 'image/webp';
  }
  const safeName = (file.name || 'image').replace(/[^\w.\-]/g, '_');
  const uploaded = await uploadMediaFile(new File([uploadBlob], safeName, { type: mime }), safeName);
  return uploaded.url;
}

/**
 * @deprecated Base64 reads are kept ONLY for legacy in-flight previews.
 * Never persist the result — upload via uploadFileToCloud instead.
 */
export async function blobToBase64(blob: Blob | File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

/**
 * Kicks off the Google Drive consent flow: POSTs (with Bearer) to get a
 * signed consent URL, then navigates the browser to it. Navigation-only
 * requests can't carry the API token, which is why we ticket it first.
 */
export async function startGdriveConsent(accessToken: string): Promise<void> {
  const res = await fetch('/api/storage/gdrive/start', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${accessToken}` },
  });
  const data = await res.json().catch(() => ({} as any));
  if (res.ok && data?.consentUrl) {
    window.location.href = data.consentUrl;
    return;
  }
  throw new Error(data?.message || data?.error || 'تعذر بدء ربط Google Drive.');
}
