// One-time cleanup: drop phone-OTP-era orphan accounts (no credentials) from Aiven.
import 'dotenv/config';
import pg from 'pg';

const url = (process.env.DATABASE_URL || '').replace(/[?&]sslmode=[^&]*/i, (m) => (m.startsWith('?') ? '?' : '')).replace(/\?$/, '');
const pool = new pg.Pool({ connectionString: url, ssl: { rejectUnauthorized: false } });

const before = await pool.query("SELECT id, username FROM users WHERE password_hash IS NULL");
console.log(`Orphan phone-era accounts: ${before.rows.length}`);
if (before.rows.length > 0) {
  await pool.query('DELETE FROM users WHERE password_hash IS NULL');
  console.log('Deleted. Remaining users:');
}
const after = await pool.query('SELECT username, display_name, created_at FROM users ORDER BY created_at');
console.table(after.rows);
await pool.end();
