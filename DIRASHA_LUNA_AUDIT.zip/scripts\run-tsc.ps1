Set-Location 'C:\Users\Zedan\Downloads\dirasha'
if (Test-Path .\tsc.log) { Remove-Item .\tsc.log -Force }
$out = & node .\node_modules\typescript\bin\tsc --noEmit 2>&1 | Out-String -Width 400
Set-Content tsc.log $out -Encoding utf8
Add-Content tsc.log ("EXIT:" + $LASTEXITCODE)
