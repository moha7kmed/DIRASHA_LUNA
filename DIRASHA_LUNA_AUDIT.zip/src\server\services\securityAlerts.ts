/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * SecurityAlerts — proactive account-security notifications (Signal/WhatsApp parity)
 * -------------------------------------------------------------------------------------
 * Three triggers, all fire-and-forget (never block the auth response, never throw):
 *   1. notifyNewLogin        — successful login from an IP with NO previous
 *                              successful login on record → push + WS toast.
 *   2. notifyFailedAttempts  — failed login on an EXISTING account from an IP
 *                              that never logged in successfully → throttled
 *                              push (max 1 / user / 15 min).
 *   3. notifyPasswordChanged — credentials changed (sessions already revoked
 *                              by the caller) → push + WS toast.
 *
 * Delivery = WebPushService.sendPush (all registered endpoints) PLUS a
 * `security:alert` WS event on the user's private Redis channel
 * (`user:updates:<userId>`) so connected clients toast live. The publish
 * payload shape mirrors the authClassic session-revoke publish pattern.
 *
 * Privacy (F15): IPs NEVER appear in push notification bodies or WS payloads —
 * they are recorded in auth_logs only. IPs are truncated to 24 chars for the
 * internal known-IP baseline comparison; tokens/passwords are never accepted
 * or logged by this service.
 */

import { db } from '../database.ts';
import { redisCluster } from '../websocket/redis_client.ts';
import { WebPushService } from './push.ts';
import { logger } from '../logger.ts';

export type SecurityAlertKind = 'new_login' | 'failed_attempt' | 'password_changed';

/** Hard privacy cap: full IPs never leave the server. */
const IP_MAX = 24;
/** Failed-attempt push throttle window (per user). */
const FAILED_ATTEMPT_THROTTLE_MS = 15 * 60 * 1000;
/** How many previous successful-login records form the known-IP baseline. */
const LOGIN_BASELINE_LIMIT = 50;

function truncIp(ip: unknown): string {
  return String(ip || '').trim().slice(0, IP_MAX);
}

/** Module-level throttle state: userId → last push epoch ms (bounded by user count). */
const failedAttemptLastPush = new Map<string, number>();

/** WS event on the user's private channel — same shape as the authClassic publishes. */
async function publishSecurityAlert(userId: string, title: string, body: string, kind: SecurityAlertKind): Promise<void> {
  try {
    await redisCluster.publish(`user:updates:${userId}`, {
      event: 'security:alert',
      payload: { title, body, kind },
    });
  } catch { /* WS toast is best-effort — never surfaced to the auth flow */ }
}

export const SecurityAlertsService = {
  /**
   * Successful login. Reads the PREVIOUS successful-login baseline BEFORE
   * recording this login (the ordering is guaranteed here — the caller only
   * fires this once), then always records the 'login' baseline entry that
   * future logins compare against.
   */
  async notifyNewLogin(userId: string, meta: { ip?: string; userAgent?: string }): Promise<void> {
    const ip = truncIp(meta?.ip);
    const ua = String(meta?.userAgent || 'unknown').slice(0, 200);
    try {
      const baseline = await db.getAuthActionHistory(userId, 'login', LOGIN_BASELINE_LIMIT);
      const knownIps = new Set(baseline.map(h => truncIp(h.ip || h.metadata?.ip)).filter(Boolean));
      if (knownIps.size > 0 && !knownIps.has(ip)) {
        // F15: no IP in the push body — the address lives in auth_logs only.
        const title = '🔔 دخول جديد لحسابك';
        const body = 'تم الدخول من جهاز/موقع جديد — إن لم تكن أنت غيّر كلمة السر فوراً';
        await WebPushService.sendPush(userId, title, body, { category: 'security' });
        await publishSecurityAlert(userId, title, body, 'new_login');
        await db.logAuthAction(userId, 'login_new_ip', { ip, userAgent: ua });
      }
    } catch (err: any) {
      logger.warn('[SecurityAlerts] notifyNewLogin failed:', err?.message);
    }
    // Baseline bookkeeping is unconditional (own guard — never throws)
    try {
      await db.logAuthAction(userId, 'login', { ip, userAgent: ua });
    } catch { /* baseline record is best-effort */ }
  },

  /**
   * Failed login on an EXISTING account (the route only calls this when the
   * username resolved). Alerts only when the source IP has never had a
   * successful login before — drive-by noise against one's own known devices
   * stays silent — throttled to max 1 push per user per 15 minutes.
   */
  async notifyFailedAttempts(userId: string, ip: string): Promise<void> {
    try {
      const tIp = truncIp(ip);
      const now = Date.now();
      const last = failedAttemptLastPush.get(userId) || 0;
      if (now - last < FAILED_ATTEMPT_THROTTLE_MS) return;
      const baseline = await db.getAuthActionHistory(userId, 'login', LOGIN_BASELINE_LIMIT);
      if (baseline.some(h => truncIp(h.ip || h.metadata?.ip) === tIp)) return;
      // Reserve the throttle slot BEFORE the awaits → concurrent failures stay single-shot
      failedAttemptLastPush.set(userId, now);
      // F15: no IP in the push body — the address lives in auth_logs only.
      const title = '⚠️ محاولة دخول فاشلة على حسابك';
      const body = 'حدثت محاولة دخول فاشلة على حسابك — إن لم تكن أنت غيّر كلمة السر فوراً';
      await WebPushService.sendPush(userId, title, body, { category: 'security' });
      await publishSecurityAlert(userId, title, body, 'failed_attempt');
    } catch (err: any) {
      logger.warn('[SecurityAlerts] notifyFailedAttempts failed:', err?.message);
    }
  },

  /** Password change completed — the caller has already revoked other sessions. */
  async notifyPasswordChanged(userId: string): Promise<void> {
    try {
      const title = '🔐 تم تغيير كلمة المرور';
      const body = 'سُجّل خروج الأجهزة الأخرى — إن لم تكن أنت، راجع حسابك فوراً';
      await WebPushService.sendPush(userId, title, body, { category: 'security' });
      await publishSecurityAlert(userId, title, body, 'password_changed');
    } catch (err: any) {
      logger.warn('[SecurityAlerts] notifyPasswordChanged failed:', err?.message);
    }
  }
};

export default SecurityAlertsService;
