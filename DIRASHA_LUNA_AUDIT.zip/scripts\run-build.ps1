Set-Location 'C:\Users\Zedan\Downloads\dirasha'
if (Test-Path .\build.log) { Remove-Item .\build.log -Force }
npm run build > build.log 2>&1
Add-Content build.log ("EXIT:" + $LASTEXITCODE)
