import { useEffect, useState } from 'react';
import { Users, X, Check, Loader2 } from 'lucide-react';
import { getAccessToken } from '../lib/token_vault';
import { fetchAllUsersPaginated } from '../lib/users_paging.ts';

interface Props {
  onClose: () => void;
  onCreated: (chatId: string) => void;
}

/**
 * WhatsApp-style group creation: pick members (multi-select) → name → create.
 * Server assigns creator = owner, invitees = members, and enforces the
 * allowGroupInvites privacy policy per invitee.
 */
export function GroupCreateModal({ onClose, onCreated }: Props) {
  const [users, setUsers] = useState<any[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const users = await fetchAllUsersPaginated(getAccessToken());
        setUsers(users);
      } catch { /* empty list on failure */ }
    })();
  }, []);

  const toggle = (id: string) => {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else if (next.size < 50) next.add(id);
      return next;
    });
  };

  const create = async () => {
    if (!name.trim() || selected.size === 0) return;
    setBusy(true); setError(null);
    try {
      const res = await fetch('/api/chats', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` },
        body: JSON.stringify({ type: 'group', name: name.trim(), memberIds: Array.from(selected) }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'فشل إنشاء المجموعة.');
      onCreated(data.chat.id);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  const filtered = users.filter(u => (u.displayName || u.username || '').toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="fixed inset-0 z-[2000] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div className="w-full max-w-md bg-zinc-900 border border-white/10 rounded-3xl overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/5">
          <div className="flex items-center gap-2">
            <Users size={18} className="text-blue-400" />
            <h3 className="text-white font-bold text-sm">مجموعة جديدة</h3>
          </div>
          <button onClick={onClose} className="text-zinc-400 hover:text-white"><X size={18} /></button>
        </div>

        <div className="p-5 space-y-4">
          <input
            value={name}
            onChange={(e) => setName(e.target.value.slice(0, 60))}
            placeholder="اسم المجموعة"
            className="w-full bg-zinc-800/80 border border-white/10 rounded-2xl px-4 py-3 text-white outline-none focus:border-blue-500/50"
          />

          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث عن أعضاء..."
            className="w-full bg-zinc-800/60 border border-white/5 rounded-xl px-3 py-2 text-xs text-white outline-none"
          />

          <div className="max-h-56 overflow-y-auto space-y-1">
            {filtered.map((u) => {
              const isSel = selected.has(u.id);
              return (
                <button
                  key={u.id}
                  onClick={() => toggle(u.id)}
                  className={`w-full flex items-center gap-3 p-2 rounded-xl transition-colors ${isSel ? 'bg-blue-500/15' : 'hover:bg-white/5'}`}
                >
                  <img src={u.avatarUrl} alt="" className="w-9 h-9 rounded-full object-cover" />
                  <div className="flex-1 text-right">
                    <p className="text-[13px] text-white font-bold">{u.displayName}</p>
                    <p className="text-[10px] text-zinc-500">@{u.username}</p>
                  </div>
                  <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${isSel ? 'bg-blue-500 border-blue-500' : 'border-white/20'}`}>
                    {isSel && <Check size={12} className="text-white" />}
                  </div>
                </button>
              );
            })}
            {filtered.length === 0 && <p className="text-zinc-500 text-xs text-center py-4">لا يوجد مستخدمون</p>}
          </div>

          {error && <p className="text-red-400 text-xs">{error}</p>}

          <button
            onClick={create}
            disabled={busy || !name.trim() || selected.size === 0}
            className="w-full py-3 rounded-2xl bg-blue-500 text-white font-black text-sm disabled:opacity-40 flex items-center justify-center gap-2"
          >
            {busy ? <Loader2 size={16} className="animate-spin" /> : null}
            إنشاء المجموعة ({selected.size} أعضاء)
          </button>
        </div>
      </div>
    </div>
  );
}
