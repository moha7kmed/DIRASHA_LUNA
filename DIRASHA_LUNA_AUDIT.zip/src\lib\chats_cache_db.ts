/**
 * Vanilla IndexedDB manager for caching the user's chats thread list locally.
 * This completely avoids blocking the main UI thread (unlike synchronous localStorage)
 * and supports virtually limitless storage.
 */
const DB_NAME = 'dirashaChatsDB';
const STORE_NAME = 'chatsList';
const DB_VERSION = 1;

export class ChatsCacheDB {
  private static initDB(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event: any) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME, { keyPath: 'userId' });
        }
      };

      request.onsuccess = (event: any) => {
        resolve(event.target.result);
      };

      request.onerror = (event: any) => {
        reject(event.target.error);
      };
    });
  }

  public static async get(userId: string): Promise<any[] | null> {
    try {
      if (!userId) return null;
      const db = await this.initDB();
      return new Promise((resolve, reject) => {
        const transaction = db.transaction(STORE_NAME, 'readonly');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.get(userId);

        request.onsuccess = () => {
          resolve(request.result ? request.result.chats : null);
        };

        request.onerror = () => {
          reject(request.error);
        };
      });
    } catch (err) {
      console.error('[ChatsCacheDB] Failed to read cached chats list:', err);
      return null;
    }
  }

  public static async put(userId: string, chats: any[]): Promise<void> {
    try {
      if (!userId || !chats) return;
      const db = await this.initDB();
      return new Promise<void>((resolve, reject) => {
        const transaction = db.transaction(STORE_NAME, 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.put({ userId, chats });

        request.onsuccess = () => {
          resolve();
        };

        request.onerror = () => {
          reject(request.error);
        };
      });
    } catch (err) {
      console.error('[ChatsCacheDB] Saving chats list cache failed:', err);
    }
  }

  public static async clear(): Promise<void> {
    try {
      const db = await this.initDB();
      return new Promise<void>((resolve, reject) => {
        const transaction = db.transaction(STORE_NAME, 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.clear();

        request.onsuccess = () => {
          resolve();
        };

        request.onerror = () => {
          reject(request.error);
        };
      });
    } catch (err) {
      console.error('[ChatsCacheDB] clear failed:', err);
    }
  }
}
