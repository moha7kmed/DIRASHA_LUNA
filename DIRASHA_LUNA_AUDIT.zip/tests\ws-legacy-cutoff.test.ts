/**
 * DIR-NEW-09 (external audit) — WebSocket legacy JWT fallback is FAIL-CLOSED.
 *
 * The review found the upgrade path still accepted the long-lived access JWT
 * via ?token= or Bearer-in-Sec-WebSocket-Protocol with only a deprecation
 * warning — keeping the leak-to-proxy-logs transport alive for every client
 * that never migrated. The cutoff is now:
 *
 *   - default REJECT: no upgrade at all (403 + Arabic reason), before any
 *     JWT is parsed;
 *   - explicit opt-in: WS_ALLOW_LEGACY_WS_TOKEN=1 re-opens the deprecated
 *     transport for the documented client-rollout transition window (the env
 *     must be deleted after rollout).
 *
 * Test split (repo convention — ws_server.ts is import-safe):
 *   1. BEHAVIORAL: the pure decision function shouldAcceptLegacyWsToken(env).
 *   2. STATIC-SOURCE: the upgrade path consults the decision and rejects with
 *      the Arabic reason string when it is false; the ticket path is intact.
 *
 * Run: npx vitest run tests/ws-legacy-cutoff.test.ts
 */
import { describe, it, expect } from 'vitest';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  shouldAcceptLegacyWsToken,
  LEGACY_WS_TOKEN_REJECT_REASON,
} from '../src/server/websocket/ws_server.ts';

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const wsSrc = fs.readFileSync(path.join(repoRoot, 'src/server/websocket/ws_server.ts'), 'utf8');

describe('shouldAcceptLegacyWsToken — pure fail-closed decision', () => {
  it('rejects by default (env absent) — the deprecated transport stays closed', () => {
    expect(shouldAcceptLegacyWsToken({})).toBe(false);
    expect(shouldAcceptLegacyWsToken({ WS_ALLOW_LEGACY_WS_TOKEN: undefined })).toBe(false);
  });

  it('accepts ONLY the explicit opt-in value WS_ALLOW_LEGACY_WS_TOKEN=1', () => {
    expect(shouldAcceptLegacyWsToken({ WS_ALLOW_LEGACY_WS_TOKEN: '1' })).toBe(true);
  });

  it('rejects every other value ("0", garbage, wrong case) — no truthy coercion', () => {
    expect(shouldAcceptLegacyWsToken({ WS_ALLOW_LEGACY_WS_TOKEN: '0' })).toBe(false);
    expect(shouldAcceptLegacyWsToken({ WS_ALLOW_LEGACY_WS_TOKEN: '' })).toBe(false);
    expect(shouldAcceptLegacyWsToken({ WS_ALLOW_LEGACY_WS_TOKEN: 'true' })).toBe(false);
    expect(shouldAcceptLegacyWsToken({ WS_ALLOW_LEGACY_WS_TOKEN: 'yes' })).toBe(false);
    expect(shouldAcceptLegacyWsToken({ WS_ALLOW_LEGACY_WS_TOKEN: 'enabled' })).toBe(false);
    expect(shouldAcceptLegacyWsToken({ WS_ALLOW_LEGACY_WS_TOKEN: '1 ' })).toBe(false);
    expect(shouldAcceptLegacyWsToken({ WS_ALLOW_LEGACY_WS_TOKEN: ' 1' })).toBe(false);
    expect(shouldAcceptLegacyWsToken({ WS_ALLOW_LEGACY_WS_TOKEN: '01' })).toBe(false);
    expect(shouldAcceptLegacyWsToken({ WS_ALLOW_LEGACY_WS_TOKEN: '2' })).toBe(false);
    expect(shouldAcceptLegacyWsToken({ UNRELATED: '1' })).toBe(false);
  });

  it('the exported reject reason is the required Arabic message', () => {
    expect(LEGACY_WS_TOKEN_REJECT_REASON).toBe(
      'اتصال WebSocket يتطلب تذكرة قصيرة العمر — حدّث العميل.',
    );
  });
});

describe('ws_server.ts upgrade path — legacy cutoff wiring (static)', () => {
  it('consults shouldAcceptLegacyWsToken() in the upgrade handler', () => {
    const upgradeBlock = wsSrc.slice(wsSrc.indexOf('server.on("upgrade"'));
    expect(upgradeBlock).toContain('shouldAcceptLegacyWsToken()');
    // The decision gates the LEGACY transports only, never the ticket path.
    expect(upgradeBlock).toContain('(queryToken || isLegacyJwtUpgrade) &&');
  });

  it('rejects legacy upgrades with 403 + the Arabic reason and NO upgrade when the flag is off', () => {
    const upgradeBlock = wsSrc.slice(wsSrc.indexOf('server.on("upgrade"'));
    expect(upgradeBlock).toContain('!shouldAcceptLegacyWsToken()');
    expect(upgradeBlock).toContain('rejectUpgrade(');
    expect(upgradeBlock).toContain('403 Forbidden');
    // The reject call wires in the exported Arabic reason constant (its exact
    // value is asserted in the pure-function block above).
    expect(upgradeBlock).toContain('${LEGACY_WS_TOKEN_REJECT_REASON}');
    // The reject happens BEFORE any JWT verification on the legacy path.
    const gateIdx = upgradeBlock.indexOf('!shouldAcceptLegacyWsToken()');
    const verifyIdx = upgradeBlock.indexOf('AuthService.verifyAccessToken(token)');
    expect(gateIdx).toBeGreaterThan(-1);
    expect(verifyIdx).toBeGreaterThan(gateIdx);
  });

  it('logs a clear security rejection (not a silent drop) for the closed transport', () => {
    const upgradeBlock = wsSrc.slice(wsSrc.indexOf('server.on("upgrade"'));
    expect(upgradeBlock).toContain(
      'legacy ?token=/Bearer-protocol WebSocket upgrade rejected (WS_ALLOW_LEGACY_WS_TOKEN is not',
    );
  });

  it('keeps the documented opt-in transition window: accepted legacy upgrades still warn', () => {
    // Under WS_ALLOW_LEGACY_WS_TOKEN=1 the pre-existing one-shot deprecation
    // warning remains — the window is observable, not silent.
    expect(wsSrc).toContain('legacyTokenDeprecationWarned');
    expect(wsSrc).toContain('DEPRECATION: legacy ?token=/Bearer-protocol WebSocket upgrades are deprecated');
    expect(wsSrc).toContain('WS_ALLOW_LEGACY_WS_TOKEN=1');
    // The window is explicitly documented as temporary (delete after rollout).
    expect(wsSrc).toContain('deleted once the client rollout completes');
  });

  it('the ticket path is unaffected by the cutoff', () => {
    expect(wsSrc).toContain('consumeWsTicket(queryTicket, upgradeOrigin)');
    // The ticket branch completes its upgrade before any legacy gate.
    const ticketIdx = wsSrc.indexOf('if (queryTicket)');
    const gateIdx = wsSrc.indexOf('!shouldAcceptLegacyWsToken()');
    expect(ticketIdx).toBeGreaterThan(-1);
    expect(gateIdx).toBeGreaterThan(ticketIdx);
  });
});
