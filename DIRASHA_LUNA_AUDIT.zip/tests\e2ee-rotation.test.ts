/**
 * Project 10 — Emergency Key Rotation (تدوير مفاتيح الطوارئ) tests.
 *
 * Covers the three mandated scenarios:
 *   (r1) after emergencyRotate: identity keys CHANGED, ALL sessions wiped,
 *        fresh 100-OPK pool (old OPK privs deleted), SPK re-signed, and the
 *        server re-registration with the SAME deviceId confirms (registered).
 *   (r2) a peer holding a session with the OLD identity: pre-rotation traffic
 *        (stale bootstrap with the old ik) fails CLOSED with RekeyDetectedError
 *        (identity-currency check), and the next fresh bootstrap re-establishes
 *        a working two-directional session with the NEW identity.
 *   (r3) mid-failure: the registration POST fails during emergencyRotate → the
 *        call throws, but the LOCAL identity is already the new one (persisted
 *        before any network call, registered:false) → a retry via
 *        ensureRegistered() (idempotent per deviceId) completes registration and
 *        partners' sessions rebuild.
 *
 * Also pins the server-contract hook the rotation relies on: a same-device
 * re-registration with NEW identity keys is flagged as an identity change
 * (mirrors src/server/routes/e2ee.ts, which publishes 'e2ee:rekey' to DM
 * partners on exactly this condition).
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';

import { DirashaE2EE, E2eeError } from '../src/lib/e2ee/engine.ts';
import { MemoryKVStore } from '../src/lib/e2ee/store.ts';
import type { IdentityRecord, KVStore } from '../src/lib/e2ee/types.ts';

/* ── Mock server (multi-device contract + identity-change detection) ──────── */

interface ServerOpk { id: number; pub: string; consumed: boolean }
interface ServerDeviceReg {
  deviceId: string;
  identityDhPub: string;
  identitySigPub: string;
  signedPrekeyPub: string;
  prekeySignature: string;
  opks: ServerOpk[];
}

function createMockServer() {
  const regs = new Map<string, Map<string, ServerDeviceReg>>();
  /** Same-device re-registrations whose identity keys changed (the exact
   * condition src/server/routes/e2ee.ts uses to publish 'e2ee:rekey'). */
  const rekeyEvents: Array<{ user: string; deviceId: string }> = [];
  let registerCalls = 0;
  /** When true, every POST /api/e2ee/register returns 500 (mid-failure test). */
  let failRegisters = false;

  const userOf = (init?: RequestInit): string => {
    const headers = (init?.headers ?? {}) as Record<string, string>;
    return String(headers.Authorization ?? '').replace(/^Bearer\s+/, '');
  };
  const respond = (status: number, data: unknown) =>
    new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json' } });

  const fetch = async (url: any, init?: RequestInit): Promise<Response> => {
    const path = String(url).split('?')[0];
    const method = (init?.method ?? 'GET').toUpperCase();
    const body = init?.body ? JSON.parse(String(init.body)) : {};
    const user = userOf(init);

    if (path === '/api/e2ee/register' && method === 'POST') {
      registerCalls++;
      if (failRegisters) return respond(500, { error: 'registration failed (simulated outage)' });
      const deviceId = typeof body.deviceId === 'string' && body.deviceId ? body.deviceId : 'default';
      let devices = regs.get(user);
      if (!devices) {
        devices = new Map<string, ServerDeviceReg>();
        regs.set(user, devices);
      }
      const prev = devices.get(deviceId);
      // Identity-change detection — mirrors the server's rekey push condition:
      // SAME device row re-registered with DIFFERENT identity keys.
      if (prev && prev.identityDhPub !== body.identityDhPub) {
        rekeyEvents.push({ user, deviceId });
      }
      devices.set(deviceId, {
        deviceId,
        identityDhPub: body.identityDhPub,
        identitySigPub: body.identitySigPub,
        signedPrekeyPub: body.signedPrekeyPub,
        prekeySignature: body.prekeySignature,
        opks: (body.oneTimePrekeys ?? []).map((o: any) => ({ id: o.id, pub: o.pub, consumed: false })),
      });
      return respond(200, { ok: true });
    }
    if (path.startsWith('/api/e2ee/bundle/') && method === 'GET') {
      const devices = regs.get(path.split('/').pop()!);
      if (!devices || devices.size === 0) return respond(404, { registered: false });
      return respond(200, {
        registered: true,
        devices: [...devices.values()].map((d) => {
          const opk = d.opks.find((o) => !o.consumed) ?? null;
          if (opk) opk.consumed = true;
          return {
            deviceId: d.deviceId,
            identityDhPub: d.identityDhPub,
            identitySigPub: d.identitySigPub,
            signedPrekeyPub: d.signedPrekeyPub,
            prekeySignature: d.prekeySignature,
            opk: opk ? { id: opk.id, pub: opk.pub } : null,
          };
        }),
      });
    }
    if (path === '/api/e2ee/prekeys' && method === 'POST') {
      const devices = regs.get(user);
      if (!devices || devices.size === 0) return respond(404, { ok: false });
      const primary = [...devices.values()][0];
      for (const o of body.oneTimePrekeys ?? []) primary.opks.push({ id: o.id, pub: o.pub, consumed: false });
      return respond(200, { ok: true, opkRemaining: 0 });
    }
    if (path === '/api/e2ee/status' && method === 'GET') {
      const devices = regs.get(user);
      const remaining = devices
        ? [...devices.values()].reduce((a, d) => a + d.opks.filter((o) => !o.consumed).length, 0)
        : 0;
      return respond(200, { registered: !!devices && devices.size > 0, opkRemaining: remaining });
    }
    if (path.startsWith('/api/e2ee/identity/') && method === 'GET') {
      const devices = regs.get(path.split('/').pop()!);
      if (!devices || devices.size === 0) return respond(404, { registered: false });
      const primary = [...devices.values()][0];
      return respond(200, {
        registered: true,
        identityDhPub: primary.identityDhPub,
        identitySigPub: primary.identitySigPub,
        deviceCount: devices.size,
      });
    }
    return respond(404, { error: 'not found' });
  };

  return {
    fetch,
    regs,
    rekeyEvents,
    getRegisterCalls: () => registerCalls,
    failRegistersNow: () => { failRegisters = true; },
    resumeRegisters: () => { failRegisters = false; },
  };
}

/* ── Harness ──────────────────────────────────────────────────────────────── */

let server: ReturnType<typeof createMockServer>;

function makeEngine(user: string, store?: KVStore): DirashaE2EE {
  return new DirashaE2EE({
    authHeaders: () => ({ Authorization: `Bearer ${user}` }),
    store: store ?? new MemoryKVStore(),
  });
}

async function loadIdentityRecord(engine: DirashaE2EE): Promise<IdentityRecord> {
  // The engine's identity record is persisted in its KV layer under 'identity';
  // tests read the persisted shape through the (private) loadIdentity reader.
  const rec = await (engine as unknown as { loadIdentity(): Promise<IdentityRecord | null> }).loadIdentity();
  if (!rec) throw new Error('identity record missing');
  return rec;
}

async function kvKeys(engine: DirashaE2EE): Promise<string[]> {
  return (engine as unknown as { kv: KVStore }).kv.keys();
}

async function kvGet(engine: DirashaE2EE, key: string): Promise<string | null> {
  return (engine as unknown as { kv: KVStore }).kv.get(key);
}

/** Establish confirmed sessions in BOTH directions (Alice ↔ Bob). */
async function establishSessions(alice: DirashaE2EE, bob: DirashaE2EE): Promise<void> {
  const m1 = (await alice.encryptMessage('bob', 'hi from alice')).content;
  expect((await bob.decryptMessage('alice', m1))).toEqual({ plaintext: 'hi from alice' });
  const m2 = (await bob.encryptMessage('alice', 'hi from bob')).content;
  expect((await alice.decryptMessage('bob', m2))).toEqual({ plaintext: 'hi from bob' });
}

describe('Project 10 — emergencyRotate', () => {
  beforeEach(() => {
    server = createMockServer();
    vi.stubGlobal('fetch', server.fetch as unknown as typeof fetch);
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('(r1) wipes all sessions, generates a completely new identity + fresh OPKs, and re-registers with the SAME deviceId', async () => {
    const alice = makeEngine('alice');
    const bob = makeEngine('bob');
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    await establishSessions(alice, bob);

    const before = await loadIdentityRecord(alice);
    const beforeSpk = JSON.parse((await kvGet(alice, 'spkPriv'))!);
    expect(beforeSpk.priv).toBeTruthy();

    // Sanity: sessions and old OPK privs (ids 1..100 from ensureRegistered) exist.
    const keysBefore = await kvKeys(alice);
    expect(keysBefore.some((k) => k.startsWith('session:'))).toBe(true);
    const oldOpkKeys = keysBefore.filter((k) => /^opk:\d+$/.test(k) && Number(k.slice(4)) <= 1000);
    expect(oldOpkKeys.length).toBeGreaterThan(0);

    const registerCallsBefore = server.getRegisterCalls();
    const result = await alice.emergencyRotate();

    expect(result).toEqual({ newIdentity: true });

    // Identity keys CHANGED (both IK_dh and IK_sig).
    const after = await loadIdentityRecord(alice);
    expect(after.dh.pub).not.toBe(before.dh.pub);
    expect(after.dh.priv).not.toBe(before.dh.priv);
    expect(after.sig.pub).not.toBe(before.sig.pub);
    expect(after.sig.priv).not.toBe(before.sig.priv);
    // SAME deviceId preserved (server replaces THIS device's row only).
    expect(after.deviceId).toBe(before.deviceId);
    // Server registration CONFIRMED (success only after the POST returned 200).
    expect(after.registered).toBe(true);
    expect(await alice.isRegistered()).toBe(true);
    expect(server.getRegisterCalls()).toBe(registerCallsBefore + 1);

    // ALL sessions gone (suffixed + legacy plain keys).
    const keysAfter = await kvKeys(alice);
    expect(keysAfter.filter((k) => k.startsWith('session:'))).toEqual([]);

    // Old OPK privs deleted; the pool is FRESH (new timestamp-anchored ids).
    for (const k of oldOpkKeys) expect(keysAfter).not.toContain(k);
    const newOpkKeys = keysAfter.filter((k) => /^opk:\d+$/.test(k) && Number(k.slice(4)) > 1000);
    expect(newOpkKeys.length).toBe(100);

    // SPK regenerated + re-signed by the new IK_sig.
    const afterSpk = JSON.parse((await kvGet(alice, 'spkPriv'))!);
    expect(afterSpk.priv).not.toBe(beforeSpk.priv);
    expect(afterSpk.sig).not.toBe(beforeSpk.sig);

    // Server contract hook: same-device identity change was detected (this is
    // the condition under which the real server publishes 'e2ee:rekey').
    expect(server.rekeyEvents).toContainEqual({ user: 'alice', deviceId: before.deviceId! });

    // Fresh identity is immediately usable end-to-end with the NEW keys.
    const m = (await alice.encryptMessage('bob', 'post-rotation')).content;
    expect((await bob.decryptMessage('alice', m))).toEqual({ plaintext: 'post-rotation' });
  });

  it('(r2) pre-rotation traffic against the old identity fails closed (RekeyDetectedError); the next bootstrap re-establishes', async () => {
    const alice = makeEngine('alice');
    const bob = makeEngine('bob');
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    // Capture Alice's FIRST bootstrap envelope (old identity, x3dh, old ik) —
    // this is the "pre-rotation traffic" we will deliver AFTER the rotation.
    const staleBootstrap = (await alice.encryptMessage('bob', 'pre-rotation')).content;

    // Complete a full confirmed session exchange (second message carries the
    // pending bootstrap too; Bob confirms it, then Bob replies).
    const m2 = (await alice.encryptMessage('bob', 'hello')).content;
    expect((await bob.decryptMessage('alice', m2))).toEqual({ plaintext: 'hello' });
    const m3 = (await bob.encryptMessage('alice', 'bob here')).content;
    expect((await alice.decryptMessage('bob', m3))).toEqual({ plaintext: 'bob here' });

    await alice.emergencyRotate();

    // Bob still holds the OLD-identity session. Delivering the stale
    // pre-rotation bootstrap: its env.ik is no longer Alice's REGISTERED
    // identity → the identity-currency check fails CLOSED.
    const rejected = await bob.decryptMessage('alice', staleBootstrap);
    expect(rejected).toEqual({ error: 'RekeyDetectedError' });

    // A message sealed WITHOUT a bootstrap but under the NEW identity against
    // Bob's OLD-identity session would also be rejected (never accepted as
    // authentic post-rekey). Here the recovery path: Alice's fresh bootstrap
    // (new ik, matches registration) rebuilds Bob's session.
    const fresh = (await alice.encryptMessage('bob', 'post-rotation')).content;
    expect((await bob.decryptMessage('alice', fresh))).toEqual({ plaintext: 'post-rotation' });

    // Re-established both directions on the NEW identity generation.
    const reply = (await bob.encryptMessage('alice', 're-synced')).content;
    expect((await alice.decryptMessage('bob', reply))).toEqual({ plaintext: 're-synced' });
    const again = (await alice.encryptMessage('bob', 'still working')).content;
    expect((await bob.decryptMessage('alice', again))).toEqual({ plaintext: 'still working' });
  });

  it('(r3) mid-failure: registration fails → local identity is already new → retry completes and sessions rebuild', async () => {
    const alice = makeEngine('alice');
    const bob = makeEngine('bob');
    await alice.ensureRegistered();
    await bob.ensureRegistered();
    await establishSessions(alice, bob);

    const before = await loadIdentityRecord(alice);

    // Simulate a server outage DURING rotation: local rotation persists first,
    // then the registration POST fails (all attempts).
    server.failRegistersNow();
    let threw: unknown = null;
    try {
      await alice.emergencyRotate();
    } catch (e) {
      threw = e;
    }
    expect(threw).toBeInstanceOf(E2eeError);

    // CRASH-SAFETY GUARANTEE: the local state is ALREADY the new identity
    // (persisted before any network call) — with registered:false.
    const midFailure = await loadIdentityRecord(alice);
    expect(midFailure.dh.pub).not.toBe(before.dh.pub);
    expect(midFailure.sig.pub).not.toBe(before.sig.pub);
    expect(midFailure.deviceId).toBe(before.deviceId);
    expect(midFailure.registered).toBe(false);
    expect(await alice.isRegistered()).toBe(false);
    // And ALL sessions were wiped locally despite the network failure.
    expect((await kvKeys(alice)).filter((k) => k.startsWith('session:'))).toEqual([]);

    // SELF-HEALING: registration is idempotent per (user, deviceId) — the
    // retry path (ensureRegistered, same in-flight-guarded entry the login
    // path uses) completes the registration with the SAME new identity.
    server.resumeRegisters();
    await expect(alice.ensureRegistered()).resolves.toEqual({ registered: true });
    const healed = await loadIdentityRecord(alice);
    expect(healed.dh.pub).toBe(midFailure.dh.pub); // no second rotation
    expect(healed.registered).toBe(true);
    expect(server.rekeyEvents).toContainEqual({ user: 'alice', deviceId: before.deviceId! });

    // Partners' sessions rebuild end-to-end on the rotated identity.
    const m = (await alice.encryptMessage('bob', 'recovered')).content;
    expect((await bob.decryptMessage('alice', m))).toEqual({ plaintext: 'recovered' });
    const reply = (await bob.encryptMessage('alice', 'confirmed')).content;
    expect((await alice.decryptMessage('bob', reply))).toEqual({ plaintext: 'confirmed' });
  });
});
