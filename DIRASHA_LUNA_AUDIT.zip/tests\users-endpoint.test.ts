/**
 * F5 — GET /api/users directory-dump hardening tests.
 *
 * server.ts boots the HTTP listener at import time (top-level `startServer()`),
 * so full-handler behavioral tests are not possible in-process without a
 * running Postgres. Per the audit-fix directive, these tests pin the
 * SECURITY-CRITICAL logic with static-source assertions (grep-style) over the
 * exact handler block, plus behavioral coverage of the new distributed
 * scrape-budget rule (behavioral limiter tests live in
 * tests/distributed-rate-limit.test.ts).
 *
 * Pinned guarantees:
 *   1. The route requires authentication (requireAuth → 401 when no token).
 *   2. The handler enforces the distributed 'users:directory:list' budget.
 *   3. Pagination: default 20, hard cap 100, non-negative offset.
 *   4. PUBLIC-FIELDS-ONLY projection: no email, no moderation/internal flags,
 *      no raw-row spread (`...u`).
 *   5. Response shape unchanged for existing consumers: `{ users: [...] }`.
 *
 * Run: npx vitest run tests/users-endpoint.test.ts
 */
import { describe, it, expect } from 'vitest';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { RATE_LIMIT_RULES } from '../src/server/services/rate_limiter.ts';

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const serverSrc = fs.readFileSync(path.join(repoRoot, 'server.ts'), 'utf8');

/** Extract the full source block of a route handler (registration → next route). */
function extractHandler(src: string, needle: string): string {
  const start = src.indexOf(needle);
  expect(start, `route registration not found: ${needle}`).toBeGreaterThan(-1);
  const next = src.indexOf('\n  app.', start + needle.length);
  return src.slice(start, next === -1 ? undefined : next);
}

const usersHandler = extractHandler(serverSrc, "app.get('/api/users', requireAuth");

describe('F5 — GET /api/users hardening', () => {
  it('requires authentication (requireAuth middleware → 401 without a token)', () => {
    // The handler is registered WITH requireAuth...
    expect(usersHandler.startsWith("app.get('/api/users', requireAuth")).toBe(true);
    // ...and requireAuth itself answers 401 when no token is presented.
    expect(serverSrc).toContain("return res.status(401).json({ error: 'Unauthorized: Access Token missing.' })");
  });

  it('enforces the distributed users:directory:list rate limit before listing', () => {
    expect(usersHandler).toContain("checkLimit('users:directory:list'");
    expect(usersHandler).toContain("res.status(429)");
    // The rule exists in the central table: 30/min/user.
    expect(RATE_LIMIT_RULES['users:directory:list']).toMatchObject({
      limit: 30,
      windowMs: 60 * 1000,
    });
  });

  it('paginates: default 20, hard cap 100, non-negative offset', () => {
    // Default 20 when limit is absent/NaN.
    expect(usersHandler).toMatch(/parsedLimit : 20/);
    // Hard cap: Math.min(..., 100).
    expect(usersHandler).toMatch(/Math\.min\(\s*[^;]*?, 100\)/);
    // Floor at 1 and non-negative offset.
    expect(usersHandler).toMatch(/Math\.max\(\s*[^;]*?, 1\)/);
    expect(usersHandler).toMatch(/Math\.max\(\s*[^;]*?parsedOffset[^;]*?, 0\)/);
  });

  it('projects PUBLIC fields only — no email, no internal/moderation flags, no raw spread', () => {
    // No private/internal field is ever emitted from the handler.
    for (const forbidden of ['email', 'isBanned', 'bannedUntil', 'banReason',
      'mutedUntil', 'muteReason', 'phoneNumber', 'passwordHash', 'pinHash',
      'role', 'deviceKeyHash', 'totpSecret', 'privacySettings']) {
      expect(usersHandler).not.toContain(`${forbidden}:`);
    }
    // Explicit allowlist fields a stranger may see.
    for (const required of ['id: u.id', 'username: u.username', 'displayName: u.displayName',
      'avatarUrl: avatarUrl', 'photoURL: avatarUrl', 'verified: u.verified']) {
      expect(usersHandler).toContain(required);
    }
    // No raw-row spread of the user object (mass-exfiltration guard).
    expect(usersHandler).not.toMatch(/\.\.\.u\b/);
  });

  it('keeps the response shape compatible: `{ users: [...] }`', () => {
    expect(usersHandler).toContain('res.status(200).json({ users:');
  });
});
