/**
 * AUTH-06 + AUTH-07 (external audit) — authClassic hardening tests.
 *
 * Test split (same constraint as tests/group-membership.test.ts — server.ts
 * boots the HTTP listener at import, so in-process route tests are impossible;
 * authClassic.ts is imported directly for its exported pure helpers, exactly
 * like tests/passkeys.test.ts does for passkeys.ts):
 *
 *   1. BEHAVIORAL (pure): hardened clientIp extraction (AUTH-07) —
 *      parseTrustedProxyHops + xffClientFromRight + clientIp with crafted
 *      X-Forwarded-For headers under TRUST_PROXY_HOPS=0/1/2. Spoofed XFF
 *      values must never win; unknown sources fail closed to the socket
 *      address or the shared 'unknown' bucket.
 *   2. BEHAVIORAL (pure): the new 'auth:pin:change' limiter rule (AUTH-06) —
 *      rule shape (5/10min, critical class), composite user+IP key isolation
 *      (one user's exhausted budget never affects another user's bucket,
 *      successes never reset a counter), and fail-closed behavior on a Redis
 *      outage (critical class).
 *   3. STATIC-SOURCE: the pin/change route calls checkLimit BEFORE
 *      verifySecret, answers 429 with the Arabic budget message, logs
 *      failures without any PIN material, and the limiter table carries the
 *      new rule + the per-instance honesty disclosure.
 *
 * Run: npx vitest run tests/authclassic-hardening.test.ts
 */
import { describe, it, expect, beforeAll, afterAll, afterEach } from 'vitest';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { parseTrustedProxyHops, xffClientFromRight, clientIp } from '../src/server/routes/authClassic.ts';
import {
  DistributedRateLimiter,
  RATE_LIMIT_RULES,
  type RateLimitRedisAdapter,
} from '../src/server/services/rate_limiter.ts';

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const authSrc = fs.readFileSync(path.join(repoRoot, 'src/server/routes/authClassic.ts'), 'utf8');
const limiterSrc = fs.readFileSync(path.join(repoRoot, 'src/server/services/rate_limiter.ts'), 'utf8');

/* ── 1. Hardened clientIp extraction (AUTH-07, pure behavior) ─────────────── */

let origHops: string | undefined;
beforeAll(() => { origHops = process.env.TRUST_PROXY_HOPS; });
afterAll(() => {
  if (origHops === undefined) delete process.env.TRUST_PROXY_HOPS;
  else process.env.TRUST_PROXY_HOPS = origHops;
});

/** Minimal Request stand-in. req.ip is a DECOY — the hardened helper must never use it. */
function fakeReq(xff: string | string[] | undefined, remoteAddress: string | undefined): any {
  const headers: Record<string, string | string[]> = {};
  if (xff !== undefined) headers['x-forwarded-for'] = xff;
  return { headers, socket: { remoteAddress }, ip: 'req.ip-decoy-must-not-be-used' };
}

describe('parseTrustedProxyHops — fail-closed env parsing (AUTH-07)', () => {
  it('unset / empty → 0 (socket address only, XFF never trusted)', () => {
    expect(parseTrustedProxyHops(undefined)).toBe(0);
    expect(parseTrustedProxyHops('')).toBe(0);
    expect(parseTrustedProxyHops('   ')).toBe(0);
  });

  it('valid non-negative integers parse (incl. surrounding whitespace)', () => {
    expect(parseTrustedProxyHops('0')).toBe(0);
    expect(parseTrustedProxyHops('1')).toBe(1);
    expect(parseTrustedProxyHops('2')).toBe(2);
    expect(parseTrustedProxyHops(' 3 ')).toBe(3);
  });

  it('garbage values fail closed to 0 (never a loose interpretation)', () => {
    expect(parseTrustedProxyHops('abc')).toBe(0);
    expect(parseTrustedProxyHops('-1')).toBe(0);
    expect(parseTrustedProxyHops('1.5')).toBe(0);
    expect(parseTrustedProxyHops('0x1')).toBe(0);
    expect(parseTrustedProxyHops('1e2')).toBe(0);
  });
});

describe('xffClientFromRight — Nth-from-the-RIGHT selection (AUTH-07)', () => {
  it('hops=1 → rightmost entry (the edge proxy appended it)', () => {
    expect(xffClientFromRight('forged-by-client,198.51.100.23', 1)).toBe('198.51.100.23');
    expect(xffClientFromRight('forged-by-client, 198.51.100.23', 1)).toBe('198.51.100.23');
  });

  it('hops=2 / hops=3 walk leftward from the right edge', () => {
    expect(xffClientFromRight('forged, edge-one, 198.51.100.23', 2)).toBe('edge-one');
    expect(xffClientFromRight('forged, edge-one, 198.51.100.23', 3)).toBe('forged');
  });

  it('whitespace entries are trimmed and empties skipped', () => {
    expect(xffClientFromRight('  forged ,  , 198.51.100.23 ', 1)).toBe('198.51.100.23');
    expect(xffClientFromRight(' 198.51.100.23 ', 1)).toBe('198.51.100.23');
  });

  it('chain shorter than the trusted-hop count → null (caller fails closed)', () => {
    expect(xffClientFromRight('forged', 2)).toBeNull();
    expect(xffClientFromRight('a,b,c', 4)).toBeNull();
    expect(xffClientFromRight('', 1)).toBeNull();
    expect(xffClientFromRight('   ', 1)).toBeNull();
  });

  it('hops < 1 → null (disables XFF consultation entirely)', () => {
    expect(xffClientFromRight('anything', 0)).toBeNull();
    expect(xffClientFromRight('anything', -1)).toBeNull();
  });
});

describe('clientIp — crafted headers under TRUST_PROXY_HOPS=0/1/2 (AUTH-07)', () => {
  // Each case manages the env explicitly; the hook guarantees a clean slate
  // for the next test even when a case throws.
  afterEach(() => { delete process.env.TRUST_PROXY_HOPS; });

  it('hops UNSET (default): a spoofed X-Forwarded-For is IGNORED — socket address wins', () => {
    delete process.env.TRUST_PROXY_HOPS;
    const req = fakeReq('6.6.6.6', '203.0.113.7');
    expect(clientIp(req)).toBe('203.0.113.7');
  });

  it('hops=0: XFF never consulted, even for the rightmost entry', () => {
    process.env.TRUST_PROXY_HOPS = '0';
    expect(clientIp(fakeReq('forged, 198.51.100.23', '203.0.113.7'))).toBe('203.0.113.7');
    expect(clientIp(fakeReq('198.51.100.23', '203.0.113.7'))).toBe('203.0.113.7');
  });

  it('hops unset + no socket address → shared unknown bucket (stricter, not looser)', () => {
    delete process.env.TRUST_PROXY_HOPS;
    expect(clientIp(fakeReq('6.6.6.6', undefined))).toBe('unknown');
    expect(clientIp(fakeReq(undefined, undefined))).toBe('unknown');
  });

  it('hops=1: rightmost XFF entry (the trusted edge appended the real client)', () => {
    process.env.TRUST_PROXY_HOPS = '1';
    expect(clientIp(fakeReq('forged-by-client, 198.51.100.23', '10.0.0.9'))).toBe('198.51.100.23');
  });

  it('hops=2: second-from-the-right entry', () => {
    process.env.TRUST_PROXY_HOPS = '2';
    expect(clientIp(fakeReq('forged-by-client, edge-one, 198.51.100.23', '10.0.0.9'))).toBe('edge-one');
  });

  it('hops set + XFF SHORTER than the hop count → fail closed to the socket address', () => {
    process.env.TRUST_PROXY_HOPS = '3';
    // Attacker sends a 1-entry forged chain: shifting the trust window must
    // not let the forged value be attributed.
    expect(clientIp(fakeReq('forged-by-client', '10.0.0.9'))).toBe('10.0.0.9');
    expect(clientIp(fakeReq(undefined, '10.0.0.9'))).toBe('10.0.0.9');
  });

  it('hops set + no socket address → trusted chain entry wins, else unknown bucket', () => {
    process.env.TRUST_PROXY_HOPS = '1';
    // No trusted chain available (no XFF) → shared unknown bucket.
    expect(clientIp(fakeReq(undefined, undefined))).toBe('unknown');
    // A full-length chain under a configured hop count is trusted even
    // without a socket address: the entry was appended by the outermost
    // trusted proxy, never by the client (deployment assumption: the app
    // port is only reachable through the edge proxy — true on Render).
    expect(clientIp(fakeReq('198.51.100.23', undefined))).toBe('198.51.100.23');
  });

  it('array-form XFF header (node repeats) is handled like the string form', () => {
    process.env.TRUST_PROXY_HOPS = '1';
    expect(clientIp(fakeReq(['forged-by-client', '198.51.100.23'], '10.0.0.9'))).toBe('198.51.100.23');
  });

  it('hops unset + garbage TRUST_PROXY_HOPS values still ignore XFF', () => {
    for (const garbage of ['abc', '-1', '1.5']) {
      process.env.TRUST_PROXY_HOPS = garbage;
      expect(clientIp(fakeReq('6.6.6.6', '203.0.113.7'))).toBe('203.0.113.7');
    }
  });
});

/* ── 2. auth:pin:change limiter rule (AUTH-06, pure behavior) ──────────────── */

/**
 * Compact mock with the SAME semantics as the production Lua script
 * (INCR + PEXPIRE-on-first + compare). 'down' mode = configured but
 * unreachable (evalAtomic → null) to exercise the fail-closed path.
 */
class MockRedis implements RateLimitRedisAdapter {
  private store = new Map<string, { count: number; expiresAt: number }>();
  constructor(private mode: 'ok' | 'down' | 'unconfigured' = 'ok') {}
  getIsConfigured(): boolean { return this.mode !== 'unconfigured'; }
  getIsConnected(): boolean { return this.mode === 'ok'; }
  async evalAtomic(_script: string, keys: string[], args: (string | number)[]): Promise<string | null> {
    if (this.mode !== 'ok') return null;
    const key = keys[0];
    const windowMs = Number(args[0]);
    const limit = Number(args[1]);
    const bucket = this.store.get(key);
    const count = (bucket ? bucket.count : 0) + 1;
    const expiresAt = bucket && bucket.expiresAt > Date.now() ? bucket.expiresAt : Date.now() + windowMs;
    this.store.set(key, { count, expiresAt });
    return count > limit ? '1' : '0';
  }
}

describe("RATE_LIMIT_RULES['auth:pin:change'] — rule shape (AUTH-06)", () => {
  it('tight budget: 5 attempts / 10 minutes, critical class (fail-closed on outage)', () => {
    expect(RATE_LIMIT_RULES['auth:pin:change']).toEqual({
      limit: 5,
      windowMs: 10 * 60 * 1000,
      class: 'critical',
    });
  });

  it('is a legal RateLimitRuleName (the table drives the route call)', () => {
    expect(Object.prototype.hasOwnProperty.call(RATE_LIMIT_RULES, 'auth:pin:change')).toBe(true);
  });
});

describe('auth:pin:change — composite user+IP key isolation (AUTH-06)', () => {
  it('5 attempts allowed, 6th denied within the window (per explicit composite key)', async () => {
    const limiter = new DistributedRateLimiter(new MockRedis('ok'));
    const key = 'user-1:203.0.113.7';
    for (let i = 0; i < 5; i++) expect(await limiter.check('auth:pin:change', key)).toBe(false);
    expect(await limiter.check('auth:pin:change', key)).toBe(true);
    expect(await limiter.check('auth:pin:change', key)).toBe(true);
  });

  it('SUCCESS never resets the counter: attempts are charged INCR-only', async () => {
    const limiter = new DistributedRateLimiter(new MockRedis('ok'));
    const key = 'user-1:203.0.113.7';
    expect(await limiter.check('auth:pin:change', key)).toBe(false); // "successful" attempt
    // Every later check keeps consuming — no success-induced refund/reset.
    expect(await limiter.check('auth:pin:change', key)).toBe(false);
    expect(await limiter.check('auth:pin:change', key)).toBe(false);
    expect(await limiter.check('auth:pin:change', key)).toBe(false);
    expect(await limiter.check('auth:pin:change', key)).toBe(false);
    expect(await limiter.check('auth:pin:change', key)).toBe(true);
  });

  it('per-user isolation: user A exhausting the budget never blocks user B', async () => {
    const limiter = new DistributedRateLimiter(new MockRedis('ok'));
    for (let i = 0; i < 5; i++) await limiter.check('auth:pin:change', 'user-1:203.0.113.7');
    expect(await limiter.check('auth:pin:change', 'user-1:203.0.113.7')).toBe(true); // A denied
    expect(await limiter.check('auth:pin:change', 'user-2:203.0.113.7')).toBe(false); // B unaffected
    expect(await limiter.check('auth:pin:change', 'user-2:203.0.113.9')).toBe(false); // B other IP unaffected
  });

  it('critical class FAILS CLOSED on a Redis outage (deny, never degrade silently)', async () => {
    const limiter = new DistributedRateLimiter(new MockRedis('down'));
    expect(await limiter.check('auth:pin:change', 'user-1:203.0.113.7')).toBe(true);
  });
});

/* ── 3. Static-source asserts (boot-at-import server — repo convention) ───── */

describe('pin/change route — checkLimit BEFORE verifySecret (AUTH-06, static)', () => {
  const pinBlock = authSrc.slice(authSrc.indexOf("app.post('/api/auth/pin/change'"));

  it('route exists and is requireAuth-gated', () => {
    expect(authSrc).toContain("app.post('/api/auth/pin/change', requireAuth");
  });

  it("checkLimit('auth:pin:change', userId:ip) runs BEFORE verifySecret", () => {
    const rlIdx = pinBlock.indexOf("checkLimit('auth:pin:change'");
    const vsIdx = pinBlock.indexOf('verifySecret(');
    expect(rlIdx).toBeGreaterThan(-1);
    expect(vsIdx).toBeGreaterThan(-1);
    expect(rlIdx).toBeLessThan(vsIdx);
  });

  it('the limiter key is the explicit per-call composite userId:ip', () => {
    expect(pinBlock).toContain("checkLimit('auth:pin:change', `${userId}:${ip}`)");
  });

  it('limit exceeded → 429 with the Arabic budget message', () => {
    expect(pinBlock).toContain('return res.status(429).json({ error:');
    expect(pinBlock).toContain('محاولات كثيرة على رمز PIN. حاول بعد عشر دقائق.');
  });

  it('wrong current PIN is audited WITHOUT any PIN material (outcome + ip only)', () => {
    expect(pinBlock).toContain("await db.logAuthAction(userId, 'pin_change_failed', { ip });");
    const logLine = pinBlock.slice(pinBlock.indexOf("'pin_change_failed'"));
    expect(logLine.slice(0, logLine.indexOf(');'))).not.toContain('currentPin');
    expect(logLine.slice(0, logLine.indexOf(');'))).not.toContain('newPin');
  });
});

describe('clientIp hardening wiring (AUTH-07, static)', () => {
  it('clientIp + pure helpers live in the shared lib; authClassic re-exports them', () => {
    // BATCH-6 (F-4): extracted to src/server/lib/trustedClientIp.ts so EVERY
    // limiter surface uses the same hardened attribution.
    const libSrc = fs.readFileSync(path.join(repoRoot, 'src', 'server', 'lib', 'trustedClientIp.ts'), 'utf8');
    expect(libSrc).toContain('export function clientIp');
    expect(libSrc).toContain('export function parseTrustedProxyHops');
    expect(libSrc).toContain('export function xffClientFromRight');
    expect(authSrc).toMatch(/export \{ clientIp, parseTrustedProxyHops, xffClientFromRight \}/);
  });

  it('trust model: TRUST_PROXY_HOPS env + socket-anchored fallback are present', () => {
    const libSrc = fs.readFileSync(path.join(repoRoot, 'src', 'server', 'lib', 'trustedClientIp.ts'), 'utf8');
    expect(libSrc).toContain('process.env.TRUST_PROXY_HOPS');
    expect(libSrc).toContain('req.socket');
    expect(libSrc).toContain('remoteAddress');
  });

  it('the spoofable FIRST-XFF extraction is gone (AUTH-07 fix, not a patch on top)', () => {
    expect(authSrc).not.toContain("xff.split(',')[0]");
    expect(authSrc).not.toContain('FIRST entry of x-forwarded-for');
  });

  it('every IP-keyed limiter in this file flows through the hardened clientIp', () => {
    // register / login / recover / pin-change all derive `ip` via clientIp(req)
    const deriveCount = authSrc.split('const ip = clientIp(req);').length - 1;
    expect(deriveCount).toBeGreaterThanOrEqual(4);
    expect(authSrc).toContain("checkLimit('auth:register:ip', ip)");
    expect(authSrc).toContain("checkLimit('auth:login:ip', ip)");
    expect(authSrc).toContain("checkLimit('auth:recover:ip', ip)");
  });
});

describe('rate_limiter.ts — rule registered + shared-limiter honesty (static)', () => {
  it("'auth:pin:change' rule is in the central table with the tuned values", () => {
    expect(limiterSrc).toContain("'auth:pin:change'");
    expect(limiterSrc).toMatch(/'auth:pin:change':\s*\{\s*limit:\s*5,\s*windowMs:\s*10 \* 60 \* 1000,\s*class:\s*'critical'/);
  });

  it('in-memory fallback honesty: per-instance limitation is disclosed in-source', () => {
    expect(limiterSrc).toContain('IN-MEMORY');
    expect(limiterSrc).toContain('PER-INSTANCE');
    expect(limiterSrc).toContain('limit × instance-count');
  });
});
