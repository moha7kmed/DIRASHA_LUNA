/**
 * Group Call Sessions (server-side, in-memory registry)
 * ------------------------------------------------------
 * Mesh group calls for small groups (max 4 participants).
 *
 * This module ONLY tracks group-call sessions (who is in which call).
 * It holds NO media and NO signaling state — the actual WebRTC offer /
 * answer / ICE-candidate exchange between every pair of participants
 * rides the EXISTING 1:1 `call:signal` relay in ws_server.ts
 * (handleCallSignal), with the client including `groupCallId` inside
 * the `callId` slot (or as a sibling field) of the relay payload.
 *
 * Sessions are intentionally volatile: if the server restarts, calls
 * drop — same trade-off the 1:1 `activeCalls` registry already makes.
 */

import { randomUUID } from 'crypto';

/** Hard cap for mesh mode. Above this an SFU is required (see docs/GROUP_CALLS_DESIGN_AR.md). */
export const GROUP_CALL_MAX_PARTICIPANTS = 4;

export interface GroupCallParticipant {
  userId: string;
  /** epoch ms */
  joinedAt: number;
}

export interface GroupCallSession {
  groupCallId: string;
  chatId: string;
  initiatorId: string;
  createdAt: number;
  participants: Map<string, GroupCallParticipant>;
  maxParticipants: number;
}

export type GroupCallErrorCode =
  | 'NOT_FOUND'
  | 'FULL'
  | 'ALREADY_IN_CALL'
  | 'NOT_A_PARTICIPANT';

export class GroupCallError extends Error {
  public readonly code: GroupCallErrorCode;
  constructor(code: GroupCallErrorCode, message: string) {
    super(message);
    this.name = 'GroupCallError';
    this.code = code;
  }
}

/** groupCallId → session */
const sessions = new Map<string, GroupCallSession>();

/** Create a new group-call session for a chat. Returns the session. */
export function createGroupCall(chatId: string, initiatorId: string): GroupCallSession {
  const session: GroupCallSession = {
    groupCallId: 'gcall-' + randomUUID(),
    chatId,
    initiatorId,
    createdAt: Date.now(),
    participants: new Map(),
    maxParticipants: GROUP_CALL_MAX_PARTICIPANTS,
  };
  sessions.set(session.groupCallId, session);
  return session;
}

/**
 * Join an existing session. Capacity is enforced here; chat-membership
 * MUST be validated by the caller (routes use db.getChatMembers).
 *
 * Re-joining while already a participant is idempotent (returns the
 * current roster without erroring) so a flaky client retry is safe.
 *
 * Returns the full participant roster so the joiner can open one
 * RTCPeerConnection per existing participant (mesh).
 */
export function joinGroupCall(groupCallId: string, userId: string): {
  groupCallId: string;
  chatId: string;
  initiatorId: string;
  participants: GroupCallParticipant[];
} {
  const session = sessions.get(groupCallId);
  if (!session) {
    throw new GroupCallError('NOT_FOUND', 'Group call not found');
  }

  if (!session.participants.has(userId)) {
    if (session.participants.size >= session.maxParticipants) {
      throw new GroupCallError('FULL', 'Group call is full (max ' + session.maxParticipants + ' participants)');
    }
    session.participants.set(userId, { userId, joinedAt: Date.now() });
  }

  return snapshot(session);
}

/** Remove a participant. Returns true if the user was in the call. */
export function leaveGroupCall(groupCallId: string, userId: string): boolean {
  const session = sessions.get(groupCallId);
  if (!session) return false;
  const removed = session.participants.delete(userId);
  // Auto-teardown: last person out closes the session.
  if (session.participants.size === 0) {
    sessions.delete(groupCallId);
  }
  return removed;
}

/** End/remove a session entirely (e.g. initiator hangs up for everyone). */
export function endGroupCall(groupCallId: string): boolean {
  return sessions.delete(groupCallId);
}

/** All active sessions for a chat (newest first). */
export function listActive(chatId: string): Array<{
  groupCallId: string;
  chatId: string;
  initiatorId: string;
  createdAt: number;
  participants: GroupCallParticipant[];
}> {
  const out: Array<ReturnType<typeof snapshot>> = [];
  for (const session of sessions.values()) {
    if (session.chatId !== chatId) continue;
    out.push(snapshot(session));
  }
  return out.sort((a, b) => b.createdAt - a.createdAt);
}

/** Look up a session without joining (used by routes for pre-checks). */
export function getGroupCall(groupCallId: string): GroupCallSession | undefined {
  return sessions.get(groupCallId);
}

function snapshot(session: GroupCallSession) {
  return {
    groupCallId: session.groupCallId,
    chatId: session.chatId,
    initiatorId: session.initiatorId,
    createdAt: session.createdAt,
    participants: Array.from(session.participants.values())
      .sort((a, b) => a.joinedAt - b.joinedAt),
  };
}
