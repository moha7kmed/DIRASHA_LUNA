/**
 * DIR-NEW-08 (external audit) — scan-secrets.cjs coverage honesty.
 *
 * The independent review proved the scanner PRINTED "PASS across 229 files"
 * without ever reading the sensitive files it claimed to cover: .pem/.key
 * were absent from TEXT_EXTENSIONS and path.extname('.env.example') returns
 * '.example', so the '.env.example' list entry was dead. These tests run the
 * REAL scanner as a child process against a throwaway tree and assert:
 *
 *   1. A .key file carrying a private-key block is read and FAILS the run.
 *   2. A .pem certificate is content-scanned (no false positive on a plain
 *      CERTIFICATE — the real repo fixture is fed through to prove it).
 *   3. A high-entropy literal in .env.example is detected (basename rule).
 *   4. tests/fixtures/test-ca.key is skipped ONLY as an exact declared path —
 *      the same basename anywhere else is still scanned.
 *   5. The PASS line reports real coverage: scanned N (skipped: X
 *      declared-fixture, Y non-text) across Z listed files.
 *
 * Run: npx vitest run tests/scanner-hardening.test.ts
 */
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { execFileSync } from 'child_process';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { fileURLToPath } from 'url';

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SCANNER_SRC = path.join(repoRoot, 'scripts', 'scan-secrets.cjs');
const REPO_CA_KEY = path.join(repoRoot, 'tests', 'fixtures', 'test-ca.key');
const REPO_CA_PEM = path.join(repoRoot, 'tests', 'fixtures', 'test-ca.pem');

// High-entropy literal for the .env.example case — Shannon entropy 5.0
// bits/char, above the scanner's MIN_ASSIGNMENT_ENTROPY (3.2), 32 chars of
// the assignment-value alphabet, and not a benign/placeholder value.
const HIGH_ENTROPY_LITERAL = 'Kx9mQ2vL7pZ4wR8sT3nY6bC1dF5gH0jM';

let tmp: string;

beforeEach(() => {
  tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'scan-secrets-test-'));
  // Empty .git dir pins git-ls-files to this tree; an empty repo lists no
  // files so the scanner deterministically falls back to walking the tree.
  fs.mkdirSync(path.join(tmp, '.git'));
  fs.mkdirSync(path.join(tmp, 'scripts'));
  fs.copyFileSync(SCANNER_SRC, path.join(tmp, 'scripts', 'scan-secrets.cjs'));
});

afterEach(() => {
  fs.rmSync(tmp, { recursive: true, force: true });
  tmp = '';
});

interface RunResult {
  status: number;
  stdout: string;
  stderr: string;
}

function runScanner(): RunResult {
  try {
    const stdout = execFileSync(process.execPath, ['scripts/scan-secrets.cjs'], {
      cwd: tmp,
      encoding: 'utf8',
    });
    return { status: 0, stdout, stderr: '' };
  } catch (err: any) {
    return {
      status: err.status ?? -1,
      stdout: typeof err.stdout === 'string' ? err.stdout : '',
      stderr: typeof err.stderr === 'string' ? err.stderr : String(err.message ?? ''),
    };
  }
}

function write(rel: string, content: string): void {
  const abs = path.join(tmp, rel);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  fs.writeFileSync(abs, content);
}

const PRIVATE_KEY_BODY =
  '-----BEGIN PRIVATE KEY-----\n' + // gitleaks:allow (synthetic sample for the scanner test — not a real key)
  'MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCURbz2SIEtLuPw\n' +
  'MzHmhMF1U+oZ86azXGfVdYeByAQdwTg4geFBZlf2EJXBcSf568MrxJDm6zPF7srX\n' +
  '-----END PRIVATE KEY-----\n';

const PASS_LINE_RE =
  /\[scan-secrets\] PASS — scanned (\d+) files \(skipped: (\d+) declared-fixture, (\d+) non-text\) across (\d+) listed files/;

describe('scan-secrets.cjs — DIR-NEW-08 coverage honesty (child-process runs)', () => {
  it('detects a private-key block inside a .key file (exit 1 + finding)', () => {
    write('secrets/leaked.key', PRIVATE_KEY_BODY);
    const r = runScanner();
    expect(r.status).toBe(1);
    expect(r.stderr).toContain('[scan-secrets] FAIL');
    expect(r.stderr).toContain('private-key-block');
    expect(r.stderr).toContain('leaked.key');
  });

  it('content-scans a .pem certificate without false-positive on a plain CERTIFICATE', () => {
    // Feed the repo's real reviewed fixture content through: a genuine
    // X.509 certificate (base64 body, no private key) must be READ (it is
    // counted as scanned) yet produce no finding.
    const cert = fs.readFileSync(REPO_CA_PEM, 'utf8');
    expect(cert).toContain('-----BEGIN CERTIFICATE-----');
    write('certs/host.pem', cert);
    const r = runScanner();
    expect(r.status).toBe(0);
    const m = PASS_LINE_RE.exec(r.stdout);
    expect(m).not.toBeNull();
    const [scanned, declared, nonText, listed] = m!.slice(1).map(Number);
    // scripts/scan-secrets.cjs (self-scan; every pattern line is gitleaks:allow)
    // plus certs/host.pem — proves the .pem was content-scanned, not skipped.
    expect(scanned).toBe(2);
    expect(declared).toBe(0);
    expect(nonText).toBe(0);
    expect(listed).toBe(2);
  });

  it('detects a high-entropy literal in .env.example (basename rule, exit 1)', () => {
    // path.extname('.env.example') === '.example' — only the
    // /^\.env(\..+)?$/ basename rule gets this file scanned.
    write('.env.example', `API_KEY="${HIGH_ENTROPY_LITERAL}"\n`);
    const r = runScanner();
    expect(r.status).toBe(1);
    expect(r.stderr).toContain('[scan-secrets] FAIL');
    expect(r.stderr).toContain('high-entropy-assignment');
    expect(r.stderr).toContain('.env.example');
  });

  it('skips tests/fixtures/test-ca.key ONLY as an exact declared path', () => {
    // Same content, same basename, DIFFERENT path — must still be scanned.
    // The exempted copy at the exact declared path is skipped and counted.
    write('tests/fixtures/test-ca.key', fs.readFileSync(REPO_CA_KEY, 'utf8'));
    write('tests/fixtures/impostor/test-ca.key', PRIVATE_KEY_BODY);
    const r = runScanner();
    expect(r.status).toBe(1);
    expect(r.stderr).toContain('impostor');
    expect(r.stderr).not.toContain('tests/fixtures/test-ca.key');
  });

  it('PASS line reports scanned vs skipped counts (declared-fixture + non-text)', () => {
    write('tests/fixtures/test-ca.key', fs.readFileSync(REPO_CA_KEY, 'utf8'));
    write('notes.bin', PRIVATE_KEY_BODY); // non-text extension — skipped, counted
    write('hello.txt', 'nothing suspicious here\n');
    const r = runScanner();
    expect(r.status).toBe(0);
    const m = PASS_LINE_RE.exec(r.stdout);
    expect(m).not.toBeNull();
    const [scanned, declared, nonText, listed] = m!.slice(1).map(Number);
    // scanned = scanner self + hello.txt; declared = the exact fixture path;
    // non-text = notes.bin (its private-key block stays unread — that skip
    // is now VISIBLE instead of silently folded into the old total).
    expect(scanned).toBe(2);
    expect(declared).toBe(1);
    expect(nonText).toBe(1);
    expect(listed).toBe(4);
    expect(scanned + declared + nonText).toBe(listed);
    expect(r.stdout).not.toContain('no secrets detected across');
  });

  it('the FAIL path is unchanged and does not print the coverage line', () => {
    write('secrets/leaked.key', PRIVATE_KEY_BODY);
    const r = runScanner();
    expect(r.status).toBe(1);
    expect(r.stderr).toContain('[scan-secrets] FAIL');
    expect(r.stdout).not.toMatch(PASS_LINE_RE);
  });
});
