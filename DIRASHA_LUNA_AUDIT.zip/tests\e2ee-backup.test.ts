/**
 * Dirasha E2EE — encrypted backup module tests.
 *
 * Covers: create→open round-trip (multi-chat, multi-message, unicode),
 * wrong passphrase → BackupError BAD_PASSPHRASE, corrupted ciphertext →
 * BAD_PASSPHRASE, truncated/garbage/magic-mismatch/malformed-header →
 * MALFORMED, fingerprint stability + divergence (incl. hint-based compare),
 * unicode passphrase round-trip, empty chats edge, per-backup salt/iv
 * freshness with both backups still openable, and the BackupManager wrapper.
 */
import { describe, it, expect } from 'vitest';

import {
  createBackup,
  openBackup,
  exportAccountBackup,
  importAccountBackup,
  backupFingerprint,
  fingerprintFromHint,
  BackupError,
  BackupManager,
  BACKUP_MAGIC,
  BACKUP_INFO,
  BACKUP_KIND,
  BACKUP_KIND_V2,
  BACKUP_VERSION,
  BACKUP_VERSION_V2,
  BACKUP_SUPPORTED_VERSIONS,
  BACKUP_SALT_BYTES,
  BACKUP_IV_BYTES,
  type BackupChats,
} from '../src/lib/e2ee/backup.ts';
import { b64decode, utf8Decode } from '../src/lib/e2ee/crypto.ts';

/** Multi-chat, multi-message snapshot with unicode content. */
function sampleChats(): BackupChats {
  return [
    {
      chatId: 'chat-1',
      peerName: 'أحمد',
      messages: [
        { id: 'm1', senderId: 'user-a', senderName: 'أحمد', content: 'مرحبا، كيف حالك؟', createdAt: '2026-01-01T10:00:00.000Z', type: 'text' },
        { id: 'm2', senderId: 'user-me', senderName: 'Me', content: 'بخير الحمد لله ✓ — with emoji 🎉', createdAt: '2026-01-01T10:00:05.000Z', type: 'text' },
      ],
    },
    {
      chatId: 'chat-2',
      peerName: 'Sara',
      messages: [
        { id: 'm3', senderId: 'user-s', senderName: 'Sara', content: 'see you tomorrow', createdAt: '2026-01-02T09:30:00.000Z', type: 'text' },
        { id: 'm4', senderId: 'user-me', senderName: 'Me', content: '', createdAt: '2026-01-02T09:31:00.000Z', type: 'text' },
      ],
    },
  ];
}

/** Decode the b64 header JSON that follows the magic prefix. */
function parseHeader(fileText: string): {
  v: number; salt: string; iv: string; ct: string; hint: string;
} {
  expect(fileText.startsWith(BACKUP_MAGIC)).toBe(true);
  const json = utf8Decode(b64decode(fileText.slice(BACKUP_MAGIC.length)));
  return JSON.parse(json);
}

describe('createBackup / openBackup round-trip', () => {
  it('round-trips multi-chat multi-message data', () => {
    const chats = sampleChats();
    const fileText = createBackup('correct horse battery staple', chats);

    expect(fileText.startsWith(BACKUP_MAGIC)).toBe(true);
    const opened = openBackup('correct horse battery staple', fileText);
    expect(opened.chats).toEqual(chats);
    expect(typeof opened.createdAt).toBe('string');
    expect(Number.isNaN(Date.parse(opened.createdAt))).toBe(false);
  });

  it('serializes the documented header structure (v, salt, iv, ct, hint)', () => {
    const fileText = createBackup('pw', sampleChats());
    const header = parseHeader(fileText);

    expect(header.v).toBe(1);
    expect(b64decode(header.salt).length).toBe(BACKUP_SALT_BYTES);
    expect(b64decode(header.iv).length).toBe(BACKUP_IV_BYTES);
    expect(b64decode(header.ct).length).toBeGreaterThan(16); // ct || 16B tag
    expect(typeof header.hint).toBe('string');
    expect(b64decode(header.hint).length).toBe(8);
  });

  it('seals a payload with the documented kind', () => {
    const fileText = createBackup('pw', sampleChats());
    const header = parseHeader(fileText);
    // Payload itself is AEAD-protected; just assert the constant is exported
    // and stable so integration code can rely on it.
    expect(BACKUP_KIND).toBe('dirasha-backup-v1');
    expect(BACKUP_INFO).toBe('DirashaBackup-v1');
    expect(header.ct.length).toBeGreaterThan(0);
  });
});

describe('wrong passphrase / corruption', () => {
  it('wrong passphrase → BackupError with code BAD_PASSPHRASE', () => {
    const fileText = createBackup('right-passphrase', sampleChats());
    let err: unknown;
    try {
      openBackup('wrong-passphrase', fileText);
    } catch (e) {
      err = e;
    }
    expect(err).toBeInstanceOf(BackupError);
    const be = err as BackupError;
    expect(be.name).toBe('BackupError');
    expect(be.code).toBe('BAD_PASSPHRASE');
    expect(be.message.length).toBeGreaterThan(0);
  });

  it('corrupted ciphertext → BAD_PASSPHRASE', () => {
    const fileText = createBackup('pw', sampleChats());
    const header = parseHeader(fileText);
    // Flip one bit-bearing char in the middle of the ct b64 (never the last
    // char, whose low bits can be padding-only).
    const idx = Math.floor(header.ct.length / 2);
    const orig = header.ct[idx];
    const repl = orig === 'A' ? 'B' : 'A';
    header.ct = header.ct.slice(0, idx) + repl + header.ct.slice(idx + 1);
    const corrupted = BACKUP_MAGIC + btoa(JSON.stringify(header));

    expect(() => openBackup('pw', corrupted)).toThrowError(BackupError);
    try {
      openBackup('pw', corrupted);
      expect.unreachable('should have thrown');
    } catch (e) {
      expect((e as BackupError).code).toBe('BAD_PASSPHRASE');
    }
  });

  it('tampered salt (AAD mismatch) → BAD_PASSPHRASE, not silent success', () => {
    const fileText = createBackup('pw', sampleChats());
    const header = parseHeader(fileText);
    // Replace salt with a different valid 16-byte salt: AAD then differs.
    const salt = b64decode(header.salt);
    salt[0] ^= 0x01;
    header.salt = btoa(String.fromCharCode(...salt));
    const tampered = BACKUP_MAGIC + btoa(JSON.stringify(header));
    try {
      openBackup('pw', tampered);
      expect.unreachable('should have thrown');
    } catch (e) {
      expect((e as BackupError).code).toBe('BAD_PASSPHRASE');
    }
  });
});

describe('malformed input', () => {
  const pw = 'pw';

  function expectMalformed(fileText: string): void {
    try {
      openBackup(pw, fileText);
      expect.unreachable('should have thrown');
    } catch (e) {
      expect(e).toBeInstanceOf(BackupError);
      expect((e as BackupError).code).toBe('MALFORMED');
    }
  }

  it('truncated file → MALFORMED', () => {
    const fileText = createBackup(pw, sampleChats());
    expectMalformed(fileText.slice(0, Math.floor(fileText.length / 2)));
  });

  it('garbage text → MALFORMED', () => {
    expectMalformed('this is not a backup at all');
    expectMalformed('');
  });

  it('magic mismatch → MALFORMED', () => {
    const fileText = createBackup(pw, sampleChats());
    expectMalformed('OTHER:' + fileText.slice(BACKUP_MAGIC.length));
    expectMalformed('dirbk1:' + fileText.slice(BACKUP_MAGIC.length)); // case-sensitive
  });

  it('valid b64 but invalid header JSON → MALFORMED', () => {
    expectMalformed(BACKUP_MAGIC + btoa('not json {{{'));
  });

  it('header JSON array / missing fields → MALFORMED', () => {
    expectMalformed(BACKUP_MAGIC + btoa(JSON.stringify([1, 2, 3])));
    expectMalformed(BACKUP_MAGIC + btoa(JSON.stringify({ v: 1 })));
  });

  it('wrong version → MALFORMED', () => {
    const fileText = createBackup(pw, sampleChats());
    const header = parseHeader(fileText);
    header.v = 99;
    expectMalformed(BACKUP_MAGIC + btoa(JSON.stringify(header)));
  });

  it('wrong salt/iv lengths → MALFORMED', () => {
    const fileText = createBackup(pw, sampleChats());
    const h1 = parseHeader(fileText);
    h1.salt = btoa('short-salt');
    expectMalformed(BACKUP_MAGIC + btoa(JSON.stringify(h1)));
    const h2 = parseHeader(fileText);
    h2.iv = btoa('bad-iv');
    expectMalformed(BACKUP_MAGIC + btoa(JSON.stringify(h2)));
  });

  it('tampered payload kind (valid AEAD forge impossible — wrong kind after header edit) → MALFORMED or BAD_PASSPHRASE only', () => {
    // kind lives inside the encrypted payload, so it cannot be edited without
    // failing the AEAD tag; this test pins that neither error code is ever
    // anything else than the two documented codes.
    const fileText = createBackup(pw, sampleChats());
    const header = parseHeader(fileText);
    header.hint = 'AAAAAAAA';
    const edited = BACKUP_MAGIC + btoa(JSON.stringify(header));
    try {
      openBackup(pw, edited);
      // hint is not authenticated by the AEAD; a mismatched hint alone must
      // NOT block opening (it's cosmetic), so success is acceptable here.
    } catch (e) {
      expect(['BAD_PASSPHRASE', 'MALFORMED']).toContain((e as BackupError).code);
    }
  });
});

describe('backupFingerprint', () => {
  it('is stable per passphrase and 8 lowercase hex chars', () => {
    const a1 = backupFingerprint('same-passphrase');
    const a2 = backupFingerprint('same-passphrase');
    expect(a1).toBe(a2);
    expect(a1).toMatch(/^[0-9a-f]{8}$/);
  });

  it('differs across passphrases', () => {
    const a = backupFingerprint('alpha');
    const b = backupFingerprint('beta');
    expect(a).not.toBe(b);
  });

  it('fingerprintFromHint(hint) matches backupFingerprint(passphrase, salt)', () => {
    const passphrase = 'fingerprint-check';
    const chats = sampleChats();
    const fileText = createBackup(passphrase, chats);
    const header = parseHeader(fileText);

    const fromHint = fingerprintFromHint(header.hint);
    expect(fromHint).toMatch(/^[0-9a-f]{8}$/);
    // With the file's salt, the passphrase fingerprint must equal the hint's.
    expect(backupFingerprint(passphrase, header.salt)).toBe(fromHint);
    // A wrong passphrase (with the file's salt) almost surely differs.
    expect(backupFingerprint('not-the-passphrase', header.salt)).not.toBe(fromHint);
  });
});

describe('unicode & edge cases', () => {
  it('unicode passphrase round-trips; other unicode passphrase fails cleanly', () => {
    const chats = sampleChats();
    const fileText = createBackup('كلمة السر 🔐 パスワード', chats);
    const opened = openBackup('كلمة السر 🔐 パスワード', fileText);
    expect(opened.chats).toEqual(chats);

    try {
      openBackup('كلمة السر', fileText);
      expect.unreachable('should have thrown');
    } catch (e) {
      expect((e as BackupError).code).toBe('BAD_PASSPHRASE');
    }
  });

  it('empty chats edge case round-trips', () => {
    const fileText = createBackup('pw', []);
    const opened = openBackup('pw', fileText);
    expect(opened.chats).toEqual([]);
    expect(Array.isArray(opened.chats)).toBe(true);
  });

  it('chat with empty messages array round-trips', () => {
    const chats: BackupChats = [{ chatId: 'c1', peerName: 'Peer', messages: [] }];
    const opened = openBackup('pw', createBackup('pw', chats));
    expect(opened.chats).toEqual(chats);
  });
});

describe('salt/iv freshness', () => {
  it('two backups of the same data use different salt and iv, both openable', () => {
    const chats = sampleChats();
    const f1 = createBackup('pw', chats);
    const f2 = createBackup('pw', chats);

    const h1 = parseHeader(f1);
    const h2 = parseHeader(f2);
    expect(h1.salt).not.toBe(h2.salt);
    expect(h1.iv).not.toBe(h2.iv);
    expect(h1.ct).not.toBe(h2.ct);

    expect(openBackup('pw', f1).chats).toEqual(chats);
    expect(openBackup('pw', f2).chats).toEqual(chats);
  });
});

describe('BackupManager wrapper', () => {
  it('delegates create/open/fingerprint', () => {
    const mgr = new BackupManager();
    const chats = sampleChats();
    const fileText = mgr.create('pw', chats);
    expect(fileText.startsWith(BACKUP_MAGIC)).toBe(true);
    expect(mgr.open('pw', fileText).chats).toEqual(chats);
    expect(mgr.fingerprint('pw')).toMatch(/^[0-9a-f]{8}$/);
  });

  it('delegates account export/import (v2) — accepts v1 files too', () => {
    const mgr = new BackupManager();
    const chats = sampleChats();
    const v2File = mgr.exportAccount('pw', chats);
    expect(mgr.importAccount('pw', v2File).chats).toEqual(chats);
    const v1File = mgr.create('pw', chats);
    expect(mgr.importAccount('pw', v1File).chats).toEqual(chats);
  });
});

/* ══ Project 11 — full ACCOUNT backup (payload v2) ══ */

describe('exportAccountBackup / importAccountBackup (v2, multi-chat)', () => {
  it('round-trips a multi-chat account backup with metadata intact', () => {
    const chats = sampleChats();
    const fileText = exportAccountBackup('account-passphrase 🔐', chats);

    expect(fileText.startsWith(BACKUP_MAGIC)).toBe(true);
    const opened = importAccountBackup('account-passphrase 🔐', fileText);
    expect(opened.chats).toEqual(chats);
    expect(typeof opened.createdAt).toBe('string');
    expect(Number.isNaN(Date.parse(opened.createdAt))).toBe(false);
  });

  it('writes header v=2 and seals the documented v2 payload kind', () => {
    const chats = sampleChats();
    const fileText = exportAccountBackup('pw', chats);
    const header = parseHeader(fileText);
    expect(header.v).toBe(BACKUP_VERSION_V2);
    expect(header.v).toBe(2);
    expect(b64decode(header.salt).length).toBe(BACKUP_SALT_BYTES);
    expect(b64decode(header.iv).length).toBe(BACKUP_IV_BYTES);
    // BACKUP_KIND_V2 is a stable constant the UI/integration can rely on.
    expect(BACKUP_KIND_V2).toBe('dirasha-backup-v2');
  });

  it('v1 files still open — via importAccountBackup AND via openBackup (back-compat)', () => {
    const chats = sampleChats();
    const v1File = createBackup('pw', chats);
    expect(parseHeader(v1File).v).toBe(BACKUP_VERSION);
    expect(importAccountBackup('pw', v1File).chats).toEqual(chats);
    expect(openBackup('pw', v1File).chats).toEqual(chats);
  });

  it('version guard: a v2 account file opened through the strict v1 openBackup → MALFORMED', () => {
    const fileText = exportAccountBackup('pw', sampleChats());
    expect(() => openBackup('pw', fileText)).toThrowError(BackupError);
    try {
      openBackup('pw', fileText);
      expect.unreachable('should have thrown');
    } catch (e) {
      expect((e as BackupError).code).toBe('MALFORMED');
    }
  });

  it('wrong passphrase on an account file → BAD_PASSPHRASE', () => {
    const fileText = exportAccountBackup('right-pass', sampleChats());
    try {
      importAccountBackup('wrong-pass', fileText);
      expect.unreachable('should have thrown');
    } catch (e) {
      expect(e).toBeInstanceOf(BackupError);
      expect((e as BackupError).code).toBe('BAD_PASSPHRASE');
    }
  });

  it('format-version guard: a FUTURE header version (v3) is rejected, never parsed guessingly', () => {
    const fileText = exportAccountBackup('pw', sampleChats());
    const header = parseHeader(fileText);
    header.v = 3;
    const future = BACKUP_MAGIC + btoa(JSON.stringify(header));
    try {
      importAccountBackup('pw', future);
      expect.unreachable('should have thrown');
    } catch (e) {
      expect((e as BackupError).code).toBe('MALFORMED');
      expect((e as BackupError).message).toContain('unsupported backup version');
    }
    expect([...BACKUP_SUPPORTED_VERSIONS]).toEqual([1, 2]);
  });

  it('empty account (zero chats) round-trips; invalid snapshot fails fast before scrypt', () => {
    const empty = exportAccountBackup('pw', []);
    expect(importAccountBackup('pw', empty).chats).toEqual([]);

    // Structurally invalid snapshot → MALFORMED immediately (no AEAD needed).
    expect(() => exportAccountBackup('pw', [{} as any])).toThrowError(BackupError);
    expect(() => exportAccountBackup('pw', [{ chatId: 'c', peerName: 'p', messages: [{}] } as any]))
      .toThrowError(BackupError);
  });
});
