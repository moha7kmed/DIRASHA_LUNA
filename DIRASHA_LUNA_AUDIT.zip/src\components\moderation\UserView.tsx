import React from 'react';
import { User as UserIcon, ShieldAlert, Calendar, CheckCircle, Ban, Trash2, ShieldCheck, Mail, Clock, MessageSquare, Users as GroupsIcon, Flag, ArrowRight, RefreshCw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { User } from '../../types.ts';
import { UserBadge, StatusBadge } from './ModerationShared.tsx';

interface UserListViewProps {
  users: User[];
  loading: boolean;
  onSelectUser: (user: User) => void;
}

export function UserListView({ users, loading, onSelectUser }: UserListViewProps) {
  if (loading && users.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-zinc-500">
        <Clock className="w-8 h-8 animate-spin mb-3 opacity-20" />
        <span className="text-[10px] font-black uppercase tracking-widest">Hydrating user directory...</span>
      </div>
    );
  }

  if (users.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-zinc-500 border border-dashed border-white/5 rounded-[32px]">
        <UserIcon className="w-10 h-10 mb-3 opacity-10" />
        <span className="text-sm font-bold">No accounts found in directory</span>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-10">
      {users.map((user) => (
        <motion.div
          key={user.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          onClick={() => onSelectUser(user)}
          className="p-6 bg-white/[0.02] border border-white/5 rounded-[32px] hover:bg-white/[0.05] hover:border-white/10 transition-all cursor-pointer group flex items-center justify-between gap-4 overflow-hidden backdrop-blur-md"
        >
          <div className="min-w-0 flex-1">
            <UserBadge user={user} />
          </div>

          <div className="flex flex-col items-end gap-3 shrink-0">
             <div className="flex items-center gap-2">
               {user.isBanned && <StatusBadge status="banned" label="Banned" />}
               <StatusBadge status={user.role || 'user'} label={user.role || 'User'} />
             </div>
             <div className="flex items-center gap-1.5 text-[9px] text-zinc-700 font-black uppercase tracking-widest opacity-60">
               <Clock className="w-3 h-3" />
               <span>EST. {new Date(user.createdAt).getFullYear()}</span>
             </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}

interface UserDetailsViewProps {
  user: User;
  stats: {
    messages: number;
    chats: number;
    reportsAgainst: number;
    reportsBy: number;
    warnings?: number;
  } | null;
  loadingStats: boolean;
  canManageRoles: boolean;
  notes?: any[];
  warnings?: any[];
  enforcementHistory?: any[];
  reports?: any[];
  onUpdateRole: (role: 'user' | 'admin' | 'developer') => void;
  onUpdateVerified: (verified: boolean) => void;
  onMute: (durationHours: number, reason: string) => void;
  onUnmute: () => void;
  onBan: (durationHours: number, reason: string) => void;
  onUnban: () => void;
  onAddNote: (content: string) => void;
  onAddWarning: (reason: string, severity: number) => void;
  onClearWarnings: () => void;
  onBack: () => void;
}

export function UserDetailsView({ 
  user, stats, loadingStats, canManageRoles, 
  notes = [], warnings = [], enforcementHistory = [], reports = [],
  onUpdateRole, onUpdateVerified, 
  onMute, onUnmute, onBan, onUnban, 
  onAddNote, onAddWarning, onClearWarnings, onBack 
}: UserDetailsViewProps) {
  const [showMuteDialog, setShowMuteDialog] = React.useState(false);
  const [showBanDialog, setShowBanDialog] = React.useState(false);
  const [showWarningDialog, setShowWarningDialog] = React.useState(false);
  const [reason, setReason] = React.useState('');
  const [noteContent, setNoteContent] = React.useState('');
  const [muteDuration, setMuteDuration] = React.useState(1);
  const [banDuration, setBanDuration] = React.useState(-1);
  const [warningSeverity, setWarningSeverity] = React.useState(1);
  const [isUpdating, setIsUpdating] = React.useState(false);
  const [activeSubTab, setActiveSubTab] = React.useState<'overview' | 'enforcement' | 'reports' | 'notes'>('overview');

  const DURATION_OPTIONS = [
    { label: '1 Hour', value: 1 },
    { label: '6 Hours', value: 6 },
    { label: '12 Hours', value: 12 },
    { label: '24 Hours', value: 24 },
    { label: '3 Days', value: 72 },
    { label: '7 Days', value: 168 },
    { label: '30 Days', value: 720 },
    { label: 'Permanent', value: -1 },
  ];

  return (
    <div className="space-y-8 pb-10">
      {/* Header with back button */}
      <div className="flex flex-col md:flex-row md:items-center gap-6 justify-between">
        <div className="flex items-center gap-6">
          <button onClick={onBack} className="p-3 bg-white/[0.03] hover:bg-white/[0.08] rounded-2xl transition-all text-zinc-400 hover:text-white border border-white/5 hover:border-white/10 backdrop-blur-md">
            <ArrowRight className="w-5 h-5" />
          </button>
          <div className="flex-1">
            <h2 className="text-2xl font-black tracking-tight text-white flex items-center gap-3">
               {user.displayName}
               <div className="flex items-center gap-2">
                 {user.isBanned && <StatusBadge status="banned" label="Banned" />}
                 <StatusBadge status={user.role || 'user'} label={user.role || 'User'} />
                 {user.verified && <ShieldCheck className="w-5 h-5 text-indigo-400" />}
               </div>
            </h2>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">@{user.username}</span>
              <span className="w-1 h-1 bg-zinc-800 rounded-full" />
              <span className="text-[10px] text-zinc-600 font-bold uppercase tracking-widest">{user.email}</span>
            </div>
          </div>
        </div>

        {/* Sub-tabs */}
        <div className="flex items-center gap-1 p-1 bg-white/5 border border-white/5 rounded-2xl backdrop-blur-xl animate-fadeIn">
           {(['overview', 'enforcement', 'reports', 'notes'] as const).map(tab => {
             const label = tab === 'overview' ? 'Overview' :
                           tab === 'enforcement' ? 'Enforcement' :
                           tab === 'reports' ? `Reports (${reports.length})` : 'Notes';
             return (
               <button
                 key={tab}
                 onClick={() => setActiveSubTab(tab)}
                 className={`px-4 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${
                   activeSubTab === tab ? 'bg-white text-black shadow-lg' : 'text-zinc-500 hover:text-zinc-300'
                 }`}
               >
                 {label}
               </button>
             );
           })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Card */}
        <div className="lg:col-span-2 space-y-8">
          {activeSubTab === 'overview' && (
            <>
              <div className="p-8 bg-white/[0.02] border border-white/5 rounded-[36px] space-y-8 shadow-inner backdrop-blur-xl">
                 <div className="grid grid-cols-2 xs:grid-cols-3 md:grid-cols-5 gap-4">
                   <StatBox label="Messages" value={loadingStats ? '...' : stats?.messages || 0} icon={<MessageSquare className="w-4 h-4" />} />
                   <StatBox label="Chats" value={loadingStats ? '...' : stats?.chats || 0} icon={<GroupsIcon className="w-4 h-4" />} />
                   <StatBox label="Reports" value={loadingStats ? '...' : stats?.reportsAgainst || 0} icon={<Flag className="w-4 h-4" />} red />
                   <StatBox label="Warnings" value={loadingStats ? '...' : stats?.warnings || 0} icon={<ShieldAlert className="w-4 h-4" />} red />
                   <StatBox label="Filed" value={loadingStats ? '...' : stats?.reportsBy || 0} icon={<CheckCircle className="w-4 h-4" />} />
                 </div>

                 <div className="h-px bg-white/5" />

                 <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                   <InfoItem icon={<Mail className="w-4 h-4" />} label="Email Address" value={user.email} />
                   <InfoItem icon={<Calendar className="w-4 h-4" />} label="Registration Date" value={new Date(user.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })} />
                   <InfoItem icon={<Clock className="w-4 h-4" />} label="Last Activity" value={user.lastSeen ? new Date(user.lastSeen).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'Never'} />
                   <InfoItem icon={<ShieldCheck className="w-4 h-4" />} label="System Role" value={user.role || 'user'} />
                 </div>
                 
                 {user.bio && (
                   <div className="p-6 bg-black/20 border border-white/5 rounded-[24px]">
                     <p className="text-[9px] font-black uppercase text-zinc-600 mb-3 tracking-widest">Account Bio</p>
                     <p className="text-sm text-zinc-400 leading-relaxed font-medium">"{user.bio}"</p>
                   </div>
                 )}
              </div>

              {canManageRoles && (
                <div className="p-8 bg-white/[0.02] border border-white/10 rounded-[36px] space-y-6 backdrop-blur-xl">
                   <h3 className="text-[10px] font-black text-zinc-500 uppercase tracking-widest flex items-center gap-2 px-1">
                     <ShieldCheck className="w-4 h-4" />
                     Clearance & Rank Authority
                   </h3>
                   
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                     {/* Role Switcher */}
                     <div className="space-y-3">
                       <p className="text-[9px] font-black text-zinc-600 uppercase tracking-widest px-1">Identity Rank</p>
                       <div className="flex gap-2 p-1.5 bg-black/20 rounded-2xl border border-white/5">
                          {(['user', 'admin', 'developer'] as const).map(r => (
                            <button 
                              key={r}
                              disabled={isUpdating}
                              onClick={() => { setIsUpdating(true); onUpdateRole(r); setTimeout(() => setIsUpdating(false), 1000); }}
                              className={`flex-1 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${user.role === r ? 'bg-white text-black shadow-lg shadow-white/10' : 'text-zinc-600 hover:text-zinc-300 hover:bg-white/5'}`}
                            >
                              {r}
                            </button>
                          ))}
                       </div>
                     </div>

                     {/* Verification Toggle */}
                     <div className="space-y-3">
                       <p className="text-[9px] font-black text-zinc-600 uppercase tracking-widest px-1">Security Verification</p>
                       <button 
                         disabled={isUpdating}
                         onClick={() => { setIsUpdating(true); onUpdateVerified(!user.verified); setTimeout(() => setIsUpdating(false), 1000); }}
                         className={`w-full py-3 rounded-2xl border text-[9px] font-black uppercase tracking-widest flex items-center justify-center gap-3 transition-all ${
                           user.verified 
                           ? 'bg-indigo-500/10 border-indigo-500/20 text-indigo-400' 
                           : 'bg-white/5 border-white/10 text-zinc-500'
                         }`}
                       >
                         {user.verified ? <ShieldCheck className="w-4 h-4" /> : <ShieldAlert className="w-4 h-4" />}
                         {user.verified ? 'Verified Identity' : 'Unverified Identity'}
                       </button>
                     </div>
                   </div>
                </div>
              )}

              <div className="p-8 bg-white/[0.01] border border-white/5 rounded-[36px] space-y-6 backdrop-blur-md">
                 <h3 className="text-[10px] font-black text-zinc-500 uppercase tracking-widest flex items-center gap-2 px-1">
                   <ShieldAlert className="w-4 h-4" />
                   Rapid Enforcement
                 </h3>
                 <div className="flex flex-wrap gap-4">
                   {!user.isBanned ? (
                     <button onClick={() => setShowBanDialog(true)} className="px-8 py-3.5 bg-rose-500/10 hover:bg-rose-500 text-rose-500 hover:text-white text-[9px] font-black uppercase tracking-widest rounded-xl transition-all flex items-center gap-3 border border-rose-500/20 active:scale-95">
                       <Ban className="w-4 h-4" />
                       Final Ban
                     </button>
                   ) : (
                     <button onClick={onUnban} className="px-8 py-3.5 bg-emerald-500/10 hover:bg-emerald-500 text-emerald-500 hover:text-white text-[9px] font-black uppercase tracking-widest rounded-xl transition-all flex items-center gap-3 border border-emerald-500/20">
                       <RefreshCw className="w-4 h-4" />
                       Revoke Ban
                     </button>
                   )}

                   {(!user.mutedUntil || new Date(user.mutedUntil) <= new Date()) ? (
                     <button onClick={() => setShowMuteDialog(true)} className="px-8 py-3.5 bg-zinc-500/10 hover:bg-white text-zinc-400 hover:text-black text-[9px] font-black uppercase tracking-widest rounded-xl transition-all flex items-center gap-3 border border-white/10 active:scale-95">
                       <Clock className="w-4 h-4" />
                       Restriction Mute
                     </button>
                   ) : (
                     <button onClick={onUnmute} className="px-8 py-3.5 bg-zinc-500/10 hover:bg-white text-zinc-400 hover:text-black text-[9px] font-black uppercase tracking-widest rounded-xl transition-all flex items-center gap-3 border border-white/10">
                       <RefreshCw className="w-4 h-4" />
                       Lift Mute
                     </button>
                   )}

                   <button 
                     onClick={() => setShowWarningDialog(true)}
                     className="px-8 py-3.5 bg-amber-500/10 hover:bg-amber-500 text-amber-500 hover:text-white text-[9px] font-black uppercase tracking-widest rounded-xl transition-all flex items-center gap-3 border border-amber-500/20 active:scale-95"
                   >
                     <ShieldAlert className="w-4 h-4" />
                     Issue Warning
                   </button>
                 </div>
              </div>
            </>
          )}

          {activeSubTab === 'enforcement' && (
            <div className="space-y-6">
               <div className="flex items-center justify-between px-1">
                  <h3 className="text-[11px] font-black text-zinc-400 uppercase tracking-widest">Enforcement Audit Log</h3>
                  {warnings.length > 0 && (
                    <button onClick={onClearWarnings} className="text-[10px] font-black text-rose-500 underline uppercase tracking-widest">Wipe Warnings</button>
                  )}
               </div>

               {/* Active Warnings Section */}
               <div className="grid grid-cols-1 gap-4">
                  <p className="text-[9px] font-black text-zinc-700 uppercase tracking-widest px-1">Recent Citations</p>
                  {warnings.length === 0 ? (
                     <div className="p-10 text-center bg-white/[0.01] border border-dashed border-white/5 rounded-[32px]">
                        <span className="text-[10px] font-black text-zinc-700 uppercase tracking-widest">No citation history recorded</span>
                     </div>
                  ) : (
                    warnings.map((w, i) => (
                      <div key={i} className="p-6 bg-white/[0.02] border border-white/5 rounded-[28px] flex items-start gap-4">
                        <div className="p-3 bg-amber-500/5 rounded-2xl text-amber-500">
                           <ShieldAlert className="w-5 h-5" />
                        </div>
                        <div className="flex-1 space-y-1">
                           <div className="flex items-center justify-between">
                              <span className="text-[10px] font-black text-zinc-200 uppercase tracking-widest">{w.reason}</span>
                              <span className="text-[9px] font-bold text-zinc-600">{new Date(w.createdAt).toLocaleDateString()}</span>
                           </div>
                           <p className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest opacity-60">Officer: {w.author_name}</p>
                        </div>
                      </div>
                    ))
                  )}
               </div>

               {/* General Enforcement History */}
               <div className="grid grid-cols-1 gap-4 pt-4 border-t border-white/5">
                  <p className="text-[9px] font-black text-zinc-700 uppercase tracking-widest px-1">Global Audit Record</p>
                  {enforcementHistory.length === 0 ? (
                    <div className="p-10 text-center bg-white/[0.01] border border-dashed border-white/5 rounded-[32px]">
                       <span className="text-[10px] font-black text-zinc-700 uppercase tracking-widest">No administrative actions logged</span>
                    </div>
                  ) : (
                    enforcementHistory.map((h, i) => (
                      <div key={i} className="p-6 bg-black/20 border border-white/5 rounded-[28px] flex items-center gap-5">
                         <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center shrink-0 border border-white/10">
                            <span className="text-[10px] font-black text-zinc-600 uppercase">{(h.eventType || '').split('_')[1]?.[0] || h.eventType?.[0] || 'A'}</span>
                         </div>
                         <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-4">
                               <h5 className="text-[11px] font-black text-white uppercase tracking-widest truncate">{h.targetResource || h.eventType}</h5>
                               <span className="text-[9px] font-bold text-zinc-600 shrink-0">{new Date(h.createdAt).toLocaleDateString()}</span>
                            </div>
                            <p className="text-[10px] text-zinc-500 font-bold truncate mt-1">BY {h.actor_name || 'SYSTEM'}</p>
                         </div>
                      </div>
                    ))
                  )}
               </div>
            </div>
          )}

          {activeSubTab === 'reports' && (
             <div className="space-y-6">
                <div className="flex items-center justify-between px-1">
                   <h3 className="text-[11px] font-black text-zinc-400 uppercase tracking-widest">Reports File (سجل البلاغات)</h3>
                </div>

                <div className="space-y-4">
                   {reports.length === 0 ? (
                      <div className="p-16 text-center bg-white/[0.01] border border-dashed border-white/5 rounded-[40px]">
                         <span className="text-[10px] font-black text-zinc-700 uppercase tracking-widest">No reports filed against this user (لا توجد بلاغات مسجلة ضد المستخدم)</span>
                      </div>
                   ) : (
                      reports.map((r, i) => (
                        <div key={i} className="p-6 bg-white/[0.02] border border-white/5 rounded-[36px] space-y-4 relative overflow-hidden group">
                           <div className="flex items-center justify-between border-b border-white/5 pb-4">
                              <div className="flex items-center gap-3">
                                 <span className="text-[10px] font-black text-white uppercase tracking-widest bg-zinc-800 px-3 py-1.5 rounded-full">
                                    {r.category || 'General Violation'}
                                 </span>
                                 <span className={`text-[9px] font-black uppercase tracking-widest px-2.5 py-1 rounded-full ${
                                   r.status === 'Pending' ? 'bg-amber-500/10 text-amber-500 border border-amber-500/20' : 
                                   r.status === 'Resolved' ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' : 
                                   'bg-zinc-800 text-zinc-400'
                                 }`}>
                                    {r.status === 'Pending' ? 'Pending (لم يتم مراجعتها)' : r.status === 'Resolved' ? 'Resolved (تمت المراجعة والحل)' : r.status}
                                 </span>
                              </div>
                              <span className="text-[9px] font-bold text-zinc-500">
                                 {new Date(r.createdAt || Date.now()).toLocaleString()}
                              </span>
                           </div>
                           <div className="space-y-2">
                              <div className="text-xs text-zinc-300 font-medium">
                                 <strong className="text-zinc-500 text-[10px] uppercase font-black tracking-wider block mb-1">Incident Report Description / الوصف</strong>
                                 {r.description || 'No description provided.'}
                              </div>
                              {r.targetMessageId && (
                                <p className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest">
                                   Target Message ID: <span className="font-mono text-zinc-400 bg-white/5 px-2 py-1 rounded">{r.targetMessageId}</span>
                                </p>
                              )}
                              <p className="text-[9px] font-bold text-zinc-600 uppercase tracking-widest pt-2">
                                 Reporter: @{r.reporterUsername || 'anonymous'} ({r.reporterName || 'Anonymous'})
                              </p>
                           </div>
                        </div>
                      ))
                   )}
                </div>
             </div>
           )}

          {activeSubTab === 'notes' && (
            <div className="space-y-6">
               <div className="flex items-center justify-between px-1">
                  <h3 className="text-[11px] font-black text-zinc-400 uppercase tracking-widest">Stationery Records (Internal)</h3>
               </div>

               <div className="p-6 bg-white/[0.02] border border-white/10 rounded-[32px] space-y-4">
                  <textarea 
                    value={noteContent}
                    onChange={(e) => setNoteContent(e.target.value)}
                    placeholder="Document observation..."
                    className="w-full h-32 bg-black/40 border border-white/10 rounded-2xl p-5 text-sm text-white focus:outline-none focus:border-white/20 resize-none font-medium"
                  />
                  <div className="flex justify-end">
                     <button 
                       onClick={() => { onAddNote(noteContent); setNoteContent(''); }}
                       disabled={!noteContent}
                       className="px-10 py-3 bg-white text-black rounded-xl text-[10px] font-black uppercase tracking-widest disabled:opacity-30"
                     >
                       Post Internal Note
                     </button>
                  </div>
               </div>

               <div className="space-y-4">
                  {notes.length === 0 ? (
                    <div className="p-16 text-center bg-white/[0.01] border border-dashed border-white/5 rounded-[40px]">
                       <span className="text-[10px] font-black text-zinc-700 uppercase tracking-widest">Vault is empty of notes</span>
                    </div>
                  ) : (
                    notes.map((n, i) => (
                      <div key={i} className="p-8 bg-white/[0.02] border border-white/5 rounded-[36px] space-y-4 relative overflow-hidden group">
                         <div className="flex items-center gap-4 border-b border-white/5 pb-4">
                            <img src={n.author_avatar || `https://ui-avatars.com/api/?name=${n.author_name}`} className="w-8 h-8 rounded-full border border-white/10" alt="" />
                            <div className="flex-1">
                               <p className="text-[10px] font-black text-white uppercase tracking-widest">{n.author_name}</p>
                               <p className="text-[9px] font-bold text-zinc-600">{new Date(n.createdAt).toLocaleString()}</p>
                            </div>
                         </div>
                         <p className="text-sm text-zinc-300 leading-relaxed font-medium">
                            {n.content}
                         </p>
                      </div>
                    ))
                  )}
               </div>
            </div>
          )}
        </div>

        {/* Status Side Card */}
        <div className="space-y-8">
           <div className="p-8 bg-white/[0.03] border border-white/5 rounded-[36px] space-y-6 text-center shadow-xl backdrop-blur-xl">
             <div className="relative inline-block mx-auto">
               <img 
                 src={user.avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.displayName)}&background=random`} 
                 className="w-32 h-32 rounded-full object-cover border-4 border-white/5 shadow-2lx aspect-square" 
                 alt={user.displayName}
                 referrerPolicy="no-referrer"
               />
               {user.verified && (
                 <div className="absolute -bottom-1 -right-1 p-1.5 bg-indigo-500 rounded-full border-4 border-[#0a0a0a]">
                   <ShieldCheck className="w-4 h-4 text-white" />
                 </div>
               )}
             </div>
             <div className="space-y-1">
               <h4 className="text-xl font-bold text-white">{user.displayName}</h4>
               <div className="flex items-center justify-center gap-2">
                 <span className={`w-2 h-2 rounded-full ${user.onlineStatus === 'online' ? 'bg-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.4)]' : 'bg-zinc-600'}`} />
                 <span className="text-[10px] font-black uppercase tracking-widest text-zinc-600">{user.onlineStatus}</span>
               </div>
             </div>
             
             <div className="pt-4 border-t border-white/5 grid grid-cols-2 gap-4">
                <div className="p-3 bg-white/5 rounded-2xl">
                   <span className="block text-[9px] font-black uppercase tracking-tighter text-zinc-700 mb-1">Status</span>
                   <span className="text-[10px] font-bold text-zinc-400">{user.isBanned ? 'Restricted' : 'Active'}</span>
                </div>
                <div className="p-3 bg-white/5 rounded-2xl">
                   <span className="block text-[9px] font-black uppercase tracking-tighter text-zinc-700 mb-1">Clearance</span>
                   <span className="text-[10px] font-bold text-zinc-400">{user.role || 'User'}</span>
                </div>
             </div>
           </div>

           {/* Current Active Penalties */}
           {(user.isBanned || user.mutedUntil) && (
             <div className="p-6 bg-black/40 border border-white/5 rounded-[36px] space-y-5">
               <h4 className="text-[10px] font-black text-zinc-500 uppercase tracking-widest px-1">Active Penalties</h4>
               
               {user.isBanned && (
                 <div className="p-5 bg-rose-500/10 border border-rose-500/20 rounded-[24px] space-y-3">
                   <div className="flex items-center gap-2 text-rose-400 font-black text-[10px] uppercase tracking-widest">
                     <Ban className="w-3.5 h-3.5" />
                     <span>Banned</span>
                   </div>
                   <p className="text-xs text-zinc-400 leading-relaxed font-medium">
                     Reason: {user.banReason || 'Security Policy Violation'}
                   </p>
                 </div>
               )}

               {user.mutedUntil && new Date(user.mutedUntil) > new Date() && (
                 <div className="p-5 bg-amber-500/10 border border-amber-500/20 rounded-[24px] space-y-3">
                   <div className="flex items-center gap-2 text-amber-500 font-black text-[10px] uppercase tracking-widest">
                     <Clock className="w-3.5 h-3.5" />
                     <span>Muted</span>
                   </div>
                   <p className="text-xs text-zinc-400 leading-relaxed font-medium">
                     Reason: {user.muteReason || 'Behavioral Guidelines'}
                   </p>
                   <div className="pt-2 text-[10px] font-bold text-amber-500/70 border-t border-amber-500/10">
                     Expires {new Date(user.mutedUntil).toLocaleDateString()}
                   </div>
                 </div>
               )}
             </div>
           )}
        </div>
      </div>

      {/* Mute Modal */}
      <AnimatePresence>
        {showMuteDialog && (
          <div className="fixed inset-0 z-[300] flex items-center justify-center p-4">
             <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/90 backdrop-blur-sm" onClick={() => setShowMuteDialog(false)} />
             <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="relative w-full max-w-sm bg-[#1a1a1a] border border-white/5 rounded-[32px] p-8 shadow-2xl space-y-6">
                <div className="space-y-1">
                  <h3 className="text-lg font-black text-white">Mute Restriction</h3>
                  <p className="text-xs text-zinc-500">Select duration and provide an administrative reason.</p>
                </div>
                
                <div className="space-y-3">
                  <label className="text-[10px] font-black uppercase tracking-widest text-zinc-600 px-1">Duration</label>
                  <div className="grid grid-cols-2 gap-2">
                    {DURATION_OPTIONS.map((opt) => (
                      <button 
                         key={opt.value}
                         onClick={() => setMuteDuration(opt.value)}
                         className={`px-3 py-3 rounded-xl text-[10px] font-bold transition-all border ${
                           muteDuration === opt.value ? 'bg-white text-black border-white shadow-xl' : 'bg-white/5 text-zinc-400 border-white/5 hover:border-white/10'
                         }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] font-black uppercase tracking-widest text-zinc-600 px-1">Enforcement Reason</label>
                  <textarea 
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    placeholder="Describe the violation..."
                    className="w-full h-24 bg-black/30 border border-white/10 rounded-2xl p-4 text-xs text-white focus:outline-none focus:border-white/20 resize-none font-medium"
                  />
                </div>

                <div className="flex gap-3 pt-2">
                   <button 
                     onClick={() => {
                       onMute(muteDuration, reason);
                       setShowMuteDialog(false);
                       setReason('');
                     }}
                     disabled={!reason}
                     className="flex-1 py-4 bg-white text-black rounded-2xl text-[10px] font-black uppercase tracking-widest disabled:opacity-30 shadow-xl"
                   >
                     Apply Restriction
                   </button>
                </div>
             </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Warning Modal */}
      <AnimatePresence>
        {showWarningDialog && (
          <div className="fixed inset-0 z-[300] flex items-center justify-center p-4">
             <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/90 backdrop-blur-sm" onClick={() => setShowWarningDialog(false)} />
             <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="relative w-full max-w-sm bg-[#1a1a1a] border border-white/5 rounded-[32px] p-8 shadow-2xl space-y-6">
                <div className="space-y-1">
                  <h3 className="text-lg font-black text-white">Record Warning</h3>
                  <p className="text-xs text-zinc-500">Formally notify the user of an official violation.</p>
                </div>
                
                <div className="space-y-3">
                  <label className="text-[10px] font-black uppercase tracking-widest text-zinc-600 px-1">Case Level</label>
                  <div className="flex gap-2 p-1.5 bg-black/20 rounded-2xl">
                     {[1, 2, 3].map((s) => (
                       <button 
                          key={s}
                          onClick={() => setWarningSeverity(s)}
                          className={`flex-1 py-3 rounded-xl text-[10px] font-black transition-all border ${
                            warningSeverity === s ? 'bg-amber-500 text-white border-amber-500 shadow-xl' : 'bg-white/5 text-zinc-400 border-white/5'
                          }`}
                       >
                         Lvl {s}
                       </button>
                     ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] font-black uppercase tracking-widest text-zinc-600 px-1">Offense Detail</label>
                  <textarea 
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    placeholder="Mention specific rule violated..."
                    className="w-full h-24 bg-black/30 border border-white/10 rounded-2xl p-4 text-xs text-white focus:outline-none focus:border-white/20 resize-none font-medium"
                  />
                </div>

                <div className="flex gap-3 pt-2">
                   <button 
                     onClick={() => {
                       onAddWarning(reason, warningSeverity);
                       setShowWarningDialog(false);
                       setReason('');
                     }}
                     disabled={!reason}
                     className="flex-1 py-4 bg-amber-500 text-black rounded-2xl text-[10px] font-black uppercase tracking-widest disabled:opacity-30 shadow-xl"
                   >
                     Issue Citation
                   </button>
                </div>
             </motion.div>
          </div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {showBanDialog && (
          <div className="fixed inset-0 z-[300] flex items-center justify-center p-4">
             <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/90 backdrop-blur-sm" onClick={() => setShowBanDialog(false)} />
             <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="relative w-full max-w-sm bg-[#1a1a1a] border border-white/5 rounded-[32px] p-8 shadow-2xl space-y-6">
                <div className="flex items-center gap-3 text-rose-500">
                  <ShieldAlert className="w-8 h-8" />
                  <div className="space-y-0.5">
                    <h3 className="text-lg font-black text-rose-400">Account Ban</h3>
                    <p className="text-[10px] font-bold text-rose-500/60 uppercase tracking-widest">Critical Enforcement</p>
                  </div>
                </div>
                
                <p className="text-xs text-zinc-500 leading-relaxed p-4 bg-rose-500/5 border border-rose-500/10 rounded-2xl">
                  Banning this account will terminate all active sessions and permanently revoke access to the platform.
                </p>

                <div className="space-y-3">
                  <label className="text-[10px] font-black uppercase tracking-widest text-zinc-600 px-1">Ban Duration</label>
                  <div className="grid grid-cols-2 gap-2">
                    {DURATION_OPTIONS.map((opt) => (
                      <button 
                         key={opt.value}
                         onClick={() => setBanDuration(opt.value)}
                         className={`py-3 text-xs font-bold rounded-xl transition-all border ${banDuration === opt.value ? 'bg-rose-500 text-white border-rose-500 shadow-lg shadow-rose-500/20' : 'bg-black/20 text-zinc-400 border-white/5 hover:border-white/10 hover:bg-white/5'}`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] font-black uppercase tracking-widest text-zinc-600 px-1">Official Audit Reason</label>
                  <textarea 
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    placeholder="State the specific policy violation..."
                    className="w-full h-24 bg-black/30 border border-rose-500/10 rounded-2xl p-4 text-xs text-white focus:outline-none focus:border-rose-500/30 resize-none font-medium"
                  />
                </div>

                <div className="flex gap-3 pt-2">
                   <button 
                     onClick={() => {
                       onBan(banDuration, reason);
                       setShowBanDialog(false);
                       setReason('');
                     }}
                     disabled={!reason}
                     className="flex-1 py-4 bg-rose-600 hover:bg-rose-500 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest disabled:opacity-30 shadow-xl"
                   >
                     Execute Final Ban
                   </button>
                </div>
             </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function StatBox({ label, value, icon, red }: { label: string; value: any; icon: React.ReactNode; red?: boolean }) {
  return (
    <div className={`p-4 bg-white/[0.01] border border-white/5 rounded-[22px] space-y-3 ${red ? 'hover:bg-rose-500/[0.03] transition-colors' : ''}`}>
      <div className={`flex items-center gap-2 text-[9px] font-black uppercase tracking-widest ${red ? 'text-rose-400' : 'text-zinc-600'}`}>
        {icon}
        {label}
      </div>
      <div className="text-xl font-black text-zinc-100">{value}</div>
    </div>
  );
}

function InfoItem({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-start gap-4">
      <div className="p-3 bg-white/5 rounded-xl text-zinc-600">
        {icon}
      </div>
      <div>
        <div className="text-[9px] font-black uppercase tracking-widest text-zinc-600 mb-1.5">{label}</div>
        <div className="text-xs text-zinc-300 font-bold">{value}</div>
      </div>
    </div>
  );
}

