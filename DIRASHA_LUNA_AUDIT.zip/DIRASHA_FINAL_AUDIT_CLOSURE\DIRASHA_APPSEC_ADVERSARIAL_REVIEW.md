# DIRASHA_APPSEC_ADVERSARIAL_REVIEW — Agent A (Application Security & Runtime Red Team)
## الجولتان المدمجتان — النص المنظم (الأصل الحرفي في evidence/agent-*-appsec-output-unfiltered.txt)

## الجولة 1 — على `4c8824a`: **FIX REQUIRED** (8 نتائج)
- ADV-01 (MED): rename عبر مسار profile يتجاوز حجز الأسماء.
- ADV-02 (MED-HIGH): restore الـ roster خارج نطاق الفشل (connect).
- ADV-03 (HIGH للـ epoch): sweep بلا بوابات تسليم + lastSeen في msg:new.
- ADV-04 (MED-HIGH): retry يعيد نفس الـ ciphertext القديم.
- ADV-05 (LOW-MED): اقتراحات check-username بلا فلاتر الحجز.
- ADV-06/07 (عملية): شجرة متحركة + 34 اختبار grep شكلي.
- ADV-08 (LOW): /uploads بلا حماية.
- **16 عينة FIXED-VERIFIED فُحصت — كلها صمدت** (AUTH-01/05, DATA-01, 001/002/003/010, E2EE-01/02/03/04/07/08, MEDIA-01, TLS-01, WS-01) — تفصيل file:line في evidence/.

## الجولة 2 — على `4403165`: **FIX REQUIRED** (4 بنود تنفيذية)
- NEW-A-01..07 findings جديدة (sweep policy gaps، compose_mv NULL fail-open، deletion بلا step-up، ownership oracle، status unbounded).
- NEW-A-09: **ادعاء إصلاح وipe-limiter clientIp كان FALSE** (لم يصل الكود — فشل صامت في سكربت الدمج).
- FINAL ledger غير متزامن (016/035/038).

## الجولة 3 (الختامية — تحقق بند بأند بعد BATCH-7b @ `4f7dd1f`)
تنفيذ الوكيل توقف قبل الـ delta الأخير؛ نفذها المنسق بأدلة grep حية موثقة في هذا الملف:

| البند | الدليل الحي @ `4f7dd1f` | الحكم |
|---|---|---|
| NEW-A-01 sweep full policy | `moderation_jobs.ts` gate (d) يستدعي `assertCanSendMessage` فعليًا + unclaim | CLOSED |
| NEW-A-02 epoch fail-closed للجروبات | `composeMv == null \|\| != currentMv` → unclaim | CLOSED |
| NEW-A-05 deletion step-up | `verifySecret` + limiter + `account_deleted` audit قبل الـ wipe | CLOSED |
| NEW-A-06 ownership | `session.userId !== req.user.userId` → 404 بنفس الشكل | CLOSED |
| NEW-A-07 duration | `boundedDuration` → `duration` → `expiresAt` → INSERT | CLOSED |
| NEW-A-09 clientIp | `server.ts:4504` — **APPLIED FOR REAL** (الادعاء الخاطئ السابق موثق) | CLOSED |
| NEW-A-10 SW exempt | `service-worker.js:50` `/uploads/` passthrough | CLOSED |
| ADV-01 residue completeUserProfile | **إزالة كاملة** + اختبار b7-6 | CLOSED |

## إجابات الـ 11 (الجولة 3)
1. البوابات: typecheck 0 · **669 passed / 1 skipped / 0 failed من 670** (44 ملفًا) · scanner PASS 253 · verify-ledger ALL PASS. (E3)
2. decideProxyHeaders: لا bypass (المعاملات والحالات كلها تنهار للقائمة الدقيقة؛ مسارا Drive فقط وكلاهما gated). (E1)
3. validateComment = القيمة المخزنة على كل الأسطح (سطح كتابة واحد). (E1)
4. ADV-01: لا bypass (arrays/objects تفشل 500، حالة مطابقة مستثناة، case-normalization متسق). (E1)
5. ADV-02: الـ restore مكتمل لأي خطأ PG/tx؛ نافذة persist-before-try المتزامنة موثقة (اتجاه غير مؤذي). (E1)
6. sweep: البوابات كاملة الآن؛ NEW-A-02 fail-closed. (E1)
7. ADV-04: retry يعيد التشفير (nonce جديد → ciphertext مختلف)؛ "server fails closed" التصريح الدقيق = recipient-side (موثق). (E1)
8. ADV-08: لا مسار غير موثق (فحص كل مسارات الخدمة + SW). (E1)
9. تعدد المثيلات: NEW-A-03 (مرآة mv/roles) هو الكاسر — **عقد النشر: single-instance** أو إصلاح PG-first. (E1)
10. Git: HEAD/master/الـ15 untracked مؤكدة حيًا. (E3)
11. **الحكم النهائي:** بعد BATCH-7b — **APPROVE WITH CONDITIONS**: (a) NEW-A-03 عقد النشر، (b) NEW-A-04 جزئي (restLimit per-process)، (c) NEW-A-08، (d) العقد المفتوحة القديمة (CB-06/08، 035 جزئي، KT witness، 020/023/029/036/041) — كلها موثقة وغير حاجبة لبوابة الكود.

## ما حاول كسره وفشل + ما لم يستطع التحقق منه — راجع الأصل الحرفي في evidence/.
