/**
 * Dirasha E2EE client-library tests (Agent C).
 *
 * Engines (Alice/Bob, possibly several DEVICES per account) talk over a mock
 * fetch that emulates the multi-device server E2EE contract, each with its own
 * MemoryKVStore.
 *
 * Covers: (a) full round-trip with ratchet steps both directions,
 * (b) out-of-order delivery, (c) tamper rejection + state survival,
 * (d) X3DH with and without OPK, (b2) safety-number equality,
 * (e) PeerNotRegisteredError, (f) non-DIR1 passthrough, (g) session
 * persistence across engine reload, (h) deterministic reload + AAD single source.
 * Multi-device: (m1) DIRM1 fan-out decrypt on every peer device, (m2) per-device
 * ratchet independence, (m3) legacy DIR1 wire + plain-key session fallback,
 * (m4) primary-identity safety numbers across devices, (m5) RekeyDetectedError,
 * (m6) broken-device bundle tolerance.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';

import { DirashaE2EE } from '../src/lib/e2ee/engine.ts';
import { MemoryKVStore } from '../src/lib/e2ee/store.ts';
import { TamperedError, DecryptFailedError, PeerNotRegisteredError, RekeyDetectedError, E2eeError } from '../src/lib/e2ee/types.ts';
import type { KVStore } from '../src/lib/e2ee/types.ts';
import {
  aadString,
  AAD_TEMPLATE,
  WIRE_PREFIX,
  aeadSeal,
  aeadOpen,
  b64encode,
  b64decode,
  utf8Encode,
  utf8Decode,
  generateX25519,
  generateEd25519,
  ed25519Sign,
  SPK_SIG_PREFIX,
} from '../src/lib/e2ee/crypto.ts';

/* ── Mock server (emulates the multi-device src/server/routes/e2ee.ts) ────── */

interface ServerOpk { id: number; pub: string; consumed: boolean }
interface ServerDeviceReg {
  deviceId: string;
  identityDhPub: string;
  identitySigPub: string;
  signedPrekeyPub: string;
  prekeySignature: string;
  opks: ServerOpk[];
}

function createMockServer() {
  // userId → (deviceId → device registration); Map preserves insertion order,
  // so the FIRST device is the PRIMARY (oldest) identity.
  const regs = new Map<string, Map<string, ServerDeviceReg>>();
  // Counts POST /api/e2ee/register hits (regression guard: concurrent
  // ensureRegistered() callers must dedupe into ONE registration).
  let registerCalls = 0;
  const userOf = (init?: RequestInit): string => {
    const headers = (init?.headers ?? {}) as Record<string, string>;
    return String(headers.Authorization ?? '').replace(/^Bearer\s+/, '');
  };
  const respond = (status: number, data: unknown) =>
    new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json' } });

  const fetch = async (url: any, init?: RequestInit): Promise<Response> => {
    const path = String(url).split('?')[0];
    const method = (init?.method ?? 'GET').toUpperCase();
    const body = init?.body ? JSON.parse(String(init.body)) : {};
    const user = userOf(init);

    if (path === '/api/e2ee/register' && method === 'POST') {
      registerCalls++;
      const deviceId = typeof body.deviceId === 'string' && body.deviceId ? body.deviceId : 'default';
      let devices = regs.get(user);
      if (!devices) {
        devices = new Map<string, ServerDeviceReg>();
        regs.set(user, devices);
      }
      // Same deviceId → replaces that device's row only; otherwise a new device row.
      devices.set(deviceId, {
        deviceId,
        identityDhPub: body.identityDhPub,
        identitySigPub: body.identitySigPub,
        signedPrekeyPub: body.signedPrekeyPub,
        prekeySignature: body.prekeySignature,
        opks: (body.oneTimePrekeys ?? []).map((o: any) => ({ id: o.id, pub: o.pub, consumed: false })),
      });
      return respond(200, { ok: true });
    }
    if (path.startsWith('/api/e2ee/bundle/') && method === 'GET') {
      const devices = regs.get(path.split('/').pop()!);
      if (!devices || devices.size === 0) return respond(404, { registered: false });
      return respond(200, {
        registered: true,
        devices: [...devices.values()].map((d) => {
          const opk = d.opks.find((o) => !o.consumed) ?? null;
          if (opk) opk.consumed = true;
          return {
            deviceId: d.deviceId,
            identityDhPub: d.identityDhPub,
            identitySigPub: d.identitySigPub,
            signedPrekeyPub: d.signedPrekeyPub,
            prekeySignature: d.prekeySignature,
            opk: opk ? { id: opk.id, pub: opk.pub } : null,
          };
        }),
      });
    }
    if (path === '/api/e2ee/prekeys' && method === 'POST') {
      const devices = regs.get(user);
      if (!devices || devices.size === 0) return respond(404, { ok: false });
      // Device-scoped in production; the mock appends to the primary device.
      const primary = [...devices.values()][0];
      for (const o of body.oneTimePrekeys ?? []) primary.opks.push({ id: o.id, pub: o.pub, consumed: false });
      const remaining = [...devices.values()].reduce((a, d) => a + d.opks.filter((o) => !o.consumed).length, 0);
      return respond(200, { ok: true, opkRemaining: remaining });
    }
    if (path === '/api/e2ee/status' && method === 'GET') {
      const devices = regs.get(user);
      const remaining = devices
        ? [...devices.values()].reduce((a, d) => a + d.opks.filter((o) => !o.consumed).length, 0)
        : 0;
      return respond(200, { registered: !!devices && devices.size > 0, opkRemaining: remaining });
    }
    if (path.startsWith('/api/e2ee/identity/') && method === 'GET') {
      const devices = regs.get(path.split('/').pop()!);
      if (!devices || devices.size === 0) return respond(404, { registered: false });
      const primary = [...devices.values()][0];
      return respond(200, {
        registered: true,
        identityDhPub: primary.identityDhPub,
        identitySigPub: primary.identitySigPub,
        deviceCount: devices.size,
      });
    }
    return respond(404, { error: 'not found' });
  };

  return { fetch, regs, getRegisterCalls: () => registerCalls };
}

/* ── Harness ──────────────────────────────────────────────────────────────── */

let server: ReturnType<typeof createMockServer>;

function makeEngine(user: string, store?: KVStore): DirashaE2EE {
  return new DirashaE2EE({
    authHeaders: () => ({ Authorization: `Bearer ${user}` }),
    store: store ?? new MemoryKVStore(),
    selfId: user, // enables PRIMARY-identity (device-stable) safety numbers
  });
}

/** Sender encrypts for peer; peer decrypts; returns the decrypt result. */
async function sendAndDecrypt(from: DirashaE2EE, fromId: string, to: DirashaE2EE, toId: string, text: string) {
  const { content } = await from.encryptMessage(toId, text);
  return to.decryptMessage(fromId, content);
}

/** Alice sends `text` to Bob; Bob decrypts and returns the decrypt result. */
async function sendToBob(alice: DirashaE2EE, bob: DirashaE2EE, text: string) {
  return sendAndDecrypt(alice, 'alice', bob, 'bob', text);
}

/** Flip one base64 char inside the ciphertext field to break AEAD, keeping the envelope valid. */
function tamperCt(content: string): string {
  const raw = content.slice(WIRE_PREFIX.length);
  const json = JSON.parse(new TextDecoder().decode(
    Uint8Array.from(atob(raw), (c) => c.charCodeAt(0)),
  ));
  const flip = (ch: string) => (ch === 'A' ? 'B' : 'A');
  json.ct = flip(json.ct[0]) + json.ct.slice(1);
  const bytes = new TextEncoder().encode(JSON.stringify(json));
  let bin = '';
  for (const b of bytes) bin += String.fromCharCode(b);
  return content.slice(0, WIRE_PREFIX.length) + btoa(bin);
}

/** Parse a DIR1 wire string into its envelope object. */
function parseWire(content: string): any {
  return JSON.parse(utf8Decode(b64decode(content.slice(WIRE_PREFIX.length))));
}

/** Re-serialize an envelope object into a DIR1 wire string. */
function toWire(env: any): string {
  return WIRE_PREFIX + b64encode(utf8Encode(JSON.stringify(env)));
}

/** Simulate a LEGACY sender: strip the multi-device `sd` field from a DIR1 envelope. */
function stripSd(content: string): string {
  const env = parseWire(content);
  delete env.sd;
  return toWire(env);
}

/** Downgrade a store to OLD-version session layout: sessions live at plain 'session:<peerId>' keys. */
async function migrateSessionsToLegacyKeys(store: KVStore, peerId: string): Promise<void> {
  const prefix = `session:${peerId}:`;
  for (const k of await store.keys()) {
    if (k.startsWith(prefix)) {
      const v = await store.get(k);
      if (v !== null) await store.set(`session:${peerId}`, v);
      await store.del(k);
    }
  }
}

/** The server's registered deviceId list for a user (insertion-ordered; first = primary). */
function deviceIdsOf(user: string): string[] {
  return [...server.regs.get(user)!.keys()];
}

beforeEach(() => {
  server = createMockServer();
  vi.stubGlobal('fetch', server.fetch as unknown as typeof fetch);
});

afterEach(() => {
  vi.unstubAllGlobals();
});

/* ── Tests ────────────────────────────────────────────────────────────────── */

describe('DirashaE2EE engine (X3DH + Double Ratchet)', () => {
  it('(a) Alice↔Bob full conversation round-trip over multiple messages with ratchet steps both directions', async () => {
    const alice = makeEngine('alice');
    const bob = makeEngine('bob');
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    const status = await alice.getStatus();
    expect(status).toEqual({ registered: true, opkRemaining: 100 });

    // Alternating directions → every message forces a DH ratchet step on the receiver.
    const script: Array<[DirashaE2EE, DirashaE2EE, string]> = [
      [alice, bob, 'مرحبا بوب 👋'],
      [bob, alice, 'أهلاً أليس'],
      [alice, bob, 'third message'],
      [bob, alice, 'fourth message'],
      [alice, bob, 'fifth 💬 message'],
      [bob, alice, 'sixth message'],
    ];
    for (const [from, to, text] of script) {
      const { content } = await from.encryptMessage(to === bob ? 'bob' : 'alice', text);
      expect(content.startsWith('DIR1:')).toBe(true);
      const res = await to.decryptMessage(from === alice ? 'alice' : 'bob', content);
      expect(res).toEqual({ plaintext: text });
    }
    expect(await alice.hasSession('bob')).toBe(true);
    expect(await bob.hasSession('alice')).toBe(true);
  });

  it('(b) out-of-order delivery: send 5, deliver 3,2,1,5,4 — all decrypt correctly', async () => {
    const alice = makeEngine('alice');
    const bob = makeEngine('bob');
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    const contents: string[] = [];
    for (let i = 1; i <= 5; i++) {
      contents.push((await alice.encryptMessage('bob', `msg${i}`)).content);
    }
    // Literal delivery order from the task (3,2,1,5) + the missing #4 last.
    for (const idx of [2, 1, 0, 4, 3]) {
      const res = await bob.decryptMessage('alice', contents[idx]);
      expect(res).toEqual({ plaintext: `msg${idx + 1}` });
    }
  });

  it('(c) tampered ciphertext → TamperedError and session state survives for the next message', async () => {
    const alice = makeEngine('alice');
    const bob = makeEngine('bob');
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    expect(new TamperedError()).toBeInstanceOf(DecryptFailedError);

    // Tamper the very FIRST (X3DH) message before the session is even established.
    const first = (await alice.encryptMessage('bob', 'secret 1')).content;
    const r1 = await bob.decryptMessage('alice', tamperCt(first));
    expect(r1).toEqual({ error: 'TamperedError' });
    // State survived: the ORIGINAL message still decrypts.
    expect(await bob.decryptMessage('alice', first)).toEqual({ plaintext: 'secret 1' });

    // Tamper mid-session (established ratchet chains).
    expect(await sendToBob(alice, bob, 'secret 2')).toEqual({ plaintext: 'secret 2' });
    const msg3 = (await alice.encryptMessage('bob', 'secret 3')).content;
    expect(await bob.decryptMessage('alice', tamperCt(msg3))).toEqual({ error: 'TamperedError' });
    // Original mid-session message still decrypts and the NEXT message flows too.
    expect(await bob.decryptMessage('alice', msg3)).toEqual({ plaintext: 'secret 3' });
    expect(await sendToBob(alice, bob, 'after tamper')).toEqual({ plaintext: 'after tamper' });

    // AAD tamper (hdr.n) is equally rejected.
    const msg5 = (await alice.encryptMessage('bob', 'secret 5')).content;
    const raw = JSON.parse(new TextDecoder().decode(
      Uint8Array.from(atob(msg5.slice(WIRE_PREFIX.length)), (c) => c.charCodeAt(0)),
    ));
    raw.hdr.n = raw.hdr.n + 1000;
    const bytes = new TextEncoder().encode(JSON.stringify(raw));
    let bin = '';
    for (const b of bytes) bin += String.fromCharCode(b);
    expect(await bob.decryptMessage('alice', WIRE_PREFIX + btoa(bin))).toEqual({ error: 'TamperedError' });
    expect(await sendToBob(alice, bob, 'still alive')).toEqual({ plaintext: 'still alive' });
  });

  it('(d) X3DH works both WITH and WITHOUT a one-time prekey', async () => {
    const alice = makeEngine('alice');
    const dave = makeEngine('dave');
    const eve = makeEngine('eve');
    await alice.ensureRegistered();
    await dave.ensureRegistered();
    await eve.ensureRegistered();

    // WITH OPK (bundle still has one-time prekeys).
    expect(await sendAndDecrypt(alice, 'alice', eve, 'eve', 'with opk')).toEqual({ plaintext: 'with opk' });
    expect(await eve.decryptMessage('alice', (await alice.encryptMessage('eve', 'with opk 2')).content)).toEqual({ plaintext: 'with opk 2' });

    // WITHOUT OPK: drain dave's pool server-side → bundle returns opk:null.
    for (const dev of server.regs.get('dave')!.values()) dev.opks.forEach((o) => (o.consumed = true));
    const r = await sendAndDecrypt(alice, 'alice', dave, 'dave', 'no opk');
    expect(r).toEqual({ plaintext: 'no opk' });
    // Reply in the no-OPK session too (full ratchet round trip).
    const reply = await dave.encryptMessage('alice', 'no opk reply');
    expect(await alice.decryptMessage('dave', reply.content)).toEqual({ plaintext: 'no opk reply' });
  });

  it('(b2) safety number is identical on both sides (60 digits)', async () => {
    const alice = makeEngine('alice');
    const bob = makeEngine('bob');
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    const a = await alice.getSafetyNumber('bob');
    const b = await bob.getSafetyNumber('alice');
    expect(a).toMatch(/^\d{60}$/);
    expect(a).toBe(b);
  });

  it('(e) encrypt to unregistered peer → PeerNotRegisteredError', async () => {
    const alice = makeEngine('alice');
    await alice.ensureRegistered();

    await expect(alice.encryptMessage('carol', 'hi')).rejects.toBeInstanceOf(PeerNotRegisteredError);
    await expect(alice.getSafetyNumber('carol')).rejects.toBeInstanceOf(PeerNotRegisteredError);
    await expect(alice.hasSession('carol')).resolves.toBe(false);
  });

  it('(f) decryptMessage passes non-DIR1 content through untouched', async () => {
    const bob = makeEngine('bob');
    await bob.ensureRegistered();
    expect(await bob.decryptMessage('alice', 'just plain text')).toEqual({ plaintext: 'just plain text' });
    expect(await bob.decryptMessage('alice', '')).toEqual({ plaintext: '' });
  });

  it('(g) session persists: a NEW engine instance on the same KV store decrypts after reload', async () => {
    const bobStore = new MemoryKVStore();
    const alice = makeEngine('alice');
    const bob1 = makeEngine('bob', bobStore);
    await alice.ensureRegistered();
    await bob1.ensureRegistered();

    const msg1 = (await alice.encryptMessage('bob', 'before reload')).content;
    expect(await bob1.decryptMessage('alice', msg1)).toEqual({ plaintext: 'before reload' });

    // "Reload": brand-new engine instance, same persisted store, no in-memory state.
    const bob2 = makeEngine('bob', bobStore);
    expect(await bob2.hasSession('alice')).toBe(true);
    const msg2 = (await alice.encryptMessage('bob', 'after reload')).content;
    expect(await bob2.decryptMessage('alice', msg2)).toEqual({ plaintext: 'after reload' });

    // The reloaded engine can also SEND on the persisted session.
    const msg3 = await bob2.encryptMessage('alice', 'sent after reload');
    expect(await alice.decryptMessage('bob', msg3.content)).toEqual({ plaintext: 'sent after reload' });

    // deleteSession clears it (rekey hint path).
    await bob2.deleteSession('alice');
    expect(await bob2.hasSession('alice')).toBe(false);
    const msg4 = (await alice.encryptMessage('bob', 'orphan chain')).content;
    // msg4 carries no X3DH bootstrap (alice already got a reply) → SessionMissingError.
    expect(await bob2.decryptMessage('alice', msg4)).toEqual({ error: 'SessionMissingError' });
    // Recovery: bob bootstraps a FRESH session by sending; alice re-inits from his x3dh.
    const recovery = (await bob2.encryptMessage('alice', 'fresh bootstrap from bob')).content;
    expect(await alice.decryptMessage('bob', recovery)).toEqual({ plaintext: 'fresh bootstrap from bob' });
    const msg5 = (await alice.encryptMessage('bob', 'rekey flow ok')).content;
    expect(await bob2.decryptMessage('alice', msg5)).toEqual({ plaintext: 'rekey flow ok' });
  });

  it('(h) deterministic cross-check: encrypt, decrypt with a fresh engine + same store; AAD has a single grep-able source', async () => {
    // AAD construction: one template constant + one builder used by encrypt & decrypt.
    expect(AAD_TEMPLATE).toBe('${v}|${ik}|${dh}|${pn}|${n}');
    expect(aadString(1, 'IK_A', 'DH_B', 3, 7)).toBe('1|IK_A|DH_B|3|7');

    // Primitive-level round trip through the exact AAD the wire format uses.
    const key = new Uint8Array(32).fill(9);
    const nonce = new Uint8Array(12).fill(7);
    const aad = new TextEncoder().encode(aadString(1, 'ik', 'dh', 0, 0));
    const ct = aeadSeal(key, nonce, new TextEncoder().encode('aad roundtrip'), aad);
    expect(new TextDecoder().decode(aeadOpen(key, nonce, ct, aad))).toBe('aad roundtrip');

    // Engine-level deterministic reload in Node: encrypt → fresh engine + same store decrypts.
    const bobStore = new MemoryKVStore();
    const alice = makeEngine('alice');
    const bobLoader = makeEngine('bob', bobStore);
    await alice.ensureRegistered();
    await bobLoader.ensureRegistered();

    const msg = (await alice.encryptMessage('bob', 'deterministic ✅')).content;
    const freshBob = makeEngine('bob', bobStore); // never used before this decrypt
    expect(await freshBob.decryptMessage('alice', msg)).toEqual({ plaintext: 'deterministic ✅' });
    // And immediately continues the ratchet from the persisted state.
    const followUp = (await alice.encryptMessage('bob', 'follow up')).content;
    expect(await freshBob.decryptMessage('alice', followUp)).toEqual({ plaintext: 'follow up' });
  });

  /* ── Multi-device (Signal-style) ─────────────────────────────────────────── */

  it('(m1) Alice → Bob-with-2-devices: DIRM1 fan-out, BOTH Bob devices decrypt', async () => {
    const alice = makeEngine('alice');
    const bobStore1 = new MemoryKVStore();
    const bobStore2 = new MemoryKVStore();
    const bob1 = makeEngine('bob', bobStore1);
    const bob2 = makeEngine('bob', bobStore2);
    await alice.ensureRegistered();
    await bob1.ensureRegistered();
    await bob2.ensureRegistered();

    const { content } = await alice.encryptMessage('bob', 'hello both devices 💬');
    // 2 peer devices → multi-device container.
    expect(content.startsWith('DIRM1:')).toBe(true);
    const multi = JSON.parse(utf8Decode(b64decode(content.slice('DIRM1:'.length))));
    expect(multi.v).toBe(1);
    expect(multi.devices.map((e: any) => e.d).sort()).toEqual(deviceIdsOf('bob').sort());
    // Each envelope carries the sender's deviceId.
    for (const entry of multi.devices) {
      expect(entry.env.sd).toBe(deviceIdsOf('alice')[0]);
      expect(entry.env.ik).toBeTruthy();
    }

    // Both of Bob's devices decrypt the SAME container, each on its own session.
    expect(await bob1.decryptMessage('alice', content)).toEqual({ plaintext: 'hello both devices 💬' });
    expect(await bob2.decryptMessage('alice', content)).toEqual({ plaintext: 'hello both devices 💬' });

    // Per peer-device session keys (suffixed), keyed by ALICE's deviceId.
    const aliceDev = deviceIdsOf('alice')[0];
    expect((await bobStore1.keys()).includes(`session:alice:${aliceDev}`)).toBe(true);
    expect((await bobStore2.keys()).includes(`session:alice:${aliceDev}`)).toBe(true);
    expect(await bob1.hasSession('alice')).toBe(true);
    expect(await bob2.hasSession('alice')).toBe(true);

    // Both devices keep receiving her subsequent fan-outs on independent chains.
    expect(await bob1.decryptMessage('alice', (await alice.encryptMessage('bob', 'second dirm1')).content))
      .toEqual({ plaintext: 'second dirm1' });
    expect(await bob2.decryptMessage('alice', (await alice.encryptMessage('bob', 'second dirm1 v2')).content))
      .toEqual({ plaintext: 'second dirm1 v2' });
  });

  it('(m2) Bob replies from device-2 → Alice decrypts (per-device ratchet independence)', async () => {
    const alice = makeEngine('alice');
    const bob1 = makeEngine('bob', new MemoryKVStore());
    const bob2 = makeEngine('bob', new MemoryKVStore());
    await alice.ensureRegistered();
    await bob1.ensureRegistered();
    await bob2.ensureRegistered();

    const first = (await alice.encryptMessage('bob', 'fan-out')).content;
    expect(await bob1.decryptMessage('alice', first)).toEqual({ plaintext: 'fan-out' });
    expect(await bob2.decryptMessage('alice', first)).toEqual({ plaintext: 'fan-out' });

    // Device-2 answers on ITS OWN responder session (ratcheted independently).
    const reply = await bob2.encryptMessage('alice', 'reply from device 2');
    expect(reply.content.startsWith('DIR1:')).toBe(true); // alice has ONE device
    const replyEnv = parseWire(reply.content);
    expect(replyEnv.sd).toBe(deviceIdsOf('bob')[1]); // sent by bob's second device
    expect(await alice.decryptMessage('bob', reply.content)).toEqual({ plaintext: 'reply from device 2' });

    // Alice's session for device-2 advanced; device-1's session is untouched and
    // both still receive her next fan-out (independent chains per device).
    const next = (await alice.encryptMessage('bob', 'after device-2 reply')).content;
    expect(next.startsWith('DIRM1:')).toBe(true);
    expect(await bob1.decryptMessage('alice', next)).toEqual({ plaintext: 'after device-2 reply' });
    expect(await bob2.decryptMessage('alice', next)).toEqual({ plaintext: 'after device-2 reply' });
  });

  it('(m3) Bob-with-1-device: wire stays legacy DIR1 and plain-key (old-version) sessions still decrypt via the default fallback', async () => {
    const aliceStore = new MemoryKVStore();
    const bobStore = new MemoryKVStore();
    const alice = makeEngine('alice', aliceStore);
    const bob = makeEngine('bob', bobStore);
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    // Single peer device → EXACT legacy wire.
    const m1 = (await alice.encryptMessage('bob', 'legacy wire')).content;
    expect(m1.startsWith('DIR1:')).toBe(true);
    expect(await bob.decryptMessage('alice', m1)).toEqual({ plaintext: 'legacy wire' });
    // Confirm both sessions (pendingX3dh cleared, established chains).
    const r1 = await bob.encryptMessage('alice', 'bob reply');
    expect(await alice.decryptMessage('bob', r1.content)).toEqual({ plaintext: 'bob reply' });

    // Simulate OLD-version stores: sessions persisted at plain 'session:<peerId>' keys.
    await migrateSessionsToLegacyKeys(bobStore, 'alice');
    await migrateSessionsToLegacyKeys(aliceStore, 'bob');

    // Legacy peer (old engine, no sd on the wire) sends to the upgraded bob:
    // sd absent → sd='default' → suffixed miss → falls back to the plain key.
    const legacyIn = stripSd((await alice.encryptMessage('bob', 'old sender, no sd')).content);
    expect(await bob.decryptMessage('alice', legacyIn)).toEqual({ plaintext: 'old sender, no sd' });
    // Lazy migration: the session was written back under the NEW suffixed key.
    expect((await bobStore.keys()).includes('session:alice:default')).toBe(true);

    // And the reverse direction: upgraded bob (sd stripped to simulate legacy)
    // replies; upgraded alice decrypts through her own plain-key fallback.
    const legacyReply = stripSd((await bob.encryptMessage('alice', 'bob legacy reply')).content);
    expect(await alice.decryptMessage('bob', legacyReply)).toEqual({ plaintext: 'bob legacy reply' });
    expect((await aliceStore.keys()).includes('session:bob:default')).toBe(true);

    // The migrated sessions keep working (now found under the suffixed keys).
    // NOTE: this leg KEEPS the legacy simulation (sd stripped). An sd-bearing
    // envelope here would route to the OTHER side's UN-CONFIRMED initiator
    // session while carrying the first bootstrap — exactly the mutual X3DH
    // tie-break shape, whose KEEPER/ADOPTER outcome depends on the random
    // identity keys (a per-run coin flip → intermittent DecryptFailedError).
    // Stripped, it deterministically lands on the rebuilt responder session.
    const followUp = stripSd((await alice.encryptMessage('bob', 'migrated session alive')).content);
    expect(await bob.decryptMessage('alice', followUp)).toEqual({ plaintext: 'migrated session alive' });
  });

  it('(m4) safety number is identical across peer devices (primary-identity based)', async () => {
    const alice = makeEngine('alice');
    const bob1 = makeEngine('bob', new MemoryKVStore());
    const bob2 = makeEngine('bob', new MemoryKVStore());
    await alice.ensureRegistered();
    await bob1.ensureRegistered();
    await bob2.ensureRegistered();

    const fromAlice = await alice.getSafetyNumber('bob');
    const fromBobDev1 = await bob1.getSafetyNumber('alice');
    const fromBobDev2 = await bob2.getSafetyNumber('alice');
    expect(fromAlice).toMatch(/^\d{60}$/);
    expect(fromAlice).toBe(fromBobDev1);
    expect(fromAlice).toBe(fromBobDev2);

    // Registering a THIRD bob device must not move the primary identity.
    const bob3 = makeEngine('bob', new MemoryKVStore());
    await bob3.ensureRegistered();
    expect(await bob3.getSafetyNumber('alice')).toBe(fromAlice);
    expect(await alice.getSafetyNumber('bob')).toBe(fromAlice);
  });

  it('(m5) peer re-registration with a new identity + stale local session → RekeyDetectedError', async () => {
    expect(new RekeyDetectedError()).toBeInstanceOf(E2eeError);

    const aliceStore = new MemoryKVStore();
    const bobStore = new MemoryKVStore();
    const alice = makeEngine('alice', aliceStore);
    const bob = makeEngine('bob', bobStore);
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    // Establish and CONFIRM sessions both ways (pendingX3dh cleared).
    expect(await bob.decryptMessage('alice', (await alice.encryptMessage('bob', 'v1')).content))
      .toEqual({ plaintext: 'v1' });
    expect(await alice.decryptMessage('bob', (await bob.encryptMessage('alice', 'v1 reply')).content))
      .toEqual({ plaintext: 'v1 reply' });

    // Snapshot bob's PRE-rekey session (a "backup" he will restore later).
    const aliceDev = deviceIdsOf('alice')[0];
    const sessKey = `session:alice:${aliceDev}`;
    const preRekeySession = await bobStore.get(sessKey);
    expect(preRekeySession).not.toBeNull();

    // ── Alice re-registers with a NEW identity, REUSING her deviceId (same
    //    store → server replaces that device's row only). ──
    const identity = JSON.parse((await aliceStore.get('identity'))!);
    const dh = generateX25519();
    const sig = generateEd25519();
    identity.dh = { priv: b64encode(dh.priv), pub: b64encode(dh.pub) };
    identity.sig = { priv: b64encode(sig.priv), pub: b64encode(sig.pub) };
    identity.registered = false;
    const sameDeviceId = identity.deviceId;
    await aliceStore.set('identity', JSON.stringify(identity));
    const spk = generateX25519();
    const spkSig = ed25519Sign(utf8Encode(SPK_SIG_PREFIX + b64encode(spk.pub)), sig.priv);
    await aliceStore.set('spkPriv', JSON.stringify({ priv: b64encode(spk.priv), pub: b64encode(spk.pub), sig: b64encode(spkSig) }));
    await alice.deleteSession('bob'); // the app's 'e2ee:rekey' handler does this
    await alice.ensureRegistered();
    expect(deviceIdsOf('alice')).toEqual([sameDeviceId]); // deviceId reused, row replaced
    expect(deviceIdsOf('alice').length).toBe(1);

    // Post-rekey traffic bootstraps seamlessly (fresh X3DH on every envelope).
    const m1 = (await alice.encryptMessage('bob', 'post rekey 1')).content;
    expect(await bob.decryptMessage('alice', m1)).toEqual({ plaintext: 'post rekey 1' });
    expect(await alice.decryptMessage('bob', (await bob.encryptMessage('alice', 'bob post-rekey reply')).content))
      .toEqual({ plaintext: 'bob post-rekey reply' });
    // An ESTABLISHED (no-x3dh) message from the new identity decrypts fine.
    const m2 = (await alice.encryptMessage('bob', 'post rekey 2, no bootstrap')).content;
    expect(await bob.decryptMessage('alice', m2)).toEqual({ plaintext: 'post rekey 2, no bootstrap' });

    // Bob restores his PRE-rekey backup → session predates the canonical
    // identity change; the no-bootstrap message can never match it.
    await bobStore.set(sessKey, preRekeySession!);
    const res = await bob.decryptMessage('alice', m2);
    expect(res).toEqual({ error: 'RekeyDetectedError' });
    // …and the restored state is not destroyed by the failed decrypt (idempotent).
    expect(await bobStore.get(sessKey)).toBe(preRekeySession);
  });

  it('(m6) one peer device has a broken bundle → encryption still succeeds with the remaining device', async () => {
    const alice = makeEngine('alice');
    const bob1 = makeEngine('bob', new MemoryKVStore());
    const bob2 = makeEngine('bob', new MemoryKVStore());
    await alice.ensureRegistered();
    await bob1.ensureRegistered();
    await bob2.ensureRegistered();

    // Corrupt device-2's SPK signature in the mock server.
    const devices = server.regs.get('bob')!;
    const broken = [...devices.keys()][1];
    const badSig = devices.get(broken)!.prekeySignature;
    devices.get(broken)!.prekeySignature = (badSig[0] === 'A' ? 'B' : 'A') + badSig.slice(1);

    // Only the healthy device yields an envelope → legacy single wire.
    const { content } = await alice.encryptMessage('bob', 'survives broken device');
    expect(content.startsWith('DIR1:')).toBe(true);
    expect(await bob1.decryptMessage('alice', content)).toEqual({ plaintext: 'survives broken device' });

    // Restore the signature → both devices valid again → DIRM1 fan-out returns.
    devices.get(broken)!.prekeySignature = badSig;
    alice.clearDeviceCache();
    const { content: content2 } = await alice.encryptMessage('bob', 'all devices healthy');
    expect(content2.startsWith('DIRM1:')).toBe(true);
    expect(await bob1.decryptMessage('alice', content2)).toEqual({ plaintext: 'all devices healthy' });
    expect(await bob2.decryptMessage('alice', content2)).toEqual({ plaintext: 'all devices healthy' });
  });

  it('(m7) concurrent ensureRegistered() calls dedupe into ONE registration (in-flight singleton)', async () => {
    // Regression: the login path, auth:ready and token-refresh paths all fire
    // ensureRegistered() — previously each concurrent call re-registered and
    // re-posted its own OPK pool, so an in-flight peer bundle fetch could
    // consume an OPK whose private key a later call wiped (→ undecryptable
    // peer envelopes → placeholders). Now all callers share ONE in-flight
    // promise and the register endpoint is hit exactly once.
    const engine = makeEngine('zara');
    const [r1, r2, r3] = await Promise.all([
      engine.ensureRegistered(),
      engine.ensureRegistered(),
      engine.ensureRegistered(),
    ]);
    expect(r1).toEqual({ registered: true });
    expect(r2).toEqual({ registered: true });
    expect(r3).toEqual({ registered: true });
    expect(server.getRegisterCalls()).toBe(1);

    // Exactly one device row with the full OPK pool (a second registration
    // would have replaced the row and re-inserted 100 more OPKs).
    expect(deviceIdsOf('zara')).toHaveLength(1);
    const dev = server.regs.get('zara')!.get(deviceIdsOf('zara')[0])!;
    expect(dev.opks).toHaveLength(100);

    // Already-registered short-circuit still bypasses the server entirely.
    expect(await engine.ensureRegistered()).toEqual({ registered: true });
    expect(server.getRegisterCalls()).toBe(1);
  });

  /* ── One-time prekey priv cleanup (P4) ───────────────────────────────────── */

  /** Local 'opk:<id>' priv keys currently held by a store. */
  async function opkPrivKeysOf(store: KVStore): Promise<string[]> {
    return (await store.keys()).filter((k) => k.startsWith('opk:'));
  }

  describe('one-time prekey priv cleanup (P4)', () => {
    it('(o1) after the bootstrap message decrypts, the consumed OPK priv kv entry is DELETED', async () => {
      const bobStore = new MemoryKVStore();
      const alice = makeEngine('alice');
      const bob = makeEngine('bob', bobStore);
      await alice.ensureRegistered();
      await bob.ensureRegistered();
      expect(await opkPrivKeysOf(bobStore)).toHaveLength(100);

      const first = (await alice.encryptMessage('bob', 'bootstrap hello')).content;
      const env = parseWire(first);
      expect(env.x3dh).toBeTruthy();
      expect(typeof env.x3dh.opkId).toBe('number');
      const opkId = env.x3dh.opkId as number;

      expect(await bob.decryptMessage('alice', first)).toEqual({ plaintext: 'bootstrap hello' });

      // The consumed priv is gone…
      expect(await bobStore.get(`opk:${opkId}`)).toBeNull();
      // …exactly one priv was removed, and it is the consumed one.
      const remaining = await opkPrivKeysOf(bobStore);
      expect(remaining).toHaveLength(99);
      expect(remaining).not.toContain(`opk:${opkId}`);

      // Follow-up traffic (still carrying the same bootstrap — pendingX3dh is
      // attached until the first inbound reply) decrypts WITHOUT the deleted
      // priv, on the persisted session.
      const second = (await alice.encryptMessage('bob', 'follow up, same bootstrap')).content;
      expect(parseWire(second).x3dh?.opkId).toBe(opkId);
      expect(await bob.decryptMessage('alice', second)).toEqual({ plaintext: 'follow up, same bootstrap' });
    });

    it('(o2) replaying the bootstrap afterwards fails closed (replay guard) and does NOT resurrect the deleted key', async () => {
      const bobStore = new MemoryKVStore();
      const alice = makeEngine('alice');
      const bob = makeEngine('bob', bobStore);
      await alice.ensureRegistered();
      await bob.ensureRegistered();

      const first = (await alice.encryptMessage('bob', 'first')).content;
      const opkId = parseWire(first).x3dh.opkId as number;
      expect(await bob.decryptMessage('alice', first)).toEqual({ plaintext: 'first' });
      expect(await bobStore.get(`opk:${opkId}`)).toBeNull();

      // Replay of the SAME bootstrap message: the existing session cannot
      // decrypt it again (chain already advanced), the bootstrappedEk replay
      // guard rejects the rebuild — fail closed, no priv needed, no
      // resurrection, no rollback.
      expect(await bob.decryptMessage('alice', first)).toEqual({ error: 'TamperedError' });
      expect(await bobStore.get(`opk:${opkId}`)).toBeNull();

      // The session survived the failed replay: normal traffic still flows.
      expect(await sendToBob(alice, bob, 'session intact after replay')).toEqual({
        plaintext: 'session intact after replay',
      });
    });

    it('(o3) a second NEW session bootstrap (fresh EK, different OPK) still works after cleanup', async () => {
      const bobStore = new MemoryKVStore();
      const alice = makeEngine('alice');
      const bob = makeEngine('bob', bobStore);
      await alice.ensureRegistered();
      await bob.ensureRegistered();

      // Round 1: bootstrap with OPK #1 → priv deleted.
      const first = (await alice.encryptMessage('bob', 'round one')).content;
      const env1 = parseWire(first);
      const opkId1 = env1.x3dh.opkId as number;
      expect(await bob.decryptMessage('alice', first)).toEqual({ plaintext: 'round one' });
      expect(await bobStore.get(`opk:${opkId1}`)).toBeNull();

      // Alice re-inits (the app's rekey path): fresh EK, fresh bundle → a
      // DIFFERENT unconsumed OPK. Bob's pool must not be corrupted by the
      // round-1 cleanup.
      await alice.deleteSession('bob');
      const second = (await alice.encryptMessage('bob', 'round two, fresh bootstrap')).content;
      const env2 = parseWire(second);
      expect(env2.x3dh.ek).not.toBe(env1.x3dh.ek);
      const opkId2 = env2.x3dh.opkId as number;
      expect(opkId2).not.toBe(opkId1);
      expect(await bobStore.get(`opk:${opkId2}`)).not.toBeNull(); // unconsumed priv still held

      expect(await bob.decryptMessage('alice', second)).toEqual({ plaintext: 'round two, fresh bootstrap' });
      // The second bootstrap's priv is now consumed and cleaned up too.
      expect(await bobStore.get(`opk:${opkId2}`)).toBeNull();
      const remaining = await opkPrivKeysOf(bobStore);
      expect(remaining).toHaveLength(98);
      expect(remaining).not.toContain(`opk:${opkId1}`);
      expect(remaining).not.toContain(`opk:${opkId2}`);

      // Full round trip on the NEW session.
      const reply = await bob.encryptMessage('alice', 'bob on the new session');
      expect(await alice.decryptMessage('bob', reply.content)).toEqual({ plaintext: 'bob on the new session' });
      expect(await bob.decryptMessage('alice', (await alice.encryptMessage('bob', 'and round trip')).content))
        .toEqual({ plaintext: 'and round trip' });
    });

    it('(o4) the SPK priv and identity privs remain present and unchanged after cleanup', async () => {
      const bobStore = new MemoryKVStore();
      const alice = makeEngine('alice');
      const bob = makeEngine('bob', bobStore);
      await alice.ensureRegistered();
      await bob.ensureRegistered();

      const identityBefore = await bobStore.get('identity');
      const spkBefore = await bobStore.get('spkPriv');
      expect(identityBefore).not.toBeNull();
      expect(spkBefore).not.toBeNull();

      // Two full bootstrap generations + traffic + a replay attempt.
      const first = (await alice.encryptMessage('bob', 'one')).content;
      expect(await bob.decryptMessage('alice', first)).toEqual({ plaintext: 'one' });
      await alice.deleteSession('bob');
      const second = (await alice.encryptMessage('bob', 'two')).content;
      expect(await bob.decryptMessage('alice', second)).toEqual({ plaintext: 'two' });
      expect(await bob.decryptMessage('alice', first)).toEqual({ error: 'TamperedError' });
      expect(await sendToBob(alice, bob, 'three')).toEqual({ plaintext: 'three' });

      // Identity (IK_dh + IK_sig privs) and the still-active SPK priv are
      // byte-for-byte untouched by the OPK cleanup.
      expect(await bobStore.get('identity')).toBe(identityBefore);
      expect(await bobStore.get('spkPriv')).toBe(spkBefore);
      const identity = JSON.parse(identityBefore!);
      expect(identity.dh.priv).toBeTruthy();
      expect(identity.sig.priv).toBeTruthy();
      const spk = JSON.parse(spkBefore!);
      expect(spk.priv).toBeTruthy();
    });

    it("(o5) multi-device DIRM1 responder path deletes each device's consumed OPK priv (device pool)", async () => {
      const bobStore1 = new MemoryKVStore();
      const bobStore2 = new MemoryKVStore();
      const alice = makeEngine('alice');
      const bob1 = makeEngine('bob', bobStore1);
      const bob2 = makeEngine('bob', bobStore2);
      await alice.ensureRegistered();
      await bob1.ensureRegistered();
      await bob2.ensureRegistered();
      expect(await opkPrivKeysOf(bobStore1)).toHaveLength(100);
      expect(await opkPrivKeysOf(bobStore2)).toHaveLength(100);

      const { content } = await alice.encryptMessage('bob', 'dirm1 cleanup');
      expect(content.startsWith('DIRM1:')).toBe(true);
      const multi = JSON.parse(utf8Decode(b64decode(content.slice('DIRM1:'.length))));
      const opkIds = multi.devices.map((e: any) => e.env.x3dh?.opkId as number);
      expect(opkIds).toHaveLength(2);
      for (const id of opkIds) expect(typeof id).toBe('number');

      // Each Bob device consumes ITS OWN OPK from its own device pool — and
      // each device's cleanup removes exactly that priv from its own store.
      expect(await bob1.decryptMessage('alice', content)).toEqual({ plaintext: 'dirm1 cleanup' });
      expect(await bob2.decryptMessage('alice', content)).toEqual({ plaintext: 'dirm1 cleanup' });
      for (const [store, id] of [[bobStore1, opkIds[0]], [bobStore2, opkIds[1]]] as const) {
        expect(await store.get(`opk:${id}`)).toBeNull();
        const remaining = await opkPrivKeysOf(store);
        expect(remaining).toHaveLength(99);
        expect(remaining).not.toContain(`opk:${id}`);
      }

      // Both devices keep working (independent chains, pools intact).
      const next = (await alice.encryptMessage('bob', 'next dirm1')).content;
      expect(await bob1.decryptMessage('alice', next)).toEqual({ plaintext: 'next dirm1' });
      expect(await bob2.decryptMessage('alice', next)).toEqual({ plaintext: 'next dirm1' });
    });
  });
});

/* ── Remediation regression guards (F7/F8 — crypto-hardening round) ───────── */

describe('engine hardening regressions (F7 KT wiring / F8 downgrade memory)', () => {
  /** LocalStorage shim (vitest runs in a node env — no localStorage global). */
  class LocalStorageShim {
    private m = new Map<string, string>();
    getItem(k: string): string | null { return this.m.has(k) ? (this.m.get(k) as string) : null; }
    setItem(k: string, v: string): void { this.m.set(k, String(v)); }
    removeItem(k: string): void { this.m.delete(k); }
    key(i: number): string | null { return [...this.m.keys()][i] ?? null; }
    get length(): number { return this.m.size; }
    clear(): void { this.m.clear(); }
  }

  let storage: LocalStorageShim;
  beforeEach(() => {
    storage = new LocalStorageShim();
    vi.stubGlobal('localStorage', storage as unknown as Storage);
  });

  it('(kt1) F7: bundle fetch fires KT proof verification fire-and-forget — bundle never blocked', async () => {
    const alice = makeEngine('alice');
    const bob = makeEngine('bob');
    await alice.ensureRegistered();
    await bob.ensureRegistered();

    // The default mock serves NO /api/e2ee/kt/proof route (404 = transport
    // unavailable) → the fire-and-forget verification resolves ok:true
    // 'unavailable', raises NO flag, and the bundle path is untouched.
    const r = await sendToBob(alice, bob, 'kt transport-unavailable must not flag');
    expect(r).toEqual({ plaintext: 'kt transport-unavailable must not flag' });
    expect(storage.getItem('ktFlag:bob')).toBeNull();
    // And it must never throw into the caller even on engine errors:
    await alice.encryptMessage('bob', 'after-kt-tick');
  });

  it('(f8a) F8: 429/5xx bundle failures must NOT write the plaintext-downgrade memory', async () => {
    const alice = makeEngine('alice');
    await alice.ensureRegistered();

    const orig = server.fetch;
    // NOTE: beforeEach stubbed the global fetch with server.fetch BY REFERENCE
    // — reassigning server.fetch would not take effect. Re-stub the GLOBAL to
    // intercept only the bundle route with a 429.
    vi.stubGlobal('fetch', (async (url: any, init?: RequestInit) => {
      const path = String(url).split('?')[0];
      if (path.startsWith('/api/e2ee/bundle/') && (init?.method ?? 'GET').toUpperCase() === 'GET') {
        return new Response(JSON.stringify({ error: 'rate limited' }), { status: 429 });
      }
      return orig(url, init);
    }) as unknown as typeof fetch);
    await expect(alice.encryptMessage('bob', 'throttled')).rejects.toThrow();
    // fail-closed (E2eeError) ≠ PeerNotRegisteredError → NO downgrade memory
    expect(await alice.wasDowngraded('bob')).toBe(false);
    expect(storage.getItem('e2eeDowngraded:bob')).toBeNull();
  });

  it('(f8b) F8: wasDowngraded reflects the per-peer KV memory across engine reload', async () => {
    const aliceStore = new MemoryKVStore();
    const alice = makeEngine('alice', aliceStore);
    await alice.ensureRegistered();
    // no bundle → PeerNotRegisteredError → memory persisted
    await expect(alice.encryptMessage('bob', 'unregistered')).rejects.toBeInstanceOf(PeerNotRegisteredError);
    expect(await aliceStore.get('e2eeDowngraded:bob')).toBe('1');

    // A RELOADED engine over the same store sees the memory (persistence, not
    // in-memory state) — this is what the App reads for the badge.
    const reloaded = makeEngine('alice', aliceStore);
    expect(await reloaded.wasDowngraded('bob')).toBe(true);
  });
});
