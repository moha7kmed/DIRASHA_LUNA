// Headless diagnosis: open the app, capture console errors + page errors + final DOM
import puppeteer from 'puppeteer-core';

const browser = await puppeteer.launch({
  executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  headless: true,
  args: ['--no-sandbox', '--disable-setuid-sandbox'],
});

const page = await browser.newPage();
const logs: string[] = [];
page.on('console', (msg) => logs.push(`[console.${msg.type()}] ${msg.text()}`));
page.on('pageerror', (err) => logs.push(`[PAGEERROR] ${(err as Error).message}`));
page.on('requestfailed', (req) => logs.push(`[REQFAIL] ${req.url()} :: ${req.failure()?.errorText}`));

await page.goto('http://localhost:3000/', { waitUntil: 'networkidle2', timeout: 30000 });
await new Promise(r => setTimeout(r, 3000));

const bodyText = await page.evaluate(() => document.body?.innerText?.slice(0, 500) || '(empty)');
const rootHtmlLen = await page.evaluate(() => document.getElementById('root')?.innerHTML?.length || 0);

console.log('=== ROOT innerHTML length:', rootHtmlLen);
console.log('=== BODY TEXT:', JSON.stringify(bodyText));
console.log('=== CONSOLE/PAGE LOGS:');
for (const l of logs.slice(0, 40)) console.log('  ' + l.slice(0, 300));

await browser.close();
