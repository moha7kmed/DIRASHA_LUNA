import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, User, Mail, Calendar, Activity, MessageSquare, Quote, Copy, Check, ShieldAlert } from 'lucide-react';
import { VerifiedBadge } from './VerifiedBadge';

interface UserProfileModalProps {
  userId: string | null;
  allUsers: Record<string, any>;
  currentUserId: string | null;
  onClose: () => void;
  onStartDirectMessage?: (userId: string) => void;
  onReportUser?: (userId: string) => void;
}

export function UserProfileModal({
  userId,
  allUsers,
  currentUserId,
  onClose,
  onStartDirectMessage,
  onReportUser
}: UserProfileModalProps) {
  const [copied, setCopied] = React.useState(false);
  
  if (!userId) return null;
  const user = allUsers[userId];
  if (!user) return null;

  const isMe = currentUserId === userId;

  const handleCopyUsername = () => {
    if (user.username) {
      navigator.clipboard.writeText(`@${user.username}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        navigator.vibrate(20);
      }
    }
  };
  
  // No connection checks required as presence is removed.
  
  // Format deterministic of accurate joins
  const formatJoinedDate = (dateStr?: string) => {
    let dateObj = new Date();
    if (dateStr) {
      dateObj = new Date(dateStr);
    } else {
      // Fallback hash
      let sum = 0;
      if (userId) {
        for (let i = 0; i < userId.length; i++) {
          sum += userId.charCodeAt(i);
        }
      }
      const dayOffset = sum % 25; 
      dateObj = new Date(1779264000000 - dayOffset * 24 * 60 * 60 * 1000);
    }

    const monthNames = [
      "January", "February", "March", "April", "May", "June", 
      "July", "August", "September", "October", "November", "December"
    ];
    const month = monthNames[dateObj.getMonth()];
    const year = dateObj.getFullYear();

    const isFounder = user.email?.toLowerCase().trim() === 'thedarkh95@gmail.com';
    const suffix = isFounder ? ' • Founder' : '';

    return `Joined ${month} ${year}${suffix}`;
  };



  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[120] flex items-end md:items-center justify-center bg-black/60 backdrop-blur-md" dir="ltr">
        {/* Dismiss trigger */}
        <div className="absolute inset-0" onClick={onClose} />

        <motion.div
          initial={{ opacity: 0, y: '100%', scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: '100%', scale: 0.95 }}
          transition={{ duration: 0.35, ease: [0.32, 0.72, 0, 1] }}
          className="relative w-full md:max-w-md h-[95vh] md:h-auto bg-black/40 backdrop-blur-[40px] md:border-[1.2px] border-white/10 md:rounded-[40px] rounded-t-[40px] overflow-hidden md:shadow-[inset_0_2px_4px_rgba(255,255,255,0.2),0_12px_40px_rgba(0,0,0,0.8)] shadow-[0_-10px_40px_rgba(0,0,0,0.8)] text-white z-10 font-sans text-left flex flex-col"
        >
          {/* Header & Avatar Selection based on backgroundBannerUrl */}
          {user.backgroundBannerUrl ? (
            <div className="relative h-48 sm:h-56 bg-[#1a1a1c] shrink-0 flex items-center justify-center">
              <img
                src={user.backgroundBannerUrl}
                alt="Background Banner"
                className="absolute inset-0 w-full h-full object-cover select-none pointer-events-none"
                referrerPolicy="no-referrer"
              />
              {/* Dynamic Background Banner Overlay Shadow on bottom part of height */}
              <div 
                className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black to-transparent pointer-events-none z-0" 
                style={{ opacity: (user.bgBannerShadowOpacity !== undefined && user.bgBannerShadowOpacity !== null ? Number(user.bgBannerShadowOpacity) : 20) / 100 }}
              />
              <div className="relative z-10 group flex flex-col items-center">
                <div className="w-[104px] h-[104px] rounded-full overflow-hidden">
                  <img
                    src={user.avatarUrl || user.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop'}
                    alt={user.displayName}
                    className="w-full h-full object-cover group-hover:scale-105 transition-all duration-300 pointer-events-none"
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>
            </div>
          ) : (
            <>
              {/* Normal Header Backdrop Accent */}
              <div className="h-32 bg-gradient-to-r from-blue-600/30 via-slate-800 to-sky-600/20 relative overflow-hidden shrink-0">
                {user.bannerUrl && (
                  <img
                    src={user.bannerUrl}
                    alt="Banner"
                    className="w-full h-full object-cover select-none pointer-events-none opacity-80"
                    referrerPolicy="no-referrer"
                  />
                )}
                {/* Dynamic Banner Overlay Shadow - lowered to cover bottom h-1/2 and controlled by user parameter */}
                <div 
                  className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black to-transparent pointer-events-none z-0" 
                  style={{ opacity: (user.bannerShadowOpacity !== undefined && user.bannerShadowOpacity !== null ? Number(user.bannerShadowOpacity) : 60) / 100 }}
                />
              </div>

              {/* Normal Avatar Container */}
              <div className="absolute top-16 left-1/2 -translate-x-1/2 flex flex-col items-center z-10">
                <div className="relative group">
                  <div className="w-[104px] h-[104px] rounded-full overflow-hidden border-[3px] border-[#18181a] shadow-[0_8px_24px_rgba(0,0,0,0.6)]">
                    <img
                      src={user.avatarUrl || user.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop'}
                      alt={user.displayName}
                      className="w-full h-full object-cover group-hover:scale-105 transition-all duration-300 pointer-events-none"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                </div>
              </div>
            </>
          )}

          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-10 h-10 flex items-center justify-center bg-black/40 backdrop-blur-md border border-white/10 hover:bg-white/10 rounded-full transition-all text-white hover:scale-105 active:scale-95 z-20 shadow-lg"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Content info card */}
          <div className={`${user.backgroundBannerUrl ? 'pt-6' : 'pt-[60px]'} px-6 pb-8 text-center overflow-y-auto flex-1 scrollbar-hide`}>
            {/* Display name & badges */}
            <div className="flex items-center justify-center gap-2 mt-2">
              <h3 className="text-[26px] font-bold text-white tracking-tight">
                {user.displayName}
              </h3>
              {user.verified && (
                <VerifiedBadge className="w-6 h-6 shrink-0 shadow-sm" />
              )}
            </div>

            {/* Custom Unique Username */}
            <div className="flex items-center justify-center gap-2 mt-1">
              <p className="text-[15px] text-white/50 font-medium">
                @{user.username || 'user'}
              </p>
              <button
                onClick={handleCopyUsername}
                className="p-1 px-2 rounded-full bg-white/5 hover:bg-white/10 text-white/40 hover:text-white transition-all flex items-center gap-1 cursor-pointer"
                title="Copy username"
              >
                {copied ? (
                  <>
                    <Check className="w-3 h-3 text-green-400" />
                    <span className="text-[10px] font-bold text-green-400">Copied</span>
                  </>
                ) : (
                  <Copy className="w-3 h-3" />
                )}
              </button>
            </div>

            {/* Status Bio Section */}
            <div className="mt-8 text-left p-5 bg-white/5 backdrop-blur-md rounded-[28px] border border-white/10 relative min-h-[80px] flex items-center gap-4 shadow-[inset_0_1px_2px_rgba(255,255,255,0.05)]">
              <Quote className="w-7 h-7 text-white/20 shrink-0 self-start mt-1" />
              <div className="flex-1">
                <span className="text-[12px] font-bold text-white/40 uppercase tracking-widest block mb-1">Status</span>
                <p className="text-[15.5px] text-white/90 leading-relaxed break-words font-medium">
                  {user.bio || 'No status set.'}
                </p>
              </div>
            </div>

            {/* Grid of basic user metadata */}
            <div className="mt-4 space-y-3 text-left">
              {/* Email Section */}
              {user.email && (
                <div className="flex items-center justify-between p-4 bg-white/[0.04] backdrop-blur-md rounded-[24px] border border-white/10 shadow-[inset_0_1px_2px_rgba(255,255,255,0.05)]">
                  <div className="flex items-center gap-3.5">
                    <div className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center">
                      <Mail className="w-[18px] h-[18px] text-white/80" />
                    </div>
                    <span className="text-[15px] text-white/70 font-medium">Email</span>
                  </div>
                  <span className="text-[14px] font-mono text-white/90 font-medium truncate max-w-[150px] sm:max-w-none">
                    {user.email.length > 20 ? user.email.substring(0,18) + '...' : user.email}
                  </span>
                </div>
              )}

              {/* Verified Platform Creator Section */}
              {user.email?.toLowerCase().trim() === 'thedarkh95@gmail.com' && (
                <div className="flex items-center justify-between p-4 bg-white/[0.06] backdrop-blur-md rounded-[24px] border border-indigo-400/30 shadow-[inset_0_1px_2px_rgba(255,255,255,0.1),0_4px_20px_rgba(99,102,241,0.2)]">
                  <div className="flex items-center gap-3.5">
                    <div className="w-9 h-9 rounded-full bg-indigo-500/20 flex items-center justify-center">
                      <User className="w-[18px] h-[18px] text-indigo-400" />
                    </div>
                    <span className="text-[15px] text-indigo-200/80 font-medium tracking-wide">Role</span>
                  </div>
                  <span className="text-[14px] text-indigo-300 font-bold">
                    Founder & Lead Dev ✨
                  </span>
                </div>
              )}

              {/* Date Joined Section */}
              <div className="flex items-center justify-between p-4 bg-white/[0.04] backdrop-blur-md rounded-[24px] border border-white/10 shadow-[inset_0_1px_2px_rgba(255,255,255,0.05)]">
                <div className="flex items-center gap-3.5">
                  <div className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center">
                    <Calendar className="w-[18px] h-[18px] text-white/80" />
                  </div>
                  <span className="text-[15px] text-white/70 font-medium">Joined</span>
                </div>
                <span className="text-[15px] text-white/90 font-medium">
                  {formatJoinedDate(user.createdAt)}
                </span>
              </div>

              {/* Active Chats Usage Section */}
              {user.activeChatsCount !== undefined && (
                <div className="flex items-center justify-between p-4 bg-white/[0.04] backdrop-blur-md rounded-[24px] border border-white/10 shadow-[inset_0_1px_2px_rgba(255,255,255,0.05)]">
                  <div className="flex items-center gap-3.5">
                    <div className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center">
                      <Activity className="w-[18px] h-[18px] text-white/80" />
                    </div>
                    <span className="text-[15px] text-white/70 font-medium">Active Chats</span>
                  </div>
                  <span className="text-[15px] text-white/90 font-medium bg-white/10 px-3 py-1 rounded-full border border-white/5">
                    {user.activeChatsCount} {user.activeChatsCount === 1 ? 'Session' : 'Sessions'}
                  </span>
                </div>
              )}
            </div>

            {/* Interaction Direct Communication button */}
            {!isMe && onStartDirectMessage && (
              <button
                onClick={() => {
                  onStartDirectMessage(user.id);
                  onClose();
                }}
                className="w-full mt-6 py-4 bg-white text-black hover:bg-neutral-200 active:scale-[0.98] text-[16px] font-bold rounded-[24px] transition-all duration-300 shadow-[0_8px_20px_rgba(255,255,255,0.2)] flex items-center justify-center gap-2.5 cursor-pointer will-change-transform"
              >
                <MessageSquare className="w-[18px] h-[18px]" />
                <span>Message</span>
              </button>
            )}

            {!isMe && onReportUser && (
              <button
                onClick={() => {
                  onReportUser(user.id);
                }}
                className="w-full mt-3 py-3.5 bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20 active:scale-[0.98] text-[15px] font-bold rounded-[24px] transition-all duration-300 flex items-center justify-center gap-2.5 cursor-pointer will-change-transform"
              >
                <ShieldAlert className="w-[18px] h-[18px]" />
                <span>إبلاغ عن المستخدم (Report User)</span>
              </button>
            )}
            
            <div className="h-8 shrink-0 md:hidden" /> {/* Extra padding at bottom for mobile safe area */}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
