/**
 * Dirasha — encrypt-at-source media flow tests (F1/P0 fix).
 *
 * Pure logic, no browser / no network:
 *   t1 — a wire attachment built from encryptAttachment carries ONLY opaque
 *        metadata (mimeType application/octet-stream, name 'enc.bin',
 *        meta.e2ee) exactly like App.send-wrap / ChatWindow pre-upload build.
 *   t2 — buildEncryptedPayload with a PRE-ENCRYPTED payload round-trips through
 *        parseEncryptedPayload: mime/name/size are recovered from the PAYLOAD
 *        (which rode inside the encrypted envelope), never from the wire
 *        attachment's opaque enc.bin metadata.
 *   t3 — the skip-guard (isAlreadyEncryptedAttachment, used by App's
 *        encryptAttachmentsForWire): already-encrypted attachments are
 *        recognized so the send wrap does NOT re-encrypt / re-upload them,
 *        while every plaintext/pseudo/malformed shape stays unflagged.
 */
import { describe, it, expect } from 'vitest';

import {
  encryptAttachment,
  decryptAttachment,
  buildEncryptedPayload,
  parseEncryptedPayload,
  isAlreadyEncryptedAttachment,
} from '../src/lib/e2ee/media.ts';
import { utf8Encode } from '../src/lib/e2ee/crypto.ts';

/** Mirror of the wire-attachment construction used by ChatWindow's
 *  encryptAndUploadAttachment and App's encryptAttachmentsForWire. */
function buildWireAttachment(enc: ReturnType<typeof encryptAttachment>) {
  return {
    id: enc.payload.attId,
    url: '/api/media/gdrive/enc-file-id',
    mimeType: 'application/octet-stream',
    name: 'enc.bin',
    size: enc.blob.length,
    meta: { e2ee: true, attId: enc.payload.attId },
  };
}

describe('t1 — wire attachment built from encryptAttachment is opaque', () => {
  it('carries mimeType octet-stream + name enc.bin + meta.e2ee (no plaintext metadata)', () => {
    const bytes = utf8Encode('secret image bytes ✓');
    const enc = encryptAttachment(bytes, 'image/png', 'holiday-photo.png');
    const att = buildWireAttachment(enc);

    // Opaque on the wire — the real mime/name/size never ride the upload.
    expect(att.mimeType).toBe('application/octet-stream');
    expect(att.name).toBe('enc.bin');
    expect(att.meta.e2ee).toBe(true);
    expect(att.id).toBe(enc.payload.attId);
    expect(att.meta.attId).toBe(enc.payload.attId);

    // Ciphertext length = plaintext + 16B Poly1305 tag (declared size is the blob).
    expect(att.size).toBe(bytes.length + 16);

    // None of the plaintext metadata may appear in the wire object.
    const wireJson = JSON.stringify(att);
    expect(wireJson).not.toContain('holiday-photo.png');
    expect(wireJson).not.toContain('image/png');
    expect(wireJson).not.toContain(enc.payload.key);
    expect(wireJson).not.toContain(enc.payload.iv);
  });
});

describe('t2 — pre-encrypted payload round-trips through the envelope', () => {
  it('recovers mime/name from the payload (inside the envelope), not the wire attachment', () => {
    const bytes = utf8Encode('مرحبا — voice note body');
    const enc = encryptAttachment(bytes, 'audio/webm;codecs=opus', 'رسالة_صوتية_12-30-05.webm');
    const att = buildWireAttachment(enc);

    // Sender-side: payload is embedded INSIDE the encrypted text envelope
    // (buildEncryptedPayload), the wire attachment stays opaque.
    const envelopePlaintext = buildEncryptedPayload('🎙️ رسالة صوتية', [enc.payload]);

    // ── Wire transport boundary (content is encrypted by the engine) ──
    // Receiver side: engine-decrypted plaintext → parseEncryptedPayload.
    const parsed = parseEncryptedPayload(envelopePlaintext);
    expect(parsed.text).toBe('🎙️ رسالة صوتية');
    expect(parsed.files).toHaveLength(1);

    const payload = parsed.files[0];
    // Metadata comes from the PAYLOAD, not from att (name/mime on att are opaque).
    expect(payload.mime).toBe('audio/webm;codecs=opus');
    expect(payload.name).toBe('رسالة_صوتية_12-30-05.webm');
    expect(payload.size).toBe(bytes.length);
    expect(payload.attId).toBe(att.id);

    // The payload + fetched ciphertext decrypt back to the original bytes.
    const dec = decryptAttachment(payload, enc.blob);
    expect(Array.from(dec.bytes)).toEqual(Array.from(bytes));
    expect(dec.mime).toBe('audio/webm;codecs=opus');
    expect(dec.name).toBe('رسالة_صوتية_12-30-05.webm');
  });
});

describe('t3 — skip-guard: already-encrypted attachments are not re-processed', () => {
  it('flags wire attachments produced by the encrypt-at-source path', () => {
    const enc = encryptAttachment(utf8Encode('body'), 'application/pdf', 'doc.pdf');
    const att = buildWireAttachment(enc) as any;

    expect(isAlreadyEncryptedAttachment(att)).toBe(true);
    expect(isAlreadyEncryptedAttachment({ ...att, meta: { e2ee: true, attId: att.meta.attId, e2eePayload: enc.payload } })).toBe(true);
  });

  it('does NOT flag plaintext, pseudo or malformed attachments', () => {
    // Plain composer upload (legacy path) — must stay on the re-encrypt path.
    expect(isAlreadyEncryptedAttachment({ url: '/api/media/gdrive/x', mimeType: 'image/png', name: 'photo.png', size: 10 })).toBe(false);
    // Pseudo attachment (location/contact/poll cards).
    expect(isAlreadyEncryptedAttachment({ url: 'https://www.openstreetmap.org/?mlat=1', mimeType: 'application/x-dirasha-location' })).toBe(false);
    // A sticker / viewOnce / arbitrary meta WITHOUT e2ee must not trip it.
    expect(isAlreadyEncryptedAttachment({ mimeType: 'image/webp', meta: { sticker: true } })).toBe(false);
    expect(isAlreadyEncryptedAttachment({ mimeType: 'image/png', meta: { viewOnce: true } })).toBe(false);
    // e2ee flag with the wrong value is not authoritative.
    expect(isAlreadyEncryptedAttachment({ mimeType: 'application/octet-stream', meta: { e2ee: false } })).toBe(false);
    expect(isAlreadyEncryptedAttachment({ mimeType: 'application/octet-stream', meta: { e2ee: 'yes' } })).toBe(false);
    // Malformed shapes are safe (never throw).
    expect(isAlreadyEncryptedAttachment(null)).toBe(false);
    expect(isAlreadyEncryptedAttachment(undefined)).toBe(false);
    expect(isAlreadyEncryptedAttachment('enc.bin')).toBe(false);
    expect(isAlreadyEncryptedAttachment(42)).toBe(false);
    expect(isAlreadyEncryptedAttachment({})).toBe(false);
    expect(isAlreadyEncryptedAttachment({ meta: null })).toBe(false);
    expect(isAlreadyEncryptedAttachment({ meta: 'e2ee' })).toBe(false);
  });

  it('mirrors App.send-wrap behavior: flagged attachments skip encryption, payload passes through unmodified', () => {
    // Reproduces the App encryptAttachmentsForWire skip-guard branch as a
    // pure function so the contract is pinned against regressions.
    const encryptOrSkip = (att: any, payloadSink: any[]) => {
      if (isAlreadyEncryptedAttachment(att)) {
        const payload = att?.meta?.e2eePayload;
        if (payload) payloadSink.push(payload);
        const { e2eePayload: _stripped, ...cleanMeta } = att.meta || {};
        return { ...att, meta: cleanMeta };
      }
      return { ...att, encryptedNow: true };
    };

    const enc = encryptAttachment(utf8Encode('bytes'), 'video/mp4', 'clip.mp4');
    const preEncrypted = {
      id: enc.payload.attId,
      url: '/api/media/gdrive/enc-file-id',
      mimeType: 'application/octet-stream',
      name: 'enc.bin',
      size: enc.blob.length,
      meta: { e2ee: true, attId: enc.payload.attId, e2eePayload: enc.payload },
    };

    const payloads: any[] = [];
    const wire = encryptOrSkip(preEncrypted, payloads);

    // Skipped: no re-encryption, wire copy is clean of key material, payload
    // passed through to the envelope UNCHANGED (same object reference).
    expect(wire.encryptedNow).toBeUndefined();
    expect(wire.meta.e2ee).toBe(true);
    expect(wire.meta.e2eePayload).toBeUndefined();
    expect(JSON.stringify(wire)).not.toContain(enc.payload.key);
    expect(payloads).toHaveLength(1);
    expect(payloads[0]).toBe(enc.payload);

    // A plaintext attachment is NOT skipped (would be encrypted + re-uploaded).
    const plain = { url: '/api/media/gdrive/x', mimeType: 'image/png', name: 'photo.png' };
    const sink2: any[] = [];
    expect(encryptOrSkip(plain, sink2).encryptedNow).toBe(true);
    expect(sink2).toHaveLength(0);
  });
});
