# خادم TURN الخاص بديراشة — دليل التشغيل

## لماذا؟
المكالمات تعتمد على TURN مجاني مشترك (openrelay) — غير مضمون. خادم TURN خاص = مكالمات موثوقة حتى خلف أقسى الشبكات، تمامًا مثل واتساب.

## المتطلبات (≈10 دقائق، ~5$/شهر أو مجاني على Oracle Free Tier)
- VPS صغير (Ubuntu 22.04+)
- Docker: `curl -fsSL https://get.docker.com | sh`

## الخطوات

### 1) ارفع المجلد إلى الـ VPS
```bash
scp -r deploy/coturn root@<IP>:~/dirasha-turn
```

### 2) عدّل الإعدادات
```bash
cd ~/dirasha-turn
nano turnserver.conf
#  - ضع IP العام للـ VPS في سطر external-ip=
#  - غيّر CHANGE_THIS_TURN_SECRET إلى سر قوي
```

### 3) شغّل
```bash
docker compose up -d
docker compose logs -f  # تأكد: "TURN server listening"
```

### 4) الجدار الناري
```bash
ufw allow 3478
ufw allow 3478/udp
ufw allow 3478/tcp
ufw allow 49160:49200/udp
```

### 5) اربطه بديراشة (Render env vars)
Render → Service → Environment ثم أعد النشر:
```
VITE_TURN_URLS = turn:<IP>:3478?transport=udp,turn:<IP>:3478?transport=tcp
VITE_TURN_USERNAME = dirasha
VITE_TURN_CREDENTIAL = <نفس السر الذي وضعتَه في turnserver.conf>
```
عميل ديراشة يقرأ هذه المتغيرات تلقائيًا (App.tsx) — صفر تغيير كود.
