/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { db } from '../database.ts';
import { redisCluster } from './redis_client.ts';
import { WebPushService, buildMessagePushPayload } from '../services/push.ts';
import { DashboardStatsCollector } from '../services/dashboard_stats.ts';

export interface WriteJob {
  id: string; // Message syntheticId
  chatId: string;
  senderId: string;
  senderName: string;
  content: string;
  type: 'text' | 'attachment';
  attachments: any[];
  replyTo: any;
  metadata?: any;
  createdAt: string;
  tempMessageId?: string;
  expiresAt?: string;
  onlinePartners: string[];
  members: any[];
  retryCount: number;
}

/**
 * PROJECT 7 (Privacy-Preserving Notifications): the message push payload is
 * built exclusively by the pure generic builder `buildMessagePushPayload`
 * (src/server/services/push.ts). Message content, attachment URLs and the
 * sender's display name NEVER ride the push — it transits third-party
 * relays (FCM/APNs gateways) and lands verbatim on the OS lock screen.
 * Recipients route by chatId and resolve sender names locally after unlock.
 */

export class BackgroundWriteQueue {
  private static queue: WriteJob[] = [];
  private static isProcessing = false;
  private static REDIS_KEY = 'queue:pending_writes';

  /**
   * F16 (privacy/retention): WriteJob carries message content in plaintext,
   * and the queue state is mirrored to Redis as a crash-recovery buffer.
   * That mirror is now HARD-BOUNDED to 1 hour on both axes:
   *   - Redis TTL (`persist`) = 1h — content can never linger in Redis for
   *     the previous 1-year window;
   *   - in-queue age cap = 1h — jobs older than MAX_JOB_AGE_MS are dropped
   *     loudly (failed-state broadcast + DELETE from the mirror) instead of
   *     being retried forever, at boot recovery and on every worker pass.
   * Net effect: no message content survives anywhere (memory or Redis)
   * longer than one hour after it entered the queue.
   */
  private static readonly MAX_JOB_AGE_MS = 60 * 60 * 1000; // 1 hour
  private static readonly REDIS_TTL_SECONDS = 60 * 60; // 1 hour

  /**
   * Initializes the queue from Redis to restore any unsaved messages in case of a crash or restart.
   */
  public static async initialize(): Promise<void> {
    try {
      console.log('[BackgroundWriteQueue] Initializing and seeking cached pending writes in Redis...');
      const serialized = await redisCluster.getTemp(this.REDIS_KEY);
      if (serialized) {
        const jobs: WriteJob[] = JSON.parse(serialized);
        // F16: enforce the 1h retention cap at recovery — stale jobs (content
        // in plaintext) are dropped loudly, never resurrected after restart.
        const fresh = jobs.filter(j => this.jobAgeMs(j) <= this.MAX_JOB_AGE_MS);
        const stale = jobs.length - fresh.length;
        if (stale > 0) {
          console.error(`[BackgroundWriteQueue] [RETENTION] Dropped ${stale} queued write job(s) older than 1h during recovery — their content will NOT be persisted (senders already saw the 'failed' state).`);
        }
        if (fresh.length > 0) {
          console.log(`[BackgroundWriteQueue] Restored ${fresh.length} pending message writes from Redis broker storage. Booting workers...`);
          // Increment retryCount for recovered jobs since they were interrupted
          for (const job of fresh) {
            job.retryCount = Math.min((job.retryCount || 0) + 1, 3);
          }
          this.queue = fresh;
          this.triggerProcessing();
        }
      } else {
        console.log('[BackgroundWriteQueue] No cached pending writes found. Resilient mode active.');
      }
    } catch (err: any) {
      console.error('[BackgroundWriteQueue] Critical Initialization Error:', err.message);
    }
  }

  /**
   * Adds a new message write job to the queue, persists the queue state to Redis, and triggers the worker loop.
   */
  public static async enqueue(job: WriteJob): Promise<void> {
    this.queue.push(job);
    await this.persist();
    console.log(`[BackgroundWriteQueue] Queued write job for Msg ID: ${job.id} (Chat: ${job.chatId}). Current queue length: ${this.queue.length}`);
    this.triggerProcessing();
  }

  /**
   * Persists the current queue state into Redis / Memory cache.
   * F16: TTL is bounded to 1h — plaintext message content may ride this
   * mirror ONLY as a short-lived crash-recovery buffer, never long-term.
   */
  private static async persist(): Promise<void> {
    try {
      await redisCluster.setTemp(this.REDIS_KEY, JSON.stringify(this.queue), this.REDIS_TTL_SECONDS);
    } catch (err: any) {
      console.error('[BackgroundWriteQueue] Failed persisting queue state:', err.message);
    }
  }

  /** F16: age of a queued job in ms, from its createdAt stamp. */
  private static jobAgeMs(job: WriteJob): number {
    const ts = new Date(job.createdAt).getTime();
    return Number.isFinite(ts) ? Date.now() - ts : Infinity;
  }

  /**
   * Triggers background queue processing if not already running.
   */
  private static triggerProcessing(): void {
    if (this.isProcessing) return;
    this.isProcessing = true;
    
    // Run worker loop fully detached in background
    (async () => {
      try {
        await this.processQueue();
      } catch (err: any) {
        console.error('[BackgroundWriteQueue] Worker loop crash:', err.message);
      } finally {
        this.isProcessing = false;
      }
    })();
  }

  /**
   * Sequential, controlled-concurrency worker loop.
   */
  private static async processQueue(): Promise<void> {
    while (this.queue.length > 0) {
      const job = this.queue[0]; // Process FIFO

      // F16: hard 1h retention cap — expired jobs are dropped loudly and
      // broadcast as 'failed' instead of holding plaintext content forever
      // during a prolonged outage.
      const ageMs = this.jobAgeMs(job);
      if (ageMs > this.MAX_JOB_AGE_MS) {
        console.error(`[BackgroundWriteQueue] [RETENTION] Dropping Msg ID: ${job.id} — queued write is ${Math.round(ageMs / 60000)} min old (> 1h retention cap). Content will NOT be persisted.`);
        await this.dropExpiredJob(job);
        continue;
      }

      // Check if simulated database outage is active
      if (globalThis as any && (globalThis as any).dbFailureSimulation === true) {
        console.warn(`[BackgroundWriteQueue] [SIMULATION ENFORCED] Rejecting database insert mock for Msg ID: ${job.id}`);
        await this.handleJobFailure(job, new Error('Simulated Database Connection Timeout (504)'));
        continue;
      }

      try {
        console.log(`[BackgroundWriteQueue] Attempting DB Insert for Msg ID: ${job.id} (Attempt ${job.retryCount + 1})...`);
        const sentTs = new Date(job.createdAt).getTime();
        const dbStart = Date.now();
        
        // 1. Create message in PostgreSQL database
        const message = await db.createMessage(
          job.chatId,
          job.senderId,
          job.content,
          job.type,
          job.attachments,
          job.replyTo,
          {},
          job.id, // syntheticId
          job.createdAt,
          job.tempMessageId,
          job.expiresAt
        );

        const dbEnd = Date.now();

        // 2. Persist delivered receipts for active online partners
        if (job.onlinePartners.length > 0) {
          await Promise.all(
            job.onlinePartners.map(partnerId => db.updateMessageStatus(message.id, partnerId, 'delivered'))
          );
        }

        const pubStart = Date.now();

        // 3. Dispatch separate read receipt state transitions
        const stateChangePromises: Promise<any>[] = [];
        const successState = job.onlinePartners.length > 0 ? 'delivered' : 'sent';

        const stateEventPayload = {
          chatId: job.chatId,
          lastMessageId: message.id,
          userId: job.senderId,
          status: successState,
          updatedAt: new Date().toISOString()
        };

        const stateEvent = {
          event: 'msg:state:change',
          payload: stateEventPayload
        };

        stateChangePromises.push(redisCluster.publish(`chat:${job.chatId}`, stateEvent));
        for (const memb of job.members) {
          stateChangePromises.push(redisCluster.publish(`user:updates:${memb.userId}`, stateEvent));
        }
        await Promise.all(stateChangePromises);

        const pubEnd = Date.now();

        // 4. Send silent background Web Push Notifications
        // Push privacy (Project 7): the payload carries ONLY the generic
        // label + routing metadata — no message content, no sender display
        // name (see buildMessagePushPayload in src/server/services/push.ts).
        for (const memb of job.members) {
          if (memb.userId !== job.senderId) {
            const pushPayload = buildMessagePushPayload(job.chatId, message.id);
            WebPushService.sendPush(memb.userId, pushPayload.title, pushPayload.body, pushPayload.data)
              .catch(e => console.warn('[BackgroundWriteQueue] Async WebPush warning:', e.message));
          }
        }

        // Record precise telemetry logs
        const queueTime = dbStart - sentTs;
        const dbWriteTime = dbEnd - dbStart;
        const redisPubTime = pubEnd - pubStart;
        const deliveryTime = Date.now() - sentTs;

        DashboardStatsCollector.recordMessageTimings({
          messageId: message.id,
          senderId: job.senderId,
          chatId: job.chatId,
          sendTime: sentTs,
          queueTime: queueTime > 0 ? queueTime : 0,
          dbWriteTime,
          redisPubTime,
          deliveryTime,
          totalTime: deliveryTime
        });

        // 5. Job successfully executed! Remove from queue-list
        this.queue.shift();
        await this.persist();
        console.log(`[BackgroundWriteQueue] Successfully fully stored Msg ID: ${job.id} in PostgreSQL. Remaining queue count: ${this.queue.length}`);

      } catch (err: any) {
        console.error(`[BackgroundWriteQueue] Error inserting message ${job.id} into database:`, err.message);
        DashboardStatsCollector.logError('BACKGROUND_QUEUE', err.message, err.stack);
        await this.handleJobFailure(job, err);
      }
    }
  }

  /**
   * Process failure logic, tracking retry loops with backoff or marking as failed.
   */
  private static async handleJobFailure(job: WriteJob, error: Error): Promise<void> {
    job.retryCount++;

    if (job.retryCount <= 3) {
      // F16: an expired job never re-enters the retry loop — it is dropped
      // loudly with a 'failed' broadcast instead of holding content longer.
      if (this.jobAgeMs(job) > this.MAX_JOB_AGE_MS) {
        console.error(`[BackgroundWriteQueue] [RETENTION] Msg ID: ${job.id} expired (> 1h) while backing off — dropping instead of retrying.`);
        await this.dropExpiredJob(job);
        return;
      }
      // Schedule dynamic delay backoff
      const delayMs = Math.min(1000 * Math.pow(2, job.retryCount), 15000); // 2s, 4s, 8s max 15s
      console.warn(`[BackgroundWriteQueue] Job Msg ID: ${job.id} failed. Postponing next attempt (${job.retryCount}/3) in ${delayMs / 1000} seconds.`);
      
      // Rotate job to back of queue to let other messages stream during recovery (FIFO round-robin)
      this.queue.shift();
      this.queue.push(job);
      await this.persist();

      // Spawn non-blocking backoff delay
      await new Promise(resolve => setTimeout(resolve, delayMs));
    } else {
      // 3 Attempts exhausted! Permanent Failure inside database layer
      console.error(`[BackgroundWriteQueue] [PERMANENT FAILURE] Job Msg ID: ${job.id} has exhausted all 3 DB retries. Marking as permanently failed.`);
      DashboardStatsCollector.logError('QUEUE_FAILURE', `Job Msg ID: ${job.id} failed permanently for Chat: ${job.chatId} after 3 attempts`);
      
      // Update sender that save has failed
      const failureEvent = {
        event: 'msg:state:change',
        payload: {
          chatId: job.chatId,
          lastMessageId: job.id,
          userId: job.senderId,
          status: 'failed',
          updatedAt: new Date().toISOString()
        }
      };

      // Broadcast 'failed' status to sender device so they see failure indicator & enable Manual Retry
      await redisCluster.publish(`chat:${job.chatId}`, failureEvent);
      for (const memb of job.members) {
        await redisCluster.publish(`user:updates:${memb.userId}`, failureEvent);
      }

      // Remove from queue completely
      this.queue.shift();
      await this.persist();
    }
  }

  /**
   * F16 (retention drop): broadcast the 'failed' state to the sender and
   * members (same payload shape as the permanent-failure path), then remove
   * the job from the in-memory queue AND the Redis mirror. The caller must
   * ensure the job is at the head of the queue (FIFO) — all call sites do.
   */
  private static async dropExpiredJob(job: WriteJob): Promise<void> {
    try {
      const failureEvent = {
        event: 'msg:state:change',
        payload: {
          chatId: job.chatId,
          lastMessageId: job.id,
          userId: job.senderId,
          status: 'failed',
          updatedAt: new Date().toISOString()
        }
      };
      await redisCluster.publish(`chat:${job.chatId}`, failureEvent);
      for (const memb of job.members) {
        await redisCluster.publish(`user:updates:${memb.userId}`, failureEvent);
      }
    } catch (err: any) {
      console.error('[BackgroundWriteQueue] Failed broadcasting retention-drop event:', err.message);
    }
    this.queue.shift();
    await this.persist();
  }

  /**
   * Safe helper to update the content of a pending message in the queue before it hits the DB
   */
  public static updatePendingMessageContent(messageId: string, content: string): boolean {
    const job = this.queue.find(j => j.id === messageId);
    if (job) {
      job.content = content;
      this.persist().catch(() => {});
      console.log(`[BackgroundWriteQueue] Moderation Intercept: Updated pending write job for Msg ID ${messageId} content directly in memory.`);
      return true;
    }
    return false;
  }

  /**
   * Retrieves active items inside queue for debug and dashboard monitoring
   */
  public static getActiveQueue(): WriteJob[] {
    return this.queue;
  }

  /**
   * Flushes and clears entire queue for test simulation sweeps
   */
  public static clearQueue(): void {
    this.queue = [];
    this.persist().catch(() => {});
  }
}
