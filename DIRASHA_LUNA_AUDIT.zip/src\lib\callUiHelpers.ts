/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/** Shared formatting helpers for the call UI (CallInterface + Calls tab). */

/**
 * Format a call duration in seconds as 'mm:ss' or 'h:mm:ss'.
 * Minutes/seconds are always zero-padded to two digits; hours are not padded.
 */
export function formatCallDuration(totalSeconds: number): string {
  const secs = Math.max(0, Math.floor(totalSeconds || 0));
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  const s = secs % 60;
  const mm = m.toString().padStart(2, '0');
  const ss = s.toString().padStart(2, '0');
  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
}

/**
 * Human-readable Arabic day label for a call log timestamp.
 * Returns 'اليوم' for today, 'أمس' for yesterday, otherwise a formatted date.
 */
export function dayLabelFor(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '';

  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const startOfThatDay = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const diffDays = Math.round((startOfToday.getTime() - startOfThatDay.getTime()) / 86400000);

  if (diffDays === 0) return 'اليوم';
  if (diffDays === 1) return 'أمس';
  return date.toLocaleDateString('ar', { day: 'numeric', month: 'long' });
}
