/**
 * DIR-NEW-05 + DIR-NEW-12 — vault hardening (src/lib/e2ee/vault.ts).
 *
 * DIR-NEW-05 — KEK creation race across SEPARATE store instances:
 *   App.tsx constructs two separate `new IndexedDBKekStore()` instances (the
 *   1:1 engine vault and the group-crypto vault) pointing at the SAME
 *   dbName/storeName/keyId. The old in-flight guard was a WeakMap keyed on
 *   the store OBJECT, so each instance raced its own KEK generation; the
 *   last put won and the loser's encrypted records were orphaned. The guard
 *   is now a Map keyed by the store's LOGICAL coordinates (`logicalId`) —
 *   these tests use the EphemeralKekStore seam with shared logical ids to
 *   exercise the identical code path in Node.
 *
 * DIR-NEW-12 — legacy migration QUARANTINES instead of silently keeping
 *   plaintext forever: migrateExisting() encrypts + verifies read-back per
 *   record; failures move the record to 'quarantine:<key>' (plaintext
 *   preserved for manual recovery, out of the served namespace). get()
 *   lazily migrates legacy values and fails CLOSED on failure — raw legacy
 *   plaintext is never served.
 *
 * Runs in Node: crypto.subtle (WebCrypto) is global in Node ≥ 18; the KEK
 * store is the EphemeralKekStore seam and the record store is MemoryKVStore
 * (or fault-injected subclasses) — same logic as the browser path. No new
 * dependencies.
 */

import { describe, it, expect, vi } from 'vitest';
import {
  VaultKVStore,
  IndexedDBKekStore,
  EphemeralKekStore,
  getOrCreateKek,
  kekInFlightSizeForTests,
} from '../src/lib/e2ee/vault.ts';
import type { KekStore } from '../src/lib/e2ee/vault.ts';
import { MemoryKVStore } from '../src/lib/e2ee/store.ts';

/* ── Fault-injected record stores (stand in for IndexedDB in Node) ────────── */

/** MemoryKVStore whose set() throws for armed keys (injected write failure). */
class FaultKVStore extends MemoryKVStore {
  private failSetFor = new Set<string>();
  armFailSet(key: string): void { this.failSetFor.add(key); }
  async set(key: string, value: string): Promise<void> {
    if (this.failSetFor.has(key)) throw new Error('injected set failure');
    await super.set(key, value);
  }
}

/** MemoryKVStore that corrupts the ciphertext read-back of armed keys — the
 *  write "succeeds" but the stored envelope no longer decrypts (the verify
 *  path of migration must catch this, not just the encrypt path). */
class CorruptOnReadKVStore extends MemoryKVStore {
  corruptEnvelopeFor = new Set<string>();
  async get(key: string): Promise<string | null> {
    const v = await super.get(key);
    if (v !== null && this.corruptEnvelopeFor.has(key) && v.includes('"v":"enc1"')) {
      return v.replace(/"ct":"[^"]*"/, '"ct":"CORRUPTED"');
    }
    return v;
  }
}

/* ═══ DIR-NEW-05 — logical store identity ══════════════════════════════════ */

describe('DIR-NEW-05 — KekStore logicalId (logical coordinates, not object identity)', () => {
  it('IndexedDBKekStore.logicalId encodes dbName|storeName|keyId (constructed in Node, no IndexedDB touched)', () => {
    // The constructor only computes the identity string — open() is lazy, so
    // this unit-constructs without any IndexedDB access (Node has none).
    const store = new IndexedDBKekStore('dirasha-vault', 'keys', 'kek');
    expect(store.logicalId).toBe('dirasha-vault|keys|kek');

    const cache = new IndexedDBKekStore('dirasha-cache-vault', 'cache-keys', 'cache-kek:user-9');
    expect(cache.logicalId).toBe('dirasha-cache-vault|cache-keys|cache-kek:user-9');
  });

  it('two SEPARATE IndexedDBKekStore instances over the SAME coordinates share one logicalId (the App.tsx bug shape)', () => {
    // App.tsx: `new VaultKVStore(new IndexedDBKVStore(), new IndexedDBKekStore())`
    // is constructed twice (1:1 engine + group crypto) with the defaults.
    const engine = new IndexedDBKekStore();
    const group = new IndexedDBKekStore();
    expect(engine).not.toBe(group);                       // distinct objects…
    expect(engine.logicalId).toBe(group.logicalId);       // …but ONE logical slot
  });

  it('EphemeralKekStore: unique logicalId per instance by default, explicit ids are honored', () => {
    const a = new EphemeralKekStore();
    const b = new EphemeralKekStore();
    expect(a.logicalId).not.toBe(b.logicalId);
    expect(a.logicalId).toMatch(/^ephemeral\|/);

    const s1 = new EphemeralKekStore('shared-logical');
    const s2 = new EphemeralKekStore('shared-logical');
    expect(s1.logicalId).toBe(s2.logicalId);
  });
});

/* ═══ DIR-NEW-05 — cross-instance KEK creation race ════════════════════════ */

describe('DIR-NEW-05 — getOrCreateKek serialized per logical slot', () => {
  it('two stores sharing a logicalId race → SAME key object, exactly ONE generation', async () => {
    const a = new EphemeralKekStore('race-shared');
    const b = new EphemeralKekStore('race-shared');
    const [ka, kb] = await Promise.all([getOrCreateKek(a), getOrCreateKek(b)]);

    // Same CryptoKey object identity — crypto.subtle keys are objects, and
    // both waiters rode the ONE in-flight creation promise for the slot.
    expect(ka).toBe(kb);

    // Exactly one generation across both stores (put = one generation each).
    expect(a.putCalls + b.putCalls).toBe(1);

    // Both instances re-read the same single stored key record.
    expect(await a.get()).toBe(await b.get());
    expect(await a.get()).not.toBeNull();

    // Sequential re-entry stays on the stored key (no churn, no 2nd generation).
    expect(await getOrCreateKek(b)).toBe(ka);
    expect(a.putCalls + b.putCalls).toBe(1);

    // The guard drained after the race.
    expect(kekInFlightSizeForTests()).toBe(0);
  });

  it('two vaults over stores sharing a logicalId converge on one KEK (engine+group vault parity)', async () => {
    // Direct mirror of the App.tsx scenario: two VaultKVStore instances built
    // on separate KEK-store objects with the same logical coordinates, one
    // base record store. Under the old WeakMap guard each store generated its
    // own key and v2 could never decrypt v1's records.
    const base = new MemoryKVStore();
    const v1 = new VaultKVStore(base, new EphemeralKekStore('engine-logical'));
    const v2 = new VaultKVStore(base, new EphemeralKekStore('engine-logical'));
    await v1.set('identity', '{"priv":"SECRET-IDENTITY"}');
    expect(await v2.get('identity')).toBe('{"priv":"SECRET-IDENTITY"}');
  });

  it('the guard holds exactly ONE in-flight entry during a 5-way race on one logicalId', async () => {
    const inner = new EphemeralKekStore('race-sampled');
    let observedDuringRace = -1;
    // Sampling wrapper (same logicalId): the creator's RE-READ (get after
    // put) happens while the four waiters are queued on the in-flight
    // promise → sample the guard size there.
    const sampled: KekStore = {
      logicalId: inner.logicalId,
      get: async () => {
        const v = await inner.get();
        if (v !== null) observedDuringRace = kekInFlightSizeForTests();
        return v;
      },
      put: async (k) => { await inner.put(k); },
    };
    const keys = await Promise.all([
      getOrCreateKek(sampled),
      getOrCreateKek(inner),
      getOrCreateKek(inner),
      getOrCreateKek(inner),
      getOrCreateKek(inner),
    ]);

    // All five callers converge on ONE key object.
    for (const k of keys) expect(k).toBe(keys[0]);
    // During the race the guard held exactly one entry (this creator's).
    expect(observedDuringRace).toBe(1);
    // Exactly one generation.
    expect(inner.putCalls).toBe(1);
    expect(kekInFlightSizeForTests()).toBe(0);
  });

  it('5 concurrent getOrCreateKek over one logicalId → exactly ONE generation (putCalls)', async () => {
    const store = new EphemeralKekStore('race-five');
    const keys = await Promise.all(
      Array.from({ length: 5 }, () => getOrCreateKek(store)),
    );
    for (const k of keys) expect(k).toBe(keys[0]);
    expect(store.putCalls).toBe(1);
  });

  it('separate ephemeral stores (distinct logicalIds) still get SEPARATE keys (existing behavior)', async () => {
    // Regression guard for the F2 key-separation requirement: the per-account
    // cache KEK must never converge on the engine vault's KEK. Distinct
    // default logicalIds keep their own slots.
    const a = new EphemeralKekStore();
    const b = new EphemeralKekStore();
    const [ka, kb] = await Promise.all([getOrCreateKek(a), getOrCreateKek(b)]);
    expect(ka).not.toBe(kb);
    expect(await getOrCreateKek(a)).toBe(ka);
    expect(await getOrCreateKek(b)).toBe(kb);
    expect(a.putCalls).toBe(1);
    expect(b.putCalls).toBe(1);
  });
});

/* ═══ DIR-NEW-12 — legacy migration with quarantine ════════════════════════ */

describe('DIR-NEW-12 — migrateExisting: migrate + verify, quarantine on failure, report counts', () => {
  it('legacy plaintext records migrate with verified read-back and counts are reported', async () => {
    const base = new MemoryKVStore();
    const vault = new VaultKVStore(base, new EphemeralKekStore());
    await base.set('a', 'plain-a');
    await base.set('b', 'plain-b');
    await vault.set('enc', 'already-encrypted'); // envelope — must be skipped

    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const summary = await vault.migrateExisting();
    const warnText = warnSpy.mock.calls.map((c) => String(c[0])).join('\n');
    warnSpy.mockRestore();

    expect(summary).toEqual({ scanned: 2, migrated: 2, quarantined: 0 });

    // At rest: envelopes, not plaintext.
    const rawA = await base.get('a');
    expect(rawA).toContain('"v":"enc1"');
    expect(rawA).not.toContain('plain-a');
    expect(await vault.get('a')).toBe('plain-a');
    expect(await vault.get('b')).toBe('plain-b');

    // The warn carries counts only — no values, no key names.
    expect(warnText).toContain('scanned=2');
    expect(warnText).toContain('migrated=2');
    expect(warnText).toContain('quarantined=0');
    expect(warnText).not.toContain('plain-a');
    expect(warnText).not.toContain('plain-b');
  });

  it('a failed migration QUARANTINES the record — original key gone, plaintext preserved out of the served namespace', async () => {
    const base = new FaultKVStore();
    const vault = new VaultKVStore(base, new EphemeralKekStore());
    await base.set('session:x', 'TOP-SECRET-PLAINTEXT');

    // Inject: the ENCRYPTED REPLACE write fails — read-back then observes
    // the old plaintext instead of an envelope → verification fails →
    // quarantine.
    base.armFailSet('session:x');
    const summary = await vault.migrateExisting();
    expect(summary).toEqual({ scanned: 1, migrated: 0, quarantined: 1 });

    // The original served key is GONE; the plaintext is preserved under the
    // quarantine namespace (manual recovery possible).
    expect(await base.get('session:x')).toBeNull();
    expect(await base.get('quarantine:session:x')).toBe('TOP-SECRET-PLAINTEXT');

    // Normal get() never serves it — cache-miss semantics, fail-closed.
    expect(await vault.get('session:x')).toBeNull();
    // keys() never enumerates quarantine records.
    expect(await vault.keys()).toEqual([]);
    // …but the quarantine namespace stays reachable for manual recovery.
    expect(await vault.get('quarantine:session:x')).toBe('TOP-SECRET-PLAINTEXT');
  });

  it('verify read-back failure (corrupted write) → quarantine, original deleted', async () => {
    // The write "succeeds" but the persisted envelope no longer decrypts —
    // migration must NOT trust a bare write; only a verified round-trip.
    const base = new CorruptOnReadKVStore();
    const vault = new VaultKVStore(base, new EphemeralKekStore());
    await base.set('k', 'ORIGINAL-PLAINTEXT');
    base.corruptEnvelopeFor.add('k');

    const summary = await vault.migrateExisting();
    expect(summary).toEqual({ scanned: 1, migrated: 0, quarantined: 1 });

    expect(await base.get('k')).toBeNull();
    expect(await base.get('quarantine:k')).toBe('ORIGINAL-PLAINTEXT');
    expect(await vault.get('k')).toBeNull();
  });

  it('quarantined records are out of the served namespace (keys() filtered, re-runs skip them)', async () => {
    const base = new MemoryKVStore();
    const vault = new VaultKVStore(base, new EphemeralKekStore());
    await base.set('good', 'migrates');
    await base.set('quarantine:old', 'manual-recovery-only');

    const summary = await vault.migrateExisting();
    expect(summary).toEqual({ scanned: 1, migrated: 1, quarantined: 0 });
    expect(await vault.keys()).toEqual(['good']); // quarantine key never enumerated

    // Re-run: nothing left to migrate — quarantine records are not re-scanned.
    const again = await vault.migrateExisting();
    expect(again).toEqual({ scanned: 0, migrated: 0, quarantined: 0 });
    expect(await vault.keys()).toEqual(['good']);
  });
});

describe('DIR-NEW-12 — get(): lazy migration is verified and fails closed', () => {
  it('a legacy plaintext hit is lazily migrated (encrypt + verify) and served', async () => {
    const base = new MemoryKVStore();
    const vault = new VaultKVStore(base, new EphemeralKekStore());
    await base.set('legacy', 'lazy-plaintext');

    expect(await vault.get('legacy')).toBe('lazy-plaintext');

    // At rest it is now an envelope — the plaintext is gone from the base
    // store under the served key.
    const raw = await base.get('legacy');
    expect(raw).toContain('"v":"enc1"');
    expect(raw).not.toContain('lazy-plaintext');
    expect(await vault.get('legacy')).toBe('lazy-plaintext'); // stable re-read
  });

  it('a lazy migration failure QUARANTINES the key and returns null (fail-closed, never raw plaintext)', async () => {
    const base = new FaultKVStore();
    const vault = new VaultKVStore(base, new EphemeralKekStore());
    await base.set('legacy-bad', 'LAZY-SECRET');
    base.armFailSet('legacy-bad');

    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    // Fail-closed: raw legacy plaintext is NEVER returned.
    expect(await vault.get('legacy-bad')).toBeNull();
    warnSpy.mockRestore();

    // Moved out of the served namespace, preserved for manual recovery.
    expect(await base.get('legacy-bad')).toBeNull();
    expect(await base.get('quarantine:legacy-bad')).toBe('LAZY-SECRET');

    // Subsequent reads are cache misses (the original key is gone).
    expect(await vault.get('legacy-bad')).toBeNull();
    expect(await vault.keys()).toEqual([]);
  });
});
