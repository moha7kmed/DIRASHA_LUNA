/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * BATCH-6 (F-4 — adversarial review): shared client-IP attribution helpers.
 * Extracted verbatim from src/server/routes/authClassic.ts so EVERY limiter
 * (including the new username-check and push/recover surfaces) uses the same
 * TRUST_PROXY_HOPS-aware attribution instead of raw req.ip.
 */

import type { Request } from 'express';

/**
 * Parse TRUST_PROXY_HOPS (AUTH-07):
 *   - unset → 0 (direct exposure: never trust XFF — use socket address only).
 *   - TRUST_PROXY_HOPS=N (N ≥ 1): the client is the Nth entry from the RIGHT
 *     of the XFF chain (what the outermost trusted hop appended). Everything
 *     further left is client-forgeable and ignored.
 *   - Fail-closed fallbacks: XFF missing, shorter than the trusted-hop count,
 *     or an unparseable env value resolve to req.socket.remoteAddress (the
 *     TCP peer — the edge proxy's own address when behind one) or the shared
 *     'unknown' bucket, so attackers collapse into one shared budget instead
 *     of gaining per-IP buckets.
 */
export function parseTrustedProxyHops(raw: string | undefined): number {
  if (raw === undefined) return 0;
  const trimmed = raw.trim();
  // Base-10 digits only — '0x1', '1e2', '1.5', '-1' all fail closed to 0.
  if (!/^\d+$/.test(trimmed)) return 0;
  return Number(trimmed);
}

/**
 * Pick the client-attributable entry from an XFF chain given N trusted proxy
 * hops: the Nth entry from the RIGHT. Returns null when the chain has no
 * usable entries or fewer entries than trusted hops.
 */
export function xffClientFromRight(xff: string, hops: number): string | null {
  const parts = xff.split(',').map(s => s.trim()).filter(s => s.length > 0);
  if (hops < 1 || parts.length === 0 || hops > parts.length) return null;
  return parts[parts.length - hops];
}

/**
 * Client-attributable IP for rate-limit keys:
 *   - TRUST_PROXY_HOPS unset → socket address only (never trust XFF).
 *   - N hops → Nth-from-right of XFF, fail-closed to the socket address.
 */
export function clientIp(req: Request): string {
  const remote = (req.socket && req.socket.remoteAddress) || '';
  const hops = parseTrustedProxyHops(process.env.TRUST_PROXY_HOPS);
  if (hops < 1) return remote || 'unknown';
  const xff = req.headers['x-forwarded-for'];
  const chain = typeof xff === 'string' ? xff : Array.isArray(xff) ? xff.map(String).join(',') : '';
  const picked = chain.length > 0 ? xffClientFromRight(chain, hops) : null;
  if (picked) return picked;
  return remote || 'unknown';
}