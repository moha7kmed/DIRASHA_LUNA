/**
 * ض6 — Negative TLS tests (owner constraint 6): REAL socket-level rejections.
 *
 * A local TLS server presents a self-signed fixture certificate
 * (tests/fixtures/test-host.pem — SAN IP:127.0.0.1, 30-day validity).
 * Clients connect with the EXACT ssl config shapes buildPgSslConfig produces,
 * and the tests assert the SECURITY PROPERTY itself:
 *   - untrusted CA (self-signed, not in the trust store) → REJECTED
 *   - wrong CA anchor (a different real cert as the pin) → REJECTED
 *   - hostname mismatch (expected host ≠ cert SAN) → REJECTED
 *   - positive control: matching anchor + matching host → CONNECTS
 *     (proves the rig rejects for trust reasons, not rig breakage)
 *
 * Run: npx vitest run tests/db-tls-negative.test.ts
 */

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import tls from 'node:tls';
import fs from 'fs';
import path from 'path';

const FIXTURE_CERT = fs.readFileSync(path.join(__dirname, 'fixtures', 'test-host.pem'));
const FIXTURE_KEY = fs.readFileSync(path.join(__dirname, 'fixtures', 'test-ca.key'));
// A DIFFERENT real certificate used as a wrong anchor (the production Aiven leaf)
const WRONG_ANCHOR_CERT = fs.readFileSync(path.join(__dirname, '..', 'deploy', 'pg-db-cert.pem'));

let server: tls.Server | null = null;
let serverPort = 0;

beforeAll(async () => {
  server = tls.createServer({
    cert: FIXTURE_CERT,
    key: FIXTURE_KEY,
    rejectUnauthorized: false, // the SERVER accepts anything; the CLIENT is under test
  }, (socket) => {
    socket.end('ok\n');
  });
  await new Promise<void>((resolve) => {
    server!.listen(0, '127.0.0.1', () => resolve());
  });
  serverPort = (server.address() as { port: number }).port;
});

afterAll(async () => {
  await new Promise<void>((resolve) => {
    if (!server) return resolve();
    server.close(() => resolve());
    setTimeout(resolve, 500).unref?.();
  });
});

/** One TLS connection attempt with an explicit ssl config; classify the result. */
function tryConnect(sslExtra: Record<string, unknown>, servername: string): Promise<
  { outcome: 'connected' } | { outcome: 'rejected'; reason: string }
> {
  return new Promise((resolve) => {
    const socket = tls.connect({
      host: '127.0.0.1',
      port: serverPort,
      servername,
      rejectUnauthorized: true,
      ...sslExtra,
    } as tls.ConnectionOptions, () => {
      socket.end();
      resolve({ outcome: 'connected' });
    });
    socket.on('error', (err: Error) => {
      resolve({ outcome: 'rejected', reason: String(err.message || err).slice(0, 140) });
    });
  });
}

describe('ض6 — negative TLS tests (real socket rejections)', () => {
  it('untrusted self-signed CA (no anchor) → REJECTED', async () => {
    const r = await tryConnect({ rejectUnauthorized: true }, '127.0.0.1');
    expect(r.outcome).toBe('rejected');
    if (r.outcome === 'rejected') {
      expect(/self-signed|certificate|DEPTH_ZERO/i.test(r.reason)).toBe(true);
    }
  });

  it('wrong CA anchor (production Aiven leaf as pin vs fixture server) → REJECTED', async () => {
    const r = await tryConnect({ ca: WRONG_ANCHOR_CERT, rejectUnauthorized: true }, '127.0.0.1');
    expect(r.outcome).toBe('rejected');
  });

  it('hostname mismatch (servername ≠ cert SAN) → REJECTED even with a trusted anchor', async () => {
    const r = await tryConnect({ ca: FIXTURE_CERT, rejectUnauthorized: true }, 'pg-real.aivencloud.com');
    expect(r.outcome).toBe('rejected');
    if (r.outcome === 'rejected') {
      expect(/hostname|IP address|CN|certificat/i.test(r.reason)).toBe(true);
    }
  });

  it('positive control: matching anchor + matching IP host → CONNECTS', async () => {
    const r = await tryConnect({ ca: FIXTURE_CERT, rejectUnauthorized: true }, '127.0.0.1');
    expect(r.outcome).toBe('connected');
  });
});
