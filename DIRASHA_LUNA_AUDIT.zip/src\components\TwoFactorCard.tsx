import { useEffect, useState } from 'react';
import { ShieldCheck, ShieldOff, Loader2, KeyRound, X } from 'lucide-react';
import { getAccessToken } from '../lib/token_vault';

interface SetupPayload {
  secret: string;
  otpauthUri: string;
  qrDataUrl: string;
}

/**
 * TOTP 2FA settings card (self-contained): status → enroll (QR + confirm code)
 * → disable (password re-auth). Used inside the security settings section.
 */
export function TwoFactorCard() {
  const [enabled, setEnabled] = useState<boolean | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [setup, setSetup] = useState<SetupPayload | null>(null);
  const [code, setCode] = useState('');
  const [password, setPassword] = useState('');
  const [backupCodes, setBackupCodes] = useState<string[] | null>(null);

  const authHeaders = () => ({ 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` });

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch('/api/auth/2fa/status', { headers: authHeaders() });
        const data = await res.json();
        setEnabled(Boolean(data.enabled));
      } catch {
        setEnabled(false);
      }
    })();
  }, []);

  const startSetup = async () => {
    setBusy(true); setError(null);
    try {
      const res = await fetch('/api/auth/2fa/setup', { method: 'POST', headers: authHeaders() });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'تعذر بدء التفعيل.'); return; }
      setSetup(data);
    } finally {
      setBusy(false);
    }
  };

  const confirmEnable = async () => {
    setBusy(true); setError(null);
    try {
      const res = await fetch('/api/auth/2fa/enable', { method: 'POST', headers: authHeaders(), body: JSON.stringify({ code }) });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'الرمز غير صحيح.'); return; }
      setSetup(null); setCode('');
      setEnabled(true);
      // Backup codes shown ONCE (Signal parity) — download/copy now
      if (Array.isArray(data.backupCodes) && data.backupCodes.length) {
        setBackupCodes(data.backupCodes);
      }
    } finally {
      setBusy(false);
    }
  };

  const disable2FA = async () => {
    setBusy(true); setError(null);
    try {
      const res = await fetch('/api/auth/2fa/disable', { method: 'POST', headers: authHeaders(), body: JSON.stringify({ password }) });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'تعذر الإيقاف.'); return; }
      setEnabled(false); setPassword('');
    } finally {
      setBusy(false);
    }
  };

  const inputCls = 'w-full bg-zinc-800/80 border border-white/10 rounded-2xl px-4 py-3 text-white placeholder-white/25 outline-none focus:border-emerald-500/50 transition-colors';

  return (
    <div className="bg-white/[0.03] border border-white/10 rounded-3xl p-5">
      <div className="flex items-center gap-3 mb-1">
        {enabled ? <ShieldCheck className="text-emerald-400" size={20} /> : <ShieldOff className="text-zinc-400" size={20} />}
        <div className="text-white font-bold text-sm">التحقق بخطوتين (TOTP)</div>
        {busy && <Loader2 className="animate-spin text-zinc-400" size={16} />}
      </div>
      <p className="text-zinc-400 text-xs mb-4 leading-relaxed">
        طبقة حماية ثانية عبر تطبيق المصادقة: حتى لو سُرقت كلمة المرور، لن يستطيع أحد الدخول بدون رمز التطبيق.
      </p>
      {enabled === null ? null : !enabled && !setup ? (
        <button onClick={startSetup} disabled={busy} className="w-full py-3 rounded-2xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold text-sm hover:bg-emerald-500/30 transition-colors disabled:opacity-50">
          تفعيل التحقق بخطوتين
        </button>
      ) : null}
      {setup ? (
        <div className="space-y-3">
          <img src={setup.qrDataUrl} alt="QR" className="w-44 h-44 mx-auto rounded-2xl bg-white p-2" />
          <p className="text-[11px] text-zinc-400 text-center">امسح الكود بتطبيق المصادقة ثم أدخل الرمز السداسي</p>
          <p className="text-[10px] text-zinc-500 text-center font-mono break-all">{setup.secret}</p>
          <input value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))} inputMode="numeric" maxLength={6} placeholder="000000" className={inputCls + ' text-center text-xl tracking-[0.5em] font-black'} />
          <button onClick={confirmEnable} disabled={busy || code.length !== 6} className="w-full py-3 rounded-2xl bg-emerald-500 text-black font-black text-sm disabled:opacity-50">
            تأكيد التفعيل
          </button>
        </div>
      ) : null}
      {backupCodes ? (
        <div className="space-y-2 border border-amber-500/40 bg-amber-500/10 rounded-2xl p-4">
          <p className="text-[12px] font-black text-amber-300">🔑 أكواد الاسترداد — تظهر مرة واحدة فقط!</p>
          <p className="text-[10px] text-amber-200/80">احفظها في مكان آمن: كل كود يعمل مرة واحدة بدل رمز التطبيق إذا فُقد جهازك.</p>
          <div className="grid grid-cols-2 gap-1.5">
            {backupCodes.map((c, i) => (
              <code key={i} className="text-[11px] font-mono text-amber-100 bg-black/30 rounded px-2 py-1 text-center">{c}</code>
            ))}
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => { try { navigator.clipboard.writeText(backupCodes.join('\n')); } catch {} }}
              className="flex-1 py-2 rounded-xl bg-white/10 text-amber-100 text-[11px] font-bold"
            >
              نسخ الأكواد
            </button>
            <button
              onClick={() => {
                const blob = new Blob([backupCodes.join('\n')], { type: 'text/plain' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'dirasha-backup-codes.txt';
                a.click();
                URL.revokeObjectURL(url);
              }}
              className="flex-1 py-2 rounded-xl bg-white/10 text-amber-100 text-[11px] font-bold"
            >
              تنزيل كملف
            </button>
          </div>
        </div>
      ) : null}

      {enabled ? (
        <div className="space-y-3">
          <p className="text-emerald-300 text-xs">الحالة: مفعّل ✓ — الدخول يتطلب رمز التطبيق</p>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="كلمة المرور للتأكيد" className={inputCls} dir="ltr" />
          <button onClick={disable2FA} disabled={busy || password.length === 0} className="w-full py-3 rounded-2xl bg-red-500/15 text-red-300 border border-red-500/30 font-bold text-sm hover:bg-red-500/25 transition-colors disabled:opacity-50">
            إيقاف التحقق بخطوتين
          </button>
        </div>
      ) : null}
      {error && <p className="text-red-400 text-xs mt-3">{error}</p>}
    </div>
  );
}