/**
 * Video tuning (FREE quality stack)
 * ---------------------------------
 * - Bounded capture (720p30 ideal, hard max) → encoder never overloads weak devices
 * - degradationPreference 'maintain-framerate' → weak networks drop RESOLUTION,
 *   not frames (fixes stutter)
 * - Explicit video maxBitrate caps (2.5 Mbps)
 * - Codec preference order: hardware-encodable H264/VP8 before VP9/AV1
 */

export function buildVideoConstraints(): { width: { ideal: number; max: number }; height: { ideal: number; max: number }; frameRate: { ideal: number; max: number } } {
  return {
    width: { ideal: 1280, max: 1280 },
    height: { ideal: 720, max: 720 },
    frameRate: { ideal: 30, max: 30 },
  };
}

/** Keep motion smooth: bandwidth pressure lowers resolution, never framerate. */
export async function tuneVideoSender(pc: RTCPeerConnection | null, maxVideoBitrate = 2_500_000): Promise<void> {
  if (!pc) return;
  try {
    const sender = pc.getSenders().find(s => s.track?.kind === 'video');
    if (!sender) return;
    const params = sender.getParameters();
    params.degradationPreference = 'maintain-framerate';
    params.encodings = params.encodings?.length ? params.encodings : [{}];
    params.encodings[0].maxBitrate = maxVideoBitrate;
    params.encodings[0].scaleResolutionDownBy = 1;
    await sender.setParameters(params).catch(() => {});
  } catch { /* non-fatal */ }
}

/** Prefer hardware-encodable codecs (H264/VP8) over VP9/AV1 for CPU relief. */
export function preferEfficientVideoCodecs(pc: RTCPeerConnection | null): void {
  if (!pc) return;
  try {
    for (const transceiver of pc.getTransceivers()) {
      if (transceiver.sender?.track?.kind !== 'video' && transceiver.receiver?.track?.kind !== 'video') continue;
      if (typeof transceiver.setCodecPreferences !== 'function') continue;
      const codecs = RTCRtpSender.getCapabilities('video')?.codecs || [];
      const mimeOrder = ['video/H264', 'video/VP8', 'video/VP9', 'video/AV1'];
      const sorted = [...codecs].sort((a, b) => {
        const ia = mimeOrder.findIndex(m => a.mimeType.toLowerCase() === m.toLowerCase());
        const ib = mimeOrder.findIndex(m => b.mimeType.toLowerCase() === m.toLowerCase());
        return (ia === -1 ? 99 : ia) - (ib === -1 ? 99 : ib);
      });
      if (sorted.length) transceiver.setCodecPreferences(sorted as any);
    }
  } catch { /* non-fatal — negotiation falls back to defaults */ }
}
