/**
 * BATCH-6 BEHAVIORAL TESTS — adversarial-review closures (B5-F1 / B5-F2 / F-9).
 *
 * These are NOT static greps: they execute the actual pure functions and the
 * actual Redis-fallback code path, and every assertion here FAILS on the
 * pre-fix implementation (revert-evidence demonstrated separately in
 * DIRASHA_FINAL_VERIFICATION/REGRESSION_TEST_EVIDENCE notes).
 *
 *   b6-1..b6-10  decideProxyHeaders — exact-allowlist inline decision
 *                (image/png, jpeg, webp, svg+xml, octet-stream, unknown,
 *                manipulated case/params, null, text/plain params).
 *   b6-11..b6-17 validateComment — raw-length-first bound (exactly-500,
 *                over-by-one, padded-short, huge-padded, empty, unicode,
 *                body-limit-scale payload).
 *   b6-18..b6-19 setTempIfAbsent — atomic claim semantics on the memory
 *                fallback path (first claim wins; second claim returns false).
 */
import { describe, it, expect } from 'vitest';
import { decideProxyHeaders } from '../src/server/guards/proxyHeaders.ts';
import { validateComment, MAX_COMMENT_LENGTH } from '../src/server/guards/statusPolicy.ts';
import { RedisClusterClient } from '../src/server/websocket/redis_client.ts';
import { readFileSync } from 'fs';
import path from 'path';

const b6repo = path.resolve(__dirname, '..');
const b6read = (rel: string) => readFileSync(path.join(b6repo, rel), 'utf8');

describe('BATCH-6 B5-F1: decideProxyHeaders (exact-allowlist inline)', () => {
  it('b6-1 image/png served inline with its type', () => {
    expect(decideProxyHeaders('image/png')).toEqual({ contentType: 'image/png', contentDisposition: 'inline' });
  });
  it('b6-2 image/jpeg inline', () => {
    expect(decideProxyHeaders('image/jpeg').contentDisposition).toBe('inline');
  });
  it('b6-3 image/webp inline', () => {
    expect(decideProxyHeaders('image/webp').contentType).toBe('image/webp');
  });
  it('b6-4 image/svg+xml NEVER inline — forced octet-stream + attachment (the B5-F1 blocker case)', () => {
    expect(decideProxyHeaders('image/svg+xml')).toEqual({
      contentType: 'application/octet-stream',
      contentDisposition: 'attachment',
    });
  });
  it('b6-5 application/octet-stream stays a forced download', () => {
    expect(decideProxyHeaders('application/octet-stream').contentDisposition).toBe('attachment');
  });
  it('b6-6 unknown MIME type → forced download', () => {
    expect(decideProxyHeaders('application/x-dirasha-unknown')).toEqual({
      contentType: 'application/octet-stream',
      contentDisposition: 'attachment',
    });
  });
  it('b6-7 manipulated type (UPPERCASE + parameters) normalized then allowlisted', () => {
    expect(decideProxyHeaders('IMAGE/PNG; charset=utf-8')).toEqual({
      contentType: 'image/png',
      contentDisposition: 'inline',
    });
  });
  it('b6-8 null/missing upstream type → forced download', () => {
    expect(decideProxyHeaders(null).contentDisposition).toBe('attachment');
    expect(decideProxyHeaders(undefined).contentType).toBe('application/octet-stream');
  });
  it('b6-9 text/plain with parameters → inline, parameters stripped', () => {
    expect(decideProxyHeaders('text/plain; format=flowed')).toEqual({
      contentType: 'text/plain',
      contentDisposition: 'inline',
    });
  });
  it('b6-10 application/pdf stays inline (legitimate preview)', () => {
    expect(decideProxyHeaders('application/pdf').contentDisposition).toBe('inline');
  });
});

describe('BATCH-6 B5-F2: validateComment (raw-length-first bound)', () => {
  it('b6-11 exactly at the limit → accepted, trimmed', () => {
    const v = validateComment('a'.repeat(500));
    expect(v.ok).toBe(true);
    expect(v.value).toBe('a'.repeat(500));
  });
  it('b6-12 over by one → rejected', () => {
    expect(validateComment('a'.repeat(501)).ok).toBe(false);
  });
  it('b6-13 short padded comment → accepted with trimmed value', () => {
    expect(validateComment('  hello world  ')).toEqual({ ok: true, value: 'hello world' });
  });
  it('b6-14 huge whitespace-padded payload → rejected on RAW length (the B5-F2 bypass case)', () => {
    const padded = 'a'.repeat(500) + ' '.repeat(5_000_000);
    const v = validateComment(padded);
    expect(v.ok).toBe(false);
    expect(v.reason).toBe('too-long');
  });
  it('b6-15 empty and whitespace-only → rejected', () => {
    expect(validateComment('').ok).toBe(false);
    expect(validateComment('     ').ok).toBe(false);
    expect(validateComment(undefined).ok).toBe(false);
    expect(validateComment(12345).ok).toBe(false);
  });
  it('b6-16 Unicode content (Arabic + emoji) accepted and preserved', () => {
    const v = validateComment('مرحبا بالعالم 🌍');
    expect(v.ok).toBe(true);
    expect(v.value).toBe('مرحبا بالعالم 🌍');
  });
  it('b6-17 payload at HTTP-body scale (6M chars) rejected without trim cost', () => {
    const huge = 'x'.repeat(6_000_000);
    expect(validateComment(huge).ok).toBe(false);
  });
  it('b6-17b MAX_COMMENT_LENGTH is exactly 500', () => {
    expect(MAX_COMMENT_LENGTH).toBe(500);
  });
});

describe('BATCH-6 F-9: setTempIfAbsent claim semantics (memory fallback path)', () => {
  it('b6-18 first claim wins, second claim loses (atomic set-if-absent)', async () => {
    const engine = new RedisClusterClient();
    const key = `b6-test-${Date.now()}-${Math.random()}`;
    const first = await engine.setTempIfAbsent(key, 'processed', 60);
    const second = await engine.setTempIfAbsent(key, 'processed', 60);
    expect(first).toBe(true);
    expect(second).toBe(false);
  });
  it('b6-19 distinct keys claim independently', async () => {
    const engine = new RedisClusterClient();
    const base = `b6-distinct-${Date.now()}-${Math.random()}`;
    expect(await engine.setTempIfAbsent(`${base}-a`, 'v', 60)).toBe(true);
    expect(await engine.setTempIfAbsent(`${base}-b`, 'v', 60)).toBe(true);
    expect(await engine.setTempIfAbsent(`${base}-a`, 'v2', 60)).toBe(false);
  });
});

// BATCH-6 F-13: decidePushEndpointAllowed — adversarial endpoint cases
import { decidePushEndpointAllowed } from '../src/server/guards/pushEndpoint.ts';

describe('BATCH-6 F-13: decidePushEndpointAllowed', () => {
  it('b6-20 real vendor endpoints allowed', () => {
    expect(decidePushEndpointAllowed('https://fcm.googleapis.com/fcm/send/abc').allowed).toBe(true);
    expect(decidePushEndpointAllowed('https://push.services.mozilla.com/wpush/v2/xyz').allowed).toBe(true);
    expect(decidePushEndpointAllowed('https://push.apple.com/3/device/abc').allowed).toBe(true);
    expect(decidePushEndpointAllowed('https://abc123.notify.windows.com/token').allowed).toBe(true);
  });
  it('b6-21 attacker lookalikes rejected', () => {
    expect(decidePushEndpointAllowed('https://evilfcm.googleapis.com/x').allowed).toBe(false);
    expect(decidePushEndpointAllowed('https://fcm.googleapis.com.evil.net/x').allowed).toBe(false);
    expect(decidePushEndpointAllowed('https://fcm.googleapis.com.attacker.io/x').allowed).toBe(false);
    expect(decidePushEndpointAllowed('https://push.services.mozilla.com.evil.io/x').allowed).toBe(false);
  });
  it('b6-22 non-https rejected', () => {
    expect(decidePushEndpointAllowed('http://fcm.googleapis.com/x').allowed).toBe(false);
  });
  it('b6-23 userinfo / ports / IDN fail closed', () => {
    expect(decidePushEndpointAllowed('https://user:pass@fcm.googleapis.com/x').allowed).toBe(false);
    expect(decidePushEndpointAllowed('https://fcm.googleapis.com:8080/x').allowed).toBe(false);
    expect(decidePushEndpointAllowed('https://xn--fcm-gmail-8za.com/x').allowed).toBe(false);
  });
  it('b6-24 unparseable / missing / oversized rejected', () => {
    expect(decidePushEndpointAllowed('not-a-url').allowed).toBe(false);
    expect(decidePushEndpointAllowed(undefined).allowed).toBe(false);
    expect(decidePushEndpointAllowed('https://fcm.googleapis.com/' + 'x'.repeat(3000)).allowed).toBe(false);
  });
});

// BATCH-7b wiring tests (Agent-A round-2 closures) — negative asserts included
describe('BATCH-7b wiring (NEW-A fixes)', () => {
  it('b7-1 wipe limiter keyed on hardened clientIp (NEW-A-09 — prior claim was false)', () => {
    const srv = b6read('server.ts');
    expect(srv).toMatch(/const wipeRlKey = clientIp\(req\);/);
    expect(srv).not.toMatch(/const wipeRlKey = req\.ip/);
  });
  it('b7-2 status duration uses the bounded value everywhere (NEW-A-07 dead-store recurrence fixed)', () => {
    const st = b6read('src/server/routes/status.ts');
    expect(st).toMatch(/const duration = boundedDuration;/);
    expect(st).not.toMatch(/const duration = duration_hours \|\| 24;/);
  });
  it('b7-3 sessions/check ownership gate present (NEW-A-06)', () => {
    const srv = b6read('server.ts');
    expect(srv).toMatch(/session\.userId !== req\.user!\.userId/);
  });
  it('b7-4 account deletion requires password step-up (NEW-A-05)', () => {
    const srv = b6read('server.ts');
    expect(srv).toMatch(/verifySecret\(String\(deletePassword \|\| ''\), secrets\.passwordHash\)/);
    expect(srv).toMatch(/account_deleted/);
  });
  it('b7-5 sweep re-runs the full send policy (NEW-A-01) + epoch fail-closed (NEW-A-02)', () => {
    const mj = b6read('src/server/services/moderation_jobs.ts');
    expect(mj).toMatch(/assertCanSendMessage\(db, message\.senderId, chatId/);
    expect(mj).toMatch(/composeMv == null \|\| Number\(composeMv\) !== Number\(currentMv\)/);
  });
  it('b7-6 completeUserProfile dead bypass removed (ADV-01 residue)', () => {
    const db = b6read('src/server/database.ts');
    // The name survives only inside the removal-explanation comment.
    expect(db).not.toMatch(/public async completeUserProfile/);
    expect(db).toMatch(/completeUserProfile REMOVED/);
  });

});
