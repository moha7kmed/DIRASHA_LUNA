# API SECURITY MATRIX — تدقيق أمني كامل لواجهة Dirasha

> تاريخ التدقيق: 2026-11-17 — تدقيق قراءة فقط (read-only) بواسطة وكيل تدقيق أمني مستقل.
> المنهجية: كل بند مصحوب بـ file:line + مقتطف + تصنيف (VERIFIED / PARTIALLY VERIFIED / UNVERIFIED / NOT IMPLEMENTED / FAILED).
> نطاق الملفات: `server.ts` (3993 سطر), `src/server/routes/*.ts` (8 ملفات), `src/server/websocket/ws_server.ts`, `src/server/guards/sendGate.ts`, `src/server/services/*`.
> الاختبارات: `npm test` أخضر قبل التدقيق وبعده (15 ملف، 210 اختبار — PASSED).

---

## 1) ملخص تنفيذي (أهم النتائج مرتبة بالخطورة)

| # | الخطورة | النتيجة | الموقع | التصنيف |
|---|---------|---------|--------|---------|
| F1 | **MEDIUM** | تجاوز سياسة الإرسال عبر جسر المزامنة: `POST /api/chats/:chatId/messages/sync` يتحقق من العضوية فقط ولا يستدعي `assertCanSendMessage` — مستخدم muted أو مقيد بـ slow-mode أو محظور من طرف DM يمكنه النشر عبر هذا المسار | server.ts:2494-2593 | VERIFIED |
| F2 | **MEDIUM** | allowlist مرفقات الرسائل يعتمد `x-forwarded-host` من طلب **المرسِل نفسه** عند فحص same-origin (أول إدخال) — إذا لم يقم الـ edge proxy بالكتابة فوق الترويسة يستطيع المرسِل تمرير أي `https://evil.example` | server.ts:141-147 | PARTIALLY VERIFIED (لا يمكن التحقق الحي دون إرسال رسالة — تعديل حالة) |
| F3 | **MEDIUM** | `GET /api/users` يُرجع دليل المستخدمين **كاملاً** بدون pagination وبلا rate limit (بينما `/api/users/search` مقيّد بـ 60/min) — ناقل enumeration قابل للكشط | server.ts:1422-1492 | VERIFIED |
| F4 | **MEDIUM** | ترقية WebSocket تقبل access token كامل (15 دقيقة) عبر query param `?token=` بينما مسار REST يقصر توكنات الـ URL على media tokens فقط — التوكن يتسرب إلى سجلات البروكسي | ws_server.ts:196-222 مقابل server.ts:329-349 | VERIFIED |
| F5 | **LOW/MEDIUM** | تسريب رسائل الخطأ الداخلية: **88 موضعاً** في server.ts يعيد `res.status(500).json({ error: err.message })` — قد يكشف تفاصيل الـ driver/الاستعلام (لا full stack) | server.ts (عام)، أمثلة :443، :647، :1018 | VERIFIED (النمط)، PARTIALLY VERIFIED (الأثر الفعلي) |
| F6 | **LOW** | `GET /api/auth/sessions/check` بلا فحص ملكية: أي مستخدم مصادق يستطيع الاستعلام عن **جلسة أي مستخدم آخر** ومعرفة هل هي revoked | server.ts:1071-1085 | VERIFIED |
| F7 | **LOW** | `GET /api/admin/system/api-keys` يعيد `key_value` **غير مقنّع** عندما يكون طول المفتاح ≤ 15 حرفاً | src/server/routes/apiKeys.ts:17-20 | VERIFIED (admin-only) |
| F8 | **LOW** | `POST /api/moderation/users/:userId/warnings` مسجّل **مرتين** (server.ts:3296 و server.ts:3512) — الأول يفوز دائماً؛ الثاني dead code يكشف انقسام مساهمات | server.ts:3296, 3512 | VERIFIED |
| F9 | **LOW** | مسارات Statuses: `POST /:id/view`, `/:id/like`, `GET /:id/comments`, `POST /:id/comments` بلا فحص visibility للستاتس — مستخدم مصادق يتفاعل/يقرأ تعليقات ستاتس مخفي عنه (nobody/contacts) | src/server/routes/status.ts:118-251 | VERIFIED |
| F10 | **LOW** | `POST /api/admin/reset-database`: مقارنة `x-admin-secret === adminSecret` ليست timing-safe، وبلا rate limit خاص؛ الحماية تعتمد علىBearer role أو secret | server.ts:3673-3706 | VERIFIED (حارس موجود)، PARTIALLY VERIFIED (الأثر) |
| F11 | **INFO** | تعديل محتوى الرسالة `PUT /api/messages/:messageId` لا يطبّق سقف 8000 حرف المطبق على الإرسال | server.ts:2829-2875 مقابل :2621 | VERIFIED |
| F12 | **INFO** | `POST /api/chats` + `PUT /api/users/me` وغيرها يستخدمون ليميتر in-memory محلي `restLimit` (per-process) وليس الـ DistributedRateLimiter — على أكثر من instance الحد قابل للتجاوز بمعامل عدد الـ instances | server.ts:55-69 مقابل rate_limiter.ts | VERIFIED |
| F13 | **INFO** | كلمات مرور/أسرار التطوير المضمّنة في الكود معطّلة في الإنتاج (JWT_SECRET/COOKIE_SECRET تُرمى FATAL بدون env) — إيجابي | auth.ts:19-23, server.ts:228-232 | VERIFIED |
| F14 | **POSITIVE** | جدول معدلات موزع حقيقي (Redis Lua atomic) بفشل مغلق fail-closed للقواعد الحرجة — أُثبت حياً في p6 | rate_limiter.ts:89-98, 194-227 | VERIFIED |

---

## 2) البنية الأمنية العامة (middleware chain)

الترتيب الفعلي في `startServer()` (server.ts:197-396):

1. `compression()` — server.ts:223.
2. `express.json({ limit: '5mb' })` + `express.urlencoded({ limit: '5mb' })` — server.ts:224-225 — **سقف حجم الطلب 5MB** (VERIFIED)؛ إطارات WS مقيدة بـ `maxPayload: 128 KiB` (ws_server.ts:161) (VERIFIED).
3. `cookieParser(COOKIE_SECRET)` — إنتاج بدون `COOKIE_SECRET` يرمي FATAL (server.ts:228-232) (VERIFIED).
4. Security headers: CSP صارم (بدون unsafe-inline سكربت في الإنتاج)، `X-Content-Type-Options`, `Referrer-Policy`, HSTS, `Permissions-Policy`, XFO — server.ts:250-276 (VERIFIED).
5. CORS allowlist من `ALLOWED_ORIGINS` — بدون الـ env يُسمح فقط لـ localhost — server.ts:239-248, 278-285 (VERIFIED).
6. **CSRF defense-in-depth**: فحص Origin/Referer لكل `/api/*` غير GET/HEAD/OPTIONS؛ origin="null" مرفوض — server.ts:291-304 (VERIFIED).
7. no-store على /api/* — server.ts:307-312 (VERIFIED).
8. `requireAuth` (server.ts:322-369): Bearer أو `?access_token=` (URL tokens = media-scoped GET-only، server.ts:347-349)، فحص ban مع رفع تلقائي للـ ban المنتهي (VERIFIED).
9. `requireAdmin` (server.ts:372-386): username في `ADMIN_USERNAMES` env (VERIFIED).
10. `requireModerator` (server.ts:2997-3028): role admin/developer أو ADMIN_USERNAMES، مع ترقية تلقائية لـ developer (VERIFIED).
11. ملاحظة: `app.set('trust proxy')` **غير مستدعى إطلاقاً** (grep: 0 نتائج)؛ `clientIp()` يقرأ أول إدخال من `x-forwarded-for` يدوياً (authClassic.ts:48-53) — صحيح خلف بروكسي Render لكن إدخال XFF الأول **spoofable** إذا لم يكتبه الـ edge فوقه (PARTIALLY VERIFIED).

---

## 3) جدول نقاط النهاية الكاملة (بدون أخذ عينات)

اختصارات: AUTH = requireAuth، ADMIN = requireAdmin، MOD = requireModerator، PUB = بلا توكن، MEM = فحص عضوية chat_members، OWN = فحص ملكية، RL = rate limit (اسم القاعدة من rate_limiter.ts أو restLimit محلي).

### 3.1 Admin Dashboard (server.ts:422-487) — كلها ADMIN

| Endpoint | الغرض | Authorization | المدخلات | المخرجات | RL | ملاحظات أمنية |
|---|---|---|---|---|---|---|
| GET /api/admin/dashboard/overview (:422) | إحصاءات عامة | ADMIN | — | JSON stats | — | نظيف |
| GET /api/admin/dashboard/performance (:426) | أداء | ADMIN | — | JSON | — | نظيف |
| GET /api/admin/dashboard/queue (:430) | طابور الكتابة | ADMIN | — | JSON | — | نظيف |
| GET /api/admin/dashboard/errors (:434) | أخطاء | ADMIN | — | JSON | — | نظيف |
| GET /api/admin/dashboard/database (:438) | حالة DB | ADMIN | — | JSON | — | يرجع `e.message` عند 500 (:443) — F5 |
| GET /api/admin/dashboard/redis (:447) | حالة Redis | ADMIN | — | JSON | — | نفس الملاحظة (:452) |
| GET /api/admin/dashboard/analytics (:456) | تحليلات | ADMIN | — | JSON | — | نفس الملاحظة (:461) |
| GET /api/admin/dashboard/health (:465) | صحة | ADMIN | — | JSON | — | نظيف |
| GET /api/admin/dashboard/logs (:469) | سجل نشاط | ADMIN | — | JSON | — | نظيف |
| GET /api/admin/dashboard/search (:473) | بحث كيانات | ADMIN | `?q` | JSON | — | q يُمرر لـ `queryEntitiesSearch(String(q))` — String() يمنع حقن نوع؛ لا معامل SQL مباشر هنا |
| POST /api/admin/dashboard/log-activity (:483) | تسجيل نشاط إداري | ADMIN | {action,category,details} | {success} | — | بدون تحقق أطوال — تخزين بحرية في الذاكرة |

### 3.2 عامة / بنية تحتية

| Endpoint | الغرض | AUTH | المدخلات | المخرجات | RL | ملاحظات |
|---|---|---|---|---|---|---|
| GET /service-worker.js (:494) | ملف SW | PUB | — | static | — | sendFile مسار ثابت — لا path traversal (VERIFIED) |
| GET /manifest.json (:501) | PWA manifest | PUB | — | static | — | نظيف |
| GET /.well-known/security.txt (:510) | RFC 9116 | PUB | — | text | — | نظيف |
| GET /security (:516) | صفحة الإفصاح | PUB | — | 302 | — | نظيف |
| GET /api/push/vapid-key (:521) | مفتاح VAPID العام | PUB | — | {publicKey} | — | مفتاح عام بطبيعته — نظيف |
| POST /api/push/subscribe (:526) | تسجيل push endpoint | AUTH | {subscription} | {success} | — | **لا تحقق أن endpoint belongs لمستخدم واحد**؛ endpoint هو PK — اشتراك مستخدم فوق endpoint مستخدم آخر يستبدله (PARTIALLY VERIFIED — يعتمد على upsert الداخلية) |
| GET /api/health (:547) | health probe | PUB | — | {status,db} | — | لا يكشف أسراراً — يكشف نوع backend فقط (مقبول) |
| GET /api/debug/queue (:564) | حالة الطابور | ADMIN | — | JSON | — | يعرض عناصر الطابور الحية (محتوى رسائل مؤقتة) — admin-only مقبول |
| POST /api/debug/simulate-db-failure (:574) | محاكاة فشل DB | ADMIN | {enable} | {success} | — | **endpoint تدميري محتمل في الإنتاج** (يُطفئ المتانة) — يُفضل تعطيله بـ NODE_ENV (PARTIALLY VERIFIED) |
| GET * (:3969) | SPA fallback | PUB | — | index.html | — | إنتاج فقط؛ لا يخدم /api (مسار /api/* يُعاد 404 قبلها، :3951-3953) |

### 3.3 المصادقة — authClassic.ts + server.ts

| Endpoint | الغرض | AUTH | المدخلات | RL | ملاحظات |
|---|---|---|---|---|---|
| POST /api/auth/register (authClassic.ts:137) | إنشاء حساب | PUB | {displayName,username,password,pin} | `auth:register:ip` 10/h/IP | scrypt+pepper (password.ts)، HIBP k-anonymity (:96-118)، فحص اسم محجوز 409+suggestions؛ يعيد deviceKey مرة واحدة (:227). VERIFIED جيد. ملاحظة: يسمح بـ enumeration جزئي عبر رسائل 409 المختلفة (مقصود UX) |
| POST /api/auth/login (authClassic.ts:237) | دخول كلمة مرور | PUB | {username,password,deviceKey?,totpCode?} | `auth:login:ip` 30/10min/IP | dummy hash ضد timing enumeration (:74-79, :260-263)، قفل حساب تدريجي 423 (:254-257)، TOTP + backup codes أحادية الاستخدام (:288-331)، إعادة hash ترقية v1→v2 (:282-284). **refresh token يعاد في الجسم + cookie SameSite=None** (:127-134) — مقصود لبيئة iframe؛ SameSite=None يعتمد كلياً على فحص Origin (:291-304). VERIFIED |
| POST /api/auth/recover/request (:385) | طلب استرجاع | PUB | {username,pin,deviceKey} | `auth:recover:ip` 8/h + `auth:recover:user` 5/30min | عاملان (PIN + deviceKey) رسالة فشل موحدة — لا oracle (VERIFIED) |
| POST /api/auth/recover/reset (:428) | حرق resetToken | PUB | {username,resetToken,newPassword} | — (يعتمد صعوبة التوكن 600s) | يلغي كل الجلسات + يصفّر 2FA (:460-461). VERIFIED |
| POST /api/auth/password/change (:481) | تغيير كلمة مرور | AUTH | {currentPassword,newPassword} | `auth:passwordchange:user` 5/h | يلغي بقية الجلسات + WS event (:521-541). VERIFIED |
| POST /api/auth/pin/change (:558) | تغيير PIN | AUTH | {currentPin,newPin} | — | **بلا rate limit** — brute-force PIN عبر هذا المسار محدود فقط بـ scrypt؛ PIN ضعيف محتمل (PARTIALLY VERIFIED — يعتمد validatePin) |
| POST /api/auth/sessions/revoke (:596) | إبطال جلسة | AUTH | {sessionId} | `auth:sessions:revoke` 10/h | فحص ملكية داخل AuthService.revokeSessionById (auth.ts:242-259) — short-id يُحل من جلسات المستخدم نفسه فقط (VERIFIED) |
| GET /api/auth/2fa/status (:636) | حالة 2FA | AUTH | — | — | نظيف |
| POST /api/auth/2fa/setup (:646) | بدء TOTP | AUTH | — | — | سر مشفر بالذاكرة 10min، QR — نظيف |
| POST /api/auth/2fa/enable (:663) | تأكيد TOTP | AUTH | {code} | — | إثبات ملكية قبل التفعيل + 10 backup codes hashed (VERIFIED) |
| POST /api/auth/2fa/disable (:693) | إيقاف TOTP | AUTH | {password} | — | يتطلب كلمة المرور (VERIFIED) |
| GET /api/auth/check-username (server.ts:585) | توفر اسم المستخدم | PUB | ?username | — | **enumeration مقصود** (فحص التوفر) — يكشف وجود أسماء؛ مقبول كمنتج لكن يجعل anti-enumeration في login أقل قيمة (INFO) |
| GET /api/auth/eval-display-name (:652) | تقييم اسم العرض | PUB | ?name | — | نظيف (دالة نقية) |
| POST /api/auth/refresh (server.ts:665) | دوران التوكن | PUB (refresh token) | cookie/body | restLimit محلي 60/10min IP+username (:670) | كشف إعادة استخدام refresh → إلغاء كل الجلسات (auth.ts:140-144) (VERIFIED)؛ cookie SameSite=None (:708-713) |
| POST /api/auth/logout (server.ts:727) | خروج | PUB | cookie | — | يبطل الجلسة + Clear-Site-Data (:735) (VERIFIED) |
| GET /api/auth/me (:743) | المستخدم الحالي | AUTH | — | — | نظيف |
| GET /api/media-token (:754) | توكن وسائط 120s | AUTH | — | — | media-scoped GET-only عند الاستخدام من URL (server.ts:347-349 + auth.ts:62-76) (VERIFIED) |
| GET /api/auth/sessions (:1023) | قائمة الجلسات | AUTH | — | `auth:sessions:list` 30/min | تنقية حقول صارمة، refresh tokens لا تخرج أبداً (:1039-1063) (VERIFIED) |
| GET /api/auth/sessions/check (:1071) | حالة revocation | AUTH | ?sessionId | — | **F6: بلا فحص ملكية** — oracle revocation لأي sessionId (VERIFIED) |
| DELETE /api/auth/sessions/:sessionId (:1088) | إبطال جلسة | AUTH | param | — | فحص ملكية `session.userId === userId` (:1094) (VERIFIED) |
| POST /api/auth/sessions/revoke-others (:1112) | إبطال الجماعي | AUTH | header x-session-id | `auth:sessions:revoke-others` 5/h | VERIFIED |
| GET /api/users/me (:765) | البروفايل | AUTH | — | — | دمج settings — نظيف |
| PUT /api/users/me (:826) | تحديث البروفايل | AUTH | أي JSON | restLimit 10/h | **Mass-assignment guard** يسقط role/isBanned/mutedUntil/... (:842-848) (VERIFIED إيجابي)؛ لكن أي مفاتيح أخرى غير معروفة تُمرر لـ `db.updateUser` — يعتمد على allowlist داخل updateUser (database.ts:2790+ allowedKeys) (VERIFIED — الحماية النهائية عند طبقة DB) |
| DELETE /api/users/me (:1144) | حذف الحساب | AUTH | — | — | **بلا تأكيد كلمة مرور/PIN** — حذف حساب بسرقة access token 15 دقيقة فقط (PARTIALLY VERIFIED خطر) |
| GET /api/users/me/export (:1162) | تصدير البيانات | AUTH | — | — | يصدر رسائل آخر 200 لكل محادثة — scoped للمستخدم (VERIFIED) |
| GET /api/settings (:1190) / PUT /api/settings (:1199) | الإعدادات | AUTH | JSON | — | PUT يخزن `req.body` كاملاً في JSONB — **بلا schema validation** (حقول غريبة تُخزن؛ تُقرأ لاحقاً كإعدادات خصوصية — خطورة منخفضة لأن القيم تُستخدم بنمط string) (VERIFIED مع ملاحظة) |
| PUT /api/users/me/username (:1217) | تغيير الاسم | AUTH | {newUsername} | `username:change` 3/h | تحقق+حجز+audit (VERIFIED) |

### 3.4 المستخدمون / الاتصالات / الحظر

| Endpoint | AUTH | Ownership/Authorization | RL | ملاحظات |
|---|---|---|---|---|
| GET /api/calls (:1250) | AUTH | user-scoped (getCallLog(userId)) | — | نظيف |
| DELETE /api/calls (:1264) | AUTH | user-scoped | — | نظيف |
| GET /api/users/search (:1274) | AUTH | searchVisibility privacy filtering (:1288-1297) | `search:user` 60/min | يعيد activeChatsCount لكل نتيجة (:1332) — تسريب مقياس اجتماعي طفيف (INFO) |
| GET /api/users (:1422) | AUTH | privacy filtering | **بلا RL** — F3 | يرجع **الدليل كاملاً** — VERIFIED |
| GET/POST/DELETE /api/contacts (:1346,:1357,:1373) | AUTH | user-scoped (user_id=$1) | — | POST يقبل أي contactId بدون إذن الطرف الآخر — إضافة نفسك لجهات اتصال شخص آخر تسمح لك برؤية lastSeen حسب سياساته؟ لا — الفحص يقرأ جهات اتصال **الآخر** (getContacts(u.id)) لذا الإضافة الأحادية لا تكسر الخصوصية (VERIFIED) |
| GET/POST/DELETE /api/blocks (:1384,:1395,:1411) | AUTH | user-scoped | — | نظيف |

### 3.5 المحادثات والمجموعات والقنوات

| Endpoint | AUTH | Authorization | RL | ملاحظات |
|---|---|---|---|---|
| GET /api/chats (:1495) | AUTH | user-scoped (getOptimizedChatsForUser) | — | نظيف |
| POST /api/chats (:1525) | AUTH | مالك الإنشاء + قيود privacy (blocks, allowDirectMessages, allowGroupInvites :1584-1629) | restLimit 10/h (:1534) | VERIFIED |
| PUT /api/chats/:chatId/info (:1730) | AUTH | requireGroupAdmin (عضوية) + whoCanEditInfo + adminCan(editInfo) | — | VERIFIED |
| PUT /api/chats/:chatId/permissions (:1759) | AUTH | عضوية + isGroupAdmin | — | VERIFIED |
| GET /api/chats/:chatId/group (:1782) | AUTH | عضوية؛ inviteCode يُخفى عن غير المشرفين (:1787) | — | VERIFIED |
| POST /api/chats/:chatId/members (:1799) | AUTH | عضوية + adminCan(addMembers) + فحص banned (:1811) | — | VERIFIED |
| DELETE /api/chats/:chatId/members/:userId (:1829) | AUTH | self أو admin؛ منع إزالة المالك (:1839) | — | VERIFIED |
| POST /api/chats/:chatId/promote (:1855) | AUTH | owner فقط (:1859) | — | VERIFIED |
| POST /api/chats/:chatId/leave (:1879) | AUTH | عضوية؛ نقل الملكية عند مغادرة المالك (:1890-1894) | — | VERIFIED |
| DELETE /api/chats/:chatId (:1906) | AUTH | owner فقط (:1910) | — | VERIFIED |
| POST /api/chats/:chatId/invite (:1921) | AUTH | isGroupAdmin | — | invite code عشوائي 6 bytes base64url (:1930) — 48 bit مساحة — مقبول مع usage limit |
| POST /api/chats/join (:1954) | AUTH | code lookup + expiry + blocks + group-ban + usage limit (:1968-1984) | — | VERIFIED |
| GET /api/chats/:chatId/join-requests (:2012) | AUTH | isGroupAdmin | — | VERIFIED |
| POST /api/chats/:chatId/join-requests/:userId (:2029) | AUTH | isGroupAdmin | — | VERIFIED |
| GET /api/chats/:chatId/subscribers/count (:2060) | AUTH | عضوية (:2065) | — | VERIFIED |
| PUT /api/chats/:chatId/disappearing (:2076) | AUTH | **عضوية فقط** (requireGroupAdmin لا يفحص adminship — مقصود حسب التعليق "members may set for their chats" :2075) | — | VERIFIED (بقرار تصميمي) |
| PUT /api/chats/:chatId/slow-mode (:2094) | AUTH | isGroupAdmin | — | VERIFIED |
| POST /api/chats/:chatId/ban / unban (:2114,:2137) | AUTH | isGroupAdmin + منع حظر المالك (:2123) | — | VERIFIED |
| POST /api/chats/:chatId/restrict (:2153) | AUTH | isGroupAdmin | — | **minutes غير مقيّد** — `Number(minutes)` قد يكون NaN→ -1 دائم أو رقم ضخم (INFO) |
| PUT /api/chats/:chatId/protected (:2175) | AUTH | isGroupAdmin | — | VERIFIED |
| GET /api/chats/:chatId/past-members (:2192) | AUTH | isGroupAdmin | — | VERIFIED |
| POST /api/chats/:chatId/admin-rights (:2206) | AUTH | owner فقط | — | VERIFIED |
| POST /api/chats/:chatId/clear-me (:2229) | AUTH | عضوية (:2234) | — | حلقة up-to-10000 تحديث متسلسل — أداء/DoS ذاتي فقط (INFO) |
| GET /api/chats/:chatId/stats (:2253) | AUTH | isGroupAdmin | — | VERIFIED |

### 3.6 الرسائل

| Endpoint | AUTH | Authorization | RL | ملاحظات |
|---|---|---|---|---|
| GET /api/telemetry/messages/:messageId (:2283) | AUTH | عضوية دردشة الرسالة (:2288-2295) | — | SQL معاملات مباشرة `WHERE message_id = $1` (:2299-2306) (VERIFIED لا حقن) |
| GET /api/chats/:chatId/messages (:2318) | AUTH | عضوية + auto-provision للـ one_to_one فقط إن كنت الطرفين (:2326-2343) | — | stripped deletedFor (:2349-2353) (VERIFIED) |
| GET /api/chats/:chatId/messages/search (:2395) | AUTH | عضوية | restLimit 60/min | ILIKE معامل + escapeLikePattern (database.ts:5295-5312) (VERIFIED لا حقن) |
| GET /api/search/messages (:2437) | AUTH | **في SQL**: `JOIN chat_members ... user_id = $1` (database.ts:5343-5352) | restLimit 60/min | VERIFIED |
| GET /api/chats/:chatId/media (:2460) | AUTH | عضوية | restLimit 60/min | VERIFIED |
| POST /api/chats/:chatId/messages/sync (:2494) | AUTH | عضوية + `senderId !== currentUserId` مرفوض (:2537-2540) + ملكية التحديث (:2546-2548) | — | **F1: بلا assertCanSendMessage** — bypass لـ mute/slow-mode/whoCanSend/blocks/DM-policy؛ يقبل id و createdAt من العميل (VERIFIED) |
| POST /api/chats/:chatId/messages (:2596) | AUTH | assertCanSendMessage كامل (:2653) + allowlist مرفقات (:2628) + scheduleAt validation (:2604) + سقف 8000 (:2621) | — | VERIFIED (إلا F2 allowlist) |
| POST /api/messages (:2735) | AUTH | assertCanSendMessage كامل (:2779) | — | VERIFIED |
| PUT /api/messages/:messageId (:2829) | AUTH | `message.senderId !== userId` → 403 (:2840-2842) | — | F11: بلا سقف طول للتعديل |
| POST /api/messages/:messageId/delete-everyone (:2878) | AUTH | المرسِل أو moderator أو مشرف مجموعة بصلاحية deleteMessages (:2889-2902) | — | نسخة vault قبل الحذف (:2905-2915) (VERIFIED) |
| POST /api/messages/:messageId/delete-me (:2959) | AUTH | عضوية (:2970-2973) | — | VERIFIED |
| POST /api/messages/:messageId/react (:3709) | AUTH | عضوية (:3721-3724) | — | emoji بلا قائمة بيضاء — يخزن أي string حتى 32 حرف (عمود reaction_emoji VARCHAR(32)) — INFO |
| POST /api/messages/:messageId/poll-vote (:3768) | AUTH | عضوية (:3791-3794) | restLimit 30/min | VERIFIED |
| POST /api/messages/:messageId/star (:3823) | AUTH | عضوية (:3834-3837) | — | VERIFIED |
| POST /api/messages/:messageId/pin (:3870) | AUTH | عضوية + adminCan(pinMessages) للمجموعات (:3889-3891) | — | VERIFIED |
| GET /api/messages/starred (:3920) | AUTH | user-scoped SQL (database.ts:5120-5121) | — | VERIFIED |

### 3.7 الإشراف (Moderation) — كلها MOD إلا الأولى

| Endpoint | AUTH | ملاحظات |
|---|---|---|
| POST /api/moderation/reports (:3033) | AUTH + restLimit 5/h + Redis ban ساعة عند 10 تقارير/10min (:3067-3087) | targetUser يتحقق وجوداً؛ targetMessage يتحقق وجوداً فقط — **بلا فحص عضوية**: يمكن الإبلاغ عن رسالة من دردشة لا تنتسب لها (الإبلاغ مسموح تصميمياً) (INFO) |
| GET /api/moderation/reports/:reportId (:3165) | MOD | نظيف |
| GET /api/moderation/reports (:3179) | MOD | limit/offset أعداد صحيحة عبر parseInt (VERIFIED) |
| POST /api/moderation/reports/:reportId/status (:3194) | MOD | status enum checked (VERIFIED) |
| GET/POST /api/moderation/users/:userId/enforcement|reports|notes|warnings (:3240-3323) | MOD | نظيف |
| DELETE /api/moderation/users/:userId/warnings (:3325) | MOD | نظيف |
| GET /api/moderation/vault (:3340) + /:messageId (:3353) | MOD | vault = نسخ الرسائل المحذوفة — الوصول MOD فقط (VERIFIED) |
| GET /api/moderation/users (:3368) + /stats (:3378) | MOD | نظيف |
| POST /api/moderation/users/:userId/mute|unmute|ban|unban (:3388,:3437,:3467,:3542) | MOD | durationHours مدقق؛ **بلا منع مشرف من كتم/حظر مشرف آخر أو نفسه** (الـ role endpoint يمنع self فقط) (INFO) |
| POST /api/moderation/users/:userId/warnings (:3296 + مكرر :3512) | MOD | F8 |
| GET /api/moderation/audit-logs (:3567) | MOD | نظيف |
| POST /api/moderation/users/:userId/role (:3588) | MOD | درع تصعيد: self ممنوع (:3595)؛ admin/developer تتطلب ADMIN_USERNAMES (:3619-3624)؛ سقف rank (:3629-3637) — VERIFIED إيجابي |
| POST /api/admin/reset-database (:3673) | مخصص: Bearer role admin/developer **أو** `x-admin-secret === ADMIN_WIPE_SECRET` (:3678-3693) | F10 — مسار يدمر كل البيانات؛ الحارس موجود لكن المقارنة غير timing-safe وبلا RL مخصص |

### 3.8 E2EE (routes/e2ee.ts) — routes حديثة تحت المجهر

| Endpoint | AUTH | RL | المدخلات | التحقق | ملاحظات |
|---|---|---|---|---|---|
| POST /api/e2ee/register (:183) | AUTH | `e2ee:register` 30/h | مفاتيح عامة + deviceId + OPKs ≤200 | base64 std pad صارم؛ X25519=32b، Ed25519 sig=64b، ML-KEM-768=1184b (:36-72)؛ advisory lock ضد سباق سقف الأجهزة (:245)؛ إخلاء أقدم جهاز عند التشبع (:252-266) | **لا يقبل أي private key slot بنيوياً** (التعليق :13-17 + لا حقل يقبل ذلك) (VERIFIED)؛ المعاملات كلها parameterized (:267-321)؛ KT append best-effort (:332-342)؛ إشعار rekey للشركاء (:348-370). p4 حي: مفتاح base64 غير صالح → 400 دقيق (PASSED) |
| GET /api/e2ee/bundle/:userId (:413) | AUTH | `e2ee:bundle` 120/h + **`e2ee:bundlepeer` 10/10min لكل هدف** (:420-425) | userId regex `[A-Za-z0-9_-]{1,128}` (:416) | 404 `registered:false` إن لم يوجد (:444-446) | استهلاك OPK واحد لكل جهاز بشكل ذري `FOR UPDATE SKIP LOCKED` (:451-480) (VERIFIED) — p6 حي أكّد التبريد الفعلي 10/10min (FAILED للتوقع القديم "4→429"، PASSED للسلوك الحقيقي) |
| POST /api/e2ee/prekeys (:543) | AUTH | `e2ee:prekeys` 10/h | دفعة OPKs ≤200 بمعرفات فريدة (:95-110) | ON CONFLICT DO NOTHING — لا استبدال مفاتيح الآخرين (user_id=$1 دائماً) (VERIFIED) |
| GET /api/e2ee/status (:589) | AUTH | `e2ee:status` 30/min | — | self-only (VERIFIED) |
| GET /api/e2ee/identity/:userId (:605) | AUTH | `e2ee:identity` 60/h | userId regex | يرجع المفاتيح العامة فقط (VERIFIED) — **يواجه أي userId مسجل بلا علاقة اجتماعية** (مقصود: safety number يحتاج ذلك؛ مقبول، المفاتيح عامة) |

**تقييم E2EE الصريح (مطلوب من المهمة):** الكود حديث ومتماسك. أضعافه الضعيفة الحقيقية:
- (a) `bundle` لا يفحص علاقة/حظر بين الطرفين — أي مستخدم مصادق يستطيع سحب OPKs من أي مستخدم حتى حد 10/10min لكل هدف؛ استنزاف OPKs يُجبر fallback إلى signed prekey فقط (سلوك Signal القياسي، ليس كسراً لكنه أطقالة مقصودة) — VERIFIED كتصميم، INFO.
- (b) `register` بدون deviceId يكتب في جدول legacy v7 — جهاز "خفي" ثانٍ بلا سقف أجهزة يمر عبر المسار legacy (MAX_DEVICES_PER_USER لا يطبق على المسار legacy، :295-321) — VERIFIED، LOW.
- (c) خطر مساومة المفاتيح = صفر: الخادم لا يلمس مفاتيح خاصة (VERIFIED).

### 3.9 Key Transparency (routes/kt.ts)

| Endpoint | AUTH | RL | ملاحظات |
|---|---|---|---|
| GET /api/e2ee/kt/root (:85) | AUTH | — | يعيد آخر snapshot موقّع؛ signature='' في وضع unverified موثّق (:14-19 + key_transparency.ts:313-336) (VERIFIED) |
| GET /api/e2ee/kt/proof/:userId (:95) | AUTH | in-process 60/min (:68-82) | **in-process وليس الـ distributed limiter** — على N instances الحد الفعلي N×60/min (VERIFIED، INFO)؛ userId regex (:98)؛ p5 حي: بلا توكن → 401 (PASSED) |
| POST /api/e2ee/kt/replay-detect (:121) | AUTH + requireAdmin محلي (:51-65) | — | تنقية مدخلات صارمة (hex ≤128، detail ≤2000) (:127-133) (VERIFIED) — نسخة معاد تكرارها من requireAdmin في server.ts — ازدواجية تحتاج مزامنة يدوية (INFO، موثّق بذاته :45-50) |

### 3.10 Passkeys (routes/passkeys.ts)

| Endpoint | AUTH | RL | ملاحظات |
|---|---|---|---|
| POST /api/auth/passkeys/register-options (:271) | AUTH | `passkeys:register-verify` 10/h | Origin/_rpID strict match (:92-101) — VERIFIED |
| POST /api/auth/passkeys/register-verify (:311) | AUTH | نفس القاعدة | challenge واحد للاستخدام (:158-164, :329)؛ UV=false مقبول (preferred) — INFO |
| POST /api/auth/passkeys/login-options (:376) | PUB | `passkeys:login-options` 30/min | anti-enumeration موحد 401 (:393-397) (VERIFIED) |
| POST /api/auth/passkeys/login-verify (:415) | PUB | `passkeys:login-verify` 20/h per username+IP | كشف clone عبر counter monotonic → إبطال فوري للمفتاح (:474-485) — VERIFIED إيجابي قوي |
| GET /api/auth/passkeys (:519) | AUTH | — | user-scoped (VERIFIED) |
| DELETE /api/auth/passkeys/:credentialId (:539) | AUTH | — | `AND user_id = $2` في الـ DELETE (:239) — لا IDOR (VERIFIED) |

### 3.11 التخزين ووسائط Google Drive (routes/storage.ts)

| Endpoint | AUTH | RL | ملاحظات |
|---|---|---|---|
| GET /api/storage/status (:111) | AUTH | — | لا يرجع أسراراً (VERIFIED) |
| POST /api/storage/link (:137) | AUTH | — | تحقق provider/endpoint/bucket regex + أطوال مفاتيح (:144-158)؛ تشفير AES-256-GCM قبل التخزين (:173 + services/storage.ts:107-125) (VERIFIED)؛ **يقبل أي publicBaseUrl https** — موثّق كقرار مع warning (:184-187) — الأساس يغذي allowlist المرفقات للمُرسِل فقط (INFO) |
| DELETE /api/storage/link (:195) | AUTH | — | نظيف |
| POST /api/storage/presign (:207) | AUTH + mute guard | `storage:presign` 60/h | MIME whitelist قاطعة (HTML/SVG مرفوض — services/storage.ts:34-45)؛ **object key server-side** `dirasha/<userId>/...` — لا يمكن للعميل اختيار مسار → لا path traversal / overwrite (storage.ts:150-166, 214-217) (VERIFIED) |
| POST/GET /api/storage/gdrive/start (:264,:275) | AUTH | — | consent URL مربوط بـ state (VERIFIED) |
| GET /api/storage/gdrive/callback (:287) | PUB | — | ربط المستخدم عبر state token أحادي الاستخدام (consumeState) (:289-299) (VERIFIED) |
| GET /api/storage/gdrive/status (:327) | AUTH | — | نظيف |
| GET /api/media/gdrive + /:fileId (:411-415) | **PUB** | — | **Capability-URL model** موثّق (:357-369): fileId regex `[A-Za-z0-9_-]{10,}` (:360) — لا path traversal (host ثابت googleapis.com، :379) → **لا SSRF** (VERIFIED)؛ Authorization = وجود fileId في جدول attachments (غير قابل للتخمين + LIKE lookup :66-72) — من يملك رابط الرسالة يقدر يبث الملف؛ **بلا فحص عضوية دردشة** — مفتاح capability يكفي (قرار موثّق؛ أخف من public Drive link لكن أضعف من باقي النظام) — PARTIALLY VERIFIED كقرار، LOW |
| POST /api/storage/gdrive/share (:416) | AUTH | `gdrive:share` 30/10min | نظيف |
| POST /api/storage/gdrive/upload-ticket (:439) | AUTH + mute guard | `storage:gdrive-ticket` 30/10min | يعيد accessToken للعميل لرفع مباشر — scope drive.file (VERIFIED) |
| DELETE /api/storage/gdrive (:495) | AUTH | — | نظيف |

### 3.12 Statuses (routes/status.ts — مثبتة مع requireAuth على server.ts:490)

| Endpoint | AUTH | ملاحظات |
|---|---|---|
| GET /api/statuses (:9) | AUTH | فلترة statusVisibility (:32-43) — VERIFIED |
| POST /api/statuses (:52) | AUTH | رفض data: URLs (:63-68)؛ HTTPS-only للوسائط — VERIFIED؛ duration_hours بلا سقف أعلى (`duration_hours || 24` أي عدد ساعات ممكن) — INFO |
| POST /api/statuses/:id/view (:118) | AUTH | **بلا فحص وجود/visibility** — سجلات مشاهدة لأي status id (فشل FK يظهر 500) — F9 (VERIFIED) |
| POST /api/statuses/:id/like|unlike (:137,:155) | AUTH | نفس الملاحظة — F9 |
| GET /api/statuses/:id/viewers (:172) | AUTH | OWNERSHIP مفحوص (:178-188) — VERIFIED إيجابي |
| POST /api/statuses/:id/comments (:207) | AUTH | **بلا فحص visibility** + طول text_content غير مقيّد — F9 |
| GET /api/statuses/:id/comments (:234) | AUTH | قراءة تعليقات ستاتس خاص — F9 |
| DELETE /api/statuses/:id (:254) | AUTH | ownership مفحوص (:260-267) — VERIFIED |

### 3.13 API Keys (routes/apiKeys.ts — مثبتة مع requireAdmin على server.ts:491)

| Endpoint | AUTH | ملاحظات |
|---|---|---|
| GET / (:8) | ADMIN | **F7**: masking يُطبق فقط إذا `key_value.length > 15` (:17-20) — مفتاح قصير يخرج كاملاً (VERIFIED) |
| POST / (:43) | ADMIN | `req.userId` (:50) — **requireAdmin لا يضبط req.userId** (يضبط req.user فقط، server.ts:367) → added_by يُخزن undefined دائماً (VERIFIED — خلل وظيفي أمني صغير) |
| DELETE /:id (:72) | ADMIN | نظيف |
| POST /:id/toggle (:88) | ADMIN | is_active بلا boolean coercion — يخزن كما هو (INFO) |

### 3.14 Group Calls (routes/groupCallRoutes.ts — مثبتة مع requireAuth على :418 → :61)

| Endpoint | AUTH | ملاحظات |
|---|---|---|
| POST /api/group-calls (:65) | AUTH | عضوية chatId (:72-74) — VERIFIED |
| POST /api/group-calls/:id/join (:88) | AUTH | سعة + عضوية مع rollback للانضمام المتفائل (:92-95) — VERIFIED |
| POST /api/group-calls/:id/leave (:107) | AUTH | idempotent — نظيف |
| GET /api/group-calls?chatId= (:118) | AUTH | عضوية — VERIFIED |

السجل في الذاكرة (groupCallSessions.ts) — إعادة تشغيل تمسح الجلسات؛ لا تسريب بين المستخدمين (VERIFIED).

---

## 4) التحليل الموضوعي

### 4.1 جودة التحقق من المدخلات (Input validation)
- **قوي**: E2EE (regex + أطوال bytes دقيقة)، authClassic (validateUsername/validatePasswordStrength/validatePin)، passkeys (Origin/RPID/counter)، storage (MIME whitelist + bucket regex)، chats permissions (enums صريحة)، moderation categories/statuses enums، search (q ≤100).
- **ضعيف/ناقص**: PUT /api/settings (JSONB حر) — server.ts:1199؛ PUT /api/messages/:messageId (content بلا سقف) — server.ts:2829؛ restrict minutes — server.ts:2162؛ status comments طول حر — status.ts:207-225؛ DELETE /api/users/me بلا إعادة مصادقة — server.ts:1144. — **PARTIALLY VERIFIED مجمّع**.

### 4.2 سطح SQL Injection
فحص شامل لكل استدعاءات `.query(` في src/server (grep 16 موضعاً في database.ts + كل routes):
- كل الاستعلامات بمعاملات `$1..$n` **إلا**:
  - database.ts:1443-1467 `SAVEPOINT ${sp}` — sp مولّد داخلياً (`sp_${safeTable}_${i}`) — غير قابلة للتأثير الخارجي — VERIFIED آمن.
  - database.ts:2827 / :4075 `UPDATE ... SET ${updateFields.join(', ')}` — الأسماء من allowlist داخلي ثابت (تحويل key→column يدوي) والقيم parameterized — VERIFIED آمن.
  - e2ee.ts:286-292, :561-568 placeholders مبنية برمجياً لكن القيم parameterized — VERIFIED آمن.
  - status.ts: LIKE 'image/%' ثابت — آمن.
- ILIKE search يستخدم `escapeLikePattern` + معامل (database.ts:5295-5312, :5339-5355) — VERIFIED.
- **النتيجة: لا سطح حقن SQL فعلي** (VERIFIED).

### 4.3 IDOR/BOLA endpoint-by-endpoint
- كل قراءة/كتابة رسالة تفحص العضوية أو الملكية (telemetry :2288، edit :2840، delete-me :2970، react :3721، star :3834، pin :3881) — VERIFIED.
- الجلسات: DELETE :1094 و revoke :596 (auth.ts:256) و passkeys delete :539 — ملكية مفحوصة — VERIFIED.
- **الاستثناءات** (مذكورة أعلاه): F6 sessions/check، F7 apiKeys masking، F9 statuses view/like/comments، sync F1.
- `GET /api/e2ee/identity/:userId` و `bundle/:userId` مقصود أن يكونا عامين-بعد-المصادقة (مفاتيح عامة) — INFO.

### 4.4 SSRF / Path Traversal
- لا endpoint يقبل URL للسحب من الخادم إلا media proxy لـ Google Drive بنطاق ثابت — لا SSRF (VERIFIED).
- allowlist المرفقات يمنع data:/blob:/relative ويعتمد https-only (server.ts:122-163) — مع ثغرة XFF المحتملة F2.
- مسارات الملفات: sendFile ثابتة (server.ts:497, :504, :513)، /uploads عبر express.static (:3948)، object keys مولدة server-side (storage.ts:150-166)، fileId regex — **لا path traversal** (VERIFIED).

### 4.5 الاتساق في وسط المصادقة (routes بلا requireAuth؟)
جرد كامل — PUB فعلاً: service-worker, manifest, security.txt, /security, vapid-key, health, check-username, eval-display-name, refresh, logout, register, login, recover/*, passkeys login-options/login-verify, gdrive/callback, **gdrive media proxy**, **reset-database (حارس مخصص)**. لا route نسيانه بلا حماية عدا ما وُثّق — VERIFIED (الجرد أعلاه كامل: 167 مسار).

### 4.6 WebSocket auth + ترخيص الأحداث (routeFrame)
- Handshake: JWT إجباري (:212-230) + Origin allowlist (CSWSH) (:232-242) + سقف 6 اتصالات/مستخدم (:244-253) + maxPayload 128KiB (:161) — VERIFIED. **F4: token كامل عبر URL**.
- routeFrame (ws_server.ts:449-590): token bucket لكل حدث (:461-483، budgets :77-91) + kick بعد 3 مخالفات — VERIFIED.
- ترخيص لكل حدث: chat:join عضوية (:609-638)، msg:send عبر sendGate المشترك (:770-795)، msg:read عضوية (:1015-1022)، msg:delivered عضوية (:1147-1154)، typing عضوية (:1196-1203)، call:respond ملزم بسجل المكالمة (:1573-1587)، call:signal الطرفان فقط (:1626-1645)، call:end الطرفان (:1668-1681)، groupcall:* مشاركات الجلسة (:1722-1735, :1757-1762, :1795-1796, :1816-1817)، e2ee:ctrl المرسِل والمرسل إليه عضوان بنفس المجموعة (:1883-1895)، admin:subscribe فحص role (:552-570) — **كل الأحداث مفحوصة** (VERIFIED).
- msg:send WS يطبق سقف 8000 / 24576 للمغلفات المشفرة (:753-765) — VERIFIED.

### 4.7 معالجة الأخطاء
- 88 موضعاً `err.message` (F5)؛ مسارات المصادقة/E2EE/Passkeys تستخدم رسائل عامة بالعربية (authClassic.ts:231, 379; e2ee.ts:408, 538 — VERIFIED إيجابي). لا stack traces في أي استجابة (grep `err.stack` في الاستجابات = 0) — VERIFIED.
- default 404 API يعيد `req.originalUrl` (:3952) — انعكاس URL معلوم — INFO (منخفض، مع Content-Type json لا HTML).

### 4.8 الـ Distributed Rate Limiter — التوصيل الفعلي
- الجدول المركزي RATE_LIMIT_RULES (rate_limiter.ts:50-79): 21 قاعدة من فئتين critical/throughput.
- التوصيل: Redis Lua atomic واحد (INCR + PEXPIRE أول ضربة + مقارنة) عبر `redisCluster.evalAtomic` (redis_client.ts:248) — atomic عبر كل الـ instances (VERIFIED).
- Fail semantics: critical → **fail-closed** 429 مع سجل صاخب (:206-217)؛ throughput → local Map مع سجل (:219-226)؛ بدون Redis → local Map مع تحذير إقلاع (:122-129) — VERIFIED.
- **ملاحظة مزدوجة**: `restLimit` المحلي في server.ts:55-69 لا يزال يخدم 5 قواعد (users:me, chats:create, auth:refresh, moderation:report, search:<uid>, pollvote) خارج الجدول الموزع — F12.
- Limiter fixes حية: `e2ee:bundlepeer` = 10/10min — أُثبت حياً (p6).

---

## 5) البروبات الإنتاجية الآمنة (SAFE PROBES — نتائج فعلية)

الهدف: `https://dirasha.onrender.com`. جميع البروبات قراءة فقط وتتوقع رفضاً. البروبات المصدقة استخدمت حساب فريق الاختبار الموثق في `deploy/e2ee-verify.cjs` (identity_final)، ثم **أُلغيت الجلسة فوراً** عبر `POST /api/auth/sessions/revoke` → HTTP 200 {"ok":true} (أثر متبقٍ: صف جلسة تم إبطاله + سطور audit؛ لا تعديل بيانات دائم).

| # | الأمر (مختصر) | المتوقع | النتيجة الفعلية | الحكم |
|---|---|---|---|---|
| p1 | `curl GET /api/chats` بلا توكن | 401/403 | **HTTP 401** `{"error":"Unauthorized: Access Token missing."}` | PASSED |
| p2 | `curl GET /api/e2ee/bundle/00000000-0000-0000-0000-000000000000` بلا توكن | رفض | **HTTP 401** `{"error":"Unauthorized: Access Token missing."}` | PASSED |
| p3 | `GET /api/e2ee/bundle/00000000-...-000000000000` **مع توكن** | 404 registered:false | **HTTP 404** `{"registered":false}` | PASSED |
| p4 | `POST /api/e2ee/register` بمفتاح `"!!!not-base64!!!"` (مصادق) | 400 | **HTTP 400** `{"error":"identityDhPub must be base64 X25519 (32 bytes)."}` | PASSED |
| p5 | `GET /api/e2ee/kt/proof/00000000-...` بلا توكن | رفض | **HTTP 401** `{"error":"Unauthorized: Access Token missing."}` | PASSED |
| p6 | 12 طلب متتالٍ `GET /api/e2ee/bundle/00000000-...` مع توكن (هدف غير موجود — قراءة صرفة، لا استهلاك OPKs) | تحقق التبريد لكل هدف | الطلبات 1-9 → **404**، ثم **429** `{"error":"تجاوزت حد جلب مفاتيح هذا المستخدم."}` للطلبات 10-12 | PASSED كسلوك حي / **FAILED** لتوقع المهمة القديم "الطلب الرابع → 429": القاعدة الفعلية `e2ee:bundlepeer` = **10/10min** (rate_limiter.ts:68)، والطلب العاشر هنا هو الضربة 11 إجمالاً (شملت ضربة p3 السابقة نفس المفتاح). البروب كما صيغ أصلاً (هدف حقيقي ×4) **تُخُطّي عن قصد**: كل جلب bundle يستهلّ OPK واحد (UPDATE consumed=true — e2ee.ts:451-480) وهذا تعديل حالة ممنوع في قواعد التدقيق |
| — | `POST /api/auth/sessions/revoke` بعد البروبات | إلغاء جلسة الاختبار | HTTP 200 {"ok":true} — استعادة الحالة | PASSED |

ملاحظات إجرائية: الطلبات curl بلا Origin — فحص CSRF (server.ts:291-304) يسمح بالعملاء غير المتصفحية، وهذا صحيح للـ API.

---

## 6) خلاصة التصنيف العامة

| المجال | التقييم |
|---|---|
| المصادقة والجلسات | قوي جداً (rotation + theft detection + قفل + 2FA + passkeys + media tokens) — VERIFIED |
| ترخيص REST | شبه كامل؛ استثناءات F1/F6/F9 موثقة |
| E2EE routes | جودة عالية، لا تعامل مع مفاتيح خاصة، تحقق بايتات صارم — VERIFIED |
| Rate limiting | موزع حقيقي fail-closed؛ ثغرة توازن: 6 قواعد على limiter محلي — F12 |
| SQLi | لا سطح فعلي — VERIFIED |
| SSRF/Traversal | لا سطح فعلي — VERIFIED (مع شرط F2) |
| خطورة إجمالية أعلى | MEDIUM ×3 (F1, F2, F3) — لا HIGH ولا CRITICAL وُجدت |
