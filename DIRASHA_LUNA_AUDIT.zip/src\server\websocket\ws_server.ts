/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { WebSocketServer, WebSocket } from "ws";
import type { IncomingMessage, Server } from "http";
import type { Duplex } from "stream";
import url from "url";
import { createHash, randomBytes } from "crypto";
import { db, normalizePollPayload, POLL_ATTACHMENT_MIME } from "../database.ts";
import { AuthService } from "../services/auth.ts";
import type {
  WSFrame,
  ClientToServerEvent,
  ServerToClientEvent,
  PresenceStatus,
} from "../../types.ts";
import { redisCluster } from "./redis_client.ts";
import { PresenceManager } from "./presence_manager.ts";
import { DeduplicationManager } from "./dedup_manager.ts";
import { AckManager } from "./ack_manager.ts";
import { WebPushService } from "../services/push.ts";
import { BackgroundWriteQueue } from "./write_queue.ts";
import { DashboardStatsCollector } from "../services/dashboard_stats.ts";
import {
  assertCanSendMessage,
  assertMembershipFresh,
  SendBlockedError,
  MembershipStaleError,
} from "../guards/sendGate.ts";
import {
  assertEncryptedIngress,
  E2eeRequiredError,
  E2eePolicyUnavailableError,
} from "../guards/encryptionPolicy.ts";
import { getGroupCall, leaveGroupCall } from "../groupCallSessions.ts";

// ── WS-01 (external audit): short-lived single-use WebSocket tickets ─────────
// The upgrade path historically accepted the long-lived access JWT in the
// query string (?token=...), leaking it into proxy/server logs and browser
// history. The ticket flow replaces that: the client first fetches a 60s,
// single-use ticket bound to its userId + Origin (GET /api/ws-ticket, wired
// in server.ts), then connects with ?ticket=<t>. The ticket proves the
// bearer ALREADY authenticated over a header-bearing REST call, so the
// long-lived JWT never appears in a URL.
//
// DIR-NEW-09 (external audit): legacy ?token=/Bearer-protocol upgrades are
// FAIL-CLOSED by default — rejected outright, before any JWT is even parsed.
// WS_ALLOW_LEGACY_WS_TOKEN=1 re-opens the deprecated transport with its
// one-shot deprecation warning as a DOCUMENTED TRANSITION WINDOW for
// not-yet-migrated clients. NOTE: this env flag is temporary and MUST be
// deleted once the client rollout completes — it is not a permanent setting.
// Scoped media tokens are never accepted on either path.
const WS_TICKET_TTL_MS = 60_000;
interface WsTicketRecord {
  userId: string;
  exp: number;
  used: boolean;
  /** Normalized Origin bound at issue time — null when the issuer had none. */
  origin: string | null;
}
const wsTickets = new Map<string, WsTicketRecord>();
let wsTicketSweeper: NodeJS.Timeout | null = null;

/**
 * DIR-NEW-09 (external audit): the legacy-token cutoff decision, as a pure
 * function so it is unit-testable without booting the server. Default is
 * FAIL-CLOSED: the deprecated ?token=/Bearer-protocol transport is accepted
 * ONLY when WS_ALLOW_LEGACY_WS_TOKEN is exactly '1' (the temporary client-
 * rollout transition window — delete the env after migration; see the
 * WS-01 block above). Any other value ('0', garbage, unset) keeps it closed.
 */
export function shouldAcceptLegacyWsToken(
  env: Record<string, string | undefined> = process.env,
): boolean {
  return env.WS_ALLOW_LEGACY_WS_TOKEN === '1';
}

/** User-facing reject reason for the legacy-token cutoff (Arabic, repo style). */
export const LEGACY_WS_TOKEN_REJECT_REASON =
  'اتصال WebSocket يتطلب تذكرة قصيرة العمر — حدّث العميل.';

function normalizeWsTicketOrigin(origin: string | null | undefined): string | null {
  if (typeof origin !== "string" || origin.length === 0) return null;
  return origin.replace(/\/$/, "");
}

function sweepExpiredWsTickets() {
  const now = Date.now();
  for (const [ticket, rec] of wsTickets) {
    if (rec.exp <= now) wsTickets.delete(ticket);
  }
}

function ensureWsTicketSweeper() {
  if (wsTicketSweeper) return;
  wsTicketSweeper = setInterval(sweepExpiredWsTickets, 30_000);
  // Never hold the event loop open just for ticket housekeeping.
  wsTicketSweeper.unref?.();
}

/**
 * WS-01: mint a single-use WebSocket upgrade ticket for an ALREADY-
 * authenticated user. Called by the REST route (server.ts: GET /api/ws-ticket)
 * — the route's requireAuth gate is what makes the ticket trustworthy.
 * Origin is bound at issue time (the REST request's Origin header; null for
 * non-browser clients) and re-checked at upgrade.
 */
export function issueWsTicket(
  userId: string,
  origin?: string | null,
): { ticket: string; exp: number } {
  if (typeof userId !== "string" || userId.length === 0) {
    throw new Error("issueWsTicket requires a userId.");
  }
  sweepExpiredWsTickets();
  ensureWsTicketSweeper();
  const ticket = randomBytes(32).toString("base64url");
  const exp = Date.now() + WS_TICKET_TTL_MS;
  wsTickets.set(ticket, {
    userId,
    exp,
    used: false,
    origin: normalizeWsTicketOrigin(origin),
  });
  return { ticket, exp };
}

/**
 * WS-01: consume a ticket at upgrade time. Single-use (the record is burned
 * on the FIRST consume attempt — success or failure — so replays and
 * races fail closed), 60s TTL, userId-bound, and Origin-bound: a ticket
 * issued WITH an Origin may only be redeemed with the SAME Origin. A ticket
 * issued WITHOUT one (issuer had no Origin header — e.g. a same-origin GET
 * fetch, which browsers do not stamp with Origin) accepts any presented
 * Origin: there was no Origin to bind, and such upgrades still pass the
 * CSWSH allowlist gate below. Synchronous by design — in-memory Map +
 * JS single threading = no TOCTOU.
 */
export function consumeWsTicket(
  ticket: unknown,
  origin?: string | null,
): { userId: string } | null {
  if (typeof ticket !== "string" || ticket.length === 0) return null;
  const record = wsTickets.get(ticket);
  // Burn the ticket on ANY consume attempt (single-use, fail-closed).
  wsTickets.delete(ticket);
  if (!record || record.used) return null;
  if (record.exp <= Date.now()) return null;
  const presented = normalizeWsTicketOrigin(origin);
  if (record.origin !== null && record.origin !== presented) {
    return null; // origin binding mismatch
  }
  return { userId: record.userId };
}

// ── STATUS-01 (external audit): global-broadcast status sanitizer ────────────
// Defense-in-depth at the fan-out boundary: no status row (or any payload
// carrying status content) may ever cross the GLOBAL `presence:broadcast`
// channel onto every open socket. Producers now publish pointer-only
// {statusId, ownerId} events on per-recipient `user:updates:*` channels;
// anything status-shaped that still arrives here is stripped down to that
// safe pointer shape before fan-out. Recipients fetch content via the
// authenticated GET which enforces canViewStatus.
function carriesStatusContent(o: any): boolean {
  return (
    !!o &&
    typeof o === "object" &&
    ("text_content" in o ||
      "media_url" in o ||
      "textContent" in o ||
      "mediaUrl" in o)
  );
}

export function sanitizeStatusBroadcastPayload(payload: any): any {
  if (!payload || typeof payload !== "object") return payload;

  // Legacy `status:new` shape: the full row nested under `status`.
  const nested = payload.status;
  if (
    nested &&
    typeof nested === "object" &&
    !Array.isArray(nested) &&
    (carriesStatusContent(nested) || typeof nested.id === "string")
  ) {
    return {
      statusId: nested.id ?? null,
      ownerId: nested.user_id ?? nested.userId ?? null,
    };
  }

  // Direct row / pointer payloads carrying content or a statusId.
  if (carriesStatusContent(payload) || payload.statusId != null) {
    return {
      statusId: payload.statusId ?? payload.id ?? null,
      ownerId: payload.ownerId ?? payload.user_id ?? payload.userId ?? null,
    };
  }
  return payload;
}

// ── WS-02 (external audit): attachment URL allowlist on the WS path ──────────
// Minimal WS-side mirror of the REST attachment gate (server.ts
// isAllowedAttachmentUrl — NOT importable from here without an import-boot
// cycle). Rejections mirror sendGate's media rule exactly:
//   1. `data:` URLs are rejected outright (inline base64 never allowed —
//      clients must presign+PUT to object storage first).
//   2. http(s) URLs must target a hostname in MEDIA_HOST_ALLOWLIST
//      (comma-separated) — when unset, SAME-ORIGIN only (the upgrade
//      request's Origin / Host header).
//   3. Anything unparseable or off-protocol fails closed.
// NOTE: the canonical unification with server.ts/sendGate belongs to the
// sendGate owner (shared guard module) — this is the WS enforcement seam.
export function isWsAttachmentUrlAllowed(
  rawUrl: unknown,
  socketOrigin?: string | null,
  socketHost?: string | null,
): boolean {
  if (typeof rawUrl !== "string" || rawUrl.length === 0) return false;
  if (rawUrl.startsWith("data:")) return false; // sendGate parity
  if (rawUrl.startsWith("/")) return true; // relative → this server by definition

  let parsed: URL;
  try {
    parsed = new URL(rawUrl);
  } catch {
    return false; // blob:, garbage, anything unparseable
  }
  if (parsed.protocol !== "https:" && parsed.protocol !== "http:") return false;

  const targetHostname = parsed.hostname.toLowerCase();
  const allowList = (process.env.MEDIA_HOST_ALLOWLIST || "")
    .split(",")
    .map((h) => h.trim().toLowerCase())
    .filter(Boolean);
  if (allowList.length > 0) return allowList.includes(targetHostname);

  // No explicit allowlist configured → same-origin only (fail-closed when
  // the upgrade request carried neither an Origin nor a Host header).
  const hostnameOf = (value: string | null | undefined): string | null => {
    if (!value) return null;
    try {
      return new URL(value).hostname.toLowerCase();
    } catch {
      return value.replace(/:\d+$/, "").toLowerCase();
    }
  };
  const originHostname = hostnameOf(socketOrigin);
  const hostHeaderHostname = hostnameOf(socketHost);
  return (
    (!!originHostname && targetHostname === originHostname) ||
    (!!hostHeaderHostname && targetHostname === hostHeaderHostname)
  );
}

// Extends standard WebSocket instance with custom session parameters
export interface ManagedWebSocket extends WebSocket {
  id: string; // Connection-specific UUID
  userId: string; // User Authenticated ID
  username: string; // Handle/username
  phone: string; // Authenticated phone (E.164) — identity root in the phone-auth era
  isAlive: boolean; // Connection state tracker for heartbeats
  activeChatRooms: Set<string>; // Connected rooms scope (prevents security leaked cross-chats)
  pongTimeoutTimer?: NodeJS.Timeout; // custom heartbeat timer
  upgradeOrigin?: string | null; // WS-02: Origin header seen at upgrade (attachment same-origin check)
  upgradeHost?: string | null; // WS-02: Host header seen at upgrade (proxy-aware fallback)
}

export class WebSocketChatServer {
  private wss: WebSocketServer;

  // Track direct websocket connections to this local server instance
  private userConnections = new Map<string, Set<ManagedWebSocket>>();

  // Ephemeral Typing Status cache local to this thread, synchronized over Redis Cluster PubSub
  private typingCache = new Map<
    string,
    Map<string, { displayName: string; timer: NodeJS.Timeout }>
  >();

  // Dynamic PubSub state unsubscribers map (channel -> unsubscribe function)
  private redisUnsubscribers = new Map<string, () => void>();

  // Active voice calls registry (callId -> call details)
  private activeCalls = new Map<
    string,
    {
      callId: string;
      callerId: string;
      calleeId: string;
      type?: string;
      startedAt?: number;
      ringTimer?: NodeJS.Timeout; // T3: unanswered-call timeout handle
      callerName?: string; // T3: resolved display name for call:missed payloads
    }
  >();

  // P0-hardening ─ realtime abuse engine ────────────────────────────────────────────
  // Per-user connection cap: allows multi-device usage while preventing one account
  // from hoarding thousands of sockets (fd/memory exhaustion).
  private static readonly MAX_CONNECTIONS_PER_USER = 6;

  // Token-bucket budgets per event family (maxActions, windowMs). Applied per user
  // across all their sockets; stops message floods, typing spam and signal storms.
  private static readonly EVENT_BUDGETS: Record<string, { max: number; windowMs: number }> = {
    'msg:send':          { max: 30,  windowMs: 10_000 },
    // Poll voting shares the msg:send budget family scale but gets its own
    // bucket so a vote burst cannot starve message sending (and vice versa).
    'msg:poll:vote':     { max: 30,  windowMs: 10_000 },
    'presence:typing':   { max: 10,  windowMs: 5_000 },
    'call:signal':       { max: 60,  windowMs: 10_000 },
    'call:initiate':     { max: 6,   windowMs: 60_000 },
    // Group-call mesh relay: ICE candidates fan out to N-1 peers, so the
    // budget is per-user across all peers (generous but still bounded).
    'groupcall:signal':  { max: 120, windowMs: 10_000 },
    // E2EE control relay (sender-key distribution): ≤60 envelopes/min/user.
    'e2ee:ctrl':         { max: 60,  windowMs: 60_000 },
    default:             { max: 120, windowMs: 10_000 },
  };
  private static readonly STRIKES_BEFORE_KICK = 3;

  // Hard cap on text content — DB, caches and fan-out all handle bounded payloads.
  private static readonly MAX_MESSAGE_LENGTH = 8000;
  /**
   * PQXDH transport ceiling for E2EE envelope content (DIR1:/DIRM1:/DIRG1 —
   * opaque, strictly bounded). MEASURED worst case (design doc §2.1 math,
   * b64-of-JSON layering included): a 6-device first-message DIRM1 fan-out
   * with one ML-KEM-768 ciphertext per device is ~20.2KB on the wire
   * (6 × ~2.6KB envelopes + container, the whole container is b64). The
   * 16KB estimate in the task understated it even after its own 13.7KB raw
   * figure (≈18.3KB after the container b64) — so the gate is set to the
   * EXISTING e2ee:ctrl relay ceiling (24KB) instead of inventing a tighter
   * one that would silently drop exactly the 6-device PQ bootstrap this
   * exists to protect. Encrypted content remains opaque and bounded.
   */
  private static readonly MAX_E2EE_MESSAGE_LENGTH = 24576;

  private eventBuckets = new Map<string, { tokens: number; lastRefill: number; strikes: number }>();

  /** Origin gate for browser clients (CSWSH). Non-browser clients send no Origin and pass. */
  private static isBrowserOriginAllowed(origin: string): boolean {
    const allowList = (process.env.ALLOWED_ORIGINS || '')
      .split(',').map(o => o.trim().replace(/\/$/, '')).filter(Boolean);
    if (allowList.length > 0) return allowList.includes(origin.replace(/\/$/, ''));
    try { const u = new URL(origin); return ['localhost', '127.0.0.1', '[::1]'].includes(u.hostname); }
    catch { return false; }
  }

  /**
   * Token-bucket check per user+event; repeated violations disconnect the flooder.
   *
   * Project 5 — deliberately IN-MEMORY (NOT routed through the Redis
   * distributed limiter in services/rate_limiter.ts): these budgets are
   * per-connection abuse braking (server-side throttling of a single
   * authenticated socket's event rate). A restart resetting these counters
   * is explicitly acceptable, and a Redis round-trip on every WS event would
   * add latency to the hot message path. The Redis-backed fail-closed
   * enforcement covers the REST surface; msg:send event budgets stay here.
   */
  private consumeEventBudget(userId: string, event: string): { allowed: boolean; kick: boolean } {
    const budget = WebSocketChatServer.EVENT_BUDGETS[event] || WebSocketChatServer.EVENT_BUDGETS.default;
    const key = `${userId}:${event}`;
    const now = Date.now();
    let bucket = this.eventBuckets.get(key);
    if (!bucket) {
      bucket = { tokens: budget.max, lastRefill: now, strikes: 0 };
      this.eventBuckets.set(key, bucket);
    }
    const elapsed = now - bucket.lastRefill;
    if (elapsed > budget.windowMs) {
      const refillCycles = Math.floor(elapsed / budget.windowMs);
      bucket.tokens = Math.min(budget.max, bucket.tokens + refillCycles * budget.max);
      bucket.lastRefill += refillCycles * budget.windowMs;
    }
    if (bucket.tokens <= 0) {
      bucket.strikes++;
      return { allowed: false, kick: bucket.strikes >= WebSocketChatServer.STRIKES_BEFORE_KICK };
    }
    bucket.tokens--;
    return { allowed: true, kick: false };
  }

  // ────────────────────────────────────────────────────────────────────────────────

  constructor(server: Server) {
    // P0-hardening: cap frame size (library default is 100 MiB — a memory-exhaustion DoS
    // vector for any authenticated user). 128 KiB is generous: attachments travel via
    // presigned PUT, never inline; WS frames only carry text + attachment metadata.
    this.wss = new WebSocketServer({ noServer: true, maxPayload: 128 * 1024 });
    this.setupUpgradeHandler(server);
    this.setupConnectionHandler();
    this.setupHeartbeat();
    this.setupGlobalPubSubSubscriptions();

    // Wire up telemetry callbacks to our DashboardStatsCollector
    DashboardStatsCollector.getCurrentOnlineUserCount = () => {
      return this.userConnections.size;
    };
    DashboardStatsCollector.getCurrentActiveConnectionsCount = () => {
      let count = 0;
      for (const sockets of this.userConnections.values()) {
        count += sockets.size;
      }
      return count;
    };

    // Restore pending database writes from Redis
    BackgroundWriteQueue.initialize().catch((err) => {
      console.error(
        "[WebSocketChatServer] Failed initializing BackgroundWriteQueue:",
        err.message,
      );
    });

    console.log("[WS] WebSocket server initialized.");
  }

  /**
   * Intercept and authenticate incoming socket handshake requests before upgrading
   */
  private setupUpgradeHandler(server: Server) {
    // WS-01: one-shot deprecation notice for the legacy JWT-in-URL upgrade.
    let legacyTokenDeprecationWarned = false;

    const rejectUpgrade = (
      socket: Duplex,
      status: string,
      extra?: string,
      body?: string,
    ) => {
      socket.write(
        `HTTP/1.1 ${status}\r\n${extra || ""}Connection: close\r\n\r\n${body || ""}`,
      );
      socket.destroy();
    };

    server.on("upgrade", async (request: IncomingMessage, socket, head) => {
      const parsedUrl = url.parse(request.url || "", true);
      const queryToken = parsedUrl.query.token as string | undefined;
      const queryTicket = parsedUrl.query.ticket as string | undefined;
      const upgradeOrigin =
        typeof request.headers.origin === "string" && request.headers.origin.length > 0
          ? request.headers.origin
          : null;
      const upgradeHost =
        typeof request.headers.host === "string" && request.headers.host.length > 0
          ? request.headers.host
          : null;

      let token = queryToken as string | undefined;
      let isLegacyJwtUpgrade = false;

      // Fallback for custom clients passing Bearer protocol configurations
      if (!token && request.headers["sec-websocket-protocol"]) {
        const protocols = request.headers["sec-websocket-protocol"]
          .split(",")
          .map((p) => p.trim());
        if (protocols.length > 1 && protocols[0] === "Bearer") {
          token = protocols[1];
          isLegacyJwtUpgrade = true;
        } else if (protocols[0]) {
          token = protocols[0]; // fallback direct assignment
          isLegacyJwtUpgrade = true;
        }
      }

      // WS-01 (external audit): preferred path — short-lived, single-use,
      // userId+Origin-bound ticket minted by GET /api/ws-ticket AFTER a full
      // authenticated REST round-trip. The long-lived JWT never appears in a
      // URL on this path.
      if (queryTicket) {
        const consumed = consumeWsTicket(queryTicket, upgradeOrigin);
        if (!consumed) {
          console.warn(
            "[WebSocketChatServer] Security Rejection: invalid, expired, replayed, or origin-mismatched WS ticket.",
          );
          rejectUpgrade(socket, "403 Forbidden");
          return;
        }
        const ticketUser = await db
          .getUserById(consumed.userId)
          .catch(() => null); // db outage → fail closed (never upgrade unverified)
        if (!ticketUser) {
          console.warn(
            "[WebSocketChatServer] Security Rejection: WS ticket references a nonexistent or unverifiable user.",
          );
          rejectUpgrade(socket, "403 Forbidden");
          return;
        }
        // BATCH-4 (DIR-AB-04): banned accounts cannot complete the WS upgrade —
        // ticket redemption now re-checks ban state (REST parity at connect).
        // Matches requireAuth's ban semantics: active/temporary/permanent bans
        // reject; expired bans auto-lift on the REST path.
        if ((ticketUser as any).isBanned) {
          const until = (ticketUser as any).bannedUntil;
          const activeBan = !until || new Date(until) > new Date();
          if (activeBan) {
            console.warn(`[WebSocketChatServer] Security Rejection: banned user ${ticketUser.username || consumed.userId} attempted WS upgrade.`);
            rejectUpgrade(socket, "403 Forbidden");
            return;
          }
        }
        // P0-hardening: the CSWSH Origin allowlist applies to EVERY upgrade
        // path — ticket redemption included (defense-in-depth on top of the
        // per-ticket Origin binding).
        if (upgradeOrigin && !WebSocketChatServer.isBrowserOriginAllowed(upgradeOrigin)) {
          console.warn(
            `[WebSocketChatServer] Security Rejection: disallowed Origin "${upgradeOrigin}" attempted ticket upgrade.`,
          );
          rejectUpgrade(socket, "403 Forbidden");
          return;
        }
        this.completeUpgrade(request, socket, head, {
          userId: ticketUser.id,
          username: ticketUser.username || "",
          upgradeOrigin,
          upgradeHost,
        });
        return;
      }

      if (!token) {
        console.warn(
          "[WebSocketChatServer] Security Rejection: Unauthenticated WebSocket upgrade requested.",
        );
        rejectUpgrade(socket, "401 Unauthorized");
        return;
      }

      // DIR-NEW-09 (external audit): legacy ?token=/Bearer-protocol upgrades
      // are FAIL-CLOSED unless the temporary WS_ALLOW_LEGACY_WS_TOKEN=1
      // transition window is enabled. The gate runs BEFORE any JWT parsing —
      // an unaccepted transport must not even validate the credential that
      // leaks into proxy/server logs. The ticket path above is unaffected.
      if (
        (queryToken || isLegacyJwtUpgrade) &&
        !shouldAcceptLegacyWsToken()
      ) {
        console.warn(
          "[WebSocketChatServer] Security Rejection: legacy ?token=/Bearer-protocol WebSocket upgrade rejected (WS_ALLOW_LEGACY_WS_TOKEN is not '1') — clients must use GET /api/ws-ticket + ?ticket=.",
        );
        rejectUpgrade(
          socket,
          "403 Forbidden",
          "Content-Type: text/plain; charset=utf-8\r\n",
          `${LEGACY_WS_TOKEN_REJECT_REASON}\n`,
        );
        return;
      }

      // Cryptographically verify validity of Bearer JSON Web Token
      const decoded = AuthService.verifyAccessToken(token);
      if (!decoded) {
        console.warn(
          "[WebSocketChatServer] Security Rejection: Invalid JWT Signature or Token Expired.",
        );
        rejectUpgrade(socket, "403 Forbidden");
        return;
      }

      // AUTH-05 (defense-in-depth): scoped media tokens (aud/purpose 'media')
      // are valid ONLY for media element URLs — never as a WebSocket upgrade
      // credential, matching the requireAuth Bearer gate in server.ts.
      if (AuthService.isScopedMediaToken(decoded) || AuthService.isMediaToken(decoded)) {
        console.warn(
          "[WebSocketChatServer] Security Rejection: media-scoped token presented on the WebSocket upgrade path.",
        );
        rejectUpgrade(socket, "403 Forbidden");
        return;
      }

      // BATCH-3 review follow-up: ban parity on the legacy transition path —
      // a banned user holding a valid legacy JWT must not complete the upgrade
      // either (same semantics as the ticket-path check above).
      if (queryToken || isLegacyJwtUpgrade) {
        try {
          const legacyUser = await db.getUserById((decoded as any).userId).catch(() => null);
          if (legacyUser && (legacyUser as any).isBanned) {
            const until = (legacyUser as any).bannedUntil;
            if (!until || new Date(until) > new Date()) {
              console.warn(`[WebSocketChatServer] Security Rejection: banned user ${legacyUser.username || (decoded as any).userId} attempted legacy WS upgrade.`);
              rejectUpgrade(socket, "403 Forbidden");
              return;
            }
          }
        } catch { /* fail-open here would defeat the check — but DB failure already fails closed upstream */ }
      }

      if (queryToken || isLegacyJwtUpgrade) {
        // DIR-NEW-09: reached ONLY under the WS_ALLOW_LEGACY_WS_TOKEN=1
        // transition window (the default path rejected above, pre-JWT-parse).
        // WS-01 backward compat: the JWT-in-URL transport is deprecated.
        if (!legacyTokenDeprecationWarned) {
          legacyTokenDeprecationWarned = true;
          console.warn(
            "[WebSocketChatServer] DEPRECATION: legacy ?token=/Bearer-protocol WebSocket upgrades are deprecated — migrate clients to GET /api/ws-ticket + ?ticket= (short-lived, single-use). The access JWT in a URL leaks to proxy/server logs.",
          );
        }
      }

      // P0-hardening: reject browser cross-site hijacking attempts (CSWSH).
      // Browsers always send Origin on WS; our own pages pass the allowlist.
      if (upgradeOrigin && !WebSocketChatServer.isBrowserOriginAllowed(upgradeOrigin)) {
        console.warn(
          `[WebSocketChatServer] Security Rejection: disallowed Origin "${upgradeOrigin}" attempted upgrade.`,
        );
        rejectUpgrade(socket, "403 Forbidden");
        return;
      }

      // P0-hardening: per-user connection cap (fd/memory exhaustion guard).
      const existing = this.userConnections.get(decoded.userId);
      if (existing && existing.size >= WebSocketChatServer.MAX_CONNECTIONS_PER_USER) {
        console.warn(
          `[WebSocketChatServer] Security Rejection: user ${decoded.username} exceeded ${WebSocketChatServer.MAX_CONNECTIONS_PER_USER} concurrent connections.`,
        );
        rejectUpgrade(socket, "403 Forbidden", "X-Limit: connections\r\n");
        return;
      }

      this.completeUpgrade(request, socket, head, {
        userId: decoded.userId,
        username: decoded.username,
        upgradeOrigin,
        upgradeHost,
      });
    });
  }

  /**
   * Shared tail of the upgrade flow: Nagle-off, raw stream upgrade and
   * ManagedWebSocket session binding (both ticket and legacy JWT paths).
   */
  private completeUpgrade(
    request: IncomingMessage,
    socket: Duplex,
    head: Buffer,
    session: { userId: string; username: string; upgradeOrigin: string | null; upgradeHost: string | null },
  ) {
    // P0-hardening + perf: kill Nagle's algorithm — small WS frames must not
    // queue behind delayed-ACK on real networks.
    (socket as import("net").Socket).setNoDelay(true);

    // Upgrade to raw secure stream
    this.wss.handleUpgrade(request, socket, head, (ws) => {
      const mws = ws as ManagedWebSocket;
      mws.id = "conn-" + crypto.randomUUID();
      mws.userId = session.userId;
      mws.username = session.username;
      mws.phone = session.username || ''; // field kept for socket log lines; identity = username now
      mws.isAlive = true;
      mws.activeChatRooms = new Set();
      mws.upgradeOrigin = session.upgradeOrigin;
      mws.upgradeHost = session.upgradeHost;

      this.wss.emit("connection", mws, request);
    });
  }

  /**
   * Initialize connection events
   */
  private setupConnectionHandler() {
    this.wss.on("connection", async (ws: ManagedWebSocket) => {
      const userId = ws.userId;
      // console.log(`[WebSocketChatServer] Establishing session [ConnID: ${ws.id}] for User: ${ws.username} [ID: ${userId}]`);

      // 1. Map session connection registry
      if (!this.userConnections.has(userId)) {
        this.userConnections.set(userId, new Set());
      }
      this.userConnections.get(userId)!.add(ws);

      // Subscribe this server thread if no other socket on this server has subscribed to user private channel
      const userRedisChannel = `user:updates:${userId}`;
      if (!this.redisUnsubscribers.has(userRedisChannel)) {
        const unsubUser = await redisCluster.subscribe(
          userRedisChannel,
          (msg: { event: string; payload: any }) => {
              this.wss.clients.forEach((client) => {
                const mws = client as ManagedWebSocket;
                if (mws.readyState === WebSocket.OPEN && mws.userId === userId) {
                  // Group eviction: strip the room from live sockets so the
                  // removed member stops receiving immediately (defect T3 fix).
                  if (msg.event === "chat:evicted") {
                    mws.activeChatRooms.delete(msg.payload?.chatId);
                    this.sendToSocket(mws, "chat:evicted", msg.payload);
                    return;
                  }
                  // Moderation Enforcement: If ban or session revoke, terminate
                  if (
                    msg.event === "auth:revoked" ||
                    msg.event === "user:banned"
                  ) {
                  this.sendToSocket(mws, "auth:revoked", msg.payload);
                  mws.terminate();
                  return;
                }

                // Deduplicate event transmissions that are already dispatched via active room subscription (only for generic message broadcasts)
                const chatId = msg.payload?.chatId;
                if (
                  msg.event === "msg:new" &&
                  chatId &&
                  mws.activeChatRooms.has(chatId)
                ) {
                  return; // Already received via chat room channel subscription, skipping to avoid duplicates
                }
                this.sendToSocket(mws, msg.event, msg.payload);
              }
            });
          },
        );
        this.redisUnsubscribers.set(userRedisChannel, unsubUser);
      }

      // 2. Propagate online state securely
      await PresenceManager.registerUserOnline(userId, ws.id);

      // 3. Perform offline resync transition logic (Pending Messages syncing)
      await this.syncPendingMessagesDeliveryOnConnect(userId);

      // 4. Send handshaking ready response for client alignment
      const userObj = await db.getUserById(userId);
      this.sendToSocket(ws, "auth:ready", {
        user: {
          id: userId,
          username: ws.username,
          displayName: userObj?.displayName || ws.username,
        },
        connectionId: ws.id,
        timestamp: new Date().toISOString(),
      });

      // 5. Setup data transmission receiver route
      ws.on("message", async (raw: string) => {
        try {
          const frame: WSFrame = JSON.parse(raw);
          await this.routeFrame(ws, frame);
        } catch (err: any) {
          console.error(
            `[WebSocketChatServer] Invalid frame syntax received from user ${ws.username}:`,
            err.message,
          );
          this.sendToSocket(ws, "socket:error", {
            error:
              "Payload must be serialized JSON conforming to WSFrame spec.",
          });
        }
      });

      // 6. Bind standard ping-pong checks
      ws.on("pong", async () => {
        ws.isAlive = true;
        await PresenceManager.refreshConnection(ws.userId, ws.id);
      });

      // 7. Session Cleanup handlers
      ws.on("close", async () => {
        DashboardStatsCollector.removeAdminSocket(ws);
        await this.handleSocketDisconnect(ws);
      });

      ws.on("error", async (err) => {
        console.error(
          `[WebSocketChatServer] Hardware exception flag for connection index Ref [${ws.id}] [User: ${ws.username}]:`,
          err.message,
        );
        DashboardStatsCollector.removeAdminSocket(ws);
        await this.handleSocketDisconnect(ws);
      });
    });
  }

  /**
   * Periodically check socket live feedback to terminate silent/ghost sockets safely.
   * Send ping every 20 seconds. Client must respond in <= 10 seconds.
   */
  private setupHeartbeat() {
    setInterval(() => {
      this.wss.clients.forEach((ws) => {
        const mws = ws as ManagedWebSocket;

        // Check if socket was unresponsive to previous heartbeat
        if (!mws.isAlive) {
          mws.terminate();
          return;
        }

        mws.isAlive = false;

        // Send application-level ping frame
        this.sendToSocket(mws, "socket:ping", { timestamp: Date.now() });

        // Native physical websocket ping
        try {
          mws.ping();
        } catch (e) {}

        // Timeout of 10 seconds to receive the pong.
        if (mws.pongTimeoutTimer) {
          clearTimeout(mws.pongTimeoutTimer);
        }
        mws.pongTimeoutTimer = setTimeout(() => {
          if (!mws.isAlive) {
            mws.terminate();
          }
        }, 10000);
      });
    }, 20000); // Send ping every 20 seconds
  }

  /**
   * Binds global subscriber channels across our scalable Redis setup to synchronize state
   */
  private async setupGlobalPubSubSubscriptions() {
    // Synchronize global presence changes across multiple server instances
    const unsubPresence = await redisCluster.subscribe(
      "presence:broadcast",
      (payload: any) => {
        // STATUS-01 defense-in-depth: ANY status-shaped payload on the GLOBAL
        // channel is stripped to the safe {statusId, ownerId} pointer before
        // fan-out — full status rows (text_content/media_url) must never
        // reach sockets that the owner's statusVisibility excludes. Legit
        // per-recipient status delivery rides `user:updates:<uid>` instead.
        const safePayload = sanitizeStatusBroadcastPayload(payload?.payload);
        this.wss.clients.forEach((client) => {
          const mws = client as ManagedWebSocket;
          if (mws.readyState === WebSocket.OPEN) {
            this.sendToSocket(mws, payload.event, safePayload);
          }
        });
      },
    );
    this.redisUnsubscribers.set("presence:broadcast", unsubPresence);
  }

  /**
   * Validates, secures, and routes action payloads to specialized system controllers
   */
  private async routeFrame(ws: ManagedWebSocket, frame: WSFrame) {
    const { event, payload, traceId } = frame;

    // Reject processing if payload parameters are entirely missing
    if (!event) {
      this.sendToSocket(ws, "socket:error", {
        error: "Undefined event type in frame envelope.",
        traceId,
      });
      return;
    }

    // P0-hardening: per-user token bucket per event family. Heartbeats are free;
    // everything else spends budget. Serial violators get disconnected.
    if (event !== "socket:pong") {
      const { allowed, kick } = this.consumeEventBudget(ws.userId, event);
      if (!allowed) {
        if (kick) {
          console.warn(
            `[WebSocketChatServer] Abuse Engine: disconnecting user ${ws.username} (repeated ${event} flood).`,
          );
          this.sendToSocket(ws, "socket:error", {
            error: "Rate limit exceeded repeatedly. Connection terminated.",
            traceId,
          });
          ws.close(1008, "rate limit abuse");
          return;
        }
        this.sendToSocket(ws, "socket:error", {
          error: "Rate limit exceeded. Slow down.",
          traceId,
        });
        return;
      }
    }

    try {
      switch (event as ClientToServerEvent) {
        case "socket:pong" as any:
          ws.isAlive = true;
          if (ws.pongTimeoutTimer) {
            clearTimeout(ws.pongTimeoutTimer);
            ws.pongTimeoutTimer = undefined;
          }
          await PresenceManager.refreshConnection(ws.userId, ws.id);
          break;
        case "chat:join":
          await this.handleChatJoin(ws, payload?.chatId, traceId);
          break;
        case "msg:send":
          await this.handleMessageSend(ws, payload, traceId);
          break;
        case "msg:read":
          await this.handleMessageRead(ws, payload, traceId);
          break;
        case "msg:poll:vote" as any:
          await this.handlePollVote(
            ws,
            payload,
            traceId,
          );
          break;
        case "msg:delivered" as any:
          await this.handleMessageDelivered(ws, payload, traceId);
          break;
        case "presence:status":
          await this.handlePresenceStatusChange(ws, payload?.status, traceId);
          break;
        case "presence:typing":
          await this.handlePresenceTyping(
            ws,
            payload?.chatId,
            payload?.isTyping,
            traceId,
          );
          break;
        case "call:initiate" as any:
          await this.handleCallInitiate(ws, payload, traceId);
          break;
        case "call:respond" as any:
          await this.handleCallRespond(ws, payload, traceId);
          break;
        case "call:signal" as any:
          await this.handleCallSignal(ws, payload, traceId);
          break;
        case "call:end" as any:
          await this.handleCallEnd(ws, payload, traceId);
          break;
        case "groupcall:signal" as any:
          await this.handleGroupCallSignal(ws, payload, traceId);
          break;
        case "groupcall:announce" as any:
          await this.handleGroupCallAnnounce(ws, payload, traceId);
          break;
        case "groupcall:joined" as any:
          await this.handleGroupCallJoined(ws, payload, traceId);
          break;
        case "groupcall:leave" as any:
          await this.handleGroupCallLeave(ws, payload, traceId);
          break;
        case "e2ee:ctrl" as any:
          await this.handleE2eeCtrl(ws, payload, traceId);
          break;
        case "admin:subscribe" as any:
          const requester = await db.getUserById(ws.userId);
          const isAdmin =
            requester &&
            (requester.role === "admin" || requester.role === "developer");

          if (isAdmin) {
            DashboardStatsCollector.registerAdminSocket(ws);
            this.sendToSocket(ws, "admin:subscribe:ack", { success: true });
          } else {
            console.warn(
              `[Security Alert] Unauthorized WebSocket admin:subscribe attempt by ${ws.phone || "unknown"} (ID: ${ws.userId})`,
            );
            this.sendToSocket(ws, "socket:error", {
              error:
                "Rejection: 403 Forbidden. This action requires administrative permissions.",
              traceId,
            });
          }
          break;
        case "admin:unsubscribe" as any:
          DashboardStatsCollector.removeAdminSocket(ws);
          this.sendToSocket(ws, "admin:unsubscribe:ack", { success: true });
          break;
        default:
          // Ignore unsupported events silently to avoid logging spam
          break;
      }
    } catch (err: any) {
      console.error(
        `[WebSocketChatServer] Exception occurred processing event '${event}':`,
        err,
      );
      this.sendToSocket(ws, "socket:error", {
        error: "Internal gateway operational failure.",
        traceId,
      });
    }
  }

  /**
   * Secure Chatroom Subscription and verification middleware
   */
  private async handleChatJoin(
    ws: ManagedWebSocket,
    chatId: string,
    traceId?: string,
  ) {
    if (!chatId) {
      this.sendToSocket(ws, "socket:error", {
        error: "chatId argument is strictly required to subscribe.",
        traceId,
      });
      return;
    }

    // Verify requesting socket identity is a valid, authorized member of database conversation (source of truth is PostgreSQL)
    let members = await db.getChatMembers(chatId);

    // Auto-provision direct one-to-one chats deterministically if members are correct but record was not indexed yet
    if (members.length === 0 && chatId.startsWith("one_to_one_")) {
      const parts = chatId.replace("one_to_one_", "").split("___");
      if (parts.length === 2) {
        const [u1, u2] = parts;
        if (ws.userId === u1 || ws.userId === u2) {
          console.log(
            `[WebSocketChatServer] Auto-provisioning direct-chat from websocket session: ${chatId} for ${u1} and ${u2}`,
          );
          await db.createChat("one-to-one", "", [u1, u2], chatId);
          members = await db.getChatMembers(chatId);
        }
      }
    }

    const isMember = members.some((m) => m.userId === ws.userId);

    if (!isMember) {
      console.warn(
        `[WebSocketChatServer] Sec-Policy Guard: User ${ws.username} (ID: ${ws.userId}) denied access to join room ${chatId}. Members recorded:`,
        members.map((m) => m.userId),
      );
      this.sendToSocket(ws, "socket:error", {
        error: "Unauthorized: You are not a member of this chat space.",
        traceId,
      });
      return;
    }

    // Subscribe to chatroom
    ws.activeChatRooms.add(chatId);

    // Subscribe this server thread if no other socket on this server has subscribed to it yet
    const redisChannel = `chat:${chatId}`;
    if (!this.redisUnsubscribers.has(redisChannel)) {
      const unsub = await redisCluster.subscribe(
        redisChannel,
        (msg: { event: string; payload: any }) => {
          this.wss.clients.forEach((client) => {
            const mws = client as ManagedWebSocket;
            if (
              mws.readyState === WebSocket.OPEN &&
              mws.activeChatRooms.has(chatId)
            ) {
              this.sendToSocket(
                mws,
                msg.event as ServerToClientEvent,
                msg.payload,
              );
            }
          });
        },
      );
      this.redisUnsubscribers.set(redisChannel, unsub);
    }

    if (process.env.LOG_LEVEL === "DEBUG") {
      console.log(
        `[WebSocketChatServer] Session [${ws.id}] successfully subscribed to room: ${chatId}`,
      );
    }

    // Confirm subscription achievement back to client
    this.sendToSocket(ws, "chat:join:ack", {
      chatId,
      status: "subscribed",
      traceId,
    });
  }

  /**
   * Secure, idempotent message processor
   */
  private async handleMessageSend(
    ws: ManagedWebSocket,
    payload: {
      tempMessageId?: string;
      chatId: string;
      content: string;
      type?: "text" | "attachment";
      attachments?: any[];
      poll?: any;
      traceTimings?: any;
    },
    traceId?: string,
  ) {
    const serverReceived = Date.now();
    const {
      tempMessageId,
      chatId,
      content,
      type = "text",
      attachments = [],
      traceTimings = null,
    } = payload;

    // Poll extraction: the client rides the poll as a structured attachment
    // (application/x-dirasha-poll — contact/location-card pattern) so it
    // survives the App send path untouched. It is validated here, stripped
    // from the broadcast attachments, and re-extracted at the persistence
    // boundary (db.createMessage) from the raw write-queue attachments.
    let poll: any = (payload as any).poll || null;
    let sendAttachments = attachments;
    const pollAttIndex = attachments.findIndex(
      (a: any) => a && a.mimeType === POLL_ATTACHMENT_MIME && a.poll,
    );
    if (pollAttIndex >= 0) {
      poll = attachments[pollAttIndex].poll;
      sendAttachments = attachments.filter((_: any, i: number) => i !== pollAttIndex);
    }
    if (poll) {
      poll = normalizePollPayload(poll);
      if (!poll) {
        this.sendToSocket(ws, "socket:error", {
          error: "بيانات التصويت غير صالحة (السؤال 1-200 حرفاً، الخيارات 2-10 بحد 100 حرف).",
          traceId,
        });
        return;
      }
    }

    if (traceTimings) {
      traceTimings.serverReceived = serverReceived;
    }

    if (!chatId || (!content && sendAttachments.length === 0)) {
      this.sendToSocket(ws, "socket:error", {
        error: "Incomplete properties for message creation.",
        traceId,
      });
      return;
    }

    // WS-02 (external audit): attachment URL allowlist on the WS path — the
    // REST send gate (assertAttachmentUrlsAllowed in server.ts) cannot be
    // imported here without an import-boot cycle, so this minimal mirror is
    // enforced before anything fans out. `data:` URLs are rejected outright
    // (sendGate media-rule parity); http(s) URLs must target the
    // MEDIA_HOST_ALLOWLIST hostnames or, when unset, the socket's own
    // upgrade origin (same-origin only). Everything else fails closed.
    for (const att of sendAttachments) {
      const attUrl = typeof att?.url === "string" ? att.url : null;
      if (
        attUrl &&
        !isWsAttachmentUrlAllowed(attUrl, ws.upgradeOrigin ?? null, ws.upgradeHost ?? null)
      ) {
        console.warn(
          `[WebSocketChatServer] Security Rejection: blocked attachment URL on msg:send (user ${ws.userId}, host ${attUrl.startsWith("data:") ? "data:" : (() => { try { return new URL(attUrl).hostname; } catch { return "unparseable"; } })()}).`,
        );
        this.sendToSocket(ws, "socket:error", {
          error: attUrl.startsWith("data:")
            ? "يجب رفع الملفات إلى التخزين السحابي أولاً قبل الإرسال."
            : "مضيف الوسائط غير مسموح به — استخدم التخزين السحابي المعتمد.",
          traceId,
        });
        return;
      }
    }

    // P0-hardening: bound text payload size (DB, cache and fan-out safety).
    // PQXDH (design doc §2.1): an E2EE bootstrap envelope grew ~1.1KB/device
    // (ML-KEM-768 ciphertext) — a first-message DIRM1 fan-out to 6 devices
    // measures ~20.2KB on the wire (the whole container is b64-of-JSON),
    // which busts the 8000-char gate and gets silently dropped in transit.
    // Encrypted content is opaque and still strictly bounded: DIR1:/DIRM1:/
    // DIRG1 envelopes get the dedicated E2EE ceiling (24KB — the same cap the
    // e2ee:ctrl relay already enforces); everything else keeps the 8000
    // plaintext cap. The ctrl relay cap itself is unchanged.
    const isEncryptedEnvelope =
      typeof content === "string" &&
      (content.startsWith("DIR1:") || content.startsWith("DIRM1:") || content.startsWith("DIRG1:"));
    const contentCap = isEncryptedEnvelope
      ? WebSocketChatServer.MAX_E2EE_MESSAGE_LENGTH
      : WebSocketChatServer.MAX_MESSAGE_LENGTH;
    if (typeof content === "string" && content.length > contentCap) {
      this.sendToSocket(ws, "socket:error", {
        error: `الرسالة طويلة جداً (الحد ${contentCap} حرف).`,
        traceId,
      });
      return;
    }

    // Shared enforcement gate (WS + REST): media guard, mute, ban, membership,
    // group whoCanSend, slow mode (shared limiter), member restrictions,
    // blocks and DM policy — identical semantics, single source of truth.
    try {
      await assertCanSendMessage(db, ws.userId, chatId, { attachments: sendAttachments });
    } catch (err: any) {
      if (err instanceof SendBlockedError) {
        if ((err as any).kind === "mute") {
          this.sendToSocket(ws, "moderation:mute_report", {
            chatId: (err as any).chatId || chatId,
            mutedUntil: (err as any).mutedUntil,
            reason: err.reason,
            serverTime: new Date().toISOString(),
          });
          return;
        }
        if ((err as any).kind === "ban") {
          this.sendToSocket(ws, "auth:revoked", { reason: err.reason });
          ws.terminate();
          return;
        }
        this.sendToSocket(ws, "socket:error", {
          error: err.reason,
          traceId,
        });
        return;
      }
      throw err;
    }

    // E2EE ingress policy (external-audit E2EE-03/P0-B): content entering an
    // E2EE-eligible chat must ALREADY be a wire envelope — plaintext rejected
    // server-side regardless of UI. Mirrors REST create/edit enforcement.
    try {
      await assertEncryptedIngress(db, chatId, content);
    } catch (err: any) {
      if (err instanceof E2eeRequiredError) {
        this.sendToSocket(ws, "socket:error", {
          error: err.reason,
          code: "E2EE_REQUIRED",
          traceId,
        });
        return;
      }
      if (err instanceof E2eePolicyUnavailableError) {
        this.sendToSocket(ws, "socket:error", {
          error: err.reason,
          code: "E2EE_POLICY_UNAVAILABLE",
          traceId,
        });
        return;
      }
      throw err;
    }

    // Membership-epoch gate (external-audit E2EE-01/E2EE-02): group sends must
    // declare the membership_version they were composed under. Stale/future
    // versions fail closed with the current version so the client can rotate
    // sender keys and retry once. Mirrors the REST message-create gate.
    try {
      await assertMembershipFresh(db, chatId, (payload as any).mv);
    } catch (err: any) {
      if (err instanceof MembershipStaleError) {
        this.sendToSocket(ws, "socket:error", {
          error: err.reason,
          code: "MEMBERSHIP_STALE",
          expectedVersion: (err as any).expectedVersion,
          traceId,
        });
        return;
      }
      throw err;
    }

    const [members, sender] = await Promise.all([
      db.getChatMembers(chatId),
      db.getUserById(ws.userId),
    ]);

    // Enforce strict Idempotency deduplication using Client Temporary Message ID or unique UUID
    // F17 (privacy): when no client-supplied idempotency id exists, the
    // fallback key hashes the content (SHA-256, first 10 hex chars) — the
    // first characters of message content NEVER appear in the key or in the
    // dedup log lines below.
    const dedupKey =
      tempMessageId ||
      traceId ||
      `msg-raw-${chatId}-${ws.userId}-${createHash("sha256").update(content).digest("hex").substring(0, 10)}`;
    const isUnique = await DeduplicationManager.registerEvent(dedupKey);
    if (!isUnique) {
      console.warn(
        `[WebSocketChatServer] Deduplication event caught. Retransmitting receipt payload for trace: ${dedupKey}`,
      );
      // Find matching message in database to send valid ACK info
      const list = await db.getMessagesForChat(chatId, 10);
      const matched = list.find(
        (m) => m.senderId === ws.userId && m.content === content,
      );
      if (matched) {
        this.sendToSocket(ws, "msg:ack", {
          tempMessageId,
          messageId: matched.id,
          status: "sent",
          createdAt: matched.createdAt,
          traceId,
        });
      } else {
        // Fallback: send ack anyway so client can clear its outbox queue
        this.sendToSocket(ws, "msg:ack", {
          tempMessageId,
          messageId: tempMessageId || 'fallback-id',
          status: "sent",
          createdAt: new Date().toISOString(),
          traceId,
        });
      }
      return;
    }

    // Return instant server execution receipt (ACK) directly to sending client device (FAST ACK ARCHITECTURE)
    const syntheticId = tempMessageId || "msg-" + crypto.randomUUID();
    const mockCreatedAt = new Date().toISOString();
    this.sendToSocket(ws, "msg:ack", {
      tempMessageId,
      messageId: syntheticId,
      status: "sent",
      createdAt: mockCreatedAt,
      traceId,
    });

    const ackLatency = Date.now() - serverReceived;
    DashboardStatsCollector.recordAck(ackLatency);
    // Note: slow-mode timestamp recording lives inside the shared send gate
    // (src/server/guards/sendGate.ts) so WS and REST share one limiter state.

    // Check online states of other members in the room parallelly using fast Redis lookups
    const otherMembers = members.filter((m) => m.userId !== ws.userId);
    const partnerActiveCounts = await Promise.all(
      otherMembers.map((partner) =>
        PresenceManager.getActiveConnectionsCount(partner.userId),
      ),
    );

    const onlinePartners: string[] = [];
    otherMembers.forEach((partner, idx) => {
      if (partnerActiveCounts[idx] > 0) {
        onlinePartners.push(partner.userId);
      }
    });

    let aggState: "pending" = "pending";

    // @mentions: resolve @usernames to group-member ids (WhatsApp parity —
    // mentioned users get notified even in muted chats).
    let mentionedIds: string[] = [];
    if (typeof content === "string" && content.includes("@") && members.length > 2) {
      const tokens = content.match(/@([a-zA-Z0-9_.]{3,20})/g) || [];
      const resolved = new Set<string>();
      for (const tok of tokens.slice(0, 10)) {
        const u = await db.getUserByUsername(tok.slice(1).toLowerCase());
        if (u && members.some(m => m.userId === u.id)) resolved.add(u.id);
      }
      mentionedIds = Array.from(resolved);
    }

    // Construct clean, instant, fully-populated, schema-compliant Message payload
    const instantMessage = {
      id: syntheticId,
      chatId: chatId,
      senderId: ws.userId,
      senderName: sender?.displayName || ws.username,
      sender: sender
        ? {
            id: sender.id,
            username: sender.username,
            displayName: sender.displayName,
            avatarUrl: sender.avatarUrl,
            onlineStatus: sender.onlineStatus,
            lastSeen: sender.lastSeen,
          }
        : undefined,
      content,
      type,
      attachments: sendAttachments,
      // WhatsApp parity: the poll object travels on the message itself so all
      // clients render the interactive card without extra fetches.
      poll: poll || undefined,
      createdAt: mockCreatedAt,
      // Disappearing messages: per-chat timer stamps expiry when not client-specified
      expiresAt: (payload as any).expiresAt
        ? new Date((payload as any).expiresAt).toISOString()
        : (() => {
            const timer = db.getChatDisappearingTimer(chatId);
            const ms = timer === '24h' ? 86400_000 : timer === '7d' ? 7 * 86400_000 : timer === '90d' ? 90 * 86400_000 : 0;
            return ms ? new Date(Date.now() + ms).toISOString() : null;
          })(),
      editedAt: null,
      deletedAt: null,
      reactions: {},
      starredBy: [],
      isPinned: false,
      replyTo: (payload as any).replyTo
        ? {
            id: (payload as any).replyTo.id,
            senderName: (payload as any).replyTo.senderName || "",
            content: (payload as any).replyTo.content || "",
          }
        : null,
      metadata: mentionedIds.length ? { mentions: mentionedIds } : ((payload as any).metadata || undefined),
    };

    // Generate chronological sequencing payload of envelope to avoid race-condition lags
    const enrichedMessage = {
      ...AckManager.generateOrderingEnvelope(instantMessage),
      state: aggState,
    };

    // Privacy: broadcast sender without lastSeen when its visibility != 'everyone'
    // (per-viewer 'contacts' precision is enforced on the REST profile paths).
    let broadcastSender: any = sender || undefined;
    if (broadcastSender && (broadcastSender.privacySettings?.lastSeenVisibility || 'everyone') !== 'everyone') {
      broadcastSender = { ...broadcastSender, lastSeen: undefined };
    }

    const msgNewPayload: any = {
      ...enrichedMessage,
      sender: broadcastSender,
    };
    if (traceTimings) {
      msgNewPayload.traceTimings = traceTimings;
      traceTimings.redisPubStart = Date.now();
    }

    // Publish to all targets in parallel
    const pubPromises: Promise<any>[] = [
      redisCluster.publish(`chat:${chatId}`, {
        event: "msg:new",
        payload: msgNewPayload,
      }),
    ];

    for (const memb of members) {
      pubPromises.push(
        redisCluster.publish(`user:updates:${memb.userId}`, {
          event: "msg:new",
          payload: msgNewPayload,
        }),
      );
    }

    await Promise.all(pubPromises);

    if (traceTimings) {
      traceTimings.redisPubEnd = Date.now();
    }

    // Add message write job to the resilient Background Write Queue.
    // NOTE: the RAW attachments (poll pseudo-attachment included) are kept here
    // on purpose — WriteJob has no poll field, so db.createMessage extracts the
    // poll from the structured attachment at the persistence boundary.
    BackgroundWriteQueue.enqueue({
      id: syntheticId,
      chatId,
      senderId: ws.userId,
      senderName: sender?.displayName || ws.username,
      content,
      type,
      attachments: attachments || [],
      replyTo: (payload as any).replyTo,
      metadata: mentionedIds.length ? { mentions: mentionedIds } : undefined,
      createdAt: mockCreatedAt,
      tempMessageId,
      expiresAt: (payload as any).expiresAt,
      onlinePartners,
      members,
      retryCount: 0,
    }).catch((err) => {
      console.error(
        "[WebSocketChatServer] Error enqueuing message write job:",
        err.message,
      );
    });
  }

  /**
   * Updates state to READ when user views messages
   */
  private async handleMessageRead(
    ws: ManagedWebSocket,
    payload: { chatId: string; lastMessageId: string },
    traceId?: string,
  ) {
    const { chatId, lastMessageId } = payload;
    if (!chatId || !lastMessageId) return;

    // Authorization: read receipts may only be written by chat members
    const readerMembers = await db.getChatMembers(chatId);
    if (!readerMembers.some((m) => m.userId === ws.userId)) {
      this.sendToSocket(ws, "socket:error", {
        error: "Unauthorized: You are not a member of this chat space.",
        traceId,
      });
      return;
    }

    // Privacy enforcement: readReceiptsEnabled=false → receipts never reach others
    const reader = await db.getUserById(ws.userId);
    if (reader && reader.privacySettings?.readReceiptsEnabled === false) {
      return;
    }

    const nowIso = new Date().toISOString();
    let targetCreatedAt = nowIso;

    // We must find the correct targetCreatedAt before broadcasting
    if (lastMessageId === "latest") {
      const chatMsgs = await db.getMessagesForChat(chatId, 1);
      if (chatMsgs.length > 0) {
        targetCreatedAt = chatMsgs[0].createdAt;
      }
    } else {
      const targetMessage = await db.getMessageById(lastMessageId);
      if (targetMessage) {
        targetCreatedAt = targetMessage.createdAt;
      }
    }

    // 1. Reader -> WebSocket Event -> Recipient instantly! (Fast Read Receipt)
    const stateEvent = {
      event: "msg:state:change",
      payload: {
        chatId,
        lastMessageId,
        userId: ws.userId,
        status: "read",
        updatedAt: nowIso,
        targetCreatedAt,
      },
    };
    await redisCluster.publish(`chat:${chatId}`, stateEvent);

    // ALSO broadcast to each member's private channel so they can synchronise read receipts instantly
    const members = await db.getChatMembers(chatId);
    for (const memb of members) {
      await redisCluster.publish(`user:updates:${memb.userId}`, stateEvent);
    }

    // 2. Persist to PostgreSQL asynchronously in the background
    (async () => {
      try {
        await db.bulkUpdateReadReceipts(chatId, ws.userId, targetCreatedAt);
      } catch (err: any) {
        console.error(
          "[WebSocketChatServer] Background read receipt persistence error:",
          err.message,
        );
      }
    })();
  }

  /**
   * Poll voting (WhatsApp parity): membership-checked poll vote application.
   * Applies the single/multi-choice rules via db.votePoll and broadcasts the
   * canonical updated poll as 'msg:poll:update' to the chat room plus every
   * member's private channel (mirrors the msg:edit broadcast pattern).
   */
  private async handlePollVote(
    ws: ManagedWebSocket,
    payload: { chatId: string; messageId: string; optionIndexes: number[] },
    traceId?: string,
  ) {
    const { chatId, messageId, optionIndexes } = payload || ({} as any);
    if (!chatId || !messageId || !Array.isArray(optionIndexes)) {
      this.sendToSocket(ws, "socket:error", {
        error: "Incomplete properties for poll voting.",
        traceId,
      });
      return;
    }

    // Authorization: only chat members may vote (same pattern as msg:read)
    const members = await db.getChatMembers(chatId);
    if (!members.some((m: any) => m.userId === ws.userId)) {
      this.sendToSocket(ws, "socket:error", {
        error: "Unauthorized: You are not a member of this chat space.",
        traceId,
      });
      return;
    }

    const updated = await db.votePoll(chatId, messageId, ws.userId, optionIndexes);
    if (!updated) {
      this.sendToSocket(ws, "socket:error", {
        error: "تعذر تسجيل التصويت — قد تكون الرسالة محذوفة أو ليست تصويتاً.",
        traceId,
      });
      return;
    }

    const pollUpdateEvent = {
      event: "msg:poll:update" as any,
      payload: { chatId, messageId, poll: updated },
    };

    const pubPromises: Promise<any>[] = [
      redisCluster.publish(`chat:${chatId}`, pollUpdateEvent),
    ];
    for (const memb of members) {
      pubPromises.push(
        redisCluster.publish(`user:updates:${memb.userId}`, pollUpdateEvent),
      );
    }
    await Promise.all(pubPromises);
  }

  /**
   * Process client verification statement that message is delivered successfully
   */
  private async handleMessageDelivered(
    ws: ManagedWebSocket,
    payload: { chatId: string; messageId: string },
    traceId?: string,
  ) {
    const { chatId, messageId } = payload;
    if (!chatId || !messageId) return;

    // Authorization: delivery receipts may only be written by chat members
    // (the receipt is always attributed to ws.userId itself).
    const receiptMembers = await db.getChatMembers(chatId);
    if (!receiptMembers.some((m) => m.userId === ws.userId)) {
      this.sendToSocket(ws, "socket:error", {
        error: "Unauthorized: You are not a member of this chat space.",
        traceId,
      });
      return;
    }

    try {
      await AckManager.updateReceipt(chatId, messageId, ws.userId, "delivered");
    } catch (err: any) {
      console.error(
        "[WebSocketChatServer] handleMessageDelivered error:",
        err.message,
      );
    }
  }

  /**
   * Process manual presence status adjustments (online, offline, away)
   */
  private async handlePresenceStatusChange(
    ws: ManagedWebSocket,
    status: PresenceStatus,
    traceId?: string,
  ) {
    if (!status || !["online", "offline", "away"].includes(status)) {
      this.sendToSocket(ws, "socket:error", {
        error: "Invalid user status target.",
        traceId,
      });
      return;
    }
    await PresenceManager.updateUserStatus(ws.userId, status);
  }

  /**
   * Ephemeral Bandwidth-Optimized Typing Broker (No Database Writes)
   */
  private async handlePresenceTyping(
    ws: ManagedWebSocket,
    chatId: string,
    isTyping: boolean,
    traceId?: string,
  ) {
    if (!chatId) return;

    // Authorization: typing signals may only be broadcast by chat members
    const typingMembers = await db.getChatMembers(chatId);
    if (!typingMembers.some((m) => m.userId === ws.userId)) {
      this.sendToSocket(ws, "socket:error", {
        error: "Unauthorized: You are not a member of this chat space.",
        traceId,
      });
      return;
    }

    // Channels are one-way broadcast spaces (Telegram parity): typing
    // indicators make no sense there, so they are dropped entirely — even for
    // owner/admin posters. Cheap in-memory chat-type lookup, no extra I/O.
    if (db.getChatType(chatId) === "channel") {
      return;
    }

    // Privacy enforcement: user's typingIndicatorEnabled=false → signals are dropped
    const typer = await db.getUserById(ws.userId);
    if (typer && typer.privacySettings?.typingIndicatorEnabled === false) {
      return;
    }

    if (isTyping) {
    } else {
    }

    if (!this.typingCache.has(chatId)) {
      this.typingCache.set(chatId, new Map());
    }

    const roomTypers = this.typingCache.get(chatId)!;

    // Clear previous debouncing timer
    if (roomTypers.has(ws.userId)) {
      clearTimeout(roomTypers.get(ws.userId)!.timer);
      roomTypers.delete(ws.userId);
    }

    const userObj = await db.getUserById(ws.userId);
    const displayName = userObj?.displayName || ws.username;

    if (isTyping) {
      // Configure ephemeral 4-second auto-expiration sweep to prevent frozen indicators
      const timer = setTimeout(async () => {
        roomTypers.delete(ws.userId);
        await this.broadcastTyping(chatId, ws.userId, displayName, false);
      }, 4000);

      roomTypers.set(ws.userId, { displayName, timer });
      await this.broadcastTyping(chatId, ws.userId, displayName, true);
    } else {
      await this.broadcastTyping(chatId, ws.userId, displayName, false);
    }
  }

  /**
   * Dispatches the typing event to the cluster
   */
  private async broadcastTyping(
    chatId: string,
    userId: string,
    displayName: string,
    isTyping: boolean,
  ) {
    const eventData = {
      event: "presence:typing",
      payload: {
        chatId,
        userId,
        displayName,
        isTyping,
      },
    };
    if (isTyping) {
    }
    await redisCluster.publish(`chat:${chatId}`, eventData);

    const members = await db.getChatMembers(chatId);
    for (const memb of members) {
      await redisCluster.publish(`user:updates:${memb.userId}`, eventData);
    }
  }

  /**
   * Transitions 'sent' state messages to 'delivered' status on reconnection
   */
  private async syncPendingMessagesDeliveryOnConnect(userId: string) {
    try {
      const updatedReceipts = await db.syncPendingReceipts(userId);
      if (updatedReceipts.length === 0) return;

      console.log(
        `[WebSocketChatServer] Bulk synchronized pending message receipts for user ${userId}. Updated: ${updatedReceipts.length} rows.`,
      );

      // Group updated receipts by chatId to reduce notifications overhead
      const chatGroup = new Map<string, string[]>();
      for (const item of updatedReceipts) {
        if (!chatGroup.has(item.chatId)) {
          chatGroup.set(item.chatId, []);
        }
        chatGroup.get(item.chatId)!.push(item.messageId);
      }

      for (const [chatId, messageIds] of chatGroup.entries()) {
        const lastMessageId = messageIds[messageIds.length - 1];

        const eventData = {
          event: "msg:state:change",
          payload: {
            chatId,
            lastMessageId,
            userId,
            status: "delivered",
            updatedAt: new Date().toISOString(),
          },
        };

        // Publish to Redis so other server instances or scaling units are aware
        await redisCluster.publish(`chat:${chatId}`, eventData);

        // Notify matching members
        const members = await db.getChatMembers(chatId);
        for (const memb of members) {
          await redisCluster.publish(`user:updates:${memb.userId}`, eventData);
        }
      }
    } catch (err: any) {
      console.error(
        "[WebSocketChatServer] Error in syncPendingMessagesDeliveryOnConnect:",
        err.message,
      );
    }
  }

  /**
   * Gracefully close and unregister user sockets on physical connection breaks
   */
  private async handleSocketDisconnect(ws: ManagedWebSocket) {
    if (ws.pongTimeoutTimer) {
      clearTimeout(ws.pongTimeoutTimer);
      ws.pongTimeoutTimer = undefined;
    }
    const userId = ws.userId;
    const connections = this.userConnections.get(userId);

    if (connections) {
      connections.delete(ws);
      if (connections.size === 0) {
        this.userConnections.delete(userId);

        // P0-hardening: release this user's event-budget buckets (no leak on full disconnect)
        for (const key of this.eventBuckets.keys()) {
          if (key.startsWith(userId + ':')) this.eventBuckets.delete(key);
        }

        // Unsubscribe from Redis user channel since no active connections remain for this user on this node
        const redisChannel = `user:updates:${userId}`;
        const unsub = this.redisUnsubscribers.get(redisChannel);
        if (unsub) {
          unsub();
          this.redisUnsubscribers.delete(redisChannel);
        }
      }
    }

    // Instantly delete this socket-specific tracking key and evaluate remaining global connections globally
    await PresenceManager.registerUserOffline(userId, ws.id, () => {
      console.log(
        `[WebSocketChatServer] Session disconnected: User ${userId} is now completely offline.`,
      );
    });

    // Sweep any active calls associated with this disconnecting socket session
    for (const [callId, call] of this.activeCalls.entries()) {
      if (call.callerId === userId || call.calleeId === userId) {
        const partnerId =
          call.callerId === userId ? call.calleeId : call.callerId;
        if (call.ringTimer) clearTimeout(call.ringTimer);
        this.activeCalls.delete(callId);

        // Notify the remaining partner that the call has ended due to sudden disconnect
        await redisCluster.publish(`user:updates:${partnerId}`, {
          event: "call:end",
          payload: {
            callId,
            senderId: userId,
            reason: "disconnected",
          },
        });
        console.log(
          `[CallManager] Cleaning call ${callId} because client ${userId} closed connection.`,
        );
      }
    }

    // console.log(`[WebSocketChatServer] Session closed for [ConnID: ${ws.id}]. Remaining connection channels on this node for user ${ws.username}: ${connections?.size || 0}`);
  }

  private async handleCallInitiate(
    ws: ManagedWebSocket,
    payload: any,
    traceId?: string,
  ) {
    const { callId, calleeId, offer, type } = payload || {};
    if (!callId || !calleeId || !offer) {
      this.sendToSocket(ws, "socket:error", {
        error: "Incomplete parameters for call initiation.",
        traceId,
      });
      return;
    }

    const caller = await db.getUserById(ws.userId);
    if (caller?.mutedUntil && new Date(caller.mutedUntil) > new Date()) {
      this.sendToSocket(ws, "moderation:mute_report", {
        reason:
          caller.muteReason ||
          "Your account is restricted from initiating calls.",
      });
      return;
    }
    if (caller?.isBanned) {
      this.sendToSocket(ws, "auth:revoked", {
        reason: caller.banReason || "Your account has been banned.",
      });
      ws.terminate();
      return;
    }

    // Silence unknown callers (WhatsApp parity): callee's privacy gates apply
    const callee = await db.getUserById(calleeId);
    if (callee) {
      const calleeSettings = (callee as any).privacySettings || {};
      if (calleeSettings.silenceUnknownCallers === true) {
        const calleeContacts = await db.getContacts(calleeId);
        if (!calleeContacts.includes(ws.userId)) {
          this.sendToSocket(ws, "call:rejected", {
            callId,
            reason: "المستخدم لا يستقبل مكالمات من غير جهات اتصاله.",
          } as any);
          return;
        }
      }
      // DM policy also governs calls when set to nobody
      if (String(calleeSettings.allowDirectMessages || 'everyone') === 'nobody') {
        this.sendToSocket(ws, "call:rejected", {
          callId,
          reason: "المستخدم لا يستقبل مكالمات.",
        } as any);
        return;
      }
    }

    // Blocks: a blocked pair cannot call each other (isBlocked is symmetric)
    if (await db.isBlocked(calleeId, ws.userId)) {
      this.sendToSocket(ws, "call:rejected", {
        callId,
        reason: "لا يمكنك الاتصال بهذا المستخدم.",
      } as any);
      return;
    }

    // Register active call state
    this.activeCalls.set(callId, {
      callId,
      callerId: ws.userId,
      calleeId,
      type,
      startedAt: Date.now(),
    });

    // Call log (Calls tab): entry for both parties
    const callerUser = await db.getUserById(ws.userId);
    const calleeUser = await db.getUserById(calleeId);
    const callType = type || "voice";
    db.addCallLogEntry(ws.userId, { callId, withUserId: calleeId, withName: calleeUser?.displayName || calleeId, callType, direction: "outgoing", status: "ringing" });
    db.addCallLogEntry(calleeId, { callId, withUserId: ws.userId, withName: callerUser?.displayName || ws.userId, callType, direction: "incoming", status: "ringing" });

    // T3: never ring an offline callee — fail fast and mark both log entries missed
    const calleeActiveConnections = await PresenceManager.getActiveConnectionsCount(calleeId);
    if (calleeActiveConnections === 0) {
      console.log(
        `[CallManager] Call ${callId} aborted: callee ${calleeId} is offline (no active connections).`,
      );
      this.activeCalls.delete(callId);
      db.finalizeCallLog(callId, "missed-offline");
      this.sendToSocket(ws, "call:rejected", {
        callId,
        reason: "المستخدم غير متصل حالياً.",
      } as any);
      return;
    }

    // T3: ring timeout — unanswered calls are finalized as missed after RING_TIMEOUT
    const RING_TIMEOUT = Number(process.env.CALL_RING_TIMEOUT_MS) || 45000;
    const ringTimer = setTimeout(() => {
      const entry = this.activeCalls.get(callId);
      if (!entry) return; // answered or ended before the timeout fired
      console.log(
        `[CallManager] Call ${callId} rang out with no answer after ${RING_TIMEOUT}ms — finalizing as missed.`,
      );
      this.activeCalls.delete(callId);
      db.finalizeCallLog(callId, "missed");
      (async () => {
        await redisCluster.publish(`user:updates:${entry.callerId}`, {
          event: "call:end",
          payload: { callId, reason: "no-answer" },
        });
        await redisCluster.publish(`user:updates:${entry.calleeId}`, {
          event: "call:end",
          payload: { callId, reason: "no-answer" },
        });
        await redisCluster.publish(`user:updates:${entry.calleeId}`, {
          event: "call:missed",
          payload: { callId, callerName: entry.callerName },
        });
      })().catch((err: any) => {
        console.error("[CallManager] Ring timeout fan-out error:", err.message);
      });
    }, RING_TIMEOUT);

    const callEntry = this.activeCalls.get(callId);
    if (callEntry) {
      callEntry.ringTimer = ringTimer;
      callEntry.callerName = callerUser?.displayName || ws.username;
    }

    // Publish to callee private stream
    await redisCluster.publish(`user:updates:${calleeId}`, {
      event: "call:initiate",
      payload: {
        callId,
        callerId: ws.userId,
        callerName: ws.username,
        offer,
        type: type || "voice",
      },
    });
    console.log(
      `[CallManager] Call ${callId} initiated: ${ws.userId} -> ${calleeId} (Type: ${type || "voice"})`,
    );

    // Under remote mobile networks or locked screens, the target's socket is disconnected.
    // Trigger an immediate, high-priority system Web Push notification to wake up the service worker.
    try {
      const pushTitle =
        type === "video" ? "مكالمة فيديو واردة" : "مكالمة صوتية واردة";
      const pushBody = `اتصال وارد من ${ws.username}...`;
      await WebPushService.sendPush(calleeId, pushTitle, pushBody, {
        category: "call",
        callId,
        callerId: ws.userId,
        callerName: ws.username,
        callType: type || "voice",
      });
      console.log(
        `[CallManager] Dispatched immediate call push notification to offline/sleeping device of user: ${calleeId}`,
      );
    } catch (pushErr: any) {
      console.warn(
        "[CallManager] Call push notification bypassed/unregistered:",
        pushErr.message,
      );
    }
  }

  private async handleCallRespond(
    ws: ManagedWebSocket,
    payload: any,
    traceId?: string,
  ) {
    const { callId, callerId, accepted, answer, reason } = payload || {};
    if (!callId || !callerId) return;

    // Authorization: only the callee of a live call may respond to it, and the
    // claimed caller must match the registered caller of that call.
    const respondingEntry = this.activeCalls.get(callId);
    if (
      !respondingEntry ||
      respondingEntry.calleeId !== ws.userId ||
      respondingEntry.callerId !== callerId
    ) {
      console.log(
        `[CallManager] Forged respond rejected: user ${ws.userId} attempted to respond to call ${callId} (claimed caller ${callerId}).`,
      );
      this.sendToSocket(ws, "socket:error", {
        error: "[CallManager] Forged respond rejected.",
        traceId,
      });
      return;
    }

    // T3: the ring timeout is obsolete once the callee has responded
    if (respondingEntry?.ringTimer) {
      clearTimeout(respondingEntry.ringTimer);
      respondingEntry.ringTimer = undefined;
    }

    if (!accepted) {
      this.activeCalls.delete(callId);
    }

    // Publish acceptance details back to caller's stream
    await redisCluster.publish(`user:updates:${callerId}`, {
      event: "call:respond",
      payload: {
        callId,
        calleeId: ws.userId,
        accepted,
        answer,
        reason,
      },
    });
    console.log(
      `[CallManager] Call ${callId} respond: Callee ${ws.userId} -> Accepted: ${accepted}`,
    );
  }

  private async handleCallSignal(
    ws: ManagedWebSocket,
    payload: any,
    traceId?: string,
  ) {
    const { callId, receiverId, signal } = payload || {};
    if (!callId || !receiverId || !signal) return;

    // Authorization: signals may only flow between the two parties of a live
    // call — sender must be caller or callee, and receiverId must be the OTHER
    // party (never a third user, never self).
    const signalEntry = this.activeCalls.get(callId);
    const otherParty = signalEntry
      ? signalEntry.callerId === ws.userId
        ? signalEntry.calleeId
        : signalEntry.callerId
      : undefined;
    if (
      !signalEntry ||
      (ws.userId !== signalEntry.callerId && ws.userId !== signalEntry.calleeId) ||
      receiverId !== otherParty
    ) {
      console.log(
        `[CallManager] Unauthorized signal dropped: user ${ws.userId} -> ${receiverId} (call ${callId}).`,
      );
      this.sendToSocket(ws, "socket:error", {
        error: "[CallManager] Unauthorized signal dropped.",
        traceId,
      });
      return;
    }

    // Relay candidates / intermediate signaling payload to the recipient user stream
    await redisCluster.publish(`user:updates:${receiverId}`, {
      event: "call:signal",
      payload: {
        callId,
        senderId: ws.userId,
        signal,
      },
    });
  }

  private async handleCallEnd(
    ws: ManagedWebSocket,
    payload: any,
    traceId?: string,
  ) {
    const { callId, receiverId, reason } = payload || {};
    if (!callId) return;

    // Authorization: only a party of the live call may terminate it and
    // finalize its call logs.
    const endingEntry = this.activeCalls.get(callId);
    if (
      !endingEntry ||
      (ws.userId !== endingEntry.callerId && ws.userId !== endingEntry.calleeId)
    ) {
      console.log(
        `[CallManager] Unauthorized call end dropped: user ${ws.userId} attempted to end call ${callId}.`,
      );
      this.sendToSocket(ws, "socket:error", {
        error: "[CallManager] Unauthorized call end dropped.",
        traceId,
      });
      return;
    }

    // T3: clear any pending ring timeout for this call
    if (endingEntry?.ringTimer) {
      clearTimeout(endingEntry.ringTimer);
      endingEntry.ringTimer = undefined;
    }
    this.activeCalls.delete(callId);
    db.finalizeCallLog(callId, reason);

    if (receiverId) {
      await redisCluster.publish(`user:updates:${receiverId}`, {
        event: "call:end",
        payload: {
          callId,
          senderId: ws.userId,
          reason,
        },
      });
    }
    console.log(`[CallManager] Call ${callId} ended by user ${ws.userId}`);
  }

  /* ── Group-call signaling (mesh relay, ≤4 participants) ──────────────
   * The 1:1 call:signal relay authorizes against the activeCalls registry
   * (caller/callee pair only), so group calls cannot ride it. These handlers
   * mirror its relay pattern but authorize against the in-memory
   * groupCallSessions registry: the sender AND the target must both be
   * current participants of the live session.
   */

  /** Relay one WebRTC offer/answer/ICE payload between two session participants. */
  private async handleGroupCallSignal(
    ws: ManagedWebSocket,
    payload: any,
    traceId?: string,
  ) {
    const { groupCallId, receiverId, signal } = payload || {};
    if (!groupCallId || !receiverId || !signal) return;
    if (receiverId === ws.userId) return;

    const session = getGroupCall(groupCallId);
    if (
      !session ||
      !session.participants.has(ws.userId) ||
      !session.participants.has(receiverId)
    ) {
      console.log(
        `[GroupCallManager] Unauthorized group signal dropped: user ${ws.userId} -> ${receiverId} (session ${groupCallId}).`,
      );
      this.sendToSocket(ws, "socket:error", {
        error: "[GroupCallManager] Unauthorized group signal dropped.",
        traceId,
      });
      return;
    }

    await redisCluster.publish(`user:updates:${receiverId}`, {
      event: "groupcall:signal",
      payload: {
        groupCallId,
        senderId: ws.userId,
        signal,
      },
    });
  }

  /** One-shot invite: initiator announces a freshly-created session to chat members. */
  private async handleGroupCallAnnounce(
    ws: ManagedWebSocket,
    payload: any,
    traceId?: string,
  ) {
    const { groupCallId, chatId, callType, chatName, initiatorName } = payload || {};
    if (!groupCallId || !chatId) return;

    const session = getGroupCall(groupCallId);
    if (!session || session.chatId !== chatId || !session.participants.has(ws.userId)) {
      console.log(
        `[GroupCallManager] Unauthorized group announce dropped: user ${ws.userId} (session ${groupCallId}).`,
      );
      return;
    }

    const members = await db.getChatMembers(chatId);
    const eventData = {
      event: "groupcall:invite",
      payload: {
        groupCallId,
        chatId,
        chatName: chatName || '',
        callType: callType === "video" ? "video" : "voice",
        initiatorId: ws.userId,
        initiatorName: initiatorName || ws.username,
      },
    };
    for (const member of members) {
      if (member.userId === ws.userId) continue;
      await redisCluster.publish(`user:updates:${member.userId}`, eventData);
    }
    console.log(
      `[GroupCallManager] Session ${groupCallId} announced to chat ${chatId} by ${ws.userId}`,
    );
  }

  /** Presence: a participant joined → existing participants learn to dial them. */
  private async handleGroupCallJoined(
    ws: ManagedWebSocket,
    payload: any,
    traceId?: string,
  ) {
    const { groupCallId } = payload || {};
    if (!groupCallId) return;

    const session = getGroupCall(groupCallId);
    if (!session || !session.participants.has(ws.userId)) return;

    for (const participantId of Array.from(session.participants.keys())) {
      if (participantId === ws.userId) continue;
      await redisCluster.publish(`user:updates:${participantId}`, {
        event: "groupcall:peer-joined",
        payload: { groupCallId, userId: ws.userId },
      });
    }
  }

  /** Presence: a participant is leaving → remaining participants tear down that peer's PC. */
  private async handleGroupCallLeave(
    ws: ManagedWebSocket,
    payload: any,
    traceId?: string,
  ) {
    const { groupCallId } = payload || {};
    if (!groupCallId) return;

    const session = getGroupCall(groupCallId);
    if (!session || !session.participants.has(ws.userId)) return;

    const remaining = Array.from(session.participants.keys()).filter(
      (id) => id !== ws.userId,
    );
    leaveGroupCall(groupCallId, ws.userId); // idempotent roster update (REST leave also calls this)

    for (const participantId of remaining) {
      await redisCluster.publish(`user:updates:${participantId}`, {
        event: "groupcall:peer-left",
        payload: { groupCallId, userId: ws.userId },
      });
    }
    console.log(
      `[GroupCallManager] User ${ws.userId} left group session ${groupCallId} (${remaining.length} remaining).`,
    );
  }

  /* ── E2EE control-message relay (group Sender-Keys distribution) ──────
   * Client→Server 'e2ee:ctrl' carries { toUserId, groupId, payload } where
   * `payload` is an OPAQUE pairwise-encrypted 'DIR1:...' envelope string
   * produced by the client's 1:1 engine. The server is a DUMB RELAY: it
   * never parses or decrypts the envelope — only size-checks and authz-gates
   * it. No database persistence; the relay rides the existing per-user
   * fan-out mechanism (Redis `user:updates:<userId>` publish → every socket
   * of the recipient on every server instance), exactly like call/groupcall
   * signaling.
   *
   * NOTE FOR CLIENT AGENT — member-removal event: when a member is removed
   * from (or leaves) a group chat, clients are notified via the
   * 'chat:evicted' event on the socket (see the `user:updates:*`
   * subscription handler in setupConnectionHandler above, which also strips
   * the room from the socket's activeChatRooms; the client listener lives in
   * src/App.tsx). That is the trigger for sender-key rotation on removal.
   * This event is documented here only — it is intentionally NOT modified.
   */
  private async handleE2eeCtrl(
    ws: ManagedWebSocket,
    payload: { toUserId?: string; groupId?: string; payload?: string },
    traceId?: string,
  ) {
    console.info('[E2EE] ctrl frame REACHED handler from', ws.userId, 'to=', payload && payload.toUserId, 'len=', String((payload && payload.payload) || '').length);
    const { toUserId, groupId, payload: envelope } = payload || ({} as any);

    // Schema + size caps. The envelope stays opaque: string type and length
    // only — no prefix check, no JSON parse, no crypto.
    if (
      typeof toUserId !== "string" || toUserId.length === 0 || toUserId.length > 128 ||
      typeof groupId !== "string" || groupId.length === 0 || groupId.length > 128 ||
      typeof envelope !== "string" || envelope.length === 0 ||
      // Dedicated relay cap (3x message cap): multi-device DIRM1 fan-out
      // carries one bootstrap-heavy envelope per target device (~1KB each x 8)
      // — the 8KB message cap silently dropped fleet-wide distributions.
      envelope.length > WebSocketChatServer.MAX_MESSAGE_LENGTH * 3
    ) {
      this.sendToSocket(ws, "socket:error", {
        error: "Invalid e2ee:ctrl relay parameters.",
        traceId,
      });
      return;
    }

    // AUTHZ (critical): the sender AND the recipient must both be active
    // members of the same chat — same membership source of truth as the
    // msg:send path (db.getChatMembers, mirrored from sendGate.ts). On
    // violation: silent drop, log-only (no detail leaks back to the sender).
    const members = await db.getChatMembers(groupId);
    if (
      !members.some((m: any) => m.userId === ws.userId) ||
      !members.some((m: any) => m.userId === toUserId)
    ) {
      // Log-injection hardening: strip control chars from client-supplied ids
      // before they reach log output (adversarial-audit finding #9).
      const safeGroup = String(groupId).replace(/[^\x20-\x7E]/g, '');
      console.warn(
        `[E2EE] ctrl authz drop: user ${ws.userId} -> ${toUserId} (group ${safeGroup}).`,
      );
      return;
    }

    // Targeted fan-out to ALL of the recipient's active sockets across all
    // server instances via the Redis user channel (same mechanism as
    // call:signal / groupcall:signal). The recipient's `user:updates:*`
    // subscription delivers 'e2ee:ctrl' to each of their local sockets.
    await redisCluster.publish(`user:updates:${toUserId}`, {
      event: "e2ee:ctrl",
      payload: {
        fromUserId: ws.userId,
        groupId,
        payload: envelope,
      },
    });

    console.log(
      `[E2EE] ctrl relayed ${ws.userId}→${toUserId} (group ${groupId}, ${envelope.length} bytes)`,
    );
  }

  /**
   * Helper module to send packet payloads safely downstream
   */
  // Perf: fan-out reuses the SAME payload object across all member channels.
  // Cache the serialized frame per payload reference (WeakMap → GC-safe) so a
  // group broadcast serializes ONCE instead of once-per-recipient.
  private frameCache = new WeakMap<object, { event: string; raw: string }>();

  private sendToSocket<T = any>(
    ws: WebSocket,
    event: ServerToClientEvent | string,
    payload: T,
  ) {
    if (ws.readyState === WebSocket.OPEN) {
      try {
        let raw: string;
        const cached = typeof payload === 'object' && payload !== null
          ? this.frameCache.get(payload as object)
          : undefined;
        if (cached && cached.event === event) {
          raw = cached.raw;
        } else {
          raw = JSON.stringify({ event, payload });
          if (typeof payload === 'object' && payload !== null) {
            this.frameCache.set(payload as object, { event, raw });
          }
        }
        ws.send(raw);
      } catch (err: any) {
        console.error(
          "[WebSocketChatServer] Transmission Failure:",
          err.message,
        );
      }
    }
  }
}

export default WebSocketChatServer;
