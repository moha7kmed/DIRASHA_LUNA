/**
 * BATCH-1 regression tests (DIR-2026-001 / 010p / 006 / AB-09).
 *
 * Static source asserts over the remediation changes so a future edit cannot
 * silently regress the identity/broadcast/wipe hardening:
 *   b1-1  mapUserRow never derives privilege from username (no isTargetAdmin).
 *   b1-2  createPasswordUser ALWAYS creates role 'user'.
 *   b1-3  requireAdmin/kt gate read the DURABLE role from DB (no ADMIN_USERNAMES
 *         matching, no promotion).
 *   b1-4  requireModerator has no auto-promotion side effect.
 *   b1-5  Role minting to admin/developer requires callerRole==='developer'.
 *   b1-6  Registration + rename REJECT operator handles (isAdminReservedName).
 *   b1-7  Bootstrap endpoint: secret-gated, one-time marker, timing-safe.
 *   b1-8  reset-database: timing-safe secret compare + explicit confirm + rate
 *         limit + audit line before wipe.
 *   b1-9  Global broadcasts carry the public projection only (no passcode/ban/
 *         lastSeen on presence channels).
 */
import { describe, it, expect } from 'vitest';
import { readFileSync } from 'fs';
import path from 'path';

const repo = path.resolve(__dirname, '..');
const read = (p: string) => readFileSync(path.join(repo, p), 'utf8');

describe('BATCH-1 remediation (DIR-2026-001/010p/006/AB-09)', () => {
  it('b1-1 mapUserRow: no username-based privilege derivation', () => {
    const db = read('src/server/database.ts');
    expect(db).not.toMatch(/isTargetAdmin/);
    expect(db).not.toMatch(/isTargetAdmin \? true/);
    expect(db).toMatch(/role is the durable DB column ONLY/);
  });

  it('b1-2 createPasswordUser: public registration always role user', () => {
    const db = read('src/server/database.ts');
    expect(db).toMatch(/public registration ALWAYS creates a plain user/);
    expect(db).not.toMatch(/isAdminName \? 'developer'/);
  });

  it('b1-3 requireAdmin + kt gate: durable role from DB, no username matching', () => {
    const srv = read('server.ts');
    expect(srv).toMatch(/admin gate is the DURABLE role only/);
    const kt = read('src/server/routes/kt.ts');
    expect(kt).toMatch(/identity = the DURABLE role read fresh from the DB/);
    // The env-name matching pattern must be gone from both gates
    const gateRegion = srv.slice(srv.indexOf('admin gate is the DURABLE role only'), srv.indexOf('admin gate is the DURABLE role only') + 900);
    expect(gateRegion).not.toMatch(/ADMIN_USERNAMES/);
  });

  it('b1-4 requireModerator: no auto-promotion side effect', () => {
    const srv = read('server.ts');
    expect(srv).not.toMatch(/are always promoted to developer role/);
    expect(srv).toMatch(/NO promotion side effect on read/);
  });

  it('b1-5 role minting: developer-only mint of admin/developer', () => {
    const srv = read('server.ts');
    expect(srv).toMatch(/only the durable 'developer' role may mint/);
    expect(srv).not.toMatch(/callerIsEnvAdmin/);
  });

  it('b1-6 registration and rename reject operator handles', () => {
    const auth = read('src/server/routes/authClassic.ts');
    expect(auth).toMatch(/isAdminReservedName\(cleanUsername\)/);
    const srv = read('server.ts');
    expect(srv).toMatch(/isAdminReservedName\(clean\) && clean !== current\?\.username/);
  });

  it('b1-7 bootstrap operator endpoint: gated, one-time, audited', () => {
    const srv = read('server.ts');
    expect(srv).toMatch(/api\/admin\/bootstrap-operator/);
    expect(srv).toMatch(/OPERATOR_BOOTSTRAP_SECRET/);
    expect(srv).toMatch(/timingSafeEqual/);
    expect(srv).toMatch(/Operator bootstrap already consumed/);
    expect(srv).toMatch(/OPERATOR-BOOTSTRAP/);
  });

  it('b1-8 reset-database: timing-safe + confirm + limiter + audit', () => {
    const srv = read('server.ts');
    const region = srv.slice(srv.indexOf('/api/admin/reset-database'), srv.indexOf('/api/admin/reset-database') + 3400);
    expect(region).toMatch(/timingSafeEqual/);
    expect(region).toMatch(/RESET-DIRASHA/);
    expect(region).toMatch(/admin:wipe/);
    expect(region).toMatch(/AUDIT\]\[RESET-DATABASE/);
  });

  it('b1-9 global broadcasts: public projection only', () => {
    const srv = read('server.ts');
    expect(srv).toMatch(/GLOBAL broadcast carries the public-surface/);
    expect(srv).not.toMatch(/payload: \{ userId, user: enrichedUser \}/);
    const pm = read('src/server/websocket/presence_manager.ts');
    expect(pm).toMatch(/lastSeen is NEVER included in the global/);
    const fn = pm.slice(pm.indexOf('broadcastPresence'), pm.indexOf('broadcastPresence') + 500);
    expect(fn).not.toMatch(/lastSeen/);
  });

  it('b1-10 database.ts compiles against its own invariants (mapUserRow role path)', () => {
    const db = read('src/server/database.ts');
    expect(db).toMatch(/role: row\.role && row\.role !== 'user' \? row\.role : 'user'/);
  });
});
