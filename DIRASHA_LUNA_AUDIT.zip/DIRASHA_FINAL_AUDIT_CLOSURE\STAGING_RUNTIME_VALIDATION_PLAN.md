# STAGING RUNTIME VALIDATION PLAN — DIRASHA @ 4c8824a

**البيئة المطلوبة:** staging معزول تمامًا — PostgreSQL فعلي + Redis فعلي + reverse proxy (nginx/Caddy) + server runtime + **instance ثانٍ** لاختبارات التعدد. صفر بيانات حقيقية؛ حسابات اصطناعية فقط. ممنوع الاتصال بأي إنتاج.
**قاعدة التشغيل:** كل اختبار = أمر/إجراء موثق + دليل محفوظ (log/DB snapshot/screenshot) + معيار فشل صريح + شرط rollback. **أي فشل = توقف الخطة ومعالجة قبل المتابعة.**

## 0. تجهيز البيئة (Pre-flight)
- Deploy من ZIP النظيف (`dirasha-4c8824a-clean.zip`) أو checkout `4c8824a` — **بلا أي قيمة من ملفات `deploy/*` القديمة** (أسرار جديدة كليًا).
- Env: `NODE_ENV=production`, `PG_CA_CERT` (CA جديد), `PG_REQUIRE_DB_TLS=1`, `REDIS_URL`, `JWT_SECRET/COOKIE_SECRET/AUTH_PEPPER` جديدة, `OPERATOR_BOOTSTRAP_SECRET` مؤقت, `KT_SIGNING_KEY` + `VITE_KT_WITNESS_PUB`, `TRUST_PROXY_HOPS=1`, `ALLOWED_ORIGINS` نطاق staging.
- Instances: A وB خلف proxy (للاختبارات 15a/15b).

---

## الاختبارات الـ18

### 1. Clean boot
- **Pre:** قاعدة PG فارغة، Redis فارغ، لا snapshot محلي.
- **Expected:** boot يكتمل؛ `[DB-TLS] mode=verified`؛ migrations 1-13 تُطبق؛ `[Boot Config] PASSED`؛ لا CRITICAL memory-write logs.
- **Evidence:** boot log كامل + `\dt` في PG (جداول الترحيلات موجودة).
- **Fail:** أي FATAL غير متوقع / وضع memory في production / TLS unverified.
- **Rollback:** إيقاف، تصحيح env، إعادة boot (لا بيانات للفقد).

### 2. Database TLS fail-closed
- **Pre:** boot سليم (اختبار 1).
- **Expected:** إعادة boot بـ `PG_REQUIRE_DB_TLS=1` + CA فاسد → **exit(1)** مع `[DB-TLS] FATAL`؛ boot بـ PG متوقف → **exit(1)** DATA-01 FATAL.
- **Evidence:** سجلّا boot (نجاح/فشل) + exit codes.
- **Fail:** أي استمرار تشغيل بـ unverified أو fallback memory في production.
- **Rollback:** غير مطلوب (فشل مغلق = السلوك الصحيح).

### 3. Redis failure behavior
- **Pre:** تشغيل عادي + عميل متصل.
- **Expected:** إيقاف Redis → rate limiting الحرجة **ترفض (429)** لا تتجاهل؛ presence يتدهور بصمت موثق؛ Redis يعود → الاستعادة دون فقد.
- **Evidence:** log الـ limiter أثناء العطل + محاولة login أثناءه (429) + سجل الاستعادة.
- **Fail:** أي 200 login أثناء عطل Redis بقواعد critical.
- **Rollback:** استعادة Redis؛ إعادة تشغيل الاختبار.

### 4. Operator bootstrap
- **Pre:** مستخدم اختباري `stg-op-1` مسجل بجهاز حقيقي؛ `OPERATOR_BOOTSTRAP_SECRET` مضبوط.
- **Expected:** استدعاء `/api/admin/bootstrap-operator` بالسر الصحيح → 200 + role=developer في DB؛ **استدعاء ثانٍ (نفس المستخدم أو آخر) → 403 consumed**؛ سر خاطئ → 403؛ env محذوف → 404؛ صف `operator-bootstrap` في system_api_keys؛ سجل audit موجود.
- **Evidence:** 4 استجابات HTTP + صف DB + logAuthAction row.
- **Fail:** أي 200 ثانٍ / ترقية بلا سر / غياب marker.
- **Rollback:** delete صف الـ marker + إعادة تعيين role=user ثم إعادة الاختبار.

### 5. Authorization and profile broadcasts
- **Pre:** مستخدمان A/B متصلان WS؛ A يضبط screen-lock passcode قديمًا في إعداداته.
- **Expected:** PUT /api/users/me من A → B يستقبل `user:presence_profile_update` بالحقول الخمسة فقط (`id,username,displayName,avatarUrl,verified`) — **لا passcode ولا ban/mute ولا lastSeen**؛ `presence:update` بلا lastSeen؛ قنوات الإشعار الخاصة للمالك كاملة.
- **Evidence:** حزم WS المسجلة (wscat/mitm proxy log) + payload diff.
- **Fail:** أي حقل خارج القائمة الخمسة في البثّ العام.
- **Rollback:** revert commit `f1190b8` hunk البثّ (hotfix) — إعادة الاختبار.

### 6. Group join
- **Pre:** مجموعة G بمشرف O وعضو M؛ joinApproval=off؛ invite link صالح؛ المحادثة على instance A.
- **Expected:** انضمام U → `chat:membership_changed` يصل لـ O وM وU بنفس mv؛ mv في DB زاد +1؛ system message يُنشر؛ history ما قبل الانضمام **غير قابلة للفك** لـ U.
- **Evidence:** أحداث WS الثلاثة + `SELECT membership_version FROM chats` قبل/بعد + محاولة فك رسالة قديمة بجهاز U (فشل متوقع).
- **Fail:** غياب الحدث لأي طرف / mv غير متسق / فك تاريخ قديم.
- **Rollback:** إزالة U + إعادة الاختبار بعد rotate يدوي.

### 7. Group approval
- **Pre:** كما (6) مع joinApproval=on وطلب معلق.
- **Expected:** الموافقة → نفس سلوك (6) بالضبط (بثّ لكل الأعضاء + mv + تاريخ محجوب).
- **Evidence:** كما (6).
- **Fail:** كما (6).
- **Rollback:** كما (6).

### 8. Member removal
- **Pre:** G فيها O, M, X.
- **Expected:** O يزيل X → X يستقبل `chat:evicted` **مع userId=X**؛ O وM يستقبلان `membership_changed` بنفس mv الجديد؛ X لا يستقبل أي بثّ رسائل بعده؛ محاولات إرسال من X → 403.
- **Evidence:** أحداث WS الثلاثة + فحص roster في DB + محاولة إرسال X.
- **Fail:** evicted بلا userId / غياب membership_changed للباقين / بثّ يصل لـ X.
- **Rollback:** إعادة إضافة X يدويًا + rotate.

### 9. Ban and Sender Key rotation
- **Pre:** كما (8).
- **Expected:** ban X → تسلسل (8) كاملًا **+** صف X في bannedUserIds؛ رسائل جديدة من O/M **تُفشل الفك على جهاز X** (rotate حقيقي وليس شكليًا)؛ unban لا يعيد العضوية تلقائيًا؛ إعادة الإضافة بعد unban تمر بـ GROUP-01.
- **Evidence:** keyring dump من جهاز X (قبل/بعد) + فشل فك فعلي + DB ban row.
- **Fail:** رسالة جديدة تُفك على جهاز X بعد البان.
- **Rollback:** unban + إزالة + rotate.

### 10. Restart and membership_version hydration
- **Pre:** G بعد عدة تغييرات عضوية (mv=N في PG)؛ العملاء يحملون N.
- **Expected:** restart كامل للا instance → `getMembershipVersion` يساوي N من PG (لا 1)؛ إرسال من عميل يحمل N ينجح **بدون** 409؛ فشل مُحاكى للـ hydration (PG متاح، شبكة مقطوعة لحظة الـ boot) → إرسالات المجموعات تُرفض fail-closed (لا skip للبوابات).
- **Evidence:** log boot + استعلام mv بعد restart + نتيجة إرسال.
- **Fail:** mv=1 بعد restart / إرسالات تمر بحقبة قديمة.
- **Rollback:** hotfix hydration + إعادة boot.

### 11. Multi-device synchronization
- **Pre:** حساب واحد بجهازين مسجلين؛ مجموعة E2EE.
- **Expected:** الرسائل من الأعضاء تُفك على الجهازين؛ **رسائل الحساب نفسه تُفك على الجهاز الآخر فقط إذا وُزّع مفتاح الذات — الحالة الحالية: CB-08 documented limitation (فك غير ممكن) — سجل السلوك الفعلي كدليل وليس انقطاعًا**؛ PQXDH يعمل لكل جهاز؛ KT لا يرفض الجهاز الثاني.
- **Evidence:** نتائج فك على الجهازين + قائمة fleet في DB.
- **Fail:** فشل فك رسائل الأعضاء الآخرين على أي جهاز (هذا يكسر الوعد الأساسي).
- **Rollback:** غير مطلوب — التوثيق فقط لحد CB-08 الحالي.

### 12. Tombstone enforcement
- **Pre:** رسالة M1 في G بين A/B.
- **Expected:** delete-everyone → edit على M1 (REST + sync) → 409 MESSAGE_TOMBSTONED؛ react/star/pin → 409؛ المحتوى في DB يظل tombstone.
- **Evidence:** 5 استجابات 409 + صف DB غير متغير.
- **Fail:** أي تحديث محتوى ناجح.
- **Rollback:** غير مطلوب (الحماية اتجاهها الصحيح).

### 13. Sync attachment allowlist
- **Pre:** عضو في G.
- **Expected:** sync مع attachment على host خارجي → 400 ATTACHMENT blocked؛ sync مع content >8000 → 400؛ type غير مسموح (`'system'`) → 400 SYNC_TYPE_REJECTED؛ types المسموحة تعمل.
- **Evidence:** 4 استجابات + مقارنة مع WS/REST لنفس الحمولات.
- **Fail:** مرور أي URL خارجي أو >8000 أو type شاذ عبر sync.
- **Rollback:** إصلاح wiring + إعادة.

### 14. Refresh-token reuse after restart
- **Pre:** جلسة S مع refresh token RT1؛ دورّت إلى RT2 (RT1 spent).
- **Expected:** إعادة تشغيل السيرفر ثم استخدام RT1 → **رفض + إبطال العائلة** (فحص `user_sessions.family_id`/sessions revoked في DB) + سجل `refresh_token_reuse` في auth_logs؛ استخدام RT2 بعد الإبطال → مرفوض.
- **Evidence:** استجابة 403 + حالة العائلة في DB قبل/بعد + صف auth_logs.
- **Fail:** RT1 بعد restart → رفض صامت بلا إبطال عائلة.
- **Rollback:** إعادة تفعيل عائلة الاختبار + إعادة.

### 15. Session revocation across instances
- **Pre:** نفس المستخدم على instance A وB (نفس DB+Redis)؛ جلسة S.
- **Expected:** revoke S عبر A → طلب REST عبر **B** بـ access token من S → 401 (PG fallback يجد الجلسة الملغاة)؛ WS عبر B بعد revoke → قطع خلال ≤60s أو عند أول refresh؛ إنشاء جلسة على A وقراءتها عبر B → not-revoked (لا false-401).
- **Evidence:** استجابات HTTP عبر كلا الـ instances + حالة DB.
- **Fail:** 401 لجلسة سليمة عبر B (false revoke) أو استمرار ملغاة بلا حد.
- **Rollback:** غير مطلوب — توثيق نافذة WS ≤60s كحد معروف.

### 16. Media token path scoping
- **Pre:** وسائط Drive مربوطة في G؛ media token صالح.
- **Expected:** GET `/api/media/gdrive/...?access_token=` → 200 (مع عضوية حالية)؛ GET `/api/chats/.../messages?access_token=` → **401**؛ GET export بنفس التوكن → 401؛ عضو مُزال على مسار الوسائط → 403؛ token بعد 120s → 401.
- **Evidence:** مصفوفة استجابات (مسار × token) + no-store headers.
- **Fail:** أي 200 خارج مسارات الوسائط أو لعضو مُزال.
- **Rollback:** إصلاح scoping + إعادة.

### 17. TURN credential behavior
- **Pre:** مكالمة WebRTC بين جهازين في staging.
- **Expected:** السلوك الحالي: credentials ثابتة من البندل تعمل — **توثيق الحالة فقط (DEFERRED-INFRA)**؛ تسجيل ما يصلح للبندل (استخراج creds) كدليل للبند 023.
- **Evidence:** SDP exchange + اتصال TURN ناجح + إثبات استخراج الـ creds من البندل.
- **Fail:** فشل مكالمات أساسي (regression غير متوقع).
- **Rollback:** تكوين TURN بديل مؤقت.

### 18. Key Transparency verification
- **Pre:** `KT_SIGNING_KEY` مضبوط + `VITE_KT_WITNESS_PUB` مثبت في البناء.
- **Expected:** snapshot موقّع يتغير عند تسجيل/إضافة جهاز؛ العميل يتحقق قبل استخدام bundle (بوابة متزامنة)؛ عبث في proof → رفض `KT_UNVERIFIED_PEER`؛ rollback نسخة → رفض؛ الـ mismatch report يسجل.
- **Evidence:** استجابات `/api/e2ee/kt/*` + محاولة إرسال بعد عبث (فشل) + صف kt_mismatch_reports.
- **Fail:** bundle يُستخدم قبل التحقق / عبث يمر.
- **Rollback:** إزالة العبث؛ تصحيح التوقيع.

---

## معايير نجاح الخطة كلها
18/18 PASS بدون أي Failure criteria → تفتح بوابة G2. أي FAIL → إصلاح + إعادة الاختبار المتأثر **ومن بعده**. كل دليل يُحفظ في `STAGING_EVIDENCE/` (خارج الجلسة — تنفيذ المالك أو جلسة تشغيل لاحقة). **هذه خطة فقط — لم تُنفذ في هذه الجلسة، ولا يُحتسب أي بند منها ناجحًا.**
