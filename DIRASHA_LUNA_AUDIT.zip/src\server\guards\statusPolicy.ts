/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * STATUS-01 (external audit) — unified status privacy policy.
 *
 * Single source of truth for "who may see a status" across every ingress
 * surface (REST routes, per-recipient WS fanout, comments/likes/views), plus
 * the payload sanitizer used by any push/broadcast transport.
 *
 * Rules (fail-closed everywhere):
 *   - The status OWNER always sees their own status.
 *   - 'nobody'   → never visible to others.
 *   - 'contacts' → visible only to the owner's contacts (db.getContacts).
 *   - 'everyone' → visible to all authenticated users.
 *   - An UNKNOWN visibility value fails closed (treated as 'nobody').
 *   - A missing visibility setting falls back to the codebase default
 *     ('everyone') — the same default the REST list route and the DM policy
 *     (sendGate.ts) have always applied.
 *
 * filterStatusFor strips the GLOBAL-AUDIENCE fields (text_content / media_url)
 * from a status row: full content may only travel over authenticated,
 * targeted responses (owner fetch, GET /api/statuses) — never over a global
 * broadcast channel. Callers that legitimately need the full row (the
 * authenticated GET handlers) use the raw row; every push/broadcast path
 * must pass through this sanitizer.
 */

export type StatusVisibility = 'everyone' | 'contacts' | 'nobody';

/** Fields that must never cross a global-audience (broadcast) transport. */
const GLOBAL_AUDIENCE_FIELDS: ReadonlyArray<string> = [
  'text_content',
  'media_url',
  'textContent',
  'mediaUrl',
];

/**
 * Resolve the owner's statusVisibility from their privacy settings.
 * Unknown explicit values fail closed as 'nobody'; a missing setting keeps
 * the codebase-wide 'everyone' default.
 */
export async function getStatusVisibility(db: any, ownerId: string): Promise<StatusVisibility> {
  if (typeof ownerId !== 'string' || ownerId.length === 0) return 'nobody';
  let raw: unknown;
  try {
    const settings = await db.getUserSettings(ownerId);
    raw =
      settings?.privacySettings?.statusVisibility ??
      settings?.privacy?.status ??
      'everyone';
  } catch {
    return 'nobody'; // settings lookup failure → fail closed
  }
  if (raw === 'everyone' || raw === 'contacts' || raw === 'nobody') return raw;
  return 'nobody'; // unknown explicit value → fail closed
}

/**
 * May `viewerId` view `status`?
 *
 * - Owner is always allowed (status.userId / status.user_id both accepted).
 * - 'nobody' → false. 'contacts' → owner's contact list must include the
 *   viewer. 'everyone' → true. Unknown visibility / lookup failure /
 *   malformed input → false (fail-closed).
 */
export async function canViewStatus(db: any, viewerId: string, status: any): Promise<boolean> {
  if (!status || typeof status !== 'object') return false;
  if (typeof viewerId !== 'string' || viewerId.length === 0) return false;

  const ownerId: unknown = status.userId ?? status.user_id;
  if (typeof ownerId !== 'string' || ownerId.length === 0) return false;

  // The owner always sees their own status.
  if (ownerId === viewerId) return true;

  const visibility = await getStatusVisibility(db, ownerId);
  if (visibility === 'nobody') return false;
  if (visibility === 'contacts') {
    try {
      const contacts = await db.getContacts(ownerId);
      return Array.isArray(contacts) && contacts.includes(viewerId);
    } catch {
      return false; // contact lookup failure → fail closed
    }
  }
  // 'everyone'
  return true;
}

/**
 * Shape a status row for delivery to a (potential) viewer over a broadcast
 * transport. Not allowed → null. Allowed → the row with ONLY the
 * global-audience fields stripped (text/media); every other field is kept so
 * the existing client field shape survives. Recipients fetch the full content
 * via the authenticated GET, which re-enforces canViewStatus server-side.
 */
export function filterStatusFor(status: any, viewerId: string, allowed: boolean): any {
  if (!allowed) return null;
  if (!status || typeof status !== 'object') return null;
  const safe: any = Array.isArray(status) ? [...status] : { ...status };
  for (const field of GLOBAL_AUDIENCE_FIELDS) {
    delete safe[field];
  }
  return safe;
}

/* ── BATCH-6 (B5-F2 — adversarial review): comment bound validation ──────────
 * The previous fix validated a trimmed copy but persisted the RAW string —
 * a whitespace-padded 5MB payload bypassed the cap. This validator rejects on
 * the RAW length BEFORE any trim cost, then returns the trimmed value that
 * MUST be the one persisted. */
export const MAX_COMMENT_LENGTH = 500;

export interface CommentValidation {
  ok: boolean;
  /** Present when ok=true — the validated, trimmed value that MUST be persisted. */
  value?: string;
  /** Present when ok=false — machine-readable rejection reason. */
  reason?: 'not-string' | 'too-long' | 'empty';
}

export function validateComment(raw: unknown): CommentValidation {
  if (typeof raw !== 'string') return { ok: false, reason: 'not-string' };
  // Raw length check FIRST — rejects oversized (incl. whitespace-padded)
  // payloads before any further processing/allocation.
  if (raw.length > MAX_COMMENT_LENGTH) return { ok: false, reason: 'too-long' };
  const trimmed = raw.trim();
  if (!trimmed) return { ok: false, reason: 'empty' };
  return { ok: true, value: trimmed };
}
