/**
 * Account Recovery Service
 * --------------------------
 * Three independent recovery channels (all free, all self-hosted):
 *
 *   A) Device Key — a 256-bit random "device fingerprint" stored in the user's
 *      browser (generated once, shown as a file download). Server stores only
 *      its keyed hash. Proves "I still own the original device".
 *
 *   B) Recovery PIN — 6 digits chosen at signup, scrypt-hashed. Proves
 *      "I am the human who created the account".
 *
 *   Recovery reset = Device Key (A) + PIN (B) together → one-time reset token
 *   (10-minute TTL, single-use, burns immediately).
 *
 *   C) Admin-assisted identity verification is documented as a future channel
 *      and NOT implemented cryptographically here (no backdoors).
 */

import crypto from 'crypto';
import { digestToken } from './password.ts';

export function generateDeviceKey(): { key: string; hash: string } {
  const key = crypto.randomBytes(32).toString('base64url');
  return { key, hash: digestToken(key) };
}

export function verifyDeviceKey(key: string, expectedHash: string): boolean {
  if (!key || !expectedHash) return false;
  const a = Buffer.from(digestToken(key), 'utf8');
  const b = Buffer.from(expectedHash, 'utf8');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export const RESET_TOKEN_TTL_MS = 10 * 60 * 1000; // 10 minutes
export function generateResetToken(): { token: string; hash: string; expiresAt: string } {
  const token = crypto.randomBytes(24).toString('base64url');
  return {
    token,
    hash: digestToken(token),
    expiresAt: new Date(Date.now() + RESET_TOKEN_TTL_MS).toISOString(),
  };
}

export function verifyResetToken(token: string, expectedHash: string, expiresAt: string): boolean {
  if (new Date(expiresAt).getTime() < Date.now()) return false;
  const a = Buffer.from(digestToken(token), 'utf8');
  const b = Buffer.from(expectedHash || '', 'utf8');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
