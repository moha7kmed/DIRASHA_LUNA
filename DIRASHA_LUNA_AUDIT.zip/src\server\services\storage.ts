/**
 * External Media Storage Layer (BYO-Cloud + Managed Fallback)
 * ------------------------------------------------------------
 * Media files NEVER touch our database or stream through our server:
 *   client → presigned PUT URL → uploads directly to object storage
 *   our DB stores only the resulting HTTPS URL + metadata.
 *
 * Two sources of configuration:
 *   1. User-linked storage (BYO): Cloudflare R2 / Backblaze B2 / MinIO / AWS S3
 *      — credentials are AES-256-GCM encrypted at rest before hitting the DB.
 *   2. Managed fallback bucket (env S3_*) with strict per-upload caps, so
 *      unlinked users get a working experience at near-zero cost.
 *
 * Presigning is a hand-rolled AWS Signature Version 4 implementation using
 * only Node's built-in crypto — works with every S3-compatible provider and
 * adds zero dependencies / supply-chain risk.
 */

import crypto from 'crypto';
import { logger } from '../logger.ts';

export interface S3Config {
  endpoint: string;        // e.g. https://<accountid>.r2.cloudflarestorage.com
  region: string;          // 'auto' for R2, 'us-east-1' for AWS/MinIO
  bucket: string;
  accessKeyId: string;
  secretAccessKey: string;
  publicBaseUrl: string;   // e.g. https://cdn.example.com or https://<bucket>.<endpoint>
  forcePathStyle?: boolean; // MinIO requires path-style addressing
}

export const STORAGE_RULES = {
  /** MIME whitelist — active content (HTML/SVG/XML) can never be accepted (stored-XSS shield). */
  ALLOWED_MIME: new Set([
    'image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif',
    'audio/mpeg', 'audio/ogg', 'audio/webm', 'audio/mp4', 'audio/wav', 'audio/aac',
    'video/mp4', 'video/webm', 'video/quicktime',
    'application/pdf',
    'text/plain',
    // Real office/archive documents (client doc picker mirrors this list)
    'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'application/zip',
  ]),
  /** Caps for the MANAGED fallback bucket (cost-protective; tighten freely). */
  FALLBACK_MAX_BYTES: {
    image: 5 * 1024 * 1024,
    audio: 10 * 1024 * 1024,
    video: 25 * 1024 * 1024,
    other: 5 * 1024 * 1024,
  },
  /** Caps for users on their OWN linked storage (their bill — still guardrails). */
  LINKED_MAX_BYTES: {
    image: 20 * 1024 * 1024,
    audio: 50 * 1024 * 1024,
    video: 500 * 1024 * 1024,
    other: 50 * 1024 * 1024,
  },
  PRESIGN_TTL_SEC: 600,
} as const;

function mimeCategory(mime: string): keyof typeof STORAGE_RULES.FALLBACK_MAX_BYTES {
  if (mime.startsWith('image/')) return 'image';
  if (mime.startsWith('audio/')) return 'audio';
  if (mime.startsWith('video/')) return 'video';
  return 'other';
}

export function validateUploadRequest(
  mimeType: string,
  sizeBytes: number,
  isLinkedStorage: boolean,
): { ok: boolean; error?: string } {
  const mime = (mimeType || '').toLowerCase();
  if (!STORAGE_RULES.ALLOWED_MIME.has(mime)) {
    return { ok: false, error: `نوع الملف غير مسموح (${mime || 'غير معروف'}). المسموح: صور، صوت، فيديو، PDF، نص.` };
  }
  if (!Number.isFinite(sizeBytes) || sizeBytes <= 0) {
    return { ok: false, error: 'حجم الملف غير صالح.' };
  }
  const caps = isLinkedStorage ? STORAGE_RULES.LINKED_MAX_BYTES : STORAGE_RULES.FALLBACK_MAX_BYTES;
  const cap = caps[mimeCategory(mime)];
  if (sizeBytes > cap) {
    const mb = Math.round(cap / 1024 / 1024);
    return {
      ok: false,
      error: isLinkedStorage
        ? `الملف أكبر من الحد الأقصى المسموح (${mb}MB).`
        : `الملف أكبر من حد التخزين الاحتياطي (${mb}MB). اربط تخزينك السحابي الخاص لرفع ملفات أكبر بلا حدود تقريباً.`,
    };
  }
  return { ok: true };
}

/* =========================================================================
   Credential Encryption (AES-256-GCM) — BYO keys are encrypted at rest
   ========================================================================= */

const MASTER_KEY_SOURCE = process.env.STORAGE_MASTER_KEY || process.env.COOKIE_SECRET
  || (process.env.NODE_ENV === 'production' ? '' : 'dirasha-dev-only-storage-key');
if (!MASTER_KEY_SOURCE) {
  throw new Error('FATAL: STORAGE_MASTER_KEY environment variable is required in production.');
}
const MASTER_KEY = crypto.createHash('sha256').update(`dirasha-storage:${MASTER_KEY_SOURCE}`).digest();

export function encryptCredentials(payload: object): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', MASTER_KEY, iv);
  const plaintext = JSON.stringify(payload);
  const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${iv.toString('base64')}.${tag.toString('base64')}.${encrypted.toString('base64')}`;
}

export function decryptCredentials(blob: string): { accessKeyId: string; secretAccessKey: string } {
  const [ivB64, tagB64, dataB64] = (blob || '').split('.');
  if (!ivB64 || !tagB64 || !dataB64) throw new Error('Malformed encrypted credentials');
  const decipher = crypto.createDecipheriv('aes-256-gcm', MASTER_KEY, Buffer.from(ivB64, 'base64'));
  decipher.setAuthTag(Buffer.from(tagB64, 'base64'));
  const decrypted = Buffer.concat([decipher.update(Buffer.from(dataB64, 'base64')), decipher.final()]);
  const parsed = JSON.parse(decrypted.toString('utf8'));
  if (!parsed.accessKeyId || !parsed.secretAccessKey) throw new Error('Decrypted credentials incomplete');
  return { accessKeyId: parsed.accessKeyId, secretAccessKey: parsed.secretAccessKey };
}

/* =========================================================================
   Fallback bucket config (env-driven; swap provider = swap env, zero code)
   ========================================================================= */

export function getFallbackS3Config(): S3Config | null {
  const endpoint = process.env.S3_ENDPOINT;
  const bucket = process.env.S3_BUCKET;
  const accessKeyId = process.env.S3_ACCESS_KEY_ID;
  const secretAccessKey = process.env.S3_SECRET_ACCESS_KEY;
  const publicBaseUrl = process.env.S3_PUBLIC_BASE_URL;
  if (!endpoint || !bucket || !accessKeyId || !secretAccessKey || !publicBaseUrl) return null;
  return {
    endpoint: endpoint.replace(/\/+$/, ''),
    region: process.env.S3_REGION || 'auto',
    bucket,
    accessKeyId,
    secretAccessKey,
    publicBaseUrl: publicBaseUrl.replace(/\/+$/, ''),
    forcePathStyle: process.env.S3_FORCE_PATH_STYLE === 'true',
  };
}

/** Object key layout — strictly scoped per user so nobody can overwrite another user's objects. */
export function buildObjectKey(userId: string, mimeType: string): string {
  const safeUser = userId.replace(/[^a-zA-Z0-9_-]/g, '');
  const now = new Date();
  const ym = `${now.getUTCFullYear()}/${String(now.getUTCMonth() + 1).padStart(2, '0')}`;
  const extFromMime: Record<string, string> = {
    'image/webp': 'webp', 'image/jpeg': 'jpg', 'image/png': 'png', 'image/gif': 'gif', 'image/avif': 'avif',
    'audio/webm': 'webm', 'audio/ogg': 'ogg', 'audio/mpeg': 'mp3', 'audio/mp4': 'm4a', 'audio/wav': 'wav', 'audio/aac': 'aac',
    'video/mp4': 'mp4', 'video/webm': 'webm', 'video/quicktime': 'mov',
    'application/pdf': 'pdf', 'text/plain': 'txt',
    'application/msword': 'doc', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
    'application/vnd.ms-excel': 'xls', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
    'application/vnd.ms-powerpoint': 'ppt', 'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx',
    'application/zip': 'zip',
  };
  const ext = extFromMime[mimeType.toLowerCase()] || 'bin';
  return `dirasha/${safeUser}/${ym}/${crypto.randomUUID()}.${ext}`;
}

export function buildPublicUrl(cfg: S3Config, key: string): string {
  return `${cfg.publicBaseUrl}/${key.split('/').map(encodeURIComponent).join('/')}`;
}

export function logStorageBoot(): void {
  const fb = getFallbackS3Config();
  if (fb) {
    logger.info(`[Storage] Managed fallback bucket active: ${fb.bucket} @ ${fb.endpoint}`);
  } else {
    logger.warn('[Storage] No fallback bucket configured (S3_* env). Users MUST link their own cloud storage to send media.');
  }
}

/* =========================================================================
   AWS Signature Version 4 — Presigned PUT URL (hand-rolled, zero deps)
   ========================================================================= */

function hmac(key: Buffer | string, data: string): Buffer {
  return crypto.createHmac('sha256', key).update(data, 'utf8').digest();
}
function sha256Hex(data: string): string {
  return crypto.createHash('sha256').update(data, 'utf8').digest('hex');
}

const pct = (byte: number) => '%' + byte.toString(16).toUpperCase().padStart(2, '0');

function uriEncode(str: string, encodeSlash = true): string {
  let out = '';
  for (const ch of str) {
    const code = ch.codePointAt(0)!;
    const isUnreserved =
      (code >= 65 && code <= 90) || (code >= 97 && code <= 122) || (code >= 48 && code <= 57)
      || ch === '_' || ch === '-' || ch === '~' || ch === '.';
    if (isUnreserved) {
      out += ch;
    } else if (ch === '/') {
      out += encodeSlash ? pct(code) : '/';
    } else {
      for (const byte of Buffer.from(ch, 'utf8')) out += pct(byte);
    }
  }
  return out;
}

/**
 * Generates a presigned PUT URL valid for `expiresSec`. The client uploads
 * directly to object storage with fetch(url, { method: 'PUT', body }).
 * The object key is generated server-side and prefixed by the user's id —
 * clients can never choose paths, so cross-user overwrite is impossible.
 */
export function buildPresignedPutUrl(
  cfg: S3Config,
  key: string,
  mimeType: string,
  expiresSec = STORAGE_RULES.PRESIGN_TTL_SEC,
): string {
  const endpointUrl = new URL(cfg.endpoint);
  const host = endpointUrl.host;
  const isPathStyle = cfg.forcePathStyle === true;

  const amzDate = new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
  const dateStamp = amzDate.slice(0, 8);
  const credentialScope = `${dateStamp}/${cfg.region}/s3/aws4_request`;

  const canonicalUri = isPathStyle ? `/${cfg.bucket}/${uriEncode(key, false)}` : `/${uriEncode(key, false)}`;
  const effectiveHost = isPathStyle ? host : `${cfg.bucket}.${host}`;

  const queryParams: Record<string, string> = {
    'X-Amz-Algorithm': 'AWS4-HMAC-SHA256',
    'X-Amz-Credential': `${cfg.accessKeyId}/${credentialScope}`,
    'X-Amz-Date': amzDate,
    'X-Amz-Expires': String(expiresSec),
    'X-Amz-SignedHeaders': 'content-type;host',
  };

  const canonicalQuery = Object.keys(queryParams)
    .sort()
    .map(k => `${uriEncode(k)}=${uriEncode(queryParams[k])}`)
    .join('&');

  const canonicalRequest = [
    'PUT',
    canonicalUri,
    canonicalQuery,
    `content-type:${mimeType}\nhost:${effectiveHost}\n`,
    'content-type;host',
    'UNSIGNED-PAYLOAD',
  ].join('\n');

  const stringToSign = ['AWS4-HMAC-SHA256', amzDate, credentialScope, sha256Hex(canonicalRequest)].join('\n');

  const kDate = hmac(`AWS4${cfg.secretAccessKey}`, dateStamp);
  const kRegion = hmac(kDate, cfg.region);
  const kService = hmac(kRegion, 's3');
  const kSigning = hmac(kService, 'aws4_request');
  const signature = crypto.createHmac('sha256', kSigning).update(stringToSign, 'utf8').digest('hex');

  const base = isPathStyle
    ? `${cfg.endpoint}/${cfg.bucket}/${uriEncode(key, false)}`
    : `${endpointUrl.protocol}//${cfg.bucket}.${host}/${uriEncode(key, false)}`;

  return `${base}?${canonicalQuery}&X-Amz-Signature=${signature}`;
}

