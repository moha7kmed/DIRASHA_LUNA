import { useEffect, useState } from 'react';
import { Fingerprint, Loader2, Plus, Trash2, KeyRound } from 'lucide-react';
import { listPasskeys, deletePasskey, startPasskeyRegistration, type PasskeyCredentialInfo } from '../lib/webauthn';

/**
 * مفاتيح المرور (Passkeys) settings card — security/privacy settings area.
 *
 * Minimal Arabic UI: register button + list with delete. The honest-limits
 * text is binding: passkeys protect LOGIN only; they do not encrypt chats
 * and cannot restore the E2EE keys that live in this device's IndexedDB vault.
 */
export function PasskeysCard() {
  const [credentials, setCredentials] = useState<PasskeyCredentialInfo[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const supported = typeof window !== 'undefined'
    && (window.PublicKeyCredential?.isUserVerifyingPlatformAuthenticatorAvailable
      ? true
      : !!window.PublicKeyCredential);

  const refresh = async () => {
    try {
      setCredentials(await listPasskeys());
    } catch (e: any) {
      setCredentials([]);
      setError(e?.message || 'تعذر تحميل القائمة.');
    }
  };

  useEffect(() => { void refresh(); }, []);

  const register = async () => {
    setBusy(true); setError(null); setSuccess(null);
    try {
      await startPasskeyRegistration();
      setSuccess('تم تسجيل مفتاح المرور بنجاح — يمكنك الآن الدخول به بدل كلمة المرور.');
      await refresh();
    } catch (e: any) {
      setError(e?.message || 'تعذر تسجيل مفتاح المرور.');
    } finally {
      setBusy(false);
    }
  };

  const remove = async (credentialId: string) => {
    setBusy(true); setError(null); setSuccess(null);
    try {
      await deletePasskey(credentialId);
      setSuccess('تم حذف مفتاح المرور.');
      await refresh();
    } catch (e: any) {
      setError(e?.message || 'تعذر حذف المفتاح.');
    } finally {
      setBusy(false);
    }
  };

  const fmtDate = (v: string | null): string => {
    if (!v) return '—';
    try { return new Date(v).toLocaleString('ar-EG'); } catch { return String(v); }
  };

  const deviceLabel = (d: string): string =>
    d === 'multiDevice' ? 'مفتاح متعدد الأجهزة (قابل للمزامنة)' :
    d === 'singleDevice' ? 'مفتاح مرتبط بهذا الجهاز' : 'مفتاح';

  return (
    <div className="bg-white/[0.03] border border-white/10 rounded-3xl p-5">
      <div className="flex items-center gap-3 mb-1">
        <Fingerprint className="text-cyan-400" size={20} />
        <div className="text-white font-bold text-sm">مفاتيح المرور (Passkeys)</div>
        {busy && <Loader2 className="animate-spin text-zinc-400" size={16} />}
      </div>
      <p className="text-zinc-400 text-xs mb-3 leading-relaxed">
        سجّل دخولك ببصمة إصبعك أو وجهك بدل كتابة كلمة المرور — المفتاح يُخزَّن في جهازك ولا يتركه أبداً.
        <br />
        <span className="text-amber-300/80">
          تنبيه صريح: مفاتيح المرور تحمي <b>تسجيل الدخول فقط</b> — لا تشفّر المحادثات ولا تستعيد مفاتيح التشفير
          طرف-لطرف، فهي تعيش في خزنة هذا الجهاز (IndexedDB) ولا علاقة لها بمفاتيح المرور إطلاقاً.
        </span>
      </p>

      {success && <p className="text-emerald-300 text-xs mb-2">{success}</p>}
      {error && <p className="text-red-400 text-xs mb-2">{error}</p>}

      {!supported && (
        <p className="text-zinc-500 text-xs mb-2">
          متصفحك الحالي لا يبدو يداعماً مفاتيح المرور — جرّب متصفحاً حديثاً على جهاز موثوق.
        </p>
      )}

      <button
        onClick={register}
        disabled={busy || !supported}
        className="w-full py-3 rounded-2xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold text-sm hover:bg-cyan-500/30 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
      >
        <Plus size={16} /> تسجيل مفتاح مرور جديد
      </button>

      {credentials === null ? (
        <p className="text-zinc-500 text-xs mt-3 flex items-center gap-2"><Loader2 size={14} className="animate-spin" /> جارٍ التحميل…</p>
      ) : credentials.length === 0 ? (
        <p className="text-zinc-500 text-xs mt-3">لا توجد مفاتيح مرور مسجّلة على حسابك بعد.</p>
      ) : (
        <ul className="mt-4 space-y-2">
          {credentials.map(c => (
            <li key={c.credentialId} className="bg-black/30 border border-white/10 rounded-2xl px-4 py-3 flex items-center gap-3">
              <KeyRound className="text-zinc-500 shrink-0" size={16} />
              <div className="flex-1 min-w-0">
                <p className="text-white/90 text-xs font-bold">{deviceLabel(c.device)}</p>
                <p className="text-zinc-500 text-[11px]">
                  أُنشئ: {fmtDate(c.createdAt)} · آخر استخدام: {fmtDate(c.lastUsedAt)}
                </p>
                <p className="text-zinc-600 text-[10px] font-mono break-all" dir="ltr">{c.credentialId.slice(0, 24)}…</p>
              </div>
              <button
                onClick={() => remove(c.credentialId)}
                disabled={busy}
                title="حذف المفتاح"
                className="p-2 rounded-xl bg-red-500/10 text-red-300 hover:bg-red-500/25 transition-colors disabled:opacity-40 shrink-0"
              >
                <Trash2 size={14} />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
