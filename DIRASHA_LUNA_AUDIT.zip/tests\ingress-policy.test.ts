/**
 * P0-B (external-audit E2EE-03) — E2EE ingress policy.
 *
 * Test split (same boot-at-import constraint as tests/db-tls.test.ts):
 *   1. BEHAVIORAL (pure): the REAL encryptionPolicy guard with mock db —
 *      eligible-chat detection (group / DM-both-registered / DM-missing /
 *      channel / DB-error), envelope detection, plaintext rejection.
 *   2. STATIC-SOURCE: the guard is wired at EVERY message ingress (WS send,
 *      3 REST creates, edit route) and the client encrypts edit/schedule/
 *      forward + strips the reply quote + decrypts edit envelopes.
 *
 * The audit's full marker test (unique marker through edit/schedule/forward/
 * reply against the live server) requires the booting server harness; the
 * server-side REJECTION of any plaintext ingress is proven here at the guard
 * the real routes call, and the client-side encryption is asserted statically.
 *
 * Run: npx vitest run tests/ingress-policy.test.ts
 */
import { describe, it, expect, beforeAll } from 'vitest';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const serverSrc = fs.readFileSync(path.join(repoRoot, 'server.ts'), 'utf8');
const wsSrc = fs.readFileSync(path.join(repoRoot, 'src/server/websocket/ws_server.ts'), 'utf8');
const cwSrc = fs.readFileSync(path.join(repoRoot, 'src/components/ChatWindow.tsx'), 'utf8');
const appSrc = fs.readFileSync(path.join(repoRoot, 'src/App.tsx'), 'utf8');

/* ── 1. Guard behavior (real code, mock db) ────────────────────────────────── */

describe('encryptionPolicy — server-side E2EE ingress enforcement', () => {
  let isWireEnvelope: any;
  let isE2eeEligibleChat: any;
  let assertEncryptedIngress: any;
  let E2eeRequiredError: any;
  beforeAll(async () => {
    const mod = await import('../src/server/guards/encryptionPolicy.ts');
    isWireEnvelope = mod.isWireEnvelope;
    isE2eeEligibleChat = mod.isE2eeEligibleChat;
    assertEncryptedIngress = mod.assertEncryptedIngress;
    E2eeRequiredError = mod.E2eeRequiredError;
  });

  it('isWireEnvelope: DIR1/DIRM1/DIRG1 only', () => {
    expect(isWireEnvelope('DIR1:AAAA')).toBe(true);
    expect(isWireEnvelope('DIRM1:AAAA')).toBe(true);
    expect(isWireEnvelope('DIRG1:AAAA')).toBe(true);
    expect(isWireEnvelope('hello')).toBe(false);
    expect(isWireEnvelope('DIR9:AAAA')).toBe(false);
    expect(isWireEnvelope(42)).toBe(false);
  });

  it('group chats are E2EE-eligible', async () => {
    const db = {
      getChatInfo: () => ({ type: 'group' }),
      getChatMembers: async () => [{ userId: 'a' }, { userId: 'b' }],
    };
    expect(await isE2eeEligibleChat(db, 'g1')).toBe(true);
  });

  it('DM eligible only when BOTH members registered', async () => {
    const both = {
      getChatInfo: () => ({ type: 'one-to-one' }),
      getChatMembers: async () => [{ userId: 'a' }, { userId: 'b' }],
      getExportE2eePublicKeys: async (u: string) => (u === 'a' ? [{ deviceId: 'd1' }] : []),
    };
    expect(await isE2eeEligibleChat(both, 'dm')).toBe(false);

    const bothReg = {
      getChatInfo: () => ({ type: 'one-to-one' }),
      getChatMembers: async () => [{ userId: 'a' }, { userId: 'b' }],
      getExportE2eePublicKeys: async () => [{ deviceId: 'd1' }],
    };
    bothReg.getExportE2eePublicKeys = async () => [{ deviceId: 'd1' }];
    expect(await isE2eeEligibleChat(bothReg, 'dm')).toBe(true);
    expect(await isE2eeEligibleChat(both, 'dm')).toBe(false);
  });

  it('channels are NOT eligible (documented non-E2EE boundary)', async () => {
    const db = { getChatInfo: () => ({ type: 'channel' }) };
    expect(await isE2eeEligibleChat(db, 'ch')).toBe(false);
  });

  it('DB error during registration check fails closed (not eligible)', async () => {
    const db = {
      getChatInfo: () => ({ type: 'one-to-one' }),
      getChatMembers: async () => [{ userId: 'a' }, { userId: 'b' }],
      getExportE2eePublicKeys: async () => { throw new Error('db down'); },
    };
    expect(await isE2eeEligibleChat(db, 'dm')).toBe(false);
  });

  it('plaintext into eligible chat → E2eeRequiredError; envelope passes; non-eligible unchanged', async () => {
    const dbGroup = { getChatInfo: () => ({ type: 'group' }) };
    await expect(assertEncryptedIngress(dbGroup, 'g', 'مرحبا بالنص الصريح')).rejects.toBeInstanceOf(E2eeRequiredError);
    await expect(assertEncryptedIngress(dbGroup, 'g', 'DIRG1:AAAA')).resolves.toBeUndefined();
    const dbChan = { getChatInfo: () => ({ type: 'channel' }) };
    await expect(assertEncryptedIngress(dbChan, 'c', 'نص صريح')).resolves.toBeUndefined();
  });
});

/* ── 2. Wiring asserts (static) ─────────────────────────────────────────────── */

describe('ingress policy wiring (static)', () => {
  it('WS msg:send enforces the ingress policy with E2EE_REQUIRED', () => {
    expect(wsSrc).toContain('assertEncryptedIngress(db, chatId, content)');
    expect(wsSrc).toContain('code: "E2EE_REQUIRED"');
  });

  it('all 3 REST create routes enforce it (400 E2EE_REQUIRED)', () => {
    const hits = serverSrc.split('assertEncryptedIngress(db, chatId, req.body?.content)').length - 1;
    expect(hits).toBe(3);
    expect(serverSrc).toContain("code: 'E2EE_REQUIRED'");
  });

  it('edit route enforces it + former members cannot edit (GROUP-02)', () => {
    const block = serverSrc.slice(serverSrc.indexOf("app.put('/api/messages/:messageId'"));
    expect(block).toContain('assertEncryptedIngress(db, message.chatId, content)');
    expect(block).toContain('editMembersNow');
    expect(block).toContain('لم تعد عضواً فيها');
  });

  it('client encrypts edits fail-closed (never plaintext-edit)', () => {
    expect(cwSrc).toContain('wireForEdit = await encryptContentForChat(chatId, trimmed)');
    expect(cwSrc).toContain('لن تُرسل نصًا صريحًا');
  });

  it('client encrypts scheduled content (server stores envelopes only)', () => {
    expect(cwSrc).toContain('wireForSchedule = await encryptContentForChat(chatId, trimmed)');
  });

  it('forward re-encrypts for the TARGET chat; non-E2EE target keeps legacy path', () => {
    expect(cwSrc).toContain('forwardWireFor(targetChatId, forwardModalMsg.content)');
    expect(cwSrc).toContain('non-E2EE target: legacy plaintext path');
  });

  it('reply quote carries NO plaintext content (id-only + local lookup)', () => {
    expect(cwSrc).not.toContain('content: replyingToMessage.content');
    expect(cwSrc).toContain('const orig = (messages || []).find((m: any) => m.id === message.replyTo.id)');
    expect(cwSrc).toContain('الرسالة الأصلية غير متوفرة');
  });

  it('msg:edit handler decrypts envelopes (self-DM keeps optimistic)', () => {
    expect(appSrc).toContain('decryptContentForChat(payload.chatId, content');
    expect(appSrc).toContain('isSelfDmEdit');
  });
});

describe('P1-A — attachment bytes fail-closed (E2EE-04, static)', () => {
  it('fetch/encrypt failure in an E2EE-capable chat ABORTS the send (no plaintext URL rides)', () => {
    expect(appSrc).toContain("throw new Error('E2EE_ATTACHMENT_BYTES_UNAVAILABLE')");
    expect(appSrc).toContain('e2eeCapableP1A = !!sendChatP1A && (isE2eeGroupChat(sendChatP1A) || !!e2eePeerForChat(activeChatId))');
  });
  it('already-encrypted source attachments skip via meta.e2eePayload before the guard', () => {
    expect(appSrc).toContain('const payload = att?.meta?.e2eePayload;');
  });
});

describe('P1-H client half — scoped media tokens in ChatWindow (AUTH-05, static)', () => {
  const cw = fs.readFileSync(path.join(repoRoot, 'src/components/ChatWindow.tsx'), 'utf8');
  it('the long-lived access JWT NEVER appears in media URLs', () => {
    expect((cw.match(/access_token=\$\{accessToken\}/g) || []).length).toBe(0);
    expect((cw.match(/access_token=' \+ accessToken/g) || []).length).toBe(0);
  });
  it('all media URLs use the short-lived scoped media token (state or async fetch)', () => {
    expect(cw).toContain('getScopedMediaToken');
    expect(cw).toContain('access_token=${mediaToken}');
    expect(cw).toContain('access_token=${mt}');
  });
  it('token cache has an in-flight guard + expiry (no token stampede)', () => {
    expect(cw).toContain('mediaTokInflight');
    expect(cw).toContain('exp: Date.now() + 90_000');
  });
});

describe('P1-H client — E2eeMedia scoped token (static)', () => {
  it('E2eeMedia fetches a scoped media token; the access JWT never rides URLs', () => {
    const src = fs.readFileSync(path.join(repoRoot, 'src/components/E2eeMedia.tsx'), 'utf8');
    expect((src.match(/access_token=\$\{accessToken\}/g) || []).length).toBe(0);
    expect(src).toContain("fetch('/api/media-token'");
  });
});

describe('AUTH-05 server half — media tokens are MEDIA-ONLY (static)', () => {
  it('requireAuth rejects media tokens off the media scope (Bearer or writes)', () => {
    expect(serverSrc).toContain('AuthService.isScopedMediaToken(decoded)');
    expect(serverSrc).toContain('Media tokens are URL-scoped only');
  });
  it('URL-borne access JWTs remain rejected (media-scoped GET-only rule intact)', () => {
    expect(serverSrc).toContain('URL tokens are media-scoped and GET-only');
  });
});

describe('DIR-NEW-01 — tri-state eligibility (second review)', () => {
  it('DB FAILURE inside assertEncryptedIngress → plaintext REJECTED (E2EE_POLICY_UNAVAILABLE), never allowed', async () => {
    const { assertEncryptedIngress, E2eePolicyUnavailableError, getE2eeEligibility } = await import('../src/server/guards/encryptionPolicy.ts');
    const failingDb = {
      getChatInfo: () => ({ type: 'one-to-one' }),
      getChatMembers: async () => [{ userId: 'a' }, { userId: 'b' }],
      getE2eeDeviceCount: async () => { throw new Error('E2EE_DEVICE_COUNT_DB_UNAVAILABLE'); },
    };
    const verdict = await getE2eeEligibility(failingDb, 'dm');
    expect(verdict).toBe('unknown');
    await expect(assertEncryptedIngress(failingDb, 'dm', 'نص صريح')).rejects.toBeInstanceOf(E2eePolicyUnavailableError);
  });
  it('pgQuery-null path (real database.ts shape: count method throws on null rows)', async () => {
    const db = {
      getChatInfo: () => ({ type: 'one-to-one' }),
      getChatMembers: async () => [{ userId: 'a' }, { userId: 'b' }],
      // Simulates getE2eeDeviceCount when pgQuery returns null (query failed)
      getE2eeDeviceCount: async () => { throw new Error('E2EE_DEVICE_COUNT_DB_UNAVAILABLE'); },
    };
    const { getE2eeEligibility } = await import('../src/server/guards/encryptionPolicy.ts');
    expect(await getE2eeEligibility(db, 'dm')).toBe('unknown');
  });
  it('explicitly-unregistered (count 0) stays ineligible → legacy plaintext policy', async () => {
    const db = {
      getChatInfo: () => ({ type: 'one-to-one' }),
      getChatMembers: async () => [{ userId: 'a' }, { userId: 'b' }],
      getE2eeDeviceCount: async () => 0,
    };
    const { getE2eeEligibility, assertEncryptedIngress } = await import('../src/server/guards/encryptionPolicy.ts');
    expect(await getE2eeEligibility(db, 'dm')).toBe('ineligible');
    await expect(assertEncryptedIngress(db, 'dm', 'نص صريح')).resolves.toBeUndefined();
  });
  it('tri-state prefers getE2eeDeviceCount when the db exposes it', async () => {
    const db = {
      getChatInfo: () => ({ type: 'one-to-one' }),
      getChatMembers: async () => [{ userId: 'a' }, { userId: 'b' }],
      getE2eeDeviceCount: async () => 3,
      getExportE2eePublicKeys: async () => { throw new Error('should not be called'); },
    };
    const { getE2eeEligibility } = await import('../src/server/guards/encryptionPolicy.ts');
    expect(await getE2eeEligibility(db, 'dm')).toBe('eligible');
  });
});
