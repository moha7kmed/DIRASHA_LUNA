# 🛠️ دليل التشغيل — ديراشة (نظام الهوية الكلاسيكي)

## ما تم بناؤه (بدون SMS نهائياً)
- **تسجيل**: اسم العرض → اسم مستخدم فريد → كلمة مرور قوية → PIN استرجاع إجباري → مفتاح جهاز (يُحمَّل كملف `dirasha-key.txt`)
- **دخول**: اسم المستخدم + كلمة المرور (+ كشف "جهاز معروف")
- **استرجاع**: اسم المستخدم + PIN + مفتاح الجهاز → رابط إعادة تعيين (10 دقائق، مرة واحدة)
- **التشفير**: scrypt + Salt + Pepper — قفل 15 دقيقة بعد 10 محاولات فاشلة — مقارنة timing-safe

## الإعداد (الأسرار تولّدت تلقائياً في `.env` — يتبقى سطر واحد فقط)
1. `DATABASE_URL` — ⚠️ **معطّل حالياً**: الـ hostname القديم يرجع NXDOMAIN (مشروع Aiven اتقفل/اتحذف).
   - افتح https://console.aiven.io → مشروع PostgreSQL → **Connection info → General** → انسخ **Service URI**
   - ضعه في `.env` كـ `DATABASE_URL=` (مع `?sslmode=require`)
   - أعد التشغيل — يجب أن يظهر: `[Database] PostgreSQL connected successfully.`
   - الجداول (21 جدول) تُنشأ تلقائياً
   - التفاصيل الكاملة: `docs/HANDOFF_AR.md` §7.1
2. `ADMIN_USERNAMES=` — ضع اسم المستخدم الذي ستسجله بنفسك ليأخذ دور `developer` فوراً:
   ```
   ADMIN_USERNAMES=your_username
   ```
3. ⚠️ **دوّر كلمة مرور Aiven** قبل النشر — السلسلة القديمة ظهرت في محادثة سابقة (`docs/HANDOFF_AR.md` §7.2)

## التشغيل
```bash
npm install
npm run dev   # http://localhost:3000
```

## الوسائط (BYO-Cloud)
من إعدادات المستخدم ← **Cloud Storage (BYO)**: كل مستخدم يربط R2/B2/S3/MinIO الخاص به،
ومفاتيحه تُشفَّر AES-256-GCM. المخزن الاحتياطي المشترك يُضبط عبر `S3_*` في `.env` (اختياري).

## عند النمو
كل شيء قابل للترحيل بسطر واحد: `DATABASE_URL` لأي Postgres أكبر (مثلاً Oracle Always Free بـ 200GB).
