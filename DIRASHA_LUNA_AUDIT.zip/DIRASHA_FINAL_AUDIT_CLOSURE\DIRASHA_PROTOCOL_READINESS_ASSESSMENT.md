# DIRASHA_PROTOCOL_READINESS_ASSESSMENT
## هل معمارية ديراشة الحالية تسمح مستقبلًا بتصميم بروتوكول مستقل باسم DIRASHA PROTOCOL؟

**الإجابة القصيرة: PARTIALLY READY** — الجذور المعمارية موجودة (فصل client-crypto عن السيرفر، wire format مجهز بالإصدارات، ربط AAD بحقائب السياق)، لكن هناك فجوات معمارية محددة يجب حسمها قبل صياغة أي مواصفة بروتوكول. **هذا تقييم جاهزية — ليس إعلان بروتوكول.**

---

## A. Architectural Separation

| الوظيفة | الحالة الحالية | قابلية الفصل |
|---|---|---|
| Identity | `crypto.ts` (identity keys per device) + directory server | ✅ معزولة جزئيًا — التسجيل عبر routes/e2ee.ts |
| Authentication | JWT/refresh منفصلة تمامًا عن E2EE | ✅ معزولة |
| Key Management | vault.ts + OPK management في engine | ⚠️ جزئي — إدارة OPK ممزومة بمنطق الجلسة |
| Key Agreement | PQXDH في engine.ts (764-905) | ✅ دالة نقية قابلة للفصل |
| Session Management | engine sessions (IndexedDB) | ⚠️ الحالة ممزومة بـ namespace المستخدم |
| Message Encryption | encryptMessage/decryptMessage | ✅ نقاط دخول واضحة |
| Group Encryption | group.ts (ratchet v2) — وحدة مستقلة | ✅ الأكثر جاهزية للفصل |
| Media Encryption | media.ts — وحدة نقية كاملة | ✅ |
| Device Management | routes/e2ee.ts (fleet) + engine fetchPeerDevices | ⚠️ السيرفر directory جزء من الـ API العام |
| Key Transparency | kt-client.ts + key_transparency.ts | ✅ معزولة (contract منفصل: kt-contract.ts) |
| Protocol Serialization | DIR1:/DIRM1:/DIRG1: prefixes + base64-of-JSON | ⚠️ نصي بسيط — يحتاج مواصفة ثنائية/توقيع |
| Version Negotiation | ثابت أحادي (v1) عبر الثوابت — لا تفاوض فعلي | ❌ **فجوة**: لا آلية تفاوض ديناميكية |

## B. Cryptographic Boundaries
- الواجهات موجودة فعليًا: `encryptContentForChat` (App-level choke point)، وحدات e2ee النقية (media/backup/group تستورد crypto.ts فقط).
- **التسريبات:** App.tsx يستدعي WebCrypto مباشرة في مواضع متفرقة (backup)؛ sendGate يعرف بـ prefixes التشفير (`DIR1:`...) — تسريب بسيط لمعرفة البروتوكول في طبقة التفويض؛ لا نقاط تتجاوز الواجهات في مسارات المحتوى.
- **الحكم:** تبديل محرك التشفير ممكن للرسائل/الوسائط؛ إعادة كتابة جزئية لطبقة التطبيق مطلوبة (متوسط).

## C. Protocol Versioning
- `GROUP_WIRE_VERSION`/`DR_WIRE_VERSION` ثوابت مدمجة في كل envelope + رفض الإصدارات الأخرى fail-closed (مثبت).
- ❌ لا تفاوض إصدارات (v1 فقط) — جهاز أقدم مع أحدث = إما يعمل أو يفشل مغلقًا؛ لا مسار ترحيل متعدد الإصدارات متزامن.
- **مطلوب مستقبلًا:** حقل version قابل للتوسع + policy لكل إصدار + رفض downgrade محكم (موجود جزئيًا عبر pqSeen).

## D. Canonical Message Envelope
- الحالي: envelope 1:1 (v|ik|dh|pn|n + pq) وgroup (v|groupId|skId|n|senderId|mv) — **يربط بالسياق جيدًا** (sender+epoch+counter).
- **الفجوات:** لا session-id صريح (يُشتق)؛ لا message-type داخل AAD؛ لا protocol-version مستقبلي قابل للتوسع؛ الرؤوس الحملية (senderId) مرئية للسيرفر في group envelopes (metadata).
- **أساس جيد** لبناء مواصفة موحدة — يحتاج توسيع الحقول + مواصفة serialization دقيقة.

## E. Group Security
- الحالي: Sender Keys معدلة (one-way chain + FS داخل الحقبة + replay + identity binding) — **لا PCS، لا DH ratchet بين الأعضاء، لا tree-KEM**.
- المقارنة: MLS (RFC 9420) يوفر PCS حقيقي عبر TreeKEM + شفافية membership؛ Sender Keys الحالية أقل بوضوح.
- **لبروتوكول مستقبلي:** إما تصميم tree-KEM مستوحى من MLS أو قبول غياب PCS توثيقًا. الفجوة: **تصميمية كبيرة** — أولويتها قبل كتابة أي مواصفة.

## F. Post-Quantum Strategy
- الحالي: PQXDH يحمي **تأسيس المفاتيح فقط** (hybrid X25519+ML-KEM-768)؛ الـ ratchet كلاسيكي؛ المصادقة (Ed25519 signatures) غير كمية-مقاومة.
- **المطلوب تحديده مستقبلًا:** هل نحتاج PQ ratchet (حماية مستمرة)؟ ملاءمة ML-DSA للمصادقة؟ حجم الحمولات (ML-KEM ciphertext ~1.1KB/جهاز).
- لا يُستخدم مصطلح Quantum-Safe إلا بتحديد الخاصية: "حماية تأسيس المفاتيح ضد هجوم كمّي مستقبلي (harvest-now-decrypt-later)" — محقق بنسخة hybrid.

## G. Trust and Transparency
- الحالي: KT log على نفس السيرفر + witness = نفس السيرفر (مثبت) — **مركزي فعليًا**.
- الفجوة: شاهد مستقل (بنية خارجية) + اكتشاف سجلات متناقضة بين العملاء (موجود جزئيًا عبر mismatch reports) + إثباتات consistency موزعة.
- **متطلب بروتوكولي مستقبلي:** witness federation أو transparencylog مستقل — قرار بنية تحتية.

## H. Metadata Privacy
- السيرفر يرى: المرسل، المستلمين، التوقيت، الحجم، نوع النشاط، fleet الأجهزة،KT entries. المحتوى محمي.
- الموجود للحد: generic push payloads (مُصلح)؛ lastSeen privacy (مُصلح جزئيًا)؛ لا sealed sender؛ لا relay/gateway split.
- **التكلفة:** فصل Relay عن Gateway = إعادة هندسة النشر + أداء (hops إضافية) — قرار مستقبلي بالأولوية والتكلفة.

## I. Migration
- الأساس موجود: wire-version fail-closed + pqSeen downgrade gates + compose_mv/epoch binding.
- **الناقص:** مسار ترحيل متعدد الإصدارات المتزامنة، سياسة ترحيل المفاتيح/الهوية، عدم كشف الرسائل القديمة عند الترقية (التصميم الحالي يحفظها مشفرة بالحقبة القديمة — مقبول إذا لم تُكسر المفاتيح).

---

## حكم الجاهزية: **PARTIALLY READY**

**ما يسمح بالبدء التحضيري:** فصل وحدات التشفير، wire format بمفاتيح سياق، fail-closed versioning، KT math سليم، اختبارات خصائص فعلية.
**ما يحجب كتابة المواصفة الآن (بالترتيب):**
1. قرار Group PCS: MLS-inspired أو قبول غيابه صراحة (أكبر قرار).
2. آلية version negotiation حقيقية.
3. Envelope موحد موصّف (جميع الأنواع) بحدود metadata واضحة.
4. witness independence (بنية تحتية).
5. تنظيف تسريبات App→crypto (sendGate يعرف البروتوكول).

**المرجع:** Signal specs (X3DH/DR/PQXDH)، IETF MLS RFC 9420، NIST FIPS 203/204 — سُجلت كمراجع قراءة، **ليست** دليلًا على تطابق ديراشة معها.
