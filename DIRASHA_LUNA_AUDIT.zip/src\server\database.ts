/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import pg from 'pg';
import { X509Certificate } from 'node:crypto';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import type { User, Chat, ChatMember, Message, MessageReadReceipt, UserSession, PresenceStatus, SearchResult, MediaItem } from '../types.ts';

const DATA_DIR = path.join(process.cwd(), 'data');
const SNAPSHOT_FILE = path.join(DATA_DIR, 'local_db_snapshot.json');
let saveTimeout: NodeJS.Timeout | null = null;

// Helper: Hashing function for Refresh Tokens
function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

// ── P2-hardening: at-rest encryption for the local snapshot file ─────────────────
// The in-memory engine's snapshot holds users, sessions and message plaintext.
// It is encrypted with AES-256-GCM before touching disk; the key is derived from
// the deployment's auth pepper/JWT secret (never stored alongside the file).
// Legacy plaintext snapshots are transparently re-encrypted on the next save.
const SNAPSHOT_ENC_PREFIX = 'ENC1:';

function deriveSnapshotKey(): Buffer {
  const material = process.env.SNAPSHOT_ENCRYPTION_KEY
    || `${process.env.AUTH_PEPPER || ''}:${process.env.JWT_SECRET || ''}:dirasha-local-dev`;
  return crypto.createHmac('sha256', material).update('dirasha-snapshot-encryption-v1').digest();
}

export function encryptSnapshot(plaintext: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', deriveSnapshotKey(), iv);
  const ct = Buffer.concat([cipher.update(plaintext, 'utf-8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return SNAPSHOT_ENC_PREFIX + Buffer.concat([iv, tag, ct]).toString('base64');
}

export function decryptSnapshot(fileContent: string): string {
  const blob = Buffer.from(fileContent.slice(SNAPSHOT_ENC_PREFIX.length), 'base64');
  const iv = blob.subarray(0, 12);
  const tag = blob.subarray(12, 28);
  const ct = blob.subarray(28);
  const decipher = crypto.createDecipheriv('aes-256-gcm', deriveSnapshotKey(), iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(ct), decipher.final()]).toString('utf-8');
}
// ─────────────────────────────────────────────────────────────────────────────────

// User Row Mapping Utility
// BATCH-1 (DIR-2026-001): operator identity is the DURABLE role column only.
// No username-based privilege derivation anywhere — ADMIN_USERNAMES no longer
// grants or influences role/verified at read time. Privileged accounts are
// provisioned exclusively via the audited bootstrap flow (see server.ts).
const ADMIN_USERNAMES: Set<string> = new Set(
  (process.env.ADMIN_USERNAMES || '')
    .split(',')
    .map(u => u.toLowerCase().trim())
    .filter(Boolean)
);

function mapUserRow(row: any): User {
  const phone = (row.phone_number || row.phoneNumber || '').trim();
  const uname = (row.username || '').toLowerCase().trim();
  const settings = typeof row.user_settings === 'string' ? JSON.parse(row.user_settings || '{}') : (row.user_settings || {});

  return {
    id: row.id,
    phoneNumber: phone,
    profileCompleted: row.profile_completed ?? row.profileCompleted ?? false,
    username: row.username,
    displayName: row.display_name || row.displayName || row.username || '',
    email: '',
    avatarUrl: row.avatar_url || row.avatarUrl,
    bannerUrl: row.banner_url || row.bannerUrl || undefined,
    backgroundBannerUrl: row.background_banner_url || row.backgroundBannerUrl || undefined,
    bio: row.bio || undefined,
    verified: row.verified ?? false,
    onlineStatus: row.online_status || row.onlineStatus || 'offline',
    lastSeen: row.last_seen ? new Date(row.last_seen).toISOString() : (row.lastSeen || undefined),
    createdAt: row.created_at ? new Date(row.created_at).toISOString() : (row.createdAt || new Date().toISOString()),
    updatedAt: row.updated_at ? new Date(row.updated_at).toISOString() : (row.updatedAt || new Date().toISOString()),
    bannerShadowOpacity: row.banner_shadow_opacity !== undefined && row.banner_shadow_opacity !== null ? Number(row.banner_shadow_opacity) : 60,
    bgBannerShadowOpacity: row.bg_banner_shadow_opacity !== undefined && row.bg_banner_shadow_opacity !== null ? Number(row.bg_banner_shadow_opacity) : 20,
    // BATCH-1 (DIR-2026-001): role is the durable DB column ONLY — no username
    // re-evaluation, no read-time promotion.
    role: row.role && row.role !== 'user' ? row.role : 'user',
    privacySettings: settings.privacySettings ? {
      ...settings.privacySettings,
      // New keys default on legacy-stored settings that predate them
      searchVisibility: settings.privacySettings.searchVisibility || 'everyone',
      aboutVisibility: settings.privacySettings.aboutVisibility || 'everyone',
    } : {
      lastSeenVisibility: settings.privacy?.lastSeen || 'everyone',
      avatarVisibility: settings.privacy?.avatar || 'everyone',
      statusVisibility: settings.privacy?.status || 'everyone',
      searchVisibility: 'everyone',
      aboutVisibility: 'everyone',
      allowDirectMessages: settings.privacy?.allowDirectMessages || 'everyone',
      allowGroupInvites: settings.privacy?.allowGroupInvites || 'everyone',
      readReceiptsEnabled: settings.privacy?.readReceiptsEnabled !== false,
      typingIndicatorEnabled: settings.privacy?.typingIndicatorEnabled !== false,
      screenLockEnabled: settings.privacy?.screenLockEnabled || false,
      screenLockPasscode: settings.privacy?.screenLockPasscode || ''
    },
    // Full settings state round-trips through the User object (UI reads these)
    chatSettings: settings.chatSettings || {},
    chatNotifOverrides: settings.chatNotifOverrides || {},
    chatWallpapers: settings.chatWallpapers || {},
    pinnedChats: settings.pinnedChats || [],
    unreadMarks: settings.unreadMarks || [],
    lockedChats: settings.lockedChats || [],
    archivedChats: settings.archivedChats || [],
    chatFolders: settings.chatFolders || [],
    autoDeleteAfterMonths: settings.autoDeleteAfterMonths || 0,
    isBanned: row.is_banned || row.isBanned || false,
    bannedAt: row.banned_at ? new Date(row.banned_at).toISOString() : (row.bannedAt || undefined),
    bannedUntil: row.banned_until ? new Date(row.banned_until).toISOString() : (row.bannedUntil || undefined),
    bannedBy: row.banned_by || row.bannedBy || undefined,
    banReason: row.ban_reason || row.banReason || undefined,
    mutedUntil: row.muted_until ? new Date(row.muted_until).toISOString() : (row.mutedUntil || undefined),
    mutedAt: row.muted_at ? new Date(row.muted_at).toISOString() : (row.mutedAt || undefined),
    mutedBy: row.muted_by || row.mutedBy || undefined,
    muteReason: row.mute_reason || row.muteReason || undefined,
    mutedFromAiUntil: row.muted_from_ai_until ? new Date(row.muted_from_ai_until).toISOString() : (row.mutedFromAiUntil || undefined)
  };
}

// Session Row Mapping Utility
function mapSessionRow(row: any): UserSession {
  return {
    id: row.id,
    userId: row.user_id || row.userId,
    refreshToken: row.refreshToken || '',
    userAgent: row.user_agent || row.userAgent || 'unknown',
    ipAddress: row.ip_address || row.ipAddress || '127.0.0.1',
    isRevoked: row.is_revoked || row.isRevoked || false,
    expiresAt: row.expires_at ? new Date(row.expires_at).toISOString() : (row.expiresAt || new Date().toISOString()),
    createdAt: row.created_at ? new Date(row.created_at).toISOString() : (row.createdAt || new Date().toISOString())
  };
}

/* =========================================================================
   Connection Candidate Management
   ========================================================================= */

let activePgPool: pg.Pool | null = null;
let isPostgresHealthy = false;

/**
 * Retention windows (documented privacy claims — see docs/security/
 * REMEDIATION_EXECUTION_PLAN.md F10/F11):
 *   - auth_logs: 180 days (authentication audit records)
 *   - Deleted Messages Vault: 30 days (moderation safety archive)
 */
const AUTH_LOGS_RETENTION_DAYS = 180;
const DELETED_MSG_VAULT_RETENTION_DAYS = 30;

/**
 * Keep-alive heartbeat: a trivial SELECT 1 through the live pool every 4
 * minutes so hosted providers' idle-watcher never sees the database as
 * inactive. Load is negligible (1 query / 4 min). Toggle: DB_KEEPALIVE=false.
 */
let keepAliveTimer: NodeJS.Timeout | null = null;
function startKeepAliveHeartbeat(): void {
  if (keepAliveTimer || process.env.DB_KEEPALIVE === 'false') return;
  keepAliveTimer = setInterval(() => {
    activePgPool?.query('SELECT 1').catch((err) => {
      console.warn('[Database] Keep-alive query failed:', err.message);
    });
  }, 4 * 60 * 1000);
  keepAliveTimer.unref?.();
}
let primaryConnectionString = (process.env.DATABASE_URL || '').trim();

if (primaryConnectionString.startsWith('"') && primaryConnectionString.endsWith('"')) {
  primaryConnectionString = primaryConnectionString.slice(1, -1).trim();
}
if (primaryConnectionString.startsWith("'") && primaryConnectionString.endsWith("'")) {
  primaryConnectionString = primaryConnectionString.slice(1, -1).trim();
}

/* =========================================================================
   DB TLS configuration (audit finding: `ssl: { rejectUnauthorized: false }`
   encrypted-but-unverified connections to managed Postgres providers).

   Activation gate — the mechanism is always on; activation is the owner's
   env action:
     1. Download ca.pem from the provider console (Aiven: Service Overview →
        CA certificate).
     2. Base64-encode it once:  base64 -w0 ca.pem   (Git Bash / Linux)
     3. Set PG_CA_CERT to that base64 string in the deployment environment.
     4. Restart. Boot log must print:  [DB-TLS] mode=verified

   Fail-closed deployments: set PG_REQUIRE_DB_TLS=1 — a missing/invalid CA
   then aborts boot with exit(1) instead of continuing unverified.

   The decision itself lives in the exported PURE helper buildPgSslConfig()
   (unit-tested in tests/db-tls.test.ts); this module applies the decision
   to every pool creation site and emits the boot log (names only, never
   certificate values).
   ========================================================================= */

export type DbTlsMode = 'verified' | 'pinned-leaf' | 'unverified' | 'none';

export interface PgSslEnv {
  PG_DB_CERT_PEM?: string;
  PG_REQUIRE_DB_TLS?: string;
  PG_CA_CERT?: string;
  NODE_ENV?: string;
}

export interface PgSslDecision {
  /** verified = CA pinned + full chain + hostname check ON. unverified = encrypted, server identity NOT verified. none = TLS not required for this connection. */
  mode: DbTlsMode;
  /** The node-postgres `ssl` option to pass to every pool. undefined when mode === 'none'. */
  ssl: { ca: string; rejectUnauthorized: true } | { rejectUnauthorized: false } | undefined;
  /** True when PG_REQUIRE_DB_TLS=1 was set but no usable CA exists — the caller must abort (exit(1)). */
  failClosed: boolean;
  /** Loud warning when a weak/empty/invalid PG_CA_CERT was treated as unset. Never contains certificate material. */
  warning: string | null;
  isProduction: boolean;
}

/** Minimum plausible PEM length — a real CA cert is >1KB; smaller values are garbage. */
const PG_CA_CERT_MIN_PEM_LENGTH = 64;

/**
 * Project: X.509 parse + validity + type validation (Node X509Certificate).
 * Rejects: non-cert PEM, EXPIRED or not-yet-valid certificates.
 * The caller decides trust: the owner-provided provider CA is anchored;
 * network-captured material is NEVER auto-anchored (owner constraint 1).
 */
function validateCertPem(pem: string): { ok: true; x509: import("node:crypto").X509Certificate } | { ok: false; error: string } {
  try {
    const x509 = new X509Certificate(pem);
    const now = new Date();
    const validFrom = new Date(x509.validFrom);
    const validTo = new Date(x509.validTo);
    if (validTo < now) return { ok: false, error: 'certificate EXPIRED at ' + x509.validTo };
    if (validFrom > now) return { ok: false, error: 'certificate NOT YET VALID (from ' + x509.validFrom + ')' };
    return { ok: true, x509 };
  } catch (err: any) {
    return { ok: false, error: 'X.509 parse failed: ' + (err?.message || 'unknown') };
  }
}

/**
 * Owner-provided trust anchor decode: base64-of-PEM or raw PEM, then X.509
 * validation (structure + validity). NEVER anchored from network captures
 * without the owner's independent verification (owner constraint 1).
 */
function decodeOwnerAnchorPem(raw: string | undefined): { pem: string } | { error: string } {
  if (typeof raw !== 'string' || raw.trim().length === 0) return { error: 'not set' };
  const compact = raw.replace(/[\r\n]+/g, '');
  if (process.env.PG_TLS_DEBUG === '1') { console.info('[KT-DBG] anchor: rawLen=', raw.length, 'compactHead=', JSON.stringify(compact.slice(0, 40)), 'hasBegin=', compact.includes('-----BEGIN CERTIFICATE-----')); }
  let pem: string;
  if (compact.includes('-----BEGIN CERTIFICATE-----')) {
    pem = raw.replace(/\\n/g, '\n').trim();
  } else if (/^[A-Za-z0-9+/]+={0,2}$/.test(compact)) {
    try { pem = Buffer.from(compact, 'base64').toString('utf-8'); } catch { return { error: 'invalid base64' }; }
  } else {
    return { error: 'unrecognized certificate format' };
  }
  const v = validateCertPem(pem);
  if (v.ok === false) return { error: v.error };
  return { pem };
}

function decodeCaPem(raw: string | undefined): { pem: string } | { error: string } {
  if (typeof raw !== 'string') return { error: 'not set' };
  const compact = raw.replace(/[\r\n]+/g, '');
  if (compact.length === 0) return { error: 'empty' };
  if (compact.length < PG_CA_CERT_MIN_PEM_LENGTH) return { error: 'too short to be a PEM certificate' };
  if (!/^[A-Za-z0-9+/]+={0,2}$/.test(compact)) return { error: 'not valid base64' };
  let pem: string;
  try {
    pem = Buffer.from(compact, 'base64').toString('utf-8');
  } catch {
    return { error: 'base64 decode failed' };
  }
  if (!pem.includes('-----BEGIN CERTIFICATE-----') || !pem.includes('-----END CERTIFICATE-----')) {
    return { error: 'decoded payload is not a PEM certificate' };
  }
  return { pem };
}

/**
 * PURE TLS decision for PostgreSQL pool creation (unit boundary — tests/db-tls.test.ts).
 * Env-driven, no side effects, never reads process.env directly and never logs/exits.
 */
export function buildPgSslConfig(env: PgSslEnv = {}): PgSslDecision {
  const isProduction = env.NODE_ENV === 'production';
  const decoded = decodeCaPem(env.PG_CA_CERT);

  if ('pem' in decoded) {
    return {
      mode: 'verified',
      ssl: { ca: decoded.pem, rejectUnauthorized: true },
      failClosed: false,
      warning: null,
      isProduction
    };
  }

  // Pinned-leaf mode (TOFU): PG_DB_CERT_PEM holds the leaf certificate
  // observed directly from the provider (captured over an encrypted
  // connection during diagnostics). Passing it as the trust anchor gives
  // verify-full semantics anchored at the pinned leaf — chain + hostname
  // both verified. Priority: provider CA > pinned leaf > unverified.
  const pinnedRaw = env.PG_DB_CERT_PEM;
  console.info('[DB-TLS] pinned diag: present=', !!pinnedRaw,
    'len=', pinnedRaw ? pinnedRaw.length : 0,
    'head24=', pinnedRaw ? pinnedRaw.slice(0, 24) : '',
    'hasWS=', pinnedRaw ? /s/.test(pinnedRaw) : false,
    'compactHasBegin=', pinnedRaw ? pinnedRaw.replace(/s+/g, '').includes('-----BEGIN CERTIFICATE-----') : false,
    'b64DecodeHasBegin=', (() => { try { return Buffer.from(pinnedRaw.replace(/s+/g, ''), 'base64').toString('utf-8').includes('-----BEGIN CERTIFICATE-----'); } catch { return 'err'; } })(),
  );
  // Owner-provided anchor (constraints 1+2): the OFFICIAL provider CA from
  // the Aiven console — a network-captured leaf/chain is NEVER auto-anchored.
  const ownerAnchor = decodeOwnerAnchorPem(env.PG_DB_CERT_PEM);
  if ('pem' in ownerAnchor) {
    return {
      mode: 'verified',
      ssl: { ca: ownerAnchor.pem, rejectUnauthorized: true },
      failClosed: false,
      warning: null,
      isProduction,
    };
  } else if (env.PG_DB_CERT_PEM !== undefined) {
    // Loud: a provided-but-invalid anchor must not silently fall back.
    // TLS-01 (external audit): when PG_REQUIRE_DB_TLS=1, ANY configured
    // cert/CA material that is invalid/unparseable is a FAIL-CLOSED condition
    // — the caller (applyDbTlsDecision) exits(1) instead of continuing
    // unverified. Without the require flag keep the loud-warning behavior.
    const requireTls = env.PG_REQUIRE_DB_TLS === '1' || env.PG_REQUIRE_DB_TLS === 'true';
    const warning = '[DB-TLS] PG_DB_CERT_PEM rejected: ' + ownerAnchor.error
      + (env.PG_CA_CERT !== undefined ? ` (configured PG_CA_CERT is also unusable: ${decoded.error})` : '');
    return { mode: 'unverified', ssl: { rejectUnauthorized: false }, failClosed: requireTls, warning, isProduction };
  }

  const caMissing = decoded.error;
  const warning = env.PG_CA_CERT !== undefined
    ? `[DB-TLS] PG_CA_CERT present but unusable (${caMissing}) — treated as UNSET. Provide base64(PEM) of the provider CA.`
    : null;
  const failClosed = env.PG_REQUIRE_DB_TLS === '1' || env.PG_REQUIRE_DB_TLS === 'true';

  return {
    mode: 'unverified',
    ssl: { rejectUnauthorized: false },
    failClosed,
    warning,
    isProduction
  };
}

/**
 * Emits the boot log for the TLS decision (names only — never certificate values)
 * and aborts boot when a fail-closed deployment has no usable CA.
 */
function applyDbTlsDecision(decision: PgSslDecision): PgSslDecision {
  if (decision.warning) console.error(decision.warning);
  if (decision.failClosed) {
    console.error(
      '[DB-TLS] FATAL: PG_REQUIRE_DB_TLS=1 but the configured CA/cert material (PG_CA_CERT and/or PG_DB_CERT_PEM) is missing or invalid. ' +
      'Fail-closed mode refuses UNVERIFIED database TLS. Set PG_CA_CERT (base64 PEM from your provider console) or unset PG_REQUIRE_DB_TLS.'
    );
    process.exit(1);
  }
  if (decision.mode === 'verified') {
    console.log('[DB-TLS] mode=verified (CA pinned, full chain + hostname verification ON)');
  } else if (decision.isProduction) {
    console.error(
      '[DB-TLS] UNVERIFIED: set PG_CA_CERT (base64 PEM from your provider console) — ' +
      'current connection is encrypted but the server identity is UNVERIFIED'
    );
    console.log('[DB-TLS] mode=unverified');
  } else {
    console.log('[DB-TLS] mode=unverified (development)');
  }
  return decision;
}

// Decide once per boot; every pool creation site (primary + startup probe)
// consumes the SAME decision so the log is emitted exactly once.
const dbTlsDecision = applyDbTlsDecision(buildPgSslConfig(process.env)); // must read the REAL environment

function createPoolForString(connStr: string): pg.Pool {
  // Managed Postgres providers (Supabase pooler, Aiven, Neon…) terminate TLS with
  // provider CA certs that fail public-chain verification. Strip any sslmode= from
  // the URL and control TLS explicitly here, otherwise node-postgres lets the URL
  // override our `ssl` option and rejects their self-signed chains.
  const needsTls = /sslmode=require|supabase|pooler|aivencloud|neon\.tech/i.test(connStr);
  const sanitized = connStr.replace(/[?&]sslmode=[^&]*/i, (m) => (m.startsWith('?') ? '?' : '')).replace(/\?$/, '');
  // TLS decision comes exclusively from buildPgSslConfig():
  //   - PG_CA_CERT set (+valid) → verified: { ca, rejectUnauthorized: true } regardless of
  //     URL shape (an explicit CA is an explicit owner intent to verify).
  //   - PG_CA_CERT unset + TLS-required URL → unverified: { rejectUnauthorized: false }
  //     (documented activation gate — see the banner above; loud CRITICAL log in production).
  //   - PG_CA_CERT unset + plain local URL → no TLS (mode 'none' semantics).
  const useSsl = needsTls || dbTlsDecision.mode === 'verified';
  return new pg.Pool({
    connectionString: sanitized,
    ssl: useSsl ? dbTlsDecision.ssl : undefined,
    connectionTimeoutMillis: 8000,
    idleTimeoutMillis: 30000,
    max: 10,
    keepAlive: true
  });
}

if (primaryConnectionString) {
  activePgPool = createPoolForString(primaryConnectionString);
  activePgPool.on('error', (err) => {
    isPostgresHealthy = false;
  });
  // ض7: capture the FIRST connection's TLS authorization state on the real
  // production path (names/status only — never certificate content).
  activePgPool.on('connect', (client: any) => {
    try {
      const stream = client.connection && client.connection.stream;
      if (stream && typeof stream.on === 'function') {
        stream.once('secureConnect', () => {
          const authErr = (stream as any).authorizationError;
          const auth = authErr ? 'authorizationError: '.concat(String(authErr).slice(0, 60)) : 'authorized';
          const fp = stream.getPeerCertificate ? (stream.getPeerCertificate() || {}).fingerprint256 : undefined;
          console.log('[DB-TLS] production connection '.concat(auth, ' | mode=').concat(dbTlsDecision.mode, ' | peerFP=').concat(String(fp || 'n/a').slice(0, 47)));
        });
      }
    } catch { /* TLS introspection is best-effort */ }
  });
} else if (dbTlsDecision.mode === 'unverified') {
  // No DATABASE_URL at all (memory engine) — log the gate state so owners see
  // what would happen the moment a connection string is added.
  console.log('[DB-TLS] mode=unverified (no DATABASE_URL configured — in-memory engine)');
}

/* =========================================================================
   Resilient In-Memory & Local Storage Engine
   ========================================================================= */

const memoryStore = {
  users: new Map<string, any>(),
  userProfiles: new Map<string, any>(),
  userSettings: new Map<string, any>(),
  userSessions: new Map<string, any>(),
  // AUTH-01: consumed refresh tokens (SHA-256 HASHES ONLY, never raw tokens),
  // keyed sessionId -> Set<tokenHash>. Reuse detection reads this + the
  // spent_refresh_tokens PG table (migration v13).
  spentRefreshTokens: new Map<string, Set<string>>(),
  passwordResetTokens: new Map<string, any>(),
  verificationTokens: new Map<string, any>(),
  userStorageAccounts: new Map<string, any>(), // userId -> { provider, endpoint, region, bucket, public_base_url, credentials_encrypted, force_path_style, is_active, created_at, updated_at }
  chats: new Map<string, any>(),
  chatMembers: new Map<string, Set<string>>(),
  chatRoles: new Map<string, Map<string, 'owner' | 'admin' | 'member'>>(), // group roles (WhatsApp/TG parity)
  reservedUsernames: new Set<string>(), // anti-impersonation: old usernames stay reserved
  callLogs: new Map<string, any[]>(), // userId -> call history entries (Calls tab)
  messages: new Map<string, any>(),
  attachments: new Map<string, any>(),
  messageReactions: new Map<string, Map<string, Set<string>>>(), // msgId -> emoji -> Set<userId>
  messageReads: new Map<string, Map<string, { status: string; updatedAt: string }>>(), // msgId -> userId -> status
  messagePins: new Map<string, Map<string, { pinnedBy: string; pinnedAt: string }>>(), // chatId -> msgId -> info
  messageStars: new Map<string, Set<string>>(), // userId -> Set<msgId>
  contacts: new Map<string, Set<string>>(), // userId -> Set<contactId>
  blocks: new Map<string, Set<string>>(), // userId -> Set<blockedId>
  reports: new Map<string, any>(),
  auditLogs: [] as any[],
  moderationLogs: [] as any[],
  staffNotes: new Map<string, any[]>(), // userId -> notes[]
  userWarnings: new Map<string, any[]>(), // userId -> warnings[]
  statuses: new Map<string, any>(),
  statusViews: new Map<string, Set<string>>(), // statusId -> Set<userId>
  statusLikes: new Map<string, Set<string>>(), // statusId -> Set<userId>
  statusComments: new Map<string, any[]>(), // statusId -> comments[]
  pushSubscriptions: new Map<string, { userId: string; subscription: any }>(), // endpoint -> sub
  deletedMessagesVault: new Map<string, any>(),
  systemApiKeys: new Map<string, any>()
};

function trySalvageJsonArray(rawData: string, filename: string): any[] {
  const trimmed = rawData.trim();
  if (!trimmed) return [];
  try {
    return JSON.parse(trimmed);
  } catch (err) {}

  const items: any[] = [];
  let braceCount = 0;
  let inString = false;
  let isEscaped = false;
  let objectStartIdx = -1;

  for (let i = 0; i < trimmed.length; i++) {
    const char = trimmed[i];
    if (isEscaped) {
      isEscaped = false;
      continue;
    }
    if (char === '\\') {
      isEscaped = true;
      continue;
    }
    if (char === '"') {
      inString = !inString;
      continue;
    }

    if (!inString) {
      if (char === '{') {
        if (braceCount === 0) objectStartIdx = i;
        braceCount++;
      } else if (char === '}') {
        braceCount--;
        if (braceCount === 0 && objectStartIdx !== -1) {
          const objStr = trimmed.substring(objectStartIdx, i + 1);
          try {
            items.push(JSON.parse(objStr));
          } catch (e) {}
          objectStartIdx = -1;
        }
      }
    }
  }
  return items;
}

let pendingSnapshotWrite: Promise<void> = Promise.resolve();

/**
 * Graceful-shutdown hook: resolves once any in-flight/debounced snapshot write
 * has hit disk (memory mode). In PostgreSQL mode there are no pending snapshot
 * writes (chat data is durable in PG) and this resolves immediately.
 */
export async function flushPendingWrites(): Promise<void> {
  if (saveTimeout) {
    clearTimeout(saveTimeout);
    saveTimeout = null;
  }
  await pendingSnapshotWrite;
}

export function persistMemoryStore(immediate = false): void {
  // PG-durable mode: chat/auth domain lives in PostgreSQL — the O(N) full-store
  // snapshot serialization is skipped entirely (it blocked the event loop and
  // rewrote the whole dataset on every mutation). Memory mode keeps it: the
  // snapshot is the ONLY durability there.
  if (isPostgresHealthy) return;
  const doSave = () => {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      const serialized = {
        version: '2.0',
        savedAt: new Date().toISOString(),
        users: Array.from(memoryStore.users.entries()),
        userProfiles: Array.from(memoryStore.userProfiles.entries()),
        userSettings: Array.from(memoryStore.userSettings.entries()),
        userSessions: Array.from(memoryStore.userSessions.entries()),
        spentRefreshTokens: Array.from(memoryStore.spentRefreshTokens.entries()).map(([sid, hashes]) => [sid, Array.from(hashes)]),
        passwordResetTokens: Array.from(memoryStore.passwordResetTokens.entries()),
        verificationTokens: Array.from(memoryStore.verificationTokens.entries()),
        chats: Array.from(memoryStore.chats.entries()),
        chatMembers: Array.from(memoryStore.chatMembers.entries()).map(([cid, members]) => [cid, Array.from(members)]),
        chatRoles: Array.from(memoryStore.chatRoles.entries()).map(([cid, roles]) => [cid, Array.from(roles.entries())]),
        reservedUsernames: Array.from(memoryStore.reservedUsernames || []),
        callLogs: Array.from(memoryStore.callLogs.entries()),
        messages: Array.from(memoryStore.messages.entries()),
        attachments: Array.from(memoryStore.attachments.entries()),
        messageReactions: Array.from(memoryStore.messageReactions.entries()).map(([mid, emojis]) => [
          mid,
          Array.from(emojis.entries()).map(([e, users]) => [e, Array.from(users)])
        ]),
        messageReads: Array.from(memoryStore.messageReads.entries()).map(([mid, reads]) => [
          mid,
          Array.from(reads.entries())
        ]),
        messagePins: Array.from(memoryStore.messagePins.entries()).map(([cid, pins]) => [
          cid,
          Array.from(pins.entries())
        ]),
        messageStars: Array.from(memoryStore.messageStars.entries()).map(([uid, stars]) => [uid, Array.from(stars)]),
        contacts: Array.from(memoryStore.contacts.entries()).map(([uid, c]) => [uid, Array.from(c)]),
        blocks: Array.from(memoryStore.blocks.entries()).map(([uid, b]) => [uid, Array.from(b)]),
        reports: Array.from(memoryStore.reports.entries()),
        auditLogs: memoryStore.auditLogs,
        moderationLogs: memoryStore.moderationLogs,
        staffNotes: Array.from(memoryStore.staffNotes.entries()),
        userWarnings: Array.from(memoryStore.userWarnings.entries()),
        statuses: Array.from(memoryStore.statuses.entries()),
        statusViews: Array.from(memoryStore.statusViews.entries()).map(([sid, v]) => [sid, Array.from(v)]),
        statusLikes: Array.from(memoryStore.statusLikes.entries()).map(([sid, l]) => [sid, Array.from(l)]),
        statusComments: Array.from(memoryStore.statusComments.entries()),
        pushSubscriptions: Array.from(memoryStore.pushSubscriptions.entries()),
        systemApiKeys: Array.from(memoryStore.systemApiKeys.entries())
      };

      const tempFile = `${SNAPSHOT_FILE}.tmp`;
      // P2-hardening: snapshot payload is encrypted at rest (AES-256-GCM).
      fs.writeFileSync(tempFile, encryptSnapshot(JSON.stringify(serialized)), 'utf-8');
      fs.renameSync(tempFile, SNAPSHOT_FILE);
    } catch (err: any) {
      console.error('[Database Persistence] Error saving local DB snapshot:', err.message);
    }
  };

  if (immediate) {
    if (saveTimeout) clearTimeout(saveTimeout);
    saveTimeout = null;
    pendingSnapshotWrite = Promise.resolve().then(() => { doSave(); });
  } else {
    if (saveTimeout) return;
    saveTimeout = setTimeout(() => {
      saveTimeout = null;
      pendingSnapshotWrite = Promise.resolve().then(() => { doSave(); });
    }, 150);
  }
}

function loadMemoryStoreFromDisk(): void {
  try {
    if (fs.existsSync(SNAPSHOT_FILE)) {
      let raw = fs.readFileSync(SNAPSHOT_FILE, 'utf-8');
      // P2-hardening: decrypt encrypted snapshots; legacy plaintext files load as-is
      // and get re-encrypted automatically on the next save.
      if (raw.startsWith(SNAPSHOT_ENC_PREFIX)) {
        try {
          raw = decryptSnapshot(raw);
        } catch {
          console.error('[Database Persistence] Snapshot decryption failed (key mismatch or corruption) — starting with an empty store.');
          return;
        }
      }
      const data = JSON.parse(raw);
      if (data && data.users) {
        if (Array.isArray(data.users)) data.users.forEach(([k, v]: [string, any]) => memoryStore.users.set(k, v));
        if (Array.isArray(data.userProfiles)) data.userProfiles.forEach(([k, v]: [string, any]) => memoryStore.userProfiles.set(k, v));
        if (Array.isArray(data.userSettings)) data.userSettings.forEach(([k, v]: [string, any]) => memoryStore.userSettings.set(k, v));
        if (Array.isArray(data.userSessions)) data.userSessions.forEach(([k, v]: [string, any]) => memoryStore.userSessions.set(k, v));
        if (Array.isArray(data.spentRefreshTokens)) data.spentRefreshTokens.forEach(([sid, hashList]: [string, string[]]) => memoryStore.spentRefreshTokens.set(sid, new Set(hashList || [])));
        if (Array.isArray(data.passwordResetTokens)) data.passwordResetTokens.forEach(([k, v]: [string, any]) => memoryStore.passwordResetTokens.set(k, v));
        if (Array.isArray(data.verificationTokens)) data.verificationTokens.forEach(([k, v]: [string, any]) => memoryStore.verificationTokens.set(k, v));
        if (Array.isArray(data.chats)) data.chats.forEach(([k, v]: [string, any]) => memoryStore.chats.set(k, v));
        if (Array.isArray(data.chatMembers)) data.chatMembers.forEach(([k, v]: [string, string[]]) => memoryStore.chatMembers.set(k, new Set(v)));
        if (Array.isArray(data.chatRoles)) data.chatRoles.forEach(([k, v]: [string, [string, string][]]) => memoryStore.chatRoles.set(k, new Map(v as any)));
        if (Array.isArray(data.reservedUsernames)) memoryStore.reservedUsernames = new Set(data.reservedUsernames);
        if (Array.isArray(data.callLogs)) data.callLogs.forEach(([k, v]: [string, any[]]) => memoryStore.callLogs.set(k, v));
        if (Array.isArray(data.messages)) data.messages.forEach(([k, v]: [string, any]) => memoryStore.messages.set(k, v));
        if (Array.isArray(data.attachments)) data.attachments.forEach(([k, v]: [string, any]) => memoryStore.attachments.set(k, v));
        if (Array.isArray(data.messageReactions)) {
          data.messageReactions.forEach(([mid, emojiList]: [string, [string, string[]][]]) => {
            const map = new Map<string, Set<string>>();
            emojiList.forEach(([emoji, userIds]) => map.set(emoji, new Set(userIds)));
            memoryStore.messageReactions.set(mid, map);
          });
        }
        if (Array.isArray(data.messageReads)) {
          data.messageReads.forEach(([mid, readList]: [string, [string, any][]]) => {
            const map = new Map<string, any>();
            readList.forEach(([uid, st]) => map.set(uid, st));
            memoryStore.messageReads.set(mid, map);
          });
        }
        if (Array.isArray(data.messagePins)) {
          data.messagePins.forEach(([cid, pinList]: [string, [string, any][]]) => {
            const map = new Map<string, any>();
            pinList.forEach(([mid, info]) => map.set(mid, info));
            memoryStore.messagePins.set(cid, map);
          });
        }
        if (Array.isArray(data.messageStars)) data.messageStars.forEach(([k, v]: [string, string[]]) => memoryStore.messageStars.set(k, new Set(v)));
        if (Array.isArray(data.contacts)) data.contacts.forEach(([k, v]: [string, string[]]) => memoryStore.contacts.set(k, new Set(v)));
        if (Array.isArray(data.blocks)) data.blocks.forEach(([k, v]: [string, string[]]) => memoryStore.blocks.set(k, new Set(v)));
        if (Array.isArray(data.reports)) data.reports.forEach(([k, v]: [string, any]) => memoryStore.reports.set(k, v));
        if (Array.isArray(data.auditLogs)) memoryStore.auditLogs = data.auditLogs;
        if (Array.isArray(data.moderationLogs)) memoryStore.moderationLogs = data.moderationLogs;
        if (Array.isArray(data.staffNotes)) data.staffNotes.forEach(([k, v]: [string, any[]]) => memoryStore.staffNotes.set(k, v));
        if (Array.isArray(data.userWarnings)) data.userWarnings.forEach(([k, v]: [string, any[]]) => memoryStore.userWarnings.set(k, v));
        if (Array.isArray(data.statuses)) data.statuses.forEach(([k, v]: [string, any]) => memoryStore.statuses.set(k, v));
        if (Array.isArray(data.statusViews)) data.statusViews.forEach(([k, v]: [string, string[]]) => memoryStore.statusViews.set(k, new Set(v)));
        if (Array.isArray(data.statusLikes)) data.statusLikes.forEach(([k, v]: [string, string[]]) => memoryStore.statusLikes.set(k, new Set(v)));
        if (Array.isArray(data.statusComments)) data.statusComments.forEach(([k, v]: [string, any[]]) => memoryStore.statusComments.set(k, v));
        if (Array.isArray(data.pushSubscriptions)) data.pushSubscriptions.forEach(([k, v]: [string, any]) => memoryStore.pushSubscriptions.set(k, v));
        if (Array.isArray(data.systemApiKeys)) data.systemApiKeys.forEach(([k, v]: [string, any]) => memoryStore.systemApiKeys.set(k, v));

        console.log(`[Database] Hydrated ${memoryStore.users.size} users, ${memoryStore.chats.size} chats, ${memoryStore.messages.size} messages from snapshot.`);
        return;
      }
    }

    // Otherwise, bootstrap from backups/
    const backupsDir = path.join(process.cwd(), 'backups');
    if (fs.existsSync(backupsDir)) {
      console.log('[Database] Initializing memory store from backups directory...');
      const readBackup = (prefix: string) => {
        const files = fs.readdirSync(backupsDir).filter(f => f.startsWith(prefix) && f.endsWith('.json'));
        if (files.length === 0) return [];
        try {
          const raw = fs.readFileSync(path.join(backupsDir, files[0]), 'utf-8');
          return trySalvageJsonArray(raw, files[0]);
        } catch {
          return [];
        }
      };

      const usersArr = readBackup('users');
      usersArr.forEach((u: any) => {
        if (u && u.id) memoryStore.users.set(u.id, u);
      });

      const profilesArr = readBackup('user_profiles');
      profilesArr.forEach((p: any) => {
        if (p && p.user_id) memoryStore.userProfiles.set(p.user_id, p);
      });

      const settingsArr = readBackup('user_settings');
      settingsArr.forEach((s: any) => {
        if (s && s.user_id) memoryStore.userSettings.set(s.user_id, s);
      });

      const sessionsArr = readBackup('user_sessions');
      sessionsArr.forEach((s: any) => {
        if (s && s.id) memoryStore.userSessions.set(s.id, s);
      });

      const chatsArr = readBackup('chats');
      chatsArr.forEach((c: any) => {
        if (c && c.id) memoryStore.chats.set(c.id, c);
      });

      const membersArr = readBackup('chat_members');
      membersArr.forEach((m: any) => {
        if (m && m.chat_id && m.user_id) {
          if (!memoryStore.chatMembers.has(m.chat_id)) memoryStore.chatMembers.set(m.chat_id, new Set());
          memoryStore.chatMembers.get(m.chat_id)!.add(m.user_id);
        }
      });

      const messagesArr = readBackup('messages');
      messagesArr.forEach((msg: any) => {
        if (msg && msg.id) memoryStore.messages.set(msg.id, msg);
      });

      const attachmentsArr = readBackup('attachments');
      attachmentsArr.forEach((att: any) => {
        if (att && att.id) memoryStore.attachments.set(att.id, att);
      });

      const reactionsArr = readBackup('message_reactions');
      reactionsArr.forEach((r: any) => {
        if (r && r.message_id && r.emoji && r.user_id) {
          if (!memoryStore.messageReactions.has(r.message_id)) memoryStore.messageReactions.set(r.message_id, new Map());
          const emojiMap = memoryStore.messageReactions.get(r.message_id)!;
          if (!emojiMap.has(r.emoji)) emojiMap.set(r.emoji, new Set());
          emojiMap.get(r.emoji)!.add(r.user_id);
        }
      });

      const readsArr = readBackup('message_reads');
      readsArr.forEach((rd: any) => {
        if (rd && rd.message_id && rd.user_id) {
          if (!memoryStore.messageReads.has(rd.message_id)) memoryStore.messageReads.set(rd.message_id, new Map());
          memoryStore.messageReads.get(rd.message_id)!.set(rd.user_id, { status: rd.status || 'read', updatedAt: rd.updated_at || rd.read_at || new Date().toISOString() });
        }
      });

      const contactsArr = readBackup('contacts');
      contactsArr.forEach((c: any) => {
        if (c && c.user_id && c.contact_id) {
          if (!memoryStore.contacts.has(c.user_id)) memoryStore.contacts.set(c.user_id, new Set());
          memoryStore.contacts.get(c.user_id)!.add(c.contact_id);
        }
      });

      const blocksArr = readBackup('blocks');
      blocksArr.forEach((b: any) => {
        if (b && b.user_id && b.blocked_id) {
          if (!memoryStore.blocks.has(b.user_id)) memoryStore.blocks.set(b.user_id, new Set());
          memoryStore.blocks.get(b.user_id)!.add(b.blocked_id);
        }
      });

      const pushArr = readBackup('push_subscriptions');
      pushArr.forEach((ps: any) => {
        if (ps && ps.endpoint && ps.user_id) {
          memoryStore.pushSubscriptions.set(ps.endpoint, { userId: ps.user_id, subscription: ps.subscription || ps });
        }
      });

      console.log(`[Database] Successfully bootstrapped ${memoryStore.users.size} users, ${memoryStore.chats.size} chats, ${memoryStore.messages.size} messages from backups.`);
      persistMemoryStore(true);
    }
  } catch (err: any) {
    console.error('[Database] Failed hydrating memory store:', err.message);
  }
}

// Seed initial environment data into memory store
function initMemoryStoreSeed() {
  loadMemoryStoreFromDisk();
  const now = new Date().toISOString();

  // Pre-seed primary Gemini API key if in process.env
  if (process.env.GEMINI_API_KEY) {
    memoryStore.systemApiKeys.set('primary-env-key', {
      id: 'primary-env-key',
      key_value: process.env.GEMINI_API_KEY,
      service_name: 'gemini',
      is_active: true,
      usage_count: 0,
      daily_usage_count: 0,
      usage_date: now,
      last_used: null,
      added_by: 'system',
      created_at: now,
      total_tokens: 0
    });
  }
}

initMemoryStoreSeed();

/* =========================================================================
   Resilient Pool Proxy
   ========================================================================= */

export const pool = {
  query: async (text: string, params: any[] = []): Promise<{ rows: any[]; rowCount: number }> => {
    if (isPostgresHealthy && activePgPool) {
      try {
        const res = await activePgPool.query(text, params);
        return { rows: res.rows, rowCount: res.rowCount || 0 };
      } catch (err: any) {
        // DATA-01: same classification as pgQuery — only connection-class
        // failures flip the engine to memory mode ('timeout' in particular is
        // NOT a connection signal: statement timeouts are deterministic).
        if (isPgConnectionClassError(err)) {
          isPostgresHealthy = false;
        }
      }
    }

    // High-performance query fallback on in-memory store
    const lower = text.toLowerCase();

    // 1. System API Keys query
    if (lower.includes('from system_api_keys')) {
      const rows = Array.from(memoryStore.systemApiKeys.values());
      return { rows, rowCount: rows.length };
    }
    if (lower.includes('insert into system_api_keys')) {
      const [id, key_value, service_name, added_by] = params;
      // BATCH-1 review fix: memory-mode parity for ON CONFLICT (id) DO NOTHING —
      // an existing id means the claim LOSES (rowCount 0), never overwrites.
      if (memoryStore.systemApiKeys.has(id)) {
        return { rows: [], rowCount: 0 };
      }
      const row = {
        id,
        key_value,
        service_name: service_name || 'gemini',
        is_active: true,
        usage_count: 0,
        daily_usage_count: 0,
        usage_date: new Date().toISOString(),
        last_used: null,
        added_by,
        created_at: new Date().toISOString(),
        total_tokens: 0
      };
      memoryStore.systemApiKeys.set(id, row);
      return { rows: [row], rowCount: 1 };
    }
    if (lower.includes('delete from system_api_keys')) {
      const id = params[0];
      const deleted = memoryStore.systemApiKeys.delete(id);
      return { rows: [], rowCount: deleted ? 1 : 0 };
    }
    if (lower.includes('update system_api_keys set is_active')) {
      const [is_active, id] = params;
      const k = memoryStore.systemApiKeys.get(id);
      if (k) k.is_active = is_active;
      return { rows: [], rowCount: k ? 1 : 0 };
    }

    // 2. Statuses query
    if (lower.includes('from statuses where id =') || lower.includes('from statuses where id=')) {
      const statusId = params[0];
      const status = memoryStore.statuses.get(statusId);
      if (status) {
        return { rows: [status], rowCount: 1 };
      }
      return { rows: [], rowCount: 0 };
    }

    if (lower.includes('from statuses')) {
      const currentUserId = params && params[0];
      const now = new Date();
      const rows = Array.from(memoryStore.statuses.values())
        .filter(s => !s.is_archived && (!s.expires_at || new Date(s.expires_at) > now))
        .map(s => {
          const views_count = (memoryStore.statusViews.get(s.id) || new Set()).size;
          const likes_count = (memoryStore.statusLikes.get(s.id) || new Set()).size;
          const user = memoryStore.users.get(s.user_id) || {};
          const has_liked = currentUserId ? (memoryStore.statusLikes.get(s.id)?.has(currentUserId) || false) : false;
          return {
            ...s,
            username: user.username || 'user',
            display_name: user.display_name || user.username || 'User',
            avatar_url: user.avatar_url || '',
            views_count,
            likes_count,
            has_liked
          };
        })
        .sort((a, b) => new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime());
      return { rows, rowCount: rows.length };
    }

    if (lower.includes('insert into statuses')) {
      const [id, user_id, content_type, media_url, text_content, duration_hours, expires_at, settings] = params;
      const row = {
        id,
        user_id,
        content_type,
        media_url,
        text_content,
        duration_hours: duration_hours || 24,
        expires_at,
        settings: typeof settings === 'string' ? JSON.parse(settings) : settings,
        created_at: new Date().toISOString(),
        is_archived: false
      };
      memoryStore.statuses.set(id, row);
      persistMemoryStore();
      return { rows: [row], rowCount: 1 };
    }

    if (lower.includes('delete from statuses where id =') || lower.includes('delete from statuses where id=')) {
      const statusId = params[0];
      memoryStore.statuses.delete(statusId);
      memoryStore.statusViews.delete(statusId);
      memoryStore.statusLikes.delete(statusId);
      memoryStore.statusComments.delete(statusId);
      persistMemoryStore();
      return { rows: [], rowCount: 1 };
    }

    if (lower.includes('insert into status_views')) {
      const [status_id, user_id] = params;
      if (!memoryStore.statusViews.has(status_id)) {
        memoryStore.statusViews.set(status_id, new Set());
      }
      memoryStore.statusViews.get(status_id)!.add(user_id);
      persistMemoryStore();
      return { rows: [{ status_id, user_id, viewed_at: new Date().toISOString() }], rowCount: 1 };
    }

    if (lower.includes('from status_views')) {
      const status_id = params[0];
      const viewerIds = Array.from(memoryStore.statusViews.get(status_id) || []);
      const rows = viewerIds.map(uid => {
        const u = memoryStore.users.get(uid);
        return {
          viewed_at: new Date().toISOString(),
          id: uid,
          username: u?.username || 'user',
          display_name: u?.display_name || u?.username || 'User',
          avatar_url: u?.avatar_url || ''
        };
      });
      return { rows, rowCount: rows.length };
    }

    if (lower.includes('delete from status_views')) {
      const status_id = params[0];
      memoryStore.statusViews.delete(status_id);
      persistMemoryStore();
      return { rows: [], rowCount: 1 };
    }

    if (lower.includes('insert into status_likes')) {
      const [status_id, user_id] = params;
      if (!memoryStore.statusLikes.has(status_id)) {
        memoryStore.statusLikes.set(status_id, new Set());
      }
      memoryStore.statusLikes.get(status_id)!.add(user_id);
      persistMemoryStore();
      return { rows: [{ status_id, user_id }], rowCount: 1 };
    }

    if (lower.includes('delete from status_likes')) {
      const status_id = params[0];
      if (params.length > 1) {
        const user_id = params[1];
        memoryStore.statusLikes.get(status_id)?.delete(user_id);
      } else {
        memoryStore.statusLikes.delete(status_id);
      }
      persistMemoryStore();
      return { rows: [], rowCount: 1 };
    }

    if (lower.includes('insert into status_comments')) {
      const [id, status_id, user_id, content] = params;
      const comm = {
        id,
        status_id,
        user_id,
        content,
        text_content: content,
        created_at: new Date().toISOString()
      };
      const comms = memoryStore.statusComments.get(status_id) || [];
      comms.push(comm);
      memoryStore.statusComments.set(status_id, comms);
      persistMemoryStore();
      return { rows: [comm], rowCount: 1 };
    }

    if (lower.includes('from status_comments')) {
      const status_id = params[0];
      const comms = memoryStore.statusComments.get(status_id) || [];
      const rows = comms.map(c => {
        const u = memoryStore.users.get(c.user_id);
        return {
          ...c,
          username: u?.username || 'user',
          display_name: u?.display_name || u?.username || 'User',
          avatar_url: u?.avatar_url || ''
        };
      });
      return { rows, rowCount: rows.length };
    }

    if (lower.includes('delete from status_comments')) {
      const status_id = params[0];
      memoryStore.statusComments.delete(status_id);
      persistMemoryStore();
      return { rows: [], rowCount: 1 };
    }

    // 3. Attachments query
    if (lower.includes('from attachments where id =')) {
      const att = memoryStore.attachments.get(params[0]);
      return { rows: att ? [att] : [], rowCount: att ? 1 : 0 };
    }

    // 4. Reports & moderation queries
    if (lower.includes('from moderation_audit_logs')) {
      return { rows: memoryStore.moderationLogs.slice(0, 100), rowCount: memoryStore.moderationLogs.length };
    }
    if (lower.includes('from reports')) {
      const rows = Array.from(memoryStore.reports.values());
      return { rows, rowCount: rows.length };
    }

    // 5. Dashboard analytics & count queries fallback
    if (lower.includes('count(*) as count from messages') || lower.includes('count(*) from messages')) {
      if (lower.includes('1 hour') || lower.includes('24 hours') || lower.includes('7 days')) {
        let msThreshold = 3600000;
        if (lower.includes('24 hours')) msThreshold = 86400000;
        if (lower.includes('7 days')) msThreshold = 7 * 86400000;
        const nowMs = Date.now();
        let cnt = 0;
        for (const m of memoryStore.messages.values()) {
          const t = new Date(m.created_at || m.createdAt || 0).getTime();
          if (nowMs - t <= msThreshold) cnt++;
        }
        return { rows: [{ count: String(cnt) }], rowCount: 1 };
      }
      return { rows: [{ count: String(memoryStore.messages.size) }], rowCount: 1 };
    }

    if (lower.includes('count(*) as count from users') || lower.includes('count(*) from users')) {
      return { rows: [{ count: String(memoryStore.users.size) }], rowCount: 1 };
    }

    if (lower.includes('count(*) as count from chats') || lower.includes('count(*) from chats')) {
      return { rows: [{ count: String(memoryStore.chats.size) }], rowCount: 1 };
    }

    if (lower.includes('count(*) as count from attachments') || lower.includes('count(*) from attachments')) {
      if (lower.includes("image/")) {
        let cnt = 0;
        for (const a of memoryStore.attachments.values()) {
          if ((a.mime_type || a.mimeType || '').startsWith('image/')) cnt++;
        }
        return { rows: [{ count: String(cnt) }], rowCount: 1 };
      }
      if (lower.includes("video/")) {
        let cnt = 0;
        for (const a of memoryStore.attachments.values()) {
          if ((a.mime_type || a.mimeType || '').startsWith('video/')) cnt++;
        }
        return { rows: [{ count: String(cnt) }], rowCount: 1 };
      }
      return { rows: [{ count: String(memoryStore.attachments.size) }], rowCount: 1 };
    }

    if (lower.includes('count(*) as count from call_logs') || lower.includes('count(*) from call_logs')) {
      return { rows: [{ count: '0' }], rowCount: 1 };
    }

    if (lower.includes('sum(size) as total from attachments')) {
      let total = 0;
      for (const a of memoryStore.attachments.values()) {
        total += Number(a.size || a.file_size || 0);
      }
      return { rows: [{ total: String(total) }], rowCount: 1 };
    }

    if (lower.includes('pg_size_pretty') || lower.includes('pg_database_size')) {
      const approxBytes = (memoryStore.messages.size * 500) + (memoryStore.users.size * 1000) + (memoryStore.chats.size * 800) + 1024 * 1024;
      const mb = (approxBytes / (1024 * 1024)).toFixed(1);
      return { rows: [{ size: `${mb} MB` }], rowCount: 1 };
    }

    if (lower.includes('pg_stat_user_tables')) {
      return {
        rows: [
          { table_name: 'messages', size: `${Math.max(1, Math.round(memoryStore.messages.size * 0.5))} KB` },
          { table_name: 'users', size: `${Math.max(1, Math.round(memoryStore.users.size * 1.2))} KB` },
          { table_name: 'chats', size: `${Math.max(1, Math.round(memoryStore.chats.size * 0.8))} KB` },
          { table_name: 'attachments', size: `${Math.max(1, Math.round(memoryStore.attachments.size * 0.4))} KB` }
        ],
        rowCount: 4
      };
    }

    // Top active users query
    if (lower.includes('join users u on u.id = m.sender_id') && lower.includes('group by m.sender_id')) {
      const userCounts = new Map<string, number>();
      for (const m of memoryStore.messages.values()) {
        const sid = m.sender_id || m.senderId;
        if (sid) userCounts.set(sid, (userCounts.get(sid) || 0) + 1);
      }
      const sorted = Array.from(userCounts.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5);
      const rows = sorted.map(([uid, count]) => {
        const u = memoryStore.users.get(uid) || {};
        return {
          sender_id: uid,
          username: u.username || 'user',
          display_name: u.display_name || u.displayName || u.username || 'User',
          avatar_url: u.avatar_url || u.avatarUrl || '',
          count: String(count)
        };
      });
      return { rows, rowCount: rows.length };
    }

    // Top active chats query
    if (lower.includes('join chats c on c.id = m.chat_id') && lower.includes('group by m.chat_id')) {
      const chatCounts = new Map<string, number>();
      for (const m of memoryStore.messages.values()) {
        const cid = m.chat_id || m.chatId;
        if (cid) chatCounts.set(cid, (chatCounts.get(cid) || 0) + 1);
      }
      const sorted = Array.from(chatCounts.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5);
      const rows = sorted.map(([cid, count]) => {
        const c = memoryStore.chats.get(cid) || {};
        return {
          chat_id: cid,
          name: c.name || c.title || 'Direct Room',
          count: String(count)
        };
      });
      return { rows, rowCount: rows.length };
    }

    // Top storage users query
    if (lower.includes('total_size') && lower.includes('group by u.id')) {
      return { rows: [], rowCount: 0 };
    }

    // Entity search fallback
    if (lower.includes('from users where id = $1 or lower(username) like') || lower.includes('from users where')) {
      const term = (params[0] || '').toLowerCase();
      const termLike = (params[1] || '').replace(/%/g, '').toLowerCase();
      const rows = Array.from(memoryStore.users.values()).filter(u => {
        const uid = (u.id || '').toLowerCase();
        const uname = (u.username || '').toLowerCase();
        const uemail = (u.email || '').toLowerCase();
        return uid === term || (termLike && (uname.includes(termLike) || uemail.includes(termLike)));
      }).slice(0, 10);
      return { rows, rowCount: rows.length };
    }

    if (lower.includes('from chats where id = $1 or lower(title) like') || lower.includes('from chats where')) {
      const term = (params[0] || '').toLowerCase();
      const termLike = (params[1] || '').replace(/%/g, '').toLowerCase();
      const rows = Array.from(memoryStore.chats.values()).filter(c => {
        const cid = (c.id || '').toLowerCase();
        const cname = (c.name || c.title || '').toLowerCase();
        return cid === term || (termLike && cname.includes(termLike));
      }).slice(0, 10);
      return { rows, rowCount: rows.length };
    }

    if (lower.includes('from messages where id = $1 or lower(content) like') || lower.includes('from messages where')) {
      const term = (params[0] || '').toLowerCase();
      const termLike = (params[1] || '').replace(/%/g, '').toLowerCase();
      const rows = Array.from(memoryStore.messages.values()).filter(m => {
        const mid = (m.id || '').toLowerCase();
        const mtext = (m.content || m.text || '').toLowerCase();
        return mid === term || (termLike && mtext.includes(termLike));
      }).slice(0, 15);
      return { rows, rowCount: rows.length };
    }

    // Generic safe fallback for DDL / migrations / unhandled queries
    return { rows: [], rowCount: 0 };
  },

  get totalCount(): number {
    return activePgPool?.totalCount || 1;
  },

  get idleCount(): number {
    return activePgPool?.idleCount || 1;
  },

  get waitingCount(): number {
    return activePgPool?.waitingCount || 0;
  },

  connect: async () => {
    if (isPostgresHealthy && activePgPool) {
      try {
        return await activePgPool.connect();
      } catch (e) {
        isPostgresHealthy = false;
      }
    }
    return {
      query: pool.query,
      release: () => {},
      on: () => {}
    } as any;
  },

  end: async () => {
    if (activePgPool) {
      try {
        await activePgPool.end();
      } catch (e) {}
    }
  },

  on: (event: any, handler: any) => {
    if (activePgPool) {
      try {
        activePgPool.on(event, handler);
      } catch (e) {}
    }
  }
};

/* =========================================================================
   PostgreSQL helpers, versioned migrations & one-time snapshot import
   ========================================================================= */

/* ── DATA-01 (external audit): PG error classification for health decisions ──
   Only CONNECTION-class failures may flip the engine into memory mode.
   SQL/constraint/permission/syntax errors prove the database is up and
   answering — flipping on them would (a) hide real data bugs behind a silent
   in-memory fallback and (b) strand durable writes in the memory mirror while
   PostgreSQL is perfectly healthy. */

const PG_CONNECTION_CLASS_CODES = new Set([
  // net/libpq transport errors
  'ECONNREFUSED', 'ETIMEDOUT', 'ENOTFOUND', 'ECONNRESET', 'EPIPE',
  'EHOSTUNREACH', 'ENETUNREACH',
  // PG server: connection exception (08xxx) + shutdown/cannot-connect-now
  '08000', '08001', '08003', '08004', '08006', '08P01', '57P01', '57P03'
]);

/**
 * True when `err` means PostgreSQL is unreachable/gone (connection-class).
 * Deterministic application errors — 42xxx syntax/access (42601, 42501),
 * 23xxx integrity (23505 unique_violation, 23503 fk_violation) and 28000/28P01
 * invalid authorization — return FALSE and never change isPostgresHealthy.
 */
function isPgConnectionClassError(err: any): boolean {
  if (!err) return false;
  const code = String((err && err.code) || '');
  if (PG_CONNECTION_CLASS_CODES.has(code)) return true;
  const msg = String((err && err.message) || err || '');
  return /ECONNREFUSED|ETIMEDOUT|ENOTFOUND|ECONNRESET|EPIPE|connection refused|connection terminated|terminating connection|server closed the connection unexpectedly|socket hang up|getaddrinfo|tenant or user not found/i.test(msg);
}

/**
 * Awaited PG query used by chat-domain reads/writes. Returns rows on success,
 * null when PG is unhealthy or the query failed (caller falls back to the
 * in-memory path — identical shapes, same as before this change).
 */
async function pgQuery(text: string, params: any[] = []): Promise<any[] | null> {
  if (!isPostgresHealthy || !activePgPool) return null;
  try {
    const res = await activePgPool.query(text, params);
    return res.rows;
  } catch (err: any) {
    // DATA-01: only connection-class failures flip to memory mode (snapshot
    // writes resume immediately; the 30s health probe restores PG mode).
    // SQL/constraint/permission errors leave PG healthy — see the classifier.
    if (isPgConnectionClassError(err)) {
      isPostgresHealthy = false;
      console.warn('[Database] PG connection-class failure (reverting to memory mode until probe passes):', err.message);
    } else {
      console.warn(`[Database] PG query failed (SQL-class — PG stays healthy, this call falls back to memory): ${err?.code || 'no-code'} ${err.message}`);
    }
    return null;
  }
}

/** Fire-and-forget PG write used by synchronous chat setters (memory stays authoritative for sync reads). */
function queuePg(text: string, params: any[]): void {
  if (!isPostgresHealthy || !activePgPool) return;
  activePgPool.query(text, params).catch((err: any) => {
    if (isPgConnectionClassError(err)) isPostgresHealthy = false;
    else console.warn('[Database] Async PG write failed:', err.message);
  });
}

// ── Poll (WhatsApp/Telegram parity) shared helpers ────────────────────────────
// A poll rides the send path as a structured attachment with this mime type
// (same pattern as contact/location cards) so it survives the client → App →
// WS/REST hop unchanged, and is extracted once at the persistence boundary.
export const POLL_ATTACHMENT_MIME = 'application/x-dirasha-poll';

/** Validates + normalizes a client-supplied poll payload; returns null when invalid. */
export function normalizePollPayload(poll: any): { question: string; options: string[]; allowMultiple: boolean; votes: Record<string, number[]> } | null {
  if (!poll || typeof poll !== 'object') return null;
  const question = typeof poll.question === 'string' ? poll.question.trim() : '';
  if (question.length < 1 || question.length > 200) return null;
  if (!Array.isArray(poll.options) || poll.options.length < 2 || poll.options.length > 10) return null;
  const options: string[] = [];
  for (const o of poll.options) {
    if (typeof o !== 'string') return null;
    const t = o.trim();
    if (t.length < 1 || t.length > 100) return null;
    options.push(t);
  }
  return { question, options, allowMultiple: poll.allowMultiple === true, votes: {} };
}

/**
 * Extracts the poll pseudo-attachment (if any) from an attachments array and
 * returns the remaining real attachments plus the normalized poll (or null).
 */
export function extractPollFromAttachments(attachments: any[]): { attachments: any[]; poll: any | null } {
  if (!Array.isArray(attachments)) return { attachments: [], poll: null };
  const rest = attachments.filter(a => !(a && a.mimeType === POLL_ATTACHMENT_MIME && a.poll));
  if (rest.length === attachments.length) return { attachments, poll: null };
  const pollAtt = attachments.find(a => a && a.mimeType === POLL_ATTACHMENT_MIME && a.poll);
  return { attachments: rest, poll: normalizePollPayload(pollAtt.poll) };
}

/**
 * Applies a vote to a poll object (pure function): single-choice replaces the
 * user's selection, multi-choice toggles membership. Returns the updated poll
 * or null when the poll shape is invalid.
 */
export function applyPollVote(poll: any, userId: string, optionIndexes: number[]): any | null {
  if (!poll || typeof poll !== 'object' || !Array.isArray(poll.options) || poll.options.length === 0) return null;
  const max = poll.options.length;
  const requested = Array.isArray(optionIndexes) ? optionIndexes : [];
  const valid = requested.filter(i => Number.isInteger(i) && i >= 0 && i < max);
  if (valid.length !== requested.length) return null;
  const votes: Record<string, number[]> = { ...(poll.votes || {}) };
  if (poll.allowMultiple === true) {
    const current = new Set<number>(Array.isArray(votes[userId]) ? votes[userId] : []);
    for (const i of valid) {
      if (current.has(i)) current.delete(i);
      else current.add(i);
    }
    const arr = Array.from(current).sort((a, b) => a - b);
    if (arr.length === 0) delete votes[userId];
    else votes[userId] = arr;
  } else {
    if (valid.length === 0) delete votes[userId];
    else votes[userId] = [valid[0]];
  }
  return {
    question: String(poll.question || ''),
    options: poll.options.map((o: any) => String(o)),
    allowMultiple: poll.allowMultiple === true,
    votes
  };
}

/** Versioned migrations: tracked in schema_migrations, applied in order at boot. */
const MIGRATIONS: { version: number; sql: string }[] = [
  {
    version: 1,
    sql: `
      /* Chat-domain hot-path indexes (all idempotent) */
      CREATE INDEX IF NOT EXISTS idx_messages_chat_created_at ON messages (chat_id, created_at DESC);
      CREATE INDEX IF NOT EXISTS idx_messages_sender_id ON messages (sender_id);
      CREATE INDEX IF NOT EXISTS idx_messages_client_message_id ON messages (client_message_id);
      CREATE INDEX IF NOT EXISTS idx_message_reads_message ON message_reads (message_id);
      CREATE INDEX IF NOT EXISTS idx_message_reads_user ON message_reads (user_id);
      CREATE INDEX IF NOT EXISTS idx_chat_members_user ON chat_members (user_id);
      CREATE INDEX IF NOT EXISTS idx_chat_members_chat ON chat_members (chat_id);
      CREATE INDEX IF NOT EXISTS idx_contacts_user ON contacts (user_id);
      CREATE INDEX IF NOT EXISTS idx_contacts_contact ON contacts (contact_id);
      CREATE INDEX IF NOT EXISTS idx_blocks_blocker ON blocks (user_id);
      CREATE INDEX IF NOT EXISTS idx_blocks_blocked ON blocks (blocked_id);
      CREATE INDEX IF NOT EXISTS idx_reactions_message ON message_reactions (message_id);
      CREATE INDEX IF NOT EXISTS idx_statuses_user_expires ON statuses (user_id, expires_at);
      CREATE INDEX IF NOT EXISTS idx_user_sessions_user ON user_sessions (user_id);
      CREATE INDEX IF NOT EXISTS idx_reports_created_at ON reports (created_at);
      CREATE INDEX IF NOT EXISTS idx_moderation_logs_created_at ON moderation_audit_logs (created_at);
      CREATE INDEX IF NOT EXISTS idx_attachments_message ON attachments (message_id);
      CREATE INDEX IF NOT EXISTS idx_message_stars_user ON message_stars (user_id);
      CREATE INDEX IF NOT EXISTS idx_message_stars_message ON message_stars (message_id);
      CREATE INDEX IF NOT EXISTS idx_message_pins_message ON message_pins (message_id);
      CREATE INDEX IF NOT EXISTS idx_chats_updated_at ON chats (updated_at DESC);
      CREATE INDEX IF NOT EXISTS idx_push_subs_user ON push_subscriptions (user_id);

      /* Columns the chat domain needs that the original schema lacked */
      ALTER TABLE chats ADD COLUMN IF NOT EXISTS group_settings JSONB NOT NULL DEFAULT '{}'::jsonb;
      ALTER TABLE chats ADD COLUMN IF NOT EXISTS description TEXT;
      ALTER TABLE messages ADD COLUMN IF NOT EXISTS deleted_for JSONB NOT NULL DEFAULT '[]'::jsonb;
    `
  },
  {
    version: 2,
    sql: `
      /* Message search (v2): guaranteed prefix index that works WITHOUT any
         extension. The pg_trgm GIN upgrade for fast ILIKE is attempted
         separately at boot (best-effort, see runPgMigrations) — when the
         extension is unavailable this btree prefix index is the fallback. */
      CREATE INDEX IF NOT EXISTS idx_messages_content_prefix ON messages (left(content, 32));
    `
  },
  {
    version: 3,
    sql: `
      /* Polls (v3): messages.poll holds the full PollData JSONB (question,
         options, allowMultiple, votes) and is null for normal messages — a
         poll is deleted together with its message via deleted_at filtering.
         attachments.meta round-trips extra attachment JSON (poll pseudo-
         attachments, contact cards, etc.) that would otherwise be lost. */
      ALTER TABLE messages ADD COLUMN IF NOT EXISTS poll JSONB;
      ALTER TABLE attachments ADD COLUMN IF NOT EXISTS meta JSONB;
      CREATE INDEX IF NOT EXISTS idx_messages_poll ON messages(chat_id) WHERE poll IS NOT NULL;
    `
  },
  {
    version: 4,
    sql: `
      /* Channels (v4): Telegram-style one-way broadcast spaces reuse the SAME
         chats/chat_members tables with chats.type='channel' — zero new tables.
         Owner/admins post (chat_members role owner|admin), everyone else is a
         subscriber (role 'member'). The only physical artifact needed is a
         partial index so channel listings can be scanned cheaply. */
      CREATE INDEX IF NOT EXISTS idx_chats_channel ON chats (updated_at DESC) WHERE type = 'channel';
    `
  },
  {
    version: 5,
    sql: `
      /* Scheduled messages (v5): messages.scheduled_at holds the requested send
         time; broadcast_at stays NULL until the delivery sweep fans the message
         out (WhatsApp/Telegram parity). Undelivered scheduled messages are
         invisible to feeds/search/unread counts via the
         (broadcast_at IS NOT NULL OR scheduled_at IS NULL) predicate; the
         partial index powers the 5-minute delivery sweep. The created_at index
         supports the read-receipt retention prune. */
      ALTER TABLE messages ADD COLUMN IF NOT EXISTS scheduled_at TIMESTAMPTZ;
      ALTER TABLE messages ADD COLUMN IF NOT EXISTS broadcast_at TIMESTAMPTZ;
      CREATE INDEX IF NOT EXISTS idx_messages_scheduled ON messages (scheduled_at) WHERE broadcast_at IS NULL AND scheduled_at IS NOT NULL;
      CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages (created_at);
    `
  },
  {
    version: 6,
    sql: `
      /* Security alerts engine (v6): user_sessions.last_active powers the
         session-meta stamp (updateSessionMeta). ip/user_agent are NOT added
         again — the base schema already carries ip_address VARCHAR(45) and
         user_agent TEXT, which createSession + updateSessionMeta write.
         auth_logs is the durable PG parity table for db.logAuthAction (which
         previously lived only in the in-memory snapshot); it is the IP
         baseline source for the new-login / failed-attempt alerts. */
      ALTER TABLE user_sessions ADD COLUMN IF NOT EXISTS last_active TIMESTAMPTZ;
      CREATE TABLE IF NOT EXISTS auth_logs (
          id VARCHAR(128) PRIMARY KEY,
          user_id VARCHAR(128),
          action VARCHAR(64) NOT NULL,
          ip VARCHAR(64),
          user_agent VARCHAR(256),
          metadata JSONB,
          created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
      CREATE INDEX IF NOT EXISTS idx_auth_logs_user_action ON auth_logs (user_id, action, created_at DESC);
    `
  },
  {
    version: 7,
    sql: `
      /* E2EE (v7): Signal-style end-to-end encryption for 1:1 DMs. The server
         is a dumb key directory: it stores PUBLIC keys only (identity DH pub,
         identity signing pub, signed prekey pub + its Ed25519 signature) and
         hands out one one-time prekey per bundle fetch (atomic consumption).
         user_id is VARCHAR(128) — the spec sketch wrote UUID, but users.id is
         VARCHAR(128) in this schema and a FK requires identical types.
         The partial index powers the atomic unconsumed-OPK pick in the
         bundle endpoint (FOR UPDATE SKIP LOCKED subquery). */
      CREATE TABLE IF NOT EXISTS e2ee_registrations (
          user_id VARCHAR(128) PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
          identity_dh_pub TEXT NOT NULL,
          identity_sig_pub TEXT NOT NULL,
          signed_prekey_pub TEXT,
          prekey_signature TEXT NOT NULL,
          registered_at TIMESTAMPTZ NOT NULL DEFAULT now()
      );
      CREATE TABLE IF NOT EXISTS e2ee_one_time_prekeys (
          id BIGSERIAL PRIMARY KEY,
          user_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          key_id INTEGER NOT NULL,
          public_key TEXT NOT NULL,
          consumed BOOLEAN NOT NULL DEFAULT false,
          consumed_at TIMESTAMPTZ,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE(user_id, key_id)
      );
      CREATE INDEX IF NOT EXISTS idx_e2ee_opks_user_unconsumed ON e2ee_one_time_prekeys (user_id) WHERE consumed = false;
    `
  },
  {
    version: 8,
    sql: `
      /* E2EE multi-device (v8): Signal-style LINKED DEVICES. Each device of a
         user registers its own identity/prekey set in
         e2ee_device_registrations (PK (user_id, device_id)) plus a private
         per-device OPK pool in e2ee_device_one_time_prekeys
         (UNIQUE (user_id, device_id, key_id)). The v7 legacy tables remain
         authoritative for old clients: legacy registrations are reported as
         deviceId 'default' in bundle/identity responses, so a user's device
         list = legacy row (if present) + every device-table row. The partial
         index powers the per-device FOR UPDATE SKIP LOCKED OPK pick in the
         bundle endpoint (one OPK consumed PER DEVICE per bundle fetch). */
      CREATE TABLE IF NOT EXISTS e2ee_device_registrations (
        user_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        device_id VARCHAR(64) NOT NULL,
        identity_dh_pub TEXT NOT NULL,
        identity_sig_pub TEXT NOT NULL,
        signed_prekey_pub TEXT NOT NULL,
        prekey_signature TEXT NOT NULL,
        registered_at TIMESTAMPTZ NOT NULL DEFAULT now(),
        PRIMARY KEY (user_id, device_id)
      );
      CREATE TABLE IF NOT EXISTS e2ee_device_one_time_prekeys (
        id BIGSERIAL PRIMARY KEY,
        user_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        device_id VARCHAR(64) NOT NULL,
        key_id INTEGER NOT NULL,
        public_key TEXT NOT NULL,
        consumed BOOLEAN NOT NULL DEFAULT false,
        consumed_at TIMESTAMPTZ,
        created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
        UNIQUE (user_id, device_id, key_id)
      );
      CREATE INDEX IF NOT EXISTS idx_e2ee_device_opk_unconsumed
        ON e2ee_device_one_time_prekeys (user_id, device_id) WHERE consumed = false;
    `
  },
  {
    version: 9,
    sql: `
      /* Passkeys / WebAuthn (v9): ADDITIONAL login method (username-keyed
         discoverable credentials). Passwords remain the primary path — this
         table NEVER touches the E2EE message keys (those live only in each
         device's IndexedDB vault); it protects AUTHENTICATION only.
         public_key is the COSE key, std base64. counter is the WebAuthn
         signature counter used for strict monotonicity (clone detection).
         credential_id is the base64url credential id (globally unique). */
      CREATE TABLE IF NOT EXISTS webauthn_credentials (
          id BIGSERIAL PRIMARY KEY,
          user_id VARCHAR(128) REFERENCES users(id) ON DELETE CASCADE,
          credential_id TEXT UNIQUE NOT NULL,
          public_key TEXT NOT NULL,
          counter BIGINT NOT NULL DEFAULT 0,
          transports TEXT,
          device_type TEXT,
          created_at TIMESTAMPTZ DEFAULT now(),
          last_used_at TIMESTAMPTZ
      );
      CREATE INDEX IF NOT EXISTS idx_webauthn_credentials_user ON webauthn_credentials (user_id);
    `
  },
  {
    version: 10,
    sql: `
      /* E2EE post-quantum (v10, PQXDH design doc §3.6): per-device ML-KEM-768
         quantum prekey columns on e2ee_device_registrations. Both are NULLABLE
         — legacy devices that registered before this migration have no PQ keys
         and keep working over the classical path (bundle reports pq:false for
         them; the initiator runs hybrid only for pq:true devices). The server
         remains a dumb key directory: pq_prekey_pub is the 1184-byte b64
         ML-KEM-768 encapsulation key, pq_prekey_signature is the 64-byte b64
         Ed25519 signature over 'DirashaPQSPK-v1:' + b64(spkPub) + b64(pqPub)
         — the server checks lengths only; the CLIENT verifies the combined
         signature against the device's identity signing key at bundle fetch. */
      ALTER TABLE e2ee_device_registrations ADD COLUMN IF NOT EXISTS pq_prekey_pub TEXT;
      ALTER TABLE e2ee_device_registrations ADD COLUMN IF NOT EXISTS pq_prekey_signature TEXT;
    `
  },
  {
    version: 11,
    sql: `
      /* Key Transparency (v11, AKD-lite per docs/KEY-TRANSPARENCY-DESIGN-ar.md):
         append-only log of E2EE identity/fleet key changes + signed Merkle
         snapshots + admin mismatch-report audit.

         kt_log: every identity/fleet key change appends ONE row. seq is the
         tree position: snapshot tree_version N = root of the Merkle tree over
         the first N log entries (RFC-6962-style checkpoint sequence).
         Deliberately NO FK to users: this is an append-only AUDIT log —
         deleting a user's rows would silently change historical roots and is
         exactly the tampering the consistency proofs must detect.
         key_commitment = sha256 over the user's CURRENT sorted device identity
         pubs (see computeFleetCommitment in
         src/server/services/key_transparency.ts). prev_user_hash = the user's
         previous commitment (NULL on first entry) so clients can diff. */
      CREATE TABLE IF NOT EXISTS kt_log (
        seq BIGSERIAL PRIMARY KEY,
        user_id VARCHAR(128) NOT NULL,
        key_commitment TEXT NOT NULL,
        tree_version BIGINT NOT NULL,
        prev_user_hash TEXT,
        created_at TIMESTAMPTZ NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_kt_log_user_seq ON kt_log (user_id, seq DESC);

      /* kt_snapshots: one signed checkpoint per tree version. signature is
         Ed25519 (std base64) over the canonical string
         'DirashaKT-v1:<tree_version>:<root_hash>' from the KT_SIGNING_KEY
         seed. Empty signature = UNVERIFIED witness mode (no KT_SIGNING_KEY
         configured) — clients must warn, never silently trust. */
      CREATE TABLE IF NOT EXISTS kt_snapshots (
        tree_version BIGINT PRIMARY KEY,
        root_hash TEXT NOT NULL,
        signature TEXT NOT NULL,
        signed_at TIMESTAMPTZ NOT NULL DEFAULT now()
      );

      /* Admin audit log for client-side KT verification failures (fork /
         tamper / signature-mismatch reports from the replay-detect endpoint). */
      CREATE TABLE IF NOT EXISTS kt_mismatch_reports (
        id BIGSERIAL PRIMARY KEY,
        reporter_id VARCHAR(128) NOT NULL,
        subject_user_id VARCHAR(128),
        expected_root TEXT,
        observed_root TEXT,
        detail TEXT,
        created_at TIMESTAMPTZ NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_kt_mismatch_reports_created ON kt_mismatch_reports (created_at DESC);
    `
  },
  {
    version: 12,
    sql: `
      /* Group membership epochs (external-audit E2EE-01/E2EE-02): durable
         membership_version per chat, bumped on every membership change
         (add/remove/leave). Group messages must carry the version they were
         composed under; the send gates reject stale/future versions so no
         message crosses a membership boundary under an old sender-key epoch. */
      ALTER TABLE chats ADD COLUMN IF NOT EXISTS membership_version INTEGER NOT NULL DEFAULT 1;
    `
  },
  {
    version: 13,
    sql: `
      /* AUTH-01 (external audit): atomic refresh-token rotation support.
         spent_refresh_tokens records the CONSUMED refresh token of a session
         (SHA-256 hash ONLY — raw tokens are never persisted) at the moment of
         a compare-and-swap rotation. Reuse detection reads this table instead
         of probing rotated session rows (the old hash lookup excluded rotated
         rows and could therefore never fire). */
      CREATE TABLE IF NOT EXISTS spent_refresh_tokens (
        id BIGSERIAL PRIMARY KEY,
        session_id VARCHAR(128) NOT NULL,
        token_hash TEXT NOT NULL,
        spent_at TIMESTAMPTZ NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_spent_refresh_tokens_session ON spent_refresh_tokens (session_id);

      /* Token-family support (AUTH-01): every session minted from one login
         shares a family_id; detecting reuse of ANY family token revokes the
         whole family (OAuth 2.0 refresh-token rotation BCP). The sessions
         table in this schema is user_sessions (auth_sessions does not exist).
         Existing rows backfill family_id = id — each current session roots
         its own family; createSession() inherits/propagates the family for
         new rows. */
      ALTER TABLE user_sessions ADD COLUMN IF NOT EXISTS family_id VARCHAR(64);
      UPDATE user_sessions SET family_id = id WHERE family_id IS NULL;

      /* DB-01 (partial, DB layer) — RLS posture: see the architectural
         decision block above the MIGRATIONS array in database.ts. In short:
         this app connects as a SINGLE PostgreSQL role which owns every table;
         enabling RLS on the multi-user tables without a non-owner app role +
         per-role policies is either a no-op (owner bypasses RLS) or, with
         FORCE ROW LEVEL SECURITY, an outage (no policy exists to grant the
         owner access). Deliberately NOT enabled here; defense-in-depth stays
         at the app layer (sendGate/requireAuth) until a dedicated app role
         with policies is introduced. */
    `
  },
  {
    /* BATCH-6 (ADV-03 — adversarial review): scheduled messages must carry the
       membership_version they were composed under. The delivery sweep now
       fail-closes when the epoch moved (compose_mv != current) — an old-epoch
       ciphertext can no longer cross a membership boundary via the sweep. */
    version: 14,
    sql: `
      ALTER TABLE messages ADD COLUMN IF NOT EXISTS compose_mv INTEGER;
    `
  }
];

/* =========================================================================
   ARCHITECTURAL DECISION — Row Level Security (DB-01, external audit)
   =========================================================================
   POSTURE: RLS is DEFERRED, deliberately, as of migration v13 (2026-11).

   Why not enabled today:
   1. The app uses a single PostgreSQL connection user (DATABASE_URL role)
      which OWNS every table in this schema. PostgreSQL applies RLS only to
      non-owner roles unless FORCE ROW LEVEL SECURITY is set — so ENABLE ROW
      LEVEL SECURITY alone is a silent no-op for this role (zero added
      protection, false sense of defense).
   2. FORCE RLS with no per-role policies would make every table deny-all for
      the owning app role — i.e. a guaranteed outage. Deny-by-default policies
      that still let the app work require a DEDICATED non-owner app role
      (e.g. dirasha_app) plus per-table policies keyed on a session-bound
      GUC (e.g. SET app.user_id) — an infra + connection-pooling change that
      must be owned end-to-end, not smuggled into a migration.

   Where multi-user isolation IS enforced today (defense-in-depth chain):
   - Every route is gated by requireAuth / sendGate / requireRole in server.ts
     (app-layer authorization).
   - Chat scoping is membership-based (getChatsForUser / chat_members), never
     raw table scans; export projections whitelist columns (tested in
     tests/db-tls.test.ts).
   - Direct DB access is limited to the server process; no per-tenant DB
     credentials exist.

   Re-visit RLS when: a dedicated app role is introduced (no table ownership),
   per-row policies can be written against that role, and the connection pool
   can SET ROLE / set app.user_id per request. Until then this block is the
   recorded rationale for RLS not being enabled (asserted statically by
   tests/db-fail-closed.test.ts).
   ========================================================================= */

let pgSchemaReady = false;

async function runPgMigrations(): Promise<void> {
  if (!isPostgresHealthy || !activePgPool) return;
  // Companion to migration v2: attempt the pg_trgm GIN index for fast ILIKE
  // search. Best-effort — CREATE EXTENSION may be denied (managed PG) or the
  // extension may not exist; the btree prefix index from v2 is the fallback.
  try {
    await activePgPool.query('CREATE EXTENSION IF NOT EXISTS pg_trgm');
    await activePgPool.query('CREATE INDEX IF NOT EXISTS idx_messages_content_trgm ON messages USING gin (content gin_trgm_ops)');
    console.log('[DB Migration] pg_trgm GIN content index ready (fast ILIKE search).');
  } catch (trgmErr: any) {
    console.warn('[DB Migration] pg_trgm unavailable — ILIKE search falls back to seq scan / prefix index:', trgmErr.message);
  }
  try {
    await activePgPool.query('CREATE TABLE IF NOT EXISTS schema_migrations (version INT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW())');
    await activePgPool.query('CREATE TABLE IF NOT EXISTS migration_marker (key TEXT PRIMARY KEY, value TEXT)');
    for (const migration of MIGRATIONS) {
      const done = await activePgPool.query('SELECT 1 FROM schema_migrations WHERE version = $1', [migration.version]);
      if (done.rows.length > 0) continue;
      await activePgPool.query(migration.sql);
      await activePgPool.query('INSERT INTO schema_migrations (version) VALUES ($1) ON CONFLICT (version) DO NOTHING', [migration.version]);
      console.log(`[DB Migration] Applied migration v${migration.version}.`);
    }
  } catch (err: any) {
    // DATA-01: at boot in production a failed migration means the durable
    // schema is not guaranteed — rethrow so init() aborts instead of
    // memory-serving. The probe-restore caller (ensurePostgresFullyReady)
    // catches and logs; it runs only after a successful boot-time pass.
    if (process.env.NODE_ENV === 'production') throw err;
    console.warn('[DB Migration] Migration runner warning:', err.message);
    return;
  }
  pgSchemaReady = true;
}

/**
 * Batched INSERT helper with per-batch savepoints: on a batch failure (e.g. a
 * single row violating an FK) the batch falls back to row-by-row inserts so
 * only bad rows are skipped. Used exclusively inside the import transaction.
 */
async function batchInsertRows(
  client: pg.PoolClient,
  table: string,
  columns: string[],
  rows: any[][]
): Promise<{ ok: number; failed: number }> {
  const CHUNK = 200;
  let ok = 0;
  let failed = 0;
  const safeTable = table.replace(/[^a-zA-Z_]/g, '');
  for (let i = 0; i < rows.length; i += CHUNK) {
    const batch = rows.slice(i, i + CHUNK);
    const sp = `sp_${safeTable}_${i}`;
    const tuples = batch.map((_, bi) => {
      const base = bi * columns.length;
      return '(' + columns.map((_, ci) => '$' + (base + ci + 1)).join(', ') + ')';
    });
    const flat: any[] = [];
    batch.forEach(r => flat.push(...r));
    await client.query(`SAVEPOINT ${sp}`);
    try {
      await client.query(
        `INSERT INTO ${table} (${columns.join(', ')}) VALUES ${tuples.join(', ')} ON CONFLICT DO NOTHING`,
        flat
      );
      await client.query(`RELEASE SAVEPOINT ${sp}`);
      ok += batch.length;
    } catch (batchErr: any) {
      await client.query(`ROLLBACK TO SAVEPOINT ${sp}`);
      await client.query(`RELEASE SAVEPOINT ${sp}`);
      for (let j = 0; j < batch.length; j++) {
        const rsp = `${sp}_r${j}`;
        await client.query(`SAVEPOINT ${rsp}`);
        try {
          const placeholders = batch[j].map((_, ci) => '$' + (ci + 1)).join(', ');
          await client.query(
            `INSERT INTO ${table} (${columns.join(', ')}) VALUES (${placeholders}) ON CONFLICT DO NOTHING`,
            batch[j]
          );
          await client.query(`RELEASE SAVEPOINT ${rsp}`);
          ok++;
        } catch (rowErr: any) {
          await client.query(`ROLLBACK TO SAVEPOINT ${rsp}`);
          await client.query(`RELEASE SAVEPOINT ${rsp}`);
          failed++;
        }
      }
    }
  }
  return { ok, failed };
}

/**
 * One-time (marker-guarded) import of the encrypted local snapshot into
 * PostgreSQL. The snapshot file is NEVER deleted — it stays as a backup.
 * Re-runs are idempotent (ON CONFLICT DO NOTHING). If the snapshot file was
 * written again after the marker (e.g. chat data accumulated during a PG
 * outage), the import re-runs to pick up the delta.
 */
async function importSnapshotToPostgres(): Promise<void> {
  if (!isPostgresHealthy || !activePgPool) return;
  try {
    const markerRes = await activePgPool.query(`SELECT value FROM migration_marker WHERE key = 'snapshot_import_v1'`);
    let markerMtime = 0;
    if (markerRes.rows.length > 0) {
      markerMtime = Number(markerRes.rows[0].value) || 0;
      let snapshotMtime = 0;
      try {
        snapshotMtime = fs.statSync(SNAPSHOT_FILE).mtimeMs;
      } catch {
        return; // no snapshot file — nothing to import
      }
      if (snapshotMtime <= markerMtime) return; // already imported, snapshot unchanged
    } else if (!fs.existsSync(SNAPSHOT_FILE)) {
      await activePgPool.query(`INSERT INTO migration_marker (key, value) VALUES ('snapshot_import_v1', $1)`, ['0']);
      return;
    }

    let raw = fs.readFileSync(SNAPSHOT_FILE, 'utf-8');
    if (raw.startsWith(SNAPSHOT_ENC_PREFIX)) {
      raw = decryptSnapshot(raw);
    }
    const data = JSON.parse(raw);

    // ── Build parameterized rows (users are NOT imported — they already live in PG) ──
    const chatRows: any[][] = [];
    if (Array.isArray(data.chats)) {
      for (const [cid, c] of data.chats) {
        if (!cid || !c) continue;
        chatRows.push([
          cid,
          c.type || 'one-to-one',
          c.name || null,
          c.avatar_url || c.avatarUrl || null,
          c.created_at || c.createdAt || null,
          c.updated_at || c.updatedAt || null,
          JSON.stringify(c.group_settings || {}),
          c.description || null,
          // BATCH-2 review fix (DIR-MV-01 follow-up): the one-time memory→PG
          // migration must carry membership_version too — otherwise the import
          // resets PG mv to 1 and epoch-gated clients get stuck 409s.
          Number((c as any).membership_version) || 1
        ]);
      }
    }

    const rolesByChat = new Map<string, Map<string, string>>();
    if (Array.isArray(data.chatRoles)) {
      for (const [cid, roles] of data.chatRoles) {
        if (Array.isArray(roles)) rolesByChat.set(cid, new Map(roles as [string, string][]));
      }
    }
    const memberRows: any[][] = [];
    if (Array.isArray(data.chatMembers)) {
      for (const [cid, members] of data.chatMembers) {
        if (!cid || !Array.isArray(members)) continue;
        for (const uid of members) {
          if (!uid) continue;
          memberRows.push([cid, uid, rolesByChat.get(cid)?.get(uid) || 'member']);
        }
      }
    }

    const messageById = new Map<string, any>();
    if (Array.isArray(data.messages)) {
      for (const [mid, m] of data.messages) {
        if (mid && m) messageById.set(mid, m);
      }
    }
    // Parents before children (reply_to_id FK), oldest first
    const sortedMessages = Array.from(messageById.entries()).sort((a, b) =>
      new Date(a[1].created_at || a[1].createdAt || 0).getTime() - new Date(b[1].created_at || b[1].createdAt || 0).getTime()
    );
    const messageRows = sortedMessages.map(([mid, m]) => [
      mid,
      m.chat_id || m.chatId,
      m.sender_id || m.senderId,
      m.sender_name || m.senderName || null,
      m.content ?? '',
      m.type || 'text',
      m.reply_to_id || m.replyToId || null,
      m.created_at || m.createdAt || null,
      m.edited_at || m.editedAt || null,
      m.deleted_at || m.deletedAt || null,
      m.client_message_id || m.clientMessageId || null,
      m.expires_at || m.expiresAt || null,
      JSON.stringify(Array.isArray(m.deleted_for) ? m.deleted_for : (Array.isArray(m.deletedFor) ? m.deletedFor : []))
    ]);

    const attachmentRows: any[][] = [];
    if (Array.isArray(data.attachments)) {
      for (const [attId, a] of data.attachments) {
        if (!attId || !a) continue;
        attachmentRows.push([
          attId,
          a.message_id || null,
          a.name || 'attachment',
          Number(a.size) || 0,
          a.mime_type || a.mimeType || 'application/octet-stream',
          a.url || '',
          a.created_at || null
        ]);
      }
    }

    const reactionRows: any[][] = [];
    if (Array.isArray(data.messageReactions)) {
      for (const [mid, emojis] of data.messageReactions) {
        if (!mid || !Array.isArray(emojis)) continue;
        for (const [emoji, userIds] of emojis) {
          if (!emoji || !Array.isArray(userIds)) continue;
          for (const uid of userIds) {
            if (uid) reactionRows.push([mid, uid, emoji]);
          }
        }
      }
    }

    const readRows: any[][] = [];
    if (Array.isArray(data.messageReads)) {
      for (const [mid, reads] of data.messageReads) {
        if (!mid || !Array.isArray(reads)) continue;
        const msg = messageById.get(mid);
        const chatId = msg ? (msg.chat_id || msg.chatId) : null;
        if (!chatId) continue;
        for (const [uid, st] of reads) {
          if (!uid) continue;
          const status = typeof st === 'string' ? st : (st && st.status) || 'delivered';
          const updatedAt = typeof st === 'object' && st && st.updatedAt ? st.updatedAt : new Date().toISOString();
          readRows.push([mid, uid, chatId, status, updatedAt]);
        }
      }
    }

    const pinRows: any[][] = [];
    if (Array.isArray(data.messagePins)) {
      for (const [cid, pins] of data.messagePins) {
        if (!cid || !Array.isArray(pins)) continue;
        for (const [mid, info] of pins) {
          if (!mid) continue;
          pinRows.push([cid, mid, (info && info.pinnedBy) || null, (info && info.pinnedAt) || new Date().toISOString()]);
        }
      }
    }

    const starRows: any[][] = [];
    if (Array.isArray(data.messageStars)) {
      for (const [uid, stars] of data.messageStars) {
        if (!uid || !Array.isArray(stars)) continue;
        for (const mid of stars) {
          if (mid) starRows.push([uid, mid]);
        }
      }
    }

    const contactRows: any[][] = [];
    if (Array.isArray(data.contacts)) {
      for (const [uid, list] of data.contacts) {
        if (!uid || !Array.isArray(list)) continue;
        for (const cid of list) {
          if (cid && cid !== uid) contactRows.push([uid, cid]);
        }
      }
    }

    const blockRows: any[][] = [];
    if (Array.isArray(data.blocks)) {
      for (const [uid, list] of data.blocks) {
        if (!uid || !Array.isArray(list)) continue;
        for (const bid of list) {
          if (bid && bid !== uid) blockRows.push([uid, bid]);
        }
      }
    }

    const client = await activePgPool.connect();
    let chatsOk = 0;
    let messagesOk = 0;
    try {
      await client.query('BEGIN');
      const rChats = await batchInsertRows(client, 'chats',
        ['id', 'type', 'name', 'avatar_url', 'created_at', 'updated_at', 'group_settings', 'description', 'membership_version'], chatRows);
      const rMembers = await batchInsertRows(client, 'chat_members', ['chat_id', 'user_id', 'role'], memberRows);
      const rMessages = await batchInsertRows(client, 'messages',
        ['id', 'chat_id', 'sender_id', 'sender_name', 'content', 'type', 'reply_to_id', 'created_at', 'edited_at', 'deleted_at', 'client_message_id', 'expires_at', 'deleted_for'], messageRows);
      const rAttachments = await batchInsertRows(client, 'attachments',
        ['id', 'message_id', 'name', 'size', 'mime_type', 'url', 'created_at'], attachmentRows);
      const rReactions = await batchInsertRows(client, 'message_reactions',
        ['message_id', 'user_id', 'reaction_emoji'], reactionRows);
      const rReads = await batchInsertRows(client, 'message_reads',
        ['message_id', 'user_id', 'chat_id', 'status', 'updated_at'], readRows);
      const rPins = await batchInsertRows(client, 'message_pins',
        ['chat_id', 'message_id', 'pinned_by', 'pinned_at'], pinRows);
      const rStars = await batchInsertRows(client, 'message_stars', ['user_id', 'message_id'], starRows);
      const rContacts = await batchInsertRows(client, 'contacts', ['user_id', 'contact_id'], contactRows);
      const rBlocks = await batchInsertRows(client, 'blocks', ['user_id', 'blocked_id'], blockRows);
      await client.query('COMMIT');

      chatsOk = rChats.ok;
      messagesOk = rMessages.ok;
      let snapshotMtime = '0';
      try { snapshotMtime = String(fs.statSync(SNAPSHOT_FILE).mtimeMs); } catch { /* file vanished — keep 0 */ }
      await activePgPool.query(
        `INSERT INTO migration_marker (key, value) VALUES ('snapshot_import_v1', $1)
         ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value`,
        [snapshotMtime]
      );
      if (rMessages.failed > 0 || rChats.failed > 0 || rMembers.failed > 0) {
        console.warn(`[DB Migration] Skipped rows with dangling references: chats=${rChats.failed} members=${rMembers.failed} messages=${rMessages.failed} attachments=${rAttachments.failed} reactions=${rReactions.failed} reads=${rReads.failed} pins=${rPins.failed} stars=${rStars.failed} contacts=${rContacts.failed} blocks=${rBlocks.failed}`);
      }
      console.log(`[DB Migration] Imported ${messagesOk} messages, ${chatsOk} chats from snapshot.`);
    } catch (txErr: any) {
      await client.query('ROLLBACK').catch(() => {});
      console.warn('[DB Migration] Snapshot import transaction failed (snapshot kept as backup; will retry on next boot):', txErr.message);
    } finally {
      client.release();
    }
  } catch (err: any) {
    console.warn('[DB Migration] Snapshot import skipped:', err.message);
  }
}

/**
 * Load PG chat-domain truth into the in-memory store so the synchronous
 * accessors (getChatInfo, getChatRole, findChatByInviteCode, group settings…)
 * — which cannot await PostgreSQL — observe PG data after a restart.
 */
async function hydrateChatDomainFromPg(): Promise<void> {
  if (!isPostgresHealthy || !activePgPool) return;
  try {
    const chats = await pgQuery('SELECT * FROM chats');
    if (chats) {
      for (const c of chats) {
        let gs = c.group_settings || {};
        if (typeof gs === 'string') {
          try { gs = JSON.parse(gs); } catch { gs = {}; }
        }
        memoryStore.chats.set(c.id, {
          id: c.id,
          type: c.type || 'one-to-one',
          name: c.name,
          avatar_url: c.avatar_url || null,
          description: c.description || '',
          group_settings: gs,
          // BATCH-2 (DIR-MV-01): hydration MUST carry the authoritative PG
          // membership_version — otherwise getMembershipVersion defaults to 1
          // after every restart and the epoch gate compares against a reset value.
          membership_version: Number(c.membership_version) || 1,
          created_at: c.created_at ? new Date(c.created_at).toISOString() : new Date().toISOString(),
          updated_at: c.updated_at ? new Date(c.updated_at).toISOString() : new Date().toISOString()
        });
      }
    }
    const members = await pgQuery('SELECT chat_id, user_id, role FROM chat_members');
    if (members) {
      for (const m of members) {
        if (!m.chat_id || !m.user_id) continue;
        if (!memoryStore.chatMembers.has(m.chat_id)) memoryStore.chatMembers.set(m.chat_id, new Set());
        memoryStore.chatMembers.get(m.chat_id)!.add(m.user_id);
        if (m.role && m.role !== 'member') {
          if (!memoryStore.chatRoles.has(m.chat_id)) memoryStore.chatRoles.set(m.chat_id, new Map());
          memoryStore.chatRoles.get(m.chat_id)!.set(m.user_id, m.role);
        }
      }
    }
    const contacts = await pgQuery('SELECT user_id, contact_id FROM contacts');
    if (contacts) {
      for (const c of contacts) {
        if (!c.user_id || !c.contact_id) continue;
        if (!memoryStore.contacts.has(c.user_id)) memoryStore.contacts.set(c.user_id, new Set());
        memoryStore.contacts.get(c.user_id)!.add(c.contact_id);
      }
    }
    const blocks = await pgQuery('SELECT user_id, blocked_id FROM blocks');
    if (blocks) {
      for (const b of blocks) {
        if (!b.user_id || !b.blocked_id) continue;
        if (!memoryStore.blocks.has(b.user_id)) memoryStore.blocks.set(b.user_id, new Set());
        memoryStore.blocks.get(b.user_id)!.add(b.blocked_id);
      }
    }
    const stars = await pgQuery('SELECT user_id, message_id FROM message_stars');
    if (stars) {
      for (const s of stars) {
        if (!s.user_id || !s.message_id) continue;
        if (!memoryStore.messageStars.has(s.user_id)) memoryStore.messageStars.set(s.user_id, new Set());
        memoryStore.messageStars.get(s.user_id)!.add(s.message_id);
      }
    }
    console.log(`[Database] Hydrated chat-domain cache from PostgreSQL (${memoryStore.chats.size} chats).`);
  } catch (err: any) {
    console.warn('[Database] Chat-domain hydration warning:', err.message);
  }
}

/** Full PG readiness: schema + tracked migrations + snapshot import + hydration. */
async function ensurePostgresFullyReady(): Promise<void> {
  if (!isPostgresHealthy || !activePgPool) return;
  try {
    await db.bootstrapPostgresSchema();
  } catch { /* bootstrapPostgresSchema swallows its own errors */ }
  try {
    // DATA-01: runPgMigrations rethrows in production — this is the
    // probe-restore path (PG just came back), not boot; a failure here must
    // not crash the process as an unhandled rejection. Log loudly and keep
    // the engine in its current mode; the next probe re-runs setup.
    await runPgMigrations();
  } catch (err: any) {
    console.error('[DB Migration] Migration runner FAILED on probe-restore (schema may be incomplete):', err.message);
    return;
  }
  await importSnapshotToPostgres();
  await hydrateChatDomainFromPg();
}

/* ── Health probe: restores PG mode after transient failure (30s cadence) ── */
let pgHealthProbeTimer: NodeJS.Timeout | null = null;
let pgHealthProbeInFlight = false;
let pgHealthProbeFailures = 0;

function startPostgresHealthProbe(): void {
  if (pgHealthProbeTimer || process.env.DB_HEALTH_PROBE === 'false' || !activePgPool) return;
  pgHealthProbeTimer = setInterval(async () => {
    if (pgHealthProbeInFlight || !activePgPool) return; // guard against probe pile-up
    pgHealthProbeInFlight = true;
    try {
      await activePgPool.query('SELECT 1');
      pgHealthProbeFailures = 0;
      if (!isPostgresHealthy) {
        isPostgresHealthy = true;
        console.log('[Database] PostgreSQL health restored — switching back to PG-durable mode.');
        // Pick up anything written while PG was down (snapshot persisted it),
        // and make sure schema/migrations exist even if boot-time setup failed.
        void ensurePostgresFullyReady();
      }
    } catch (err: any) {
      pgHealthProbeFailures++;
      if (pgHealthProbeFailures >= 2 && isPostgresHealthy) {
        isPostgresHealthy = false;
        console.warn('[Database] PostgreSQL health probe failing repeatedly — reverting to memory mode:', err.message);
      }
    } finally {
      pgHealthProbeInFlight = false;
    }
  }, 30000);
  pgHealthProbeTimer.unref?.();
}

/* =========================================================================
   RelationalDatabase Class Implementation
   ========================================================================= */

export class RelationalDatabase {
  private isInitialized = false;
  private initPromise: Promise<void> | null = null;
  /** Bounded user cache: entries expire after 5 min, size capped at 5000 (oldest dropped). */
  public userCache = new Map<string, { user: User; cachedAt: number }>();
  private static readonly USER_CACHE_TTL_MS = 5 * 60 * 1000;
  private static readonly USER_CACHE_MAX = 5000;

  private userCacheGet(id: string): User | undefined {
    const entry = this.userCache.get(id);
    if (!entry) return undefined;
    if (Date.now() - entry.cachedAt > RelationalDatabase.USER_CACHE_TTL_MS) {
      this.userCache.delete(id);
      return undefined;
    }
    return entry.user;
  }

  private userCacheSet(id: string, user: User): void {
    if (this.userCache.size >= RelationalDatabase.USER_CACHE_MAX) {
      let oldestKey: string | null = null;
      let oldest = Infinity;
      for (const [k, v] of this.userCache) {
        if (v.cachedAt < oldest) { oldest = v.cachedAt; oldestKey = k; }
      }
      if (oldestKey) this.userCache.delete(oldestKey);
    }
    this.userCache.set(id, { user, cachedAt: Date.now() });
  }

  constructor() {
    this.init().catch(err => {
      // DATA-01 fail-fast: init() throws in production when DATABASE_URL is
      // configured but PostgreSQL is unreachable/unfinished at boot. Abort the
      // process instead of silently serving from the in-memory engine (same
      // shape as the TLS fail-closed exit in applyDbTlsDecision).
      if (process.env.NODE_ENV === 'production') {
        console.error('[Database] Boot aborted (DATA-01 fail-fast):', err.message);
        process.exit(1);
      }
      console.warn('[Database] Initial connection check:', err.message);
    });
  }

  public async init(): Promise<void> {
    if (this.isInitialized) return;
    if (this.initPromise) return this.initPromise;

    this.initPromise = (async () => {
      initMemoryStoreSeed();

      if (primaryConnectionString) {
        try {
          const testPool = createPoolForString(primaryConnectionString);
          const res = await testPool.query('SELECT 1 as connected');
          if (res.rows.length > 0) {
            activePgPool = testPool;
            isPostgresHealthy = true;
            console.log('[Database] PostgreSQL connected successfully.');
            await this.bootstrapPostgresSchema();
            await runPgMigrations();
            await importSnapshotToPostgres();
            await hydrateChatDomainFromPg();
            if (process.env.NODE_ENV === 'production' && !isPostgresHealthy) {
              // DATA-01: PG dropped mid-boot-setup (e.g. during hydration) —
              // the durable path never came up; refuse memory-mode serving.
              throw new Error('PostgreSQL became unreachable during boot-time schema/migration setup');
            }
            startKeepAliveHeartbeat();
            startPostgresHealthProbe();
          } else {
            // Pathological: connected but SELECT 1 returned nothing — treat
            // like a failed boot probe (outer catch applies DATA-01 policy).
            throw new Error('boot probe (SELECT 1) returned no rows');
          }
        } catch (err: any) {
          isPostgresHealthy = false;
          if (process.env.NODE_ENV === 'production') {
            // DATA-01 fail-fast: never serve writes from memory while
            // DATABASE_URL is configured — a write that only landed in the
            // in-memory mirror would be reported as success but would not be
            // durable. Fix the database (or unset DATABASE_URL explicitly).
            const fatal = '[Database] FATAL (DATA-01): DATABASE_URL is configured and PostgreSQL is unreachable or unfinished at boot — aborting instead of falling back to the in-memory engine.';
            console.error(fatal, '\nCaused by:', err.message);
            throw new Error(fatal);
          }
          console.warn('[Database] PostgreSQL connection unreachable at startup (Running on in-memory storage engine):', err.message);
          // Keep probing: when PG comes back the probe restores durable mode.
          startPostgresHealthProbe();
        }
      } else {
        console.log('[Database] Running on high-performance in-memory relational database.');
      }

      this.isInitialized = true;
    })();

    return this.initPromise;
  }

  public async bootstrapPostgresSchema(): Promise<void> {
    if (!isPostgresHealthy || !activePgPool) return;

    try {
      await activePgPool.query(`
        CREATE TABLE IF NOT EXISTS users (
            id VARCHAR(128) PRIMARY KEY,
            phone_number VARCHAR(32) UNIQUE NOT NULL,
            username VARCHAR(64) UNIQUE,
            display_name VARCHAR(128) NOT NULL DEFAULT '',
            profile_completed BOOLEAN DEFAULT FALSE,
            avatar_url TEXT,
            banner_url TEXT,
            background_banner_url TEXT,
            bio TEXT,
            verified BOOLEAN DEFAULT FALSE,
            online_status VARCHAR(16) DEFAULT 'offline',
            last_seen TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            banner_shadow_opacity INTEGER DEFAULT 60,
            bg_banner_shadow_opacity INTEGER DEFAULT 20,
            role VARCHAR(32) DEFAULT 'user',
            is_system_user BOOLEAN DEFAULT FALSE,
            is_banned BOOLEAN DEFAULT FALSE,
            banned_at TIMESTAMP WITH TIME ZONE,
            banned_until TIMESTAMP WITH TIME ZONE,
            banned_by VARCHAR(128),
            ban_reason TEXT,
            muted_until TIMESTAMP WITH TIME ZONE,
            muted_at TIMESTAMP WITH TIME ZONE,
            muted_by VARCHAR(128),
            mute_reason TEXT,
            muted_from_ai_until TIMESTAMP WITH TIME ZONE
        );

        CREATE TABLE IF NOT EXISTS phone_otps_ARCHIVE_DROP (
            _legacy INT
        );
        DROP TABLE IF EXISTS phone_otps_ARCHIVE_DROP;

        CREATE TABLE IF NOT EXISTS user_storage_accounts (
            user_id VARCHAR(128) PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
            provider VARCHAR(32) NOT NULL,
            endpoint TEXT NOT NULL,
            region VARCHAR(64) NOT NULL DEFAULT 'auto',
            bucket VARCHAR(128) NOT NULL,
            public_base_url TEXT NOT NULL,
            credentials_encrypted TEXT NOT NULL,
            force_path_style BOOLEAN DEFAULT FALSE,
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );

        /* === Phone-free era migrations (idempotent) === */
        DROP TABLE IF EXISTS phone_otps;
        ALTER TABLE users ALTER COLUMN phone_number DROP NOT NULL;
        ALTER TABLE users ADD COLUMN IF NOT EXISTS password_hash TEXT;
        ALTER TABLE users ADD COLUMN IF NOT EXISTS pin_hash TEXT;
        ALTER TABLE users ADD COLUMN IF NOT EXISTS device_key_hash VARCHAR(128);
        ALTER TABLE users ADD COLUMN IF NOT EXISTS login_attempts INTEGER DEFAULT 0;
        ALTER TABLE users ADD COLUMN IF NOT EXISTS locked_until TIMESTAMP WITH TIME ZONE;
        ALTER TABLE users ADD COLUMN IF NOT EXISTS reset_token_hash VARCHAR(128);
        ALTER TABLE users ADD COLUMN IF NOT EXISTS reset_token_expires TIMESTAMP WITH TIME ZONE;
        ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_secret TEXT;
        ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_last_counter INTEGER DEFAULT 0;
        ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_backup_hashes TEXT;

        CREATE TABLE IF NOT EXISTS user_profiles (
            user_id VARCHAR(128) PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
            bio TEXT,
            avatar TEXT,
            banner TEXT,
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS user_settings (
            user_id VARCHAR(128) PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
            settings JSONB NOT NULL DEFAULT '{}'::jsonb
        );

        CREATE TABLE IF NOT EXISTS user_sessions (
            id VARCHAR(128) PRIMARY KEY,
            user_id VARCHAR(128) REFERENCES users(id) ON DELETE CASCADE,
            refresh_token_hash VARCHAR(255) UNIQUE NOT NULL,
            user_agent TEXT,
            ip_address VARCHAR(45),
            is_revoked BOOLEAN DEFAULT FALSE,
            expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );

        /* Auth audit trail (durable PG parity for logAuthAction — the security
           alerts engine reads the ip baseline from here). IPs are stored
           truncated (24 chars) by the writers; never any tokens here. */
        CREATE TABLE IF NOT EXISTS auth_logs (
            id VARCHAR(128) PRIMARY KEY,
            user_id VARCHAR(128),
            action VARCHAR(64) NOT NULL,
            ip VARCHAR(64),
            user_agent VARCHAR(256),
            metadata JSONB,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_auth_logs_user_action ON auth_logs (user_id, action, created_at DESC);

        CREATE TABLE IF NOT EXISTS chats (
            id VARCHAR(128) PRIMARY KEY,
            type VARCHAR(32) NOT NULL DEFAULT 'one-to-one',
            name VARCHAR(128),
            avatar_url TEXT,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            disappearing_messages_timer VARCHAR(16) DEFAULT 'off'
        );

        CREATE TABLE IF NOT EXISTS chat_members (
            chat_id VARCHAR(128) REFERENCES chats(id) ON DELETE CASCADE,
            user_id VARCHAR(128) REFERENCES users(id) ON DELETE CASCADE,
            role VARCHAR(16) DEFAULT 'member',
            joined_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (chat_id, user_id)
        );
        ALTER TABLE chat_members ADD COLUMN IF NOT EXISTS role VARCHAR(16) DEFAULT 'member';

        CREATE TABLE IF NOT EXISTS messages (
            id VARCHAR(128) PRIMARY KEY,
            chat_id VARCHAR(128) NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
            sender_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            sender_name VARCHAR(128),
            content TEXT NOT NULL,
            type VARCHAR(32) NOT NULL DEFAULT 'text',
            reply_to_id VARCHAR(128) REFERENCES messages(id) ON DELETE SET NULL,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            edited_at TIMESTAMP WITH TIME ZONE,
            deleted_at TIMESTAMP WITH TIME ZONE,
            client_message_id VARCHAR(128) UNIQUE,
            expires_at TIMESTAMP WITH TIME ZONE
        );

        CREATE TABLE IF NOT EXISTS attachments (
            id VARCHAR(128) PRIMARY KEY,
            message_id VARCHAR(128) NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
            name VARCHAR(512) NOT NULL,
            size INTEGER NOT NULL,
            mime_type VARCHAR(128) NOT NULL,
            url TEXT NOT NULL,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS message_reactions (
            message_id VARCHAR(128) NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
            user_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            reaction_emoji VARCHAR(32) NOT NULL,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (message_id, user_id, reaction_emoji)
        );

        CREATE TABLE IF NOT EXISTS message_reads (
            id BIGSERIAL PRIMARY KEY,
            message_id VARCHAR(128) NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
            user_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            chat_id VARCHAR(128) NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
            status VARCHAR(32) NOT NULL DEFAULT 'delivered',
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT idx_reads_msg_user UNIQUE (message_id, user_id)
        );

        CREATE TABLE IF NOT EXISTS message_pins (
            chat_id VARCHAR(128) NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
            message_id VARCHAR(128) NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
            pinned_by VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            pinned_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (chat_id, message_id)
        );

        CREATE TABLE IF NOT EXISTS message_stars (
            user_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            message_id VARCHAR(128) NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
            starred_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id, message_id)
        );

        CREATE TABLE IF NOT EXISTS system_api_keys (
            id VARCHAR(128) PRIMARY KEY,
            key_value TEXT NOT NULL UNIQUE,
            service_name VARCHAR(64) DEFAULT 'gemini',
            is_active BOOLEAN DEFAULT TRUE,
            usage_count INTEGER DEFAULT 0,
            daily_usage_count INTEGER DEFAULT 0,
            usage_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            last_used TIMESTAMP WITH TIME ZONE,
            added_by VARCHAR(128),
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            total_tokens INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS statuses (
            id VARCHAR(128) PRIMARY KEY,
            user_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            content_type VARCHAR(32) NOT NULL,
            media_url TEXT,
            text_content TEXT,
            duration_hours INTEGER DEFAULT 24,
            expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
            settings JSONB DEFAULT '{}'::jsonb,
            is_archived BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS reports (
            report_id VARCHAR(128) PRIMARY KEY,
            reporter_id VARCHAR(128) REFERENCES users(id) ON DELETE SET NULL,
            target_user_id VARCHAR(128) REFERENCES users(id) ON DELETE CASCADE,
            target_message_id VARCHAR(128),
            category VARCHAR(64) NOT NULL,
            description TEXT,
            status VARCHAR(32) DEFAULT 'Pending',
            target_type VARCHAR(32) DEFAULT 'User',
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS moderation_audit_logs (
            id VARCHAR(128) PRIMARY KEY,
            event_type VARCHAR(64) NOT NULL,
            actor_user_id VARCHAR(128),
            target_user_id VARCHAR(128),
            target_resource TEXT,
            metadata JSONB DEFAULT '{}'::jsonb,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS contacts (
            user_id VARCHAR(128) REFERENCES users(id) ON DELETE CASCADE,
            contact_id VARCHAR(128) REFERENCES users(id) ON DELETE CASCADE,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id, contact_id)
        );

        CREATE TABLE IF NOT EXISTS blocks (
            user_id VARCHAR(128) REFERENCES users(id) ON DELETE CASCADE,
            blocked_id VARCHAR(128) REFERENCES users(id) ON DELETE CASCADE,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id, blocked_id)
        );

        CREATE TABLE IF NOT EXISTS push_subscriptions (
            endpoint TEXT PRIMARY KEY,
            user_id VARCHAR(128) NOT NULL,
            subscription JSONB NOT NULL DEFAULT '{}'::jsonb,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
      `);
      console.log('[Database] PostgreSQL schema verification complete.');
    } catch (e: any) {
      // DATA-01: schema bootstrap failure in production must reach init()'s
      // fail-fast path (throw) instead of being swallowed into memory mode.
      if (process.env.NODE_ENV === 'production') throw e;
      console.warn('[Database] Schema bootstrap warning:', e.message);
    }
  }

  /**
   * Complete Database Reset & User Purge:
   * Permanently wipes all users, sessions, chats, messages, and state from both Postgres and memoryStore.
   * Restores a completely clean database state for fresh user onboarding and unified multi-device sync.
   */
  public async resetAndWipeAllUsersAndData(): Promise<void> {
    console.log('[Database] Executing complete purge and reset of all users, chats, sessions, and messages...');

    // 1. Wipe in-memory structures completely
    memoryStore.users.clear();
    memoryStore.userProfiles.clear();
    memoryStore.userSettings.clear();
    memoryStore.userSessions.clear();
    memoryStore.passwordResetTokens.clear();
    memoryStore.verificationTokens.clear();
    memoryStore.chats.clear();
    memoryStore.chatMembers.clear();
    memoryStore.messages.clear();
    memoryStore.attachments.clear();
    memoryStore.messageReactions.clear();
    memoryStore.messageReads.clear();
    memoryStore.messagePins.clear();
    memoryStore.messageStars.clear();
    memoryStore.contacts.clear();
    memoryStore.blocks.clear();
    memoryStore.reports.clear();
    memoryStore.auditLogs = [];
    memoryStore.moderationLogs = [];
    memoryStore.staffNotes.clear();
    memoryStore.userWarnings.clear();
    memoryStore.statuses.clear();
    memoryStore.statusViews.clear();
    memoryStore.userStorageAccounts.clear();
    memoryStore.statusLikes.clear();
    memoryStore.statusComments.clear();
    memoryStore.pushSubscriptions.clear();
    memoryStore.deletedMessagesVault.clear();
    this.userCache.clear();

    // 2. Wipe PostgreSQL tables if active
    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query(`
          TRUNCATE TABLE 
            message_reads, 
            message_reactions, 
            message_pins, 
            message_stars, 
            attachments, 
            messages, 
            chat_members, 
            chats, 
            user_sessions, 
            user_settings, 
            user_profiles, 
            phone_otps,
            user_storage_accounts,
            contacts, 
            blocks, 
            statuses, 
            reports, 
            moderation_audit_logs, 
            users 
          CASCADE;
        `);
        console.log('[Database] PostgreSQL tables truncated successfully.');
      } catch (err: any) {
        console.warn('[Database] Postgres TRUNCATE warning:', err.message);
      }
    }

    // 3. Re-seed only clean system state
    initMemoryStoreSeed();
    console.log('[Database] Complete wipe executed. Database is clean and ready for fresh registrations.');
  }

  // --- User Operations ---

  public async getUsers(): Promise<User[]> {
    if (isPostgresHealthy && activePgPool) {
      try {
        const res = await activePgPool.query(`
          SELECT u.*, us.settings as user_settings 
          FROM users u 
          LEFT JOIN user_settings us ON u.id = us.user_id 
          WHERE u.is_system_user = FALSE 
          ORDER BY u.display_name ASC
        `);
        return res.rows.map(mapUserRow);
      } catch (e) {
        isPostgresHealthy = false;
      }
    }
    return Array.from(memoryStore.users.values())
      .filter(u => !u.is_system_user)
      .map(mapUserRow);
  }

  public async getUserById(id: string): Promise<User | undefined> {
    const cached = this.userCacheGet(id);
    if (cached) return cached;

    if (isPostgresHealthy && activePgPool) {
      try {
        const res = await activePgPool.query(`
          SELECT u.*, us.settings as user_settings 
          FROM users u 
          LEFT JOIN user_settings us ON u.id = us.user_id 
          WHERE u.id = $1
        `, [id]);
        if (res.rows.length > 0) {
          const u = mapUserRow(res.rows[0]);
          this.userCacheSet(id, u);
          return u;
        }
      } catch (e) {
        isPostgresHealthy = false;
      }
    }

    const row = memoryStore.users.get(id);
    if (!row) return undefined;
    const u = mapUserRow(row);
    this.userCacheSet(id, u);
    return u;
  }

  public async getUserByUsername(username: string): Promise<User | undefined> {
    const cleanUsername = (username || '').toLowerCase().trim();
    if (!cleanUsername) return undefined; // provisional accounts have no username — never match empty
    if (isPostgresHealthy && activePgPool) {
      try {
        const res = await activePgPool.query('SELECT * FROM users WHERE LOWER(username) = LOWER($1)', [cleanUsername]);
        if (res.rows.length > 0) return mapUserRow(res.rows[0]);
      } catch (e) {
        isPostgresHealthy = false;
      }
    }

    for (const u of memoryStore.users.values()) {
      if ((u.username || '').toLowerCase().trim() === cleanUsername) {
        return mapUserRow(u);
      }
    }
    return undefined;
  }

  public async getUserByPhone(phone: string): Promise<User | undefined> {
    const cleanPhone = (phone || '').trim();
    if (isPostgresHealthy && activePgPool) {
      try {
        const res = await activePgPool.query('SELECT * FROM users WHERE phone_number = $1', [cleanPhone]);
        if (res.rows.length > 0) return mapUserRow(res.rows[0]);
      } catch (e) {
        isPostgresHealthy = false;
      }
    }

    for (const u of memoryStore.users.values()) {
      if ((u.phone_number || '').trim() === cleanPhone) {
        return mapUserRow(u);
      }
    }
    return undefined;
  }

  /**
   * Create a full account: unique username claim + password + recovery PIN +
   * device fingerprint — all in one atomic write (phone-free era).
   */
  public async createPasswordUser(input: {
    username: string; displayName: string;
    passwordHash: string; pinHash: string; deviceKeyHash: string;
  }): Promise<User> {
    const cleanUsername = input.username.toLowerCase().trim();
    const now = new Date().toISOString();
    const id = 'user-' + crypto.randomUUID();
    // BATCH-1 (DIR-2026-001): public registration ALWAYS creates a plain user.
    // Operator identity is provisioned only through the audited bootstrap flow.
    const role = 'user';

    const memUser = {
      id,
      phone_number: null,
      username: cleanUsername,
      display_name: input.displayName,
      profile_completed: true,
      avatar_url: `https://api.dicebear.com/9.x/initials/png?seed=${encodeURIComponent(input.displayName)}&backgroundColor=0d9488`,
      banner_url: null,
      background_banner_url: null,
      bio: null,
      verified: false,
      online_status: 'online',
      last_seen: now,
      created_at: now,
      updated_at: now,
      role,
      password_hash: input.passwordHash,
      pin_hash: input.pinHash,
      device_key_hash: input.deviceKeyHash,
      login_attempts: 0,
      locked_until: null,
      reset_token_hash: null,
      reset_token_expires: null,
      user_settings: {
        theme: 'dark',
        language: 'ar',
        privacy: { lastSeen: 'everyone', avatar: 'everyone' },
        notifications: { enabled: true, Sound: true }
      }
    };

    memoryStore.users.set(id, memUser);
    memoryStore.userProfiles.set(id, { user_id: id, bio: '', avatar: memUser.avatar_url, banner: '', updated_at: now });

    if (isPostgresHealthy && activePgPool) {
      // Unique-violation (23505) propagates — the route converts it to an explicit 409.
      try {
        await activePgPool.query(
          `INSERT INTO users (id, phone_number, username, display_name, profile_completed, avatar_url, verified, online_status, last_seen, created_at, updated_at, role, password_hash, pin_hash, device_key_hash, login_attempts)
           VALUES ($1, NULL, $2, $3, TRUE, $4, $5, 'online', NOW(), NOW(), NOW(), $6, $7, $8, $9, 0)`,
          [id, cleanUsername, input.displayName, memUser.avatar_url, false, role,
           input.passwordHash, input.pinHash, input.deviceKeyHash]
        );
      } catch (e) {
        // Roll back the in-memory row so a failed DB insert never leaves a phantom user
        memoryStore.users.delete(id);
        memoryStore.userProfiles.delete(id);
        persistMemoryStore(true);
        throw e;
      }
    }

    const created = mapUserRow(memUser);
    this.userCacheSet(id, created);
    persistMemoryStore(true);
    return created;
  }

  /** Secrets are NEVER cached or included in public user payloads. */
  public async getUserSecrets(userId: string): Promise<{
    passwordHash: string | null; pinHash: string | null; deviceKeyHash: string | null;
    loginAttempts: number; lockedUntil: string | null;
    totpSecret: string | null; totpLastCounter: number; totpBackupHashes: string[];
  } | null> {
    if (isPostgresHealthy && activePgPool) {
      try {
        const res = await activePgPool.query(
          'SELECT password_hash, pin_hash, device_key_hash, login_attempts, locked_until, totp_secret, totp_last_counter, totp_backup_hashes FROM users WHERE id = $1',
          [userId]
        );
        if (res.rows.length > 0) {
          const r = res.rows[0];
          return {
            passwordHash: r.password_hash, pinHash: r.pin_hash, deviceKeyHash: r.device_key_hash,
            loginAttempts: r.login_attempts || 0,
            lockedUntil: r.locked_until ? new Date(r.locked_until).toISOString() : null,
            totpSecret: r.totp_secret || null,
            totpLastCounter: r.totp_last_counter || 0,
            totpBackupHashes: r.totp_backup_hashes ? JSON.parse(r.totp_backup_hashes) : [],
          };
        }
      } catch (e) {
        isPostgresHealthy = false;
      }
    }
    const mem = memoryStore.users.get(userId);
    if (!mem) return null;
    return {
      passwordHash: mem.password_hash || null, pinHash: mem.pin_hash || null,
      deviceKeyHash: mem.device_key_hash || null, loginAttempts: mem.login_attempts || 0,
      lockedUntil: mem.locked_until || null,
      totpSecret: mem.totp_secret || null,
      totpLastCounter: mem.totp_last_counter || 0,
      totpBackupHashes: mem.totp_backup_hashes ? JSON.parse(mem.totp_backup_hashes) : [],
    };
  }

  /**
   * Store/clear the encrypted TOTP secret + last-authorized counter
   * (replay binding). encSecret = null disables 2FA.
   */
  public async setTotpSecret(userId: string, encSecret: string | null, lastCounter: number = 0): Promise<void> {
    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query(
          'UPDATE users SET totp_secret = $1, totp_last_counter = $2, updated_at = NOW() WHERE id = $3',
          [encSecret, lastCounter, userId]
        );
      } catch (e) {
        isPostgresHealthy = false;
      }
    }
    const mem = memoryStore.users.get(userId);
    if (mem) { mem.totp_secret = encSecret; mem.totp_last_counter = lastCounter; }
    this.userCache.delete(userId);
    persistMemoryStore();
  }

  /** Single-use 2FA backup codes — stored hashed (never plaintext). */
  public async setTotpBackupHashes(userId: string, hashes: string[]): Promise<void> {
    const mem = memoryStore.users.get(userId);
    if (mem) { mem.totp_backup_hashes = JSON.stringify(hashes); }
    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query('UPDATE users SET totp_backup_hashes = $1, updated_at = NOW() WHERE id = $2', [JSON.stringify(hashes), userId]);
      } catch (e) {
        isPostgresHealthy = false;
      }
    }
    persistMemoryStore();
  }

  /**
   * Login throttling (OWASP Auth CS): exponential backoff per ACCOUNT —
   * each consecutive failure doubles the forced delay (1s → 2s → … capped
   * at 15 minutes), instead of a flat 10-failures lockout. Slows online
   * brute force to a crawl while never fully locking victims out
   * (anti-DoS-via-lockout).
   */
  public static readonly LOCK_CAP_SECONDS = 900;

  public async recordLoginResult(userId: string, success: boolean): Promise<{ attempts: number; lockedUntil: string | null }> {
    let attempts = 0;
    let lockedUntil: string | null = null;
    if (!success) {
      const secrets = await this.getUserSecrets(userId);
      attempts = (secrets?.loginAttempts || 0) + 1;
      const delaySec = Math.min(2 ** attempts, RelationalDatabase.LOCK_CAP_SECONDS);
      lockedUntil = new Date(Date.now() + delaySec * 1000).toISOString();
    }
    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query(
          'UPDATE users SET login_attempts = $1, locked_until = $2 WHERE id = $3',
          [attempts, lockedUntil ? new Date(lockedUntil) : null, userId]
        );
      } catch (e) {
        isPostgresHealthy = false;
      }
    }
    const mem = memoryStore.users.get(userId);
    if (mem) { mem.login_attempts = attempts; mem.locked_until = lockedUntil; }
    return { attempts, lockedUntil };
  }

  /** Username change (Telegram parity): unique-checked upstream; updates memory + PG + cache. */
  public async setUsername(userId: string, newUsername: string): Promise<void> {
    const u = memoryStore.users.get(userId);
    if (u) {
      // Anti-impersonation: reserve the old username permanently
      if (u.username) {
        if (!memoryStore.reservedUsernames) memoryStore.reservedUsernames = new Set();
        memoryStore.reservedUsernames.add(u.username.toLowerCase());
      }
      u.username = newUsername;
    }
    this.userCache.delete(userId);
    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query('UPDATE users SET username = $1, updated_at = NOW() WHERE id = $2', [newUsername, userId]);
      } catch (e) {
        isPostgresHealthy = false;
      }
    }
    persistMemoryStore();
  }

  public isUsernameReserved(username: string): boolean {
    return (memoryStore.reservedUsernames || new Set()).has(username.toLowerCase());
  }

  /**
   * BATCH-1 (DIR-2026-001): operator handles listed in ADMIN_USERNAMES are
   * RESERVED from public registration/rename (anti-impersonation). They grant
   * NO privilege by themselves — privileged role comes only from the durable
   * DB column via the audited bootstrap flow.
   */
  public isAdminReservedName(username: string): boolean {
    return ADMIN_USERNAMES.has((username || '').toLowerCase().trim());
  }

  /** Call log (Calls tab): per-user entries, newest first, capped at 100. */
  public addCallLogEntry(userId: string, entry: any): void {
    const list = memoryStore.callLogs.get(userId) || [];
    list.unshift({ ...entry, at: new Date().toISOString() });
    memoryStore.callLogs.set(userId, list.slice(0, 100));
    persistMemoryStore();
  }

  public getCallLog(userId: string): any[] {
    return memoryStore.callLogs.get(userId) || [];
  }

  public clearCallLog(userId: string): void {
    memoryStore.callLogs.delete(userId);
    persistMemoryStore();
  }

  /** Finalize both parties' entries when a call ends (status + duration). */
  public finalizeCallLog(callId: string, reason?: string): void {
    for (const [, list] of memoryStore.callLogs.entries()) {
      const entry = list.find(e => e.callId === callId);
      if (!entry) continue;
      const durationSec = Math.round((Date.now() - (entry.at ? new Date(entry.at).getTime() : Date.now())) / 1000);
      entry.status = (reason === 'declined' || reason === 'rejected' || reason === 'busy' || reason === 'missed' || reason === 'missed-offline' || reason === 'no-answer' || durationSec < 3) ? 'missed' : 'completed';
      entry.durationSec = durationSec;
    }
    persistMemoryStore();
  }

  public async setUserPassword(userId: string, passwordHash: string): Promise<void> {
    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query('UPDATE users SET password_hash = $1, login_attempts = 0, locked_until = NULL, updated_at = NOW() WHERE id = $2', [passwordHash, userId]);
      } catch (e) {
        isPostgresHealthy = false;
      }
    }
    const mem = memoryStore.users.get(userId);
    if (mem) { mem.password_hash = passwordHash; mem.login_attempts = 0; mem.locked_until = null; mem.updated_at = new Date().toISOString(); }
    this.userCache.delete(userId);
    persistMemoryStore(true);
  }

  /** One-time recovery reset token (10-min TTL, keyed hash only). */
  public async storeResetToken(userId: string, tokenHash: string, expiresAt: string): Promise<void> {
    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query('UPDATE users SET reset_token_hash = $1, reset_token_expires = $2 WHERE id = $3', [tokenHash, new Date(expiresAt), userId]);
      } catch (e) {
        isPostgresHealthy = false;
      }
    }
    const mem = memoryStore.users.get(userId);
    if (mem) { mem.reset_token_hash = tokenHash; mem.reset_token_expires = expiresAt; }
  }

  public async getResetTokenRecord(userId: string): Promise<{ hash: string | null; expiresAt: string | null } | null> {
    if (isPostgresHealthy && activePgPool) {
      try {
        const res = await activePgPool.query('SELECT reset_token_hash, reset_token_expires FROM users WHERE id = $1', [userId]);
        if (res.rows.length > 0) {
          return {
            hash: res.rows[0].reset_token_hash,
            expiresAt: res.rows[0].reset_token_expires ? new Date(res.rows[0].reset_token_expires).toISOString() : null,
          };
        }
      } catch (e) {
        isPostgresHealthy = false;
      }
    }
    const mem = memoryStore.users.get(userId);
    if (!mem) return null;
    return { hash: mem.reset_token_hash || null, expiresAt: mem.reset_token_expires || null };
  }

  public async clearResetToken(userId: string): Promise<void> {
    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query('UPDATE users SET reset_token_hash = NULL, reset_token_expires = NULL WHERE id = $1', [userId]);
      } catch (e) {
        isPostgresHealthy = false;
      }
    }
    const mem = memoryStore.users.get(userId);
    if (mem) { mem.reset_token_hash = null; mem.reset_token_expires = null; }
  }

  public async setUserPin(userId: string, pinHash: string): Promise<void> {
    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query('UPDATE users SET pin_hash = $1, updated_at = NOW() WHERE id = $2', [pinHash, userId]);
      } catch (e) {
        isPostgresHealthy = false;
      }
    }
    const mem = memoryStore.users.get(userId);
    if (mem) { mem.pin_hash = pinHash; mem.updated_at = new Date().toISOString(); }
    persistMemoryStore(true);
  }

  // BATCH-6 (ADV-01 residue): completeUserProfile REMOVED — it claimed a username
  // with zero reservation/validate checks (dead code that was a loaded bypass
  // of the operator-handle reservation system). Any future first-time profile
  // setup MUST route through the same reservation guards as register/rename.

  public async getUserStorage(userId: string): Promise<{
    provider: string; endpoint: string; region: string; bucket: string;
    publicBaseUrl: string; credentialsEncrypted: string; forcePathStyle: boolean; isActive: boolean;
  } | null> {
    if (isPostgresHealthy && activePgPool) {
      try {
        const res = await activePgPool.query('SELECT * FROM user_storage_accounts WHERE user_id = $1', [userId]);
        if (res.rows.length > 0) {
          const r = res.rows[0];
          return {
            provider: r.provider, endpoint: r.endpoint, region: r.region, bucket: r.bucket,
            publicBaseUrl: r.public_base_url, credentialsEncrypted: r.credentials_encrypted,
            forcePathStyle: r.force_path_style === true, isActive: r.is_active !== false,
          };
        }
        return null;
      } catch (e) {
        isPostgresHealthy = false;
      }
    }
    const r = memoryStore.userStorageAccounts.get(userId);
    if (!r) return null;
    return {
      provider: r.provider, endpoint: r.endpoint, region: r.region, bucket: r.bucket,
      publicBaseUrl: r.public_base_url, credentialsEncrypted: r.credentials_encrypted,
      forcePathStyle: r.force_path_style === true, isActive: r.is_active !== false,
    };
  }

  public async upsertUserStorage(userId: string, cfg: {
    provider: string; endpoint: string; region: string; bucket: string;
    publicBaseUrl: string; credentialsEncrypted: string; forcePathStyle: boolean;
  }): Promise<void> {
    const now = new Date().toISOString();
    const existing = memoryStore.userStorageAccounts.get(userId);
    memoryStore.userStorageAccounts.set(userId, {
      user_id: userId,
      provider: cfg.provider,
      endpoint: cfg.endpoint,
      region: cfg.region,
      bucket: cfg.bucket,
      public_base_url: cfg.publicBaseUrl,
      credentials_encrypted: cfg.credentialsEncrypted,
      force_path_style: cfg.forcePathStyle,
      is_active: true,
      created_at: existing?.created_at || now,
      updated_at: now,
    });
    persistMemoryStore();

    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query(
          `INSERT INTO user_storage_accounts (user_id, provider, endpoint, region, bucket, public_base_url, credentials_encrypted, force_path_style, is_active, created_at, updated_at)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, TRUE, NOW(), NOW())
           ON CONFLICT (user_id) DO UPDATE SET
             provider = $2, endpoint = $3, region = $4, bucket = $5, public_base_url = $6,
             credentials_encrypted = $7, force_path_style = $8, is_active = TRUE, updated_at = NOW()`,
          [userId, cfg.provider, cfg.endpoint, cfg.region, cfg.bucket, cfg.publicBaseUrl, cfg.credentialsEncrypted, cfg.forcePathStyle]
        );
      } catch (e) {
        isPostgresHealthy = false;
      }
    }
  }

  public async deleteUserStorage(userId: string): Promise<void> {
    memoryStore.userStorageAccounts.delete(userId);
    persistMemoryStore();
    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query('DELETE FROM user_storage_accounts WHERE user_id = $1', [userId]);
      } catch (e) {
        isPostgresHealthy = false;
      }
    }
  }
  public async updateUser(userId: string, patches: Partial<User>): Promise<User | undefined> {
    const current = memoryStore.users.get(userId);
    if (current) {
      if (patches.username !== undefined) current.username = (patches.username || '').toLowerCase().trim();
      if (patches.displayName !== undefined) current.display_name = patches.displayName;
      if (patches.email !== undefined) { /* legacy field — intentionally ignored in phone-auth era */ }
      if (patches.phoneNumber !== undefined) current.phone_number = (patches.phoneNumber || '').trim();
      if (patches.profileCompleted !== undefined) current.profile_completed = patches.profileCompleted;
      if (patches.avatarUrl !== undefined) current.avatar_url = patches.avatarUrl;
      if (patches.bannerUrl !== undefined) current.banner_url = patches.bannerUrl;
      if (patches.backgroundBannerUrl !== undefined) current.background_banner_url = patches.backgroundBannerUrl;
      if (patches.bio !== undefined) current.bio = patches.bio;
      if (patches.onlineStatus !== undefined) current.online_status = patches.onlineStatus;
      if (patches.lastSeen !== undefined) current.last_seen = patches.lastSeen;
      if (patches.role !== undefined) current.role = patches.role;
      if (patches.verified !== undefined) current.verified = patches.verified;
      if (patches.bannerShadowOpacity !== undefined) current.banner_shadow_opacity = patches.bannerShadowOpacity;
      if (patches.bgBannerShadowOpacity !== undefined) current.bg_banner_shadow_opacity = patches.bgBannerShadowOpacity;
      if (patches.isBanned !== undefined) current.is_banned = patches.isBanned;
      if (patches.bannedAt !== undefined) current.banned_at = patches.bannedAt;
      if (patches.bannedUntil !== undefined) current.banned_until = patches.bannedUntil;
      if (patches.bannedBy !== undefined) current.banned_by = patches.bannedBy;
      if (patches.banReason !== undefined) current.ban_reason = patches.banReason;
      if (patches.mutedUntil !== undefined) current.muted_until = patches.mutedUntil;
      if (patches.mutedAt !== undefined) current.muted_at = patches.mutedAt;
      if (patches.mutedBy !== undefined) current.muted_by = patches.mutedBy;
      if (patches.muteReason !== undefined) current.mute_reason = patches.muteReason;
      if (patches.mutedFromAiUntil !== undefined) current.muted_from_ai_until = patches.mutedFromAiUntil;
      current.updated_at = new Date().toISOString();

      const currentProfile = memoryStore.userProfiles.get(userId) || { user_id: userId };
      if (patches.bio !== undefined) currentProfile.bio = patches.bio;
      if (patches.avatarUrl !== undefined) currentProfile.avatar = patches.avatarUrl;
      if (patches.bannerUrl !== undefined) currentProfile.banner = patches.bannerUrl;
      currentProfile.updated_at = new Date().toISOString();
      memoryStore.userProfiles.set(userId, currentProfile);

      persistMemoryStore(true);
    }

    if (isPostgresHealthy && activePgPool) {
      try {
        const allowedKeys = [
          'username', 'displayName', 'avatarUrl', 'bannerUrl', 'backgroundBannerUrl',
          'bio', 'onlineStatus', 'lastSeen', 'updatedAt', 'bannerShadowOpacity',
          'bgBannerShadowOpacity', 'role', 'verified', 'isBanned', 'bannedAt', 'bannedUntil',
          'bannedBy', 'banReason', 'mutedUntil', 'mutedAt', 'mutedBy', 'muteReason', 'mutedFromAiUntil'
        ];
        const updateFields: string[] = [];
        const values: any[] = [];
        let idx = 1;

        for (const key of allowedKeys) {
          if (patches[key as keyof User] !== undefined) {
            const dbCol = key === 'displayName' ? 'display_name' :
                          key === 'avatarUrl' ? 'avatar_url' :
                          key === 'bannerUrl' ? 'banner_url' :
                          key === 'backgroundBannerUrl' ? 'background_banner_url' :
                          key === 'bannerShadowOpacity' ? 'banner_shadow_opacity' :
                          key === 'bgBannerShadowOpacity' ? 'bg_banner_shadow_opacity' :
                          key === 'onlineStatus' ? 'online_status' :
                          key === 'lastSeen' ? 'last_seen' :
                          key === 'isBanned' ? 'is_banned' :
                          key === 'bannedAt' ? 'banned_at' :
                          key === 'bannedUntil' ? 'banned_until' :
                          key === 'bannedBy' ? 'banned_by' :
                          key === 'banReason' ? 'ban_reason' :
                          key === 'mutedUntil' ? 'muted_until' :
                          key === 'mutedAt' ? 'muted_at' :
                          key === 'mutedBy' ? 'muted_by' :
                          key === 'muteReason' ? 'mute_reason' :
                          key === 'mutedFromAiUntil' ? 'muted_from_ai_until' :
                          key === 'updatedAt' ? 'updated_at' : key;
            updateFields.push(`${dbCol} = $${idx}`);
            let val: any = patches[key as keyof User];
            if (key === 'lastSeen' || key === 'updatedAt' || key === 'bannedAt' || key === 'bannedUntil' || key === 'mutedAt' || key === 'mutedUntil' || key === 'mutedFromAiUntil') {
              val = val ? new Date(val as string) : null;
            }
            values.push(val);
            idx++;
          }
        }

        if (updateFields.length > 0) {
          values.push(userId);
          await activePgPool.query(`UPDATE users SET ${updateFields.join(', ')} WHERE id = $${idx}`, values);
        }
      } catch (e) {
        isPostgresHealthy = false;
      }
    }

    this.userCache.delete(userId);
    return this.getUserById(userId);
  }

  // --- Session Management ---

  /**
   * AUTH-01: `familyId` (optional) stamps the token family this session
   * belongs to (migration v13 user_sessions.family_id). Callers that mint a
   * rotated session for an existing family pass the ORIGINAL session's
   * family_id; fresh logins may omit it — the session roots its own family
   * (family_id = session.id). Also honored from session.familyId when the
   * caller embeds it on the session object.
   */
  public async createSession(session: UserSession, familyId?: string): Promise<UserSession> {
    const tokenHash = hashToken(session.refreshToken);
    const family = familyId || (session as any).familyId || session.id;
    const stored = {
      id: session.id,
      user_id: session.userId,
      refresh_token_hash: tokenHash,
      // SECURITY: the raw refresh token is never persisted in the local snapshot (hash only)
      user_agent: session.userAgent,
      ip_address: session.ipAddress,
      is_revoked: session.isRevoked || false,
      expires_at: session.expiresAt,
      created_at: session.createdAt,
      family_id: family
    };

    memoryStore.userSessions.set(session.id, stored);
    persistMemoryStore();

    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query(
          `INSERT INTO user_sessions (id, user_id, refresh_token_hash, user_agent, ip_address, is_revoked, expires_at, created_at, family_id, updated_at)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW())`,
          [
            session.id,
            session.userId,
            tokenHash,
            session.userAgent,
            session.ipAddress,
            session.isRevoked,
            new Date(session.expiresAt),
            new Date(session.createdAt),
            family
          ]
        );
      } catch (e) {
        isPostgresHealthy = false;
      }
    }

    return session;
  }

  public async getSessionByRefreshToken(token: string): Promise<UserSession | undefined> {
    const tokenHash = hashToken(token);

    if (isPostgresHealthy && activePgPool) {
      try {
        const res = await activePgPool.query(
          'SELECT * FROM user_sessions WHERE refresh_token_hash = $1 AND is_revoked = FALSE',
          [tokenHash]
        );
        if (res.rows.length > 0) {
          const s = mapSessionRow(res.rows[0]);
          s.refreshToken = token;
          return s;
        }
      } catch (e) {
        isPostgresHealthy = false;
      }
    }

    for (const s of memoryStore.userSessions.values()) {
      if (s.refresh_token_hash === tokenHash && !s.is_revoked) {
        const session = mapSessionRow(s);
        session.refreshToken = token;
        return session;
      }
    }
    return undefined;
  }

  public async updateSessionRefreshToken(sessionId: string, newRefreshToken: string, expiresAt: string): Promise<void> {
    const tokenHash = hashToken(newRefreshToken);
    const s = memoryStore.userSessions.get(sessionId);
    if (s) {
      s.refresh_token_hash = tokenHash;
      s.expires_at = expiresAt;
      persistMemoryStore();
    }

    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query(
          `UPDATE user_sessions SET refresh_token_hash = $1, expires_at = $2, updated_at = NOW() WHERE id = $3`,
          [tokenHash, new Date(expiresAt), sessionId]
        );
      } catch (e) {
        isPostgresHealthy = false;
      }
    }
  }

  /* =========================================================================
     AUTH-01 (external audit): atomic refresh-token rotation (compare-and-swap)
     -------------------------------------------------------------------------
     The legacy updateSessionRefreshToken above updates by session id only —
     two concurrent refreshes both win and reuse detection never fires (the
     old-hash lookup excluded rotated rows). The CAS methods below give the
     auth layer:
       - rotateRefreshTokenCas(): UPDATE ... WHERE id=? AND refresh_token_hash=?
         AND is_revoked=FALSE — exactly one concurrent caller gets 'rotated';
         the loser gets 'stale' (or 'not-found'). Same semantics mirrored on
         the in-memory store for memory-mode operation.
       - markRefreshTokenSpent()/isRefreshTokenSpent(): consumed-token record
         (HASH ONLY) in spent_refresh_tokens (migration v13) + memory mirror.
       - revokeSessionFamily(): revoke every session of the token family.
     Callers hash tokens with sha256-hex (hashToken in this module) BEFORE
     calling — these methods accept hashes, never raw tokens.
     ========================================================================= */

  private logMemoryOnlyAuthWrite(op: string, sessionId: string, err: any): void {
    // DATA-01 gate: a durable AUTH write that landed ONLY in the in-memory
    // mirror while DATABASE_URL is configured is never silent — the boot path
    // already fails fast in production; mid-flight failures log CRITICAL and
    // the snapshot/probe path provides recovery.
    if (primaryConnectionString) {
      console.error(`[Database] CRITICAL (AUTH/DATA-01): ${op} for session ${sessionId} landed in MEMORY ONLY because the PG write failed${err ? ': ' + (err.code || err.message) : ''}`);
    }
  }

  public async rotateRefreshTokenCas(sessionId: string, currentHash: string, newHash: string, newExpiresAt: string): Promise<'rotated' | 'stale' | 'not-found'> {
    if (isPostgresHealthy && activePgPool) {
      try {
        // Atomic compare-and-swap: wins exactly once per (id, currentHash).
        const res = await activePgPool.query(
          `UPDATE user_sessions
              SET refresh_token_hash = $1, expires_at = $2, updated_at = NOW()
            WHERE id = $3 AND refresh_token_hash = $4 AND is_revoked = FALSE
            RETURNING id`,
          [newHash, new Date(newExpiresAt), sessionId, currentHash]
        );
        if (res.rowCount && res.rowCount > 0) {
          // Mirror the winning rotation into the memory mirror (sessions are
          // always written to memoryStore first by createSession, so the row
          // usually exists; PG-durable restarts may leave it empty).
          const s = memoryStore.userSessions.get(sessionId);
          if (s) {
            s.refresh_token_hash = newHash;
            s.expires_at = newExpiresAt;
            persistMemoryStore();
          }
          return 'rotated';
        }
        // No row matched — distinguish stale (exists, wrong hash / revoked)
        // from not-found (session gone).
        const cur = await activePgPool.query(
          'SELECT 1 FROM user_sessions WHERE id = $1',
          [sessionId]
        );
        return cur.rows.length > 0 ? 'stale' : 'not-found';
      } catch (err: any) {
        if (isPgConnectionClassError(err)) isPostgresHealthy = false;
        this.logMemoryOnlyAuthWrite('rotateRefreshTokenCas', sessionId, err);
        // fall through to the memory mirror below (connection-class errors
        // also flip the engine to memory mode for subsequent calls).
      }
    }

    // Memory-mode mirror — same CAS semantics. Single-threaded JS: the
    // check + write below is atomic (no await between read and write).
    const s = memoryStore.userSessions.get(sessionId);
    if (!s) return 'not-found';
    if (s.is_revoked || s.refresh_token_hash !== currentHash) return 'stale';
    s.refresh_token_hash = newHash;
    s.expires_at = newExpiresAt;
    persistMemoryStore();
    return 'rotated';
  }

  /** Records the CONSUMED refresh-token hash (hash only — raw tokens never persisted). */
  public async markRefreshTokenSpent(sessionId: string, spentHash: string): Promise<void> {
    let spent = memoryStore.spentRefreshTokens.get(sessionId);
    if (!spent) {
      spent = new Set<string>();
      memoryStore.spentRefreshTokens.set(sessionId, spent);
    }
    spent.add(spentHash);
    persistMemoryStore();

    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query(
          'INSERT INTO spent_refresh_tokens (session_id, token_hash) VALUES ($1, $2)',
          [sessionId, spentHash]
        );
      } catch (err: any) {
        if (isPgConnectionClassError(err)) isPostgresHealthy = false;
        this.logMemoryOnlyAuthWrite('markRefreshTokenSpent', sessionId, err);
      }
    }
  }

  /**
   * Reuse detection: has this exact token hash already been consumed for the
   * session? Checks the memory mirror first (it accumulates every spend this
   * process recorded, including outage-window spends), then PG (holds spends
   * from previous processes / PG-mode restarts).
   */
  public async isRefreshTokenSpent(sessionId: string, tokenHash: string): Promise<boolean> {
    if (memoryStore.spentRefreshTokens.get(sessionId)?.has(tokenHash)) return true;

    if (isPostgresHealthy && activePgPool) {
      try {
        const res = await activePgPool.query(
          'SELECT 1 FROM spent_refresh_tokens WHERE session_id = $1 AND token_hash = $2 LIMIT 1',
          [sessionId, tokenHash]
        );
        return res.rows.length > 0;
      } catch (err: any) {
        if (isPgConnectionClassError(err)) isPostgresHealthy = false;
        else console.warn('[Database] isRefreshTokenSpent PG check failed:', err.message);
      }
    }
    return false;
  }

  /**
   * BATCH-4 (DIR-CB-02): locate the session that SPENT a given refresh-token
   * hash — the DURABLE reuse detector. rejectReusedToken consults this when
   * the process-local history misses (after restart / other instance), so a
   * replayed spent token still trips family revocation + audit.
   */
  public async findSessionBySpentToken(tokenHash: string): Promise<{ sessionId: string; userId: string } | null> {
    for (const [sessionId, hashes] of memoryStore.spentRefreshTokens.entries()) {
      if (hashes.has(tokenHash)) {
        const sess = memoryStore.userSessions.get(sessionId);
        return { sessionId, userId: (sess as any)?.user_id || '' };
      }
    }
    if (isPostgresHealthy && activePgPool) {
      try {
        const res = await activePgPool.query(
          `SELECT sp.session_id, us.user_id
           FROM spent_refresh_tokens sp
           LEFT JOIN user_sessions us ON us.id = sp.session_id
           WHERE sp.token_hash = $1
           LIMIT 1`,
          [tokenHash]
        );
        if (res.rows.length > 0) {
          return { sessionId: res.rows[0].session_id, userId: res.rows[0].user_id || '' };
        }
      } catch (err: any) {
        if (isPgConnectionClassError(err)) isPostgresHealthy = false;
        else console.warn('[Database] findSessionBySpentToken failed:', err.message);
      }
    }
    return null;
  }

  /**
   * AUTH-01: revoke ALL sessions of the token family the given session
   * belongs to (family_id, migration v13). Fallback for rows with a NULL
   * family_id (pre-migration leftovers): revoke the owning user's sessions —
   * conservative, matching the remediation brief's fallback semantics.
   */
  public async revokeSessionFamily(sessionId: string): Promise<void> {
    const target = memoryStore.userSessions.get(sessionId);
    const familyId = (target as any)?.family_id as string | undefined;
    const userId = target?.user_id;

    for (const s of memoryStore.userSessions.values()) {
      if (s.id === sessionId) { s.is_revoked = true; continue; }
      if (familyId && s.family_id === familyId) s.is_revoked = true;
      else if (!familyId && userId && s.user_id === userId) s.is_revoked = true;
    }
    persistMemoryStore();

    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query(
          `UPDATE user_sessions SET is_revoked = TRUE, updated_at = NOW()
            WHERE id = $1
               OR family_id = (SELECT family_id FROM user_sessions WHERE id = $1 AND family_id IS NOT NULL)
               OR (family_id IS NULL AND user_id = (SELECT user_id FROM user_sessions WHERE id = $1))`,
          [sessionId]
        );
      } catch (err: any) {
        if (isPgConnectionClassError(err)) isPostgresHealthy = false;
        this.logMemoryOnlyAuthWrite('revokeSessionFamily', sessionId, err);
      }
    }
  }

  public async revokeSession(sessionId: string): Promise<void> {
    const s = memoryStore.userSessions.get(sessionId);
    if (s) {
      s.is_revoked = true;
      persistMemoryStore();
    }

    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query('UPDATE user_sessions SET is_revoked = TRUE, updated_at = NOW() WHERE id = $1', [sessionId]);
      } catch (e) {
        isPostgresHealthy = false;
      }
    }
  }

  public async revokeAllUserSessions(userId: string): Promise<void> {
    for (const s of memoryStore.userSessions.values()) {
      if (s.user_id === userId) s.is_revoked = true;
    }
    persistMemoryStore();
    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query('UPDATE user_sessions SET is_revoked = TRUE, updated_at = NOW() WHERE user_id = $1', [userId]);
      } catch (e) {
        isPostgresHealthy = false;
      }
    }
  }

  public async revokeOtherUserSessions(userId: string, currentSessionId: string): Promise<void> {
    for (const s of memoryStore.userSessions.values()) {
      if (s.user_id === userId && s.id !== currentSessionId) s.is_revoked = true;
    }
    persistMemoryStore();
    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query('UPDATE user_sessions SET is_revoked = TRUE, updated_at = NOW() WHERE user_id = $1 AND id != $2', [userId, currentSessionId]);
      } catch (e) {
        isPostgresHealthy = false;
      }
    }
  }

  public async getUserSessions(userId: string): Promise<UserSession[]> {
    if (isPostgresHealthy && activePgPool) {
      try {
        const res = await activePgPool.query(
          'SELECT * FROM user_sessions WHERE user_id = $1 AND is_revoked = FALSE ORDER BY created_at DESC',
          [userId]
        );
        return res.rows.map(mapSessionRow);
      } catch (e) {
        isPostgresHealthy = false;
      }
    }

    return Array.from(memoryStore.userSessions.values())
      .filter(s => s.user_id === userId && !s.is_revoked)
      .map(mapSessionRow);
  }

  /**
   * Security-alerts engine: stamp session metadata (ip + truncated user agent)
   * onto the active session row and bump last_active. Mirrors the standard
   * PG-branch / memoryStore-parity pattern; never throws.
   */
  public async updateSessionMeta(sessionId: string, ip: string, userAgent: string): Promise<void> {
    // ip_address column is VARCHAR(45) — hard-cap so chained XFF headers can
    // never trip a PG length error; UA is capped at 200 by the caller contract.
    const tIp = String(ip || '').slice(0, 45);
    const tUa = String(userAgent || 'unknown').slice(0, 200);
    const s = memoryStore.userSessions.get(sessionId);
    if (s) {
      s.ip_address = tIp;
      s.user_agent = tUa;
      s.last_active = new Date().toISOString();
      persistMemoryStore();
    }
    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query(
          `UPDATE user_sessions SET ip_address = $1, user_agent = $2, last_active = NOW(), updated_at = NOW() WHERE id = $3`,
          [tIp, tUa, sessionId]
        );
      } catch (e) {
        isPostgresHealthy = false;
      }
    }
  }

  // --- Password Reset & Verification ---

  public async createPasswordResetToken(userId: string): Promise<string> {
    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 3600000).toISOString();
    memoryStore.passwordResetTokens.set(token, { token, userId, expiresAt });
    persistMemoryStore();
    return token;
  }

  public async verifyAndConsumeResetToken(token: string): Promise<string | null> {
    const item = memoryStore.passwordResetTokens.get(token);
    if (!item) return null;
    memoryStore.passwordResetTokens.delete(token);
    persistMemoryStore();
    if (new Date(item.expiresAt).getTime() < Date.now()) return null;
    return item.userId;
  }

  public async createEmailVerificationToken(email: string): Promise<string> {
    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 24 * 3600000).toISOString();
    memoryStore.verificationTokens.set(token, { token, email, expiresAt });
    persistMemoryStore();
    return token;
  }

  public async verifyAndConsumeEmailToken(token: string): Promise<string | null> {
    const item = memoryStore.verificationTokens.get(token);
    if (!item) return null;
    memoryStore.verificationTokens.delete(token);
    persistMemoryStore();
    if (new Date(item.expiresAt).getTime() < Date.now()) return null;
    return item.email;
  }

  // --- Settings & Contacts ---

  public async getUserSettings(userId: string): Promise<any> {
    const u = memoryStore.users.get(userId);
    if (u && u.user_settings) return u.user_settings;
    return {
      theme: 'dark',
      language: 'ar',
      privacy: { lastSeen: 'everyone', avatar: 'everyone' },
      notifications: { enabled: true, Sound: true }
    };
  }

  public async updateUserSettings(userId: string, settings: any): Promise<any> {
    const current = await this.getUserSettings(userId);
    // Deep-merge: a shallow spread wiped sibling keys (privacySettings replacing
    // the whole object killed every other privacy toggle).
    const deepMerge = (a: any, b: any): any => {
      const out: any = { ...(a || {}) };
      for (const k of Object.keys(b || {})) {
        const bv = b[k];
        out[k] = (bv && typeof bv === 'object' && !Array.isArray(bv) && out[k] && typeof out[k] === 'object' && !Array.isArray(out[k]))
          ? deepMerge(out[k], bv)
          : bv;
      }
      return out;
    };
    const updated = deepMerge(current, settings);
    const u = memoryStore.users.get(userId);
    if (u) {
      u.user_settings = updated;
      persistMemoryStore();
    }
    // PG dual-write: the schema JOIN reads settings live — without this upsert
    // the settings table stays empty and PG-connected boots lose privacy state.
    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query(
          `INSERT INTO user_settings (user_id, settings) VALUES ($1, $2::jsonb)
           ON CONFLICT (user_id) DO UPDATE SET settings = $2::jsonb, updated_at = NOW()`,
          [userId, JSON.stringify(updated)]
        );
      } catch (e) {
        isPostgresHealthy = false;
      }
    }
    // Cache invalidation: without this, getUserById serves stale privacy state.
    this.userCache.delete(userId);
    return updated;
  }

  public async getUsersWithDisabledReadReceipts(): Promise<Set<string>> {
    const rows = await pgQuery(
      `SELECT user_id FROM user_settings
       WHERE settings->'privacySettings'->>'readReceiptsEnabled' = 'false'
          OR settings->'privacy'->>'readReceiptsEnabled' = 'false'`
    );
    if (rows) {
      return new Set(rows.map(r => r.user_id));
    }
    const disabled = new Set<string>();
    for (const [userId, u] of memoryStore.users.entries()) {
      const s = u.user_settings || {};
      if (s.privacySettings?.readReceiptsEnabled === false || s.privacy?.readReceiptsEnabled === false) {
        disabled.add(userId);
      }
    }
    return disabled;
  }

  public async getContacts(userId: string): Promise<string[]> {
    const rows = await pgQuery('SELECT contact_id FROM contacts WHERE user_id = $1', [userId]);
    if (rows) return rows.map(r => r.contact_id);
    const c = memoryStore.contacts.get(userId);
    return c ? Array.from(c) : [];
  }

  public async addContact(userId: string, contactId: string): Promise<boolean> {
    if (userId === contactId) return false;
    if (!memoryStore.contacts.has(userId)) memoryStore.contacts.set(userId, new Set());
    if (!memoryStore.contacts.has(contactId)) memoryStore.contacts.set(contactId, new Set());
    memoryStore.contacts.get(userId)!.add(contactId);
    memoryStore.contacts.get(contactId)!.add(userId);
    await pgQuery(
      'INSERT INTO contacts (user_id, contact_id) VALUES ($1, $2), ($2, $1) ON CONFLICT DO NOTHING',
      [userId, contactId]
    );
    persistMemoryStore();
    return true;
  }

  public async removeContact(userId: string, contactId: string): Promise<boolean> {
    memoryStore.contacts.get(userId)?.delete(contactId);
    memoryStore.contacts.get(contactId)?.delete(userId);
    await pgQuery(
      'DELETE FROM contacts WHERE (user_id = $1 AND contact_id = $2) OR (user_id = $2 AND contact_id = $1)',
      [userId, contactId]
    );
    persistMemoryStore();
    return true;
  }

  public async blockUser(userId: string, blockTargetId: string): Promise<boolean> {
    if (userId === blockTargetId) return false;
    if (!memoryStore.blocks.has(userId)) memoryStore.blocks.set(userId, new Set());
    memoryStore.blocks.get(userId)!.add(blockTargetId);
    await pgQuery(
      'INSERT INTO blocks (user_id, blocked_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
      [userId, blockTargetId]
    );
    await this.removeContact(userId, blockTargetId);
    persistMemoryStore();
    return true;
  }

  public async unblockUser(userId: string, blockedUserId: string): Promise<boolean> {
    memoryStore.blocks.get(userId)?.delete(blockedUserId);
    await pgQuery('DELETE FROM blocks WHERE user_id = $1 AND blocked_id = $2', [userId, blockedUserId]);
    persistMemoryStore();
    return true;
  }

  public async getBlockedUsers(userId: string): Promise<string[]> {
    const rows = await pgQuery('SELECT blocked_id FROM blocks WHERE user_id = $1', [userId]);
    if (rows) return rows.map(r => r.blocked_id);
    const b = memoryStore.blocks.get(userId);
    return b ? Array.from(b) : [];
  }

  public async getUsersWhoBlockedMe(userId: string): Promise<string[]> {
    const rows = await pgQuery('SELECT user_id FROM blocks WHERE blocked_id = $1', [userId]);
    if (rows) return rows.map(r => r.user_id);
    const result: string[] = [];
    for (const [uId, set] of memoryStore.blocks.entries()) {
      if (set.has(userId)) result.push(uId);
    }
    return result;
  }

  public async isBlocked(user1: string, user2: string): Promise<boolean> {
    const rows = await pgQuery(
      'SELECT 1 FROM blocks WHERE (user_id = $1 AND blocked_id = $2) OR (user_id = $2 AND blocked_id = $1) LIMIT 1',
      [user1, user2]
    );
    if (rows) return rows.length > 0;
    return (memoryStore.blocks.get(user1)?.has(user2) || memoryStore.blocks.get(user2)?.has(user1)) ?? false;
  }

  // --- Chats & Messages ---

  public async getChatsForUser(userId: string): Promise<Chat[]> {
    const rows = await pgQuery(
      `SELECT c.* FROM chats c JOIN chat_members cm ON cm.chat_id = c.id
       WHERE cm.user_id = $1 ORDER BY c.updated_at DESC`,
      [userId]
    );
    if (rows) {
      // BATCH-3 (DIR-CB-04): the chats list carries membership_version so ALL
      // client send variants (schedule/forward/reply) can declare the epoch
      // they composed under without extra round-trips.
      return rows.map(c => ({
        id: c.id,
        type: c.type,
        name: c.name,
        avatarUrl: c.avatar_url || undefined,
        membershipVersion: Number(c.membership_version) || 1,
        createdAt: c.created_at ? new Date(c.created_at).toISOString() : new Date().toISOString(),
        updatedAt: c.updated_at ? new Date(c.updated_at).toISOString() : new Date().toISOString()
      }));
    }
    const list: Chat[] = [];
    for (const [chatId, c] of memoryStore.chats.entries()) {
      const members = memoryStore.chatMembers.get(chatId);
      if (members && members.has(userId)) {
        list.push({
          id: c.id,
          type: c.type,
          name: c.name,
          avatarUrl: c.avatar_url || undefined,
          membershipVersion: Number((c as any).membership_version) || 1,
          createdAt: c.created_at,
          updatedAt: c.updated_at
        });
      }
    }
    return list.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }

  public async getChatMembers(chatId: string): Promise<ChatMember[]> {
    const rows = await pgQuery('SELECT user_id, joined_at FROM chat_members WHERE chat_id = $1', [chatId]);
    if (rows) {
      return rows.map(r => ({
        chatId,
        userId: r.user_id,
        joinedAt: r.joined_at ? new Date(r.joined_at).toISOString() : new Date().toISOString()
      }));
    }
    const set = memoryStore.chatMembers.get(chatId);
    if (!set) return [];
    return Array.from(set).map(uId => ({
      chatId,
      userId: uId,
      joinedAt: new Date().toISOString()
    }));
  }

  // ── Channels (Telegram parity) ───────────────────────────────────────────
  // Channels are chats.type='channel' in the SAME chats/chat_members tables —
  // zero new tables. Subscribers are ordinary chat_members rows (role 'member');
  // owner/admins are the only posters (enforced in sendGate).

  /** Cheap in-memory type lookup for hot paths (WS typing gate, REST guards). */
  public getChatType(chatId: string): 'one-to-one' | 'group' | 'channel' | null {
    return (memoryStore.chats.get(chatId) as any)?.type ?? null;
  }

  /** Subscriber count for a channel (owner + admins + members). Falls back to in-memory on PG failure. */
  public async getChannelSubscriberCount(chatId: string): Promise<number> {
    const rows = await pgQuery('SELECT COUNT(*)::int AS count FROM chat_members WHERE chat_id = $1', [chatId]);
    if (rows) return Number(rows[0]?.count) || 0;
    return memoryStore.chatMembers.get(chatId)?.size || 0;
  }

  public async getChatUsers(chatId: string): Promise<User[]> {
    const members = await this.getChatMembers(chatId);
    const users: User[] = [];
    for (const m of members) {
      const u = await this.getUserById(m.userId);
      if (u) users.push(u);
    }
    return users;
  }

  public async getUnreadCount(chatId: string, userId: string): Promise<number> {
    const rows = await pgQuery(
      `SELECT COUNT(*)::int AS count FROM messages m
       LEFT JOIN message_reads mr ON mr.message_id = m.id AND mr.user_id = $2
       WHERE m.chat_id = $1 AND m.sender_id <> $2 AND m.deleted_at IS NULL
         AND (m.broadcast_at IS NOT NULL OR m.scheduled_at IS NULL)
         AND (mr.id IS NULL OR mr.status <> 'read')`,
      [chatId, userId]
    );
    if (rows) return Number(rows[0]?.count) || 0;
    let unread = 0;
    for (const msg of memoryStore.messages.values()) {
      if (msg.chat_id === chatId && msg.sender_id !== userId && !msg.deleted_at) {
        if (msg.scheduled_at && !msg.broadcast_at) continue; // undelivered scheduled message — not counted as unread
        const reads = memoryStore.messageReads.get(msg.id);
        const userRead = reads?.get(userId);
        if (!userRead || userRead.status !== 'read') {
          unread++;
        }
      }
    }
    return unread;
  }

  public async getUsersActiveChatsCount(): Promise<Record<string, number>> {
    const rows = await pgQuery('SELECT user_id, COUNT(DISTINCT chat_id)::int AS count FROM chat_members GROUP BY user_id');
    if (rows) {
      const counts: Record<string, number> = {};
      for (const r of rows) counts[r.user_id] = Number(r.count) || 0;
      return counts;
    }
    const counts: Record<string, number> = {};
    for (const [chatId, members] of memoryStore.chatMembers.entries()) {
      for (const uId of members) {
        counts[uId] = (counts[uId] || 0) + 1;
      }
    }
    return counts;
  }

  public async createChat(type: 'one-to-one' | 'group' | 'channel', name: string | null, members: string[], customId?: string): Promise<Chat> {
    const chatId = customId || ('chat-' + crypto.randomUUID());
    const now = new Date().toISOString();
    const chat = {
      id: chatId,
      type,
      name,
      avatar_url: null,
      created_at: now,
      updated_at: now,
      membership_version: 1
    };

    memoryStore.chats.set(chatId, chat);
    memoryStore.chatMembers.set(chatId, new Set(members));
    // Group/Channel roles: creator = owner, everyone else = member (WhatsApp/TG parity)
    if (type === 'group' || type === 'channel') {
      const roles = new Map<string, 'owner' | 'admin' | 'member'>();
      members.forEach(id => roles.set(id, 'member'));
      if (members[0]) roles.set(members[0], 'owner');
      memoryStore.chatRoles.set(chatId, roles);
    }

    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query(
          `INSERT INTO chats (id, type, name, avatar_url, created_at, updated_at, group_settings)
           VALUES ($1, $2, $3, $4, $5, $6, '{}'::jsonb) ON CONFLICT (id) DO NOTHING`,
          [chatId, type, name, null, now, now]
        );
        const memberParams: any[] = [];
        const tuples = members.map((uid, i) => {
          const base = i * 3;
          memberParams.push(chatId, uid, ((type === 'group' || type === 'channel') && i === 0) ? 'owner' : 'member');
          return `($${base + 1}, $${base + 2}, $${base + 3})`;
        });
        if (tuples.length > 0) {
          await activePgPool.query(
            `INSERT INTO chat_members (chat_id, user_id, role) VALUES ${tuples.join(', ')}
             ON CONFLICT (chat_id, user_id) DO NOTHING`,
            memberParams
          );
        }
      } catch (err: any) {
        isPostgresHealthy = false;
        console.warn('[Database] createChat PG write failed (memory snapshot resumes):', err.message);
      }
    }
    persistMemoryStore();

    return {
      id: chatId,
      type,
      name,
      createdAt: now,
      updatedAt: now
    };
  }

  // ── Group management (WhatsApp/TG parity) ──────────────────────────────
  public getChatRole(chatId: string, userId: string): 'owner' | 'admin' | 'member' | null {
    const role = memoryStore.chatRoles.get(chatId)?.get(userId);
    if (role) return role;
    return memoryStore.chatMembers.get(chatId)?.has(userId) ? 'member' : null;
  }

  public isGroupAdmin(chatId: string, userId: string): boolean {
    const role = this.getChatRole(chatId, userId);
    return role === 'owner' || role === 'admin';
  }

  public setChatRole(chatId: string, userId: string, role: 'owner' | 'admin' | 'member'): void {
    if (!memoryStore.chatRoles.has(chatId)) memoryStore.chatRoles.set(chatId, new Map());
    memoryStore.chatRoles.get(chatId)!.set(userId, role);
    if (isPostgresHealthy && activePgPool) {
      activePgPool.query('UPDATE chat_members SET role = $1 WHERE chat_id = $2 AND user_id = $3', [role, chatId, userId]).catch(() => {});
    }
    persistMemoryStore();
  }

  /** Sync-setters companion: push the mutated in-memory group_settings blob to PostgreSQL. */
  private queueChatSettings(chatId: string): void {
    const c = memoryStore.chats.get(chatId);
    if (!c) return;
    queuePg('UPDATE chats SET group_settings = $1::jsonb WHERE id = $2', [JSON.stringify(c.group_settings || {}), chatId]);
  }

  public getChatInfo(chatId: string): any {
    const c = memoryStore.chats.get(chatId);
    if (!c) return null;
    const roles = memoryStore.chatRoles.get(chatId) || new Map();
    const members = Array.from(memoryStore.chatMembers.get(chatId) || []).map(uid => ({
      userId: uid,
      role: roles.get(uid) || 'member',
    }));
    return {
      id: c.id,
      type: c.type,
      name: c.name,
      avatarUrl: c.avatar_url || c.avatarUrl || null,
      description: c.description || '',
      permissions: {
        ...(c.group_settings?.permissions || { whoCanSend: 'all', whoCanEditInfo: 'admins' }),
        slowMode: c.group_settings?.slowMode ?? 0,
        joinApproval: c.group_settings?.joinApproval === true,
        protectedContent: c.group_settings?.protectedContent === true,
      },
      members,
      createdAt: c.created_at || c.createdAt,
      membershipVersion: this.getMembershipVersion(chatId),
    };
  }

  /**
   * Group membership epoch (external-audit E2EE-01/E2EE-02): durable monotonic
   * counter bumped on every membership change (add/remove/leave). Group send
   * gates compare the client-declared version against this — stale epochs are
   * rejected so no message crosses a membership boundary under an old
   * sender-key epoch.
   */
  public getMembershipVersion(chatId: string): number {
    const c = memoryStore.chats.get(chatId);
    return Number((c as any)?.membership_version) || 1;
  }

  /** Bump the membership epoch; returns the new value (memory mirror + Pg). */
  public bumpMembershipVersion(chatId: string): number {
    const c = memoryStore.chats.get(chatId);
    if (c) {
      (c as any).membership_version = (Number((c as any).membership_version) || 1) + 1;
    }
    queuePg('UPDATE chats SET membership_version = membership_version + 1 WHERE id = $1', [chatId]);
    persistMemoryStore();
    return this.getMembershipVersion(chatId);
  }

  public setChatInfo(chatId: string, patch: { name?: string; description?: string; avatarUrl?: string }): boolean {
    const c = memoryStore.chats.get(chatId);
    if (!c) return false;
    if (patch.name !== undefined) c.name = patch.name;
    if (patch.description !== undefined) c.description = patch.description;
    if (patch.avatarUrl !== undefined) c.avatar_url = patch.avatarUrl;
    queuePg(
      'UPDATE chats SET name = $1, description = $2, avatar_url = $3, group_settings = $4::jsonb, updated_at = NOW() WHERE id = $5',
      [c.name, c.description || '', c.avatar_url || null, JSON.stringify(c.group_settings || {}), chatId]
    );
    persistMemoryStore();
    return true;
  }

  public setChatPermissions(chatId: string, perms: { whoCanSend?: 'all' | 'admins'; whoCanEditInfo?: 'all' | 'admins' }): boolean {
    const c = memoryStore.chats.get(chatId);
    if (!c) return false;
    if (!c.group_settings) c.group_settings = {};
    c.group_settings.permissions = { ...(c.group_settings.permissions || { whoCanSend: 'all', whoCanEditInfo: 'admins' }), ...perms };
    queuePg('UPDATE chats SET group_settings = $1::jsonb WHERE id = $2', [JSON.stringify(c.group_settings || {}), chatId]);
    persistMemoryStore();
    return true;
  }

  public getChatPermissions(chatId: string): { whoCanSend: 'all' | 'admins'; whoCanEditInfo: 'all' | 'admins' } {
    const c = memoryStore.chats.get(chatId);
    return c?.group_settings?.permissions || { whoCanSend: 'all', whoCanEditInfo: 'admins' };
  }

  /**
   * DIR-NEW-04 (second independent review): ATOMIC membership change +
   * membership_version bump. Memory mutates first, then ONE awaited PG
   * transaction (BEGIN → roster writes → bump RETURNING → COMMIT). Throws
   * on PG failure (routes answer 503 and never broadcast pre-commit).
   * Returns the NEW membership_version.
   */
  public async applyMembershipChange(chatId: string, change: 'add' | 'remove', userIds: string[]): Promise<number> {
    // BATCH-2 (DIR-AB-02): snapshot the roster mirrors BEFORE mutation so a
    // failed PG transaction restores the pre-change state exactly (no phantom
    // members, no locked-out members). Copies, not references.
    const prevMembers = new Set(memoryStore.chatMembers.get(chatId) || []);
    const prevRoles = new Map(memoryStore.chatRoles.get(chatId) || []);
    // 1) Memory mirror first (single-node consistency).
    if (change === 'add') {
      const set = memoryStore.chatMembers.get(chatId) || new Set<string>();
      const roles = memoryStore.chatRoles.get(chatId) || new Map();
      userIds.forEach(uid => { set.add(uid); if (!roles.has(uid)) roles.set(uid, 'member'); });
      memoryStore.chatMembers.set(chatId, set);
      memoryStore.chatRoles.set(chatId, roles);
    } else {
      for (const uid of userIds) {
        memoryStore.chatMembers.get(chatId)?.delete(uid);
        memoryStore.chatRoles.get(chatId)?.delete(uid);
      }
    }
    const prevMv = this.getMembershipVersion(chatId);
    const mv = prevMv + 1;
    const c = memoryStore.chats.get(chatId);
    if (c) (c as any).membership_version = mv;
    persistMemoryStore();
    // 2) PG transaction (awaited — no fire-and-forget for this path).
    if (!isPostgresHealthy || !activePgPool) return mv;
    // BATCH-6 (ADV-02): connect() is INSIDE the guarded region — a pool
    // exhaustion / connect timeout previously bypassed the restore path and
    // left a phantom member (add) or a locked-out member (remove) persisted
    // in memory AND in the snapshot file.
    let client: any = null;
    try {
      client = await activePgPool.connect();
      await client.query('BEGIN');
      if (change === 'add') {
        for (const uid of userIds) {
          await client.query('INSERT INTO chat_members (chat_id, user_id, role) VALUES ($1, $2, \'member\') ON CONFLICT (chat_id, user_id) DO NOTHING', [chatId, uid]);
        }
      } else {
        for (const uid of userIds) {
          await client.query('DELETE FROM chat_members WHERE chat_id = $1 AND user_id = $2', [chatId, uid]);
        }
      }
      const res = await client.query('UPDATE chats SET membership_version = membership_version + 1 WHERE id = $1 RETURNING membership_version', [chatId]);
      const pgMv = Number(res.rows[0]?.membership_version ?? mv);
      await client.query('COMMIT');
      // Resync the memory mirror from the authoritative value.
      if (c) (c as any).membership_version = pgMv;
      return pgMv;
    } catch (err: any) {
      if (client) { try { await client.query('ROLLBACK'); } catch { /* already closed */ } }
      // BATCH-2/ADV-02: restore the FULL pre-change memory state — roster
      // snapshot + the pre-bump membership_version — and RE-PERSIST so the
      // snapshot file never keeps a phantom/lockout state.
      memoryStore.chatMembers.set(chatId, prevMembers);
      memoryStore.chatRoles.set(chatId, prevRoles);
      if (c) (c as any).membership_version = prevMv;
      persistMemoryStore();
      // Best-effort resync of the chats row from the authoritative value.
      this.resyncChatFromPg(chatId).catch(() => {});
      throw new Error('MEMBERSHIP_TX_FAILED: ' + (err?.message || String(err)));
    } finally {
      if (client) client.release();
    }
  }

  /** Re-pull one chat row from PG to resync the mirror after a failed tx. */
  private async resyncChatFromPg(chatId: string): Promise<void> {
    const rows = await pgQuery('SELECT * FROM chats WHERE id = $1', [chatId]);
    if (rows && rows[0]) {
      const c = memoryStore.chats.get(chatId);
      if (c) Object.assign(c, rows[0]);
    }
  }
  public addChatMembers(chatId: string, userIds: string[]): void {
    const set = memoryStore.chatMembers.get(chatId) || new Set<string>();
    const roles = memoryStore.chatRoles.get(chatId) || new Map();
    userIds.forEach(uid => { set.add(uid); if (!roles.has(uid)) roles.set(uid, 'member'); });
    memoryStore.chatMembers.set(chatId, set);
    memoryStore.chatRoles.set(chatId, roles);
    if (userIds.length > 0) {
      const params: any[] = [];
      const tuples = userIds.map((uid, i) => {
        const base = i * 3;
        params.push(chatId, uid, 'member');
        return `($${base + 1}, $${base + 2}, $${base + 3})`;
      });
      queuePg(
        `INSERT INTO chat_members (chat_id, user_id, role) VALUES ${tuples.join(', ')} ON CONFLICT (chat_id, user_id) DO NOTHING`,
        params
      );
    }
    persistMemoryStore();
  }

  public removeChatMember(chatId: string, userId: string): void {
    memoryStore.chatMembers.get(chatId)?.delete(userId);
    memoryStore.chatRoles.get(chatId)?.delete(userId);
    queuePg('DELETE FROM chat_members WHERE chat_id = $1 AND user_id = $2', [chatId, userId]);
    persistMemoryStore();
  }

  public deleteChat(chatId: string): void {
    memoryStore.chats.delete(chatId);
    memoryStore.chatMembers.delete(chatId);
    memoryStore.chatRoles.delete(chatId);
    memoryStore.messages.forEach((m: any, mid: string) => {
      if (m.chat_id === chatId || m.chatId === chatId) memoryStore.messages.delete(mid);
    });
    // FK cascades remove members/messages/reactions/reads/pins in PostgreSQL.
    queuePg('DELETE FROM chats WHERE id = $1', [chatId]);
    persistMemoryStore();
  }

  public findChatByInviteCode(code: string): string | null {
    for (const [id, c] of memoryStore.chats.entries()) {
      if (c.group_settings?.inviteCode === code) return id;
    }
    return null;
  }

  public setChatInviteCode(chatId: string, code: string): void {
    const c = memoryStore.chats.get(chatId);
    if (!c) return;
    if (!c.group_settings) c.group_settings = {};
    c.group_settings.inviteCode = code;
    this.queueChatSettings(chatId);
    persistMemoryStore();
  }

  public setChatInviteExpiry(chatId: string, expiresAt: number | null): void {
    const c = memoryStore.chats.get(chatId);
    if (!c) return;
    if (!c.group_settings) c.group_settings = {};
    c.group_settings.inviteExpiresAt = expiresAt;
    this.queueChatSettings(chatId);
    persistMemoryStore();
  }

  public getChatInviteExpiry(chatId: string): number | null {
    return memoryStore.chats.get(chatId)?.group_settings?.inviteExpiresAt ?? null;
  }

  public getChatJoinRequests(chatId: string): any[] {
    return memoryStore.chats.get(chatId)?.group_settings?.joinRequests || [];
  }

  public setChatJoinRequests(chatId: string, requests: any[]): void {
    const c = memoryStore.chats.get(chatId);
    if (!c) return;
    if (!c.group_settings) c.group_settings = {};
    c.group_settings.joinRequests = requests;
    this.queueChatSettings(chatId);
    persistMemoryStore();
  }

  public setChatJoinApproval(chatId: string, required: boolean): void {
    const c = memoryStore.chats.get(chatId);
    if (!c) return;
    if (!c.group_settings) c.group_settings = {};
    c.group_settings.joinApproval = required;
    this.queueChatSettings(chatId);
    persistMemoryStore();
  }

  public getChatJoinApproval(chatId: string): boolean {
    return memoryStore.chats.get(chatId)?.group_settings?.joinApproval === true;
  }

  // ── Disappearing messages (WhatsApp parity): per-chat timer ─────────────
  public setChatDisappearingTimer(chatId: string, timer: 'off' | '24h' | '7d' | '90d'): void {
    const c = memoryStore.chats.get(chatId);
    if (!c) return;
    if (!c.group_settings) c.group_settings = {};
    c.group_settings.disappearingTimer = timer;
    this.queueChatSettings(chatId);
    persistMemoryStore();
  }

  public getChatDisappearingTimer(chatId: string): 'off' | '24h' | '7d' | '90d' {
    return memoryStore.chats.get(chatId)?.group_settings?.disappearingTimer || 'off';
  }

  public setChatSlowMode(chatId: string, seconds: number): void {
    const c = memoryStore.chats.get(chatId);
    if (!c) return;
    if (!c.group_settings) c.group_settings = {};
    c.group_settings.slowMode = seconds;
    this.queueChatSettings(chatId);
    persistMemoryStore();
  }

  public getChatSlowMode(chatId: string): number {
    return memoryStore.chats.get(chatId)?.group_settings?.slowMode || 0;
  }

  // ── Advanced group privacy: ban list + per-member restrict + protected content ──
  /** Granular admin rights (Telegram parity). owner implicitly has all. */
  public getAdminRights(chatId: string, userId: string): { addMembers: boolean; editInfo: boolean; pinMessages: boolean; deleteMessages: boolean } {
    const rights = memoryStore.chats.get(chatId)?.group_settings?.adminRights?.[userId];
    // Existing admins default to full rights (backward compatible)
    return rights || { addMembers: true, editInfo: true, pinMessages: true, deleteMessages: true };
  }

  public setAdminRight(chatId: string, userId: string, right: 'addMembers' | 'editInfo' | 'pinMessages' | 'deleteMessages', value: boolean): void {
    const c = memoryStore.chats.get(chatId);
    if (!c) return;
    if (!c.group_settings) c.group_settings = {};
    if (!c.group_settings.adminRights) c.group_settings.adminRights = {};
    if (!c.group_settings.adminRights[userId]) c.group_settings.adminRights[userId] = { addMembers: true, editInfo: true, pinMessages: true, deleteMessages: true };
    c.group_settings.adminRights[userId][right] = value;
    this.queueChatSettings(chatId);
    persistMemoryStore();
  }

  public adminCan(chatId: string, userId: string, right: 'addMembers' | 'editInfo' | 'pinMessages' | 'deleteMessages'): boolean {
    if (this.getChatRole(chatId, userId) === 'owner') return true;
    if (this.getChatRole(chatId, userId) !== 'admin') return false;
    return this.getAdminRights(chatId, userId)[right];
  }

  public setInviteUsageLimit(chatId: string, limit: number): void {
    const c = memoryStore.chats.get(chatId);
    if (!c) return;
    if (!c.group_settings) c.group_settings = {};
    c.group_settings.inviteUsageLimit = limit;
    c.group_settings.inviteUsageCount = 0;
    this.queueChatSettings(chatId);
    persistMemoryStore();
  }

  public getInviteUsage(chatId: string): { limit: number; count: number } {
    const gs = memoryStore.chats.get(chatId)?.group_settings || {};
    return { limit: gs.inviteUsageLimit || 0, count: gs.inviteUsageCount || 0 };
  }

  public consumeInviteUsage(chatId: string): boolean {
    const c = memoryStore.chats.get(chatId);
    const limit = c?.group_settings?.inviteUsageLimit;
    if (!limit || limit <= 0) return true; // no limit
    const count = c.group_settings.inviteUsageCount || 0;
    if (count >= limit) return false;
    c.group_settings.inviteUsageCount = count + 1;
    this.queueChatSettings(chatId);
    persistMemoryStore();
    return true;
  }

  public addPastMember(chatId: string, userId: string, displayName: string, removedBy?: string): void {
    const c = memoryStore.chats.get(chatId);
    if (!c) return;
    if (!c.group_settings) c.group_settings = {};
    if (!c.group_settings.pastMembers) c.group_settings.pastMembers = [];
    c.group_settings.pastMembers = c.group_settings.pastMembers.filter((p: any) => p.userId !== userId);
    c.group_settings.pastMembers.push({ userId, displayName, removedBy: removedBy || null, leftAt: new Date().toISOString() });
    this.queueChatSettings(chatId);
    persistMemoryStore();
  }

  public getPastMembers(chatId: string): any[] {
    return memoryStore.chats.get(chatId)?.group_settings?.pastMembers || [];
  }
  public banGroupMember(chatId: string, userId: string): void {
    const c = memoryStore.chats.get(chatId);
    if (!c) return;
    if (!c.group_settings) c.group_settings = {};
    const list: string[] = c.group_settings.bannedUserIds || [];
    if (!list.includes(userId)) list.push(userId);
    c.group_settings.bannedUserIds = list;
    this.queueChatSettings(chatId);
    // BATCH-2 (DIR-CB-01): ban-bookkeeping ONLY — membership removal moved to
    // the routes via applyMembershipChange (atomic mv bump + broadcasts). The
    // ban path must never bypass the membership-epoch mechanism.
    persistMemoryStore();
  }

  public unbanGroupMember(chatId: string, userId: string): void {
    const c = memoryStore.chats.get(chatId);
    if (!c?.group_settings?.bannedUserIds) return;
    c.group_settings.bannedUserIds = c.group_settings.bannedUserIds.filter((id: string) => id !== userId);
    this.queueChatSettings(chatId);
    persistMemoryStore();
  }

  public isGroupBanned(chatId: string, userId: string): boolean {
    return (memoryStore.chats.get(chatId)?.group_settings?.bannedUserIds || []).includes(userId);
  }

  public getGroupBans(chatId: string): string[] {
    return memoryStore.chats.get(chatId)?.group_settings?.bannedUserIds || [];
  }

  /** Restrict a member from sending in this group. untilTs: -1 = forever, else epoch ms. */
  public restrictGroupMember(chatId: string, userId: string, untilTs: number): void {
    const c = memoryStore.chats.get(chatId);
    if (!c) return;
    if (!c.group_settings) c.group_settings = {};
    if (!c.group_settings.restrictions) c.group_settings.restrictions = {};
    if (untilTs === 0) delete c.group_settings.restrictions[userId];
    else c.group_settings.restrictions[userId] = untilTs;
    this.queueChatSettings(chatId);
    persistMemoryStore();
  }

  /** Returns remaining restriction ms (0 = unrestricted). */
  public getGroupRestriction(chatId: string, userId: string): number {
    const until = memoryStore.chats.get(chatId)?.group_settings?.restrictions?.[userId];
    if (!until) return 0;
    if (until === -1) return Number.MAX_SAFE_INTEGER;
    return Math.max(0, until - Date.now());
  }

  public setProtectedContent(chatId: string, enabled: boolean): void {
    const c = memoryStore.chats.get(chatId);
    if (!c) return;
    if (!c.group_settings) c.group_settings = {};
    c.group_settings.protectedContent = enabled;
    this.queueChatSettings(chatId);
    persistMemoryStore();
  }

  public isProtectedContent(chatId: string): boolean {
    return memoryStore.chats.get(chatId)?.group_settings?.protectedContent === true;
  }

  // ── Auto-delete inactive accounts (Telegram parity) ─────────────────────
  /** Returns userIds inactive beyond the user's own chosen threshold. */
  public collectInactiveAccounts(): { userId: string; months: number; lastSeen: string }[] {
    const out: { userId: string; months: number; lastSeen: string }[] = [];
    const now = Date.now();
    memoryStore.users.forEach((u: any, id: string) => {
      try {
        const months = Number(u.user_settings?.autoDeleteAfterMonths || 0);
        if (!months) return;
        const last = new Date(u.last_seen || u.lastSeen || u.created_at || u.createdAt || now).getTime();
        if (now - last > months * 30 * 86400_000) {
          out.push({ userId: id, months, lastSeen: new Date(last).toISOString() });
        }
      } catch { /* skip malformed rows */ }
    });
    return out;
  }

  /** Sweep expired messages: mark deleted + return ids per chat for broadcast. */
  public collectExpiredMessages(): { chatId: string; messageId: string; expiresAt: string }[] {
    const out: { chatId: string; messageId: string; expiresAt: string }[] = [];
    const now = Date.now();
    memoryStore.messages.forEach((m: any, id: string) => {
      const exp = m.expiresAt || m.expires_at;
      if (exp && !m.deleted_at && !m.deletedAt && new Date(exp).getTime() <= now) {
        m.deletedAt = new Date().toISOString();
        m.state = 'deleted';
        m.content = '';
        m.attachments = [];
        out.push({ chatId: m.chat_id || m.chatId, messageId: id, expiresAt: exp });
      }
    });
    // PG sweep for messages this process hasn't seen in memory (durable path).
    // Fire-and-forget: results are mirrored into memory so later sweeps stay consistent.
    if (isPostgresHealthy && activePgPool) {
      activePgPool.query(
        `UPDATE messages SET deleted_at = NOW(), content = ''
         WHERE expires_at IS NOT NULL AND deleted_at IS NULL AND expires_at <= NOW()
         RETURNING id, chat_id, expires_at`
      ).then((res: any) => {
        for (const r of (res.rows || []) as any[]) {
          const m: any = memoryStore.messages.get(r.id);
          if (m) {
            m.deletedAt = new Date().toISOString();
            m.state = 'deleted';
            m.content = '';
            m.attachments = [];
          }
        }
      }).catch(() => { /* transient — next sweep retries */ });
    }
    if (out.length) persistMemoryStore();
    return out;
  }

  public async findOneToOneChat(userId1: string, userId2: string): Promise<Chat | undefined> {
    const rows = await pgQuery(
      `SELECT c.* FROM chats c
       JOIN chat_members a ON a.chat_id = c.id AND a.user_id = $1
       JOIN chat_members b ON b.chat_id = c.id AND b.user_id = $2
       WHERE c.type = 'one-to-one' LIMIT 1`,
      [userId1, userId2]
    );
    if (rows) {
      if (rows.length === 0) return undefined;
      const c = rows[0];
      return {
        id: c.id,
        type: c.type,
        name: c.name,
        createdAt: c.created_at ? new Date(c.created_at).toISOString() : new Date().toISOString(),
        updatedAt: c.updated_at ? new Date(c.updated_at).toISOString() : new Date().toISOString()
      };
    }
    for (const [chatId, c] of memoryStore.chats.entries()) {
      if (c.type === 'one-to-one') {
        const members = memoryStore.chatMembers.get(chatId);
        if (members && members.has(userId1) && members.has(userId2)) {
          return {
            id: c.id,
            type: c.type,
            name: c.name,
            createdAt: c.created_at,
            updatedAt: c.updated_at
          };
        }
      }
    }
    return undefined;
  }

  public async getMessagesForChat(chatId: string, limit = 50, beforeTimestamp?: string, afterTimestamp?: string): Promise<Message[]> {
    const limitNum = Math.max(1, Math.min(Number(limit) || 50, 500));
    const rows = await pgQuery(
      `SELECT * FROM messages
       WHERE chat_id = $1 AND deleted_at IS NULL
         AND (broadcast_at IS NOT NULL OR scheduled_at IS NULL)
         AND ($2::timestamptz IS NULL OR created_at < $2::timestamptz)
         AND ($3::timestamptz IS NULL OR created_at > $3::timestamptz)
       ORDER BY created_at DESC, id DESC
       LIMIT $4`,
      [chatId, beforeTimestamp || null, afterTimestamp || null, limitNum]
    );
    if (rows) {
      rows.reverse(); // newest-N slice, returned ascending (same shape as memory path)
      return this.pgEnrichMessageRows(rows);
    }
    const chatMsgs: any[] = [];
    for (const m of memoryStore.messages.values()) {
      if (m.chat_id === chatId && !m.deleted_at) {
        if (m.scheduled_at && !m.broadcast_at) continue; // undelivered scheduled message — hidden until broadcast
        if (beforeTimestamp && new Date(m.created_at) >= new Date(beforeTimestamp)) continue;
        if (afterTimestamp && new Date(m.created_at) <= new Date(afterTimestamp)) continue;
        chatMsgs.push(m);
      }
    }

    chatMsgs.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
    const sliced = chatMsgs.slice(-limit);
    return this.enrichMessageRows(sliced);
  }

  public async createMessage(
    chatId: string,
    senderId: string,
    content: string,
    type: 'text' | 'attachment' = 'text',
    attachments: any[] = [],
    replyTo: any = null,
    reactions: any = {},
    customId?: string,
    customCreatedAt?: string,
    clientMessageId?: string,
    expiresAt?: string,
    poll?: any,
    scheduledAt?: Date | null
  ): Promise<Message> {
    const messageId = customId || ('msg-' + crypto.randomUUID());
    const now = customCreatedAt || new Date().toISOString();
    const sender = memoryStore.users.get(senderId);
    const senderName = sender?.display_name || sender?.username || '';

    // Poll handling: an explicit `poll` arg wins; otherwise the poll rides in
    // as a structured pseudo-attachment (application/x-dirasha-poll — same
    // pattern as contact/location cards) and is stripped from the attachment
    // rows before persistence.
    let pollData: any = (poll !== undefined && poll !== null) ? normalizePollPayload(poll) : null;
    let persistAttachments = attachments || [];
    if (!pollData) {
      const extracted = extractPollFromAttachments(attachments || []);
      persistAttachments = extracted.attachments;
      pollData = extracted.poll;
    } else {
      persistAttachments = extractPollFromAttachments(attachments || []).attachments;
    }

    // Scheduled messages (v5): when scheduledAt is provided the row persists
    // with scheduled_at set and broadcast_at NULL — it stays invisible to
    // feeds/search/unread counts until the delivery sweep stamps broadcast_at.
    const scheduledIso = scheduledAt ? scheduledAt.toISOString() : undefined;

    const msg = {
      id: messageId,
      chat_id: chatId,
      sender_id: senderId,
      sender_name: senderName,
      content,
      type,
      reply_to_id: replyTo ? replyTo.id : null,
      created_at: now,
      edited_at: null,
      deleted_at: null,
      client_message_id: clientMessageId || null,
      expires_at: expiresAt || null,
      poll: pollData || null,
      scheduled_at: scheduledIso,
      broadcast_at: scheduledIso ? null : undefined
    };

    memoryStore.messages.set(messageId, msg);

    if (persistAttachments && persistAttachments.length > 0) {
      for (const att of persistAttachments) {
        const attId = 'att-' + crypto.randomUUID();
        memoryStore.attachments.set(attId, {
          id: attId,
          message_id: messageId,
          name: att.name,
          size: att.size,
          mime_type: att.mimeType,
          url: att.url,
          meta: att.meta || null,
          created_at: now
        });
      }
    }

    // Set initial read receipts
    const members = memoryStore.chatMembers.get(chatId) || new Set();
    const readMap = new Map<string, { status: string; updatedAt: string }>();
    for (const uId of members) {
      readMap.set(uId, { status: uId === senderId ? 'read' : 'sent', updatedAt: now });
    }
    memoryStore.messageReads.set(messageId, readMap);

    // Update chat timestamp (scheduled messages bump it at delivery time, not scheduling time)
    const chat = memoryStore.chats.get(chatId);
    if (chat && !scheduledIso) chat.updated_at = now;

    // PostgreSQL durable write (memory stays in sync for fallback reads)
    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query(
          `INSERT INTO messages (id, chat_id, sender_id, sender_name, content, type, reply_to_id, created_at, edited_at, deleted_at, client_message_id, expires_at, deleted_for, poll, scheduled_at, broadcast_at)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13::jsonb, $14::jsonb, $15::timestamptz, $16::timestamptz)
           ON CONFLICT DO NOTHING`,
          [messageId, chatId, senderId, senderName, content, type, replyTo ? replyTo.id : null, now, null, null,
           clientMessageId || null, expiresAt || null, '[]', pollData ? JSON.stringify(pollData) : null, scheduledIso || null, null]
        );
        if (persistAttachments && persistAttachments.length > 0) {
          const attParams: any[] = [];
          const attTuples = persistAttachments.map((att, i) => {
            const base = i * 8;
            const attId = 'att-' + crypto.randomUUID();
            const metaJson = att.meta && typeof att.meta === 'object' ? JSON.stringify(att.meta) : null;
            attParams.push(attId, messageId, att.name || 'attachment', Number(att.size) || 0, att.mimeType || 'application/octet-stream', att.url || '', metaJson, now);
            return `($${base + 1}, $${base + 2}, $${base + 3}, $${base + 4}, $${base + 5}, $${base + 6}, $${base + 7}::jsonb, $${base + 8})`;
          });
          await activePgPool.query(
            `INSERT INTO attachments (id, message_id, name, size, mime_type, url, meta, created_at)
             VALUES ${attTuples.join(', ')} ON CONFLICT (id) DO NOTHING`,
            attParams
          );
        }
        // Initial receipts: sender 'read', everyone else 'sent' (mirrors memory readMap)
        const memberParams: any[] = [];
        const memberTuples: string[] = [];
        let idx = 0;
        for (const uId of members) {
          const base = idx * 5;
          memberParams.push(messageId, uId, chatId, uId === senderId ? 'read' : 'sent', now);
          memberTuples.push(`($${base + 1}, $${base + 2}, $${base + 3}, $${base + 4}, $${base + 5})`);
          idx++;
        }
        if (memberTuples.length > 0) {
          await activePgPool.query(
            `INSERT INTO message_reads (message_id, user_id, chat_id, status, updated_at)
             VALUES ${memberTuples.join(', ')}
             ON CONFLICT (message_id, user_id) DO NOTHING`,
            memberParams
          );
        }
        if (!scheduledIso) {
          await activePgPool.query('UPDATE chats SET updated_at = $2 WHERE id = $1', [chatId, now]);
        }
        const inserted = await activePgPool.query('SELECT * FROM messages WHERE id = $1', [messageId]);
        if (inserted.rows.length > 0) {
          return (await this.pgEnrichMessageRows(inserted.rows))[0];
        }
        // client_message_id dedup hit: return the existing row for that client id
        if (clientMessageId) {
          const dupe = await activePgPool.query('SELECT * FROM messages WHERE client_message_id = $1', [clientMessageId]);
          if (dupe.rows.length > 0) {
            return (await this.pgEnrichMessageRows(dupe.rows))[0];
          }
        }
      } catch (err: any) {
        isPostgresHealthy = false;
        console.warn('[Database] createMessage PG write failed (memory snapshot resumes):', err.message);
      }
    }

    persistMemoryStore();

    const list = await this.enrichMessageRows([msg]);
    return list[0];
  }

  /**
   * Poll voting (WhatsApp parity). Reads messages.poll, applies single-choice
   * (replace) or multi-choice (toggle) rules for the user, writes the updated
   * JSONB back with a row-level guard, and returns the canonical updated poll.
   * PG-first with memory-path parity; the poll dies with its message via the
   * deleted_at filter.
   */
  public async votePoll(chatId: string, messageId: string, userId: string, optionIndexes: number[]): Promise<any | null> {
    if (!chatId || !messageId || !userId || !Array.isArray(optionIndexes)) return null;

    // PG durable path
    const rows = await pgQuery(
      `SELECT poll FROM messages WHERE id = $1 AND chat_id = $2 AND deleted_at IS NULL AND poll IS NOT NULL`,
      [messageId, chatId]
    );
    if (rows) {
      if (rows.length === 0) return null;
      const updated = applyPollVote(rows[0].poll, userId, optionIndexes);
      if (!updated) return null;
      const written = await pgQuery(
        `UPDATE messages SET poll = $3::jsonb
         WHERE id = $1 AND chat_id = $2 AND poll IS NOT NULL AND deleted_at IS NULL
         RETURNING poll`,
        [messageId, chatId, JSON.stringify(updated)]
      );
      const finalPoll = written && written.length > 0 ? written[0].poll : updated;
      // Mirror into the memory store so fallback reads stay consistent
      const memMsg: any = memoryStore.messages.get(messageId);
      if (memMsg && memMsg.chat_id === chatId) memMsg.poll = finalPoll;
      return finalPoll;
    }

    // Memory fallback path (PG unavailable)
    const memMsg: any = memoryStore.messages.get(messageId);
    if (!memMsg || memMsg.chat_id !== chatId || memMsg.deleted_at) return null;
    if (!memMsg.poll) return null;
    const memUpdated = applyPollVote(memMsg.poll, userId, optionIndexes);
    if (!memUpdated) return null;
    memMsg.poll = memUpdated;
    persistMemoryStore();
    return memUpdated;
  }

  public async getMessageById(messageId: string): Promise<Message | undefined> {
    const rows = await pgQuery('SELECT * FROM messages WHERE id = $1', [messageId]);
    if (rows && rows.length > 0) {
      return (await this.pgEnrichMessageRows(rows))[0];
    }
    // Fall through to memory: the message may predate PG mode / live only in the snapshot.
    const msg = memoryStore.messages.get(messageId);
    if (!msg) return undefined;
    const list = await this.enrichMessageRows([msg]);
    return list[0];
  }

  public async updateMessage(messageId: string, patches: Partial<Message>): Promise<Message | undefined> {
    if (isPostgresHealthy && activePgPool) {
      try {
        const res = await activePgPool.query('SELECT * FROM messages WHERE id = $1', [messageId]);
        const row = res.rows[0];
        if (row) {
          const sets: string[] = [];
          const params: any[] = [];
          if (patches.content !== undefined) {
            params.push(patches.content);
            sets.push(`content = $${params.length}`);
          }
          if (patches.editedAt !== undefined) {
            params.push(patches.editedAt ? new Date(patches.editedAt) : null);
            sets.push(`edited_at = $${params.length}`);
          }
          if (patches.deletedAt !== undefined) {
            params.push(patches.deletedAt ? new Date(patches.deletedAt) : null);
            sets.push(`deleted_at = $${params.length}`);
          }
          if (patches.deletedFor !== undefined) {
            const existing: string[] = Array.isArray(row.deleted_for) ? row.deleted_for : [];
            params.push(JSON.stringify(Array.from(new Set([...existing, ...patches.deletedFor]))));
            sets.push(`deleted_for = $${params.length}::jsonb`);
          }
          if (sets.length > 0) {
            params.push(messageId);
            await activePgPool.query(`UPDATE messages SET ${sets.join(', ')} WHERE id = $${params.length}`, params);
          }
          if (patches.reactions !== undefined) {
            await activePgPool.query('DELETE FROM message_reactions WHERE message_id = $1', [messageId]);
            const entries = Object.entries(patches.reactions);
            if (entries.length > 0) {
              const rParams: any[] = [];
              const rTuples = entries.flatMap(([emoji, userIds]) => {
                const base = rParams.length;
                for (const uid of userIds) rParams.push(messageId, uid, emoji);
                return userIds.map((_, k) => `($${base + k * 3 + 1}, $${base + k * 3 + 2}, $${base + k * 3 + 3})`);
              });
              await activePgPool.query(
                `INSERT INTO message_reactions (message_id, user_id, reaction_emoji)
                 VALUES ${rTuples.join(', ')} ON CONFLICT DO NOTHING`,
                rParams
              );
            }
          }
          if (patches.starredBy !== undefined) {
            await activePgPool.query('DELETE FROM message_stars WHERE message_id = $1', [messageId]);
            if (patches.starredBy.length > 0) {
              const sParams: any[] = [];
              const sTuples = patches.starredBy.map((uid, i) => {
                const base = i * 2;
                sParams.push(uid, messageId);
                return `($${base + 1}, $${base + 2})`;
              });
              await activePgPool.query(
                `INSERT INTO message_stars (user_id, message_id) VALUES ${sTuples.join(', ')} ON CONFLICT DO NOTHING`,
                sParams
              );
            }
          }
          if (patches.isPinned !== undefined) {
            if (patches.isPinned) {
              await activePgPool.query(
                `INSERT INTO message_pins (chat_id, message_id, pinned_by) VALUES ($1, $2, $3)
                 ON CONFLICT (chat_id, message_id) DO NOTHING`,
                [row.chat_id, messageId, row.sender_id]
              );
            } else {
              await activePgPool.query('DELETE FROM message_pins WHERE chat_id = $1 AND message_id = $2', [row.chat_id, messageId]);
            }
          }
          return await this.getMessageById(messageId);
        }
      } catch (err: any) {
        isPostgresHealthy = false;
        console.warn('[Database] updateMessage PG write failed (memory fallback):', err.message);
      }
    }

    const msg = memoryStore.messages.get(messageId);
    if (!msg) return undefined;

    if (patches.content !== undefined) msg.content = patches.content;
    if (patches.editedAt !== undefined) msg.edited_at = patches.editedAt;
    if (patches.deletedAt !== undefined) msg.deleted_at = patches.deletedAt;

    // deletedFor (hide-for-self) — was silently dropped before (defect: deletes
    // resurrected after refresh). Persist on both key spellings for readers.
    if (patches.deletedFor !== undefined) {
      const existing: string[] = ((msg as any).deleted_for || (msg as any).deletedFor || []);
      const merged = Array.from(new Set([...existing, ...patches.deletedFor]));
      (msg as any).deleted_for = merged;
      (msg as any).deletedFor = merged;
    }

    if (patches.reactions !== undefined) {
      const reactionMap = new Map<string, Set<string>>();
      for (const [emoji, userIds] of Object.entries(patches.reactions)) {
        reactionMap.set(emoji, new Set(userIds));
      }
      memoryStore.messageReactions.set(messageId, reactionMap);
    }

    if (patches.starredBy !== undefined) {
      const targetUserIds = new Set(patches.starredBy);
      for (const [uId, starsSet] of memoryStore.messageStars.entries()) {
        if (targetUserIds.has(uId)) {
          starsSet.add(messageId);
        } else {
          starsSet.delete(messageId);
        }
      }
      for (const uId of targetUserIds) {
        if (!memoryStore.messageStars.has(uId)) {
          memoryStore.messageStars.set(uId, new Set());
        }
        memoryStore.messageStars.get(uId)!.add(messageId);
      }
    }

    if (patches.isPinned !== undefined) {
      const chatPins = memoryStore.messagePins.get(msg.chat_id) || new Map();
      if (patches.isPinned) {
        chatPins.set(messageId, { pinnedBy: msg.sender_id, pinnedAt: new Date().toISOString() });
      } else {
        chatPins.delete(messageId);
      }
      memoryStore.messagePins.set(msg.chat_id, chatPins);
    }

    persistMemoryStore();
    return this.getMessageById(messageId);
  }

  public async updateMessageStatus(messageId: string, userId: string, status: 'delivered' | 'read'): Promise<MessageReadReceipt | undefined> {
    const now = new Date().toISOString();

    // Memory dual-write (unchanged shape/behavior for memory mode)
    if (!memoryStore.messageReads.has(messageId)) {
      memoryStore.messageReads.set(messageId, new Map());
    }
    const readMap = memoryStore.messageReads.get(messageId)!;
    readMap.set(userId, { status, updatedAt: now });
    persistMemoryStore();

    const chatRows = await pgQuery('SELECT chat_id FROM messages WHERE id = $1', [messageId]);
    if (chatRows && chatRows.length > 0) {
      const upserted = await pgQuery(
        `INSERT INTO message_reads (message_id, user_id, chat_id, status, updated_at)
         VALUES ($1, $2, $3, $4, NOW())
         ON CONFLICT (message_id, user_id)
         DO UPDATE SET status = EXCLUDED.status, updated_at = NOW()
         RETURNING updated_at`,
        [messageId, userId, chatRows[0].chat_id, status]
      );
      return {
        messageId,
        userId,
        chatId: chatRows[0].chat_id,
        status,
        updatedAt: upserted && upserted[0]?.updated_at ? new Date(upserted[0].updated_at).toISOString() : now
      };
    }
    const msg = memoryStore.messages.get(messageId);
    if (!msg) return undefined;

    return {
      messageId,
      userId,
      chatId: msg.chat_id,
      status,
      updatedAt: now
    };
  }

  public async syncPendingReceipts(userId: string): Promise<Array<{ messageId: string; chatId: string }>> {
    const synced: Array<{ messageId: string; chatId: string }> = [];
    const now = new Date().toISOString();

    // Memory dual-write
    for (const [msgId, reads] of memoryStore.messageReads.entries()) {
      const userStatus = reads.get(userId);
      if (userStatus && userStatus.status === 'sent') {
        userStatus.status = 'delivered';
        userStatus.updatedAt = now;
        const msg = memoryStore.messages.get(msgId);
        if (msg) synced.push({ messageId: msgId, chatId: msg.chat_id });
      }
    }
    // PG durable sweep — include rows this process never saw in memory
    const rows = await pgQuery(
      `UPDATE message_reads mr SET status = 'delivered', updated_at = NOW()
       FROM messages m
       WHERE mr.message_id = m.id AND mr.user_id = $1 AND mr.status = 'sent'
       RETURNING mr.message_id, m.chat_id`,
      [userId]
    );
    if (rows) {
      const pgSynced = rows.map(r => ({ messageId: r.message_id, chatId: r.chat_id }));
      // Merge (memory-synced entries are a subset by construction)
      const seen = new Set(synced.map(s => s.messageId));
      for (const s of pgSynced) {
        if (!seen.has(s.messageId)) synced.push(s);
      }
      return synced;
    }
    return synced;
  }

  public async bulkUpdateReadReceipts(chatId: string, userId: string, upToTimestamp: string): Promise<string[]> {
    const threshold = new Date(upToTimestamp).getTime();
    const readMsgIds: string[] = [];
    const now = new Date().toISOString();

    // Memory dual-write
    for (const [msgId, msg] of memoryStore.messages.entries()) {
      if (msg.chat_id === chatId && msg.sender_id !== userId && new Date(msg.created_at).getTime() <= threshold) {
        if (!memoryStore.messageReads.has(msgId)) {
          memoryStore.messageReads.set(msgId, new Map());
        }
        const reads = memoryStore.messageReads.get(msgId)!;
        const current = reads.get(userId);
        if (!current || current.status !== 'read') {
          reads.set(userId, { status: 'read', updatedAt: now });
          readMsgIds.push(msgId);
        }
      }
    }
    // PG durable sweep
    const rows = await pgQuery(
      `WITH target AS (
         SELECT m.id AS message_id FROM messages m
         WHERE m.chat_id = $1 AND m.sender_id <> $2 AND m.created_at <= $3
       )
       INSERT INTO message_reads (message_id, user_id, chat_id, status, updated_at)
       SELECT t.message_id, $2, $1, 'read', NOW() FROM target t
       ON CONFLICT (message_id, user_id)
       DO UPDATE SET status = 'read', updated_at = NOW()
       WHERE message_reads.status <> 'read'
       RETURNING message_id`,
      [chatId, userId, upToTimestamp]
    );
    if (rows) {
      const seen = new Set(readMsgIds);
      for (const r of rows) {
        if (!seen.has(r.message_id)) readMsgIds.push(r.message_id);
      }
      return readMsgIds;
    }
    return readMsgIds;
  }

  public async getMessageReceipts(messageId: string): Promise<MessageReadReceipt[]> {
    const rows = await pgQuery(
      `SELECT mr.user_id, mr.status, mr.updated_at, m.chat_id
       FROM message_reads mr JOIN messages m ON m.id = mr.message_id
       WHERE mr.message_id = $1`,
      [messageId]
    );
    if (rows) {
      return rows.map(r => ({
        messageId,
        userId: r.user_id,
        chatId: r.chat_id,
        status: r.status,
        updatedAt: r.updated_at ? new Date(r.updated_at).toISOString() : new Date().toISOString()
      }));
    }
    const reads = memoryStore.messageReads.get(messageId);
    const msg = memoryStore.messages.get(messageId);
    if (!reads || !msg) return [];

    return Array.from(reads.entries()).map(([uId, data]) => ({
      messageId,
      userId: uId,
      chatId: msg.chat_id,
      status: data.status as any,
      updatedAt: data.updatedAt
    }));
  }

  private async enrichMessageRows(rows: any[]): Promise<Message[]> {
    if (rows.length === 0) return [];
    const disabledUsersSet = await this.getUsersWithDisabledReadReceipts();

    return rows.map(row => {
      const sender = memoryStore.users.get(row.sender_id);
      const reactionsObj: Record<string, string[]> = {};
      const reactMap = memoryStore.messageReactions.get(row.id);
      if (reactMap) {
        for (const [emoji, set] of reactMap.entries()) {
          reactionsObj[emoji] = Array.from(set);
        }
      }

      const attachments: any[] = [];
      for (const att of memoryStore.attachments.values()) {
        if (att.message_id === row.id) {
          attachments.push({
            id: att.id,
            name: att.name,
            size: att.size,
            mimeType: att.mime_type,
            url: att.url?.startsWith('data:') ? `/api/attachments/${att.id}` : att.url,
            meta: att.meta || undefined
          });
        }
      }

      const reads = memoryStore.messageReads.get(row.id);
      let calculatedState = 'sent';
      if (row.deleted_at) {
        calculatedState = 'deleted';
      } else if (reads) {
        const otherReads = Array.from(reads.entries()).filter(([uId]) => uId !== row.sender_id);
        if (otherReads.length > 0) {
          if (disabledUsersSet.has(row.sender_id) || otherReads.some(([uId, r]) => r.status === 'read' && disabledUsersSet.has(uId))) {
            calculatedState = 'delivered';
          } else {
            const allRead = otherReads.every(([, r]) => r.status === 'read');
            const anyDelivered = otherReads.some(([, r]) => r.status === 'read' || r.status === 'delivered');
            calculatedState = allRead ? 'read' : (anyDelivered ? 'delivered' : 'sent');
          }
        }
      }

      // Reconstruct reply hierarchy
      let replyToData: any = row.reply_to || row.replyTo || null;
      const refReplyId = row.reply_to_id || row.replyToId || (replyToData && replyToData.id);
      if (refReplyId) {
        const parentMsg = memoryStore.messages.get(refReplyId);
        if (parentMsg) {
          const parentSender = memoryStore.users.get(parentMsg.sender_id);
          replyToData = {
            id: parentMsg.id,
            senderId: parentMsg.sender_id,
            senderName: parentSender?.display_name || parentSender?.username || parentMsg.sender_name || 'مستخدم',
            content: parentMsg.content || ''
          };
        }
      }

      // Determine starred users
      const starredBy: string[] = [];
      for (const [uId, starsSet] of memoryStore.messageStars.entries()) {
        if (starsSet.has(row.id)) starredBy.push(uId);
      }

      // Determine pin status
      const chatPins = memoryStore.messagePins.get(row.chat_id);
      const isPinned = !!(chatPins && chatPins.has(row.id)) || !!row.is_pinned || !!row.isPinned;

      return {
        id: row.id,
        chatId: row.chat_id,
        senderId: row.sender_id,
        senderName: row.sender_name || sender?.display_name || sender?.username,
        sender: sender ? {
          id: sender.id,
          username: sender.username,
          displayName: sender.display_name,
          avatarUrl: sender.avatar_url,
          onlineStatus: sender.online_status,
          lastSeen: sender.last_seen
        } : undefined,
        content: row.content,
        type: row.type,
        attachments,
        poll: row.poll || null,
        deletedFor: row.deleted_for || row.deletedFor || [],
        createdAt: row.created_at,
        expiresAt: row.expires_at || null,
        scheduledAt: row.scheduled_at || null,
        broadcastAt: row.broadcast_at || null,
        editedAt: row.edited_at || null,
        deletedAt: row.deleted_at || null,
        reactions: reactionsObj,
        starredBy,
        isPinned,
        replyTo: replyToData,
        state: calculatedState
      };
    });
  }

  /**
   * PostgreSQL twin of enrichMessageRows: same output shape, sourced entirely
   * from PG tables (batched queries — never per-message round-trips).
   */
  private async pgEnrichMessageRows(rows: any[]): Promise<Message[]> {
    if (rows.length === 0) return [];
    const ids = rows.map(r => r.id);

    const [attRows, reactRows, readRows, starRows, pinRows, disabledUsersSet] = await Promise.all([
      pgQuery('SELECT id, message_id, name, size, mime_type, url, meta FROM attachments WHERE message_id = ANY($1)', [ids]),
      pgQuery('SELECT message_id, user_id, reaction_emoji FROM message_reactions WHERE message_id = ANY($1)', [ids]),
      pgQuery('SELECT message_id, user_id, status FROM message_reads WHERE message_id = ANY($1)', [ids]),
      pgQuery('SELECT message_id, user_id FROM message_stars WHERE message_id = ANY($1)', [ids]),
      pgQuery('SELECT chat_id, message_id FROM message_pins WHERE message_id = ANY($1)', [ids]),
      this.getUsersWithDisabledReadReceipts()
    ]);

    const replyIds = Array.from(new Set(rows.map(r => r.reply_to_id).filter(Boolean)));
    const parentRows = replyIds.length > 0
      ? (await pgQuery('SELECT id, sender_id, sender_name, content FROM messages WHERE id = ANY($1)', [replyIds])) || []
      : [];
    const senderIds = Array.from(new Set(rows.map(r => r.sender_id).filter(Boolean)));
    const senderRows = senderIds.length > 0
      ? (await pgQuery('SELECT id, username, display_name, avatar_url, online_status, last_seen FROM users WHERE id = ANY($1)', [senderIds])) || []
      : [];

    const parentMap = new Map(parentRows.map((p: any) => [p.id, p]));
    const senderMap = new Map(senderRows.map((s: any) => [s.id, s]));

    const reactionsByMsg = new Map<string, Map<string, string[]>>();
    for (const r of reactRows || []) {
      if (!reactionsByMsg.has(r.message_id)) reactionsByMsg.set(r.message_id, new Map());
      const emojiMap = reactionsByMsg.get(r.message_id)!;
      if (!emojiMap.has(r.reaction_emoji)) emojiMap.set(r.reaction_emoji, []);
      emojiMap.get(r.reaction_emoji)!.push(r.user_id);
    }

    const readsByMsg = new Map<string, Array<{ userId: string; status: string }>>();
    for (const r of readRows || []) {
      if (!readsByMsg.has(r.message_id)) readsByMsg.set(r.message_id, []);
      readsByMsg.get(r.message_id)!.push({ userId: r.user_id, status: r.status });
    }

    const starsByMsg = new Map<string, string[]>();
    for (const s of starRows || []) {
      if (!starsByMsg.has(s.message_id)) starsByMsg.set(s.message_id, []);
      starsByMsg.get(s.message_id)!.push(s.user_id);
    }

    const pinnedMsgIds = new Set((pinRows || []).map(p => p.message_id));

    const attachmentsByMsg = new Map<string, any[]>();
    for (const a of attRows || []) {
      if (!attachmentsByMsg.has(a.message_id)) attachmentsByMsg.set(a.message_id, []);
      attachmentsByMsg.get(a.message_id)!.push({
        id: a.id,
        name: a.name,
        size: a.size,
        mimeType: a.mime_type,
        url: (a.url || '').startsWith('data:') ? `/api/attachments/${a.id}` : a.url,
        meta: a.meta || undefined
      });
    }

    return rows.map(row => {
      const sender: any = senderMap.get(row.sender_id);

      const reactionsObj: Record<string, string[]> = {};
      const reactMap = reactionsByMsg.get(row.id);
      if (reactMap) {
        for (const [emoji, userIds] of reactMap.entries()) {
          reactionsObj[emoji] = userIds;
        }
      }

      const readList = readsByMsg.get(row.id) || [];
      let calculatedState = 'sent';
      if (row.deleted_at) {
        calculatedState = 'deleted';
      } else if (readList.length > 0) {
        const otherReads = readList.filter(r => r.userId !== row.sender_id);
        if (otherReads.length > 0) {
          if (disabledUsersSet.has(row.sender_id) || otherReads.some(r => r.status === 'read' && disabledUsersSet.has(r.userId))) {
            calculatedState = 'delivered';
          } else {
            const allRead = otherReads.every(r => r.status === 'read');
            const anyDelivered = otherReads.some(r => r.status === 'read' || r.status === 'delivered');
            calculatedState = allRead ? 'read' : (anyDelivered ? 'delivered' : 'sent');
          }
        }
      }

      // Reconstruct reply hierarchy
      let replyToData: any = null;
      const refReplyId = row.reply_to_id;
      if (refReplyId) {
        const parentMsg: any = parentMap.get(refReplyId);
        if (parentMsg) {
          const parentSender: any = senderMap.get(parentMsg.sender_id);
          replyToData = {
            id: parentMsg.id,
            senderId: parentMsg.sender_id,
            senderName: parentSender?.display_name || parentSender?.username || parentMsg.sender_name || 'مستخدم',
            content: parentMsg.content || ''
          };
        }
      }

      return {
        id: row.id,
        chatId: row.chat_id,
        senderId: row.sender_id,
        senderName: row.sender_name || sender?.display_name || sender?.username,
        sender: sender ? {
          id: sender.id,
          username: sender.username,
          displayName: sender.display_name,
          avatarUrl: sender.avatar_url,
          onlineStatus: sender.online_status,
          lastSeen: sender.last_seen ? new Date(sender.last_seen).toISOString() : undefined
        } : undefined,
        content: row.content,
        type: row.type,
        attachments: attachmentsByMsg.get(row.id) || [],
        poll: row.poll || null,
        deletedFor: Array.isArray(row.deleted_for) ? row.deleted_for : [],
        createdAt: row.created_at ? new Date(row.created_at).toISOString() : new Date().toISOString(),
        expiresAt: row.expires_at ? new Date(row.expires_at).toISOString() : null,
        scheduledAt: row.scheduled_at ? new Date(row.scheduled_at).toISOString() : null,
        broadcastAt: row.broadcast_at ? new Date(row.broadcast_at).toISOString() : null,
        editedAt: row.edited_at ? new Date(row.edited_at).toISOString() : null,
        deletedAt: row.deleted_at ? new Date(row.deleted_at).toISOString() : null,
        reactions: reactionsObj,
        starredBy: starsByMsg.get(row.id) || [],
        isPinned: pinnedMsgIds.has(row.id),
        replyTo: replyToData,
        state: calculatedState
      };
    });
  }

  public async getOptimizedChatsForUser(userId: string): Promise<any[]> {
    const userChats = await this.getChatsForUser(userId);
    const results: any[] = [];

    for (const c of userChats) {
      const members = await this.getChatUsers(c.id);
      const otherMember = c.type === 'one-to-one' ? members.find(m => m.id !== userId) : null;
      const msgs = await this.getMessagesForChat(c.id, 1);
      const lastMsg = msgs.length > 0 ? msgs[msgs.length - 1] : null;
      const unreadCount = await this.getUnreadCount(c.id, userId);

      results.push({
        id: c.id,
        type: c.type,
        name: c.name || otherMember?.displayName || 'مستخدم',
        avatarUrl: otherMember ? otherMember.avatarUrl : c.avatarUrl,
        createdAt: c.createdAt,
        updatedAt: c.updatedAt,
        memberIds: members.map(m => m.id),
        otherMember: otherMember ? {
          id: otherMember.id,
          displayName: otherMember.displayName,
          username: otherMember.username,
          avatarUrl: otherMember.avatarUrl,
          verified: otherMember.verified,
          onlineStatus: otherMember.onlineStatus,
          lastSeen: otherMember.lastSeen || null,
          bannerUrl: otherMember.bannerUrl,
          backgroundBannerUrl: otherMember.backgroundBannerUrl,
          bannerShadowOpacity: otherMember.bannerShadowOpacity,
          bgBannerShadowOpacity: otherMember.bgBannerShadowOpacity
        } : null,
        lastMessage: lastMsg ? {
          id: lastMsg.id,
          chatId: lastMsg.chatId,
          senderId: lastMsg.senderId,
          senderName: lastMsg.senderName,
          content: lastMsg.content,
          type: lastMsg.type,
          createdAt: lastMsg.createdAt,
          state: lastMsg.state,
          sender: lastMsg.sender
        } : null,
        unreadCount
      });
    }

    return results;
  }

  public async ensureBotChatForUser(_userId: string, _botId: string, _welcomeMessage: string): Promise<void> {
    // AI Bots removed completely
  }

  public async ensureGeminiBot(): Promise<void> {
    // AI Bots removed completely
  }

  // --- Moderation, Reports, & Administration ---

  public async getAdminsAndDevelopers(): Promise<User[]> {
    return Array.from(memoryStore.users.values())
      .filter(u => u.role === 'admin' || u.role === 'developer' || ['thedarkh95@gmail.com', 'mody12year@gmail.com', 'fff55555aa@gmail.com'].includes((u.email || '').toLowerCase()))
      .map(mapUserRow);
  }

  public async getModerationUsers(limit = 50, offset = 0, filter?: string): Promise<User[]> {
    let users = Array.from(memoryStore.users.values()).filter(u => !u.is_system_user);
    if (filter === 'banned') users = users.filter(u => u.is_banned);
    if (filter === 'muted') users = users.filter(u => u.muted_until && new Date(u.muted_until) > new Date());
    if (filter === 'admin') users = users.filter(u => u.role === 'admin' || u.role === 'developer');
    return users.slice(offset, offset + limit).map(mapUserRow);
  }

  public async getModerationUserStats(userId: string) {
    let msgCount = 0;
    for (const m of memoryStore.messages.values()) {
      if (m.sender_id === userId) msgCount++;
    }
    let chatCount = 0;
    for (const members of memoryStore.chatMembers.values()) {
      if (members.has(userId)) chatCount++;
    }
    return {
      messages: msgCount,
      chats: chatCount,
      reportsAgainst: 0,
      reportsBy: 0,
      warnings: (memoryStore.userWarnings.get(userId) || []).length
    };
  }

  public async banUser(userId: string, isBanned: boolean, bannedBy: string, reason: string, bannedUntil: Date | null = null) {
    const u = memoryStore.users.get(userId);
    if (u) {
      u.is_banned = isBanned;
      u.banned_at = isBanned ? new Date().toISOString() : null;
      u.banned_until = bannedUntil ? bannedUntil.toISOString() : null;
      u.banned_by = bannedBy;
      u.ban_reason = reason;
    }
    await pgQuery(
      'UPDATE users SET is_banned = $1, banned_at = $2, banned_until = $3, banned_by = $4, ban_reason = $5, updated_at = NOW() WHERE id = $6',
      [isBanned, isBanned ? new Date() : null, bannedUntil, bannedBy, reason, userId]
    );
    if (isBanned) {
      await this.revokeAllUserSessions(userId);
    }
    this.userCache.delete(userId);
  }

  public async muteUser(userId: string, mutedUntil: Date | null, mutedBy: string, reason: string) {
    const u = memoryStore.users.get(userId);
    if (u) {
      u.muted_until = mutedUntil ? mutedUntil.toISOString() : null;
      u.muted_at = mutedUntil ? new Date().toISOString() : null;
      u.muted_by = mutedBy;
      u.mute_reason = reason;
    }
    await pgQuery(
      'UPDATE users SET muted_until = $1, muted_at = $2, muted_by = $3, mute_reason = $4, updated_at = NOW() WHERE id = $5',
      [mutedUntil, new Date(), mutedBy, reason, userId]
    );
    this.userCache.delete(userId);
  }

  public async muteUserFromAi(userId: string, durationMinutes: number) {
    const mutedUntil = new Date(Date.now() + durationMinutes * 60 * 1000).toISOString();
    const u = memoryStore.users.get(userId);
    if (u) u.muted_from_ai_until = mutedUntil;
    await pgQuery('UPDATE users SET muted_from_ai_until = $1, updated_at = NOW() WHERE id = $2', [mutedUntil, userId]);
    this.userCache.delete(userId);
  }

  public async savePushSubscription(userId: string, subscription: any): Promise<void> {
    if (!subscription?.endpoint) return;
    memoryStore.pushSubscriptions.set(subscription.endpoint, { userId, subscription });
    await pgQuery(
      `INSERT INTO push_subscriptions (endpoint, user_id, subscription)
       VALUES ($1, $2, $3::jsonb)
       ON CONFLICT (endpoint) DO UPDATE SET user_id = EXCLUDED.user_id, subscription = EXCLUDED.subscription`,
      [subscription.endpoint, userId, JSON.stringify(subscription)]
    );
  }

  public async getPushSubscriptionsForUser(userId: string): Promise<any[]> {
    const rows = await pgQuery('SELECT subscription FROM push_subscriptions WHERE user_id = $1', [userId]);
    if (rows) {
      return rows.map(r => (typeof r.subscription === 'string' ? JSON.parse(r.subscription) : r.subscription));
    }
    const subs: any[] = [];
    for (const item of memoryStore.pushSubscriptions.values()) {
      if (item.userId === userId) subs.push(item.subscription);
    }
    return subs;
  }

  public async deletePushSubscription(endpoint: string): Promise<void> {
    memoryStore.pushSubscriptions.delete(endpoint);
    await pgQuery('DELETE FROM push_subscriptions WHERE endpoint = $1', [endpoint]);
  }

  public async createReport(report: any): Promise<any> {
    const id = report.reportId || ('rep-' + crypto.randomUUID());
    const r = {
      report_id: id,
      reporter_id: report.reporterId,
      target_user_id: report.targetUserId,
      target_message_id: report.targetMessageId || null,
      category: report.category,
      description: report.description || null,
      status: report.status || 'Pending',
      target_type: report.targetType || 'User',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    memoryStore.reports.set(id, r);
    await pgQuery(
      `INSERT INTO reports (report_id, reporter_id, target_user_id, target_message_id, category, description, status, target_type, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
       ON CONFLICT (report_id) DO NOTHING`,
      [r.report_id, r.reporter_id, r.target_user_id, r.target_message_id, r.category, r.description, r.status, r.target_type, r.created_at, r.updated_at]
    );
    return r;
  }

  public async getReports(limit = 50, offset = 0, category?: string, status?: string): Promise<any[]> {
    const conds: string[] = [];
    const params: any[] = [];
    if (category) { params.push(category); conds.push(`category = $${params.length}`); }
    if (status) { params.push(status); conds.push(`status = $${params.length}`); }
    const limitIdx = params.length + 1;
    params.push(limit);
    const offsetIdx = params.length + 1;
    params.push(offset);
    const rows = await pgQuery(
      `SELECT * FROM reports ${conds.length > 0 ? 'WHERE ' + conds.join(' AND ') : ''}
       ORDER BY created_at DESC LIMIT $${limitIdx} OFFSET $${offsetIdx}`,
      params
    );
    if (rows) {
      return rows.map(r => ({
        reportId: r.report_id,
        reporterId: r.reporter_id,
        targetUserId: r.target_user_id,
        targetMessageId: r.target_message_id,
        category: r.category,
        description: r.description,
        status: r.status,
        createdAt: r.created_at ? new Date(r.created_at).toISOString() : null,
        updatedAt: r.updated_at ? new Date(r.updated_at).toISOString() : null
      }));
    }
    let list = Array.from(memoryStore.reports.values());
    if (category) list = list.filter(r => r.category === category);
    if (status) list = list.filter(r => r.status === status);
    return list.slice(offset, offset + limit).map(r => ({
      reportId: r.report_id,
      reporterId: r.reporter_id,
      targetUserId: r.target_user_id,
      targetMessageId: r.target_message_id,
      category: r.category,
      description: r.description,
      status: r.status,
      createdAt: r.created_at,
      updatedAt: r.updated_at
    }));
  }

  public async logModerationAction(eventType: string, actorUserId: string | null, targetUserId: string | null, targetResource: string | null, metadata: any): Promise<void> {
    const id = crypto.randomUUID();
    memoryStore.moderationLogs.unshift({
      id,
      event_type: eventType,
      actor_user_id: actorUserId,
      target_user_id: targetUserId,
      target_resource: targetResource,
      metadata,
      created_at: new Date().toISOString()
    });
    await pgQuery(
      `INSERT INTO moderation_audit_logs (id, event_type, actor_user_id, target_user_id, target_resource, metadata)
       VALUES ($1, $2, $3, $4, $5, $6::jsonb)
       ON CONFLICT (id) DO NOTHING`,
      [id, eventType, actorUserId, targetUserId, targetResource, JSON.stringify(metadata || {})]
    );
  }

  public async getModerationLogs(limit = 100, offset = 0, eventType?: string): Promise<any[]> {
    const params: any[] = [];
    if (eventType) { params.push(eventType); }
    const limitIdx = params.length + 1;
    params.push(limit);
    const offsetIdx = params.length + 1;
    params.push(offset);
    const rows = await pgQuery(
      `SELECT * FROM moderation_audit_logs ${eventType ? 'WHERE event_type = $1' : ''}
       ORDER BY created_at DESC LIMIT $${limitIdx} OFFSET $${offsetIdx}`,
      params
    );
    if (rows) {
      return rows.map(r => ({
        id: r.id,
        action: r.event_type,
        moderatorId: r.actor_user_id,
        targetId: r.target_user_id,
        targetResource: r.target_resource,
        metadata: typeof r.metadata === 'string' ? JSON.parse(r.metadata) : r.metadata,
        createdAt: r.created_at ? new Date(r.created_at).toISOString() : null
      }));
    }
    let list = memoryStore.moderationLogs;
    if (eventType) list = list.filter(l => l.event_type === eventType);
    return list.slice(offset, offset + limit).map(r => ({
      id: r.id,
      action: r.event_type,
      moderatorId: r.actor_user_id,
      targetId: r.target_user_id,
      targetResource: r.target_resource,
      metadata: r.metadata,
      createdAt: r.created_at
    }));
  }

  public async searchUsers(query: string, limit = 10, offset = 0, currentUserId?: string): Promise<{ users: User[]; total: number }> {
    const term = query.toLowerCase().trim();
    let list = Array.from(memoryStore.users.values()).filter(u => !u.is_system_user);
    if (currentUserId) list = list.filter(u => u.id !== currentUserId);
    if (term) {
      list = list.filter(u =>
        (u.username || '').toLowerCase().includes(term) ||
        (u.display_name || '').toLowerCase().includes(term) ||
        (u.email || '').toLowerCase().includes(term)
      );
    }
    const sliced = list.slice(offset, offset + limit).map(mapUserRow);
    return { users: sliced, total: list.length };
  }

  public async getSessionById(sessionId: string): Promise<UserSession | undefined> {
    const s = memoryStore.userSessions.get(sessionId);
    if (s) return mapSessionRow(s);
    // BATCH-4 (DIR-AB-05): PG fallback — sessions minted on another instance
    // (or before a restart without a snapshot) must be resolvable for the
    // AUTH-03 live-revocation check to hold cross-instance. Fail-closed stays:
    // unknown sid still answers undefined → requireAuth treats as revoked.
    if (isPostgresHealthy && activePgPool) {
      try {
        const res = await activePgPool.query('SELECT * FROM user_sessions WHERE id = $1 LIMIT 1', [sessionId]);
        if (res.rows.length > 0) return mapSessionRow(res.rows[0]);
      } catch (err: any) {
        if (isPgConnectionClassError(err)) isPostgresHealthy = false;
        else console.warn('[Database] getSessionById PG fallback failed:', err.message);
      }
    }
    return undefined;
  }

  public async deleteUser(userId: string): Promise<void> {
    memoryStore.users.delete(userId);
    memoryStore.userProfiles.delete(userId);
    memoryStore.userSettings.delete(userId);
    for (const [sId, s] of memoryStore.userSessions.entries()) {
      if (s.user_id === userId) memoryStore.userSessions.delete(sId);
    }
    // PG: FK cascades clean sessions, settings, memberships, messages, receipts…
    await pgQuery('DELETE FROM users WHERE id = $1', [userId]);
    this.userCache.delete(userId);
  }

  public async mergeDuplicateUsers(): Promise<void> {
    // No-op for in-memory or already unified
  }

  // --- Staff Notes & Warnings ---

  public async getUserNotes(userId: string) {
    return memoryStore.staffNotes.get(userId) || [];
  }

  public async addUserNote(userId: string, authorId: string, content: string) {
    const id = 'note-' + crypto.randomUUID();
    const author = memoryStore.users.get(authorId);
    const note = {
      id,
      user_id: userId,
      author_id: authorId,
      content,
      created_at: new Date().toISOString(),
      author_name: author?.display_name || 'Staff',
      author_avatar: author?.avatar_url || ''
    };
    if (!memoryStore.staffNotes.has(userId)) memoryStore.staffNotes.set(userId, []);
    memoryStore.staffNotes.get(userId)!.unshift(note);
    return id;
  }

  public async deleteUserNote(noteId: string, authorId: string) {
    for (const [uId, notes] of memoryStore.staffNotes.entries()) {
      memoryStore.staffNotes.set(uId, notes.filter(n => !(n.id === noteId && n.author_id === authorId)));
    }
  }

  public async getUserWarnings(userId: string) {
    return memoryStore.userWarnings.get(userId) || [];
  }

  public async addWarning(userId: string, authorId: string, reason: string, severity: number = 1) {
    const id = 'warn-' + crypto.randomUUID();
    const author = memoryStore.users.get(authorId);
    const warn = {
      id,
      user_id: userId,
      author_id: authorId,
      reason,
      severity,
      seen: false,
      created_at: new Date().toISOString(),
      author_name: author?.display_name || 'Staff',
      author_avatar: author?.avatar_url || ''
    };
    if (!memoryStore.userWarnings.has(userId)) memoryStore.userWarnings.set(userId, []);
    memoryStore.userWarnings.get(userId)!.unshift(warn);
    return id;
  }

  public async warnUser(userId: string, authorId: string, reason: string, severity: number) {
    return this.addWarning(userId, authorId, reason, severity);
  }

  public async getUnseenWarnings(userId: string) {
    return (memoryStore.userWarnings.get(userId) || []).filter(w => !w.seen);
  }

  public async markWarningsSeen(userId: string) {
    const list = memoryStore.userWarnings.get(userId) || [];
    for (const w of list) w.seen = true;
  }

  public async clearWarnings(userId: string, moderatorId: string) {
    memoryStore.userWarnings.set(userId, []);
    await this.logModerationAction('WARNINGS_CLEARED', moderatorId, userId, 'All warnings cleared', {});
  }

  public async getEnforcementHistory(userId: string) {
    return memoryStore.moderationLogs.filter(l => l.target_user_id === userId);
  }

  // --- Reports & Moderation Extended ---

  public async getReportById(reportId: string): Promise<any | undefined> {
    const rows = await pgQuery(
      `SELECT r.*,
              ru.username AS reporter_username, ru.display_name AS reporter_name, ru.avatar_url AS reporter_avatar,
              tu.username AS target_username, tu.display_name AS target_user_name, tu.avatar_url AS target_avatar
       FROM reports r
       LEFT JOIN users ru ON ru.id = r.reporter_id
       LEFT JOIN users tu ON tu.id = r.target_user_id
       WHERE r.report_id = $1`,
      [reportId]
    );
    if (rows) {
      if (rows.length === 0) return undefined;
      const r = rows[0];
      return {
        reportId: r.report_id,
        reporterId: r.reporter_id,
        targetUserId: r.target_user_id,
        targetMessageId: r.target_message_id,
        category: r.category,
        description: r.description,
        status: r.status,
        createdAt: r.created_at ? new Date(r.created_at).toISOString() : null,
        updatedAt: r.updated_at ? new Date(r.updated_at).toISOString() : null,
        reporterUsername: r.reporter_username,
        reporterName: r.reporter_name,
        reporterAvatar: r.reporter_avatar,
        targetUsername: r.target_username,
        targetUserName: r.target_user_name,
        targetUserAvatar: r.target_avatar
      };
    }
    const r = memoryStore.reports.get(reportId);
    if (!r) return undefined;
    const rep = memoryStore.users.get(r.reporter_id);
    const tar = memoryStore.users.get(r.target_user_id);
    return {
      reportId: r.report_id,
      reporterId: r.reporter_id,
      targetUserId: r.target_user_id,
      targetMessageId: r.target_message_id,
      category: r.category,
      description: r.description,
      status: r.status,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
      reporterUsername: rep?.username,
      reporterName: rep?.display_name || rep?.username,
      reporterAvatar: rep?.avatar_url,
      targetUsername: tar?.username,
      targetUserName: tar?.display_name || tar?.username,
      targetUserAvatar: tar?.avatar_url
    };
  }

  public async getReportsForUser(targetUserId: string): Promise<any[]> {
    const rows = await pgQuery(
      'SELECT * FROM reports WHERE target_user_id = $1 ORDER BY created_at DESC',
      [targetUserId]
    );
    if (rows) {
      return rows.map(r => ({
        reportId: r.report_id,
        reporterId: r.reporter_id,
        targetUserId: r.target_user_id,
        targetMessageId: r.target_message_id,
        category: r.category,
        description: r.description,
        status: r.status,
        createdAt: r.created_at ? new Date(r.created_at).toISOString() : null,
        updatedAt: r.updated_at ? new Date(r.updated_at).toISOString() : null
      }));
    }
    return Array.from(memoryStore.reports.values())
      .filter(r => r.target_user_id === targetUserId)
      .map(r => ({
        reportId: r.report_id,
        reporterId: r.reporter_id,
        targetUserId: r.target_user_id,
        targetMessageId: r.target_message_id,
        category: r.category,
        description: r.description,
        status: r.status,
        createdAt: r.created_at,
        updatedAt: r.updated_at
      }));
  }

  public async updateReportStatus(reportId: string, status: string): Promise<boolean> {
    const r = memoryStore.reports.get(reportId);
    if (!r) return false;
    r.status = status;
    r.updated_at = new Date().toISOString();
    await pgQuery('UPDATE reports SET status = $1, updated_at = $2 WHERE report_id = $3', [status, r.updated_at, reportId]);
    return true;
  }

  public async getReporterRecentCount(reporterId: string, windowMinutes: number): Promise<number> {
    const cutoff = new Date(Date.now() - windowMinutes * 60 * 1000).toISOString();
    const rows = await pgQuery(
      'SELECT COUNT(*)::int AS count FROM reports WHERE reporter_id = $1 AND created_at >= $2',
      [reporterId, cutoff]
    );
    if (rows) return Number(rows[0]?.count) || 0;
    return Array.from(memoryStore.reports.values())
      .filter(r => r.reporter_id === reporterId && new Date(r.created_at).getTime() >= Date.now() - windowMinutes * 60 * 1000)
      .length;
  }

  // --- Deleted Messages Vault ---

  public async saveDeletedMessage(deletedMsg: any): Promise<void> {
    memoryStore.deletedMessagesVault.set(deletedMsg.messageId, {
      ...deletedMsg,
      deletedAt: new Date().toISOString()
    });
  }

  public async getDeletedMessage(messageId: string): Promise<any | undefined> {
    return memoryStore.deletedMessagesVault.get(messageId);
  }

  public async searchDeletedMessages(queryStr?: string, limit = 50): Promise<any[]> {
    let list = Array.from(memoryStore.deletedMessagesVault.values());
    if (queryStr) {
      const q = queryStr.toLowerCase();
      list = list.filter(m => (m.originalContent || '').toLowerCase().includes(q));
    }
    return list.slice(0, limit);
  }

  // --- Audit & History Logs ---

  public async logProfileChange(userId: string, fieldName: string, oldValue: string, newValue: string): Promise<void> {
    // Audit logged
  }

  public async logUsernameChange(userId: string, oldUsername: string, newUsername: string): Promise<void> {
    // Audit logged
  }

  public async searchUsersWithFuzzy(query: string, currentUserId: string, page = 1, limit = 15): Promise<any[]> {
    const res = await this.searchUsers(query, limit, (page - 1) * limit, currentUserId);
    return res.users;
  }

  public async getStarredMessagesForUser(userId: string): Promise<Message[]> {
    const rows = await pgQuery(
      `SELECT m.* FROM message_stars s JOIN messages m ON m.id = s.message_id
       WHERE s.user_id = $1 AND m.deleted_at IS NULL
       ORDER BY s.starred_at DESC`,
      [userId]
    );
    if (rows) return this.pgEnrichMessageRows(rows);
    const stars = memoryStore.messageStars.get(userId) || new Set();
    const msgs: any[] = [];
    for (const msgId of stars) {
      const m = memoryStore.messages.get(msgId);
      if (m && !m.deleted_at) msgs.push(m);
    }
    return this.enrichMessageRows(msgs);
  }

  /**
   * F11 (retention): the Deleted Messages Vault (moderation safety archive
   * written by saveDeletedMessage from the delete-for-everyone flow) is
   * purged of entries older than 30 days — the documented retention claim.
   * The vault lives in memoryStore.deletedMessagesVault (memory-only safety
   * archive, intentionally absent from PG). Each entry carries `deletedAt`
   * (set at save time); that timestamp is the retention anchor. Returns the
   * number of vault entries permanently deleted so the daily moderation job
   * can log the purge loudly.
   */
  public async cleanupExpiredDeletedMessages(): Promise<number> {
    const cutoff = Date.now() - DELETED_MSG_VAULT_RETENTION_DAYS * 24 * 60 * 60 * 1000;
    let deleted = 0;
    for (const [messageId, entry] of memoryStore.deletedMessagesVault.entries()) {
      const anchor = entry?.deletedAt || entry?.deleted_at || entry?.originalCreatedAt;
      const ts = anchor ? new Date(anchor).getTime() : NaN;
      if (Number.isFinite(ts) && ts < cutoff) {
        memoryStore.deletedMessagesVault.delete(messageId);
        deleted++;
      }
    }
    return deleted;
  }

  // ── Scheduled messages (v5) ────────────────────────────────────────────────

  /**
   * Delivery sweep helper: atomically claims due scheduled messages
   * (broadcast_at IS NULL, scheduled_at <= now, not deleted) by stamping
   * broadcast_at = NOW(), bumps the affected chats' updated_at, and returns
   * them fully enriched (same shape as getMessagesForChat). The caller
   * (moderation_jobs sweep) owns the msg:new fan-out. PG path claims via
   * UPDATE...RETURNING so two sweeps can never double-deliver; the memory
   * path mirrors the same semantics.
   */
  public async collectDueScheduledMessages(limit = 50): Promise<Message[]> {
    const lim = Math.max(1, Math.min(Number(limit) || 50, 200));
    if (isPostgresHealthy && activePgPool) {
      try {
        const res = await activePgPool.query(
          `UPDATE messages SET broadcast_at = NOW()
           WHERE id IN (
             SELECT id FROM messages
             WHERE broadcast_at IS NULL
               AND scheduled_at IS NOT NULL
               AND scheduled_at <= NOW()
               AND deleted_at IS NULL
             ORDER BY scheduled_at ASC
             LIMIT $1
           )
           RETURNING *`,
          [lim]
        );
        const rows = ((res.rows || []) as any[])
          .slice()
          .sort((a, b) => new Date(a.scheduled_at).getTime() - new Date(b.scheduled_at).getTime());
        const chatIds = Array.from(new Set(rows.map((r: any) => r.chat_id)));
        if (chatIds.length > 0) {
          await activePgPool.query('UPDATE chats SET updated_at = NOW() WHERE id = ANY($1)', [chatIds]);
        }
        return await this.pgEnrichMessageRows(rows);
      } catch (err: any) {
        console.warn('[Database] collectDueScheduledMessages PG sweep failed:', err.message);
        return [];
      }
    }

    // Memory fallback (PG outage)
    const now = Date.now();
    const due: any[] = [];
    for (const m of memoryStore.messages.values()) {
      if (!m.scheduled_at || m.broadcast_at) continue;
      if (m.deleted_at) continue;
      if (new Date(m.scheduled_at).getTime() > now) continue;
      m.broadcast_at = new Date().toISOString();
      const chat: any = memoryStore.chats.get(m.chat_id);
      if (chat) chat.updated_at = m.broadcast_at;
      due.push(m);
    }
    if (due.length > 0) persistMemoryStore();
    due.sort((a, b) => new Date(a.scheduled_at).getTime() - new Date(b.scheduled_at).getTime());
    return this.enrichMessageRows(due.slice(0, lim));
  }

  /**
   * BATCH-6 (ADV-03): UN-claim a scheduled message whose delivery gates failed
   * (sender banned/muted/left, or epoch moved). The sweep claims by setting
   * broadcast_at — a gated message is un-claimed so it stays due and can be
   * delivered later (e.g. a temporary ban lifting), never silently lost.
   */
  public async unmarkScheduledBroadcast(messageId: string): Promise<void> {
    const mem = memoryStore.messages.get(messageId);
    if (mem && mem.broadcast_at) {
      mem.broadcast_at = null;
      persistMemoryStore();
    }
    if (isPostgresHealthy && activePgPool) {
      try {
        await activePgPool.query('UPDATE messages SET broadcast_at = NULL WHERE id = $1', [messageId]);
      } catch (err: any) {
        if (isPgConnectionClassError(err)) isPostgresHealthy = false;
        else console.warn('[Database] unmarkScheduledBroadcast failed:', err.message);
      }
    }
  }

  // ── Retention pruning (batched, capped per sweep) ─────────────────────────

  /**
   * Retention: drop read receipts attached to messages older than 180 days.
   * Batched DELETE ... IN (SELECT ... LIMIT 5000) loop with a 20000-per-sweep
   * safety cap. Memory mode prunes the same predicate in-process.
   */
  public async pruneOldReadReceipts(maxPerSweep = 20000): Promise<number> {
    if (!(isPostgresHealthy && activePgPool)) {
      const cutoff = Date.now() - 180 * 24 * 60 * 60 * 1000;
      let removed = 0;
      for (const [msgId, reads] of memoryStore.messageReads.entries()) {
        const m: any = memoryStore.messages.get(msgId);
        if (m && new Date(m.created_at).getTime() < cutoff) {
          memoryStore.messageReads.delete(msgId);
          removed += reads.size;
        }
      }
      return removed;
    }
    let total = 0;
    const BATCH = 5000;
    try {
      while (total < maxPerSweep) {
        const res = await activePgPool.query(
          `DELETE FROM message_reads
           WHERE id IN (
             SELECT mr.id FROM message_reads mr
             JOIN messages m ON m.id = mr.message_id
             WHERE m.created_at < NOW() - INTERVAL '180 days'
             LIMIT $1
           )`,
          [BATCH]
        );
        const deleted = res.rowCount || 0;
        total += deleted;
        if (deleted < BATCH) break;
      }
    } catch (err: any) {
      console.warn('[Database] pruneOldReadReceipts failed:', err.message);
    }
    return total;
  }

  /**
   * Retention: drop moderation audit logs older than 365 days. Same batched
   * DELETE ... IN pattern with a 20000-per-sweep safety cap.
   */
  public async pruneOldAuditLogs(maxPerSweep = 20000): Promise<number> {
    if (!(isPostgresHealthy && activePgPool)) {
      const cutoff = Date.now() - 365 * 24 * 60 * 60 * 1000;
      const before = memoryStore.auditLogs.length;
      memoryStore.auditLogs = memoryStore.auditLogs.filter(
        l => new Date(l.timestamp || l.created_at || 0).getTime() >= cutoff
      );
      return Math.max(0, before - memoryStore.auditLogs.length);
    }
    let total = 0;
    const BATCH = 5000;
    try {
      while (total < maxPerSweep) {
        const res = await activePgPool.query(
          `DELETE FROM moderation_audit_logs
           WHERE id IN (
             SELECT id FROM moderation_audit_logs
             WHERE created_at < NOW() - INTERVAL '365 days'
             LIMIT $1
           )`,
          [BATCH]
        );
        const deleted = res.rowCount || 0;
        total += deleted;
        if (deleted < BATCH) break;
      }
    } catch (err: any) {
      console.warn('[Database] pruneOldAuditLogs failed:', err.message);
    }
    return total;
  }

  /**
   * F10 (retention): auth_logs entries older than 180 days are deleted —
   * the documented retention window for authentication audit records.
   * Batched DELETE ... IN with a 20000-per-sweep safety cap (same pattern as
   * pruneOldReadReceipts / pruneOldAuditLogs). The memory snapshot path
   * mirrors the same cutoff so dev / degraded-PG parity holds.
   */
  public async pruneOldAuthLogs(maxPerSweep = 20000): Promise<number> {
    if (!(isPostgresHealthy && activePgPool)) {
      const cutoff = Date.now() - AUTH_LOGS_RETENTION_DAYS * 24 * 60 * 60 * 1000;
      const before = memoryStore.auditLogs.length;
      memoryStore.auditLogs = memoryStore.auditLogs.filter(
        l => new Date(l.timestamp || l.created_at || 0).getTime() >= cutoff
      );
      return Math.max(0, before - memoryStore.auditLogs.length);
    }
    let total = 0;
    const BATCH = 5000;
    try {
      while (total < maxPerSweep) {
        const res = await activePgPool.query(
          `DELETE FROM auth_logs
           WHERE id IN (
             SELECT id FROM auth_logs
             WHERE created_at < NOW() - INTERVAL '${AUTH_LOGS_RETENTION_DAYS} days'
             LIMIT $1
           )`,
          [BATCH]
        );
        const deleted = res.rowCount || 0;
        total += deleted;
        if (deleted < BATCH) break;
      }
    } catch (err: any) {
      console.warn('[Database] pruneOldAuthLogs failed:', err.message);
    }
    return total;
  }

  // ── Message search (parameterized ILIKE — user input is NEVER interpolated) ──

  /** Escapes LIKE/ILIKE wildcards so %, _ and \ in the query match literally. */
  private escapeLikePattern(q: string): string {
    return q.replace(/[\\%_]/g, ch => '\\' + ch);
  }

  private normalizeSearchQuery(query: string): string {
    return String(query || '').trim().slice(0, 100);
  }

  /**
   * Full-text-ish substring search within ONE chat. Membership validation is
   * the caller's job (route checks getChatMembers before calling this).
   * Returns the same enriched shape as getMessagesForChat.
   */
  public async searchMessagesInChat(chatId: string, userId: string, query: string, limit = 30): Promise<SearchResult[]> {
    const limitNum = Math.max(1, Math.min(Number(limit) || 30, 100));
    const trimmed = this.normalizeSearchQuery(query);
    if (!trimmed) return [];
    const pattern = `%${this.escapeLikePattern(trimmed)}%`;

    const rows = await pgQuery(
      `SELECT * FROM messages
       WHERE chat_id = $1
         AND deleted_at IS NULL
         AND (broadcast_at IS NOT NULL OR scheduled_at IS NULL)
         AND NOT (deleted_for @> $2::jsonb)
         AND content ILIKE $3
       ORDER BY created_at DESC, id DESC
       LIMIT $4`,
      [chatId, JSON.stringify([userId]), pattern, limitNum]
    );
    if (rows) return this.pgEnrichMessageRows(rows);

    // Memory fallback (PG outage): same filters against the in-memory engine
    const members = memoryStore.chatMembers.get(chatId) || new Set();
    if (!members.has(userId)) return [];
    const lower = trimmed.toLowerCase();
    const hits: any[] = [];
    for (const m of memoryStore.messages.values()) {
      if (m.chat_id !== chatId || m.deleted_at) continue;
      if (m.scheduled_at && !m.broadcast_at) continue; // undelivered scheduled message — hidden until broadcast
      const df = Array.isArray(m.deleted_for) ? m.deleted_for : [];
      if (df.includes(userId)) continue;
      if (String(m.content || '').toLowerCase().includes(lower)) hits.push(m);
    }
    hits.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    return this.enrichMessageRows(hits.slice(0, limitNum));
  }

  /**
   * Global search across ALL chats the user is a member of (membership is
   * enforced in SQL via the chat_members JOIN). Each result carries chat info
   * (chatName resolved for one-to-one chats from the other member's profile).
   */
  public async searchMessagesGlobal(userId: string, query: string, limit = 40): Promise<SearchResult[]> {
    const limitNum = Math.max(1, Math.min(Number(limit) || 40, 100));
    const trimmed = this.normalizeSearchQuery(query);
    if (!trimmed) return [];
    const pattern = `%${this.escapeLikePattern(trimmed)}%`;

    const rows = await pgQuery(
      `SELECT m.*, c.type AS chat_type, c.name AS chat_name
       FROM messages m
       JOIN chat_members cm ON cm.chat_id = m.chat_id AND cm.user_id = $1
       JOIN chats c ON c.id = m.chat_id
       WHERE m.deleted_at IS NULL
         AND (m.broadcast_at IS NOT NULL OR m.scheduled_at IS NULL)
         AND NOT (m.deleted_for @> $2::jsonb)
         AND m.content ILIKE $3
       ORDER BY m.created_at DESC, m.id DESC
       LIMIT $4`,
      [userId, JSON.stringify([userId]), pattern, limitNum]
    );
    if (rows) {
      const enriched = await this.pgEnrichMessageRows(rows);
      // chats.name is empty for one-to-one rooms — resolve the other member's name
      const oneToOneIds = Array.from(new Set(rows.filter((r: any) => r.chat_type === 'one-to-one').map((r: any) => r.chat_id)));
      const otherNames = new Map<string, string>();
      if (oneToOneIds.length > 0) {
        const otherRows = await pgQuery(
          `SELECT cm.chat_id, u.display_name, u.username
           FROM chat_members cm
           JOIN users u ON u.id = cm.user_id
           WHERE cm.chat_id = ANY($1) AND cm.user_id <> $2`,
          [oneToOneIds, userId]
        );
        for (const r of otherRows || []) otherNames.set(r.chat_id, r.display_name || r.username || '');
      }
      return rows.map((row: any, i: number) => ({
        ...enriched[i],
        chatType: row.chat_type === 'group' ? 'group' : 'one-to-one',
        chatName: row.chat_type === 'group' ? (row.chat_name || '') : (otherNames.get(row.chat_id) || '')
      })) as SearchResult[];
    }

    // Memory fallback (PG outage)
    const lower = trimmed.toLowerCase();
    const hits: any[] = [];
    for (const m of memoryStore.messages.values()) {
      if (m.deleted_at) continue;
      if (m.scheduled_at && !m.broadcast_at) continue; // undelivered scheduled message — hidden until broadcast
      const df = Array.isArray(m.deleted_for) ? m.deleted_for : [];
      if (df.includes(userId)) continue;
      const members = memoryStore.chatMembers.get(m.chat_id);
      if (!members || !members.has(userId)) continue;
      if (String(m.content || '').toLowerCase().includes(lower)) hits.push(m);
    }
    hits.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    const sliced = hits.slice(0, limitNum);
    const enrichedMem = this.enrichMessageRows(sliced);
    return sliced.map((m: any, i: number) => {
      const chat: any = memoryStore.chats.get(m.chat_id);
      const chatType = chat?.type === 'group' ? 'group' : 'one-to-one';
      let chatName = chat?.name || '';
      if (chatType === 'one-to-one') {
        const members = memoryStore.chatMembers.get(m.chat_id) || new Set<string>();
        for (const uId of members) {
          if (uId === userId) continue;
          const u: any = memoryStore.users.get(uId);
          chatName = u?.display_name || u?.username || '';
          break;
        }
      }
      return { ...enrichedMem[i], chatType, chatName } as SearchResult;
    });
  }

  /**
   * Media gallery feed for one chat. type='image' → image/* attachments;
   * type='file' → everything else that is not image/video/audio or a synthetic
   * dirasha card (location/contact). Caller validates membership.
   */
  public async getChatMedia(chatId: string, userId: string, type: 'image' | 'file', limit = 200): Promise<MediaItem[]> {
    const limitNum = Math.max(1, Math.min(Number(limit) || 200, 500));
    const mimeClause = type === 'image'
      ? `a.mime_type LIKE 'image/%'`
      : `(a.mime_type NOT LIKE 'image/%'
          AND a.mime_type NOT LIKE 'video/%'
          AND a.mime_type NOT LIKE 'audio/%'
          AND a.mime_type NOT LIKE 'application/x-dirasha-%')`;

    const rows = await pgQuery(
      `SELECT a.id, a.message_id, a.url, a.mime_type, a.name, a.size, a.created_at,
              m.sender_id, m.sender_name
       FROM attachments a
       JOIN messages m ON m.id = a.message_id
       WHERE m.chat_id = $1
         AND m.deleted_at IS NULL
         AND (m.broadcast_at IS NOT NULL OR m.scheduled_at IS NULL)
         AND NOT (m.deleted_for @> $2::jsonb)
         AND a.url <> ''
         AND ${mimeClause}
       ORDER BY a.created_at DESC
       LIMIT $3`,
      [chatId, JSON.stringify([userId]), limitNum]
    );
    if (rows) {
      return rows.map((r: any) => ({
        id: r.id,
        messageId: r.message_id,
        url: (r.url || '').startsWith('data:') ? `/api/attachments/${r.id}` : r.url,
        mimeType: r.mime_type || 'application/octet-stream',
        name: r.name || 'attachment',
        size: Number(r.size) || 0,
        createdAt: r.created_at ? new Date(r.created_at).toISOString() : new Date().toISOString(),
        senderId: r.sender_id,
        senderName: r.sender_name || undefined
      }));
    }

    // Memory fallback (PG outage)
    const members = memoryStore.chatMembers.get(chatId) || new Set();
    if (!members.has(userId)) return [];
    const out: MediaItem[] = [];
    for (const a of memoryStore.attachments.values()) {
      const m: any = memoryStore.messages.get(a.message_id);
      if (!m || m.chat_id !== chatId || m.deleted_at) continue;
      if (m.scheduled_at && !m.broadcast_at) continue; // undelivered scheduled message — hidden until broadcast
      const df = Array.isArray(m.deleted_for) ? m.deleted_for : [];
      if (df.includes(userId)) continue;
      const mime = a.mime_type || '';
      if (type === 'image') {
        if (!mime.startsWith('image/')) continue;
      } else if (
        mime.startsWith('image/') || mime.startsWith('video/') ||
        mime.startsWith('audio/') || mime.startsWith('application/x-dirasha-')
      ) continue;
      if (!a.url) continue;
      out.push({
        id: a.id,
        messageId: a.message_id,
        url: (a.url || '').startsWith('data:') ? `/api/attachments/${a.id}` : a.url,
        mimeType: mime || 'application/octet-stream',
        name: a.name || 'attachment',
        size: Number(a.size) || 0,
        createdAt: a.created_at || new Date().toISOString(),
        senderId: m.sender_id,
        senderName: m.sender_name || undefined
      });
    }
    out.sort((x, y) => new Date(y.createdAt).getTime() - new Date(x.createdAt).getTime());
    return out.slice(0, limitNum);
  }

  /**
   * F10 (privacy — IP hygiene): IPs are truncated to the /24 (IPv4) or /64
   * (IPv6) network prefix AT STORAGE TIME. The full address never reaches the
   * auth_logs PG table nor memoryStore.auditLogs — not in the `ip` column and
   * not inside the metadata JSONB. Consumers are unaffected: the
   * security-alerts baseline (getAuthActionHistory → securityAlerts.ts)
   * compares truncated-vs-truncated, so new-login / failed-attempt
   * heuristics keep working unchanged. Unparseable input fails CLOSED
   * (stored as empty string) rather than persisting a full address.
   */
  private truncateIpForStorage(rawIp: unknown): string {
    const original = String(rawIp ?? '').trim();
    if (!original) return '';
    // Strip a zone index (fe80::1%eth0) and a bracketed IPv6 host form
    let ip = original.split('%')[0].trim();
    const bracketed = ip.match(/^\[(.+)\](:\d+)?$/);
    if (bracketed) ip = bracketed[1];

    // IPv4-mapped IPv6 (::ffff:192.0.2.1) is treated as plain IPv4
    const v4Mapped = ip.match(/^::ffff:(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})$/i);
    if (v4Mapped) ip = v4Mapped[1];

    // IPv4 (optionally with a trailing :port from mis-stripped proxies)
    const v4 = ip.match(/^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})(?::\d+)?$/);
    if (v4) {
      const octets = v4[1].split('.');
      return `${octets[0]}.${octets[1]}.${octets[2]}.0`; // /24 network prefix
    }

    // IPv6 → /64: keep the first 4 hextets, zero the interface ID
    if (ip.includes(':')) {
      const halves = ip.toLowerCase().split('::');
      if (halves.length > 2) return ''; // multiple '::' — malformed, fail closed
      const left = halves[0] ? halves[0].split(':') : [];
      const right = halves.length === 2 && halves[1] ? halves[1].split(':') : [];
      const middle = Array(Math.max(0, 8 - left.length - right.length)).fill('0');
      const hextets = [...left, ...middle, ...right];
      if (hextets.length < 4) return ''; // malformed / too short — fail closed
      return `${hextets.slice(0, 4).join(':')}::`; // /64 network prefix
    }

    return ''; // not a recognizable IP — never persist the raw string
  }

  public async logAuthAction(userId: string, action: string, metadata: any): Promise<void> {
    const storedMeta = (metadata && typeof metadata === 'object') ? { ...metadata } : {};
    // F10: truncate BEFORE anything is persisted (memory snapshot + PG).
    storedMeta.ip = this.truncateIpForStorage(storedMeta.ip);
    if (storedMeta.ipAddress !== undefined) storedMeta.ipAddress = this.truncateIpForStorage(storedMeta.ipAddress);

    memoryStore.auditLogs.unshift({
      id: 'log-' + crypto.randomUUID(),
      userId,
      action,
      metadata: storedMeta,
      timestamp: new Date().toISOString()
    });

    // Durable PG parity (best-effort, fire-and-forget): auth_logs backs the
    // security-alerts engine (getAuthActionHistory IP baseline) across
    // restarts. Only the truncated ip/user_agent scalars + sanitized metadata
    // reach the table — tokens/passwords never flow through logAuthAction
    // callers, and full IPs never reach the DB (F10).
    try {
      queuePg(
        `INSERT INTO auth_logs (id, user_id, action, ip, user_agent, metadata) VALUES ($1, $2, $3, $4, $5, $6)`,
        [
          'log-' + crypto.randomUUID(),
          userId,
          String(action).slice(0, 64),
          String(storedMeta.ip || '').slice(0, 64),
          String(storedMeta.userAgent || '').slice(0, 256),
          JSON.stringify(storedMeta)
        ]
      );
    } catch { /* audit PG write is best-effort */ }
  }

  /**
   * Recent auth-log records for one action (newest first). PG (auth_logs)
   * first; memoryStore.auditLogs fallback keeps dev + degraded-PG parity.
   * Security-alerts engine uses this as the successful-login IP baseline.
   */
  public async getAuthActionHistory(userId: string, action: string, limit: number = 20): Promise<Array<{
    id: string; userId: string; action: string; ip: string; userAgent: string; metadata: any; createdAt: string;
  }>> {
    const capped = Math.max(1, Math.min(200, limit));
    const rows = await pgQuery(
      `SELECT id, user_id, action, ip, user_agent, metadata, created_at
       FROM auth_logs WHERE user_id = $1 AND action = $2
       ORDER BY created_at DESC LIMIT $3`,
      [userId, action, capped]
    );
    if (rows && rows.length > 0) {
      return rows.map((r: any) => ({
        id: r.id,
        userId: r.user_id,
        action: r.action,
        ip: String(r.ip || r.metadata?.ip || ''),
        userAgent: String(r.user_agent || r.metadata?.userAgent || ''),
        metadata: r.metadata || {},
        createdAt: r.created_at ? new Date(r.created_at).toISOString() : new Date().toISOString()
      }));
    }
    // Memory parity: in-memory audit entries carry the ip inside metadata
    return memoryStore.auditLogs
      .filter((l: any) => l.userId === userId && l.action === action)
      .slice(0, capped)
      .map((l: any) => ({
        id: l.id,
        userId: l.userId,
        action: l.action,
        ip: String(l.metadata?.ip || ''),
        userAgent: String(l.metadata?.userAgent || ''),
        metadata: l.metadata || {},
        createdAt: l.timestamp || new Date().toISOString()
      }));
  }

  /** Most recent record for one auth action (or null when there is none). */
  public async getLastAuthAction(userId: string, action: string): Promise<{
    id: string; userId: string; action: string; ip: string; userAgent: string; metadata: any; createdAt: string;
  } | null> {
    const history = await this.getAuthActionHistory(userId, action, 1);
    return history[0] || null;
  }

  /**
   * Data-export helper (GET /api/users/me/export): ALL auth actions for ONE
   * user (getAuthActionHistory filters by a single action; the export needs
   * the full audit trail), newest first, hard-capped. IPs are returned
   * exactly as stored (already truncated at write time — F10).
   */
  public async getExportAuthLogs(userId: string, limit: number = 500): Promise<Array<{
    action: string; ip: string; userAgent: string; metadata: any; createdAt: string;
  }>> {
    const capped = Math.max(1, Math.min(1000, limit));
    const rows = await pgQuery(
      `SELECT action, ip, user_agent, metadata, created_at
       FROM auth_logs WHERE user_id = $1
       ORDER BY created_at DESC LIMIT $2`,
      [userId, capped]
    );
    if (rows) {
      return rows.map((r: any) => ({
        action: String(r.action || ''),
        ip: String(r.ip || r.metadata?.ip || ''),
        userAgent: String(r.user_agent || r.metadata?.userAgent || ''),
        metadata: r.metadata || {},
        createdAt: r.created_at ? new Date(r.created_at).toISOString() : new Date().toISOString()
      }));
    }
    // Memory parity: audit entries carry the ip inside metadata
    return memoryStore.auditLogs
      .filter((l: any) => l.userId === userId)
      .slice(0, capped)
      .map((l: any) => ({
        action: String(l.action || ''),
        ip: String(l.metadata?.ip || ''),
        userAgent: String(l.metadata?.userAgent || ''),
        metadata: l.metadata || {},
        createdAt: l.timestamp || new Date().toISOString()
      }));
  }

  /**
   * Data-export helper: the user's OWN E2EE PUBLIC key material only — legacy
   * (v7) registration plus every linked device (v8). The server never stores
   * private keys, but this projection pins EXACTLY which columns may leave
   * the database (identity DH pub, identity signing pub, signed prekey pub,
   * its signature, optional PQ prekey pub + signature — all public by
   * design). Memory mode has no e2ee tables → [].
   */
  /**
   * DIR-NEW-01 (second independent review): E2EE device count with a TRI-STATE
   * contract. Memory mode (no PG): registrations are PG-only — 0 is the true
   * count. PG configured: a query failure THROWS ("cannot verify") instead of
   * masquerading as "not registered" — the ingress policy must never treat
   * a DB failure as eligibility-negating.
   */
  public async getE2eeDeviceCount(userId: string): Promise<number> {
    if (!isPostgresHealthy || !activePgPool) return 0;
    const rows = await pgQuery(
      'SELECT (SELECT COUNT(*)::int FROM e2ee_registrations WHERE user_id = $1) + (SELECT COUNT(*)::int FROM e2ee_device_registrations WHERE user_id = $1) AS count',
      [userId],
    );
    if (!rows) throw new Error('E2EE_DEVICE_COUNT_DB_UNAVAILABLE');
    return Number(rows[0]?.count ?? 0);
  }

  public async getExportE2eePublicKeys(userId: string): Promise<Array<{
    deviceId: string; identityDhPub: string; identitySigPub: string; signedPrekeyPub: string | null;
    prekeySignature: string; pqPrekeyPub: string | null; pqPrekeySignature: string | null; registeredAt: string;
  }>> {
    const rows = await pgQuery(
      `SELECT 'default' AS "deviceId",
              identity_dh_pub AS "identityDhPub",
              identity_sig_pub AS "identitySigPub",
              signed_prekey_pub AS "signedPrekeyPub",
              prekey_signature AS "prekeySignature",
              NULL AS "pqPrekeyPub",
              NULL AS "pqPrekeySignature",
              registered_at AS "registeredAt"
       FROM e2ee_registrations WHERE user_id = $1
       UNION ALL
       SELECT device_id,
              identity_dh_pub,
              identity_sig_pub,
              signed_prekey_pub,
              prekey_signature,
              pq_prekey_pub,
              pq_prekey_signature,
              registered_at
       FROM e2ee_device_registrations WHERE user_id = $1`,
      [userId]
    );
    if (!rows) return [];
    return rows.map((r: any) => ({
      deviceId: String(r.deviceId || 'default'),
      identityDhPub: String(r.identityDhPub || ''),
      identitySigPub: String(r.identitySigPub || ''),
      signedPrekeyPub: r.signedPrekeyPub || null,
      prekeySignature: String(r.prekeySignature || ''),
      pqPrekeyPub: r.pqPrekeyPub || null,
      pqPrekeySignature: r.pqPrekeySignature || null,
      registeredAt: r.registeredAt ? new Date(r.registeredAt).toISOString() : new Date().toISOString()
    }));
  }
}

export const db = new RelationalDatabase();
export default db;
