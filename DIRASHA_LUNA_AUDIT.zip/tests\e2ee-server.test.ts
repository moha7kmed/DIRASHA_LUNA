/**
 * E2EE server-side key-directory validation tests.
 * Covers the pure validators exported from src/server/routes/e2ee.ts
 * (the route handlers themselves are E2E-tested live against PG).
 * Run: npm test
 */
import { describe, it, expect } from 'vitest';
import {
  isValidBase64, b64DecodedLength,
  isValidX25519Pub, isValidEd25519Signature,
  isValidKeyId, isValidUserId, isValidDeviceId, parseOpkBatch,
  MAX_DEVICES_PER_USER,
} from '../src/server/routes/e2ee.ts';

const B64_32B = Buffer.alloc(32, 7).toString('base64');   // valid X25519 pub shape
const B64_64B = Buffer.alloc(64, 11).toString('base64');  // valid Ed25519 sig shape
const B64_31B = Buffer.alloc(31, 3).toString('base64');   // wrong pub length

describe('e2ee base64 validation', () => {
  it('accepts standard padded base64 and reports decoded length', () => {
    expect(isValidBase64(B64_32B)).toBe(true);
    expect(b64DecodedLength(B64_32B)).toBe(32);
    expect(b64DecodedLength(B64_64B)).toBe(64);
  });

  it('rejects URL-safe alphabet, whitespace, empty and non-strings', () => {
    expect(isValidBase64('a-b_c')).toBe(false);      // URL-safe chars
    expect(isValidBase64('AB CD')).toBe(false);      // whitespace
    expect(isValidBase64('')).toBe(false);
    expect(isValidBase64(123)).toBe(false);
    expect(isValidBase64(null)).toBe(false);
  });

  it('rejects malformed padding', () => {
    expect(isValidBase64('A===')).toBe(false);
    expect(isValidBase64('ABCDE')).toBe(false);      // length not multiple of 4 (no valid padding group)
    expect(isValidBase64('A=')).toBe(false);
  });
});

describe('e2ee key-shape validation', () => {
  it('X25519 pubs must decode to exactly 32 bytes', () => {
    expect(isValidX25519Pub(B64_32B)).toBe(true);
    expect(isValidX25519Pub(B64_31B)).toBe(false);
    expect(isValidX25519Pub(B64_64B)).toBe(false);
    expect(isValidX25519Pub('not base64!')).toBe(false);
  });

  it('Ed25519 signatures must decode to exactly 64 bytes', () => {
    expect(isValidEd25519Signature(B64_64B)).toBe(true);
    expect(isValidEd25519Signature(B64_32B)).toBe(false);
  });
});

describe('e2ee id validation', () => {
  it('key ids are integers in [0, 2^31-1]', () => {
    expect(isValidKeyId(0)).toBe(true);
    expect(isValidKeyId(2147483647)).toBe(true);
    expect(isValidKeyId(-1)).toBe(false);
    expect(isValidKeyId(2147483648)).toBe(false);
    expect(isValidKeyId(1.5)).toBe(false);
    expect(isValidKeyId('1')).toBe(false);
  });

  it('user ids are 1-128 url-safe chars', () => {
    expect(isValidUserId('u-123_ABC')).toBe(true);
    expect(isValidUserId('')).toBe(false);
    expect(isValidUserId('a'.repeat(129))).toBe(false);
    expect(isValidUserId('bad id')).toBe(false);
  });

  it('device ids are 1-64 url-safe chars', () => {
    expect(isValidDeviceId('dev-1_ABC')).toBe(true);
    expect(isValidDeviceId('a'.repeat(64))).toBe(true);
    expect(isValidDeviceId('')).toBe(false);
    expect(isValidDeviceId('a'.repeat(65))).toBe(false);
    expect(isValidDeviceId('bad id')).toBe(false);
    expect(isValidDeviceId('bad/slash')).toBe(false);
    expect(isValidDeviceId(123)).toBe(false);
    expect(isValidDeviceId(null)).toBe(false);
  });

  it('device cap matches the Signal-style fleet limit (6 — transport ceiling bounds fan-out)', () => {
    expect(MAX_DEVICES_PER_USER).toBe(6);
  });
});

describe('e2ee OPK batch validation', () => {
  it('accepts a well-formed batch', () => {
    const batch = [{ id: 1, pub: B64_32B }, { id: 2, pub: B64_32B }];
    const res = parseOpkBatch(batch);
    expect(res.ok).toBe(true);
    if (res.ok === true) expect(res.batch).toEqual([{ keyId: 1, pub: B64_32B }, { keyId: 2, pub: B64_32B }]);
  });

  it('rejects batches over 200 entries', () => {
    const big = Array.from({ length: 201 }, (_, i) => ({ id: i, pub: B64_32B }));
    expect(parseOpkBatch(big).ok).toBe(false);
  });

  it('rejects duplicate ids, bad ids and bad pubs', () => {
    expect(parseOpkBatch([{ id: 5, pub: B64_32B }, { id: 5, pub: B64_32B }]).ok).toBe(false);
    expect(parseOpkBatch([{ id: -1, pub: B64_32B }]).ok).toBe(false);
    expect(parseOpkBatch([{ id: 1, pub: B64_31B }]).ok).toBe(false);
    expect(parseOpkBatch('nope').ok).toBe(false);
    expect(parseOpkBatch([null]).ok).toBe(false);
  });
});
