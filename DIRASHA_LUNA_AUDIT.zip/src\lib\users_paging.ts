/**
 * Pages through /api/users (server caps at 100/page) until exhausted.
 * Bounded at 20 pages (2000 users) as a safety stop.
 */
export async function fetchAllUsersPaginated(accessToken: string): Promise<any[]> {
  const all: any[] = [];
  const PAGE = 100;
  for (let offset = 0; offset < 2000; offset += PAGE) {
    const res = await fetch(`/api/users?limit=${PAGE}&offset=${offset}`, {
      headers: { Authorization: `Bearer ${accessToken}` },
    });
    if (!res.ok) break;
    const data = await res.json();
    const page = data.users || [];
    all.push(...page);
    if (page.length < PAGE) break; // exhausted
  }
  return all;
}
