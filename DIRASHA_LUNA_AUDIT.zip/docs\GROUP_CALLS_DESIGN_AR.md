# التصميم التقني: المكالمات الجماعية (Mesh) حتى 4 مشاركين

> حالة الوثيقة: v1 — Mesh عبر WebRTC مباشر، بدون SFU، بدون تسجيل.
> الملفات المرتبطة:
> - `src/server/groupCallSessions.ts` — سجل الجلسات في الذاكرة (الخادم)
> - `src/server/routes/groupCallRoutes.ts` — مسارات REST تحت `/api/group-calls`
> - `src/lib/groupCallMesh.ts` — مدير الشبكة الشبكية (Mesh) على العميل

---

## 1. لماذا Mesh (الشبكة الكاملة) ولماذا الحد 4 مشاركين؟

في معمارية Mesh يُنشئ كل مشارك اتصال WebRTC مباشر مع كل مشارك آخر، أي
**N-1 اتصالاً لكل مشارك** و **N×(N-1)/2 اتصالاً إجمالاً** داخل المجموعة:

| المشاركون | اتصالات لكل مشارك | إجمالي الاتصالات | مشاكل |
|-----------|-------------------|-------------------|--------|
| 2 | 1 | 1 | الوضع الحالي (1:1) |
| 3 | 2 | 3 | ممتاز — يُنصح به |
| 4 | 3 | 6 | الحد الأقصى المقبول |
| 5 | 4 | 10 | رفع الفيديو ×4 من كل عميل |
| 6 | 5 | 15 | انفجار استهلاك النطاق |

**سبب تحديد السقف بـ 4:** كل مشارك يرفع نسخة من الفيديو/الصوت لكل نظير.
مع 4 مشاركين يرفع كل عميل 3 نسخ (≈3× معدل الرفع الفردي)، ومع 6 مشاركين
يصل إلى 5 نسخ — وهو ما يُعرف بـ"انفجار النطاق" (Bandwidth Blowup)، إضافة
إلى استهلاك المعالج في الترميز (Encoding) المتعدد على أجهزة ضعيفة.

**عند تجاوز 4 مشاركين (مستقبلياً):** الحل القياسي هو **SFU**
(Selective Forwarding Unit) — يرفع كل مشارك نسخة واحدة فقط إلى الخادم،
والخادم يعيد توجيهها. للاطلاع على المنهجية والمقايضات:
- مقالة Signal: *How Signal is scaling group calling*
  (https://signal.org/blog/how-to-scale-group-calls/) — تشرح انتقال
  Signal إلى SFU بعد أن أصبح Mesh غير عملي للمجموعات الكبيرة.

**قرار v1:** بقاء Mesh لحد 4، مع تمهيد الواجهة (`groupCallId` مستقل عن
البنية) بحيث يمكن استبدال طبقة النقل بـ SFU لاحقاً دون تغيير مسارات REST.

---

## 2. مخطط الإشارة (Signaling Flow) — ASCII

الإشارة الحية (Offer / Answer / ICE) تمشي عبر **مُرحِّل `call:signal`
الموجود** في `src/server/websocket/ws_server.ts` → `handleCallSignal`
الذي يعيد توجيه الحمولة إلى قناة المستخدم `user:updates:<userId>`.
الخادم **لا يحلل** حمولة الإشارة — هو مُرحِّل شفاف فقط.

```
 العميل A (أصغر id = impolite)          الخادم WS            العميل B          العميل C
 ─────────────────────────────         ─────────────        ─────────         ─────────
 1) POST /api/group-calls
    {chatId} ────────────────────────► إنشاء جلسة gcall-…
    ◄──────── 201 {groupCallId}
 2) B و C يستدعيان:
    POST /api/group-calls/:id/join ──► فحص العضوية + السعة
    ◄──── roster: [A,B,C]
 3) getUserMedia() محلياً عند الجميع
 4) A (impolite مع B و C) ينشئ PC لكل نظير ويرسل Offer:
    ws: call:signal {callId: gcall-…,
                     receiverId: B,
                     signal: offer} ──► relay ──────────────► B
    ws: call:signal {receiverId: C,…} ─► relay ────────────────────────────────► C
 5) B ينشئ Answer:
    ws: call:signal {receiverId: A,
                     signal: answer} ◄── relay ◄──────────── B
 6) تبادل ICE candidates (داخل call:signal أيضاً):
    A ⇄ B ⇄ C عبر المُرحِّل حتى تكتمل الاتصالات P2P
 7) المغادرة: POST /api/group-calls/:id/leave
    + ws: call:end {callId: gcall-…, receiverId: <كل نظير>}
    آخر مغادر يحذف الجلسة تلقائياً (فحص السعة/التدمير الذاتي)
```

**قاعدة polite/impolite (بدون Perfect Negotiation في v1):** في كل زوج،
الصاحب المعرف الأصغر معجمياً (userId الأصغر) هو الطرف `impolite` الذي
ينشئ الـ Offer، والطرف الآخر `polite` ينتظر ويجيب فقط — هذا يمنع تضارب
العروض (Offer Glare) دون الحاجة لآلية التراجع (Rollback).

---

## 3. كيف تمشي الإشارة عبر مُرحِّل call:signal الحالي؟

لا تعديلات مطلوبة على `ws_server.ts`. حمولة الرسالة على السلك:

```json
{
  "event": "call:signal",
  "payload": {
    "callId": "gcall-<uuid>",
    "receiverId": "<userId للنظير>",
    "signal": {
      "kind": "offer | answer | candidate",
      "description": { "type": "offer", "sdp": "…" },
      "candidate": { "candidate": "…", "sdpMid": "0", "sdpMLineIndex": 0 }
    }
  }
}
```

- `callId` يحمل معرف المكالمة الجماعية `gcall-…` — المُرحِّل لا يتحقق من
  صيغته، و`activeCalls` الخاص بالمكالمات الثنائية لن يتأثر لأن
  `handleCallSignal` ينشر فقط بدون تسجيل حالة.
- `receiverId` يحدد النظير الواحد — لكل مشارك 3 رسائل ICE/Offer/Answer
  كحد أقصى لكل نظير في مجموعة من 4.
- ملاحظة حدود السرعة (Rate Limit): الحد الحالي لـ `call:signal` هو
  **60 رسالة / 10 ثوانٍ** لكل مستخدم. في مجموعة من 4 مع تجميع الـ ICE
  (Trickle) قد نقترب من الحد؛ يُنصح في مرحلة الدمج بمراقبة هذا الحد،
  وإن لزم رفعه قليلاً أو تجميع المرشحين (ICE Batching) في رسالة واحدة.
  (قرار الرفع يعود للمنسق لأنه يقع في `ws_server.ts`).

---

## 4. مسارات REST الجديدة

| المسار | الوظيفة | الفحوصات |
|--------|---------|----------|
| `POST /api/group-calls` | إنشاء جلسة `{chatId}` | عضوية المتصل في الدردشة |
| `POST /api/group-calls/:id/join` | الانضمام وإرجاع قائمة المشاركين | العضوية + السعة (4) |
| `POST /api/group-calls/:id/leave` | المغادرة (idempotent) | — |
| `GET /api/group-calls?chatId=` | الجلسات النشطة للدردشة | عضوية المتصل |

المصادقة عبر دالة `requireAuth` المحقونة بنمط `register` (كما في
`src/server/routes/storage.ts`) — لا تعديل على `server.ts` سوى سطر التركيب.

---

## 5. خطوات الدمج (للمنسق — مرحلة لاحقة)

1. **`server.ts`** — تركيب المسارات بعد تعريف `requireAuth`:
   ```ts
   import { registerGroupCallRoutes } from './src/server/routes/groupCallRoutes.ts';
   registerGroupCallRoutes(app, { requireAuth });
   ```
2. **`App.tsx` / `socket_client.ts`** — الاستماع لحدث `call:signal`
   القادم من WS: إذا كان `payload.callId` يبدأ بـ `gcall-` مرِّر الحمولة
   إلى `mesh.handleSignal(payload.senderId, payload.signal)` بدل مسار
   المكالمة الثنائية الحالي.
3. **بدء مكالمة جماعية** (زر في واجهة الدردشة الجماعية):
   - `POST /api/group-calls {chatId}` → ثم `POST …/:id/join`
   - إنشاء `GroupCallMesh` واستدعاء `join({groupCallId, myId,
     participants, getUserMediaStream, sendSignal, callbacks})`
   - `sendSignal` = `ws.send({event:'call:signal', payload:{callId:
     groupCallId, receiverId: toUserId, signal}})`.
4. **إشعار الآخرين** — بث راديو عبر قناة الدردشة (chat message من نوع
   `call` أو حدث presence) يخبر أعضاء الدردشة بوجود `groupCallId` نشط
   ليضغطوا "انضمام"، ثم يفحصون `GET /api/group-calls?chatId=`.
5. **واجهة `CallInterface.tsx`** — شبكة حتى 4 بطاقات فيديو: كل `onTrack`
   يربط `MediaStream` بعنصر `<video>` مرتبط بمعرف النظير، و`onParticipantLeft`
   يزيل البطاقة ويُظهر إشعار "غادر المكالمة".
6. **الخروج/الإغلاق** — عند مغادرة أي طرف: `mesh.leave()` +
   `POST …/:id/leave` + بث `call:end` بمعرف `gcall-…` لكل النظراء
   (الطرف المستقبل يستدعي `mesh.handlePeerLeft(senderId)`).

---

## 6. القيود الحالية (v1) — غير مدعوم عمداً

- **لا تسجيل (Recording)** — لا يوجد مسار لحفظ الوسائط على الخادم؛
  الخادم أصلاً لا يلمس الوسائط (P2P).
- **لا SFU** — السقف 4 مشاركين صارم؛ الخادم يرفض الانضمام بـ `409 FULL`.
- **لا Perfect Negotiation / Rollback** — لا إعادة تفاوض (Renegotiation)
  بعد الاتصال: إضافة/إزالة مسار أثناء المكالمة (كإيقاف الفيديو بالكامل)
  غير مضمونة؛ كتم الصوت/الفيديو (`track.enabled`) مدعوم لأنه لا يغيّر SDP.
- **جلسات في الذاكرة فقط** — إعادة تشغيل الخادم تُسقط الجلسات (مثل
  `activeCalls` الثنائية الحالية).
- **لا تشفير خادم إضافي** — DTLS/SRTP بين الأطراف كما في 1:1؛ الخادم
  يرى حزم الإشارة فقط (SDP/ICE) لا الوسائط.
