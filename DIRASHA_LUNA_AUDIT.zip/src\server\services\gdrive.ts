/**
 * Google Drive per-user storage layer ("movie-site streaming pattern")
 * ---------------------------------------------------------------------
 * Each user links their OWN Google account (drive.file scope — Dirasha can
 * only see the files IT created, never the user's whole Drive). Uploads go
 * browser → Google directly; playback uses
 * https://drive.usercontent.google.com/download?id=..&export=download&confirm=t
 * which serves bytes with HTTP Range support — exactly what <video> needs.
 *
 * Everything here is dependency-free: hand-rolled OAuth2 + Drive REST v3 via
 * fetch with bounded timeouts. Tokens are AES-256-GCM encrypted at rest via
 * encryptCredentials/decryptCredentials (services/storage.ts).
 *
 * NOTE on the encrypted payload shape: decryptCredentials validates the legacy
 * {accessKeyId, secretAccessKey} fields, so the refresh token is stored in the
 * accessKeyId slot and the secretAccessKey slot carries the marker
 * 'gdrive-refresh' (never a real secret). This keeps the existing crypto
 * helper untouched and backward compatible.
 */

import crypto from 'crypto';
import { logger } from '../logger.ts';
import { pool } from '../database.ts';
import { encryptCredentials, decryptCredentials } from './storage.ts';

/* ===================== Configuration (env, may be unset) ===================== */

const GDRIVE_CLIENT_ID = process.env.GDRIVE_CLIENT_ID || '';
const GDRIVE_CLIENT_SECRET = process.env.GDRIVE_CLIENT_SECRET || '';

export const GDRIVE_NOT_CONFIGURED = {
  error: 'GDRIVE_NOT_CONFIGURED',
  message: 'ربط Google غير مهيأ بعد — تواصل مع مدير التطبيق.',
} as const;

export function isGdriveConfigured(): boolean {
  return !!(GDRIVE_CLIENT_ID && GDRIVE_CLIENT_SECRET);
}

const OAUTH_AUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth';
const OAUTH_TOKEN_URL = 'https://oauth2.googleapis.com/token';
const DRIVE_API_BASE = 'https://www.googleapis.com/drive/v3';
const DRIVE_UPLOAD_BASE = 'https://www.googleapis.com/upload/drive/v3';
/** drive.file = per-file access only. Plus openid for identity. */
const GDRIVE_SCOPE = 'https://www.googleapis.com/auth/drive.file openid';

/** All outbound Google calls are timeout-bounded. */
export function fetchWithTimeout(url: string, init: RequestInit, timeoutMs = 12000): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  return fetch(url, { ...init, signal: controller.signal }).finally(() => clearTimeout(timer));
}

/* ===================== OAuth state (CSRF) ===================== */

const STATE_TTL_MS = 10 * 60 * 1000; // 10 minutes
interface PendingState { userId: string; origin: string; exp: number }
const pendingStates = new Map<string, PendingState>();

// Periodic sweep of expired states (defense against unbounded Map growth).
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of pendingStates) if (v.exp < now) pendingStates.delete(k);
}, 60_000).unref();

function hmacKey(): Buffer {
  // Same key material family as credential encryption (services/storage.ts).
  const src = process.env.STORAGE_MASTER_KEY || process.env.COOKIE_SECRET || 'dirasha-dev-only-storage-key';
  return crypto.createHash('sha256').update(`dirasha-gdrive-state:${src}`).digest();
}

/** Signed, single-use state token: <rand>.<hmac> bound to userId+timestamp. */
function mintState(userId: string, origin: string): string {
  const ts = Date.now().toString(36);
  const rand = crypto.randomBytes(16).toString('base64url');
  const sig = crypto.createHmac('sha256', hmacKey())
    .update(`${userId}|${ts}|${rand}`)
    .digest('base64url')
    .slice(0, 32);
  const state = `${ts}.${rand}.${sig}`;
  pendingStates.set(state, { userId, origin, exp: Date.now() + STATE_TTL_MS });
  return state;
}

export interface ConsumedState { userId: string; origin: string }

/** Validate + consume (delete after use) a state token. Null = invalid/expired. */
export function consumeState(state: string): ConsumedState | null {
  const entry = pendingStates.get(state);
  if (!entry) return null;
  pendingStates.delete(state); // single-use
  if (entry.exp < Date.now()) return null;
  // Verify the embedded HMAC matches this userId+timestamp binding.
  const [ts, rand, sig] = state.split('.');
  if (!ts || !rand || !sig) return null;
  const expected = crypto.createHmac('sha256', hmacKey())
    .update(`${entry.userId}|${ts}|${rand}`)
    .digest('base64url')
    .slice(0, 32);
  if (sig !== expected) return null;
  return { userId: entry.userId, origin: entry.origin };
}

/* ===================== Auth URL ===================== */

export function buildAuthUrl(userId: string, origin: string): string {
  const redirectUri = `${origin}/api/storage/gdrive/callback`;
  const state = mintState(userId, origin);
  const params = new URLSearchParams({
    client_id: GDRIVE_CLIENT_ID,
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: GDRIVE_SCOPE,
    access_type: 'offline',
    prompt: 'consent', // drive.file + offline ALWAYS yields a refresh_token
    include_granted_scopes: 'true',
    state,
  });
  return `${OAUTH_AUTH_URL}?${params.toString()}`;
}

/* ===================== Token exchange / refresh ===================== */

export interface TokenExchangeResult {
  refreshToken: string;
  accessToken: string;
  expiresInSec: number;
}

export async function exchangeCode(code: string, redirectUri: string): Promise<TokenExchangeResult> {
  const res = await fetchWithTimeout(OAUTH_TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code,
      client_id: GDRIVE_CLIENT_ID,
      client_secret: GDRIVE_CLIENT_SECRET,
      redirect_uri: redirectUri,
      grant_type: 'authorization_code',
    }).toString(),
  }, 15000);
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    logger.error(`[GDrive] code exchange failed: ${res.status} ${body.slice(0, 200)}`);
    throw new Error('GDRIVE_EXCHANGE_FAILED');
  }
  const json: any = await res.json();
  const refreshToken = String(json.refresh_token || '');
  if (!refreshToken) {
    // Should be impossible with access_type=offline + prompt=consent, but guard anyway.
    throw new Error('GDRIVE_NO_REFRESH_TOKEN');
  }
  return {
    refreshToken,
    accessToken: String(json.access_token || ''),
    expiresInSec: Number(json.expires_in || 3600),
  };
}

/* ---- Access-token cache (per user, refreshed 5 min before expiry) ---- */

const ACCESS_TOKEN_REFRESH_MARGIN_MS = 5 * 60 * 1000;
interface CachedToken { token: string; exp: number }
const accessTokens = new Map<string, CachedToken>();

export function invalidateGdriveCaches(userId: string): void {
  accessTokens.delete(userId);
  folderIds.delete(userId);
  aboutEmailCache.delete(userId);
}

/** Decrypt the stored refresh token out of the user_storage_accounts row. */
function extractRefreshToken(credentialsEncrypted: string): string {
  const creds = decryptCredentials(credentialsEncrypted);
  const rt = creds.accessKeyId; // refresh token is stored in the accessKeyId slot
  if (!rt || creds.secretAccessKey !== 'gdrive-refresh') {
    throw new Error('Not a Google Drive credential payload');
  }
  return rt;
}

async function requestAccessToken(refreshToken: string): Promise<{ token: string; expiresInSec: number }> {
  const res = await fetchWithTimeout(OAUTH_TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      refresh_token: refreshToken,
      client_id: GDRIVE_CLIENT_ID,
      client_secret: GDRIVE_CLIENT_SECRET,
      grant_type: 'refresh_token',
    }).toString(),
  }, 15000);
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    // Never log tokens — only status + a redacted slice of the error body.
    logger.error(`[GDrive] token refresh failed: ${res.status} ${body.slice(0, 200)}`);
    throw new Error(res.status === 400 || res.status === 401 ? 'GDRIVE_TOKEN_REVOKED' : 'GDRIVE_REFRESH_FAILED');
  }
  const json: any = await res.json();
  return { token: String(json.access_token || ''), expiresInSec: Number(json.expires_in || 3600) };
}

/**
 * Get a valid access token for a linked Drive user. Cached per userId with
 * expiry; refreshed 5 minutes before expiry. Throws GDRIVE_TOKEN_REVOKED when
 * the user has revoked access in their Google account (caller unlinks then).
 */
export async function refreshAccessToken(
  userId: string,
  credentialsEncrypted: string,
): Promise<string> {
  const cached = accessTokens.get(userId);
  if (cached && cached.exp > Date.now() + ACCESS_TOKEN_REFRESH_MARGIN_MS) {
    return cached.token;
  }
  const refreshToken = extractRefreshToken(credentialsEncrypted);
  const { token, expiresInSec } = await requestAccessToken(refreshToken);
  if (!token) throw new Error('GDRIVE_REFRESH_FAILED');
  accessTokens.set(userId, { token, exp: Date.now() + expiresInSec * 1000 });
  return token;
}

/**
 * Server-side "anyone with the link" share for a freshly uploaded Drive file,
 * then a server-side verification that the streaming URL actually serves
 * bytes (not a sign-in page). Reliable where the browser-side permission
 * POST was flaky.
 */
export async function shareFileToAnyone(
  userId: string,
  credentialsEncrypted: string,
  fileId: string,
): Promise<{ ok: boolean; url: string; contentType: string }> {
  const token = await refreshAccessToken(userId, credentialsEncrypted);
  const permRes = await fetchWithTimeout(
    `https://www.googleapis.com/drive/v3/files/${fileId}/permissions`,
    {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ role: 'reader', type: 'anyone' }),
    },
    15000,
  );
  if (!permRes.ok) {
    const body = await permRes.text().catch(() => '');
    logger.error(`[GDrive] permission share failed: ${permRes.status} ${body.slice(0, 150)}`);
    throw new Error('GDRIVE_SHARE_FAILED');
  }
  const url = 'https://drive.usercontent.google.com/download?id=' + encodeURIComponent(fileId) + '&export=download&confirm=t';
  const check = await fetchWithTimeout(url, { method: 'GET', redirect: 'follow' }, 20000);
  const contentType = String(check.headers.get('content-type') || '');
  if (!check.ok || /text\/html/i.test(contentType)) {
    logger.error(`[GDrive] stream verify failed: ${check.status} ${contentType.slice(0, 60)}`);
    throw new Error('GDRIVE_SHARE_VERIFY_FAILED');
  }
  return { ok: true, url, contentType };
}

/** Build the encrypted credentials blob for a fresh refresh token. */
export function buildGdriveCredentials(refreshToken: string): string {
  return encryptCredentials({ accessKeyId: refreshToken, secretAccessKey: 'gdrive-refresh' });
}

/** One-off access token straight from a raw refresh token (OAuth callback path). */
export async function requestAccessTokenForRefreshToken(refreshToken: string): Promise<string> {
  const { token } = await requestAccessToken(refreshToken);
  if (!token) throw new Error('GDRIVE_REFRESH_FAILED');
  return token;
}

/* ===================== Drive folder + about ===================== */

export const DRIVE_FOLDER_NAME = 'Dirasha Media';
const FOLDER_MIME = 'application/vnd.google-apps.folder';

const folderIds = new Map<string, string>();
const aboutEmailCache = new Map<string, { email: string; exp: number }>();

async function driveApiGet(accessToken: string, path: string, params?: URLSearchParams): Promise<any> {
  const qs = params ? `?${params.toString()}` : '';
  const res = await fetchWithTimeout(`${DRIVE_API_BASE}${path}${qs}`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    logger.error(`[GDrive] GET ${path} failed: ${res.status} ${body.slice(0, 200)}`);
    throw new Error(res.status === 401 || res.status === 403 ? 'GDRIVE_TOKEN_REVOKED' : 'GDRIVE_API_FAILED');
  }
  return res.json();
}

/**
 * Find (or create) the 'Dirasha Media' folder inside the user's Drive.
 * Cached per user; invalidated by invalidateGdriveCaches on unlink.
 */
export async function ensureFolder(userId: string, accessToken: string): Promise<string> {
  const cached = folderIds.get(userId);
  if (cached) return cached;

  // Search first (q: name + folder mime + not trashed)
  try {
    const q = `name='${DRIVE_FOLDER_NAME.replace(/'/g, "\\'")}' and mimeType='${FOLDER_MIME}' and trashed=false`;
    const found = await driveApiGet(accessToken, '/files', new URLSearchParams({
      q,
      fields: 'files(id,name)',
      pageSize: '1',
      spaces: 'drive',
    }));
    const hit = found?.files?.[0]?.id;
    if (hit) {
      folderIds.set(userId, hit);
      return hit;
    }
  } catch (e: any) {
    if (String(e?.message) === 'GDRIVE_TOKEN_REVOKED') throw e;
    // search failure is non-fatal — fall through to create
  }

  // Create when missing
  const res = await fetchWithTimeout(`${DRIVE_API_BASE}/files?fields=id`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ name: DRIVE_FOLDER_NAME, mimeType: FOLDER_MIME }),
  });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    logger.error(`[GDrive] folder create failed: ${res.status} ${body.slice(0, 200)}`);
    throw new Error(res.status === 401 || res.status === 403 ? 'GDRIVE_TOKEN_REVOKED' : 'GDRIVE_FOLDER_FAILED');
  }
  const json: any = await res.json();
  const folderId = String(json.id || '');
  if (!folderId) throw new Error('GDRIVE_FOLDER_FAILED');
  folderIds.set(userId, folderId);
  return folderId;
}

/**
 * OPTIONAL/cheap identity hint: the Drive about.get email (cached 10 min).
 * Never required — callers must tolerate a null result.
 */
export async function getDriveEmailHint(userId: string, accessToken: string): Promise<string | null> {
  const cached = aboutEmailCache.get(userId);
  if (cached && cached.exp > Date.now()) return cached.email;
  try {
    const about = await driveApiGet(accessToken, '/about', new URLSearchParams({ fields: 'user' }));
    const email = String(about?.user?.emailAddress || '');
    if (email) aboutEmailCache.set(userId, { email, exp: Date.now() + 10 * 60 * 1000 });
    return email || null;
  } catch {
    return null; // keep it optional/cheap — status route must not fail on this
  }
}

/**
 * F12: Drive file deletion with the OWNER's stored credentials.
 * The server holds per-user refresh tokens, so blobs can be deleted even
 * when the owner is offline. Best-effort: failures are logged with status,
 * never thrown into the caller's deletion flow (the audit-trail vault copy
 * documents what was not deleted).
 */
export async function deleteDriveFileByOwner(
  ownerUserId: string,
  fileId: string,
): Promise<{ ok: boolean; reason?: string }> {
  try {
    const linked = await pool.query(
      'SELECT credentials_encrypted AS creds, is_active FROM user_storage_accounts WHERE user_id = $1',
      [ownerUserId],
    );
    const row = linked.rows[0];
    if (!row || !row.is_active) return { ok: false, reason: 'no-active-storage' };
    const token = await refreshAccessToken(ownerUserId, row.creds);
    const del = await fetchWithTimeout(
      `https://www.googleapis.com/drive/v3/files/${fileId}`,
      { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } },
      15000,
    );
    if (del.status === 204 || del.status === 200) return { ok: true };
    if (del.status === 404) return { ok: true }; // already gone — treat as success
    logger.warn(`[GDrive] delete failed for ${fileId}: HTTP ${del.status}`);
    return { ok: false, reason: 'http-' + del.status };
  } catch (err: any) {
    logger.warn(`[GDrive] delete error for ${fileId}: ${err?.message}`);
    return { ok: false, reason: err?.message || 'error' };
  }
}

/** Extract gdrive fileIds from a message attachment list. */
export function extractGdriveFileIds(attachments: any[]): string[] {
  const ids: string[] = [];
  for (const a of attachments || []) {
    const url = String(a?.url || '');
    const m = url.match(/\/api\/media\/gdrive\/([A-Za-z0-9_-]+)/);
    if (m) ids.push(m[1]);
  }
  return ids;
}
