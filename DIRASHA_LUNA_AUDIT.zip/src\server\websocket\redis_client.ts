/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Redis } from 'ioredis';
import { EventEmitter } from 'events';

export interface ClusterMessage {
  channel: string;
  payload: any;
}

export class RedisClusterClient {
  private redisPub: Redis | null = null;
  private redisSub: Redis | null = null;
  private hasConfig = false;
  private isConnected = false;
  private localBus = new EventEmitter();
  private reconnectCount = 0;
  private pubCount = 0;

  public getIsConnected(): boolean {
    return this.isConnected;
  }

  /** True when REDIS_URL/REDIS_HOST was configured via environment. */
  public getIsConfigured(): boolean {
    return this.hasConfig;
  }

  public getReconnectCount(): number {
    return this.reconnectCount;
  }

  public getPubCount(): number {
    return this.pubCount;
  }

  public getPubClient(): Redis | null {
    return this.redisPub;
  }

  constructor() {
    this.initialize();
  }

  private initialize() {
    // Determine Redis endpoint configurations from env
    const host = process.env.REDIS_HOST || '127.0.0.1';
    const port = parseInt(process.env.REDIS_PORT || '6379', 10);
    const password = process.env.REDIS_PASSWORD || undefined;
    const url = process.env.REDIS_URL || undefined;

    // Check if configuration parameters exist to attempt connection
    const hasConfig = !!(process.env.REDIS_URL || process.env.REDIS_HOST);
    this.hasConfig = hasConfig;

    if (hasConfig) {
      console.log(`[RedisEngine] Attempting production connection to Redis at: ${url || `${host}:${port}`}`);
      try {
        const clientOptions = url ? url : {
          host,
          port,
          password,
          retryStrategy(times: number) {
            const delay = Math.min(times * 100, 3000);
            return delay; // Constant reconnect attempts (max 3 seconds)
          },
          maxRetriesPerRequest: null, // Critical flag for ioredis pubsub
        };

        this.redisPub = typeof clientOptions === 'string' ? new Redis(clientOptions) : new Redis(clientOptions);
        this.redisSub = typeof clientOptions === 'string' ? new Redis(clientOptions) : new Redis(clientOptions);

        const handleConnect = () => {
          this.isConnected = true;
          console.log('[RedisEngine] Successfully connected to Redis Broker.');
        };

        const handleError = (error: any) => {
          this.isConnected = false;
          this.reconnectCount++;
          console.warn('[RedisEngine] Redis connection issue. Operating on offline local-fallback layer:', error.message);
        };

        this.redisPub.on('connect', handleConnect);
        this.redisPub.on('error', handleError);
        this.redisSub.on('error', () => {}); // Silence duplicate sub cluster connection warnings

        // Fast bind to receive messages
        this.redisSub.on('message', (channel, message) => {
          try {
            const parsed = JSON.parse(message);
            this.localBus.emit(channel, parsed);
          } catch (e) {
            console.error(`[RedisEngine] Failed parsing message payload on channel: ${channel}`, e);
          }
        });

      } catch (err: any) {
        console.warn('[RedisEngine] Critical initialisation crash, falling back cleanly:', err.message);
        this.redisPub = null;
        this.redisSub = null;
        this.isConnected = false;
      }
    } else {
      console.log('[RedisEngine] No REDIS_HOST or REDIS_URL environment variables set. Running in resilient Single-Node In-Memory fallback mode.');
    }
  }

  /**
   * Publishes an event to a specific channel (horizontal scales to all nodes)
   */
  public async publish(channel: string, payload: any): Promise<void> {
    this.pubCount++;
    if (this.isConnected && this.redisPub) {
      try {
        await this.redisPub.publish(channel, JSON.stringify(payload));
        return;
      } catch (err: any) {
        console.warn('[RedisEngine] Publish payload failed, routing locally:', err.message);
      }
    }
    // Local In-Memory propagation fallback
    this.localBus.emit(channel, payload);
  }

  /**
   * Subscribes to a channel and binds callback
   */
  public async subscribe(channel: string, callback: (payload: any) => void): Promise<() => void> {
    // Dynamic binding to local event bus listener
    this.localBus.on(channel, callback);

    if (this.isConnected && this.redisSub) {
      try {
        await this.redisSub.subscribe(channel);
        if (process.env.LOG_LEVEL === 'DEBUG') {
          console.log(`[RedisEngine] Scaling Node subscribed dynamically to Redis channel: ${channel}`);
        }
      } catch (err: any) {
        console.warn(`[RedisEngine] Redis subscribe failed for ${channel}, fell back to memory:`, err.message);
      }
    }

    // Return unsubscriber trigger
    return () => {
      this.localBus.off(channel, callback);
      if (this.isConnected && this.redisSub) {
        // Only unsubscribe from Redis server if there are no listeners remaining in local memory
        const listenersCount = this.localBus.listenerCount(channel);
        if (listenersCount === 0) {
          this.redisSub.unsubscribe(channel).catch(() => {});
        }
      }
    };
  }

  /**
   * Stores a temporary value (e.g., deduplication or typing indicators)
   */
  public async setTemp(key: string, value: string, ttlSeconds: number): Promise<void> {
    if (this.isConnected && this.redisPub) {
      try {
        await this.redisPub.set(key, value, 'EX', ttlSeconds);
        return;
      } catch (err) {
        // Fail silently
      }
    }
    // Memory fallback logic (could utilize global map in process, but memory dumper works)
    localTempCache.set(key, { value, expiresAt: Date.now() + ttlSeconds * 1000 });
  }

  /**
   * BATCH-5 (DIR-AB-08): ATOMIC set-if-absent with TTL — closes the dedup
   * TOCTOU race (GET-then-SET let two concurrent packets both pass). Returns
   * true when THIS call claimed the key.
   */
  public async setTempIfAbsent(key: string, value: string, ttlSeconds: number): Promise<boolean> {
    if (this.isConnected && this.redisPub) {
      try {
        const res = await this.redisPub.set(key, value, 'EX', ttlSeconds, 'NX');
        return res === 'OK';
      } catch (err) {
        // Redis failure → local map fallback (loud per-process view)
      }
    }
    const existing = localTempCache.get(key);
    if (existing && existing.expiresAt > Date.now()) return false;
    localTempCache.set(key, { value, expiresAt: Date.now() + ttlSeconds * 1000 });
    return true;
  }

  /**
   * Checks for existence of temporary key (used for idempotency checks)
   */
  public async getTemp(key: string): Promise<string | null> {
    if (this.isConnected && this.redisPub) {
      try {
        return await this.redisPub.get(key);
      } catch {
        // Fail silently
      }
    }
    const cached = localTempCache.get(key);
    if (cached) {
      if (cached.expiresAt > Date.now()) {
        return cached.value;
      }
      localTempCache.delete(key);
    }
    return null;
  }

  /**
   * Retrieves all temporary keys matching a wildcard pattern (e.g. presence:session:user:123:*)
   */
  public async getKeys(pattern: string): Promise<string[]> {
    if (this.isConnected && this.redisPub) {
      try {
        // BATCH-5 (DIR-2026-042): SCAN iteration instead of blocking KEYS on a
        // shared Redis — KEYS is O(N) and stalls every client on the server.
        const out: string[] = [];
        let cursor = '0';
        do {
          const [next, batch] = await this.redisPub.scan(cursor, 'MATCH', pattern, 'COUNT', 500);
          cursor = next;
          if (Array.isArray(batch)) out.push(...batch);
        } while (cursor !== '0');
        return out;
      } catch (err: any) {
        console.warn('[RedisEngine] Pattern keys fetch failed, falling back:', err.message);
      }
    }

    // In-memory fallback
    const matched: string[] = [];
    const now = Date.now();
    const regexStr = '^' + pattern.replace(/\*/g, '.*') + '$';
    const regex = new RegExp(regexStr);

    for (const [key, val] of localTempCache.entries()) {
      if (regex.test(key) && val.expiresAt > now) {
        matched.push(key);
      }
    }
    return matched;
  }

  /**
   * Instantly removes a temporary key from execution cache
   */
  public async deleteTemp(key: string): Promise<void> {
    if (this.isConnected && this.redisPub) {
      try {
        await this.redisPub.del(key);
        return;
      } catch (err: any) {
        console.warn('[RedisEngine] Key delete failed:', err.message);
      }
    }
    localTempCache.delete(key);
  }

  /**
   * Runs a Lua script ATOMICALLY on the Redis primary (single command, no
   * read-then-write races). Used by the distributed rate limiter
   * (services/rate_limiter.ts) for INCR+PEXPIRE+compare windows.
   *
   * Returns the script's string result, or null when Redis is not connected
   * / the call fails — callers apply their own failure semantics (the rate
   * limiter fails CLOSED for critical limits, so the unavailability signal
   * must be explicit, never swallowed).
   */
  public async evalAtomic(script: string, keys: string[], args: (string | number)[]): Promise<string | null> {
    if (!this.isConnected || !this.redisPub) return null;
    try {
      const result = await this.redisPub.eval(script, keys.length, ...keys, ...args);
      return typeof result === 'string' ? result : String(result);
    } catch (err: any) {
      console.warn('[RedisEngine] evalAtomic failed (Redis unavailable?):', err?.message || err);
      return null;
    }
  }

  /**
   * Pings public instance or returns local success indicator
   */
  public async ping(): Promise<string> {
    if (this.isConnected && this.redisPub) {
      try {
        return await this.redisPub.ping();
      } catch {
        // Fallback below
      }
    }
    return 'PONG';
  }
}

// Global In-Memory sliding-window cache fallback for single-instance or connection downtime scenarios
const localTempCache = new Map<string, { value: string; expiresAt: number }>();

// Periodic memory garbage collection loop for localTempCache
setInterval(() => {
  const now = Date.now();
  for (const [key, val] of localTempCache.entries()) {
    if (val.expiresAt < now) {
      localTempCache.delete(key);
    }
  }
}, 60000); // 1-minute sweeping

export const redisCluster = new RedisClusterClient();
