/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Service Worker for Dirasha background notifications and PWA support
const CACHE_NAME = 'dirasha-pwa-cache-v5';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json'
];

self.addEventListener('install', (event) => {
  console.log('[ServiceWorker] Installed successfully.');
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[ServiceWorker] Caching critical offline shell assets');
      return cache.addAll(STATIC_ASSETS);
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  console.log('[ServiceWorker] Activated and fully in command.');
  // Clear old caches
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            console.log('[ServiceWorker] Deleting old cache:', key);
            return caches.delete(key);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Cache-First / Network-First Smart Routing with Stale-While-Revalidate (SWR) Strategy
self.addEventListener('fetch', (event) => {
  const requestUrl = new URL(event.request.url);

  // Skip caching for backend API requests, WebSockets, or third party files
  if (
    requestUrl.pathname.startsWith('/api/') || 
    requestUrl.pathname.startsWith('/socket.io/') ||
    requestUrl.pathname.startsWith('/uploads/') || // BATCH-6 (NEW-A-10): authenticated media is never cached
    event.request.method !== 'GET'
  ) {
    return; // Fall through directly to network
  }

  const isHtmlRequest = (event.request.headers.get('accept') && event.request.headers.get('accept').includes('text/html')) || requestUrl.pathname === '/';

  // HTML shell: NETWORK-FIRST — a stale cached shell must never white-screen the app
  if (isHtmlRequest) {
    event.respondWith(
      fetch(event.request)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const clone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put('/index.html', clone));
          }
          return networkResponse;
        })
        .catch(() => caches.match('/index.html')) // offline fallback only
    );
    return;
  }

  const isStaticAsset = (url) => {
    return (
      url.pathname.includes('/assets/') ||
      url.pathname.endsWith('.js') ||
      url.pathname.endsWith('.css') ||
      url.pathname.endsWith('.png') ||
      url.pathname.endsWith('.jpg') ||
      url.pathname.endsWith('.jpeg') ||
      url.pathname.endsWith('.svg') ||
      url.pathname.endsWith('.woff') ||
      url.pathname.endsWith('.woff2') ||
      url.pathname.endsWith('.ttf') ||
      url.pathname.endsWith('.ico') ||
      url.hostname.includes('unsplash.com') ||
      url.hostname.includes('googleapis.com') ||
      url.hostname.includes('gstatic.com') ||
      url.hostname.includes('ibb.co')
    );
  };

  // 1. For HTML/Shell requests, serve Stale-While-Revalidate
  if (isHtmlRequest) {
    event.respondWith(
      caches.match('/index.html').then((cachedResponse) => {
        const networkFetch = fetch(event.request)
          .then((networkResponse) => {
            if (networkResponse && networkResponse.status === 200) {
              const responseToCache = networkResponse.clone();
              caches.open(CACHE_NAME).then((cache) => cache.put('/index.html', responseToCache));
            }
            return networkResponse;
          })
          .catch(() => {
            return cachedResponse;
          });
        
        return cachedResponse || networkFetch;
      })
    );
    return;
  }

  // 2. For static assets (JS, CSS, Images, Fonts), serve Cache-First with Background Refresh (if not hashed)
  if (isStaticAsset(requestUrl)) {
    event.respondWith(
      caches.match(event.request).then((cachedResponse) => {
        if (cachedResponse) {
          // If it is a hashed Vite asset (has index-[8-hex-chars].js), it is immutable. We don't need background refresh.
          const isHashed = requestUrl.pathname.includes('/assets/') && /\.[a-f0-9]{8,}\./.test(requestUrl.pathname);
          if (!isHashed) {
            fetch(event.request)
              .then((networkResponse) => {
                if (networkResponse && networkResponse.status === 200) {
                  const responseToCache = networkResponse.clone();
                  caches.open(CACHE_NAME).then((cache) => cache.put(event.request, responseToCache));
                }
              })
              .catch(() => {}); // ignore offline failures during SWR background refresh
          }
          return cachedResponse;
        }

        // Not in cache, fetch from network and populate cache
        return fetch(event.request)
          .then((networkResponse) => {
            if (networkResponse && networkResponse.status === 200) {
              const responseToCache = networkResponse.clone();
              caches.open(CACHE_NAME).then((cache) => cache.put(event.request, responseToCache));
            }
            return networkResponse;
          })
          .catch(() => {
            // Return 404 response gracefully
            return new Response('', { status: 404 });
          });
      })
    );
    return;
  }

  // 3. IMPORTANT: API requests MUST NEVER be cached by the Service Worker.
  // The frontend handles real-time caching via IndexedDB and React State.
  if (requestUrl.pathname.startsWith('/api/')) {
    event.respondWith(fetch(event.request));
    return;
  }

  // 4. Fallback: Network-First strategy for remaining unrecognized assets
  event.respondWith(
    fetch(event.request)
      .then((networkResponse) => {
        if (networkResponse && networkResponse.status === 200) {
          const responseToCache = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, responseToCache));
        }
        return networkResponse;
      })
      .catch(() => {
        return caches.match(event.request);
      })
  );
});

// Listener for push notifications arriving from Server VAPID
// PROJECT 7 (Privacy-Preserving Notifications): the server only ever sends a
// GENERIC payload (title 'ديراشة', body 'لديك رسالة جديدة', data = routing
// metadata). Message content and sender names must never transit push relays,
// so this handler must never log the raw payload either — only event counters.
self.addEventListener('push', (event) => {
  console.log('[ServiceWorker] Push event received.');

  let payload = {
    title: 'ديراشة',
    body: 'لديك رسالة جديدة',
    data: {}
  };

  if (event.data) {
    try {
      payload = event.data.json();
    } catch (e) {
      console.warn('[ServiceWorker] Push payload was not valid JSON — showing generic notification.');
      // Privacy fallback: NEVER render the raw text — an undecodable payload
      // could carry anything, so we always show the generic body instead.
      payload = {
        title: 'ديراشة',
        body: 'لديك رسالة جديدة',
        data: {}
      };
    }
  }

  const APP_ICON = 'https://i.ibb.co/MD4bsZC3/96.png';
  const isCall = payload.data && payload.data.category === 'call';

  // Ensure notification is only shown if user is not active in that specific chat (checked client-side, or we display anyway)
  const options = {
    body: payload.body,
    icon: APP_ICON,
    badge: APP_ICON,
    vibrate: isCall ? [500, 200, 500, 200, 500, 200, 500, 200, 500] : [100, 50, 100],
    data: payload.data,
    dir: 'ltr',
    tag: isCall ? 'incoming-call' : undefined, // Replace previous active call notifications
    requireInteraction: isCall ? true : false, // Keep call banner on screen until acted upon
    actions: isCall ? [
      { action: 'answer', title: 'الرد' },
      { action: 'decline', title: 'رفض' }
    ] : [
      { action: 'open', title: 'عرض الرسالة' },
      { action: 'close', title: 'إغلاق' }
    ]
  };

  event.waitUntil(
    self.registration.showNotification(payload.title, options)
  );
});

// Listener for clicking notifications
// Routing uses ONLY the routing metadata (chatId / callId) from the payload —
// the client resolves chat names and sender identity locally after unlock.
self.addEventListener('notificationclick', (event) => {
  console.log('[ServiceWorker] Notification clicked (action:', event.action || 'default', ')');
  
  event.notification.close();

  if (event.action === 'close' || event.action === 'decline') return;

  const data = event.notification.data || {};
  const isCall = data.category === 'call';
  const chatId = data.chatId;
  const redirectUrl = isCall ? `/?callId=${data.callId}&action=answer` : (chatId ? `/?chatId=${chatId}` : '/');

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      // Focus existing tab if open
      for (const client of clientList) {
        if (client.url && 'focus' in client) {
          client.focus();
          // Message the tab to switch chats reactively
          if (isCall && 'postMessage' in client) {
            client.postMessage({ type: 'INCOMING_CALL_ACTION', action: event.action || 'view', callId: data.callId });
          } else if (chatId && 'postMessage' in client) {
            client.postMessage({ type: 'NAVIGATE_CHAT', chatId });
          }
          return;
        }
      }
      // Or open a fresh window if none are available
      if (self.clients.openWindow) {
        return self.clients.openWindow(redirectUrl);
      }
    })
  );
});
