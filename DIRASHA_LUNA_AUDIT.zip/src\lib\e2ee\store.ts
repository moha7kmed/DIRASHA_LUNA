/**
 * Dirasha E2EE — KVStore implementations.
 *
 * The engine persists identity/session/opk state as JSON strings under a flat
 * key namespace: 'identity', 'spkPriv', 'opk:<keyId>', 'session:<peerUserId>'.
 *
 *   - MemoryKVStore: in-memory Map (Node/tests, or as crash-only fallback).
 *   - IndexedDBKVStore: browser persistence, database 'dirasha-e2ee' with a
 *     single 'kv' object store.
 */

import type { KVStore } from './types.ts';

const DB_NAME = 'dirasha-e2ee';
const DB_VERSION = 1;
const STORE_NAME = 'kv';

/* ── In-memory store (Node / tests) ──────────────────────────────────────── */

export class MemoryKVStore implements KVStore {
  private map = new Map<string, string>();

  async get(key: string): Promise<string | null> {
    const v = this.map.get(key);
    return v === undefined ? null : v;
  }

  async set(key: string, value: string): Promise<void> {
    this.map.set(key, value);
  }

  async del(key: string): Promise<void> {
    this.map.delete(key);
  }

  async keys(): Promise<string[]> {
    return [...this.map.keys()];
  }
}

/* ── Namespaced wrapper (multi-account isolation) ────────────────────────── */

/**
 * Prefixes every key with `<namespace>:` so multiple accounts on the same
 * browser get isolated identity/session/opk state. keys() returns the
 * UNPREFIXED names (engine logic is namespace-agnostic).
 */
export class NamespacedKVStore implements KVStore {
  constructor(private readonly ns: string, private readonly inner: KVStore) {}

  private k(key: string): string {
    return `${this.ns}:${key}`;
  }

  async get(key: string): Promise<string | null> {
    return this.inner.get(this.k(key));
  }

  async set(key: string, value: string): Promise<void> {
    await this.inner.set(this.k(key), value);
  }

  async del(key: string): Promise<void> {
    await this.inner.del(this.k(key));
  }

  async keys(): Promise<string[]> {
    const all = await this.inner.keys();
    const p = `${this.ns}:`;
    return all.filter((k) => k.startsWith(p)).map((k) => k.slice(p.length));
  }
}

/* ── IndexedDB store (browser) ───────────────────────────────────────────── */

export class IndexedDBKVStore implements KVStore {
  private db: Promise<IDBDatabase> | null = null;

  private open(): Promise<IDBDatabase> {
    if (this.db) return this.db;
    if (typeof indexedDB === 'undefined') {
      return Promise.reject(new Error('IndexedDBKVStore: indexedDB is not available in this environment'));
    }
    this.db = new Promise<IDBDatabase>((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) db.createObjectStore(STORE_NAME);
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error ?? new Error('IndexedDB open failed'));
    });
    return this.db;
  }

  private async tx<T>(mode: IDBTransactionMode, run: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
    const db = await this.open();
    return new Promise<T>((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, mode);
      const request = run(transaction.objectStore(STORE_NAME));
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error ?? new Error('IndexedDB request failed'));
    });
  }

  async get(key: string): Promise<string | null> {
    const v = await this.tx<string | undefined>('readonly', (store) => store.get(key) as IDBRequest<string | undefined>);
    return v === undefined ? null : v;
  }

  async set(key: string, value: string): Promise<void> {
    await this.tx('readwrite', (store) => store.put(value, key) as IDBRequest<IDBValidKey>);
  }

  async del(key: string): Promise<void> {
    await this.tx('readwrite', (store) => store.delete(key) as IDBRequest<undefined>);
  }

  async keys(): Promise<string[]> {
    const v = await this.tx<IDBValidKey[]>('readonly', (store) => store.getAllKeys() as IDBRequest<IDBValidKey[]>);
    return v.map(String);
  }
}
