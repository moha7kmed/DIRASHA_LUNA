# دليل تشغيل الاختبارات الأمنية — ديراشة (SECURITY TESTING RUNBOOK)

> إعادة تنفيذ كل التحقق من نسخة نظيفة — بالأوامر والنتائج المتوقعة.

## 1. التحقق الأساسي (كل رفع)

```bash
npm ci                     # اعتماديات نظيفة من lockfile
npm run typecheck          # tsc --noEmit — صفر أخطاء
npm test                   # 20 ملفًا / 306 اختبارًا — كلها خضراء
npm run build              # عميل + حزمة سيرفر — أخضر
npm run scan-secrets       # 182+ ملفًا نظيفًا (CI: gitleaks أيضًا)
npm run sbom               # SBOM CycloneDX (CI artifact)
npm run license-check      # صفر تراخيص مرفوضة
npm audit --omit=dev       # صفر ثغرات HIGH/CRITICAL (CI يفشل عليها)
```

## 2. وحدات التشفير منفردة (تشخيص)

```bash
npx vitest run tests/e2ee-engine.test.ts        # 15+ — X3DH/Ratchet/تعدد أجهزة
npx vitest run tests/e2ee-pq.test.ts            # 13 — PQXDH الهجين + منع التراجع
npx vitest run tests/e2ee-fuzz.test.ts          # 30 سيناريو × 7 ثوابت
npx vitest run tests/crypto-hardening.test.ts   # 17 — عضوية/KT/ذاكرة/مراقبة
npx vitest run tests/cache-vault.test.ts        # 17 — خزنة الكاش والترحيل
npx vitest run tests/db-tls.test.ts             # 36 — وضع TLS الثلاثة
npx vitest run tests/db-tls-negative.test.ts    # 4 — رفض socket-level حقيقي
npx vitest run tests/e2ee-backup.test.ts        # 29 — النسخ الاحتياطي v1/v2
npx vitest run tests/media-e2e-flow.test.ts     # 5 — تشفير الوسائط قبل الشبكة
npx vitest run tests/passkeys.test.ts           # 20 — WebAuthn
```

## 3. البطاريات الحية (متصفحان حقيقيان على الإنتاج)

```bash
node deploy/e2ee-verify.cjs         # نصوص 1:1 — 3 PASS متوقعة
node deploy/cdp-ctrl-probe.cjs      # مجموعات — PASS×2 (CDP مرئي الإطارات)
node deploy/e2ee-multi-verify.cjs   # أجهزة متعددة — كل تدفق عبر التشغيلات
node deploy/passkeys-verify.cjs     # مفاتيح مرور (مُصادق افتراضي CDP)
```
- انتظر ~90 ثانية بعد النشر (استقرار SW-reload — موثق كفروق أداة).

## 4. المجسات الآمنة على الإنتاج (قراءة فقط)

- بدون توكن → 401 على كل نقطة (تم توثيق 6/6 PASSED).
- bundle لمعرف غير موجود (بتوكن) → 404 registered:false.
- فيض جلب الحزم → 429 (الحد المحدث).
- ❌ ممنوع: مجسات تعدل حالة (استهلاك OPK حقيقي = تعديل).

## 5. معيار الدليل
- سجل كل أمر + البيئة + نسخة الكود (git log -1) + العدد الناجح/الفاشل/المتخطى.
- الاختبار المتخطى ≠ نجاح — يوثق سبب التخطي.
- CI (verify.yml) يمنع الرفع عند فشل أي بوابة أمنية.
