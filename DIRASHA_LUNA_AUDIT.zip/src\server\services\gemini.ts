// AI Assistant (Nexora) has been permanently removed from the platform per user request.

export async function reloadGeminiKeys() {
  // No-op
}

export function getCurrentKeyId(): string | null {
  return null;
}

export async function handleGeminiBotMessage(
  _chatId: string,
  _userId: string,
  _content: string,
  _attachments: any[],
  _syntheticId?: string
) {
  // Permanently disabled
}
