/**
 * Key Transparency (Project 2) — proof-math property tests.
 * Covers the PURE functions of src/server/services/key_transparency.ts
 * (RFC-6962-style Merkle inclusion/consistency proofs, witness signing modes,
 * fleet commitments). DB-backed endpoints are exercised by the live server.
 * Run: npx vitest run tests/key-transparency.test.ts
 */
import { describe, it, expect, afterAll, beforeAll } from 'vitest';
import { createHash } from 'node:crypto';
import {
  ktLeafHash,
  ktNodeHash,
  KT_EMPTY_ROOT,
  largestPow2LessThan,
  buildMerkleTree,
  verifyInclusionProof,
  consistencyProof,
  verifyConsistencyProof,
  computeFleetCommitment,
  getKtMode,
  getKtSigningKey,
  signSnapshot,
  verifySnapshotSignature,
  resetKtKeyCacheForTests,
} from '../src/server/services/key_transparency.ts';

const sha256Hex = (...parts: (Uint8Array | string)[]): string => {
  const h = createHash('sha256');
  for (const p of parts) h.update(typeof p === 'string' ? Buffer.from(p, 'utf8') : p);
  return h.digest('hex');
};

/** Simulate an append-only log: entries → leaf hashes in seq order. */
function logLeaves(entries: Array<{ seq: number; userId: string; commitment: string }>): string[] {
  return entries.map((e) => ktLeafHash(e.seq, e.userId, e.commitment));
}

function fakeCommitment(seed: number): string {
  return sha256Hex(`commit-${seed}`);
}

/** Exhaustive inclusion checks for every tree size up to `maxN`. */
function expectInclusionHoldsForAll(leaves: string[]): void {
  const { root, authPaths } = buildMerkleTree(leaves);
  for (let i = 0; i < leaves.length; i++) {
    expect(verifyInclusionProof(i, leaves.length, leaves[i], authPaths[i], root)).toBe(true);
  }
}

/* ===================== Hashing primitives ===================== */

describe('KT hashing primitives', () => {
  it('leaf hash binds seq, userId and commitment with the 0x00 domain separator', () => {
    const h = ktLeafHash(3, 'alice', fakeCommitment(1));
    expect(h).toBe(sha256Hex('\x00', '3|alice|' + fakeCommitment(1)));
    // any field change → different leaf
    expect(ktLeafHash(4, 'alice', fakeCommitment(1))).not.toBe(h);
    expect(ktLeafHash(3, 'bob', fakeCommitment(1))).not.toBe(h);
    expect(ktLeafHash(3, 'alice', fakeCommitment(2))).not.toBe(h);
  });

  it('node hash is left/right-order sensitive with the 0x01 separator', () => {
    const a = sha256Hex('a');
    const b = sha256Hex('b');
    expect(ktNodeHash(a, b)).toBe(sha256Hex('\x01', a, b));
    expect(ktNodeHash(a, b)).not.toBe(ktNodeHash(b, a));
  });

  it('empty-tree root is sha256 of the empty string (RFC 6962 convention)', () => {
    expect(KT_EMPTY_ROOT).toBe(sha256Hex(''));
    expect(buildMerkleTree([]).root).toBe(KT_EMPTY_ROOT);
    expect(buildMerkleTree([]).authPaths).toHaveLength(0);
  });

  it('split rule: largest power of two strictly less than size', () => {
    expect(largestPow2LessThan(2)).toBe(1);
    expect(largestPow2LessThan(3)).toBe(2);
    expect(largestPow2LessThan(4)).toBe(2);
    expect(largestPow2LessThan(5)).toBe(4);
    expect(largestPow2LessThan(8)).toBe(4);
    expect(largestPow2LessThan(9)).toBe(8);
    expect(largestPow2LessThan(64)).toBe(32);
    expect(() => largestPow2LessThan(1)).toThrow();
  });
});

/* ===================== kt1: inclusion proofs ===================== */

describe('kt1: inclusion proofs verify for every leaf', () => {
  it('3 users appended → all three inclusion proofs verify against the snapshot root', () => {
    const entries = [
      { seq: 1, userId: 'alice', commitment: fakeCommitment(1) },
      { seq: 2, userId: 'bob', commitment: fakeCommitment(2) },
      { seq: 3, userId: 'carol', commitment: fakeCommitment(3) },
    ];
    const leaves = logLeaves(entries);
    const { root, authPaths } = buildMerkleTree(leaves);
    expect(root).not.toBe(KT_EMPTY_ROOT);
    for (let i = 0; i < 3; i++) {
      expect(verifyInclusionProof(i, 3, leaves[i], authPaths[i], root)).toBe(true);
    }
    // each proof is specific to its leaf: proof[i] must NOT verify for leaf j
    for (let i = 0; i < 3; i++) {
      for (let j = 0; j < 3; j++) {
        if (i !== j) {
          expect(verifyInclusionProof(i, 3, leaves[i], authPaths[j], root)).toBe(false);
        }
      }
    }
  });

  it('single-user tree (size 1) verifies with an empty auth path', () => {
    const leaf = ktLeafHash(1, 'solo', fakeCommitment(9));
    const { root, authPaths } = buildMerkleTree([leaf]);
    expect(root).toBe(leaf);
    expect(authPaths[0]).toEqual([]);
    expect(verifyInclusionProof(0, 1, leaf, [], root)).toBe(true);
    expect(verifyInclusionProof(0, 1, leaf, [], sha256Hex('x'))).toBe(false);
  });

  it('a user key change appends a new entry and the proof tracks the NEW commitment (design test 4)', () => {
    const c1 = fakeCommitment(1);
    const c1new = fakeCommitment(101);
    const entries = [
      { seq: 1, userId: 'alice', commitment: c1 },
      { seq: 2, userId: 'bob', commitment: fakeCommitment(2) },
    ];
    const before = buildMerkleTree(logLeaves(entries));
    // alice rotates → new log entry
    entries.push({ seq: 3, userId: 'alice', commitment: c1new });
    const after = buildMerkleTree(logLeaves(entries));
    expect(after.root).not.toBe(before.root);
    const aliceIdx = entries.length - 1;
    expect(
      verifyInclusionProof(aliceIdx, 3, ktLeafHash(3, 'alice', c1new), after.authPaths[aliceIdx], after.root),
    ).toBe(true);
    // the OLD commitment no longer has a live proof at the new tree tip
    expect(
      verifyInclusionProof(aliceIdx, 3, ktLeafHash(3, 'alice', c1), after.authPaths[aliceIdx], after.root),
    ).toBe(false);
  });
});

/* ===================== kt2: tamper detection ===================== */

describe('kt2: any tampered node rejects the inclusion proof (property sweep n=1..24)', () => {
  it('every path element, leaf and root position is load-bearing', () => {
    for (let n = 1; n <= 24; n++) {
      const leaves = Array.from({ length: n }, (_, i) => ktLeafHash(i + 1, `u${i}`, fakeCommitment(i)));
      const { root, authPaths } = buildMerkleTree(leaves);
      for (let i = 0; i < n; i++) {
        const path = authPaths[i];
        // the honest proof must verify (sweep is non-vacuous)
        expect(verifyInclusionProof(i, n, leaves[i], path, root), `n=${n} i=${i} honest`).toBe(true);
        // tamper each sibling in the path
        for (let p = 0; p < path.length; p++) {
          const bad = [...path];
          bad[p] = sha256Hex('tampered', String(n), String(i), String(p));
          expect(verifyInclusionProof(i, n, leaves[i], bad, root), `n=${n} i=${i} path[${p}]`).toBe(false);
        }
        // tamper leaf / swap index / tamper root
        expect(verifyInclusionProof(i, n, sha256Hex('leaf-tamper'), path, root), `n=${n} i=${i} leaf`).toBe(false);
        expect(verifyInclusionProof(i, n, leaves[i], path, sha256Hex('root-tamper')), `n=${n} i=${i} root`).toBe(false);
        if (n > 1) {
          expect(verifyInclusionProof((i + 1) % n, n, leaves[i], path, root), `n=${n} i=${i} idx`).toBe(false);
        }
      }
    }
  });

  it('malformed inputs fail closed', () => {
    const leaf = ktLeafHash(1, 'a', fakeCommitment(1));
    expect(verifyInclusionProof(0, 1, leaf, [], leaf)).toBe(true);
    expect(verifyInclusionProof(-1, 1, leaf, [], leaf)).toBe(false);
    expect(verifyInclusionProof(1, 1, leaf, [], leaf)).toBe(false); // index out of range
    expect(verifyInclusionProof(0, 0, leaf, [], leaf)).toBe(false);
    expect(verifyInclusionProof(0.5, 2, leaf, [leaf], leaf)).toBe(false);
    expect(verifyInclusionProof(0, 1, leaf, ['junk-sibling'], leaf)).toBe(false); // extra sibling
    expect(verifyInclusionProof(NaN, 1, leaf, [], leaf)).toBe(false);
    expect(verifyInclusionProof(0, 1, leaf, 'not-an-array' as unknown as string[], leaf)).toBe(false);
  });
});

/* ===================== kt3: consistency proofs / fork detection ===================== */

describe('kt3: consistency N→N+2 verifies; deleted log entry is detected (fork)', () => {
  it('3→5 consistency verifies against both anchored roots', () => {
    const leaves = Array.from({ length: 5 }, (_, i) => ktLeafHash(i + 1, `u${i}`, fakeCommitment(i)));
    const root3 = buildMerkleTree(leaves.slice(0, 3)).root;
    const root5 = buildMerkleTree(leaves).root;
    const proof = consistencyProof(leaves, 3, 5);
    expect(verifyConsistencyProof(3, 5, proof, root3, root5)).toBe(true);
    // tampered root_m / root_n / any element → reject
    expect(verifyConsistencyProof(3, 5, proof, sha256Hex('x'), root5)).toBe(false);
    expect(verifyConsistencyProof(3, 5, proof, root3, sha256Hex('x'))).toBe(false);
    const bad = [...proof];
    bad[0] = sha256Hex('elem-tamper');
    expect(verifyConsistencyProof(3, 5, bad, root3, root5)).toBe(false);
    // truncated proof → reject (structure determined by (m, n))
    expect(verifyConsistencyProof(3, 5, proof.slice(1), root3, root5)).toBe(false);
  });

  it('ALL (m, n) pairs for n = 1..32 verify (property sweep)', () => {
    const leaves = Array.from({ length: 32 }, (_, i) => ktLeafHash(i + 1, `u${i}`, fakeCommitment(i)));
    const roots = Array.from({ length: 33 }, (_, n) => buildMerkleTree(leaves.slice(0, n)).root);
    for (let n = 1; n <= 32; n++) {
      for (let m = 1; m <= n; m++) {
        const proof = consistencyProof(leaves, m, n);
        expect(verifyConsistencyProof(m, n, proof, roots[m], roots[n]), `m=${m} n=${n}`).toBe(true);
        if (m < n) {
          expect(proof.length).toBeGreaterThan(0);
          // swapping any two adjacent elements breaks the proof (order-sensitive)
          const swapped = [...proof];
          [swapped[0], swapped[proof.length - 1]] = [swapped[proof.length - 1], swapped[0]];
          expect(verifyConsistencyProof(m, n, swapped, roots[m], roots[n]), `m=${m} n=${n} swap`).toBe(false);
        } else {
          expect(proof).toEqual([]);
        }
      }
    }
  });

  it('deleting an intermediate log entry → fork detected (consistency rejects, root changes)', () => {
    const entries = [
      { seq: 1, userId: 'u1', commitment: fakeCommitment(1) },
      { seq: 2, userId: 'u2', commitment: fakeCommitment(2) },
      { seq: 3, userId: 'u3', commitment: fakeCommitment(3) },
      { seq: 4, userId: 'u4', commitment: fakeCommitment(4) },
    ];
    const honestLeaves = logLeaves(entries);
    const root2 = buildMerkleTree(honestLeaves.slice(0, 2)).root;
    const root4 = buildMerkleTree(honestLeaves).root;

    // Malicious server erases u2's entry and rebuilds its (shorter) tree.
    const forkedLeaves = logLeaves(entries.filter((e) => e.seq !== 2));
    const forkedRoot = buildMerkleTree(forkedLeaves).root;
    expect(forkedRoot).not.toBe(root4);

    // Any consistency story the forked server tells fails against the anchors:
    //   - "old snapshot = first 2, current = forked tree (3 leaves)"
    const forkProof = consistencyProof(forkedLeaves, 2, 3);
    expect(verifyConsistencyProof(2, 3, forkProof, root2, root4)).toBe(false);
    // The forked view is only SELF-consistent (its own old anchor, not the
    // client's honest root2): the client anchored at root2 flags the fork.
    const fork2 = buildMerkleTree(forkedLeaves.slice(0, 2)).root;
    expect(fork2).not.toBe(root2);
    expect(verifyConsistencyProof(2, 3, forkProof, fork2, forkedRoot)).toBe(true);
    //   - "old = first 2, current = 4 leaves" (padding the fork with a forged leaf)
    const padded = [...forkedLeaves, ktLeafHash(5, 'ghost', fakeCommitment(5))];
    const paddedRoot = buildMerkleTree(padded).root;
    expect(paddedRoot).not.toBe(root4);
    expect(verifyConsistencyProof(2, 4, consistencyProof(padded, 2, 4), root2, root4)).toBe(false);
    // only self-consistent against the forked server's OWN old anchor (fork2)
    expect(verifyConsistencyProof(2, 4, consistencyProof(padded, 2, 4), fork2, paddedRoot)).toBe(true);
    // In every case the CLIENT-anchored root_n never matches → fork flagged.
  });

  it('rewriting a historical entry value → detected (root_m / root_n mismatch)', () => {
    const entries = [
      { seq: 1, userId: 'u1', commitment: fakeCommitment(1) },
      { seq: 2, userId: 'u2', commitment: fakeCommitment(2) },
      { seq: 3, userId: 'u3', commitment: fakeCommitment(3) },
    ];
    const honestLeaves = logLeaves(entries);
    const root1 = buildMerkleTree(honestLeaves.slice(0, 1)).root;
    const root3 = buildMerkleTree(honestLeaves).root;
    // attacker rewrites u2's commitment and replays a proof over the forged log
    const forged = logLeaves([
      entries[0],
      { seq: 2, userId: 'u2', commitment: fakeCommitment(666) },
      entries[2],
    ]);
    expect(verifyConsistencyProof(1, 3, consistencyProof(forged, 1, 3), root1, root3)).toBe(false);
    // and the forged current root differs from the anchored one
    expect(buildMerkleTree(forged).root).not.toBe(root3);
  });

  it('malformed consistency inputs fail closed', () => {
    const leaves = Array.from({ length: 4 }, (_, i) => ktLeafHash(i + 1, `u${i}`, fakeCommitment(i)));
    const root2 = buildMerkleTree(leaves.slice(0, 2)).root;
    const root4 = buildMerkleTree(leaves).root;
    expect(verifyConsistencyProof(0, 4, [], KT_EMPTY_ROOT, root4)).toBe(false); // m must be ≥ 1
    expect(verifyConsistencyProof(5, 4, [], root4, root4)).toBe(false); // m > n
    expect(verifyConsistencyProof(4, 4, [], root4, root4)).toBe(true); // m == n: empty proof
    expect(verifyConsistencyProof(4, 4, ['junk'], root4, root4)).toBe(false);
    expect(verifyConsistencyProof(2, 4, consistencyProof(leaves, 2, 4).concat(['junk']), root2, root4)).toBe(false);
    expect(verifyConsistencyProof(2, 4, 'not-an-array' as unknown as string[], root2, root4)).toBe(false);
    expect(verifyConsistencyProof(NaN, 4, [], root2, root4)).toBe(false);
    expect(() => consistencyProof(leaves, 0, 4)).toThrow();
    expect(() => consistencyProof(leaves, 5, 4)).toThrow();
    expect(() => consistencyProof(leaves, 2, 9)).toThrow(); // n > available leaves
  });
});

/* ===================== kt4: witness / signing modes ===================== */

describe('kt4: witness signing modes (verified vs unverified)', () => {
  const savedEnv = process.env.KT_SIGNING_KEY;

  beforeAll(() => {
    delete process.env.KT_SIGNING_KEY;
    resetKtKeyCacheForTests();
  });

  afterAll(() => {
    if (savedEnv === undefined) delete process.env.KT_SIGNING_KEY;
    else process.env.KT_SIGNING_KEY = savedEnv;
    resetKtKeyCacheForTests();
  });

  it('no KT_SIGNING_KEY → UNVERIFIED mode: empty signature, client contract flags it', () => {
    expect(getKtMode()).toBe('unverified');
    expect(getKtSigningKey()).toBeNull();
    const root = buildMerkleTree([ktLeafHash(1, 'u', fakeCommitment(1))]).root;
    const sig = signSnapshot(1, root);
    expect(sig).toBe(''); // clients treat '' as 'unverified' — never silently trusted
    expect(verifySnapshotSignature(1, root, sig)).toBe(false);
  });

  it('KT_SIGNING_KEY set → VERIFIED mode: valid Ed25519 over DirashaKT-v1:<v>:<root>', () => {
    // deterministic 32-byte test seed (test-only, never a real key)
    process.env.KT_SIGNING_KEY = Buffer.alloc(32, 0x42).toString('base64');
    resetKtKeyCacheForTests();
    expect(getKtMode()).toBe('verified');
    const root = buildMerkleTree([ktLeafHash(1, 'u', fakeCommitment(1))]).root;
    const sig = signSnapshot(7, root);
    expect(sig).not.toBe('');
    expect(verifySnapshotSignature(7, root, sig)).toBe(true);
    // any message change invalidates (version and root are both bound)
    expect(verifySnapshotSignature(8, root, sig)).toBe(false);
    expect(verifySnapshotSignature(7, sha256Hex('other-root'), sig)).toBe(false);
    // tampered signature invalidates
    expect(verifySnapshotSignature(7, root, sig.slice(0, -2) + (sig.endsWith('AA') ? 'BB' : 'AA'))).toBe(false);
    expect(verifySnapshotSignature(7, root, '')).toBe(false);
    // message is the canonical context string
    expect(verifySnapshotSignature(7, root, sig, getKtSigningKey()!.pubB64)).toBe(true);
  });

  it('invalid KT_SIGNING_KEY falls back to UNVERIFIED (never crashes)', () => {
    process.env.KT_SIGNING_KEY = 'not base64!!';
    resetKtKeyCacheForTests();
    expect(getKtMode()).toBe('unverified');
    process.env.KT_SIGNING_KEY = Buffer.alloc(31, 7).toString('base64'); // wrong length
    resetKtKeyCacheForTests();
    expect(getKtMode()).toBe('unverified');
  });
});

/* ===================== fleet commitment ===================== */

describe('computeFleetCommitment: canonical over sorted device identity pubs', () => {
  const dev = (id: string) => ({
    deviceId: id,
    identityDhPub: sha256Hex(`dh-${id}`),
    identitySigPub: sha256Hex(`sig-${id}`),
  });

  it('order-independent (sorted by deviceId) and sensitive to any key change', () => {
    const fleet = [dev('b'), dev('a'), dev('c')];
    const shuffled = [dev('c'), dev('a'), dev('b')];
    expect(computeFleetCommitment(fleet)).toBe(computeFleetCommitment(shuffled));
    expect(computeFleetCommitment([dev('a'), dev('b')])).not.toBe(computeFleetCommitment([dev('a')]));
    const mutated = [dev('a'), { ...dev('b'), identityDhPub: sha256Hex('rotated') }];
    expect(computeFleetCommitment(mutated)).not.toBe(computeFleetCommitment([dev('a'), dev('b')]));
  });

  it('empty fleet → sha256("") (never equal to a real commitment)', () => {
    expect(computeFleetCommitment([])).toBe(sha256Hex(''));
    expect(computeFleetCommitment([])).not.toBe(computeFleetCommitment([dev('a')]));
  });

  it('matches the documented canonical line format', () => {
    const one = computeFleetCommitment([dev('a')]);
    const manual = sha256Hex(`${dev('a').deviceId}:${dev('a').identityDhPub}:${dev('a').identitySigPub}`);
    expect(one).toBe(manual);
  });
});

/* ===================== kt5: performance sanity ===================== */

describe('kt5: 100-user snapshot performance sanity (<1s)', () => {
  it('build + all 100 inclusion verifications + consistency 1→100 under 1s', () => {
    const entries = Array.from({ length: 100 }, (_, i) => ({
      seq: i + 1,
      userId: `user${i}`,
      commitment: fakeCommitment(i),
    }));
    const leaves = logLeaves(entries);
    const started = performance.now();
    const { root, authPaths } = buildMerkleTree(leaves);
    for (let i = 0; i < 100; i++) {
      expect(verifyInclusionProof(i, 100, leaves[i], authPaths[i], root)).toBe(true);
    }
    const proof = consistencyProof(leaves, 1, 100);
    expect(verifyConsistencyProof(1, 100, proof, buildMerkleTree(leaves.slice(0, 1)).root, root)).toBe(true);
    const elapsed = performance.now() - started;
    expect(elapsed).toBeLessThan(1000);
  });
});
