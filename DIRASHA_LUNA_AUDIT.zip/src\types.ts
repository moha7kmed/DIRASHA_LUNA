/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// User Presence Status
export type PresenceStatus = 'online' | 'offline' | 'away';

export interface PrivacySettings {
  lastSeenVisibility: 'everyone' | 'contacts' | 'nobody';
  avatarVisibility: 'everyone' | 'contacts' | 'nobody';
  statusVisibility: 'everyone' | 'contacts' | 'nobody';
  searchVisibility: 'everyone' | 'contacts' | 'nobody';
  aboutVisibility: 'everyone' | 'contacts' | 'nobody';
  allowDirectMessages: 'everyone' | 'contacts' | 'nobody';
  allowGroupInvites: 'everyone' | 'contacts';
  callRelayEnabled?: boolean;
  silenceUnknownCallers?: boolean;
  readReceiptsEnabled?: boolean;
  typingIndicatorEnabled?: boolean;
  screenLockEnabled?: boolean;
  screenLockPasscode?: string;
  disappearingMessagesDefault?: 'off' | '30s' | '5m' | '1h' | '1d' | '1w';
  autoDeleteAccountDuration?: '1m' | '3m' | '6m' | '12m';
  p2pRelayEnabled?: boolean;
  linkPreviewsEnabled?: boolean;
  /**
   * PROJECT 7: opt-in preview of message content in notifications.
   * Default (undefined/false) = generic notifications. Server push payloads are
   * ALWAYS generic regardless of this setting (content never rides the push);
   * enabling it only allows the foreground in-app banner to show content.
   */
  notificationPreviewEnabled?: boolean;
}

export interface NotificationSettings {
  enabled: boolean;
  privateMessages: boolean;
  groupMessages: boolean;
  soundEnabled: boolean;
  soundVolume: number; // 0 to 100
  vibration: boolean;
  desktopNotifications: boolean;
}

export interface AppearanceSettings {
  theme: 'dark' | 'light' | 'system';
  fontSize: 'small' | 'medium' | 'large';
  compactMode: boolean;
  density: 'comfortable' | 'compact';
  animationsEnabled: boolean;
}

export interface ChatSettings {
  enterToSend: boolean;
  mediaAutoDownload: boolean;
  readReceipts: boolean;
}

// User Schema Model
export interface User {
  id: string; // matches auth uid
  uid?: string;
  phoneNumber?: string; // optional — reserved for a future Telegram binding channel
  profileCompleted?: boolean; // false until username+displayName are claimed
  username: string; // unique, normalized
  displayName: string; // sanitized
  /** Full settings state round-trips on the User object (UI reads these) */
  chatNotifOverrides?: Record<string, any>;
  chatWallpapers?: Record<string, string>;
  pinnedChats?: string[];
  unreadMarks?: string[];
  lockedChats?: string[];
  archivedChats?: string[];
  chatFolders?: Array<{ id: string; name: string; chatIds: string[] }>;
  autoDeleteAfterMonths?: number;
  /** @deprecated legacy field kept for UI compatibility — always empty in the phone-auth era */
  email?: string;
  avatarUrl: string;
  photoURL?: string;
  bannerUrl?: string; // profile backdrop banner link
  backgroundBannerUrl?: string; // developer-specific background banner
  bio?: string;
  verified?: boolean;
  onlineStatus?: PresenceStatus;
  lastSeen?: string; // ISO String
  createdAt: string;
  updatedAt: string;
  profileCompletionPercentage?: number;
  bannerShadowOpacity?: number;
  bgBannerShadowOpacity?: number;
  role?: 'user' | 'admin' | 'developer';
  
  // Settings
  privacySettings?: PrivacySettings;
  notificationSettings?: NotificationSettings;
  appearanceSettings?: AppearanceSettings;
  chatSettings?: ChatSettings;
  
  // Lists
  blockedUsers?: string[]; // list of user ids blocked by this user
  mutedUsers?: string[];   // list of user ids muted
  usernameChangeHistory?: {
    lastChangedAt: string;
    count: number;
  };

  // Moderation Enforcement
  isBanned?: boolean;
  bannedAt?: string;
  bannedUntil?: string;
  bannedBy?: string;
  banReason?: string;
  mutedUntil?: string;
  mutedAt?: string;
  mutedBy?: string;
  muteReason?: string;
  mutedFromAiUntil?: string;
}

// Simple Sanitized User for Client Payloads
export interface PublicUser {
  id: string;
  username: string;
  displayName: string;
  avatarUrl: string;
  onlineStatus?: PresenceStatus;
  lastSeen?: string;
  bio?: string;
  verified?: boolean;
  bannerUrl?: string; // profile backdrop banner link
  backgroundBannerUrl?: string; // developer-specific background banner
  bannerShadowOpacity?: number;
  bgBannerShadowOpacity?: number;
  activeChatsCount?: number;
}

// Chat Type — 'channel' is a Telegram-style one-way broadcast space: chats.type
// 'channel' in the same chats/chat_members tables; only owner/admin members may
// post (enforced server-side in sendGate), everyone else is a subscriber.
export type ChatType = 'one-to-one' | 'group' | 'channel';

// Chat Schema Model
export interface Chat {
  id: string;
  type: ChatType;
  name: string | null; // null for One-to-One, string for Group/Channel
  avatarUrl?: string;
  createdAt: string;
  updatedAt: string;
  /** BATCH-3 (DIR-CB-04): current membership epoch — lets every client send
   * variant (schedule/forward/reply) declare the version it composed under. */
  membershipVersion?: number;
  /** Channels only: number of subscribers (owner + admins + members). Optional so groups/DMs are untouched. */
  subscriberCount?: number;
}

// Chat Member Junction Model
export interface ChatMember {
  chatId: string;
  userId: string;
  joinedAt: string;
}

// Message Type Classification
export type MessageType = 'text' | 'attachment' | 'call';

// WhatsApp/Telegram-style interactive poll attached to a message (messages.poll JSONB).
// votes maps userId -> selected option indexes; single-choice polls store at most one index.
export interface PollData {
  question: string;
  options: string[];
  allowMultiple?: boolean;
  votes: Record<string, number[]>;
}

// Message Schema Model
export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  senderName?: string;
  content: string;
  type: MessageType;
  attachments: AttachmentPrimitive[];
  createdAt: string;
  editedAt: string | null;
  deletedAt: string | null;
  replyTo?: { id: string; senderName: string; content: string } | null;
  reactions?: Record<string, string[]>;
  starredBy?: string[];
  deletedFor?: string[];
  isPinned?: boolean;
  expiresAt?: string | null;
  /** Scheduled send (v5): requested send time (ISO 8601); undefined/null = immediate message */
  scheduledAt?: string | null;
  /** Set (ISO 8601) once the delivery sweep broadcast the scheduled message */
  broadcastAt?: string | null;
  metadata?: any;
  /** Present only on poll messages — null/absent for normal messages */
  poll?: PollData | null;
  state?: string;
  sender?: any;
}

// Attachment Interface definition
export interface AttachmentPrimitive {
  name: string;
  size: number;
  mimeType: string;
  url: string;
  /** Optional extra JSON payload persisted in attachments.meta (server round-trips it) */
  meta?: Record<string, any>;
}

// Message search hit (in-chat or global). Extends the enriched Message shape
// returned by getMessagesForChat; global search adds chat context per result.
export interface SearchResult extends Message {
  /** Present on global search results: the chat the message lives in */
  chatName?: string | null;
  chatType?: ChatType;
}

// Media gallery item (GET /api/chats/:chatId/media)
export interface MediaItem {
  id: string;
  messageId: string;
  url: string;
  mimeType: string;
  name: string;
  size: number;
  createdAt: string;
  senderId?: string;
  senderName?: string;
}

// Message Delivery Receipt States
export type DeliveryState = 'sending' | 'sent' | 'delivered' | 'read' | 'deleted' | 'pending' | 'failed';

// Junction Record for Message Receipt Statuses
export interface MessageReadReceipt {
  messageId: string;
  userId: string;
  chatId: string;
  status: DeliveryState;
  updatedAt: string;
}

// Extended Message Object containing sender detail and aggregated client read state
export interface ClientMessage extends Message {
  sender?: PublicUser;
  state: DeliveryState;
}

// Structured Session Tracking Schema for Rotational Tokens
export interface UserSession {
  id: string;
  userId: string;
  refreshToken: string;
  userAgent: string;
  ipAddress: string;
  isRevoked: boolean;
  expiresAt: string;
  createdAt: string;
}

// WebSocket Payload Event Names classification
export type ClientToServerEvent =
  | 'chat:join'
  | 'msg:send'
  | 'msg:read'
  | 'msg:poll:vote'
  | 'presence:status'
  | 'presence:typing';

export type ServerToClientEvent =
  | 'auth:ready'
  | 'msg:new'
  | 'msg:ack'
  | 'msg:state:change'
  | 'msg:poll:update'
  | 'presence:update'
  | 'presence:typing';

// Standardized Unified WebSocket Frame
export interface WSFrame<P = any> {
  event: ClientToServerEvent | ServerToClientEvent | string;
  payload: P;
  traceId?: string;
}

// Status (Story) System Types
export interface Status {
  id: string;
  user_id: string;
  username?: string;
  display_name?: string;
  avatar_url?: string;
  content_type: 'text' | 'image' | 'video';
  media_url?: string;
  text_content?: string;
  duration_hours: number;
  expires_at: string;
  is_archived: boolean;
  settings: {
    likes_visibility: 'everyone' | 'nobody';
    comments: 'open' | 'closed';
    replies: 'open' | 'closed';
    views_visibility: 'everyone' | 'nobody';
  };
  views_count?: number;
  likes_count?: number;
  has_liked?: boolean;
  created_at: string;
  updated_at: string;
}

export interface StatusView {
  id: string;
  status_id: string;
  user_id: string;
  viewed_at: string;
}

export interface StatusLike {
  status_id: string;
  user_id: string;
  created_at: string;
}

export interface StatusComment {
  id: string;
  status_id: string;
  user_id: string;
  username?: string;
  display_name?: string;
  avatar_url?: string;
  parent_id?: string;
  content: string;
  text_content?: string;
  media_url?: string;
  created_at: string;
  updated_at: string;
  deleted_at?: string;
}
