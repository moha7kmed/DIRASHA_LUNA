/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import webpush from 'web-push';
import { db } from '../database.ts';

// Configuration for web push
let vapidPublicKey = process.env.VAPID_PUBLIC_KEY;
let vapidPrivateKey = process.env.VAPID_PRIVATE_KEY;
const pushEmail = 'mailto:thedarkh95@gmail.com';

// Production fail-fast (mirrors the STORAGE_MASTER_KEY guard in services/storage.ts):
// an ephemeral keypair would silently invalidate EVERY existing push subscription
// after the next restart, so production must provide persisted VAPID keys via env.
if ((!vapidPublicKey || !vapidPrivateKey) && process.env.NODE_ENV === 'production') {
  throw new Error('FATAL: VAPID_PUBLIC_KEY and VAPID_PRIVATE_KEY environment variables are required in production.');
}

if (!vapidPublicKey || !vapidPrivateKey) {
  // Generate dynamically if not provided in environment variables.
  // The private key is NEVER logged — persist VAPID_PRIVATE_KEY in .env so keys survive restarts.
  const generated = webpush.generateVAPIDKeys();
  vapidPublicKey = generated.publicKey;
  vapidPrivateKey = generated.privateKey;
  console.log('[Web Push Service] No VAPID keys in env — generated ephemeral keypair for this process (public key suffix:', vapidPublicKey.slice(-8) + ').');
}

// Config VAPID
webpush.setVapidDetails(
  pushEmail,
  vapidPublicKey!,
  vapidPrivateKey!
);

/**
 * PROJECT 7 (Privacy-Preserving Notifications) — generic message-push payload builder.
 *
 * Pure function so tests can assert the exact wire shape (tests/notification-privacy.test.ts).
 *
 * Privacy contract: message text and the sender's display name must NEVER ride
 * the Web Push payload — the payload transits third-party relays (FCM/APNs
 * gateways and the browser-push endpoint operator) and is rendered verbatim on
 * the OS lock screen. The server sends only a generic label plus routing
 * metadata ({chatId, messageId}); the client resolves sender names locally
 * after unlock and routes via chatId.
 *
 * Delivery strategy (documented decision): we keep sending a minimal
 * NOTIFICATION-style payload (generic title + generic body) rather than a
 * data-only message. Some browsers/platforms silently drop data-only pushes
 * or never wake the service worker for them; since our service worker always
 * calls showNotification with this generic text, a minimal notification is
 * both safe and lossless. Data-only was rejected for that reason.
 */
export const GENERIC_PUSH_TITLE = 'ديراشة';
export const GENERIC_PUSH_BODY = 'لديك رسالة جديدة';

export interface MessagePushPayload {
  title: string;
  body: string;
  data: { chatId: string; messageId: string };
}

export function buildMessagePushPayload(chatId: string, messageId: string): MessagePushPayload {
  return {
    title: GENERIC_PUSH_TITLE,
    body: GENERIC_PUSH_BODY,
    data: { chatId, messageId }
  };
}

/** Pure envelope builder for webpush.sendNotification (only place a payload is serialized). */
export function buildWebPushEnvelope(title: string, body: string, data: Record<string, unknown> = {}): string {
  return JSON.stringify({
    title,
    body,
    data: {
      ...data,
      timestamp: Date.now()
    }
  });
}

export const WebPushService = {
  getPublicKey() {
    return vapidPublicKey;
  },

  async sendPush(userId: string, title: string, body: string, data: any = {}) {
    try {
      // Find all subscriptions for this user
      const subscriptions = await db.getPushSubscriptionsForUser(userId);
      if (!subscriptions || subscriptions.length === 0) {
        return;
      }

      console.log(`[PushService] Dispatching push notification to user ${userId} across ${subscriptions.length} registered endpoints.`);

      const payload = buildWebPushEnvelope(title, body, data);

      const promises = subscriptions.map(async (sub: any) => {
        try {
          await webpush.sendNotification(sub, payload);
        } catch (err: any) {
          // If subscription is expired or revoked by browser, delete it from DB automatically to keep it clean
          if (err.statusCode === 410 || err.statusCode === 404 || err.statusCode === 401 || err.statusCode === 403 || err.statusCode === 400) {
            console.log(`[PushService] Subscription invalid (Status: ${err.statusCode}). Evicting registration.`);
            if (sub.endpoint) {
              await db.deletePushSubscription(sub.endpoint);
            }
          } else {
            console.warn(`[PushService] Failed sending to subscription ${sub.endpoint}:`, err.message);
          }
        }
      });

      await Promise.allSettled(promises);
    } catch (error: any) {
      console.error('[PushService] Master push dispatcher crashed:', error.message);
    }
  }
};
export default WebPushService;
