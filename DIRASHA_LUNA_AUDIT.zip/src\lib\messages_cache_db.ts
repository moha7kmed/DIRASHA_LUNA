/**
 * Local chat-message cache (IndexedDB) — F2/audit: every persisted value is
 * ENCRYPTED at rest with a dedicated non-extractable AES-GCM-256 key.
 *
 * WHY THIS SEAM (design decision)
 * The engine's VaultKVStore wraps a string→string KVStore. This cache is NOT
 * a string KV store: it persists `{ chatId, ... }` records with a keyPath and
 * iterates them with cursors (getStats). The clean seam is therefore the
 * RECORD boundary inside this module — every read/write passes through
 * readRecord/writeRecord below, so all call sites (App.tsx history fetch,
 * delta sync, state changes, cache eviction, ChatSidebar stats/wipe) are
 * covered without touching them. The record itself carries the envelope:
 *
 *   encrypted record : { chatId, v: 'enc1', iv: <b64>, ct: <b64> }
 *                      ct = AES-GCM-256 over JSON.stringify(messages)
 *   legacy record    : { chatId, messages: [...] }  (pre-F2 plaintext)
 *
 * KEY SEPARATION (binding design)
 * The cache KEK is NOT the engine's identity-key KEK. It lives in its own
 * database 'dirasha-cache-vault' (store 'keys', key id `cache-kek:<uid>`),
 * generated non-extractable by WebCrypto — the browser refuses any export,
 * so a stolen 'dirashaMessagesDB' file yields envelopes with no key.
 *
 * MULTI-ACCOUNT (verified: the cache DB is SHARED across accounts on the
 * same browser — chatId keys like 'one_to_one_<a>___<b>' do not include the
 * logged-in uid). The KEK id is therefore namespaced by uid
 * (`cache-kek:<uid>`): each account encrypts under its own KEK. Cost, stated
 * honestly: after an account switch, the previous account's cached entries
 * fail AEAD under the new KEK — they are treated as cache misses and
 * re-fetched from the server, then re-encrypted under the new KEK. The cache
 * is fully re-derivable, so this is a one-time cold read per switch, never
 * data loss.
 *
 * MIGRATION (owner rule: no data loss, verify-before-trust, resumable)
 * On first open (App.tsx calls migrateAll() once the uid is known; a per-key
 * lazy migration also fires on legacy cache hits) every legacy plaintext
 * record is re-written encrypted, then READ BACK and VERIFIED (decrypt must
 * reproduce the exact original JSON). Only a verified write counts as
 * migrated. Any failure restores the original plaintext record in place —
 * the entry stays plaintext (graceful) and retries on the next open. Nothing
 * is ever deleted before verification; entries migrate independently, so an
 * interrupted migration resumes cleanly on the next open.
 *
 * HONEST LIMITS (same boundary as the engine vault — owner constraint 4)
 * This protects the cache against DB-file theft (disk forensics, backup
 * exfiltration, malware with file-read access). It does NOT protect against
 * malicious code running with the page's privileges (XSS / malicious
 * extension): such code can call the same WebCrypto API while the page is
 * live. Non-extractable ≠ XSS-proof; this is documented, not claimed away.
 *
 * PERFORMANCE
 * KEK acquisition is one-time per uid (memoized in-memory CryptoKey after
 * init — no per-op key lookup). Per-value work is a single AES-GCM encrypt
 * over at most the 150-message window JSON — microseconds on WebCrypto.
 * Cache writes happen on every history fetch / sync tick; encryption adds
 * no perceptible latency at that cadence.
 *
 * GRACEFUL DEGRADATION
 * If WebCrypto/IndexedDB is unavailable (non-secure context, hardened
 * browsers) or the KEK cannot be created, the cache falls back to the
 * legacy plaintext records with a console warning — the app keeps working,
 * honestly degraded. Undecryptable records (other account's KEK, corruption)
 * are treated as cache misses, never as errors.
 */

import {
  getOrCreateKek,
  isVaultEnvelope,
  encryptToEnvelope,
  decryptEnvelope,
  IndexedDBKekStore,
} from './e2ee/vault.ts';
import type { KekStore, VaultEnvelope } from './e2ee/vault.ts';

const DB_NAME = 'dirashaMessagesDB';
const STORE_NAME = 'messages';
const CACHE_VERSION = 2; // Incremented version to purge corrupted/old cache structures

/** Own vault DB for the cache KEK — deliberately NOT the engine's 'dirasha-vault'. */
const CACHE_KEK_DB = 'dirasha-cache-vault';
const CACHE_KEK_STORE = 'keys';
const ENC_VERSION = 'enc1';

/**
 * Per-account KEK id inside 'dirasha-cache-vault'. Namespaced by uid because
 * the cache DB itself is shared across accounts on the same browser.
 */
export function cacheKekId(uid: string): string {
  return `cache-kek:${uid || 'anon'}`;
}

/* ── Record-store seam (production = IndexedDB; tests inject in-memory) ──── */

/** Raw persisted record as it sits in IndexedDB (encrypted OR legacy). */
export type CacheRecord = { chatId: string; messages?: any[] } & Partial<VaultEnvelope>;

/** Minimal persistence seam so the crypto/migration logic is testable in Node. */
export interface CacheRecordStore {
  getRecord(chatId: string): Promise<CacheRecord | null>;
  putRecord(chatId: string, record: CacheRecord): Promise<void>;
  getAllRecords(): Promise<{ chatId: string; record: CacheRecord }[]>;
  deleteRecord(chatId: string): Promise<void>;
  clearAll(): Promise<void>;
}

function isEncryptedRecord(r: any): r is CacheRecord & VaultEnvelope {
  return isVaultEnvelope(r);
}

function isLegacyRecord(r: any): r is CacheRecord & { messages: any[] } {
  return !!r && Array.isArray(r.messages);
}

/* ── Production backend: vanilla IndexedDB (schema unchanged since v2) ───── */

class IndexedDBRecordStore implements CacheRecordStore {
  private db: Promise<IDBDatabase> | null = null;

  private open(): Promise<IDBDatabase> {
    if (this.db) return this.db;
    this.db = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, CACHE_VERSION);
      request.onupgradeneeded = (event: any) => {
        const db = event.target.result;
        // If updating version, and store exists, wipe it safely and reconstruct
        if (db.objectStoreNames.contains(STORE_NAME)) {
          db.deleteObjectStore(STORE_NAME);
        }
        db.createObjectStore(STORE_NAME, { keyPath: 'chatId' });
      };
      request.onsuccess = (event: any) => resolve(event.target.result);
      request.onerror = (event: any) => reject(event.target.error);
    });
    return this.db;
  }

  async getRecord(chatId: string): Promise<CacheRecord | null> {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const request = db.transaction(STORE_NAME, 'readonly').objectStore(STORE_NAME).get(chatId);
      request.onsuccess = () => resolve(request.result ?? null);
      request.onerror = () => reject(request.error);
    });
  }

  async putRecord(chatId: string, record: CacheRecord): Promise<void> {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).put(record);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async getAllRecords(): Promise<{ chatId: string; record: CacheRecord }[]> {
    const db = await this.open();
    return new Promise((resolve) => {
      const out: { chatId: string; record: CacheRecord }[] = [];
      const tx = db.transaction(STORE_NAME, 'readonly');
      const cursorReq = tx.objectStore(STORE_NAME).openCursor();
      cursorReq.onsuccess = () => {
        const cursor = cursorReq.result;
        if (cursor) {
          out.push({ chatId: String(cursor.key), record: cursor.value });
          cursor.continue();
        } else resolve(out);
      };
      cursorReq.onerror = () => resolve(out);
    });
  }

  async deleteRecord(chatId: string): Promise<void> {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).delete(chatId);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async clearAll(): Promise<void> {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).clear();
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
}

/* ── The public static API (unchanged signatures for all call sites) ─────── */

export class MessagesCacheDB {
  /* Test/worker injection (null = production IndexedDB / per-uid KEK store). */
  private static injectedStore: CacheRecordStore | null = null;
  private static injectedKekStore: KekStore | null = null;

  private static ownerUid: string | null = null;
  private static kekPromise: Promise<CryptoKey | null> | null = null;
  private static warnedPlaintext = false;

  /**
   * Bind the cache to the logged-in account (App.tsx, on every uid change).
   * The per-uid KEK is (re)resolved lazily on the next cache operation.
   */
  public static setOwnerUid(uid: string | null): void {
    const next = uid || null;
    if (this.ownerUid === next) return;
    this.ownerUid = next;
    this.kekPromise = null; // re-resolve under the new account's KEK id
  }

  /** Test seam: inject an in-memory record store / KEK store (Node tests). */
  public static configureForTests(opts: { recordStore?: CacheRecordStore; kekStore?: KekStore }): void {
    this.injectedStore = opts.recordStore ?? null;
    this.injectedKekStore = opts.kekStore ?? null;
    this.ownerUid = null;
    this.kekPromise = null;
    this.warnedPlaintext = false;
  }

  public static resetForTests(): void {
    this.injectedStore = null;
    this.injectedKekStore = null;
    this.ownerUid = null;
    this.kekPromise = null;
    this.warnedPlaintext = false;
  }

  private static store(): CacheRecordStore {
    if (this.injectedStore) return this.injectedStore;
    return new IndexedDBRecordStore();
  }

  /**
   * One-time-per-uid KEK resolution. Returns null → plaintext fallback mode
   * (no WebCrypto, KEK creation failed). The KEK object stays in memory;
   * every subsequent value op is a direct AES-GCM call.
   */
  private static getKek(): Promise<CryptoKey | null> {
    if (!this.kekPromise) {
      if (typeof crypto === 'undefined' || !crypto.subtle) {
        if (!this.warnedPlaintext) {
          this.warnedPlaintext = true;
          console.warn('[MessagesCacheDB] WebCrypto unavailable — cache persists PLAINTEXT (graceful degradation)');
        }
        this.kekPromise = Promise.resolve(null);
      } else {
        const kekStore = this.injectedKekStore
          ?? new IndexedDBKekStore(CACHE_KEK_DB, CACHE_KEK_STORE, cacheKekId(this.ownerUid ?? ''));
        this.kekPromise = getOrCreateKek(kekStore).catch((err) => {
          if (!this.warnedPlaintext) {
            this.warnedPlaintext = true;
            console.warn('[MessagesCacheDB] cache KEK unavailable — falling back to plaintext cache', err);
          }
          return null;
        });
      }
    }
    return this.kekPromise;
  }

  /**
   * Read one record → messages array. Returns:
   *  - decrypted messages (encrypted record under THIS account's KEK),
   *  - plaintext messages (legacy record — lazily migrated, fire-and-forget),
   *  - null (missing / unreadable → callers treat as a cache miss).
   */
  private static async readMessages(chatId: string): Promise<{ messages: any[] | null; legacy: boolean }> {
    let record: CacheRecord | null = null;
    try {
      record = await this.store().getRecord(chatId);
    } catch (err) {
      console.error('[MessagesCacheDB] Failed to read cached messages:', err);
      return { messages: null, legacy: false };
    }
    if (!record) return { messages: null, legacy: false };

    if (isEncryptedRecord(record)) {
      const kek = await this.getKek();
      if (!kek) return { messages: null, legacy: false };
      const plain = await decryptEnvelope(kek, record);
      if (plain === null) {
        // Wrong KEK (other account's entry) or corruption → cache miss.
        return { messages: null, legacy: false };
      }
      try {
        const parsed = JSON.parse(plain);
        return { messages: Array.isArray(parsed) ? parsed : null, legacy: false };
      } catch {
        return { messages: null, legacy: false };
      }
    }

    if (isLegacyRecord(record)) {
      // P1-B (external-audit E2EE-06): FAIL-CLOSED legacy handling — never
      // serve a plaintext record at rest. Migrate synchronously (encrypt →
      // verify read-back → plaintext becomes KEK-only); on ANY failure the
      // plaintext record is DELETED and the caller gets a cache MISS.
      const migrated = await this.migrateEntry(chatId, record.messages);
      if (!migrated) {
        try { await this.store().deleteRecord(chatId); } catch {}
        return { messages: null, legacy: true }; // miss — never serve plaintext
      }
      return { messages: record.messages, legacy: true }; // verified-encrypted now
    }

    return { messages: null, legacy: false };
  }

  /** Serialize + encrypt a messages array into a record (or plaintext fallback). */
  private static async writeMessages(chatId: string, messages: any[]): Promise<void> {
    const kek = await this.getKek();
    if (!kek) {
      // P1-B (external-audit E2EE-06): FAIL-CLOSED — no WebCrypto/KEK means NO
      // plaintext is ever persisted; the cache simply stays empty (miss).
      return;
    }
    const env = await encryptToEnvelope(kek, JSON.stringify(messages));
    await this.store().putRecord(chatId, { chatId, v: env.v, iv: env.iv, ct: env.ct });
  }

  public static async get(chatId: string): Promise<any[] | null> {
    const { messages } = await this.readMessages(chatId);
    return messages;
  }

  public static async put(chatId: string, messages: any[]): Promise<void> {
    try {
      if (!chatId || !Array.isArray(messages)) return;
      const { messages: existingMessages } = await this.readMessages(chatId);
      const existing = existingMessages && Array.isArray(existingMessages) ? existingMessages : [];

      // Use a Map to deduplicate messages by ID and preserve message-state priority
      const msgMap = new Map<string, any>();

      // Seed with existingCached messages
      for (const m of existing) {
        if (m && m.id) {
          msgMap.set(m.id, m);
        }
      }

      // Merge incoming messages
      for (const m of messages) {
        if (m && m.id) {
          const cached = msgMap.get(m.id);
          if (cached) {
            // If message state changes, only allow upgrades (sent -> delivered -> read)
            const STATE_ORDER: Record<string, number> = { sent: 1, delivered: 2, read: 3 };
            const newStateVal = m.state || m.status || 'sent';
            const currentStateVal = cached.state || cached.status || 'sent';

            if ((STATE_ORDER[newStateVal] || 0) > (STATE_ORDER[currentStateVal] || 0)) {
              msgMap.set(m.id, { ...cached, ...m });
            } else {
              msgMap.set(m.id, { ...m, ...cached }); // retain existing further state
            }
          } else {
            msgMap.set(m.id, m);
          }
        }
      }

      // Convert to sorted array (ascending order by createdAt string/date)
      const merged = Array.from(msgMap.values()).sort((a, b) => {
        const timeA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const timeB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        return timeA - timeB;
      });

      // Keep a high performance window of top 150 messages
      const messagesToSave = merged.slice(-150);

      await this.writeMessages(chatId, messagesToSave);
    } catch (err) {
      console.error('[MessagesCacheDB] put failed', err);
    }
  }

  public static async clear(): Promise<void> {
    try {
      await this.store().clearAll();
    } catch (err) {
      console.error('[MessagesCacheDB] clear failed', err);
    }
  }

  /** Per-chat cache wipe (storage-management setting) */
  public static async deleteChat(chatId: string): Promise<void> {
    try {
      await this.store().deleteRecord(chatId);
    } catch (err) {
      console.error('[MessagesCacheDB] deleteChat failed', err);
    }
  }

  /** Per-chat cache stats for the storage-management screen.
   *  Encrypted records are decrypted to count (KEK is in-memory); entries
   *  unreadable under this account's KEK count as 0 (other account / corrupt). */
  public static async getStats(): Promise<{ chatId: string; messages: number }[]> {
    try {
      const records = await this.store().getAllRecords();
      const kek = await this.getKek();
      const out: { chatId: string; messages: number }[] = [];
      for (const { chatId, record } of records) {
        if (isEncryptedRecord(record)) {
          if (!kek) { out.push({ chatId, messages: 0 }); continue; }
          const plain = await decryptEnvelope(kek, record);
          let n = 0;
          if (plain !== null) {
            try {
              const parsed = JSON.parse(plain);
              if (Array.isArray(parsed)) n = parsed.length;
            } catch { /* corrupt → 0 */ }
          }
          out.push({ chatId, messages: n });
        } else if (isLegacyRecord(record)) {
          out.push({ chatId, messages: record.messages.length });
        } else {
          out.push({ chatId, messages: 0 });
        }
      }
      return out;
    } catch {
      return [];
    }
  }

  /* ── Migration (F2, owner rules: resumable, verify-then-trust, no delete) ── */

  /**
   * Migrate ONE legacy plaintext record to an encrypted one:
   *   1. encrypt the exact original JSON,
   *   2. write the encrypted record,
   *   3. READ BACK and decrypt — must reproduce the original byte-for-byte.
   * Any failure at any step RESTORES the original plaintext record (an
   * in-place write, never a delete) so the entry is simply retried on the
   * next open. Never throws.
   */
  private static async migrateEntry(chatId: string, originalMessages: any[]): Promise<boolean> {
    try {
      const kek = await this.getKek();
      if (!kek) return false;
      const plain = JSON.stringify(originalMessages);
      const env = await encryptToEnvelope(kek, plain);
      await this.store().putRecord(chatId, { chatId, v: env.v, iv: env.iv, ct: env.ct });

      // VERIFY read-back before considering the entry migrated (owner rule 3).
      const back = await this.store().getRecord(chatId);
      if (!back || !isEncryptedRecord(back)) throw new Error('migration read-back missing envelope');
      const round = await decryptEnvelope(kek, back);
      if (round !== plain) throw new Error('migration read-back mismatch');

      // Verified — plaintext record replaced by the envelope. Done.
      return true;
    } catch {
      // P1-B fail-closed: on any failure DELETE the plaintext record —
      // never keep it at rest. Server re-fetch covers availability.
      try { await this.store().deleteRecord(chatId); } catch {}
      return false;
    }
  }

  /**
   * Migrate every legacy plaintext record (App.tsx calls this once per login,
   * fire-and-forget). Fully resumable: encrypted records are skipped, legacy
   * records migrate independently, failures keep plaintext for next open.
   */
  public static async migrateAll(): Promise<{ migrated: number; deletedPlaintext: number }> {
    let migrated = 0;
    let deletedPlaintext = 0;
    const kek = await this.getKek();
    if (!kek) return { migrated, deletedPlaintext };
    let records: { chatId: string; record: CacheRecord }[] = [];
    try {
      records = await this.store().getAllRecords();
    } catch {
      return { migrated, deletedPlaintext };
    }
    for (const { chatId, record } of records) {
      if (isEncryptedRecord(record)) continue; // already encrypted
      if (!isLegacyRecord(record)) continue;   // malformed → leave untouched
      try {
        const kekOk = kek; // captured above; KEK is immutable per session
        const plain = JSON.stringify(record.messages);
        const env = await encryptToEnvelope(kekOk, plain);
        await this.store().putRecord(chatId, { chatId, v: env.v, iv: env.iv, ct: env.ct });
        const back = await this.store().getRecord(chatId);
        if (back && isEncryptedRecord(back) && (await decryptEnvelope(kekOk, back)) === plain) {
          migrated++;
        } else {
          throw new Error('verify failed');
        }
      } catch {
        // P1-B fail-closed: DELETE the plaintext record (never keep/serve
        // plaintext at rest). Server re-fetch covers availability.
        deletedPlaintext++;
        try {
          await this.store().deleteRecord(chatId);
        } catch { /* next open retries */ }
      }
    }
    return { migrated, deletedPlaintext };
  }
}
