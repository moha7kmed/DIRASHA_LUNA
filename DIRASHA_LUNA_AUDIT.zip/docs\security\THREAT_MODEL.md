# THREAT_MODEL.md — نموذج التهديد (STRIDE) لتطبيق Dirasha

> **نوع المستند:** Threat Model — تدقيق أمني متشكك (skeptical security audit)، قراءة فقط.
> **تاريخ التدقيق:** 2026-11-17 — على شجرة الكود الحالية (آخر commit: `11e43c5` بتاريخ 2026-11-17).
> **تصنيف كل ادعاء:** كل جملة مصحوبة بـ [مُتحقق | Verified] (ملف:سطر أو أمر + ناتج فعلي) أو [تحليل | Analysis] (استنتاج من الكود). لا توجد أي قيم أسرار في هذا المستند.

---

## 0. حدود النظام و الأصول (Assets)

| الأصل | أين يعيش | الحماية الحالية | التصنيف |
|---|---|---|---|
| نص الرسائل (plaintext) على العميل | ذاكرة React + **IndexedDB cache** (قاعدة `dirasha-messages` وليست الخزنة) | لا شيء — يُخزَّن مُفككًا | [مُتحقق — App.tsx:4195-4202 (`decryptHistoryMessages` ثم `MessagesCacheDB.put`), App.tsx:4259, App.tsx:4656, App.tsx:4346] |
| المفاتيح الخاصة للمحرك (identity/SPK/OPK/sessions/sender keys) | IndexedDB قاعدة `dirasha-e2ee` عبر `vault.ts` | مُشفرة AES-GCM-256 بمفتاح **non-extractable** KEK | [مُتحقق — src/lib/e2ee/vault.ts:8-19, 24-27] |
| مفاتيح المرفقات `e2eeFiles` (AttachmentPayload: media key + iv) | داخل رسالة الـ payload — بعد فك التشفير تُخزَّن في **نفس الكاش غير المحمي** (`item.e2eeFiles = parsed.files`) | لا شيء بعد الفك | [مُتحقق — App.tsx:1827, 1842, 2303] |
| سجل مفاتيح الهويات على الخادم | جدول `e2ee_registrations` (Postgres) | تحقق طول فقط على الخادم؛ التحقق التوقيعي يتم على العميل | [مُتحقق — src/server/routes/e2ee.ts:207-223, 269-273] |
| Refresh token | HttpOnly cookie (+ **مُرجَّع أيضًا في جسم الاستجابة JSON**) | cookie: `httpOnly, secure, sameSite:'none'` | [مُتحقق — server.ts:708-714، وجسم الاستجابة server.ts:718 وauthClassic.ts:224-225, 372-373, 469-470] |
| Access token (JWT ‏15 دقيقة) | React state + ذاكرة module فقط | لا localStorage | [مُتحقق — src/lib/token_vault.ts:3-6] |
| Metadata (من/إلى/وقت/حجم) على الخادم | Postgres + Redis | **مرئية بالكامل للخادم** (بدون Sealed Sender مُفعَّل) | [تحليل — docs/SEALED-SENDER-DESIGN-ar.md يصف تصميمًا غير مُفعَّل؛ ws_server.ts:689-701 يمرر sender_id وcontent] |
| نسخ احتياطية (backup) مشفرة بالمَرور | عن العميل | Argon2/AES عبر `backup.ts` | [مُتحقق — tests/e2ee-backup.test.ts:1-10] |

**Trust boundaries:** متصفح المستخدم ⇄ Render (TLS) ⇄ Postgres/Redis؛ عميل ⇄ عميل عبر الخادم (envelopes DIR1/DIRM1/DIRG1)؛ حقل علني `uploads/` و`/api/media/*`.

---

## 1. ملخص تنفيذي — أهم النتائج (severity-rated)

| # | النتيجة | Severity | التصنيف |
|---|---|---|---|
| T-1 | كاش الرسائل في IndexedDB يحفظ **plaintext** ومفاتيح المرفقات بعد فك التشفير — خارج الخزنة المحمية | **High** | [مُتحقق — App.tsx:4195-4202] |
| T-2 | التحقق من شفافية المفاتيح KT **كود ميت**: `kt-client.ts` غير مستورد في أي ملف تشغيلي — تبديل هوية بواسطة الخادم المُخترق غير مكتشف | **High** | [مُتحقق — `grep -rln "kt-client" src` ⇒ لا نتائج خارج kt-client.ts نفسه] |
| T-3 | مفتاح المجموعة (sender key) يُقبل من أي `peerId` دون تحقق عضوية المجموعة — عضو خبيث يطلب مفاتيح الجميع | **Medium-High** | [تحليل — src/lib/e2ee/group.ts:235-254] |
| T-4 | إشعار الفشل المتعدد في القياس الحي (live): `FAIL-MULTI-DEVICE` و`FAIL-REGISTER` في بطاريات deploy بتاريخ اليوم | **Medium (اختبار)** | [مُتحقق — deploy/e2ee-multi-verify.log، deploy/passkeys-verify.log] |
| T-5 | refresh token يُعاد في جسم الاستجابة JSON رغم وجود cookie — يلغي فائدة HttpOnly على مسار refresh | **Medium** | [مُتحقق — server.ts:718] |
| T-6 | CSP مسموح `connect-src https:` و`img-src https:` واسعة جدًا + `style-src` CDN خارجي | **Low-Medium** | [مُتحقق — server.ts:259-262] |
| T-7 | WS token يُقبل من query param URL (يتسرب إلى logs/البروكسي) | **Low-Medium** | [مُتحقق — ws_server.ts:196-208] |
| T-8 | `.env.example`، `deploy/full-env.json`، `deploy/prod-env.json`، `deploy/render-env-paste.txt` موجودة في المستودع (محليًا) — سلوك scan-secrets/gitleaks هو خط الدفاع | **Low (تم فحصه: PASS)** | [مُتحقق — `npm run scan-secrets` ⇒ PASS عبر 182 ملفًا] |

---

## 2. سيناريوهات STRIDE المفصلة

### (a) Spoofing — عضو مجموعة خبيث يطلب/يستقبل sender keys

- **Asset:** مفتاح المرسل `gsk:<groupId>` (32B) — يفك كل رسائل المجموعة القادمة منه.
- **ThreatActor:** عضو مسجَّل في المجموعة (أو أي مستخدم يُرسل ctrl عبر WS) منتحل صفة عضو.
- **AttackSurface:** قناة ctrl داخل WS؛ `GroupCrypto.processControl`.
- **AttackScenario:** يوزَّع مفتاح المرسل عبر payload من نوع `sender-key` يُرسَل **pairwise عبر محرك 1:1** [مُتحقق — group.ts:196-213]. لكن `processControl(peerId, parsed)` يقبل أي payload صحيح البنية من أي `peerId` — **لا يوجد تحقق أن peerId عضو في المجموعة، ولا توقيع على الـ payload** [تحليل — group.ts:235-254: يفحص فقط kind/type/groupId/طول المفتاح ثم يخزن `gmi:<groupId>:<peerId>`]. العضو الخبيث يستقبل مفاتيح كل الأعضاء، ويستطيع أيضًا **حقن** مفتاح مزيّف باسم عضو آخر لتنفيذ هجوم تبديل مفتاح داخل المجموعة. أعضاء المجموعة الحقيقيون يُحتكمون لعضوية الخادم عند التوزيع (توزيع لقائمة أعضاء الخادم)، والمفتاح نفسه يمر عبر تشفير 1:1 معتمد، لكن **داخل المجموعة لا مصادقة على مالك المفتاح**.
- **Impact:** كشف رسائل المجموعة المستقبلية من أي عضو مُخترق المفتاح له؛ انتحال قناة مرسل.
- **Likelihood:** متوسطة (يتطلب عضوية أو جلسة WS مستعملة).
- **ExistingControls:** توزيع عبر تشفير pairwise معتمد (X3DH + Double Ratchet) [group.ts:198-200]؛ فحوص بنية صارمة [group.ts:237-242]؛ اختبارات وحدة لثلاثة أعضاء [tests/e2ee-group.test.ts:1-9].
- **ResidualRisk:** Medium-High — لا توقيع/تحقق عضوية على ctrl payload.
- **Recommendation:** وقّع `distributionPayload` بمفتاح هوية المرسل (Ed25519 موجود أصلًا) وتحقق من العضوية محليًا من قائمة أعضاء المجموعة قبل `processControl`.

### (b) Tampering — خادم مُخترق يبدّل مفاتيح الهوية في الدليل (Key Directory)

- **Asset:** هوية المحادثة (identity DH + sig pub keys).
- **ThreatActor:** مشغّل Render مُخترق / DBA / داخل الخادم.
- **AttackSurface:** `POST /api/e2ee/register` (استبدال صفوف `e2ee_registrations`) و`GET /api/e2ee/bundle/:userId` [مُتحقق — e2ee.ts:183, 413-437].
- **AttackScenario:** الخادم يحقن هوية جديدة للمستخدم B؛ العميل A يجلب الـ bundle: الخادم يتحقق من **الأطوال فقط** [مُتحقق — e2ee.ts:207-223 والتعليق "verified by the CLIENT" سطر 212]. العميل يتحقق من توقيع SPK **باستخدام identity sig pub القادم من نفس الخادم** — تحقق ذاتي الاتساق ينجح مع هوية مزيفة كاملة [تحليل — engine.ts:662-663 يمرر `ikSigPubBytes` من نفس الرد]. **جوابًا على سؤال التدقيق:** KT (Key Transparency) موجود على الخادم (`/api/e2ee/kt/root`, `/proof/:userId`, توقيع Ed25519 للـ root) [مُتحقق — kt.ts:85-121]، لكن **`kt-client.ts` غير مستورد في App.tsx أو أي مكون تشغيلي** — التحقق من طرف العميل كود ميت فعليًا، لذا الهجوم يمر دون رصد. الواجهة الوحيدة البشرية: مقارنة safety number يدويًا (60 رقمًا) عبر `E2eeSafetyModal` [مُتحقق — App.tsx:5299، E2eeSafetyModal.tsx:62-97].
- **Impact:** MITM كامل على الرسائل المستقبلية للمستخدم المُستهدَف (بيانات جديدة فقط؛ الجلسات القائمة محمية بالـ ratchet).
- **Likelihood:** منخفضة لمهاجم خارجي، **عالية لمشغّل خبيث** — وأداة الكشف (KT) غير مُوصَّلة.
- **ExistingControls:** توقيع SPK/PQ-SPK [engine.ts:662-684]؛ خادم KT + جذر موقَّع [kt.ts:85-95]؛ tests/key-transparency.test.ts (21 اختبارًا للرياضيات الخالصة) [مُتحقق — ترويسة الملف]؛ replay-detect endpoint مقيّد بـ requireAdmin [kt.ts:121].
- **ResidualRisk:** **High** — الحماية موجودة على الورق وغير مُفعَّلة في التشغيل.
- **Recommendation:** توصيل `kt-client.ts` في مسار إنشاء/تحديث المحادثات، وإظهار حالة KT ('verified'/'unverified') في `E2eeSafetyModal`، وفشل صريح عند 'unverified'.

### (c) Information Disclosure — سرقة IndexedDB من الجهاز

- **Asset:** تاريخ الرسائل + مفاتيح المرفقات.
- **ThreatActor:** برمجية خبيثة بقراءة ملفات / نفسيّات قرص / نسخة احتياطية للمتصفح.
- **AttackSurface:** IndexedDB: قواعد `dirasha-messages`, `dirasha-chats` (غير محمية) مقابل `dirasha-e2ee` و`dirasha-vault` (محمية).
- **AttackScenario:** **جوابًا على سؤال التدقيق بحقيقة التعرض:** قاعدة `dirasha-e2ee` محمية فعليًا — كل قيمة مُشفرة AES-GCM بمفتاح KEK غير قابل للاستخراج يوجد داخل IndexedDB [مُتحقق — vault.ts:8-27]. لكن كاش الرسائل `MessagesCacheDB.put` يُخزَّن **بعد** `decryptHistoryMessages` — أي plaintext كاملًا — [مُتحقق — App.tsx:4195-4202: التعليق نفسه "decrypt server batch before it reaches the UI / cache"]، ومعه حقول `e2eeFiles` التي تحوي **media key + iv بـ base64** لكل مرفق [مُتحقق — media.ts:35-43 (AttachmentPayload: media key)، App.tsx:1827]. السرقة تعطي تاريخ المحادثات النصية والمرفقات القابلة لفك التشفير دون أي مفتاح إضافي. **لا يوجد تشفير للكاش ولا صلاحية تخزين مقيّدة.**
- **Impact:** كشف كامل لسجل المحادثات المخزَّن على الجهاز.
- **Likelihood:** متوسطة (أشيع متجه للعملاء).
- **ExistingControls:** خزنة المحرك [vault.ts:8-27]؛ حذف عند تسجيل الخروج؟ غير مُتحقق وجود مسح كامل للكاش عند logout — يوجد `clear()` في messages_cache_db.ts:147 لكن نداؤه عند الخروج غير مثبت في هذا التدقيق.
- **ResidualRisk:** **High** — الكاش هو النقطة العمياء.
- **Recommendation:** تخزين الكاش بصيغة DIR1 ciphertext وفك التشفير عند العرض فقط (الآلية موجودة أصلًا في `decryptHistoryMessages`)، أو تشفير الكاش بمفتاح مشتق من KEK الخزنة.

### (d) Information Disclosure — نسخة Render مُخترقة بالكامل

- **Asset:** كل ما يمر بالخادم.
- **ThreatActor:** مهاجم سيطر على الحاوية/env vars (JWT_SECRET, COOKIE_SECRET, ADMIN_WIPE_SECRET, VAPID, DB).
- **AttackSurface:** كود الخادم + Postgres + Redis + logs.
- **AttackScenario — ماذا يرى فعليًا؟**
  - **يرى ciphertext فقط للمحتوى:** رسائل DIR1:/DIRM1:/DIRG1 تُخزَّن كما هي [مُتحقق — ws_server.ts:749-755 يسمح فقط بهذه البادئات؛ deploy/e2ee-verify.log: "PASS-SERVER-CIPHER: stored content is DIR1 ciphertext"]. لا مسار admin يقرأ plaintext: بحثي في admin endpoints [مُتحقق — grep لكل مسارات `/api/admin` في server.ts:422-491 و3673] أظهر أن بحث الداشبورد يقرأ عمود `content` لكنه يعيد **ciphertext** [مُتحقق — dashboard_stats.ts:858-880: `SELECT id, chat_id, sender_id, content FROM messages ...`]، والمحتوى في DB هو DIR1 أصلًا.
  - **يرى plaintext العناوين للإشعارات؟ لا:** payload الإشعار عام عربي بلا محتوى ولا اسم مرسل [مُتحقق — push.ts:42-65، tests/notification-privacy.test.ts:1-9].
  - **يرى بالكامل (متاح للخادم دائمًا):** Metadata كاملة (مَن/متى/أي محادثة/حجم/عدد الأجهزة)، الهويات العامة، مفاتيح عامة، contact graphs، sender_name، عنوان/وقت، علاقات الزمن بين الرسائل، tokens الجلسات، و`uploads/` للمرفقات **مشفرة** (ciphertext فقط لأن المرفق يُرفع مشفرًا [مُتحقق — media.ts:5-9: ciphertext فقط يُرفع]).
  - **يمكنه:** حذف/تعديل ciphertext (DoS)، تحجيم توزيع المفاتيح (سيناريو b)، تسليم رسائل قديمة (replay من المستوى 2)، وتجسس على الزمن والأطراف.
- **Impact:** كسر الخصوصية الوصفية كاملًا دون كسر سرية المحتوى.
- **Likelihood:** منخفضة لكن أثرها الحدّي كامل (الخادم نقطة ثقة واحدة).
- **ExistingControls:** حد بنيوي على المحتوى [ws_server.ts:94-106]؛ إشعارات عامة [push.ts:42-65]؛ عدم وجود مسار إداري يفك التشفير (لا يوجد مفتاح خاص للعملاء على الخادم أصلًا — البنية client-held keys) [تحليل].
- **ResidualRisk:** Medium — خصوصية وصفية ضعيفة (Sealed Sender مصمم وغير مُفعَّل [docs/SEALED-SENDER-DESIGN-ar.md]).
- **Recommendation:** تفعيل Sealed Sender تدريجيًا؛ تقليل الاحتفاظ بالـ metadata؛ تدقيق logs دوريًا لمنع تسرب محتوى.

### (e) Spoofing/Elevation — إضافة متصفح خبيث تعمل في origin الصفحة

- **Asset:** كل ما فوق (كل شيء).
- **ThreatActor:** إضافة Chrome بأذونات عريضة.
- **AttackSurface:** DOM الصفحة، `window`، IndexedDB، الـ fetch/WS.
- **AttackScenario:** content script عالي الامتيازات يقرأ plaintext من state/الكاش، أو يستدعي WebCrypto نفسها لفك الخزنة حيًّا — **توثيق الخزنة نفسها يعترف بهذا صراحة** [مُتحقق — vault.ts:13-15: "does NOT protect: live malicious code running with the page's privileges"]، أو يحقن سكربت (CSP تخفف لكن extension لها bypass في كثير من الحالات عبر scripting API) [تحليل].
- **Impact:** كامل — مفاتيح + plaintext + جلسة.
- **Likelihood:** منخفضة (يتطلب تثبيت إضافة خبيثة).
- **ExistingControls:** CSP صارمة script-src 'self' بلا unsafe-inline في الإنتاج [مُتحقق — server.ts:251-258]؛ لا استخدام لـ innerHTML/dangerouslySetInnerHTML في كود العميل [مُتحقق — grep على src ⇒ التعليق السلبي فقط في ChatWindow.tsx:284]. لكن هذه الضوابط **لا تقيّد الإضافات**.
- **ResidualRisk:** High (حد معماري — لا يُحل على الويب).
- **Recommendation:** وثّقه كحد ثقة صريح في E2EE-SPEC؛ فكّر بوضع "browser hardening checklist" للمستخدمين الحساسين.

### (f) Information Disclosure — MITM على شبكة غير موثوقة

- **Asset:** كل قنوات العميل⇄الخادم.
- **AttackSurface:** TLS من Render، WS، uploads.
- **AttackScenario:** مهاجم DNS/ARP يحاول تجسس. الضوابط: HSTS ‏`max-age=31536000; includeSubDomains` [مُتحقق — server.ts:274]، cookies `secure:true` [server.ts:708-714]، CORS allowlist [server.ts:239-248]، التحقق Origin/Referer لكل POST /api [server.ts:291-304]. **لا يوجد TLS pinning ولا certificate transparency enforcement** — CA خبيث/مخترق كافٍ. محتوى E2EE يبقى محميًا حتى مع MITM على TLS لأن التشفير طرف-لطرف فوق النقل [تحليل — بنية DIR1 فوق WS].
- **Impact:** metadata + محاولات اختراق الجلسات عبر الـ directory (سيناريو b)؛ المحتوى المحمي بقاءه متوقفًا على صحة مفاتيح الدليل.
- **Likelihood:** منخفضة-متوسطة على شبكات عامة، منخفضة جدًا مع CA مخترق.
- **ExistingControls:** كما أعلاه [server.ts:270-276].
- **ResidualRisk:** Low-Medium.
- **Recommendation:** لا pinning على الويب عمليًا عبر SPKI إلا بالضربة القاضية؛ يمكن الاعتماد على expect-CT/HPKP البديلة عبرpub عتاد أو توزيع عميل مُغلف لاحقًا.

### (g) Supply-Chain — اختراق @noble/* أو @simplewebauthn/* أو qrcode

- **Asset:** كل العمليات التشفيرية والاعتمادات.
- **ThreatActor:** مهاجم الحزمة (حساب maintainer مخترق، شبكة توزيع).
- **AttackSurface:** 50 اعتمادًا مباشرًا / 517 صفًا في lockfile / 371 مكوّن SBOM [مُتحقق — استخراج من package-lock.json؛ sbom.json بعد `npm run sbom`].
- **AttackScenario:** إصدار خبيث جديد من `@noble/ciphers` (الاعتماد التشفيري الحاسم — النسخة المثبتة 1.3.0، الأحدث 2.4.0 [مُتحقق — npm outdated]) يلوث seal/open لكل رسالة. مُخفف بـ caret ranges مقيّدة بالـ lockfile (`^1.3.0` مثبتة 1.3.0 [مُتحقق — package-lock.json])، وmaintainer واحد معروف لكل حزم noble هو paulmillr [مُتحقق — `npm view` فعلي].
- **Impact:** كارثي (خدش سرية كل الرسائل) لكنه يمر عبر CI فقط عند التحديث.
- **Likelihood:** منخفضة، أثر حرج.
- **ExistingControls:** `npm ci` في CI [مُتحقق — verify.yml: خطوات "Install dependencies"]؛ npm audit --omit=dev --audit-level=high بوابة فاشلة [verify.yml + ناتج فعلي "found 0 vulnerabilities"]؛ SBOM أسبوعي/كل push [verify.yml SBOM artifact]؛ scan-secrets + gitleaks [verify.yml]؛ lockfile مُتعهد.
- **ResidualRisk:** Medium — لا يوجد أعلى من ذلك بدون pinning مطلق + checksums + مراجعة diff عند الترقية.
- **Recommendation:** تجميد ranges التشفيرية (حذف `^`)، ومراجعة إلزامية لأي ترقية لحزم @noble/* و@simplewebauthn/*، والاستفادة من artifact SBOM للمقارنة.

### (h) Insider / مشغّل الميتا يقرأ الرسائل

- **جواب التدقيق المطلوب:** هل يوجد مسار إداري يقرأ المحتوى؟ **لا يوجد مسار يقرأ plaintext** — لأن الخادم لا يملك مفاتيح فك أصلًا [تحليل معماري: كل المفاتيح الخاصة client-held]. أقرب مسارات: (1) `/api/admin/dashboard/search` تعيد عمود content — لكنه DIR1 ciphertext [مُتحقق — dashboard_stats.ts:872-878 + e2ee-verify.log PASS-SERVER-CIPHER]؛ (2) moderation reports تتعامل مع معرفات وحالات وليس محتوى فك التشفير [مُتحقق — server.ts:3033-3076]؛ (3) `POST /api/admin/reset-database` يسمح بمسح كل شيء (admin role أو ADMIN_WIPE_SECRET) [مُتحقق — server.ts:3673-3700] — تدمير لا قراءة.
- **Impact:** لا قراءة محتوى؛ لكن metadata كاملة + إمكانية هجوم (b) عبر تبديل الدليل.
- **Likelihood:** —
- **ExistingControls:** requireAdmin بقائمة ADMIN_USERNAMES [server.ts:372-383]؛ كل مسارات admin محمية [server.ts:422-491].
- **ResidualRisk:** Low للقراءة، Medium لتزوير الدليل (س ب).
- **Recommendation:** logging وتنبيه على أي عملية register/bundle شاذة؛ تشغيل KT من العميل يجعل هذا قابلاً للرصد.

### (i) Replay / Desync على الـ ratchet

- **AttackSurface:** مسار فك التشفير client-side + WS تسليم مكرر.
- **AttackScenario:** إعادة إرسال envelope مستهلَك، تسليم خارج الترتيب، bootstrap مكرر.
- **نتائج الفحص الفعلي:**
  - skipped message keys بحد MAX_SKIP وإزالة الأقدم [مُتحقق — engine.ts:830-841]؛
  - guard ضد replay/rollback لـ X3DH bootstrap: `bootstrappedEk` + رمي TamperedError [مُتحقق — engine.ts:1233-1249]؛
  - guard ضد cross-generation replay [engine.ts:1244-1249]؛
  - **مشكلة موثقة من الـ fuzz harness نفسها:** فئة "stale pre-rekey bootstrap rebuild" — envelope قبل rekey يُقبل بعد التدوير بسبب مقارنة ik مع الجلسة لا مع المسجل الحالي [مُتحقق — tests/e2ee-fuzz.test.ts:26-40 (.concern)]؛ سلوك E1-E4 مُثبت باختبارات مخصصة [tests/e2ee-security-audit.test.ts:1-8].
- **Impact:** محدود — لا rollback لplaintext قديم بعد الإصلاحات؛ الحالة المتبقية: قبول ما قبل التدوير ضمن نافذة معينة (موثقة في الكود).
- **Likelihood:** منخفضة؛ يحتاج مهاجمًا نشطًا مع القدرة على إعادة الإرسال عبر الخادم.
- **ExistingControls:** I1-I7 في الـ fuzz [tests/e2ee-fuzz.test.ts:1-25]؛ replay-detect على مستوى KT [kt.ts:121].
- **ResidualRisk:** Low-Medium (فئة pre-rekey موثقة).
- **Recommendation:** تطبيق E1-E4 كاملًا في المسار الحي إن لم يكن مطبقًا (الاختبار يثبت السلوك المطلوب — تأكد من أن الحالة المفصولة في الاختبار تطابق الإنتاج).

### (j) Account Takeover — مسارات passkey/session

- **AttackSurface:** `/api/auth/passkeys/*` [passkeys.ts:271-539]، `/api/auth/refresh` [server.ts:673-718]، JWT ‏15 دقيقة [auth.ts:42].
- **AttackScenario + الضوابط الفعلية:**
  - استنساخ authenticator: عداد توقيع غير رتيب ⇒ رفض + إبطال [مُتحقق — tests/passkeys.test.ts:11-13]؛
  - challenge ذات TTL واستهلاك لمرة واحدة [passkeys.test.ts:14-15]؛
  - رفض Origin/RP-ID مغاير [passkeys.test.ts:16]؛
  - rate limits على login-options/login-verify (لكل username وusername+ip) [مُتحقق — passkeys.ts:380, 424]؛
  - refresh rotation مع كشف "استخدام قديم" يبطل الجلسة [مُتحقق — server.ts:683-697: "Attack warning: session stolen or re-use anomaly"].
- **ثغرات متبقية:** refresh token يُعاد في جسم JSON [server.ts:718] — أي XSS/إضافة تقرأ الاستجابة تحصل على refresh token رغم HttpOnly؛ SameSite:'none' مطلوب للـ iframe لكنه يوسع إرسال الكوكي cross-site [مُتحقق — authClassic.ts:131]، مخفف بفحص Origin [server.ts:291-304].
- **Impact:** حصانة حساب كامل (كل الرسائل المستقبلية، لا القديمة).
- **Likelihood:** منخفضة.
- **ExistingControls:** كما أعلاه + fail-closed rate limiting لمسارات auth/e2ee عند انقطاع Redis [server.ts:202-216].
- **ResidualRisk:** Medium.
- **Recommendation:** حذف `refreshToken` من جسم استجابة refresh بعد تثبيت الكوكي في كل العملاء؛ دراسة SameSite:'lax' للعملاء خارج iframe.

---

## 3. واجهة أمان المتصفح (Browser Web-Security Surface)

### CSP — مُهيأة فعليًا [مُتحقق — server.ts:253-270]
- `default-src 'self'`؛ `script-src 'self'` (بلا `unsafe-inline` في الإنتاج؛ يُضاف في dev فقط) [server.ts:253-258].
- **التقييم الحرج:** `style-src 'self' 'unsafe-inline' https://fonts.cdnfonts.com` [server.ts:259] — unsafe-inline للأنماط مقبول عادة لكن CDN خارجي نقطة ثقة إضافية.
- `img-src 'self' data: blob: https:` و`media-src … https:` و`connect-src 'self' ws: wss: https: blob:` [server.ts:260-262] — **open-ended https:** تسمح بأي أصل خارجي: يخفف XSS أثره لكن يسمح تسريب الـ metadata إلى نطاقات خارجية لو نجح حقن عنوان URL. **Severity: Low-Medium.**
- `frame-ancestors` قابل للتهيئة عبر `ALLOWED_FRAME_ANCESTORS`؛ الافتراضي 'self'، وX-Frame-Options SAMEORIGIN متسق معه [مُتحقق — server.ts:252, 268, 275-276]. **Clickjacking: محمي افتراضيًا؛ الخطأ الوحيد أن ضبط ALLOWED_FRAME_ANCESTORS يرفع X-Frame-Options إلى ALLOWALL للوكلاء القدماء [server.ts:276].**

### بقية الترويسات [مُتحقق — server.ts:271-276, 306-312]
`X-Content-Type-Options: nosniff`، `Referrer-Policy: no-referrer`، `Permissions-Policy` مقيّدة (camera/mic=self، geolocation=())، HSTS طويلة، `Cache-Control: no-store` لكل /api.

### XSS sinks [مُتحقق — grep شامل على src]
- **لا `dangerouslySetInnerHTML` ولا `innerHTML` ولا `insertAdjacentHTML` ولا `document.write` ولا `eval(` في كود العميل** — النتيجة الوحيدة تعليق يوثق غيابها [ChatWindow.tsx:284] واستخدام Redis EVAL خادمي [redis_client.ts:251 — ليس XSS]. **Severity: سلبية (نظيف).** React escaping + tokenizer آمن [ChatWindow.tsx:284].

### CSRF [مُتحقق — server.ts:287-304]
- دفاع أساسي: فحص Origin/Referer لكل POST/PUT/DELETE على /api، رفض origin "null"، allowlist عبر `ALLOWED_ORIGINS` (بدونها localhost فقط) [server.ts:239-304]. كوكي refresh بـ SameSite:'none' + secure + httpOnly [server.ts:708-714]. **التقييم:** وضع CSRF قوي رغم 'none' بفضل فحص Origin؛ البدائل (CSRF token) غير موجودة — مقبول بموجب OWASP CS (origin verification).

### Dependency-injection / تزوير الواجهة
- `shield.js` يعمل monkey-patch على `window.WebSocket` و`fetch` [مُتحقق — public/shield.js:1-40] — نمط DI على primitives عامة: مصدره self-origin فلا يفتح ثغرة بذاته، لكنه **precedent** لأي سكربت آخر يحقق نفس الشيء ويقرأ كل WS frames بما فيها envelopes قبل إرسالها [تحليل]. **Severity: Low (معلومة).**

---

## 4. خلاصة الدرجة العامة

| المجال | الدرجة |
|---|---|
| تشفير المحتوى طرف-لطرف (محرك، مجموعة، وسائط، نسخ احتياطي، PQ) | جيد جدًا، مدعوم بـ 210 اختبارًا و fuzz |
| خصوصية الوصفية (metadata) على الخادم | ضعيفة — تصميم Sealed Sender غير مُفعَّل |
| التحقق من الهوية (KT) | **مُنفَّذ على الخادم، ميت على العميل** — أهم فجوة |
| سطح المتصفح (CSP/XSS/CSRF/clickjacking) | قوي مع فتحات https: open-ended |
| الحماية المحلية (vault) | جيدة للمفاتيح، **مُتجاوَزة بالكاش النصي** |
| التشغيل الحي (deploy logs) | 1:1 ينجح؛ **multi-device وpasskeys-register به sinariو فشل يوم التدقيق** |
