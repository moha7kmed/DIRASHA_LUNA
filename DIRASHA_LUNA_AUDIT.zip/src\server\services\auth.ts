/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * AuthService — Session & Token engine (Phone-OTP era)
 * -----------------------------------------------------
 * Passwords and Google OAuth are GONE. Identity = verified phone number.
 * This service only manages the cryptographic session lifecycle:
 *   issueSession → rotateRefreshToken (CAS rotation with token-family reuse
 *   detection) → logout
 *
 * Hardening in this revision:
 *   AUTH-01 — refresh tokens persist as sha256-hex hashes only; rotation is an
 *             atomic compare-and-swap with spent-token recording; presenting a
 *             SPENT or STALE token revokes the whole token family.
 *   AUTH-05 — media tokens are audience-scoped (aud:'media') with an optional
 *             resource binding and a distinguishable verifyMediaToken result.
 *   AUTH-03 — access tokens carry jti + auth_time (+ sid) so the server can
 *             run per-request revocation checks on checkable tokens.
 */

import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { db } from '../database.ts';
import type { User, UserSession } from '../../types.ts';

// JWT secret must come from the environment in production.
// The hardcoded fallback only exists so local development boots without a .env file.
const JWT_SECRET = process.env.JWT_SECRET
  || (process.env.NODE_ENV === 'production' ? '' : 'dirasha-development-secured-jwt-key-2026-core');
if (!JWT_SECRET) {
  throw new Error('FATAL: JWT_SECRET environment variable is required in production.');
}
const ACCESS_TOKEN_EXPIRY = '15m'; // 15 minutes short lifetime
const REFRESH_TOKEN_EXPIRY_DAYS = 7; // 7 days long lifetime
const ABSOLUTE_SESSION_DAYS_MS = 30 * 24 * 60 * 60 * 1000; // absolute cap (OWASP Session CS)

export interface TokenPayload {
  userId: string;
  username: string;
  displayName: string;
  /**
   * AUTH-03: per-token identifier (UUID) minted with every access token so the
   * server can key per-token / per-session revocation checks on it.
   */
  jti?: string;
  /**
   * AUTH-03: time of the authentication event this token was minted for
   * (unix seconds, at issuance). Step-up consumers treat a token as freshly
   * authenticated when auth_time (or iat for pre-AUTH-03 tokens) is recent.
   */
  auth_time?: number;
  /** Session binding — present when the token was minted for a server session. */
  sid?: string;
}

/* ==================== Module-level token helpers (unit-tested) ==================== */

/**
 * AUTH-01: refresh tokens are persisted ONLY as sha256-hex digests. This must
 * stay byte-identical to the database module's hashToken() — the writer of the
 * user_sessions.refresh_token_hash column and of the spent-token ledger. The
 * CAS rotation below passes hashes, never raw tokens, across the service/DB
 * boundary.
 */
export function hashRefreshToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

/**
 * AUTH-01 reuse detection: the durable session store keeps only the CURRENT
 * hash of each session, so a replayed (already-spent) token cannot be mapped
 * back to its session by the DB alone. The service keeps a bounded, process-
 * local record of every refresh-token hash it issued → its owning session.
 * Live-session lookup miss + history hit ⇒ the token is SPENT (used in a
 * prior rotation) or STALE (superseded / revoked) ⇒ token-family revocation.
 * A double miss means the token was never ours — plain reject. (Single-
 * instance coverage by design; see the cross-instance note in the report.)
 */
const ISSUED_TOKEN_HISTORY_CAP = 20_000; // FIFO-bounded (~4 MB worst case)
const issuedTokenHistory = new Map<string, { sessionId: string; userId: string }>();

function rememberIssuedToken(tokenHash: string, sessionId: string, userId: string): void {
  if (issuedTokenHistory.size >= ISSUED_TOKEN_HISTORY_CAP) {
    const oldest = issuedTokenHistory.keys().next().value as string | undefined;
    if (oldest) issuedTokenHistory.delete(oldest);
  }
  issuedTokenHistory.set(tokenHash, { sessionId, userId });
}

/**
 * AUTH-05: strict guard for audience-scoped media tokens. A media token is
 * valid ONLY where this guard (or AuthService.verifyMediaToken) accepts it —
 * never as a general Bearer credential, never on the WebSocket upgrade path.
 */
export function isScopedMediaTokenPayload(payload: unknown): boolean {
  if (typeof payload !== 'object' || payload === null) return false;
  const p = payload as { aud?: unknown; purpose?: unknown; userId?: unknown };
  return p.aud === 'media' && p.purpose === 'media'
    && typeof p.userId === 'string' && p.userId.length > 0;
}

/** Shape of a verified audience-scoped media token payload. */
export interface ScopedMediaTokenPayload extends TokenPayload {
  aud: 'media';
  purpose: 'media';
  /** Optional scoping — when present the token is valid for this resource only. */
  resourceType?: string;
  resourceId?: string;
}

/** Distinguishable media-token verification outcome (AUTH-05). */
export type MediaTokenVerifyResult =
  | { ok: true; payload: ScopedMediaTokenPayload }
  | { ok: false; reason: 'invalid' | 'expired' | 'wrong-audience' };

/**
 * AUTH-03 groundwork: a token is revocation-checkable when it carries BOTH a
 * per-token id (jti) AND its session binding (sid). The per-request session
 * check in requireAuth (server.ts-owned wiring) consults this guard so legacy
 * tokens fail CLOSED: no jti+sid ⇒ treat as un-checkable and reject on
 * sensitive routes until the client re-authenticates with a modern token.
 */
export function isTokenRevocationCheckable(payload: unknown): boolean {
  if (typeof payload !== 'object' || payload === null) return false;
  const p = payload as { jti?: unknown; sid?: unknown };
  return typeof p.jti === 'string' && p.jti.length > 0
    && typeof p.sid === 'string' && p.sid.length > 0;
}

export class AuthService {
  // Sign access JWT payloads.
  // AUTH-03: every token carries jti (per-token id) + auth_time (issuance-time
  // authentication stamp); tokens minted for a server session also carry sid,
  // which makes them isTokenRevocationCheckable() for per-request session checks.
  public static generateAccessToken(user: User, opts?: { sessionId?: string }): string {
    const payload: TokenPayload = {
      userId: user.id,
      username: user.username || '',
      displayName: user.displayName || '',
      jti: crypto.randomUUID(),
      auth_time: Math.floor(Date.now() / 1000),
      ...(opts?.sessionId ? { sid: opts.sessionId } : {}),
    };
    return jwt.sign(payload, JWT_SECRET, { expiresIn: ACCESS_TOKEN_EXPIRY });
  }

  // Verify access token and parse claims
  public static verifyAccessToken(token: string): TokenPayload | null {
    try {
      return jwt.verify(token, JWT_SECRET) as TokenPayload;
    } catch {
      return null;
    }
  }

  // Generate highly cryptographic secure random refresh token
  public static generateRefreshToken(): string {
    return crypto.randomBytes(32).toString('hex');
  }

  // P1-hardening: short-lived, GET-scoped media token for native elements (<audio>/<video>/<img>)
  // that cannot send Authorization headers. Replaces passing long-lived access tokens in URLs
  // (URLs leak into server/proxy logs and browser history).
  // AUTH-05: tokens are now audience-scoped (aud:'media') and optionally bound
  // to a single resource (resourceType/resourceId) so a leaked link can never
  // be replayed against another endpoint or another resource.
  private static readonly MEDIA_TOKEN_EXPIRY = '120s';
  public static generateMediaToken(
    claims: TokenPayload,
    resource?: { resourceType: string; resourceId: string },
  ): string {
    // Pick only identity claims — the source payload carries exp/iat which would
    // conflict with the fresh expiresIn below.
    const payload: ScopedMediaTokenPayload = {
      userId: claims.userId,
      username: claims.username,
      displayName: claims.displayName,
      purpose: 'media',
      aud: 'media',
      ...(resource?.resourceType ? { resourceType: String(resource.resourceType) } : {}),
      ...(resource?.resourceId ? { resourceId: String(resource.resourceId) } : {}),
    };
    return jwt.sign(payload, JWT_SECRET, { expiresIn: this.MEDIA_TOKEN_EXPIRY });
  }
  /** Legacy purpose-tag check (kept for the query-string gate until server.ts wires the scoped guard). */
  public static isMediaToken(payload: unknown): boolean {
    return typeof payload === 'object' && payload !== null && (payload as any).purpose === 'media';
  }
  /** AUTH-05 strict guard — delegates to the module-level isScopedMediaTokenPayload. */
  public static isScopedMediaToken(payload: unknown): boolean {
    return isScopedMediaTokenPayload(payload);
  }

  /**
   * AUTH-05: dedicated media-token verification — validates the signature, the
   * short expiry AND the 'media' audience, returning a DISTINGUISHABLE result
   * instead of the null of verifyAccessToken. An access token presented where
   * a media token is expected fails with 'wrong-audience' so callers can tell
   * "not a media token" apart from "media link expired".
   */
  public static verifyMediaToken(token: string): MediaTokenVerifyResult {
    let decoded: unknown;
    try {
      decoded = jwt.verify(token, JWT_SECRET, { audience: 'media' });
    } catch (err: any) {
      if (err instanceof jwt.TokenExpiredError) return { ok: false, reason: 'expired' };
      if (err instanceof jwt.JsonWebTokenError && /audience/i.test(String(err?.message || ''))) {
        return { ok: false, reason: 'wrong-audience' };
      }
      return { ok: false, reason: 'invalid' };
    }
    if (!isScopedMediaTokenPayload(decoded)) return { ok: false, reason: 'wrong-audience' };
    return { ok: true, payload: decoded as ScopedMediaTokenPayload };
  }

  /** Throws with a user-facing message when the account is under an active ban. */
  private static async assertNotBanned(user: User): Promise<void> {
    if (!user.isBanned) return;
    if (user.bannedUntil && new Date(user.bannedUntil) > new Date()) {
      throw new Error(`هذا الحساب محظور مؤقتاً حتى ${new Date(user.bannedUntil).toLocaleString('ar-EG')}. السبب: ${user.banReason || 'انتهاك سياسة الخدمة'}`);
    } else if (!user.bannedUntil || new Date(user.bannedUntil) > new Date('2099-01-01')) {
      throw new Error(`هذا الحساب محظور نهائياً من قبل الإدارة. السبب: ${user.banReason || 'انتهاك سياسة الخدمة'}`);
    } else {
      // Temporary ban has elapsed → auto-lift
      await db.banUser(user.id, false, 'system', 'Temporary ban expired');
    }
  }

  /**
   * Issue a fresh session after a successful phone-OTP verification.
   * Registers the session, marks presence, and records the audit trail.
   */
  public static async issueSession(user: User, userAgent: string, ipAddress: string) {
    await this.assertNotBanned(user);

    const refreshToken = this.generateRefreshToken();

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + REFRESH_TOKEN_EXPIRY_DAYS);

    const session: UserSession = {
      id: crypto.randomUUID(),
      userId: user.id,
      refreshToken,
      userAgent,
      ipAddress,
      isRevoked: false,
      expiresAt: expiresAt.toISOString(),
      createdAt: new Date().toISOString(),
    };

    // AUTH-03: bind the access token to its session (sid) so per-request
    // revocation checks are possible (isTokenRevocationCheckable).
    const accessToken = this.generateAccessToken(user, { sessionId: session.id });

    await db.createSession(session);
    // AUTH-01: remember the issued refresh-token HASH → session mapping so a
    // replayed (already-spent) token can be traced back to its token family.
    rememberIssuedToken(hashRefreshToken(refreshToken), session.id, user.id);
    await db.updateUser(user.id, { onlineStatus: 'online', lastSeen: new Date().toISOString() });

    return {
      user,
      accessToken,
      refreshToken,
      sessionId: session.id,
    };
  }

  /**
   * AUTH-01: token-family rotation with REUSE detection.
   *
   * The legacy flow looked the presented token up EXCLUDING rotated/revoked
   * sessions, so a replayed (already-spent) token was silently rejected and
   * the family stayed live; two concurrent refreshes could also both win the
   * in-place update. The rewritten flow:
   *
   *   1. Live lookup (current hash, not revoked) — found ⇒ proceed.
   *      Not found ⇒ the token is unknown, SPENT, or STALE: resolve it via the
   *      process-local issued-token history; a hit = REUSE ⇒ revoke the whole
   *      token family (best-effort) + audit, and REJECT (no new tokens).
   *   2. The hash swap is an ATOMIC compare-and-swap
   *      (db.rotateRefreshTokenCas): exactly one concurrent presenter of the
   *      same token wins ('rotated'); the loser sees 'stale' ⇒ REUSE path.
   *   3. After a win the consumed hash is recorded
   *      (db.markRefreshTokenSpent) so later replays are detectable even
   *      after the session record is pruned.
   *
   * Raw refresh tokens NEVER cross into the persistence layer — sha256-hex
   * hashes only (hashRefreshToken, matching the DB module's hashToken).
   */
  public static async rotateRefreshToken(oldRefreshToken: string, userAgent: string, ipAddress: string) {
    const oldHash = hashRefreshToken(oldRefreshToken);
    const activeSession = await db.getSessionByRefreshToken(oldRefreshToken);

    if (!activeSession) {
      // Not a live current hash: unknown token, or REUSE (spent / stale).
      return this.rejectReusedToken(oldHash);
    }

    // OWASP Session CS: absolute lifetime cap — refresh cannot extend a session
    // beyond 30 days total. After that the user must re-authenticate.
    if (activeSession.createdAt && Date.now() - new Date(activeSession.createdAt).getTime() > ABSOLUTE_SESSION_DAYS_MS) {
      await db.revokeAllUserSessions(activeSession.userId);
      return null;
    }

    // Security Check: is token expired or revoked? (The live lookup already
    // excludes revoked rows — this stays as defense-in-depth; expiry punishes
    // presenting a dead token with a full session wipe as before.)
    const isExpired = new Date(activeSession.expiresAt).getTime() < Date.now();
    if (isExpired || activeSession.isRevoked) {
      // Re-use anomaly! Force-revoke all sessions for this userId to protect against credential stealing
      await db.revokeAllUserSessions(activeSession.userId);
      return null;
    }

    const user = await db.getUserById(activeSession.userId);
    if (!user) return null;

    try {
      await this.assertNotBanned(user);
    } catch {
      return null;
    }

    const newRefreshToken = this.generateRefreshToken();
    const newHash = hashRefreshToken(newRefreshToken);

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + REFRESH_TOKEN_EXPIRY_DAYS);

    // AUTH-01: atomic CAS rotation — wins exactly once per (sessionId, currentHash).
    const cas = await db.rotateRefreshTokenCas(
      activeSession.id,
      oldHash,
      newHash,
      expiresAt.toISOString(),
    );

    if (cas === 'stale') {
      // Concurrent refresh race (or replay racing the lookup): the presented
      // hash is no longer current ⇒ REUSE — kill the whole token family.
      return this.rejectReusedToken(oldHash, activeSession.id, activeSession.userId);
    }
    if (cas === 'not-found') {
      // Session vanished between lookup and CAS (pruned/revoked) — plain 401-
      // equivalent failure, nothing left to revoke.
      return null;
    }

    // 'rotated' — record the consumed hash and index the successor so later
    // replays of EITHER hash resolve to this family. Best-effort: the CAS win
    // is already durable and the history map below covers replay detection.
    try {
      await db.markRefreshTokenSpent(activeSession.id, oldHash);
    } catch { /* spent ledger is best-effort; db module logs failures */ }
    rememberIssuedToken(oldHash, activeSession.id, activeSession.userId);
    rememberIssuedToken(newHash, activeSession.id, activeSession.userId);

    // Session ID stays constant across rotation; access token is session-bound.
    const newAccessToken = this.generateAccessToken(user, { sessionId: activeSession.id });

    await db.logAuthAction(user.id, 'session_refresh', { userAgent, ipAddress, sessionId: activeSession.id });

    return {
      user,
      accessToken: newAccessToken,
      refreshToken: newRefreshToken,
      sessionId: activeSession.id,
    };
  }

  /**
   * AUTH-01 REUSE handler: a presented token that matches a SPENT hash or a
   * stale (already-rotated/revoked) current hash. Revokes the whole token
   * family (best-effort), writes an audit trail line, and rejects with no new
   * tokens. When the token was never issued by this instance the history map
   * cannot resolve it — plain reject (still no tokens).
   */
  private static async rejectReusedToken(tokenHash: string, knownSessionId?: string, knownUserId?: string): Promise<null> {
    const remembered = knownSessionId
      ? { sessionId: knownSessionId, userId: knownUserId || '' }
      : issuedTokenHistory.get(tokenHash);
    // BATCH-4 (DIR-CB-02): history miss is no longer a silent plain reject —
    // consult the DURABLE spent-token ledger (survives restart / other
    // instance) so a replayed spent token still trips family revocation +
    // audit.
    const resolved = remembered
      ? remembered
      : (typeof (db as any).findSessionBySpentToken === 'function'
        ? await db.findSessionBySpentToken(tokenHash)
        : null);
    if (!resolved) return null; // genuinely unknown token — plain reject

    const { sessionId, userId } = resolved;

    try {
      await db.revokeSessionFamily(sessionId);
    } catch { /* family revocation is best-effort; db module logs failures */ }

    try {
      const spent = await db.isRefreshTokenSpent(sessionId, tokenHash);
      await db.logAuthAction(userId || 'unknown', 'refresh_token_reuse', {
        sessionId,
        spent,
      });
    } catch { /* audit is best-effort */ }

    issuedTokenHistory.delete(tokenHash);
    return null;
  }

  // Terminate target session
  public static async logout(refreshToken: string) {
    const session = await db.getSessionByRefreshToken(refreshToken);
    if (session) {
      await db.revokeSession(session.id);
      await db.updateUser(session.userId, { onlineStatus: 'offline', lastSeen: new Date().toISOString() });
      return true;
    }
    return false;
  }

  /* ==================== DEVICES & ACTIVE SESSIONS ==================== */

  /**
   * Human-readable Arabic device label from a raw User-Agent string.
   * "Windows 10 • كروم" style — never exposes the full UA (fingerprinting
   * surface) to the sessions list UI.
   */
  public static describeDevice(userAgent: string | null | undefined): string {
    const ua = String(userAgent || '').toLowerCase();
    if (!ua || ua === 'unknown' || ua === 'null') return 'جهاز غير معروف';

    let platform = 'جهاز غير معروف';
    if (/windows nt/.test(ua)) platform = 'ويندوز';
    else if (/android/.test(ua)) platform = 'أندرويد';
    else if (/iphone|ipad|ipod/.test(ua)) platform = 'آيفون';
    else if (/mac os x|macintosh/.test(ua)) platform = 'ماك';
    else if (/linux/.test(ua)) platform = 'لينكس';

    let browser = '';
    if (/edg\//.test(ua)) browser = 'إيدج';
    else if (/firefox|fxios/.test(ua)) browser = 'فايرفوكس';
    else if (/chrome|crios/.test(ua)) browser = 'كروم';
    else if (/safari/.test(ua)) browser = 'سفاري';
    else if (/opr\/|opera/.test(ua)) browser = 'أوبرا';

    return browser ? `${platform} • ${browser}` : platform;
  }

  /**
   * Devices & Active Sessions (Signal/WhatsApp parity): sanitized list of the
   * user's live sessions. Refresh-token hashes and full user-agents NEVER
   * leave the server — only a short session id (first 8 chars of the UUID,
   * enough for the UI to act on), an Arabic device label, IP, timestamps and
   * a `current` flag derived from the caller's own session id.
   */
  public static async listSessions(userId: string, currentSessionId?: string | null) {
    const sessions = await db.getUserSessions(userId);
    const cur = String(currentSessionId || '');
    return (Array.isArray(sessions) ? sessions : []).map((s) => ({
      sessionId: String(s.id || '').slice(0, 8),
      deviceLabel: this.describeDevice(s.userAgent),
      ip: s.ipAddress || '',
      createdAt: s.createdAt || null,
      lastActive: (s as any).lastActive || s.createdAt || null,
      current: Boolean(cur) && s.id === cur,
    }));
  }

  /**
   * Revoke one session by id with an ownership check (a user can never revoke
   * another user's session by guessing ids). Accepts either the full session
   * UUID or the 8-char short id exposed by listSessions() — short ids are
   * resolved ONLY within the caller's own sessions, so the ownership guarantee
   * holds regardless. Returns the status plus the FULL revoked session id (the
   * WS payload must carry the full id so the target device can match it
   * against its own TokenVault.getSessionId()).
   */
  public static async revokeSessionById(
    userId: string,
    sessionId: string,
  ): Promise<{ status: 'revoked' | 'not_found' | 'forbidden'; fullSessionId: string | null }> {
    let session = await db.getSessionById(sessionId);

    // Short-id form: resolve against the caller's own live sessions only.
    if ((!session || !session.id) && sessionId.length < 36) {
      const own = await db.getUserSessions(userId);
      session = own.find(s => s.id.startsWith(sessionId));
      if (!session) return { status: 'not_found', fullSessionId: null };
    }

    if (!session || !session.id) return { status: 'not_found', fullSessionId: null };
    if (session.userId !== userId) return { status: 'forbidden', fullSessionId: null };
    await db.revokeSession(session.id);
    return { status: 'revoked', fullSessionId: session.id };
  }

  /** Revoke every live session of the user EXCEPT the caller's own session. */
  public static async revokeOtherSessions(userId: string, currentSessionId: string): Promise<void> {
    await db.revokeOtherUserSessions(userId, currentSessionId);
  }
}
