// Safe monkey-patch to shield the browser console from Vite HMR WebSocket connection noise and unhandled exceptions.
// Extracted from index.html to an external file so the app can ship a strict CSP without 'unsafe-inline' scripts.
(function() {
  const NativeWebSocket = window.WebSocket;
  if (!NativeWebSocket) return;

  class MockWebSocket {
    constructor(url, protocols) {
      this.url = url;
      this.protocols = protocols;
      this.readyState = 3; // CLOSED
      this.binaryType = 'blob';
      this.onopen = null;
      this.onclose = null;
      this.onerror = null;
      this.onmessage = null;
    }
    send(data) {}
    close(code, reason) {}
    addEventListener(type, callback, options) {}
    removeEventListener(type, callback, options) {}
  }

  const ProxyHandler = {
    construct(target, args) {
      const [url, protocols] = args;
      const isViteHmr = (protocols === 'vite-hmr' || (typeof url === 'string' && (url.includes('vite') || url.includes('hmr'))));
      if (isViteHmr) {
        return new MockWebSocket(url, protocols);
      }
      return Reflect.construct(target, args);
    }
  };

  window.WebSocket = new Proxy(NativeWebSocket, ProxyHandler);

  // Prevent older polyfills (e.g. from Google SDKs) from crashing when fetch is a read-only getter
  const fetchDescriptor = Object.getOwnPropertyDescriptor(window, 'fetch');
  if (fetchDescriptor && !fetchDescriptor.set && fetchDescriptor.configurable) {
    const originalFetch = window.fetch;
    Object.defineProperty(window, 'fetch', {
      get: () => originalFetch,
      set: () => {}, // Silently drop to prevent warnings as requested
      configurable: true
    });
  }
})();
