/**
 * Final P0 — DB TLS certificate verification + user data-export tests.
 *
 * server.ts boots the HTTP listener at import time, so full-handler behavioral
 * tests are not possible in-process (same constraint as
 * tests/users-endpoint.test.ts). The split is:
 *
 *   1. BEHAVIORAL (pure): buildPgSslConfig() — the exported PURE TLS-decision
 *      helper in src/server/database.ts is the unit boundary. Mocking pg pool
 *      connection behavior is out of scope (pg internals): every pool
 *      creation site consumes this builder's decision, so pinning the builder
 *      pins the pools.
 *   2. STATIC-SOURCE (grep-style, over the exact blocks): pool wiring in
 *      database.ts + the GET /api/users/me/export handler in server.ts —
 *      route auth/rate-limit, ownership isolation, exclusion of secret
 *      material, streaming response.
 *
 * Pinned guarantees:
 *   - PG_CA_CERT (valid base64 PEM) → verified mode: { ca, rejectUnauthorized: true }.
 *   - PG_CA_CERT unset → unverified mode: { rejectUnauthorized: false } (documented
 *     activation gate — loud CRITICAL log in production, [DB-TLS] boot log).
 *   - Weak/empty/invalid PG_CA_CERT → treated as unset with a LOUD warning that
 *     never echoes certificate material.
 *   - PG_REQUIRE_DB_TLS=1 + missing CA → failClosed (caller exits 1).
 *   - TLS-01: PG_REQUIRE_DB_TLS=1 + ANY configured-but-invalid cert material
 *     (PG_DB_CERT_PEM or PG_CA_CERT) → failClosed (caller exits 1).
 *   - Export: requireAuth + 'export:data:user' 5/hour/user critical budget,
 *     membership-scoped chats, deleted_for respected per viewer, refreshToken /
 *     credentials_encrypted / secrets never in the payload.
 *
 * Run: npx vitest run tests/db-tls.test.ts
 */
import { describe, it, expect, beforeAll } from 'vitest';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { RATE_LIMIT_RULES } from '../src/server/services/rate_limiter.ts';

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const databaseSrc = fs.readFileSync(path.join(repoRoot, 'src', 'server', 'database.ts'), 'utf8');
const serverSrc = fs.readFileSync(path.join(repoRoot, 'server.ts'), 'utf8');

/** Extract the full source block of a route handler (registration → next route). */
function extractHandler(src: string, needle: string): string {
  const start = src.indexOf(needle);
  expect(start, `route registration not found: ${needle}`).toBeGreaterThan(-1);
  const next = src.indexOf('\n  app.', start + needle.length);
  return src.slice(start, next === -1 ? undefined : next);
}

// ── Fixtures ──────────────────────────────────────────────────────────────────
// A minimal but structurally real PEM certificate block (NOT a real key — it is
// a deterministic marker string; the builder validates structure, not crypto).
// REAL provider leaf certificate (tracked: deploy/pg-db-cert.pem — same leaf as
// the live pinned chain) — parses under X509Certificate (constraint 5: the
// fixture must survive the X.509 validation that production applies, not just
// look like a PEM). Tracked file ⇒ clean extractions run it without any
// gitignored dependency (external-audit Stage-0 fix).
const PEM_PEM = fs
  .readFileSync(path.join(repoRoot, 'deploy', 'pg-db-cert.pem'), 'utf8')
  .split('-----END CERTIFICATE-----')[0]
  .concat('-----END CERTIFICATE-----\n');

function base64Of(s: string): string {
  return Buffer.from(s, 'utf-8').toString('base64');
}

describe('buildPgSslConfig — pinned-leaf mode (PG_DB_CERT_PEM — TOFU anchor)', () => {
  let buildPgSslConfig: (env?: any) => any;
  beforeAll(async () => {
    delete process.env.DATABASE_URL;
    delete process.env.PG_REQUIRE_DB_TLS;
    delete process.env.PG_CA_CERT;
    delete process.env.PG_DB_CERT_PEM;
    ({ buildPgSslConfig } = await import('../src/server/database.ts'));
  });

  it('pinned leaf anchors full verification (chain + hostname) — production TOFU path', () => {
    const d = buildPgSslConfig({ NODE_ENV: 'production', PG_DB_CERT_PEM: PEM_PEM });
    expect(d.mode).toBe('verified'); // owner-provided anchor = verified semantics
    expect((d.ssl as any).ca).toContain('-----BEGIN CERTIFICATE-----');
    expect((d.ssl as any).ca).toContain('-----END CERTIFICATE-----');
    expect((d.ssl as any).rejectUnauthorized).toBe(true);
    expect(d.failClosed).toBe(false);
    expect(d.warning).toBeNull();
  });

  it('CA priority: provider CA wins over pin when both present (provider CA authoritative)', () => {
    const b64 = base64Of(PEM_PEM);
    const d = buildPgSslConfig({ NODE_ENV: 'production', PG_CA_CERT: b64, PG_DB_CERT_PEM: PEM_PEM });
    expect(d.mode).toBe('verified');
  });

  it('invalid pinned PEM treated as unset (falls through per existing rules)', () => {
    // TLS-01: WITHOUT PG_REQUIRE_DB_TLS the historical behavior is kept —
    // loud warning, unverified mode, NOT fail-closed (owner gate: do not take
    // prod down before valid material exists).
    const d = buildPgSslConfig({ NODE_ENV: 'production', PG_DB_CERT_PEM: 'garbage' });
    expect(d.mode).toBe('unverified');
    expect(d.failClosed).toBe(false);
    expect(d.warning).toContain('PG_DB_CERT_PEM rejected');
  });

  it('TLS-01 fail-closed: invalid pinned PEM + PG_REQUIRE_DB_TLS=1 → failClosed (caller exits 1)', () => {
    // Configured-but-invalid cert material must never degrade to unverified
    // when the deployment explicitly requires verified TLS.
    for (const flag of ['1', 'true']) {
      const d = buildPgSslConfig({ NODE_ENV: 'production', PG_DB_CERT_PEM: 'garbage', PG_REQUIRE_DB_TLS: flag });
      expect(d.mode).toBe('unverified');
      expect(d.failClosed).toBe(true);
      expect(d.warning).toContain('PG_DB_CERT_PEM rejected');
    }
  });

  it('TLS-01 fail-closed stays off when PG_REQUIRE_DB_TLS is unset/other even with invalid pinned PEM', () => {
    for (const flag of [undefined, '', '0', 'false']) {
      const d = buildPgSslConfig({ NODE_ENV: 'production', PG_DB_CERT_PEM: 'garbage', PG_REQUIRE_DB_TLS: flag });
      expect(d.failClosed).toBe(false);
    }
  });
});

describe('buildPgSslConfig — verified mode (PG_CA_CERT set)', () => {
  let buildPgSslConfig: (env?: any) => any;

  beforeAll(async () => {
    // Keep the import side-effect-free for pool creation: no DATABASE_URL, no
    // fail-closed flag during import (module import emits boot logs only).
    delete process.env.DATABASE_URL;
    delete process.env.PG_REQUIRE_DB_TLS;
    delete process.env.PG_CA_CERT;
    ({ buildPgSslConfig } = await import('../src/server/database.ts'));
  });

  it('single-line base64 PEM → verified: ca decoded correctly + rejectUnauthorized: true', () => {
    const b64 = base64Of(PEM_PEM);
    const d = buildPgSslConfig({ PG_CA_CERT: b64, NODE_ENV: 'production' });
    expect(d.mode).toBe('verified');
    expect(d.ssl).toEqual({ ca: PEM_PEM, rejectUnauthorized: true });
    expect(d.failClosed).toBe(false);
    expect(d.warning).toBeNull();
  });

  it('multi-line / whitespace-padded base64 (console copy-paste shape) decodes to the same PEM', () => {
    const wrapped = base64Of(PEM_PEM).replace(/(.{40})/g, '$1\n').trim();
    const d = buildPgSslConfig({ PG_CA_CERT: wrapped, NODE_ENV: 'production' });
    expect(d.mode).toBe('verified');
    expect((d.ssl as any).ca).toBe(PEM_PEM);
    expect((d.ssl as any).rejectUnauthorized).toBe(true);
  });

  it('verified mode is environment-independent (dev + production identical)', () => {
    const b64 = base64Of(PEM_PEM);
    for (const nodeEnv of ['production', 'development', undefined]) {
      const d = buildPgSslConfig({ PG_CA_CERT: b64, NODE_ENV: nodeEnv });
      expect(d.mode).toBe('verified');
      expect(d.ssl).toEqual({ ca: PEM_PEM, rejectUnauthorized: true });
    }
  });

  it('hostname/chain verification is part of the verified contract (rejectUnauthorized true, ca present)', () => {
    const d = buildPgSslConfig({ PG_CA_CERT: base64Of(PEM_PEM) });
    expect(d.ssl.rejectUnauthorized).toBe(true);
    expect(typeof d.ssl.ca).toBe('string');
    expect(d.ssl.ca).toContain('-----BEGIN CERTIFICATE-----');
  });
});

describe('buildPgSslConfig — unverified mode (documented activation gate)', () => {
  let buildPgSslConfig: (env?: any) => any;

  beforeAll(async () => {
    delete process.env.DATABASE_URL;
    delete process.env.PG_REQUIRE_DB_TLS;
    delete process.env.PG_CA_CERT;
    ({ buildPgSslConfig } = await import('../src/server/database.ts'));
  });

  it('CA unset → unverified: { rejectUnauthorized: false }, not fail-closed', () => {
    const d = buildPgSslConfig({ NODE_ENV: 'production' });
    expect(d.mode).toBe('unverified');
    expect(d.ssl).toEqual({ rejectUnauthorized: false });
    expect(d.failClosed).toBe(false);
    expect(d.warning).toBeNull();
  });

  it('CA unset in production flags the UNVERIFIED decision for the boot log', () => {
    const d = buildPgSslConfig({ NODE_ENV: 'production' });
    expect(d.mode).toBe('unverified');
    expect(d.isProduction).toBe(true);
  });

  it('PG_REQUIRE_DB_TLS=1 + missing CA → failClosed (deployments that prefer fail-closed exit(1))', () => {
    for (const flag of ['1', 'true']) {
      const d = buildPgSslConfig({ PG_REQUIRE_DB_TLS: flag, NODE_ENV: 'production' });
      expect(d.mode).toBe('unverified');
      expect(d.failClosed).toBe(true);
    }
  });

  it('PG_REQUIRE_DB_TLS unset/other → not fail-closed (owner gate: do not take prod down before the CA exists)', () => {
    for (const flag of [undefined, '', '0', 'false', 'yes']) {
      const d = buildPgSslConfig({ PG_REQUIRE_DB_TLS: flag, NODE_ENV: 'production' });
      expect(d.failClosed).toBe(false);
    }
  });

  it('fail-closed is respected in development too (explicit opt-in is environment-independent)', () => {
    const d = buildPgSslConfig({ PG_REQUIRE_DB_TLS: '1', NODE_ENV: 'development' });
    expect(d.failClosed).toBe(true);
  });
});

describe('buildPgSslConfig — weak/empty PG_CA_CERT treated as unset (loud warn)', () => {
  let buildPgSslConfig: (env?: any) => any;

  beforeAll(async () => {
    delete process.env.DATABASE_URL;
    delete process.env.PG_REQUIRE_DB_TLS;
    delete process.env.PG_CA_CERT;
    ({ buildPgSslConfig } = await import('../src/server/database.ts'));
  });

  it('empty string → treated as unset, mode unverified, warning present', () => {
    const d = buildPgSslConfig({ PG_CA_CERT: '', NODE_ENV: 'production' });
    expect(d.mode).toBe('unverified');
    expect(d.ssl).toEqual({ rejectUnauthorized: false });
    expect(d.warning).toBeTruthy();
    expect(d.warning).toContain('PG_CA_CERT');
  });

  it('whitespace-only → treated as unset', () => {
    const d = buildPgSslConfig({ PG_CA_CERT: '   \n\t  ' });
    expect(d.mode).toBe('unverified');
    expect(d.warning).toBeTruthy();
  });

  it('too-short garbage ("abc") → treated as unset with loud warning', () => {
    const d = buildPgSslConfig({ PG_CA_CERT: 'abc' });
    expect(d.mode).toBe('unverified');
    expect(d.warning).toBeTruthy();
    expect(String(d.warning)).toMatch(/too short|unusable/i);
  });

  it('valid base64 but NOT a PEM certificate → treated as unset with loud warning', () => {
    const notPem = base64Of('hello world this is definitely not a certificate payload at all');
    const d = buildPgSslConfig({ PG_CA_CERT: notPem });
    expect(d.mode).toBe('unverified');
    expect(d.ssl).toEqual({ rejectUnauthorized: false });
    expect(String(d.warning)).toMatch(/not a PEM certificate/i);
  });

  it('non-base64 characters → treated as unset with loud warning', () => {
    const d = buildPgSslConfig({ PG_CA_CERT: '!!!not-base64!!!'.repeat(6) });
    expect(d.mode).toBe('unverified');
    expect(d.warning).toBeTruthy();
  });

  it('warnings never echo certificate material (names only, never values)', () => {
    const b64 = base64Of(PEM_PEM);
    const bad = 'abc' + b64.slice(0, 80); // invalid → warn, but carries cert fragments
    const d = buildPgSslConfig({ PG_CA_CERT: bad });
    expect(d.warning).toBeTruthy();
    expect(d.warning).not.toContain(PEM_PEM);
    expect(d.warning).not.toContain(b64);
  });
});

describe('database.ts — pool wiring consumes the builder (single decision source)', () => {
  it('createPoolForString sources ssl exclusively from the buildPgSslConfig decision', () => {
    expect(databaseSrc).toContain('dbTlsDecision = applyDbTlsDecision(buildPgSslConfig(process.env))');
    expect(databaseSrc).toContain('ssl: useSsl ? dbTlsDecision.ssl : undefined');
  });

  it('NO pool config bypasses the builder with a literal rejectUnauthorized: false', () => {
    // Extract every `new pg.Pool({...})` construction site and assert none of
    // them hardcodes the unverified literal — the ssl option must come from
    // the buildPgSslConfig decision (occurrences of the literal outside the
    // builder are comments/docs only).
    const poolConfigs = databaseSrc.match(/new pg\.Pool\(\{[\s\S]*?\}\)/g) || [];
    expect(poolConfigs.length).toBeGreaterThanOrEqual(1);
    for (const cfg of poolConfigs) {
      expect(cfg).toContain('dbTlsDecision.ssl');
      expect(cfg).not.toContain('rejectUnauthorized: false');
    }
  });

  it('verified mode is passed through for EVERY pool creation site (primary + startup probe)', () => {
    expect(databaseSrc.match(/createPoolForString\(/g)!.length).toBeGreaterThanOrEqual(2);
  });

  it('boot log prints [DB-TLS] mode=… names only (verified/unverified), plus the production CRITICAL message', () => {
    expect(databaseSrc).toContain('[DB-TLS] mode=verified');
    expect(databaseSrc).toContain('[DB-TLS] mode=unverified');
    expect(databaseSrc).toContain(
      '[DB-TLS] UNVERIFIED: set PG_CA_CERT (base64 PEM from your provider console)'
    );
    // Names only: the log line must not interpolate any certificate value.
    expect(databaseSrc).not.toMatch(/\[DB-TLS\] mode=\$\{/);
  });

  it('PG_REQUIRE_DB_TLS=1 fail-closed path aborts boot (exit(1))', () => {
    expect(databaseSrc).toMatch(/PG_REQUIRE_DB_TLS[\s\S]{0,200}process\.exit\(1\)/);
  });
});

describe('GET /api/users/me/export — scope, isolation, budget (static source)', () => {
  const exportHandler = extractHandler(serverSrc, "app.get('/api/users/me/export', requireAuth");

  it('route requires authentication (requireAuth)', () => {
    expect(exportHandler).toContain("app.get('/api/users/me/export', requireAuth");
  });

  it('enforces the 5/hour/user critical export budget (export:data:user)', () => {
    expect(exportHandler).toContain("checkLimit('export:data:user'");
    const rule = (RATE_LIMIT_RULES as any)['export:data:user'];
    expect(rule).toMatchObject({ limit: 5, windowMs: 60 * 60 * 1000, class: 'critical' });
  });

  it('responds as a JSON download (Content-Disposition attachment)', () => {
    expect(exportHandler).toContain("Content-Type', 'application/json; charset=utf-8'");
    expect(exportHandler).toContain("Content-Disposition");
    expect(exportHandler).toContain('attachment');
  });

  it('ownership isolation: chats come from the membership boundary (getChatsForUser), never a raw table scan', () => {
    expect(exportHandler).toContain('db.getChatsForUser(userId)');
    expect(exportHandler).not.toMatch(/from chats/i);
    expect(exportHandler).not.toMatch(/from users/i);
    expect(exportHandler).not.toMatch(/from messages/i);
    expect(exportHandler).not.toMatch(/from auth_logs/i);
  });

  it('deleted_for is respected per viewer (messages hidden-for-me are excluded)', () => {
    expect(exportHandler).toContain('deletedFor || []).includes(userId)');
  });

  it('NEVER includes refresh-token material in the sessions projection', () => {
    expect(exportHandler).toContain('db.getUserSessions(userId)');
    // The projection whitelists exactly these fields:
    expect(exportHandler).toContain('isRevoked: s.isRevoked');
    expect(exportHandler).toContain('ipAddress: s.ipAddress');
    expect(exportHandler).not.toContain('refreshToken');
    expect(exportHandler).not.toContain('s.refreshToken');
  });

  it('NEVER includes secrets: no getUserSecrets, no credentials_encrypted, no password fields', () => {
    expect(exportHandler).not.toContain('getUserSecrets');
    expect(exportHandler).not.toContain('credentials_encrypted');
    expect(exportHandler).not.toContain('password');
  });

  it('includes attachments as METADATA only (documented: blobs live in the user\'s own Drive)', () => {
    expect(exportHandler).toContain('attachmentsMetadata');
    expect(exportHandler).toContain("blobs live in the user's own cloud storage");
  });

  it('includes own auth-action log + own E2EE PUBLIC keys via dedicated db projections', () => {
    expect(exportHandler).toContain('db.getExportAuthLogs(userId');
    expect(exportHandler).toContain('db.getExportE2eePublicKeys(userId)');
  });

  it('streams section-by-section (res.write), never one O(whole-payload) stringify', () => {
    expect(exportHandler).toContain('res.write(');
    expect(exportHandler).toContain('res.end()');
    expect(exportHandler).not.toContain('JSON.stringify(payload');
  });

  it('declares explicit size limits inside the payload', () => {
    expect(exportHandler).toContain('MESSAGES_PER_CHAT');
    expect(exportHandler).toContain('AUTH_LOG_LIMIT');
    expect(exportHandler).toContain('SESSION_LIMIT');
    expect(exportHandler).toContain('"limits"');
  });
});

describe('database.ts — export helper projections are public-only', () => {
  it('getExportE2eePublicKeys selects ONLY public key columns', () => {
    const start = databaseSrc.indexOf('public async getExportE2eePublicKeys');
    expect(start).toBeGreaterThan(-1);
    const block = databaseSrc.slice(start, databaseSrc.indexOf('public async', start + 10));
    for (const col of ['identity_dh_pub', 'identity_sig_pub', 'signed_prekey_pub', 'prekey_signature', 'pq_prekey_pub', 'pq_prekey_signature']) {
      expect(block).toContain(col);
    }
    // Public-only contract: private key columns do not exist in the schema and
    // must never be referenced here.
    expect(block).not.toMatch(/private/i);
  });

  it('getExportAuthLogs returns entries for ONE user only, hard-capped', () => {
    const start = databaseSrc.indexOf('public async getExportAuthLogs');
    expect(start).toBeGreaterThan(-1);
    const block = databaseSrc.slice(start, databaseSrc.indexOf('public async', start + 10));
    expect(block).toContain('WHERE user_id = $1');
    expect(block).toMatch(/LIMIT \$2/);
    expect(block).toContain('Math.min(1000');
  });
});
