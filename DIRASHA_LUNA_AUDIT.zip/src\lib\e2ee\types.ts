/**
 * Dirasha E2EE — types & persisted shapes.
 *
 * Contract: E2EE-SPEC.md ("Identity & keys", "Client lib (Agent C)", "Integration (Agent I)").
 * All binary values persisted through the KVStore are std-base64 strings (plain
 * base64 std alphabet everywhere — never b64url).
 */

/** Raw key pair. `pub`/`priv` are 32-byte Uint8Arrays (X25519 or Ed25519). */
export interface KeyPair {
  priv: Uint8Array;
  pub: Uint8Array;
}

/* ── Wire format ──────────────────────────────────────────────────────────── */

/** X3DH block carried on the initiator's FIRST message of a session. */
export interface X3dhBlock {
  /** b64 of the initiator's fresh ephemeral X25519 public key. */
  ek: string;
  /** Consumed one-time prekey id, present iff the responder's bundle offered an OPK. */
  opkId?: number;
  /**
   * PQXDH — SESSION-LOCAL ONLY: b64 of the 1088-byte ML-KEM-768 ciphertext
   * (PQ_CT) the initiator encapsulated against the responder's PQ prekey,
   * carried inside the persisted `pendingX3dh` so every bootstrap-carrying
   * message can re-attach it at the ENVELOPE level (env.pqCt) until the
   * session is confirmed. Stripped from the wire x3dh block (no double
   * carriage of the 1088B ciphertext); the responder reads env.pqCt.
   */
  pqCt?: string;
}

/** Message header of the Double Ratchet. */
export interface RatchetHeader {
  /** b64 of the sender's CURRENT ratchet (DH) public key. */
  dh: string;
  /** Number of messages in the sender's previous receiving chain. */
  pn: number;
  /** Sequence number in the sender's current sending chain. */
  n: number;
}

/** Parsed wire envelope: content === 'DIR1:' + b64(JSON.stringify(Envelope)). */
export interface Envelope {
  v: number;
  /** b64 of the SENDER's identity DH public key (constant across the session). */
  ik: string;
  x3dh?: X3dhBlock;
  hdr: RatchetHeader;
  /** b64 of the 12-byte ChaCha20-Poly1305 nonce. */
  iv: string;
  /** b64 of ciphertext + 16-byte Poly1305 tag. */
  ct: string;
  /** Sender's deviceId (multi-device). Legacy senders omit it → treated as 'default'. */
  sd?: string;
  /** Target deviceId — present only when single-device routing needs it (unused in DIRM1, where the outer `d` routes). */
  td?: string;
  /** 1 = ciphertext is bucket-padded (Project 6 message padding). Absent = legacy unpadded. */
  p?: number;
  /**
   * PQXDH (design doc §3.3): 1 = this envelope's session was bootstrapped
   * PQ-hybrid (X3DH + ML-KEM-768). Present ONLY on bootstrap-carrying
   * messages, alongside `pqCt`. Absent = classical X3DH.
   */
  pq?: 1;
  /**
   * b64 of the 1088-byte ML-KEM-768 ciphertext — present iff `pq === 1`.
   * The responder decapsulates it with its PQ prekey priv to recover PQ_SS.
   */
  pqCt?: string;
}

/**
 * One per-device entry inside a DIRM1 container.
 * Wire: 'DIRM1:' + b64(JSON.stringify(MultiEnvelope)).
 */
export interface MultiEnvelope {
  v: number;
  devices: Array<{ d: string; env: Envelope }>;
}

/** One device entry of the server bundle (GET /api/e2ee/bundle/:userId → {registered, devices}). */
export interface PeerDevice {
  deviceId: string;
  identityDhPub: string;
  identitySigPub: string;
  signedPrekeyPub: string;
  prekeySignature: string;
  opk: { id: number; pub: string } | null;
  /**
   * PQXDH (design doc §3.3): true iff the device registered a quantum prekey.
   * The initiator MUST run the hybrid exchange for pq:true devices — no
   * silent classical downgrade (see initSessionAsInitiator). Absent/false on
   * legacy (pre-migration) devices → classical X3DH.
   */
  pq?: boolean;
  /** b64 of the device's 1184-byte ML-KEM-768 encapsulation key (present iff pq). */
  pqPrekeyPub?: string;
  /**
   * b64 of the 64-byte Ed25519 signature over
   * 'DirashaPQSPK-v1:' + b64(spkPub) + b64(pqPub) made with IK_sig —
   * verified by the CLIENT against identitySigPub at session init.
   */
  pqPrekeySignature?: string;
}

/* ── Persisted shapes (values stored in the KVStore, JSON-serialized) ─────── */

/** kv key 'identity' — full identity (private keys never leave the device). */
export interface IdentityRecord {
  /** X25519 identity DH key pair (IK_dh). */
  dh: { priv: string; pub: string };
  /** Ed25519 identity signing key pair (IK_sig). */
  sig: { priv: string; pub: string };
  registered: boolean;
  /**
   * This device's id (crypto.randomUUID() at first creation, persisted).
   * Re-registration from the same store reuses it → the server replaces this
   * device's row only. Optional for legacy (pre-multi-device) stored identities;
   * assigned lazily on first use.
   */
  deviceId?: string;
}

/** kv key 'spkPriv' — signed prekey private material + its Ed25519 signature. */
export interface SpkRecord {
  priv: string;
  pub: string;
  /** Ed25519 signature over UTF8('DirashaSPK-v1:' + b64(spkPub)) made with IK_sig. */
  sig: string;
}

/**
 * kv key 'opk:<keyId>' — one-time prekey private material (never uploaded).
 * Lifecycle (P4): deleted by the engine once CONFIRMED USED — i.e. after the
 * bootstrap message that consumed it verified (AEAD) and the derived responder
 * session was persisted (persist-session-then-delete-priv). Never deleted
 * while merely received: privs of OPKs not yet consumed by any delivered
 * bootstrap stay until confirmed used. Identity and SPK privs are never
 * deleted here.
 */
export interface OpkRecord {
  priv: string;
  pub: string;
}

/**
 * kv key 'pqpq-priv' — the device's ML-KEM-768 PQ prekey (PQXDH, design doc
 * §3.1). The 2400-byte decapsulation key NEVER leaves the device; it is stored
 * through the same KVStore as every other private key, so in production
 * (VaultKVStore) it is vault-encrypted automatically. `pub` (1184 bytes b64)
 * is advertised in the register call and echoed back in bundles.
 */
export interface PqPrekeyRecord {
  priv: string;
  pub: string;
}

/**
 * Double Ratchet state per PEER DEVICE (kv key 'session:<peerId>:<peerDeviceId>';
 * legacy single-session stores used plain 'session:<peerId>' — migrated lazily
 * on decrypt). All binary fields are std-b64.
 * skipped key format: Record<'<dhRemoteB64>:<n>', mkB64>, capped at MAX_SKIP.
 */
export interface SessionState {
  rk: string;
  dhSelfPriv: string;
  dhSelfPub: string;
  dhRemote: string | null;
  ckS: string | null;
  ckR: string | null;
  nS: number;
  nR: number;
  pn: number;
  skipped: Record<string, string>;
  /** b64 of OUR identity DH pub (AD 'ik' field when we send). */
  ikSelf: string;
  /** b64 of the PEER's identity DH pub (AD 'ik' field when they send). */
  ikRemote: string;
  /** Set on X3DH init; attached to the FIRST outgoing envelope then cleared. */
  pendingX3dh?: X3dhBlock;
  /**
   * Ephemeral-key `ek` (b64) of the X3DH bootstrap that created/last rebuilt
   * this session. Replay-rollback guard: an inbound envelope whose `x3dh.ek`
   * EQUALS this value but which fails ratchet decryption is a REPLAY of the
   * session's first message — rebuilding a responder session from it would
   * deterministically re-derive the original SK and roll the ratchet chain
   * back. The engine fails closed (TamperedError) instead.
   */
  bootstrappedEk?: string;
  /**
   * Identity generations (ik b64 values) this session previously trusted and
   * then replaced via a newer bootstrap, oldest-first, capped at 4.
   * Cross-generation rollback guard: an inbound bootstrap whose `ik` matches
   * NEITHER the current `ikRemote` NOR an entry here is a legit rekey; one
   * matching a RETIRED entry is a replay of a PRE-rekey bootstrap — rebuilding
   * from it would resurrect pre-rekey ratchet state and re-enable pre-rekey
   * ciphertext after the peer rekeyed. The engine fails closed
   * (RekeyDetectedError) instead. Undefined on initiator-built sessions and
   * pre-existing persisted state (check skipped — graceful degradation).
   */
  retiredIks?: string[];
  /**
   * Bootstrap ephemeral-key generations (x3dh.ek b64 values) this session
   * previously trusted and then replaced via a NEWER bootstrap of the SAME
   * peer identity, oldest-first, capped at 4. Same-identity cross-generation
   * replay guard: an inbound bootstrap whose ek matches an entry here is a
   * replay of an OLDER session's first message — rebuilding from it would
   * roll the ratchet back. The engine fails closed (TamperedError) instead,
   * INDEPENDENT of whether that generation's OPK priv still exists (it is
   * deleted after confirmed use — P4 — and must never be needed to reject a
   * replay). Undefined on initiator-built sessions and pre-existing persisted
   * state (check skipped — graceful degradation).
   */
  retiredEks?: string[];
  /**
   * PQXDH documentation flag (design doc §3.3): true iff this session was
   * bootstrapped with the hybrid (X3DH + ML-KEM-768) derivation. Informational
   * only — the wire evidence is the envelope's pq:1 + pqCt fields.
   */
  pq?: boolean;
  createdAt: number;
}

/* ── KVStore ──────────────────────────────────────────────────────────────── */

/**
 * Minimal async key/value persistence. Values are opaque strings (JSON).
 * Key namespaces used by the engine: 'identity', 'spkPriv', 'opk:<keyId>',
 * 'session:<peerUserId>:<peerDeviceId>' (plus legacy plain 'session:<peerUserId>').
 */
export interface KVStore {
  get(key: string): Promise<string | null>;
  set(key: string, value: string): Promise<void>;
  del(key: string): Promise<void>;
  keys(): Promise<string[]>;
}

/* ── Typed errors (failure UX contract for Agent I) ───────────────────────── */

/** Base class for all E2EE errors — lets callers catch the whole family. */
export class E2eeError extends Error {
  constructor(message = 'E2EE error') {
    super(message);
    this.name = 'E2eeError';
  }
}

/** Peer has no E2EE registration on the server (bundle/identity 404). Send plaintext fallback. */
export class PeerNotRegisteredError extends E2eeError {
  constructor(message = 'peer is not registered for E2EE') {
    super(message);
    this.name = 'PeerNotRegisteredError';
  }
}

/** Generic decryption failure (bad state, missing key material, rekey needed). */
export class DecryptFailedError extends E2eeError {
  constructor(message = 'failed to decrypt message') {
    super(message);
    this.name = 'DecryptFailedError';
  }
}

/** No session with this peer and the message carries no X3DH bootstrap. */
export class SessionMissingError extends E2eeError {
  constructor(message = 'no session with peer') {
    super(message);
    this.name = 'SessionMissingError';
  }
}

/**
 * The peer's canonical identity changed (re-registration) and the incoming
 * message carries no X3DH bootstrap, so the existing session can never match.
 * The UI shows a PERSISTENT warning — the user must explicitly verify the new
 * safety number / reset the session. Not auto-recoverable by design.
 */
export class RekeyDetectedError extends E2eeError {
  constructor(message = 'peer identity changed — safety number must be re-verified') {
    super(message);
    this.name = 'RekeyDetectedError';
  }
}

/** Ciphertext/AAD/signature verification failed — likely tampering or corruption. */
export class TamperedError extends DecryptFailedError {
  constructor(message = 'message failed integrity verification') {
    super(message);
    this.name = 'TamperedError';
  }
}
