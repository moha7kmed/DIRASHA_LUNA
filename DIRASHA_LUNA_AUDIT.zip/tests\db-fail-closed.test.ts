/**
 * External-audit remediation — DB layer fail-closed guarantees.
 *
 * Covers the four audit items owned by src/server/database.ts:
 *
 *   DATA-01  no silent in-memory fallback in production:
 *            - PG error classification (isPgConnectionClassError): only
 *              connection-class failures flip isPostgresHealthy; SQL /
 *              constraint / permission / syntax errors (42xxx, 42601, 42501,
 *              23505, 23503, 28000, 28P01) never do.
 *            - Production + DATABASE_URL + failed boot connection/migrations
 *              → THROW (constructor exits 1) instead of memory-mode serving.
 *
 *   TLS-01   invalid configured CA/cert material + PG_REQUIRE_DB_TLS=1 must
 *            fail closed (detailed behavioral coverage lives in
 *            tests/db-tls.test.ts; here we pin the source contract).
 *
 *   AUTH-01  atomic refresh-token rotation DB layer (compare-and-swap):
 *            rotateRefreshTokenCas / markRefreshTokenSpent /
 *            isRefreshTokenSpent / revokeSessionFamily + migration v13
 *            (spent_refresh_tokens + user_sessions.family_id) — HASHES ONLY,
 *            raw tokens never persisted.
 *
 *   DB-01    RLS posture: the architectural decision block (deferred RLS with
 *            rationale) must exist — enabling RLS blindly against a single
 *            owner connection user would be a no-op or an outage.
 *
 * The behavioral section runs the memory-mode engine in a TEMP cwd (so the
 * real data/ snapshot is never touched) and pins the CAS semantics the
 * auth-service layer depends on.
 *
 * Run: npx vitest run tests/db-fail-closed.test.ts
 */
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import fs from 'fs';
import os from 'os';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const databaseSrc = fs.readFileSync(path.join(repoRoot, 'src', 'server', 'database.ts'), 'utf8');

/** Extract the source block from `start` up to the next top-level member marker. */
function extractBlock(src: string, needle: string): string {
  const start = src.indexOf(needle);
  expect(start, `source block not found: ${needle}`).toBeGreaterThan(-1);
  const next = src.indexOf('\n  public ', start + needle.length);
  const nextPrivate = src.indexOf('\n  private ', start + needle.length);
  const candidates = [next, nextPrivate].filter(i => i > 0);
  const end = candidates.length > 0 ? Math.min(...candidates) : src.length;
  return src.slice(start, end);
}

/** Slice between two exact source needles (for module-level function blocks). */
function sliceBetween(src: string, startNeedle: string, endNeedle: string): string {
  const start = src.indexOf(startNeedle);
  expect(start, `start needle not found: ${startNeedle}`).toBeGreaterThan(-1);
  const end = src.indexOf(endNeedle, start + startNeedle.length);
  expect(end, `end needle not found: ${endNeedle}`).toBeGreaterThan(-1);
  return src.slice(start, end);
}

// ── DATA-01: error classification + production fail-fast ─────────────────────
describe('DATA-01 — PG error classification (no silent memory fallback on SQL errors)', () => {
  it('connection-class classifier exists with the exact required code set', () => {
    expect(databaseSrc).toContain('function isPgConnectionClassError(err: any): boolean');
    // transport codes
    for (const code of ['ECONNREFUSED', 'ETIMEDOUT', 'ENOTFOUND', 'ECONNRESET', 'EPIPE']) {
      expect(databaseSrc).toContain(`'${code}'`);
    }
    // PG server connection-class codes: admin_shutdown / cannot_connect_now / 08xxx
    for (const code of ['57P01', '57P03', '08000', '08006']) {
      expect(databaseSrc).toContain(`'${code}'`);
    }
  });

  it('pgQuery flips health ONLY on connection-class errors (SQL-class keeps PG healthy)', () => {
    const pgQueryBlock = sliceBetween(databaseSrc, 'async function pgQuery(', 'function queuePg(');
    expect(pgQueryBlock).toContain('if (isPgConnectionClassError(err)) {');
    expect(pgQueryBlock).toContain('isPostgresHealthy = false;');
    expect(pgQueryBlock).toContain('SQL-class');
    // The old behavior — unconditional flip in the catch — must be gone:
    // the flip may only appear inside the connection-class branch.
    const flipCount = pgQueryBlock.match(/isPostgresHealthy = false/g)!.length;
    expect(flipCount).toBe(1);
  });

  it('queuePg also uses the connection-class classifier (password-auth errors no longer flip)', () => {
    const queuePgBlock = sliceBetween(databaseSrc, 'function queuePg(', 'POLL_ATTACHMENT_MIME');
    expect(queuePgBlock).toContain('if (isPgConnectionClassError(err)) isPostgresHealthy = false;');
    // the legacy misclassification (28P01 treated as connection error) is gone
    expect(queuePgBlock).not.toContain('password authentication failed');
    expect(databaseSrc).not.toContain('function isConnectionError(');
  });

  it('pool.query proxy uses the same classifier (no message-regex flip on statement timeouts)', () => {
    const poolQueryBlock = extractBlock(databaseSrc, 'export const pool = {');
    expect(poolQueryBlock).toContain('isPgConnectionClassError(err)');
    expect(poolQueryBlock).not.toMatch(/ENOTFOUND\|tenant\|connection refused\|timeout/);
  });

  it('production boot fail-fast: init() throws when DATABASE_URL is set but PG is unusable', () => {
    expect(databaseSrc).toContain('FATAL (DATA-01): DATABASE_URL is configured and PostgreSQL is unreachable or unfinished at boot');
    expect(databaseSrc).toContain('PostgreSQL became unreachable during boot-time schema/migration setup');
    // the constructor must abort the process in production (fail-fast shape)
    const ctorBlock = databaseSrc.slice(databaseSrc.indexOf('  constructor() {'), databaseSrc.indexOf('  public async init('));
    expect(ctorBlock).toContain("process.env.NODE_ENV === 'production'");
    expect(ctorBlock).toContain('process.exit(1)');
    expect(ctorBlock).toContain('Boot aborted (DATA-01 fail-fast)');
  });

  it('bootstrapPostgresSchema and runPgMigrations rethrow in production (reach the fail-fast path)', () => {
    const schemaBlock = databaseSrc.slice(
      databaseSrc.indexOf('public async bootstrapPostgresSchema'),
      databaseSrc.indexOf('public async resetAndWipeAllUsersAndData')
    );
    expect(schemaBlock).toMatch(/NODE_ENV === 'production'\) throw e/);
    const migrationCatch = databaseSrc.slice(databaseSrc.indexOf('async function runPgMigrations'));
    expect(migrationCatch).toMatch(/NODE_ENV === 'production'\) throw err/);
  });
});

// ── TLS-01: invalid configured material fails closed ─────────────────────────
describe('TLS-01 — invalid configured CA/cert material fails closed under PG_REQUIRE_DB_TLS', () => {
  it('buildPgSslConfig invalid-pinned branch computes failClosed from the require flag', () => {
    const pinnedBranch = databaseSrc.slice(
      databaseSrc.indexOf('const ownerAnchor = decodeOwnerAnchorPem(env.PG_DB_CERT_PEM);'),
      databaseSrc.indexOf('const caMissing = decoded.error;')
    );
    expect(pinnedBranch).toContain("env.PG_REQUIRE_DB_TLS === '1' || env.PG_REQUIRE_DB_TLS === 'true'");
    expect(pinnedBranch).toContain('failClosed: requireTls');
    expect(pinnedBranch).toContain('TLS-01');
  });

  it('the fail-closed boot abort covers BOTH material sources (PG_CA_CERT and PG_DB_CERT_PEM)', () => {
    expect(databaseSrc).toContain('PG_CA_CERT and/or PG_DB_CERT_PEM) is missing or invalid');
    expect(databaseSrc).toMatch(/PG_REQUIRE_DB_TLS[\s\S]{0,200}process\.exit\(1\)/);
  });
});

// ── AUTH-01: atomic refresh-token rotation DB layer ──────────────────────────
describe('AUTH-01 — CAS rotation DB layer: exact signatures + migration v13', () => {
  it('rotateRefreshTokenCas — exact signature the auth-service layer calls', () => {
    expect(databaseSrc).toContain(
      "public async rotateRefreshTokenCas(sessionId: string, currentHash: string, newHash: string, newExpiresAt: string): Promise<'rotated' | 'stale' | 'not-found'>"
    );
    const block = extractBlock(databaseSrc, 'public async rotateRefreshTokenCas(');
    // atomic compare-and-swap predicate (id + current hash + not revoked)
    expect(block).toContain('WHERE id = $3 AND refresh_token_hash = $4 AND is_revoked = FALSE');
    expect(block).toContain("'stale' : 'not-found'");
  });

  it('markRefreshTokenSpent / isRefreshTokenSpent — exact signatures', () => {
    expect(databaseSrc).toContain('public async markRefreshTokenSpent(sessionId: string, spentHash: string): Promise<void>');
    expect(databaseSrc).toContain('public async isRefreshTokenSpent(sessionId: string, tokenHash: string): Promise<boolean>');
  });

  it('revokeSessionFamily — exact signature + family-wide revocation', () => {
    expect(databaseSrc).toContain('public async revokeSessionFamily(sessionId: string): Promise<void>');
    const block = extractBlock(databaseSrc, 'public async revokeSessionFamily(');
    expect(block).toContain('family_id = (SELECT family_id FROM user_sessions WHERE id = $1');
    // conservative fallback for NULL family_id rows (pre-migration leftovers)
    expect(block).toContain('family_id IS NULL AND user_id = (SELECT user_id FROM user_sessions WHERE id = $1)');
  });

  it('migration v13: spent_refresh_tokens + user_sessions.family_id backfill', () => {
    const m13 = databaseSrc.slice(databaseSrc.indexOf('version: 13'), databaseSrc.indexOf('version: 13') + 4000);
    expect(m13).toContain('CREATE TABLE IF NOT EXISTS spent_refresh_tokens (');
    expect(m13).toContain('id BIGSERIAL PRIMARY KEY');
    expect(m13).toContain('session_id VARCHAR(128) NOT NULL');
    expect(m13).toContain('token_hash TEXT NOT NULL');
    expect(m13).toContain('spent_at TIMESTAMPTZ NOT NULL DEFAULT now()');
    expect(m13).toContain('CREATE INDEX IF NOT EXISTS idx_spent_refresh_tokens_session ON spent_refresh_tokens (session_id);');
    // the sessions table in this schema is user_sessions (auth_sessions does not exist)
    expect(m13).toContain('ALTER TABLE user_sessions ADD COLUMN IF NOT EXISTS family_id VARCHAR(64);');
    expect(m13).toContain('UPDATE user_sessions SET family_id = id WHERE family_id IS NULL;');
  });

  it('HASHES ONLY: raw tokens never reach spent_refresh_tokens or the session row', () => {
    const spentInsert = databaseSrc.indexOf('INSERT INTO spent_refresh_tokens');
    expect(spentInsert).toBeGreaterThan(-1);
    const insertBlock = databaseSrc.slice(spentInsert, spentInsert + 200);
    // parameterized hash columns only — no raw-token value ever interpolated
    expect(insertBlock).toContain('(session_id, token_hash) VALUES ($1, $2)');
    // createSession persists hashToken(session.refreshToken), never the raw token
    const createBlock = extractBlock(databaseSrc, 'public async createSession(');
    expect(createBlock).toContain('const tokenHash = hashToken(session.refreshToken)');
    expect(databaseSrc).toContain('HASHES ONLY');
  });

  it('new sessions inherit family_id (createSession stamps family_id = provided family / own id)', () => {
    const createBlock = extractBlock(databaseSrc, 'public async createSession(');
    expect(createBlock).toContain('family_id: family');
    expect(createBlock).toContain("familyId || (session as any).familyId || session.id");
    expect(createBlock).toContain('family_id, updated_at');
  });

  it('memory mirror: spentRefreshTokens map exists, is snapshotted and rehydrated', () => {
    expect(databaseSrc).toContain('spentRefreshTokens: new Map<string, Set<string>>()');
    expect(databaseSrc).toContain('spentRefreshTokens: Array.from(memoryStore.spentRefreshTokens.entries())');
    expect(databaseSrc).toContain('data.spentRefreshTokens.forEach');
  });
});

// ── DB-01: recorded RLS posture ──────────────────────────────────────────────
describe('DB-01 — RLS posture is a documented architectural decision (not blindly enabled)', () => {
  it('the architectural decision block exists near the migrations with the rationale', () => {
    expect(databaseSrc).toContain('ARCHITECTURAL DECISION — Row Level Security (DB-01, external audit)');
    expect(databaseSrc).toMatch(/RLS is DEFERRED, deliberately/);
    // rationale: single owner connection user → no-op / outage; app-layer authz
    expect(databaseSrc).toMatch(/FORCE ROW LEVEL SECURITY/);
    expect(databaseSrc).toMatch(/sendGate\/requireAuth/);
  });

  it('no migration blindly enables RLS (ENABLE ROW LEVEL SECURITY must not appear as executable SQL)', () => {
    const migrationsBlock = databaseSrc.slice(
      databaseSrc.indexOf('const MIGRATIONS: { version: number; sql: string }[] = ['),
      databaseSrc.indexOf('ARCHITECTURAL DECISION')
    );
    expect(migrationsBlock).not.toMatch(/^\s*(ALTER|CREATE) TABLE [^;]*ENABLE ROW LEVEL SECURITY/m);
  });
});

// ── Behavioral: memory-mode CAS semantics (temp cwd — real snapshot untouched) ──
describe('AUTH-01 behavioral — memory-mode CAS semantics (isolated temp cwd)', () => {
  let db: any;

  const h = (t: string) => crypto.createHash('sha256').update(t).digest('hex');
  const NOW = new Date().toISOString();
  const FUTURE = new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString();

  beforeAll(async () => {
    // DATA_DIR / SNAPSHOT_FILE are computed from process.cwd() AT IMPORT —
    // point cwd at a throwaway temp dir so the real data/ snapshot is never
    // read or written by this test file.
    const tmp = path.join(os.tmpdir(), `dirasha-db-failclosed-test-${process.pid}-${Date.now()}`);
    fs.rmSync(tmp, { recursive: true, force: true });
    fs.mkdirSync(tmp, { recursive: true });
    process.chdir(tmp);

    delete process.env.DATABASE_URL;
    delete process.env.PG_REQUIRE_DB_TLS;
    delete process.env.PG_CA_CERT;
    delete process.env.PG_DB_CERT_PEM;
    ({ db } = await import('../src/server/database.ts'));
  });

  afterAll(() => {
    try { process.chdir(repoRoot); } catch { /* worker teardown */ }
  });

  const mkSession = (id: string, userId: string, rawToken: string) => ({
    id,
    userId,
    refreshToken: rawToken,
    userAgent: 'vitest-agent',
    ipAddress: '127.0.0.1',
    isRevoked: false,
    expiresAt: FUTURE,
    createdAt: NOW
  });

  it('rotateRefreshTokenCas: rotated → replay-stale → wrong-hash-stale → not-found', async () => {
    await db.createSession(mkSession('sess-cas-1', 'user-cas', 'raw-one'));

    expect(await db.rotateRefreshTokenCas('sess-cas-1', h('raw-one'), h('raw-two'), FUTURE)).toBe('rotated');
    // the CONSUMED token can never rotate again (reuse → stale)
    expect(await db.rotateRefreshTokenCas('sess-cas-1', h('raw-one'), h('raw-three'), FUTURE)).toBe('stale');
    // wrong current hash → stale
    expect(await db.rotateRefreshTokenCas('sess-cas-1', h('wrong'), h('raw-four'), FUTURE)).toBe('stale');
    // unknown session → not-found
    expect(await db.rotateRefreshTokenCas('sess-does-not-exist', h('raw-one'), h('x'), FUTURE)).toBe('not-found');

    // the winning rotation actually took effect (old token gone, new resolves)
    expect(await db.getSessionByRefreshToken('raw-one')).toBeUndefined();
    const rotated = await db.getSessionByRefreshToken('raw-two');
    expect(rotated?.id).toBe('sess-cas-1');
  });

  it('two concurrent CAS rotations of the same token: exactly ONE wins', async () => {
    await db.createSession(mkSession('sess-race', 'user-race', 'raw-race'));

    const [a, b] = await Promise.all([
      db.rotateRefreshTokenCas('sess-race', h('raw-race'), h('race-a'), FUTURE),
      db.rotateRefreshTokenCas('sess-race', h('raw-race'), h('race-b'), FUTURE)
    ]);
    const results = [a, b].sort();
    expect(results).toEqual(['rotated', 'stale']);
    // exactly one successor token resolves; the loser's token never exists
    const winners = (await Promise.all([
      db.getSessionByRefreshToken('race-a'),
      db.getSessionByRefreshToken('race-b')
    ])).filter(Boolean);
    expect(winners.length).toBe(1);
  });

  it('markRefreshTokenSpent / isRefreshTokenSpent: consumed hash is detectable', async () => {
    await db.createSession(mkSession('sess-spent', 'user-spent', 'raw-s'));

    expect(await db.isRefreshTokenSpent('sess-spent', h('raw-s'))).toBe(false);
    await db.markRefreshTokenSpent('sess-spent', h('raw-s'));
    expect(await db.isRefreshTokenSpent('sess-spent', h('raw-s'))).toBe(true);
    // other hashes for the same session stay clean
    expect(await db.isRefreshTokenSpent('sess-spent', h('raw-t'))).toBe(false);
    expect(await db.isRefreshTokenSpent('sess-other', h('raw-s'))).toBe(false);
  });

  it('revokeSessionFamily revokes every session sharing family_id', async () => {
    // root login session (family roots itself) + a rotated-family member
    await db.createSession(mkSession('sess-fam-root', 'user-fam', 'raw-f0'));
    await db.createSession(mkSession('sess-fam-child', 'user-fam', 'raw-f1'), 'sess-fam-root');
    // unrelated session for the same user must NOT be in the family
    await db.createSession(mkSession('sess-fam-outsider', 'user-fam', 'raw-f2'), 'sess-fam-outsider');

    await db.revokeSessionFamily('sess-fam-root');

    expect(await db.getSessionByRefreshToken('raw-f0')).toBeUndefined();
    expect(await db.getSessionByRefreshToken('raw-f1')).toBeUndefined();
    const outsider = await db.getSessionByRefreshToken('raw-f2');
    expect(outsider?.id).toBe('sess-fam-outsider');
    expect(outsider?.isRevoked).toBe(false);
  });
});
