-- ============================================================================
-- dirasha SYSTEM SCHEMA (POSTGRESQL CAPABLE PRODUCTION DDL)
-- Principal Distributed Systems Architect + Real-Time Infrastructure Engineer
-- ============================================================================
-- ⚠️ SUPERSEDED (Phone-OTP Era): المرجع الحقيقي للسكيمة الآن هو
--    src/server/database.ts → bootstrapPostgresSchema()
--    جدول users الجديد: phone_number UNIQUE NOT NULL (بدلاً من email/password_hash/google_id)
--    + username UNIQUE (nullable حتى اكتمال الملف) + profile_completed BOOLEAN
--    + جدولا phone_otps و user_storage_accounts الجديدان
--    هذا الملف محفوظ للمرجعية التاريخية فقط.


-- Enable UUID Extension if not enabled
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. USERS TABLE
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(128) PRIMARY KEY, -- Matches Firebase UID for seamless secure authentication transition
    username VARCHAR(64) UNIQUE NOT NULL,
    display_name VARCHAR(128) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    avatar_url TEXT,
    banner_url TEXT,
    bio TEXT,
    verified BOOLEAN DEFAULT FALSE,
    online_status VARCHAR(16) DEFAULT 'offline',
    last_seen TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Indexing for username lookups and profile matching
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_online_status ON users(online_status);

-- 2. CHATS TABLE (CONVERSATIONAL ROOM METADATA)
CREATE TABLE IF NOT EXISTS chats (
    id VARCHAR(128) PRIMARY KEY, -- Deterministic UUID/String
    type VARCHAR(32) NOT NULL DEFAULT 'one-to-one', -- 'one-to-one' or 'group'
    name VARCHAR(128), -- NULL in direct messages
    avatar_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. CHAT MEMBER JUNCTION TABLE (Speed access to user rooms list)
CREATE TABLE IF NOT EXISTS chat_members (
    chat_id VARCHAR(128) REFERENCES chats(id) ON DELETE CASCADE,
    user_id VARCHAR(128) REFERENCES users(id) ON DELETE CASCADE,
    joined_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (chat_id, user_id)
);

-- Index for querying all conversations a user participates in
CREATE INDEX IF NOT EXISTS idx_chat_members_user_id ON chat_members(user_id);

-- 4. MESSAGES TABLE
CREATE TABLE IF NOT EXISTS messages (
    id VARCHAR(128) PRIMARY KEY, -- Message UID
    chat_id VARCHAR(128) NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
    sender_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    sender_name VARCHAR(128),
    content TEXT NOT NULL,
    type VARCHAR(32) NOT NULL DEFAULT 'text', -- 'text' or 'attachment'
    reply_to_id VARCHAR(128) REFERENCES messages(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    edited_at TIMESTAMP WITH TIME ZONE,
    deleted_at TIMESTAMP WITH TIME ZONE
);

-- High-performance cursor pagination index for fast sorting in channels
CREATE INDEX IF NOT EXISTS idx_messages_chat_id_created_at ON messages(chat_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_sender_id ON messages(sender_id);

-- 5. ATTACHMENT DETAILS TABLE
CREATE TABLE IF NOT EXISTS attachments (
    id SERIAL PRIMARY KEY,
    message_id VARCHAR(128) NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
    name VARCHAR(512) NOT NULL,
    size INTEGER NOT NULL,
    mime_type VARCHAR(128) NOT NULL,
    url TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_attachments_message_id ON attachments(message_id);

-- 6. REACTION DETAILS TABLE (Fast storage & lookup of user likes)
CREATE TABLE IF NOT EXISTS message_reactions (
    message_id VARCHAR(128) NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
    user_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    reaction_emoji VARCHAR(32) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (message_id, user_id, reaction_emoji)
);

-- 7. MESSAGE READ RECEIPTS SYSTEM JUNTION
CREATE TABLE IF NOT EXISTS message_read_receipts (
    id BIGSERIAL PRIMARY KEY,
    message_id VARCHAR(128) NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
    user_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    chat_id VARCHAR(128) NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
    status VARCHAR(32) NOT NULL DEFAULT 'delivered', -- 'delivered' or 'read'
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Unique index to guarantee single receipt state per user per message
CREATE UNIQUE INDEX IF NOT EXISTS idx_receipts_message_user ON message_read_receipts(message_id, user_id);
-- Compound index to query unread notifications count instantly
CREATE INDEX IF NOT EXISTS idx_receipts_chat_user_status ON message_read_receipts(chat_id, user_id, status);

CREATE TABLE IF NOT EXISTS message_status_telemetry (
    id BIGSERIAL PRIMARY KEY,
    message_id VARCHAR(128) NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
    user_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    chat_id VARCHAR(128) NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
    old_status VARCHAR(32),
    new_status VARCHAR(32) NOT NULL,
    source VARCHAR(128),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_status_telemetry_msg ON message_status_telemetry(message_id, created_at ASC);

-- 8. USER ACTIVE SESSION ENGINE (Rotational token trackers)
CREATE TABLE IF NOT EXISTS user_sessions (
    id VARCHAR(128) PRIMARY KEY,
    user_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    user_agent TEXT,
    ip_address VARCHAR(45),
    is_revoked BOOLEAN DEFAULT FALSE,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_user_sessions_user ON user_sessions(user_id, is_revoked);

-- 9. CALL LOGS TRACKING
CREATE TABLE IF NOT EXISTS call_logs (
    id VARCHAR(128) PRIMARY KEY,
    caller_id VARCHAR(128) REFERENCES users(id) ON DELETE CASCADE,
    receiver_id VARCHAR(128) REFERENCES users(id) ON DELETE CASCADE,
    status VARCHAR(32) NOT NULL DEFAULT 'missed',
    duration INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_call_logs_caller_id ON call_logs(caller_id);
CREATE INDEX IF NOT EXISTS idx_call_logs_receiver_id ON call_logs(receiver_id);

-- 10. ROLE AND PERMISSIONS FIELD
ALTER TABLE users ADD COLUMN IF NOT EXISTS role VARCHAR(32) DEFAULT 'user';
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

-- 11. DELETED MESSAGES VAULT
CREATE TABLE IF NOT EXISTS deleted_messages_vault (
    message_id VARCHAR(128) PRIMARY KEY,
    chat_id VARCHAR(128) NOT NULL,
    sender_id VARCHAR(128) NOT NULL,
    original_content TEXT NOT NULL,
    message_type VARCHAR(32) NOT NULL,
    attachments_metadata JSONB DEFAULT '[]'::jsonb,
    original_created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    deleted_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    deleted_by VARCHAR(128) NOT NULL,
    delete_reason TEXT
);

CREATE INDEX IF NOT EXISTS idx_deleted_msg_deleted_at ON deleted_messages_vault(deleted_at);

-- 12. REPORTING SYSTEM
CREATE TABLE IF NOT EXISTS reports (
    report_id VARCHAR(128) PRIMARY KEY,
    reporter_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    target_user_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    target_message_id VARCHAR(128) REFERENCES messages(id) ON DELETE SET NULL,
    category VARCHAR(64) NOT NULL,
    description TEXT,
    status VARCHAR(32) NOT NULL DEFAULT 'Pending',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_reports_reporter_id ON reports(reporter_id);
CREATE INDEX IF NOT EXISTS idx_reports_target_user_id ON reports(target_user_id);
CREATE INDEX IF NOT EXISTS idx_reports_target_msg_id ON reports(target_message_id);
CREATE INDEX IF NOT EXISTS idx_reports_created_at ON reports(created_at);
CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status);

-- 13. AUDIT LOG SYSTEM
CREATE TABLE IF NOT EXISTS moderation_audit_logs (
    id VARCHAR(128) PRIMARY KEY,
    event_type VARCHAR(64) NOT NULL,
    actor_user_id VARCHAR(128) REFERENCES users(id) ON DELETE SET NULL,
    target_user_id VARCHAR(128) REFERENCES users(id) ON DELETE SET NULL,
    target_resource VARCHAR(128),
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_mod_audit_actor ON moderation_audit_logs(actor_user_id);
CREATE INDEX IF NOT EXISTS idx_mod_audit_created ON moderation_audit_logs(created_at);

-- 14. STATUSES SYSTEM (STORIES)
CREATE TABLE IF NOT EXISTS statuses (
    id VARCHAR(128) PRIMARY KEY,
    user_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    content_type VARCHAR(32) NOT NULL DEFAULT 'text', -- 'text', 'image', 'video'
    media_url TEXT,
    text_content TEXT,
    duration_hours INTEGER DEFAULT 24,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    is_archived BOOLEAN DEFAULT FALSE,
    settings JSONB DEFAULT '{"likes_visibility":"everyone","comments":"open","replies":"open","views_visibility":"everyone"}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_statuses_user_id ON statuses(user_id);
CREATE INDEX IF NOT EXISTS idx_statuses_expires_at ON statuses(expires_at);

-- 15. STATUS VIEWS
CREATE TABLE IF NOT EXISTS status_views (
    id BIGSERIAL PRIMARY KEY,
    status_id VARCHAR(128) NOT NULL REFERENCES statuses(id) ON DELETE CASCADE,
    user_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    viewed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(status_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_status_views_status_id ON status_views(status_id);

-- 16. STATUS LIKES
CREATE TABLE IF NOT EXISTS status_likes (
    status_id VARCHAR(128) NOT NULL REFERENCES statuses(id) ON DELETE CASCADE,
    user_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (status_id, user_id)
);

-- 17. STATUS COMMENTS
CREATE TABLE IF NOT EXISTS status_comments (
    id VARCHAR(128) PRIMARY KEY,
    status_id VARCHAR(128) NOT NULL REFERENCES statuses(id) ON DELETE CASCADE,
    user_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    parent_id VARCHAR(128) REFERENCES status_comments(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    media_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX IF NOT EXISTS idx_status_comments_status_id ON status_comments(status_id);
CREATE INDEX IF NOT EXISTS idx_status_comments_parent_id ON status_comments(parent_id);

-- 18. STATUS COMMENT LIKES
CREATE TABLE IF NOT EXISTS status_comment_likes (
    comment_id VARCHAR(128) NOT NULL REFERENCES status_comments(id) ON DELETE CASCADE,
    user_id VARCHAR(128) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (comment_id, user_id)
);

-- 19. SYSTEM API KEYS
CREATE TABLE IF NOT EXISTS system_api_keys (
    id VARCHAR(128) PRIMARY KEY,
    key_value TEXT NOT NULL UNIQUE,
    service_name VARCHAR(64) DEFAULT 'gemini',
    is_active BOOLEAN DEFAULT TRUE,
    usage_count INTEGER DEFAULT 0,
    daily_usage_count INTEGER DEFAULT 0,
    usage_date DATE DEFAULT CURRENT_DATE,
    total_tokens BIGINT DEFAULT 0,
    last_used TIMESTAMP WITH TIME ZONE,
    added_by VARCHAR(128) REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

