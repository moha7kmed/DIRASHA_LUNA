/**
 * Classic Authentication Screen — username + password + PIN recovery
 * --------------------------------------------------------------------
 * No SMS, no OAuth, no phone required. Roblox-style identity:
 *   Register: display name → unique username → strong password → recovery PIN
 *             → one-time device key (downloaded as dirasha-key.txt, stored locally)
 *   Login:    username + password (+ known-device signal)
 *   Recover:  username + PIN + device key → one-time reset token → new password
 * Server-side hashing: scrypt + per-secret salt + server pepper (never leaves API).
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Lock, AtSign, User as UserIcon, Loader2, CheckCircle2, XCircle, Sparkles,
  KeyRound, ShieldCheck, Eye, EyeOff, Download, ArrowLeft, Fingerprint, LifeBuoy,
} from 'lucide-react';
import { normalizeUsernameInput, validateDisplayName } from '../lib/identityUtils';
import * as TokenVault from '../lib/token_vault';
import { authenticateWithPasskey } from '../lib/webauthn';

interface AuthScreenProps {
  onAuthSuccess: (token: string, user: any, sessionId?: string) => void;
}

type View = 'login' | 'register' | 'recover';
type RegStep = 'identity' | 'password' | 'pin' | 'deviceKey';
type RecoverStep = 'identify' | 'verify' | 'reset';

const DEVICE_KEY_STORAGE = 'dirasha_device_key';

function getStoredDeviceKey(): string {
  return (typeof localStorage !== 'undefined' && localStorage.getItem(DEVICE_KEY_STORAGE)) || '';
}

function downloadTextFile(filename: string, content: string) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

interface UsernameState {
  status: 'idle' | 'checking' | 'available' | 'taken' | 'invalid';
  message: string;
  suggestions: string[];
}

export function AuthScreen({ onAuthSuccess }: AuthScreenProps) {
  const [view, setView] = useState<View>('login');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // ── shared identity fields
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [loginNeedsTotp, setLoginNeedsTotp] = useState(false);
  const [loginTotpCode, setLoginTotpCode] = useState('');
  const [usernameState, setUsernameState] = useState<UsernameState>({ status: 'idle', message: '', suggestions: [] });
  const [nameState, setNameState] = useState<{ status: 'idle' | 'valid' | 'invalid'; message: string }>({ status: 'idle', message: '' });

  // ── register wizard
  const [regStep, setRegStep] = useState<RegStep>('identity');
  const [password, setPassword] = useState('');
  const [passwordConfirm, setPasswordConfirm] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [pin, setPin] = useState('');
  const [pinConfirm, setPinConfirm] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [issuedDeviceKey, setIssuedDeviceKey] = useState('');
  const [pendingSession, setPendingSession] = useState<{ accessToken: string; user: any; sessionId?: string } | null>(null);
  const [deviceSaved, setDeviceSaved] = useState(false);

  // ── login
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);

  // ── recovery
  const [recoverStep, setRecoverStep] = useState<RecoverStep>('identify');
  const [recoverPin, setRecoverPin] = useState('');
  const [recoverDeviceKey, setRecoverDeviceKey] = useState(getStoredDeviceKey());
  const [resetToken, setResetToken] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newPasswordConfirm, setNewPasswordConfirm] = useState('');

  /* ==================== Live validation effects ==================== */

  // Username availability (debounced) — register only
  useEffect(() => {
    if (view !== 'register' || regStep !== 'identity') return;
    const clean = normalizeUsernameInput(username);
    if (!clean) { setUsernameState({ status: 'idle', message: '', suggestions: [] }); return; }
    if (clean.length < 3) { setUsernameState({ status: 'invalid', message: 'اسم المستخدم قصير جداً (الحد الأدنى 3 أحرف).', suggestions: [] }); return; }
    setUsernameState(prev => ({ ...prev, status: 'checking', message: '' }));
    const timer = setTimeout(async () => {
      try {
        const res = await fetch(`/api/auth/check-username?username=${encodeURIComponent(clean)}`);
        const data = await res.json();
        if (data.available) {
          setUsernameState({ status: 'available', message: `@${clean} متاح!`, suggestions: [] });
        } else if (data.error) {
          setUsernameState({ status: 'invalid', message: data.error, suggestions: data.suggestions || [] });
        } else {
          setUsernameState({ status: 'taken', message: `اسم المستخدم "@${clean}" محجوز بالفعل لمستخدم آخر.`, suggestions: data.suggestions || [] });
        }
      } catch { setUsernameState({ status: 'idle', message: '', suggestions: [] }); }
    }, 450);
    return () => clearTimeout(timer);
  }, [username, view, regStep]);

  // Display-name quality (debounced)
  useEffect(() => {
    if (view !== 'register' || regStep !== 'identity') return;
    const trimmed = displayName.trim();
    if (!trimmed) { setNameState({ status: 'idle', message: '' }); return; }
    const timer = setTimeout(async () => {
      try {
        const res = await fetch(`/api/auth/eval-display-name?name=${encodeURIComponent(trimmed)}`);
        const data = await res.json();
        const isValid = data.isValid !== false && data.rating !== 'Weak';
        setNameState(isValid
          ? { status: 'valid', message: data.rating === 'Excellent' ? 'اسم ممتاز ✨' : 'اسم جيد' }
          : { status: 'invalid', message: data.reason || data.error || 'هذا الاسم غير مقبول.' });
      } catch { setNameState({ status: 'idle', message: '' }); }
    }, 450);
    return () => clearTimeout(timer);
  }, [displayName, view, regStep]);

  /* ==================== derived validity ==================== */
  const passwordScore = (() => {
    let s = 0;
    if (password.length >= 8) s++;
    if (password.length >= 12) s++;
    if (/[a-z]/.test(password) && /[A-Z]/.test(password)) s++;
    if (/\d/.test(password) && /[^a-zA-Z0-9]/.test(password)) s++;
    return s;
  })();
  const passwordOk = password.length >= 8 && /[a-zA-Z]/.test(password) && /\d/.test(password) && password === passwordConfirm;
  const pinOk = /^\d{6}$/.test(pin) && pin === pinConfirm;


  /* ==================== Handlers ==================== */

  const submitLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setError(null);
    if (!username.trim() || !loginPassword) { setError('أدخل اسم المستخدم وكلمة المرور.'); return; }
    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: normalizeUsernameInput(username), password: loginPassword, deviceKey: getStoredDeviceKey() || undefined, totpCode: loginTotpCode || undefined }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (data.code === 'totp_required') {
          setLoginNeedsTotp(true);
          setError('حسابك محمي بالتحقق بخطوتين — أدخل رمز تطبيق المصادقة.');
          return;
        }
        setError(data.error || 'فشل تسجيل الدخول.');
        return;
      }
      setLoginNeedsTotp(false); setLoginTotpCode('');
      // P1-hardening: refresh token lives in the server-set HttpOnly cookie — never persisted here.
      TokenVault.setAccessToken(data.accessToken);
      if (data.sessionId) TokenVault.setSessionId(data.sessionId);
      onAuthSuccess(data.accessToken, data.user, data.sessionId);
    } catch { setError('خطأ في الاتصال بالخادم. تحقق من الإنترنت.'); }
    finally { setLoading(false); }
  };

  // Project 9: passkey login — same session handling as the password path.
  // Requires the username to be entered first (username-keyed login options).
  const submitPasskeyLogin = async () => {
    setError(null);
    if (!username.trim()) { setError('أدخل اسم المستخدم أولاً، ثم استخدم مفتاح المرور.'); return; }
    setLoading(true);
    try {
      const data = await authenticateWithPasskey(normalizeUsernameInput(username));
      TokenVault.setAccessToken(data.accessToken);
      if (data.sessionId) TokenVault.setSessionId(data.sessionId);
      onAuthSuccess(data.accessToken, data.user, data.sessionId);
    } catch (err: any) {
      setError(err?.message || 'تعذر الدخول بمفتاح المرور.');
    } finally {
      setLoading(false);
    }
  };

  const submitRegister = async () => {
    setError(null);
    const nameCheck = validateDisplayName(displayName.trim());
    if (!nameCheck.isValid) { setError(nameCheck.error || 'اسم العرض غير صالح.'); setRegStep('identity'); return; }
    setLoading(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ displayName: displayName.trim(), username: normalizeUsernameInput(username), password, pin }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (res.status === 409) {
          setUsernameState({ status: 'taken', message: data.message || 'اسم المستخدم محجوز.', suggestions: data.suggestions || [] });
          setRegStep('identity');
        } else if (data.field === 'password') { setRegStep('password'); }
        else if (data.field === 'pin') { setRegStep('pin'); }
        else {
          setRegStep('identity');
          if (data.field === 'displayName') setNameState({ status: 'invalid', message: data.error });
        }
        setError(data.message || data.error || 'تعذر إنشاء الحساب.');
        return;
      }
      // Success → park session, show the one-time device key screen
      // P1-hardening: refresh token lives in the server-set HttpOnly cookie — never persisted here.
      TokenVault.setAccessToken(data.accessToken);
      if (data.sessionId) TokenVault.setSessionId(data.sessionId);
      if (data.deviceKey) {
        localStorage.setItem(DEVICE_KEY_STORAGE, data.deviceKey);
        setIssuedDeviceKey(data.deviceKey);
      }
      setPendingSession({ accessToken: data.accessToken, user: data.user, sessionId: data.sessionId });
      setRegStep('deviceKey');
    } catch { setError('خطأ في الاتصال بالخادم. تحقق من الإنترنت.'); }
    finally { setLoading(false); }
  };

  const finishDeviceKeyStep = () => {
    if (!pendingSession) return;
    onAuthSuccess(pendingSession.accessToken, pendingSession.user, pendingSession.sessionId);
  };


  const submitRecoverVerify = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setError(null);
    const dk = recoverDeviceKey.trim();
    if (!username.trim() || !/^\d{6}$/.test(recoverPin) || !dk) {
      setError('أكمل كل الحقول: اسم المستخدم + PIN + مفتاح الجهاز.');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/auth/recover/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: normalizeUsernameInput(username), pin: recoverPin, deviceKey: dk }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'فشل التحقق من الهوية.'); return; }
      setResetToken(data.resetToken);
      setRecoverStep('reset');
    } catch { setError('خطأ في الاتصال بالخادم.'); }
    finally { setLoading(false); }
  };

  const submitRecoverReset = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setError(null);
    if (newPassword.length < 8 || newPassword !== newPasswordConfirm) {
      setError('كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل ومتطابقة.');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/auth/recover/reset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: normalizeUsernameInput(username), resetToken, newPassword }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'فشلت إعادة التعيين. أعد محاولة الاسترجاع.'); return; }
      // P1-hardening: refresh token lives in the server-set HttpOnly cookie — never persisted here.
      TokenVault.setAccessToken(data.accessToken);
      if (data.sessionId) TokenVault.setSessionId(data.sessionId);
      onAuthSuccess(data.accessToken, data.user, data.sessionId);
    } catch { setError('خطأ في الاتصال بالخادم.'); }
    finally { setLoading(false); }
  };

  const handleDeviceKeyFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => setRecoverDeviceKey(String(reader.result || '').trim());
    reader.readAsText(file);
  };

  /* ==================== UI tokens ==================== */
  const inputCls = 'w-full bg-zinc-800/80 border border-white/10 rounded-2xl px-4 py-3.5 text-white placeholder-white/25 outline-none focus:border-emerald-500/50 transition-colors';
  const btnCls = 'w-full bg-gradient-to-l from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 disabled:opacity-40 text-black font-black text-base rounded-2xl py-3.5 transition-all flex items-center justify-center gap-2';
  const stepTitles: Record<RegStep, string> = { identity: 'هويتك', password: 'كلمة المرور', pin: 'رمز الاسترجاع PIN', deviceKey: 'مفتاح جهازك' };
  const strengthLabels = ['ضعيفة جداً', 'ضعيفة', 'مقبولة', 'قوية', 'قوية جداً'];
  const strengthColors = ['bg-red-500', 'bg-orange-500', 'bg-amber-400', 'bg-emerald-400', 'bg-emerald-300'];


  /* ==================== UI ==================== */

  return (
    <div dir="rtl" className="min-h-screen bg-[#07090d] text-white flex items-center justify-center p-4 relative overflow-hidden font-sans">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute -top-40 -right-40 w-[500px] h-[500px] bg-emerald-600/15 rounded-full blur-[140px]" />
        <div className="absolute -bottom-40 -left-40 w-[500px] h-[500px] bg-cyan-600/10 rounded-full blur-[140px]" />
      </div>

      <motion.div
        key={view + (view === 'register' ? regStep : recoverStep)}
        initial={{ opacity: 0, y: 24, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
        className="relative w-full max-w-md bg-zinc-900/70 backdrop-blur-2xl border border-white/10 rounded-[32px] p-8 shadow-2xl"
      >
        {/* Header */}
        <div className="flex flex-col items-center text-center mb-6">
          <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center mb-3">
            {view === 'recover' ? <LifeBuoy className="w-6 h-6 text-emerald-400" /> : <Lock className="w-6 h-6 text-emerald-400" />}
          </div>
          <h1 className="text-2xl font-black tracking-tight mb-1 bg-gradient-to-l from-emerald-400 via-teal-300 to-cyan-400 bg-clip-text text-transparent">ديراشة</h1>
          <p className="text-sm text-white/50">
            {view === 'login' && 'سجّل دخولك بحسابك'}
            {view === 'register' && `حساب جديد — ${stepTitles[regStep]}`}
            {view === 'recover' && 'استرجاع الحساب'}
          </p>
        </div>

        {/* Tabs (hidden mid-wizard) */}
        {view !== 'recover' && regStep !== 'deviceKey' && (
          <div className="flex bg-zinc-800/60 rounded-2xl p-1 mb-5 border border-white/5">
            {(['login', 'register'] as View[]).map(v => (
              <button
                key={v}
                type="button"
                onClick={() => { setView(v); setError(null); setRegStep('identity'); }}
                className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition-all ${view === v ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'text-white/45 hover:text-white/70'}`}
              >
                {v === 'login' ? 'تسجيل الدخول' : 'حساب جديد'}
              </button>
            ))}
          </div>
        )}

        {/* Error banner */}
        <AnimatePresence>
          {error && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="mb-4 overflow-hidden">
              <div className="bg-red-500/10 border border-red-500/25 text-red-300 text-sm rounded-2xl px-4 py-3 flex items-center gap-2">
                <XCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ═══════════ LOGIN ═══════════ */}
        {view === 'login' && (
          <form onSubmit={submitLogin} className="space-y-4">
            <div className="relative">
              <AtSign className="w-4 h-4 text-white/30 absolute right-4 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(normalizeUsernameInput(e.target.value))}
                placeholder="اسم المستخدم"
                className={inputCls + ' pr-11 font-mono'}
                dir="ltr"
                autoFocus
              />
            </div>
            <div className="relative">
              <input
                type={showLoginPassword ? 'text' : 'password'}
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                placeholder="كلمة المرور"
                className={inputCls + ' pl-11'}
                dir="ltr"
              />
              <button type="button" onClick={() => setShowLoginPassword(v => !v)} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/70">
                {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            {loginNeedsTotp ? (
              <div className="relative">
                <input
                  value={loginTotpCode}
                  onChange={(e) => setLoginTotpCode(e.target.value.replace(/[^A-Za-z0-9-]/g, '').slice(0, 10))}
                  placeholder="رمز التطبيق أو كود الاسترداد"
                  className={inputCls + ' text-center text-lg tracking-widest font-black'}
                  dir="ltr"
                  autoFocus
                />
              </div>
            ) : null}
            <button type="submit" disabled={loading} className={btnCls}>
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'دخول'}
            </button>
            {/* Project 9: الدخول بمفتاح المرور — طبقة إضافية بجانب كلمة المرور (كلمة المرور باقية كما هي) */}
            <button
              type="button"
              disabled={loading || !username.trim()}
              onClick={submitPasskeyLogin}
              className="w-full bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 font-bold text-sm rounded-2xl py-3 transition-all flex items-center justify-center gap-2 disabled:opacity-40"
            >
              <Fingerprint className="w-4 h-4" /> الدخول بمفتاح المرور
            </button>
            <p className="text-[10px] text-white/30 text-center leading-relaxed">
              مفتاح المرور يحمي تسجيل الدخول فقط ولا يشفر المحادثات ولا يستعيد مفاتيح التشفير المخزنة على هذا الجهاز.
            </p>
            <button
              type="button"
              onClick={() => { setView('recover'); setRecoverStep('identify'); setError(null); }}
              className="w-full text-sm text-white/45 hover:text-emerald-300 transition-colors"
            >
              نسيت كلمة المرور؟ استرجاع الحساب
            </button>
          </form>
        )}


        {/* ═══════════ REGISTER · STEP: IDENTITY ═══════════ */}
        {view === 'register' && regStep === 'identity' && (
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-white/60 mb-2 flex items-center gap-1.5"><UserIcon className="w-3.5 h-3.5" /> اسم العرض</label>
              <input type="text" value={displayName} onChange={(e) => setDisplayName(e.target.value)} placeholder="مثال: أحمد محمد" maxLength={35} className={inputCls} autoFocus />
              {nameState.status !== 'idle' && (
                <p className={`text-xs mt-1.5 flex items-center gap-1 ${nameState.status === 'valid' ? 'text-emerald-400' : 'text-red-400'}`}>
                  {nameState.status === 'valid' ? <CheckCircle2 className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />} {nameState.message}
                </p>
              )}
            </div>
            <div>
              <label className="block text-xs font-bold text-white/60 mb-2 flex items-center gap-1.5"><AtSign className="w-3.5 h-3.5" /> اسم المستخدم (فريد — لا يتكرر أبداً)</label>
              <div className="relative" dir="ltr">
                <input type="text" value={username} onChange={(e) => setUsername(normalizeUsernameInput(e.target.value))} placeholder="ahmed_mohamed" maxLength={20} className={inputCls + ' pl-11 font-mono'} />
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/30 font-mono">@</span>
              </div>
              {usernameState.status === 'checking' && <p className="text-xs text-white/40 mt-1.5 flex items-center gap-1"><Loader2 className="w-3.5 h-3.5 animate-spin" /> جارٍ التحقق من التوفر...</p>}
              {usernameState.status === 'available' && <p className="text-xs text-emerald-400 mt-1.5 flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5" /> {usernameState.message}</p>}
              {usernameState.status === 'taken' && (
                <div className="bg-red-500/10 border border-red-500/25 rounded-xl px-3 py-2.5 mt-1.5">
                  <p className="text-xs text-red-400 font-bold flex items-center gap-1"><XCircle className="w-3.5 h-3.5" /> {usernameState.message}</p>
                  {usernameState.suggestions.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mt-2" dir="ltr">
                      {usernameState.suggestions.map(s => (
                        <button key={s} type="button" onClick={() => setUsername(s)} className="text-[11px] font-mono bg-white/5 hover:bg-emerald-500/20 border border-white/10 hover:border-emerald-500/40 text-white/70 hover:text-emerald-300 px-2.5 py-1 rounded-lg transition-all">@{s}</button>
                      ))}
                    </div>
                  )}
                </div>
              )}
              {usernameState.status === 'invalid' && <p className="text-xs text-red-400 mt-1.5 flex items-center gap-1"><XCircle className="w-3.5 h-3.5" /> {usernameState.message}</p>}
              <p className="text-[11px] text-white/30 mt-2">3-20 حرفاً — إنجليزي وأرقام و _ و . فقط — لا يبدأ أو ينتهي برمز — بدون رموز متتالية</p>
            </div>
            <button
              type="button"
              disabled={usernameState.status !== 'available' || nameState.status === 'invalid' || !displayName.trim()}
              onClick={() => setRegStep('password')}
              className={btnCls}
            >
              متابعة
            </button>
          </div>
        )}


        {/* ═══════════ REGISTER · STEP: PASSWORD ═══════════ */}
        {view === 'register' && regStep === 'password' && (
          <div className="space-y-4">
            <div className="relative">
              <input type={showPassword ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="كلمة المرور" className={inputCls + ' pl-11'} dir="ltr" autoFocus />
              <button type="button" onClick={() => setShowPassword(v => !v)} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/70">
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <div className="flex items-center gap-2" dir="ltr">
              {[0, 1, 2, 3].map(i => (
                <div key={i} className={`h-1.5 flex-1 rounded-full transition-all ${i < passwordScore ? strengthColors[passwordScore] : 'bg-white/10'}`} />
              ))}
              <span className="text-[11px] text-white/50 shrink-0">{strengthLabels[passwordScore]}</span>
            </div>
            <input type={showPassword ? 'text' : 'password'} value={passwordConfirm} onChange={(e) => setPasswordConfirm(e.target.value)} placeholder="تأكيد كلمة المرور" className={inputCls} dir="ltr" />
            {passwordConfirm && password !== passwordConfirm && <p className="text-xs text-red-400 flex items-center gap-1"><XCircle className="w-3.5 h-3.5" /> كلمتا المرور غير متطابقتين</p>}
            <p className="text-[11px] text-white/30">8 أحرف على الأقل — حروف إنجليزية وأرقام معاً — لا تحتوي على اسم المستخدم</p>
            <div className="flex gap-2">
              <button type="button" onClick={() => setRegStep('identity')} className="px-5 py-3.5 rounded-2xl bg-white/5 text-white/60 hover:text-white text-sm font-bold transition-colors flex items-center gap-1"><ArrowLeft className="w-4 h-4" /> رجوع</button>
              <button type="button" disabled={!passwordOk} onClick={() => setRegStep('pin')} className={btnCls + ' flex-1'}>متابعة</button>
            </div>
          </div>
        )}

        {/* ═══════════ REGISTER · STEP: PIN ═══════════ */}
        {view === 'register' && regStep === 'pin' && (
          <div className="space-y-4">
            <div className="bg-amber-500/[0.07] border border-amber-500/25 rounded-2xl p-4">
              <p className="text-xs text-amber-200/90 leading-relaxed flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5" />
                <span><b>إلزامي:</b> رمز الاسترجاع هو طوق نجاتك الوحيد لو نسيت كلمة المرور. احفظه في مكان آمن — لا أحد في ديراشة يستطيع رؤيته، وبدونه (مع مفتاح الجهاز) لن تستطيع استرجاع حسابك.</span>
              </p>
            </div>
            <div className="relative">
              <input type={showPin ? 'text' : 'password'} inputMode="numeric" maxLength={6} value={pin} onChange={(e) => setPin(e.target.value.replace(/[^\d]/g, ''))} placeholder="رمز PIN — 6 أرقام" className={inputCls + ' pl-11 text-center text-xl tracking-[0.5em] font-black'} dir="ltr" autoFocus />
              <button type="button" onClick={() => setShowPin(v => !v)} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/70">
                {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <input type={showPin ? 'text' : 'password'} inputMode="numeric" maxLength={6} value={pinConfirm} onChange={(e) => setPinConfirm(e.target.value.replace(/[^\d]/g, ''))} placeholder="تأكيد رمز PIN" className={inputCls + ' text-center text-xl tracking-[0.5em] font-black'} dir="ltr" />
            {pinConfirm && pin !== pinConfirm && <p className="text-xs text-red-400 flex items-center gap-1"><XCircle className="w-3.5 h-3.5" /> رمزا PIN غير متطابقين</p>}
            <div className="flex gap-2">
              <button type="button" onClick={() => setRegStep('password')} className="px-5 py-3.5 rounded-2xl bg-white/5 text-white/60 hover:text-white text-sm font-bold transition-colors flex items-center gap-1"><ArrowLeft className="w-4 h-4" /> رجوع</button>
              <button type="button" disabled={!pinOk || loading} onClick={submitRegister} className={btnCls + ' flex-1'}>
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Sparkles className="w-4 h-4" /> إنشاء حسابي</>}
              </button>
            </div>
          </div>
        )}


        {/* ═══════════ REGISTER · STEP: DEVICE KEY (one-time!) ═══════════ */}
        {view === 'register' && regStep === 'deviceKey' && (
          <div className="space-y-4 text-center">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-cyan-500/10 border border-cyan-500/25 flex items-center justify-center">
              <Fingerprint className="w-8 h-8 text-cyan-400" />
            </div>
            <h3 className="font-black text-lg">تم إنشاء حسابك 🎉 — احفظ مفتاح جهازك</h3>
            <p className="text-xs text-white/55 leading-relaxed">
              هذا المفتاح هو <b>بصمة جهازك</b> — مع رمز PIN يشكّلان طريق استرجاع حسابك لو نسيت كلمة المرور. محفوظ تلقائياً في متصفحك، وحمّله كملف احتياطي:
            </p>
            <button
              type="button"
              onClick={() => { downloadTextFile('dirasha-key.txt', issuedDeviceKey); setDeviceSaved(true); }}
              className="w-full bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 font-bold text-sm rounded-2xl py-3.5 transition-all flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" /> تحميل dirasha-key.txt
            </button>
            {!deviceSaved && <p className="text-[11px] text-amber-300/80">⚠️ حمّل الملف قبل المتابعة — هذا مفتاحك الاحتياطي لاسترجاع الحساب</p>}
            <button type="button" disabled={!deviceSaved || loading} onClick={finishDeviceKeyStep} className={btnCls}>
              دخول إلى ديراشة
            </button>
          </div>
        )}


        {/* ═══════════ RECOVERY ═══════════ */}
        {view === 'recover' && recoverStep === 'identify' && (
          <div className="space-y-4">
            <p className="text-xs text-white/50 leading-relaxed">أدخل اسم المستخدم — سنتأكد من هويتك عبر <b>رمز PIN + بصمة الجهاز</b> في الخطوة التالية.</p>
            <div className="relative">
              <AtSign className="w-4 h-4 text-white/30 absolute right-4 top-1/2 -translate-y-1/2" />
              <input type="text" value={username} onChange={(e) => setUsername(normalizeUsernameInput(e.target.value))} placeholder="اسم المستخدم" className={inputCls + ' pr-11 font-mono'} dir="ltr" autoFocus />
            </div>
            <button type="button" disabled={!username.trim()} onClick={() => setRecoverStep('verify')} className={btnCls}>متابعة للتحقق</button>
            <button type="button" onClick={() => { setView('login'); setError(null); }} className="w-full text-sm text-white/45 hover:text-white transition-colors flex items-center justify-center gap-1"><ArrowLeft className="w-4 h-4" /> عودة لتسجيل الدخول</button>
          </div>
        )}

        {view === 'recover' && recoverStep === 'verify' && (
          <form onSubmit={submitRecoverVerify} className="space-y-4">
            <p className="text-xs text-white/50">الحساب: <span className="font-mono text-emerald-300" dir="ltr">@{username}</span></p>
            <div className="relative">
              <input type={showPin ? 'text' : 'password'} inputMode="numeric" maxLength={6} value={recoverPin} onChange={(e) => setRecoverPin(e.target.value.replace(/[^\d]/g, ''))} placeholder="رمز PIN — 6 أرقام" className={inputCls + ' pl-11 text-center text-xl tracking-[0.5em] font-black'} dir="ltr" autoFocus />
              <button type="button" onClick={() => setShowPin(v => !v)} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/70">
                {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <div className={`border rounded-2xl p-3.5 ${recoverDeviceKey ? 'bg-emerald-500/[0.06] border-emerald-500/25' : 'bg-white/[0.02] border-white/10'}`}>
              {recoverDeviceKey ? (
                <p className="text-xs text-emerald-300 flex items-center gap-2"><KeyRound className="w-4 h-4" /> مفتاح الجهاز جاهز (من هذا المتصفح)</p>
              ) : (
                <label className="text-xs text-white/60 flex items-center gap-2 cursor-pointer hover:text-white transition-colors">
                  <KeyRound className="w-4 h-4 text-amber-400" />
                  ارفع ملف dirasha-key.txt (مفتاح جهازك الاحتياطي)
                  <input type="file" accept=".txt" className="hidden" onChange={(e) => e.target.files?.[0] && handleDeviceKeyFile(e.target.files[0])} />
                </label>
              )}
            </div>
            <div className="flex gap-2">
              <button type="button" onClick={() => setRecoverStep('identify')} className="px-5 py-3.5 rounded-2xl bg-white/5 text-white/60 hover:text-white text-sm font-bold transition-colors flex items-center gap-1"><ArrowLeft className="w-4 h-4" /> رجوع</button>
              <button type="submit" disabled={loading} className={btnCls + ' flex-1'}>
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'تحقق من هويتي'}
              </button>
            </div>
          </form>
        )}


        {view === 'recover' && recoverStep === 'reset' && (
          <form onSubmit={submitRecoverReset} className="space-y-4">
            <p className="text-xs text-emerald-300 flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4" /> تم إثبات هويتك — عيّن كلمة مرور جديدة (الرابط صالح 10 دقائق)</p>
            <input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="كلمة المرور الجديدة (8+ أحرف، حروف وأرقام)" className={inputCls} dir="ltr" autoFocus />
            <input type="password" value={newPasswordConfirm} onChange={(e) => setNewPasswordConfirm(e.target.value)} placeholder="تأكيد كلمة المرور الجديدة" className={inputCls} dir="ltr" />
            {newPasswordConfirm && newPassword !== newPasswordConfirm && <p className="text-xs text-red-400 flex items-center gap-1"><XCircle className="w-3.5 h-3.5" /> غير متطابقتين</p>}
            <button type="submit" disabled={loading} className={btnCls}>
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'تعيين والدخول'}
            </button>
          </form>
        )}
      </motion.div>

      <p className="absolute bottom-5 text-[11px] text-white/25 text-center w-full px-6">
        بدون SMS وبدون حسابات خارجية — هويتك ملكك وحدك 🔐
      </p>
    </div>
  );
}

export default AuthScreen;
