/**
 * P0-A (external-audit E2EE-01/E2EE-02) — group membership epochs.
 *
 * Test split (same constraint as tests/db-tls.test.ts — server.ts boots the
 * HTTP listener at import, so in-process route tests are impossible):
 *
 *   1. BEHAVIORAL (pure): GroupCrypto membership-version helpers + the REAL
 *      assertMembershipFresh gate (sendGate.ts) with a mock db — stale/missing/
 *      future versions fail closed; 1:1 chats skip.
 *   2. BEHAVIORAL (pure, crypto proofs): the two acceptance proofs the audit
 *      demanded, at the crypto boundary:
 *        - REMOVED member cannot decrypt post-rotation traffic (skId fail-closed).
 *        - NEW member cannot decrypt pre-join traffic of the replaced epoch.
 *   3. STATIC-SOURCE: server routes bump + broadcast; WS/REST gates wired;
 *      client rotates on membership_changed + wipes on self-eviction + guards
 *      sends + carries mv on every msg:send + reconciles on hydrate.
 *
 * Run: npx vitest run tests/group-membership.test.ts
 */
import { describe, it, expect, beforeAll } from 'vitest';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const serverSrc = fs.readFileSync(path.join(repoRoot, 'server.ts'), 'utf8');
const wsSrc = fs.readFileSync(path.join(repoRoot, 'src/server/websocket/ws_server.ts'), 'utf8');
const appSrc = fs.readFileSync(path.join(repoRoot, 'src/App.tsx'), 'utf8');
const gateSrc = fs.readFileSync(path.join(repoRoot, 'src/server/guards/sendGate.ts'), 'utf8');

/* ── 1. Gate behavior (real sendGate code, mock db) ────────────────────────── */

function mockGroupDb(mv: number) {
  return {
    getChatInfo: (chatId: string) => ({ id: chatId, type: 'group' }),
    getMembershipVersion: (chatId: string) => mv,
  };
}
function mockDmDb() {
  return {
    getChatInfo: (chatId: string) => ({ id: chatId, type: 'one-to-one' }),
    getMembershipVersion: (chatId: string) => 7,
  };
}

describe('assertMembershipFresh — group send gate (E2EE-01/02)', () => {
  let assertMembershipFresh: any;
  let SendBlockedError: any;
  let MembershipStaleError: any;
  beforeAll(async () => {
    ({ assertMembershipFresh, SendBlockedError, MembershipStaleError } = await import('../src/server/guards/sendGate.ts'));
  });

  it('fresh version passes and returns the server version', async () => {
    const v = await assertMembershipFresh(mockGroupDb(3), 'chat-1', 3);
    expect(v).toBe(3);
  });

  it('stale version fails closed with the current server version', async () => {
    try {
      await assertMembershipFresh(mockGroupDb(5), 'chat-1', 3);
      expect.unreachable('stale version must be rejected');
    } catch (e: any) {
      expect(e).toBeInstanceOf(MembershipStaleError);
      expect(e.expectedVersion).toBe(5);
    }
  });

  it('FUTURE version fails closed (forged or forked state)', async () => strictThrow(9));
  async function strictThrow(mv: number) {
    await expect(assertMembershipFresh(mockGroupDb(5), 'chat-1', mv)).rejects.toThrow();
  }

  it('missing version fails closed (old clients cannot bypass)', async () => {
    await expect(assertMembershipFresh(mockGroupDb(5), 'client-chat', undefined)).rejects.toThrow();
    await expect(assertMembershipFresh(mockGroupDb(5), 'client-chat', null)).rejects.toThrow();
    await expect(assertMembershipFresh(mockGroupDb(5), 'client-chat', 'garbage')).rejects.toThrow();
  });

  it('1:1 and channel chats skip the gate', async () => {
    const v = await assertMembershipFresh(mockDmDb(), 'dm-1', undefined);
    expect(v).toBe(7);
  });

  it('missing chat fails closed', async () => {
    const db = { getChatInfo: () => null };
    await expect(assertMembershipFresh(db, 'x', 1)).rejects.toThrow();
  });
});

/* ── 2. Crypto proofs at the GroupCrypto boundary ──────────────────────────── */

describe('sender-key epochs — crypto fail-closed proofs', () => {
  let GroupCrypto: any;
  let MemoryKVStore: any;
  beforeAll(async () => {
    const mod = await import('../src/lib/e2ee/group.ts');
    GroupCrypto = mod.GroupCrypto;
    const storeMod = await import('../src/lib/e2ee/store.ts');
    MemoryKVStore = (storeMod as any).MemoryKVStore;
  });

  function makeTwo() {
    const storeA = new MemoryKVStore();
    const storeB = new MemoryKVStore();
    return { A: new GroupCrypto({ store: storeA, namespace: 'acc-A' }), B: new GroupCrypto({ store: storeB, namespace: 'acc-B' }) };
  }

  it('E2EE-01 proof: removed member holding the OLD epoch key cannot decrypt post-rotation traffic', async () => {
    const { A, B } = makeTwo();
    await A.ensureSenderKey('g1');
    await B.processControl('alice', JSON.parse(await A.distributionPayload('g1')));
    // Pre-rotation traffic: B (current member) decrypts fine.
    const preCt = await A.encryptGroupMessage('g1', 'before', 'alice', 1);
    await expect(B.decryptGroupMessage('g1', 'alice', preCt)).resolves.toMatchObject({ plaintext: 'before' });
    // ROTATION (what membership_changed now forces on every member).
    await A.rotateSenderKey('g1');
    // Post-rotation traffic: B holds ONLY the old-epoch key record (keyId
    // mismatch → DecryptFailedError) — the removed member fails closed.
    const postCt = await A.encryptGroupMessage('g1', 'after', 'alice', 1);
    const res = await B.decryptGroupMessage('g1', 'alice', postCt);
    expect('error' in res ? res.error : '').toBe('DecryptFailedError');
  });

  it('E2EE-02 proof: new member receiving ONLY the new epoch key cannot decrypt pre-join traffic', async () => {
    const { A } = makeTwo();
    await A.ensureSenderKey('g2');
    const pre1 = await A.encryptGroupMessage('g2', 'secret-1', 'alice', 1);
    const pre2 = await A.encryptGroupMessage('g2', 'secret-2', 'alice', 1);
    // ROTATION on add (what membership_changed now forces on every member);
    // the new member C receives ONLY the post-rotation key.
    await A.rotateSenderKey('g2');
    const C = new GroupCrypto({ store: new MemoryKVStore(), namespace: 'acc-C' });
    await C.processControl('alice', JSON.parse(await A.distributionPayload('g2')));
    // C holds the CURRENT epoch key, yet every pre-join envelope (old skId)
    // fails closed — backward secrecy within the replaced epoch.
    for (const ct of [pre1, pre2]) {
      const res = await C.decryptGroupMessage('g2', 'alice', ct);
      expect('error' in res ? res.error : '').toBe('DecryptFailedError');
    }
    // Sanity: post-join traffic decrypts for C.
    const postCt = await A.encryptGroupMessage('g2', 'welcome', 'alice', 1);
    await expect(C.decryptGroupMessage('g2', 'alice', postCt)).resolves.toMatchObject({ plaintext: 'welcome' });
  });

  it('membership-version helpers: round-trip + invalid rejected', async () => {
    const { A } = makeTwo();
    expect(await A.getMembershipVersion('g3')).toBeNull();
    await A.setMembershipVersion('g3', 4);
    expect(await A.getMembershipVersion('g3')).toBe(4);
    await A.setMembershipVersion('g3', 0);
    await A.setMembershipVersion('g3', Number.NaN);
    expect(await A.getMembershipVersion('g3')).toBe(4);
  });
});

/* ── 3. Static-source asserts (boot-at-import server — repo convention) ────── */

describe('server wiring — membership epoch broadcasts + gates (static)', () => {
  it('remove-member route bumps epoch + broadcasts to REMAINING members with removedUserId', () => {
    const block = serverSrc.slice(serverSrc.indexOf("app.delete('/api/chats/:chatId/members/:userId'"));
    expect(block).toContain("applyMembershipChange(chatId, 'remove', [targetId]");
    expect(block).toContain("event: 'chat:membership_changed'");
    expect(block).toContain('removedUserId: targetId');
    expect(block).toContain('membershipVersion: newMv');
  });

  it('evicted payload includes the removed user id (client can self-wipe keys)', () => {
    const block = serverSrc.slice(serverSrc.indexOf("app.delete('/api/chats/:chatId/members/:userId'"));
    expect(block).toContain("payload: { chatId, userId: targetId, membershipVersion: newMv }");
  });

  it('leave route bumps epoch + broadcasts with removedUserId = leaver', () => {
    const block = serverSrc.slice(serverSrc.indexOf("app.post('/api/chats/:chatId/leave'"));
    expect(block).toContain("applyMembershipChange(chatId, 'remove', [req.user!.userId]");
    expect(block).toContain('removedUserId: req.user!.userId');
    expect(block).toContain('membershipVersion: newMvLeave');
  });

  it('add-members route bumps epoch + notifies ALL current members', () => {
    const block = serverSrc.slice(serverSrc.indexOf("app.post('/api/chats/:chatId/members'"));
    expect(block).toContain("applyMembershipChange(chatId, 'add', addIds");
    expect(block).toContain('addedUserIds:');
    expect(block).toContain('membershipVersion: newMvAdd');
  });

  it('WS msg:send gate calls assertMembershipFresh and answers MEMBERSHIP_STALE', () => {
    expect(wsSrc).toContain('assertMembershipFresh(db, chatId, (payload as any).mv)');
    expect(wsSrc).toContain('code: "MEMBERSHIP_STALE"');
    expect(wsSrc).toContain('expectedVersion: (err as any).expectedVersion');
  });

  it('REST send routes enforce the membership gate (3 sites) with 409 MEMBERSHIP_STALE', () => {
    const hits = serverSrc.split('assertMembershipFresh(db, chatId, (req.body || {}).mv)').length - 1;
    expect(hits).toBe(3);
    expect(serverSrc).toContain("code: 'MEMBERSHIP_STALE', expectedVersion");
  });

  it('client rotates on membership_changed + wipes on self-eviction', () => {
    expect(appSrc).toContain("client.on('chat:membership_changed'");
    expect(appSrc).toContain('rotateGroupForMembership(mvChatId, newMv)');
    expect(appSrc).toContain('removedUserId === currentUserId');
    expect(appSrc).toContain('deleteGroup(evictChatId)');
  });

  it('client blocks sends while rekey is pending', () => {
    expect(appSrc).toContain('rekeyPendingRef.current.has(activeChatId)');
  });

  it('every msg:send emit carries mv (stale epochs are detectable server-side)', () => {
    const emits = appSrc.split("emit('msg:send'").length - 1;
    expect(emits).toBe(3);
    const mvCount = appSrc.split('?.membershipVersion,').length - 1;
    expect(mvCount).toBeGreaterThanOrEqual(3);
  });

  it('client reconciles membership versions on chat hydrate (offline recovery)', () => {
    expect(appSrc).toContain('membership-version reconciliation');
    expect(appSrc).toContain('rotateGroupForMembership(chat.id, serverMv)');
    expect(appSrc).toContain('setMembershipVersion(chat.id, serverMv)');
  });

  it('sendGate exports the epoch gate + typed error', () => {
    expect(gateSrc).toContain('export async function assertMembershipFresh');
    expect(gateSrc).toContain('export class MembershipStaleError');
  });
});

describe('GROUP-01 — allowGroupInvites on ALL membership paths (static)', () => {
  it('create route blocks nobody + contacts policies', () => {
    const block = serverSrc.slice(serverSrc.indexOf('app.post(\'/api/chats\'') > -1 ? serverSrc.indexOf('app.post(\'/api/chats\'') : 0);
    const createBlock = serverSrc.slice(serverSrc.indexOf('Group chat creation'));
    expect(createBlock).toContain("policy === 'nobody'");
    expect(createBlock).toContain("policy === 'contacts'");
  });
  it('add-members route enforces the same policies (was unchecked)', () => {
    const addBlock = serverSrc.slice(serverSrc.indexOf('app.post(\'/api/chats/:chatId/members\''));
    expect(addBlock).toContain('allowGroupInvites');
    expect(addBlock).toContain("policy === 'nobody'");
    expect(addBlock).toContain("policy === 'contacts'");
  });
});

describe('DIR-NEW-04 — atomic membership change (static)', () => {
  it('membership routes use the atomic applyMembershipChange (add/remove/leave/join/approve)', () => {
    const hits = serverSrc.split('await db.applyMembershipChange(chatId').length - 1;
    expect(hits).toBeGreaterThanOrEqual(5);
    expect(serverSrc).toContain("applyMembershipChange(chatId, 'remove', [targetId]");
    expect(serverSrc).toContain("applyMembershipChange(chatId, 'remove', [req.user!.userId]");
    expect(serverSrc).toContain("applyMembershipChange(chatId, 'add', addIds");
    expect(serverSrc).toContain("applyMembershipChange(chatId, 'add', [req.user!.userId]");
    expect(serverSrc).toContain("applyMembershipChange(chatId, 'add', [targetId]");
  });
  it('tx failure answers 503 MEMBERSHIP_TX_FAILED and the broadcast follows commit', () => {
    expect((serverSrc.match(/MEMBERSHIP_TX_FAILED/g) || []).length).toBeGreaterThanOrEqual(5);
    expect(serverSrc).toContain('membership_changed');
  });
});
