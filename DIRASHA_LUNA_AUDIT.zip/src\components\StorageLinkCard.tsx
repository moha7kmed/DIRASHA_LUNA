/**
 * Storage Linking Card — Google Drive first
 * ------------------------------------------
 * Big emerald "link your free 15GB Google account" button (OAuth consent via
 * /api/storage/gdrive/start → top-level redirect → callback lands the user
 * back in the app with ?storage=linked). The legacy BYO S3-compatible bucket
 * form (R2/B2/MinIO/S3) stays available behind a collapsed "advanced options"
 * details element. Credentials are AES-256-GCM encrypted server-side.
 */

import React, { useEffect, useState } from 'react';
import { Cloud, CloudOff, Loader2, CheckCircle2, XCircle, ShieldAlert, Trash2, Link2, HardDrive } from 'lucide-react';
import { getAccessToken } from '../lib/token_vault.ts';
import { startGdriveConsent } from '../lib/storageUtils';

const PROVIDERS: Record<string, { label: string; endpointHint: string; regionHint: string; pathStyle: boolean }> = {
  r2: {
    label: 'Cloudflare R2 (مجاني 10GB + نقل بلا حدود)',
    endpointHint: 'https://<ACCOUNT_ID>.r2.cloudflarestorage.com',
    regionHint: 'auto',
    pathStyle: false,
  },
  b2: {
    label: 'Backblaze B2 (مجاني 10GB)',
    endpointHint: 'https://s3.<region>.backblazeb2.com',
    regionHint: 'us-east-005',
    pathStyle: false,
  },
  minio: {
    label: 'MinIO / تخزين ذاتي (S3-متوافق)',
    endpointHint: 'https://minio.example.com',
    regionHint: 'us-east-1',
    pathStyle: true,
  },
  s3: {
    label: 'AWS S3',
    endpointHint: 'https://s3.<region>.amazonaws.com',
    regionHint: 'us-east-1',
    pathStyle: false,
  },
  other: {
    label: 'مزوّد آخر (S3-متوافق)',
    endpointHint: 'https://',
    regionHint: 'us-east-1',
    pathStyle: false,
  },
};

interface StorageStatus {
  linked: boolean;
  provider: string | null;
  bucket: string | null;
  publicBaseUrl: string | null;
  fallbackActive: boolean;
  gdrive?: boolean;
  gdriveSupported?: boolean;
}

function token(): string {
  // P1-hardening: read from the in-memory vault instead of localStorage.
  return getAccessToken();
}

export function StorageLinkCard() {
  const [status, setStatus] = useState<StorageStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [consent, setConsent] = useState(false);

  // Legacy S3 form state (kept behind the advanced details element)
  const [provider, setProvider] = useState('r2');
  const [endpoint, setEndpoint] = useState('');
  const [region, setRegion] = useState('auto');
  const [bucket, setBucket] = useState('');
  const [accessKeyId, setAccessKeyId] = useState('');
  const [secretAccessKey, setSecretAccessKey] = useState('');
  const [publicBaseUrl, setPublicBaseUrl] = useState('');

  const refresh = async () => {
    try {
      const res = await fetch('/api/storage/status', { headers: { Authorization: `Bearer ${token()}` } });
      if (res.ok) setStatus(await res.json());
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { refresh(); }, []);

  const isGdriveLinked = !!status?.linked && status?.provider === 'gdrive';

  const linkGoogle = async () => {
    try {
      await startGdriveConsent(token());
    } catch (e: any) {
      setError(e?.message || 'تعذر بدء ربط Google Drive.');
    }
  };

  const unlink = async () => {
    setSaving(true);
    setError(null);
    setSuccess(null);
    try {
      const isGdrive = status?.provider === 'gdrive';
      const res = await fetch(isGdrive ? '/api/storage/gdrive' : '/api/storage/link', {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token()}` },
      });
      if (res.ok) {
        setSuccess(isGdrive ? 'تم فصل حساب Google Drive.' : 'تم فصل التخزين السحابي.');
        await refresh();
      } else {
        setError('تعذر الفصل.');
      }
    } finally {
      setSaving(false);
    }
  };

  const linkS3 = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    if (!consent) {
      setError('يجب الموافقة على شروط تحميل تكلفة الميديا عليك أولاً.');
      return;
    }
    setSaving(true);
    try {
      const res = await fetch('/api/storage/link', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token()}` },
        body: JSON.stringify({
          provider, endpoint, region, bucket,
          accessKeyId, secretAccessKey, publicBaseUrl,
          forcePathStyle: PROVIDERS[provider].pathStyle,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'تعذر الربط. تحقق من البيانات.');
        return;
      }
      setSuccess('تم ربط تخزينك السحابي بنجاح! كل وسائطك الجديدة ستُرفع إليه.');
      setAccessKeyId('');
      setSecretAccessKey('');
      await refresh();
    } catch {
      setError('خطأ في الاتصال بالخادم.');
    } finally {
      setSaving(false);
    }
  };

  const inputCls = 'w-full bg-zinc-800/80 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white placeholder-white/25 outline-none focus:border-emerald-500/50 transition-colors font-mono';
  const labelCls = 'block text-[11px] font-bold text-white/55 mb-1.5';

  return (
    <div className="bg-white/[0.03] backdrop-blur-xl border border-white/10 rounded-[32px] p-6 shadow-xl space-y-5 text-right" dir="rtl">
      {/* Header + status */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center">
            <Cloud className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <h3 className="font-black text-white">مساحتك السحابية للوسائط</h3>
            <p className="text-[11px] text-white/45">صورك وفيديوهاتك تُرفع إلى مساحتك أنت — الخصوصية لك والمساحة مجانية</p>
          </div>
        </div>
        {loading ? (
          <Loader2 className="w-4 h-4 animate-spin text-white/40" />
        ) : status?.linked ? (
          <span className="text-[10px] font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/25 px-2.5 py-1 rounded-full flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" /> مربوط: {status.provider === 'gdrive' ? 'Google Drive' : status.provider}
          </span>
        ) : (
          <span className="text-[10px] font-bold bg-white/5 text-white/45 border border-white/10 px-2.5 py-1 rounded-full flex items-center gap-1">
            <CloudOff className="w-3 h-3" /> {status?.fallbackActive ? 'المخزن الاحتياطي' : 'غير مربوط'}
          </span>
        )}
      </div>

      {/* Linked state — Google Drive */}
      {isGdriveLinked && (
        <div className="bg-emerald-500/[0.06] border border-emerald-500/15 rounded-2xl p-4 space-y-1.5">
          <p className="text-xs font-bold text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            ✅ مرتبط بحساب Google Drive — 15GB مساحتك الخاصة
          </p>
          <p className="text-[11px] text-white/50">وسائطك تُحفظ في مجلد «Dirasha Media» داخل حسابك، وتُبثّ مباشرة من Google دون تمرير عبر خادمنا.</p>
          <button
            onClick={unlink}
            disabled={saving}
            className="mt-2 text-xs font-bold text-red-400 hover:text-red-300 flex items-center gap-1.5 transition-colors disabled:opacity-50"
          >
            {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
            فصل حساب Google (الملفات القديمة تبقى في Drive)
          </button>
        </div>
      )}

      {/* Linked state — legacy S3 */}
      {status?.linked && status.provider !== 'gdrive' && (
        <div className="bg-emerald-500/[0.06] border border-emerald-500/15 rounded-2xl p-4 space-y-1.5">
          <p className="text-xs text-white/70 flex items-center gap-2"><HardDrive className="w-3.5 h-3.5 text-emerald-400" /> الحاوية: <span className="font-mono text-emerald-300" dir="ltr">{status.bucket}</span></p>
          <p className="text-[11px] text-white/40 font-mono break-all" dir="ltr">{status.publicBaseUrl}</p>
          <button
            onClick={unlink}
            disabled={saving}
            className="mt-2 text-xs font-bold text-red-400 hover:text-red-300 flex items-center gap-1.5 transition-colors disabled:opacity-50"
          >
            {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
            فصل التخزين (الوسائط القديمة تبقى على حاويتك)
          </button>
        </div>
      )}

      {/* Google-first link button */}
      {!status?.linked && (
        <div className="space-y-3">
          <button
            onClick={linkGoogle}
            className="w-full bg-gradient-to-l from-emerald-500 to-emerald-400 hover:from-emerald-400 hover:to-emerald-300 text-black font-black text-sm rounded-2xl py-3.5 transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20"
          >
            <svg viewBox="0 0 24 24" className="w-5 h-5 shrink-0" aria-hidden="true">
              <path fill="#0F9D58" d="M12 11v3.6h5.1c-.5 2.4-2.6 3.8-5.1 3.8a5.4 5.4 0 1 1 0-10.8c1.4 0 2.6.5 3.5 1.3l2.6-2.6A9 9 0 1 0 12 21c5.2 0 8.7-3.6 8.7-8.7 0-.4 0-.8-.1-1.3H12z"/>
            </svg>
            اربط مساحتك المجانية بحساب Google (15GB)
          </button>
          <p className="text-[11px] text-white/40 leading-relaxed flex items-start gap-1.5">
            <ShieldAlert className="w-3.5 h-3.5 shrink-0 mt-0.5 text-emerald-400/70" />
            سيُطلب منك منح صلاحية إنشاء الملفات فقط (drive.file) — لا نرى ولا نلمس أي ملف آخر في حسابك. وسائطك تُخزَّن في مجلد «Dirasha Media» الخاص بك، ويمكنك فصل الحساب في أي وقت.
          </p>
        </div>
      )}

      {/* Advanced: legacy BYO S3-compatible bucket (collapsed) */}
      {!status?.linked && (
        <details className="group border border-white/10 rounded-2xl bg-white/[0.02] overflow-hidden">
          <summary className="cursor-pointer select-none px-4 py-2.5 text-[11px] font-bold text-white/50 hover:text-white/70 transition-colors list-none">
            خيارات متقدمة (R2/B2) ▾
          </summary>
          <form onSubmit={linkS3} className="space-y-3 px-4 pb-4 pt-1">
            <div>
              <label className={labelCls}>مزوّد التخزين</label>
              <select value={provider} onChange={(e) => { setProvider(e.target.value); setRegion(PROVIDERS[e.target.value].regionHint); }} className={inputCls + ' font-sans'}>
                {Object.entries(PROVIDERS).map(([key, p]) => (
                  <option key={key} value={key}>{p.label}</option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className={labelCls}>Endpoint</label>
                <input dir="ltr" value={endpoint} onChange={e => setEndpoint(e.target.value)} placeholder={PROVIDERS[provider].endpointHint} className={inputCls} required />
              </div>
              <div>
                <label className={labelCls}>Region</label>
                <input dir="ltr" value={region} onChange={e => setRegion(e.target.value)} className={inputCls} required />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className={labelCls}>Bucket</label>
                <input dir="ltr" value={bucket} onChange={e => setBucket(e.target.value)} placeholder="my-media-bucket" className={inputCls} required />
              </div>
              <div>
                <label className={labelCls}>الرابط العام (Public URL)</label>
                <input dir="ltr" value={publicBaseUrl} onChange={e => setPublicBaseUrl(e.target.value)} placeholder="https://pub-xxxx.r2.dev" className={inputCls} required />
              </div>
            </div>
            <div>
              <label className={labelCls}>Access Key ID</label>
              <input dir="ltr" value={accessKeyId} onChange={e => setAccessKeyId(e.target.value)} className={inputCls} required autoComplete="off" />
            </div>
            <div>
              <label className={labelCls}>Secret Access Key</label>
              <input dir="ltr" value={secretAccessKey} onChange={e => setSecretAccessKey(e.target.value)} type="password" className={inputCls} required autoComplete="new-password" />
            </div>

            {/* Consent — the economic contract */}
            <label className="flex items-start gap-3 bg-amber-500/[0.06] border border-amber-500/20 rounded-2xl p-3.5 cursor-pointer">
              <input type="checkbox" checked={consent} onChange={e => setConsent(e.target.checked)} className="mt-0.5 accent-amber-400" />
              <span className="text-[11px] text-amber-200/80 leading-relaxed">
                <ShieldAlert className="w-3.5 h-3.5 inline ml-1 -mt-0.5" />
                أوافق على أن وسائطي (صور/فيديو/ملفات) تُخزَّن في حساب التخزين السحابي الخاص بي، وأن مساحتها وتكلفتها على مسئوليتي الكاملة وفق شروط المزوّد. حذفي لأي ملف من تخزيني يجعله غير متاح في المحادثات. مفاتيحي تُشفَّر (AES-256) قبل حفظها.
              </span>
            </label>

            <button
              type="submit"
              disabled={saving}
              className="w-full bg-gradient-to-l from-cyan-500 to-emerald-500 hover:from-cyan-400 hover:to-emerald-400 disabled:opacity-40 text-black font-black text-sm rounded-2xl py-3 transition-all flex items-center justify-center gap-2"
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Link2 className="w-4 h-4" /> ربط التخزين السحابي</>}
            </button>
          </form>
        </details>
      )}

      {/* Feedback */}
      {error && (
        <p className="text-xs text-red-400 flex items-center gap-1.5"><XCircle className="w-3.5 h-3.5" /> {error}</p>
      )}
      {success && (
        <p className="text-xs text-emerald-400 flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5" /> {success}</p>
      )}
    </div>
  );
}

export default StorageLinkCard;
