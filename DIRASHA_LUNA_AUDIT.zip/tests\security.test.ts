/**
 * P3-hardening: automated security regression tests.
 * Covers the systems introduced in the security-hardening pass:
 *   1. Media tokens (GET-scoped, short-lived, purpose-tagged)
 *   2. Snapshot at-rest encryption (roundtrip, tamper rejection, legacy plaintext)
 *   3. Token vault migration semantics (localStorage → memory/cookie)
 * Run: npm test
 */
import { describe, it, expect, beforeAll, afterAll } from 'vitest';

// ── 1. Media tokens ────────────────────────────────────────────────────────────
describe('AuthService media tokens (P1)', () => {
  it('issues a 120s purpose-tagged token verifiable by the standard verifier', async () => {
    const { AuthService } = await import('../src/server/services/auth.ts');
    const claims = { userId: 'u1', username: 'alice', displayName: 'Alice' };
    const mt = AuthService.generateMediaToken(claims);
    const decoded = AuthService.verifyAccessToken(mt);
    expect(decoded).not.toBeNull();
    expect(AuthService.isMediaToken(decoded)).toBe(true);
    expect(decoded!.userId).toBe('u1');
  });

  it('normal access tokens are NOT media tokens (URL scoping differentiates them)', async () => {
    const { AuthService } = await import('../src/server/services/auth.ts');
    const at = AuthService.generateAccessToken({
      id: 'u1', username: 'alice', displayName: 'Alice',
    } as any);
    const decoded = AuthService.verifyAccessToken(at);
    expect(decoded).not.toBeNull();
    expect(AuthService.isMediaToken(decoded)).toBe(false);
  });

  it('media tokens expire (exp claim within 120s + clock skew)', async () => {
    const { AuthService } = await import('../src/server/services/auth.ts');
    const mt = AuthService.generateMediaToken({ userId: 'u1', username: 'a', displayName: 'a' });
    const decoded: any = AuthService.verifyAccessToken(mt);
    expect(decoded.exp - decoded.iat).toBeLessThanOrEqual(120);
  });
});

// ── 2. Snapshot encryption ─────────────────────────────────────────────────────
describe('Snapshot at-rest encryption (P2)', () => {
  it('roundtrips arbitrary JSON payloads', async () => {
    const { encryptSnapshot, decryptSnapshot } = await import('../src/server/database.ts');
    const payload = JSON.stringify({ users: [['u1', { name: 'أحمد', note: 'سلام 👋' }]] });
    const enc = encryptSnapshot(payload);
    expect(enc.startsWith('ENC1:')).toBe(true);
    expect(enc).not.toContain('أحمد'); // ciphertext never leaks plaintext
    expect(decryptSnapshot(enc)).toBe(payload);
  });

  it('produces a different ciphertext every time (random IV)', async () => {
    const { encryptSnapshot } = await import('../src/server/database.ts');
    const a = encryptSnapshot('same-input');
    const b = encryptSnapshot('same-input');
    expect(a).not.toBe(b);
  });

  it('rejects tampered ciphertext (GCM auth tag)', async () => {
    const { encryptSnapshot, decryptSnapshot } = await import('../src/server/database.ts');
    const enc = encryptSnapshot('{"v":1}');
    const blob = Buffer.from(enc.slice(5), 'base64');
    blob[blob.length - 1] ^= 0xFF; // flip last ciphertext byte
    const tampered = 'ENC1:' + blob.toString('base64');
    expect(() => decryptSnapshot(tampered)).toThrow();
  });

  it('legacy plaintext snapshots remain plain JSON (detectable, loadable)', async () => {
    const { encryptSnapshot } = await import('../src/server/database.ts');
    const legacy = '{"version":"2.0","users":[]}';
    expect(legacy.startsWith('ENC1:')).toBe(false);       // detected as legacy by loader
    expect(encryptSnapshot(legacy).startsWith('ENC1:')).toBe(true); // and upgradeable
  });
});

// ── 3. Token vault migration ───────────────────────────────────────────────────
describe('Token vault (P1 frontend)', () => {
  const store = new Map<string, string>();
  beforeAll(() => {
    (globalThis as any).localStorage = {
      getItem: (k: string) => store.get(k) ?? null,
      setItem: (k: string, v: string) => store.set(k, v),
      removeItem: (k: string) => store.delete(k),
    };
  });
  afterAll(() => { delete (globalThis as any).localStorage; });

  it('absorbs legacy localStorage tokens exactly once and wipes them', async () => {
    const vault = await import('../src/lib/token_vault.ts');
    store.set('dirasha_token', 'legacy-access');
    store.set('dirasha_refresh_token', 'legacy-refresh');
    store.set('dirasha_session_id', 'sess-1');

    expect(vault.getAccessToken()).toBe('legacy-access');
    expect(vault.getLegacyRefreshToken()).toBe('legacy-refresh');
    // scrubbed from localStorage…
    expect(store.has('dirasha_token')).toBe(false);
    expect(store.has('dirasha_refresh_token')).toBe(false);
    // …and discarded after the migration outcome is confirmed
    vault.clearLegacyRefreshToken();
    expect(vault.getLegacyRefreshToken()).toBeNull();
    expect(vault.getSessionId()).toBe('sess-1');
  });

  it('keeps runtime tokens in memory only', async () => {
    const vault = await import('../src/lib/token_vault.ts');
    vault.setAccessToken('fresh-access');
    vault.setSessionId('sess-2');
    expect(vault.getAccessToken()).toBe('fresh-access');
    expect(store.has('dirasha_token')).toBe(false); // never written to storage
    vault.clearVault();
    expect(vault.getAccessToken()).toBe('');
    expect(vault.getSessionId()).toBeNull();
  });
});

// ── 4. Password storage v2 (OWASP params) ──────────────────────────────────────
describe('scrypt v2 + legacy migration (V2)', () => {
  it('new hashes use OWASP-equivalent v2 params in the versioned format', async () => {
    const { hashSecret, verifySecretDetailed } = await import('../src/server/services/password.ts');
    const h = await hashSecret('Str0ng#Pass99');
    expect(h.startsWith('scrypt$v2$32768$8$3$')).toBe(true);
    const r = await verifySecretDetailed('Str0ng#Pass99', h);
    expect(r).toEqual({ ok: true, version: 'v2', needsRehash: false });
  });

  it('legacy v1 hashes still verify and are flagged needsRehash', async () => {
    const { verifySecretDetailed } = await import('../src/server/services/password.ts');
    // Hand-built v1 blob (legacy N=16384, r=8, p=1). Note: password.ts hashes the
    // PEPPERED value, so the test replicates that pipeline with the dev-fallback
    // pepper (vitest does not load .env; production uses the real AUTH_PEPPER).
    const crypto = await import('crypto');
    const peppered = crypto.createHmac('sha256', 'dirasha-dev-only-pepper').update('legacy-secret').digest();
    const salt = crypto.randomBytes(16);
    const key = await new Promise<Buffer>((resolve, reject) => {
      (crypto as any).scrypt(peppered, salt, 64, { N: 16384, r: 8, p: 1 }, (e: any, k: any) => e ? reject(e) : resolve(k));
    });
    const v1blob = `scrypt$v1$${salt.toString('base64')}$${key.toString('base64')}`;
    const r = await verifySecretDetailed('legacy-secret', v1blob);
    expect(r.ok).toBe(true);
    expect(r.version).toBe('v1');
    expect(r.needsRehash).toBe(true);
    const r2 = await verifySecretDetailed('wrong-secret', v1blob);
    expect(r2.ok).toBe(false);
  });

  it('policy: min 10 chars, passphrases allowed, blocklist + username containment', async () => {
    const { validatePasswordStrength } = await import('../src/server/services/password.ts');
    expect(validatePasswordStrength('short').isValid).toBe(false);
    expect(validatePasswordStrength('a'.repeat(129)).isValid).toBe(false);
    expect(validatePasswordStrength('correct-horse-battery-staple-2026').isValid).toBe(true); // passphrase, no composition rule
    expect(validatePasswordStrength('password1').isValid).toBe(false);
    expect(validatePasswordStrength('MyPassword2026', 'MyPassword').isValid).toBe(false); // contains username
    expect(validatePasswordStrength('Horse-Battery-99').isValid).toBe(true);
  });
});

// ── 5. TOTP service (otplib v13) ───────────────────────────────────────────────
describe('TOTP 2FA service (V2)', () => {
  it('enrollment → current code → verify (delta 0); wrong code rejected', async () => {
    const { createEnrollment, verifyTotp } = await import('../src/server/services/totp.ts');
    const otplib = await import('otplib');
    const { secret, otpauthUri } = createEnrollment('tester');
    expect(secret.length).toBeGreaterThanOrEqual(16);
    expect(otpauthUri.startsWith('otpauth://totp/Dirasha:tester')).toBe(true);
    const code = otplib.generateSync({ secret });
    expect(verifyTotp(code, secret)).toBe(0);
    expect(verifyTotp('000000', secret)).toBeNull();
  });
});
