/**
 * AUTH-04 + E2EE-09 + AUTH-05(client) — App.tsx client hardening (static).
 *
 * Test split (repo convention — src/App.tsx boots side effects at import, so
 * in-process render tests are impossible; see tests/group-membership.test.ts):
 * STATIC-SOURCE asserts only, against the real src/App.tsx source:
 *
 *   1. AUTH-04: the screen lock has NO default passcode — the '0000' fallback
 *      is gone, the lock screen cannot appear while no passcode is set, and
 *      the PIN comparison fails closed. UI copy states it is a UI lock only.
 *   2. E2EE-09: the PeerNotRegisteredError branch FAILS CLOSED — the send
 *      aborts (no msg:send wire payload after it) unless the EXPLICIT
 *      per-chat localStorage opt-in 'e2eeAllowPlaintext:<chatId>' = '1'
 *      exists, which is set ONLY after a window.confirm disclosing the
 *      message will be sent UNENCRYPTED; pushSecurityEvent('downgrade') fires
 *      on both the abort and the confirm path.
 *   3. AUTH-05 (client half): attachment-bytes fetches ride the short-lived
 *      SCOPED media token (/api/media-token, Bearer, ~90s cache, in-flight
 *      guard) — the long-lived access JWT never appears in media URLs.
 *
 * Run: npx vitest run tests/app-client-hardening.test.ts
 */
import { describe, it, expect } from 'vitest';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const appSrc = fs.readFileSync(path.join(repoRoot, 'src', 'App.tsx'), 'utf8');

/* ── helpers ───────────────────────────────────────────────────────────────── */

/** Slice of appSrc from `startMarker` up to (excluding) `endMarker`. */
function sliceBetween(startMarker: string, endMarker: string): string {
  const start = appSrc.indexOf(startMarker);
  expect(start, `marker not found: ${startMarker}`).toBeGreaterThanOrEqual(0);
  const end = appSrc.indexOf(endMarker, start);
  expect(end, `end marker not found after ${startMarker}: ${endMarker}`).toBeGreaterThan(start);
  return appSrc.slice(start, end);
}

/* ── 1. AUTH-04: screen lock is a UI lock only, no default passcode ────────── */

describe('AUTH-04 — screen lock has no default passcode (static)', () => {
  it("the '0000' default passcode is gone entirely", () => {
    expect(appSrc).not.toContain("'0000'");
    expect(appSrc).not.toContain('"0000"');
    expect(appSrc).not.toContain("screenLockPasscode || '0000'");
  });

  it('the lock screen cannot appear while no passcode is set (gated on a 4-digit passcode)', () => {
    const gate = sliceBetween(
      'const showLockScreen =',
      'const handleKeyPress = (num: string) => {',
    );
    expect(gate).toContain('!!currentUser?.privacySettings?.screenLockEnabled');
    expect(gate).toContain('screenLockPasscode.length === 4');
    expect(gate).toContain('!passcodeUnlocked');
  });

  it('the PIN comparison fails closed — no fallback constant can unlock', () => {
    const cmp = sliceBetween(
      'if (newPin.length === 4) {',
      'setPasscodeUnlocked(true);',
    );
    expect(cmp).toContain('correctPin.length === 4 && newPin === correctPin');
    expect(cmp).not.toContain("|| '0000'");
  });

  it('lock screen copy states it is a UI lock only (no decryption claims)', () => {
    expect(appSrc).not.toContain('Vault Locked');
    expect(appSrc).not.toContain('Enter your secure PIN');
    expect(appSrc).toContain('Screen Locked');
    expect(appSrc).toContain('privacy screen lock only');
    const copy = sliceBetween('{showLockScreen && (', '{/* Error Message */}');
    expect(copy).toContain('does not encrypt or decrypt any data');
  });

  it('the passcode is only read locally in App.tsx — never written to any API payload', () => {
    // All App.tsx occurrences must be the local read + comparison.
    const reads = appSrc.split('privacySettings?.screenLockPasscode').length - 1
      + appSrc.split('privacySettings.screenLockPasscode').length - 1;
    expect(reads).toBeGreaterThanOrEqual(1);
    expect(appSrc).not.toContain("'privacySettings.screenLockPasscode'");
    expect(appSrc).not.toContain('"privacySettings.screenLockPasscode"');
  });
});

/* ── 2. E2EE-09: no silent plaintext downgrade on PeerNotRegisteredError ───── */

describe('E2EE-09 — PeerNotRegisteredError fails closed (static)', () => {
  const branchStart = appSrc.indexOf("if (err?.name === 'PeerNotRegisteredError')");
  const branchSrc = (() => {
    expect(branchStart, 'PeerNotRegisteredError branch missing from App.tsx').toBeGreaterThanOrEqual(0);
    const end = appSrc.indexOf('        } else {', branchStart);
    expect(end).toBeGreaterThan(branchStart);
    return appSrc.slice(branchStart, end);
  })();

  it('exactly ONE PeerNotRegisteredError branch exists (no other fallbacks in send paths)', () => {
    expect(appSrc.split("err?.name === 'PeerNotRegisteredError'").length - 1).toBe(1);
  });

  it('default path ABORTS the send — control never reaches the wire payload', () => {
    expect(branchSrc).toContain('return;');
    // No msg:send emit can appear inside the branch itself.
    expect(branchSrc).not.toContain("emit('msg:send'");
    // The abort toast is present and before the branch end.
    expect(branchSrc).toContain('الطرف الآخر غير مسجل للتشفير — الرسالة لم تُرسل');
  });

  it('downgrade badge (F8 memory) is kept on the PeerNotRegisteredError path', () => {
    expect(branchSrc).toContain('setActiveChatDowngraded(true)');
    expect(appSrc).not.toContain('availability first');
  });

  it('per-chat plaintext opt-in flag is gated on localStorage, set ONLY after window.confirm', () => {
    expect(branchSrc).toContain('e2eeAllowPlaintext:');
    expect(branchSrc).toContain("localStorage.getItem(allowPlaintextKey) === '1'");
    const confirmIdx = branchSrc.indexOf('window.confirm(');
    const setIdx = branchSrc.indexOf("localStorage.setItem(allowPlaintextKey, '1')");
    expect(confirmIdx, 'window.confirm must gate the opt-in').toBeGreaterThanOrEqual(0);
    expect(setIdx, 'localStorage.setItem of the opt-in flag missing').toBeGreaterThanOrEqual(0);
    expect(confirmIdx).toBeLessThan(setIdx);
    // The confirm dialog discloses the UNENCRYPTED send.
    expect(branchSrc).toContain('بدون تشفير');
  });

  it("pushSecurityEvent('downgrade') fires on BOTH the abort and the confirm path", () => {
    const hits = branchSrc.split("pushSecurityEvent('downgrade'").length - 1;
    expect(hits).toBe(2);
    expect(branchSrc).toContain("stage: 'send-aborted'");
    expect(branchSrc).toContain("send-confirmed");
  });

  it('the group send path still aborts on crypto failure (no plaintext fallback there either)', () => {
    const groupWrap = sliceBetween(
      'const activeGroupChat =',
      "if (e2eePeer && (wireContent || hasAttachments)) {",
    );
    expect(groupWrap).toContain("showToast('تعذر تشفير الرسالة', 'error')");
    expect(groupWrap).toContain('return;');
  });
});

/* ── 3. AUTH-05 (client half): scoped media token, never the access JWT ────── */

describe('AUTH-05 client — scoped short-lived media token for attachment fetches (static)', () => {
  it('a scoped media-token fetcher exists against /api/media-token with Bearer auth', () => {
    expect(appSrc).toContain('getAppScopedMediaToken');
    expect(appSrc).toContain("fetch('/api/media-token'");
    expect(appSrc).toContain("Authorization: 'Bearer ' + accessToken");
  });

  it('the token is cached ~90s with an in-flight guard', () => {
    expect(appSrc).toContain('appMediaTokenCache');
    expect(appSrc).toContain('Date.now() + 90_000');
    expect(appSrc).toContain('appMediaTokenInflight.p');
  });

  it('attachment-bytes fetch appends the SCOPED media token, not the access JWT', () => {
    expect(appSrc).toContain('access_token=${mt}');
    expect(appSrc).not.toContain('access_token=${accessToken}');
    expect(appSrc).not.toContain("access_token=' + accessToken");
  });

  it('token failure leaves the URL WITHOUT a token (honest 401, no JWT fallback)', () => {
    const fetchSite = sliceBetween(
      '} else if (att?.url && typeof att.url === \'string\') {',
      'if (!bytes || bytes.length === 0) {',
    );
    expect(fetchSite).toContain('getAppScopedMediaToken(accessToken)');
    // The src ternary falls back to the bare URL (no token appended).
    expect(fetchSite).toContain(': att.url;');
    expect(fetchSite).not.toContain('access_token=${accessToken}');
  });
});
