/**
 * BATCH-4 regression tests (DIR-CB-02 / AB-05 / AB-04 / CB-03).
 *   b4-1  Reuse detection consults the DURABLE spent ledger on history miss.
 *   b4-2  findSessionBySpentToken: memory + PG lookup paths exist.
 *   b4-3  getSessionById has a PG fallback (cross-instance revocation).
 *   b4-4  WS upgrade rejects banned users on the ticket path.
 *   b4-5  URL media tokens are MEDIA-ROUTE-scoped.
 */
import { describe, it, expect } from 'vitest';
import { readFileSync } from 'fs';
import path from 'path';

const repo = path.resolve(__dirname, '..');
const read = (p: string) => readFileSync(path.join(repo, p), 'utf8');

describe('BATCH-4 remediation (CB-02/AB-05/AB-04/CB-03)', () => {
  it('b4-1 reuse detector falls back to the durable spent ledger', () => {
    const auth = read('src/server/services/auth.ts');
    expect(auth).toMatch(/findSessionBySpentToken\(tokenHash\)/);
    expect(auth).toMatch(/BATCH-4 \(DIR-CB-02\)/);
    expect(auth).not.toMatch(/if \(!remembered\) return null; \/\/ unknown token — plain reject/);
  });

  it('b4-2 durable spent-token lookup exists (memory + PG)', () => {
    const db = read('src/server/database.ts');
    expect(db).toMatch(/public async findSessionBySpentToken/);
    expect(db).toMatch(/FROM spent_refresh_tokens sp/);
  });

  it('b4-3 session lookup has PG fallback', () => {
    const db = read('src/server/database.ts');
    const region = db.slice(db.indexOf('public async getSessionById'), db.indexOf('public async getSessionById') + 1200);
    expect(region).toMatch(/SELECT \* FROM user_sessions WHERE id = \$1/);
    expect(region).toMatch(/BATCH-4 \(DIR-AB-05\)/);
  });

  it('b4-4 WS upgrade checks ban state', () => {
    const ws = read('src/server/websocket/ws_server.ts');
    const region = ws.slice(ws.indexOf('ticketUser'), ws.indexOf('ticketUser') + 1600);
    expect(region).toMatch(/isBanned/);
    expect(region).toMatch(/banned user .* attempted WS upgrade/);
  });

  it('b4-5 URL media tokens restricted to media routes', () => {
    const srv = read('server.ts');
    expect(srv).toMatch(/URL media tokens are MEDIA-ROUTE-scoped/);
    expect(srv).toMatch(/p\.startsWith\('\/api\/media\/'\) \|\| p\.startsWith\('\/uploads\/'\)/);
  });
});
