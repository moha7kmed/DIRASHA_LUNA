# ديراشة | Dirasha

منصة محادثات فورية عربية (رسائل ومرفقات، حالات، مكالمات WebRTC، إشعارات Web Push) مع لوحة إشراف ومركز مراقبة.

## البنية التقنية (الجيل الثالث — هوية ذاتية السيادة)

| الطبقة | التقنية |
|---|---|
| الواجهة | React 19 + Vite + TailwindCSS 4 + motion/react |
| الخادم | Node.js + Express + WebSocket (`ws`) |
| المصادقة | **اسم مستخدم فريد + كلمة مرور** (بدون SMS/OAuth) — scrypt + Salt + Pepper |
| الاسترجاع | **PIN إجباري + بصمة جهاز مشفّرة** → رابط إعادة تعيين مرة واحدة (10 دقائق) |
| الجلسات | JWT قصير (15 د) + Refresh دوّار (7 أيام) + كشف سرقة الرموز |
| قاعدة البيانات | PostgreSQL (Aiven دائم التشغيل) + محرك محلي احتياطي للتطوير |
| الوسائط | **BYO-Cloud**: ملفات المستخدم تُرفع مباشرة لتخزينه (R2/B2/S3/MinIO) عبر presign — لا تلمس قاعدتنا إطلاقاً |

## التشغيل
```bash
npm install
npm run dev   # http://localhost:3000
```

## الهيكل
```
server.ts                 REST + WebSocket + Vite middleware
src/server/routes/        authClassic (هوية/استرجاع) · storage (BYO presign) · status · apiKeys
src/server/services/      auth (جلسات) · password (scrypt) · recovery (بصمة الجهاز) · storage · push
src/components/           PhoneAuthScreen (دخول/تسجيل/استرجاع) · StorageLinkCard · الشات والإشراف
docs/SETUP_AR.md          دليل التشغيل اليدوي الكامل
docs/HANDOFF_AR.md        ⭐ ملف تسليم المشروع + حالة التنفيذ + المشاكل المفتوحة
```

> معايير اسم المستخدم مطابقة لتطبيقات المحادثة الكبرى: 3-20 حرفاً، إنجليزي/أرقام/_/.، فريد للأبد (قيد UNIQUE ذري + رسالة "محجوز" صريحة مع اقتراحات).

> **مهم:** التطبيق حالياً يعمل على محرك تخزين **in-memory** بسبب تعطّل DNS لـ Aiven — البيانات مؤقتة حتى تُربط قاعدة البيانات (راجع `docs/HANDOFF_AR.md` §7.1).
