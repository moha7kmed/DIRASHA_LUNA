# E2EE AUDIT — Dirasha (تدقيق أمني متشكك، قراءة فقط)

> **نطاق التدقيق:** محرك E2EE والعميل (`src/lib/e2ee/*`, `src/App.tsx`, `src/lib/socket_client.ts`, `src/lib/token_vault.ts`, `src/service-worker.js`, مسارات فك التشفير في `ChatWindow.tsx`/`ChatSidebar.tsx`/`E2eeMedia.tsx`).
> **تاريخ التنفيذ:** 2026-11-17. كل `file:line` من grep/قراءة فعلية. لا تعديل على أي كود.
> **التصنيفات:** `VERIFIED` / `PARTIALLY VERIFIED` / `UNVERIFIED` / `NOT IMPLEMENTED` / `NOT APPLICABLE` / `FAILED` — وسُدّاد الشدة: `Critical` / `High` / `Medium` / `Low` / `Info`.

---

## (a) أين يحدث التشفير وفك التشفير فعليًا — وماذا يرى الخادم

### مسار الإرسال (1:1)
- التغليف يحدث في `App.tsx:4807-4825`: يُبنى حاوية الوسائط `buildEncryptedPayload(content, filesPayloads)` ثم `engine.encryptMessage(e2eePeer, payloadText)` في `App.tsx:4814`، والمحتوى على السلك `wireContent = encMsg.content` في `App.tsx:4815`. **VERIFIED**.
- داخل المحرك: `engine.ts:919-961` (`encryptMessage`) → لكل جهاز من أجهزة الطرف `initSessionAsInitiator` أو `encryptWithSession` — الختم الفعلي ChaCha20-Poly1305 في `engine.ts:997` مع AAD من `engine.ts:993`. **VERIFIED**.
- المرفقات تُشفَّر قبل الرفع: `App.tsx:4710-4762` (`encryptAttachment` من `media.ts:193-212`)، الرفع `application/octet-stream` باسم `enc.bin` (`App.tsx:4749-4762`) والمفتاح/الـiv/اسم الملف داخل المغلف المشفر. **VERIFIED**.

### مسار الإرسال (مجموعات — Sender Keys)
- `App.tsx:4767-4799`: توزيع مفتاح المرسل أولًا (`ensureGroupDistribution`) ثم `gc.encryptGroupMessage(activeChatId, groupPayload)` في `App.tsx:4794`. الفشل ⇒ abort بلا سقوط صامت للنص الصريح (`App.tsx:4796-4800`). **VERIFIED**.

### مسار الاستقبال
- رسائل 1:1 عبر WS: `App.tsx:2461-2500` — `engineForMsg.decryptMessage(e2eePeerMsg, encContent)` ثم patch في `rawMessages`. **VERIFIED**.
- رسائل المجموعات: `App.tsx:2502-2540` — `gcForMsg.decryptGroupMessage(...)` بمفتاح المرسل المستلم. **VERIFIED**.
- التاريخ: `decryptHistoryMessages` (`App.tsx:1789-1869`) تُفكّك دفعات الخادم قبل العرض/التخزين المؤقت. **VERIFIED**.
- فك تشفير المرفقات: `E2eeMedia.tsx:75` — `decryptAttachment(payload, bytes)` مع تحقق AEAD + sha256 + الحجم (`media.ts:219-242`). **VERIFIED**.

### ما يراه الخادم / ما لا يراه — VERIFIED
- **لا يراه الخادم:** نص الرسالة، مفاتيح الوسائط (`filesPayloads` داخل المغلف فقط — `media.ts:74-92` jsdoc والكود `App.tsx:4749-4762`)، مفاتيح المرسل للمجموعات (تسير داخل DIR1 pairwise — `App.tsx:1677-1686`).
- **يراه الخادم (metadata):** chatId، senderId، الأحجام بعد حجب الـbuckets (حتى 64KB ثم يتسرب المقدار التقريبي — `padding.ts:9-15`)، التوقيت، عدد الرسائل، عناوين رفع الوسائط، قوائم الأجهزة والمفاتيح العامة. **VERIFIED**.
- **مسارات bypass / هبوط:**
  1. **هبوط إلى نص صريح عند 404 (بالتصميم):** `engine.ts:602-614` — فقط 404 أو `registered:false` صريح يُنتج `PeerNotRegisteredError`؛ 429/5xx يفشل مُغلقًا (جيد). لكن المستوى الأعلى يستغل الاستثناء للإرسال الصريح: `App.tsx:4818-4821` (`if (err?.name === 'PeerNotRegisteredError') { // Peer has no E2EE bundle → send plaintext }`) ومسار رفض الاتصال `App.tsx:1461-1468`. **الخادم المخترق/الشرير يمكنه إجبار هبوط دائم بإرجاع 404 لـ bundle الطرف** — الشدة: **Medium** (هجوم داخلية-خادم؛ العميل لا يُذكّر المستخدم بحدوث الهبوط ولا يتذكر "كان مشفرًا").
  2. المحتوى غير-MAGIC يمر كنص: `engine.ts:1060` — `if (!content.startsWith(WIRE_PREFIX)) return { plaintext: content };` — أي محتوى بدون `DIR1:`/`DIRM1:` يعامل كنص صريح. هذا صحيح للتوافق لكنه يعني أن قناة `msg:new` تخلط النص الصريح والمشفر بلا سياسة. الشدة: **Info**.

---

## (b) دورة حياة المفاتيح

### التوليد (CSPRNG) — VERIFIED
- الهوية/SPK/OPK: `engine.ts:457-477` عبر `generateX25519`/`generateEd25519` (`crypto.ts:167-175`) — CSPRNG موحّد `crypto.getRandomValues` ثم `Buffer.randomBytes` fallback، ورمي عند غياب الاثنين (`crypto.ts:119-129`). **VERIFIED**.
- OPK: persist-قبل-الإعلان `engine.ts:423-435` (crash-safe: priv قبل pub). **VERIFIED**.
- PQ prekey: persist قبل الإعلان `engine.ts:366-373`. **VERIFIED**.

### التوزيع (Key directory)
- `fetchPeerDevices` — `engine.ts:594-634`: `GET /api/e2ee/bundle/:userId` مع TTL cache 5 دقائق (`engine.ts:99`, `engine.ts:596-599`). fail-closed على 429/5xx (`engine.ts:601-614`). **VERIFIED**.
- **نقطة ثقة:** الـbundle يأتي من الخادم بلا تحقق Key Transparency فعلي (انظر §d و§g-8). الخادم يقدر يستبدل مفاتيح الطرف (MITM كلاسيكي على X3DH). Ed25519 يربط SPK/PQ بالهوية **التي يقدمها الخادم نفسه**. الشدة: **High** (ثقة TOFU-بلا-سجل — عميل KT موجود لكنه ميت).
- **ملاحظة تنفيذية:** cache الأجهزة يُمحى بعد استهلاك OPK (`engine.ts:745`) — جيد، يمنع إعادة استهلاك نفس OPK من الكاش. **VERIFIED**.

### التخزين (Vault) — الحد الحقيقي موثّق
- كل KV يمر عبر `VaultKVStore` (`App.tsx:1575-1577` للـengine و`App.tsx:1604` للمجموعات) — AES-GCM-256 بمفتاح غير قابل للاستخراج (`vault.ts:95-101`). **VERIFIED**.
- **حد النموذج (حاسم):** KEK مخزّن في IndexedDB (`dirasha-vault`) **بجانب** البيانات الملفوفة (`vault.ts:30-33`, `vault.ts:42-86`). أي كود يعمل بامتيازات الصفحة (XSS، إضافة متصفح خبيثة، كود npm مخترق) يمكنه استدعاء `crypto.subtle` ويقرأ KEK عبر IndexedDB ثم يفك كل شيء — jsdoc الملف يعترف بذلك حرفيًا (`vault.ts:9-12`). الخزنة تحمي **سرقة ملفات القرص فقط**. **VERIFIED** كحدّ.
- الخزنة **لا تحمي**: `dirashaMessagesDB` (نصوص صريحة — انظر §c)، `dirashaOutboxDB` (المغلفات مشفرة لكن `e2eeFiles` بمفاتيح الوسائط تُخزن صريحة — `App.tsx:4882`)، `localStorage` (أعلام safety-number/distribution — metadata فقط). **VERIFIED**.

### الدوران (emergencyRotate) — VERIFIED مع ملاحظات
- `engine.ts:1383-1468`: محو كل الجلسات (`session:*`, `x3dh-dropped:*`) `engine.ts:1397-1402` → هوية جديدة `engine.ts:1414-1424` → SPK جديد `engine.ts:1427-1429` → محو كل OPK privs + PQ prekey `engine.ts:1436-1440` → 100 OPK جديدة `engine.ts:1444` → إعادة تسجيل بنفس deviceId `engine.ts:1456-1466`. الترتيب persist-قبل-الشبكة موثّق (`engine.ts:1422-1424`). **VERIFIED**.
- ملاحظة: المحو يشمل الجلسات فقط — لا يمحو `MessagesCacheDB` ولا `OutboxDB` ولا `ChatsCacheDB`: بعد الدوران الطارئ تبقى النصوص الصريحة للمحادثات القديمة على القرص بينما تُمحى المفاتيح. الشدة: **Low** (النص كان محميًا بمفاتيح مُلغاة، لكنه يبقى مقروءًا لمن يسرق القرص — وهو نفسه محمي بلا خزنة أصلًا).
- استهلاك singleton للدوران (`engine.ts:289`, `engine.ts:1384-1389`). **VERIFIED**.

### الإلغاء والسحب
- `e2ee:rekey` من الخادم ⇒ `deleteSession(peerId)` + علم تحذير (`App.tsx:3356-3361`). **VERIFIED**.
- حذف الجلسات الكامل: `engine.ts:578-585` (كل `session:<peerId>:*` + legacy). **VERIFIED**.
- **لا يوجد إلغاء للأجهزة من جهة العميل في نطاق الفحص** (إدارة الأجهزة خارج src/lib/e2ee) — **UNVERIFIED** خارج النطاق.

### حذف OPK (cleanup) — الترتيب VERIFIED
- النقطة الوحيدة للحذف: `engine.ts:1328-1335` — بعد (1) نجاح AEAD للـbootstrap، (2) اشتقاق جلسة المستجيب، (3) **persist الجلسة** — `persist-session-then-delete-priv` صراحة (`engine.ts:1301-1327` تعليق). الحذف best-effort بلا فشل يظهر للمستخدم. **VERIFIED**.
- حراس إعادة اللعب قبل قراءة أي مادة مفاتيح: `bootstrappedEk` (`engine.ts:1241-1243`), `retiredEks` (`engine.ts:1251-1253`), `retiredIks` (`engine.ts:1265-1267`), dropped-bootstrap ledger (`engine.ts:1272-1274`). **VERIFIED**.
- **لا يوجد سقف إخلاء (retention cap) للـOPK privs غير المستهلكة** — قرار موثّق في `engine.ts:1314-1322` (العميل لا يرى consumed flag). إيواء محتمل محدود. الشدة: **Info**.

### النسخ الاحتياطية — VERIFIED مع حدود
- scrypt(N=2^15,r=8,p=1) + HKDF + ChaCha20-Poly1305، salt عشوائي 16B لكل ملف (`backup.ts:255-273`). **VERIFIED**.
- **لا تحمل النسخة أي مفاتيح E2EE** (jsdoc صريح `backup.ts:435-444`, `backup.ts:489-494`) — محتوى الرسائل فقط. يعني: استعادة = قراءة أرشيف، لا استعادة جلسات. **VERIFIED**.
- hint = 64-bit بصمة راحة، ليست حدًا أمنيًا (`backup.ts:218-227`). **VERIFIED**.

---

## (c) السرية الأمامية (Forward Secrecy) — والمشكلة الكبرى

### ما يعمل صحيحًا — VERIFIED
- Double Ratchet قياسي: KDF_RK/KDF_CK (`crypto.ts:237-250`)، DHRatchet عند كل رسالة واردة بمفتاح DH جديد (`engine.ts:846-863`)، خطوة إرسال جديدة عند `ckS === null` (`engine.ts:976-986`).
- derive-then-commit: كل الطفرات على clone والكتابة بعد نجاح AEAD (`engine.ts:138-142`, `engine.ts:1155-1161`, `engine.ts:1275-1300`). **VERIFIED**.
- حذف مفاتيح الرسائل المستهلكة: `delete s.skipped[skippedKey]` بعد الاستخدام (`engine.ts:871-873`)، وmk أحادية الاستخدام (كل رسالة تُتقدم ck). **VERIFIED**.
- MAX_SKIP=2000 مع إخلاء الأقدم (`engine.ts:834`, `engine.ts:840-841`). **VERIFIED**.

### **المشكلة الكبرى: كاش الرسائل يخزن النص الصريح** — الشدة: **Critical** (من منظور "local FS")
- **الدليل:**
  - `App.tsx:1789-1869` — `decryptHistoryMessages` تستبدل `item.content` **بالنص الصريح** (فرع المجموعات `App.tsx:1826-1827`، فرع 1:1 `App.tsx:1841-1842`: `item.content = parsed.text;`).
  - `App.tsx:4126` — الكاش المقروء يُفك ثم يُعاد للعرض؛ `App.tsx:4145` دفعة الخادم تُفك "قبل الدمج (plaintext is cached)" — التعليق نفسه يقول ذلك (`App.tsx:4144`: `// E2EE: decrypt server batch before merge (plaintext is cached).`).
  - **الإسناد الحاسم:** `App.tsx:4172`, `App.tsx:4202`, `App.tsx:4259` (continuous effect يكتب `rawMessages` — المحتوى مُفكوك — عند كل تغيير), `App.tsx:4346`, `App.tsx:4656` — كلها تكتب في `MessagesCacheDB.put`.
  - `messages_cache_db.ts:4` — قاعدة IndexedDB اسمها `dirashaMessagesDB`، **خارج الخزنة تمامًا** (لا `VaultKVStore` — الخزنة تغلف فقط KV المحرك). تخزن آخر 150 رسالة لكل محادثة (`messages_cache_db.ts:107-110`).
- **النتيجة:** الخزنة (vault) تحمي مفاتيح المحرك، لكن **النص الصريح نفسه ينام على القرص بلا تشفير** في `dirashaMessagesDB` — السرقة المادية/الطبية للقرص أو النسخ الاحتياطي للمتصفح تعطي آخر 150 رسالة لكل محادثة مفتوحة نصًا صريحًا. كل وعود Forward-Secrecy على القرص **مُهمَلة عمليًا** لهذه النافذة.
- **وسوء إضافي:** كائنات الرسائل المحفوظة تشمل `e2eeFiles` — أي **مفاتيح فك تشفير المرفقات (media keys) بصيغة صريحة** (`App.tsx:1827` و`App.tsx:1842` تضع `item.e2eeFiles = parsed.files`) تُخزن مع الرسالة في نفس الكاش. مرفق مسروق من الخادم + مفتاحه من الكاش = فك تشفير كامل.
- وكذلك `dirashaOutboxDB` يحمل `e2eeFiles` صريحة (`App.tsx:4882`) — المغلف في الـoutbox مشفر (جيد، `App.tsx:4875`: `content: wireContent`) لكن مفاتيح المرفقات ليست كذلك.
- **ما لا تحميه الخزنة إذًا:** كل IndexedDB خارج `dirasha-e2ee` — أي messages/outbox/chats caches. **VERIFIED** (فحص الكود: `VaultKVStore` يُستخدم فقط في `App.tsx:1575` و`App.tsx:1604`).
- **التصنيف:** الخصم المستهدف = سرقة القرص/النسخ الاحتياطي. حسب ادعاء المشروع عن FS، هذا الثغرة **High → Critical**؛ صنفناه **Critical** لأنه يعاقب الضحية سلبًا حتى مع سليم الكتابة العليا (adversary-at-rest).

### ملاحظات إضافية على FS
- الجلسة نفسها لا تُحفظ إلا بعد AEAD؛ رفض إعادة اللعب يمنع استرجاع سلسلة قديمة (`engine.ts:1241-1274`). **VERIFIED**.
- لا يوجد شطب زمني (msg TTL) على الكاش المحلي — `MessagesCacheDB.clear()` موجود (`messages_cache_db.ts:130`) لكن لا استدعاء تلقائي بعد `emergencyRotate` (grep: لا استدعاء في مسار الدوران). **PARTIALLY VERIFIED** (أداة الحذف موجودة، الربط غائب).

---

## (d) ما بعد الكم (PQXDH)

- **البناء الهجين VERIFIED في الكود:** IKM واحد `F || DH1..DH4 || PQ_SS` — المُبادِر `engine.ts:703-709`، المستجيب يطابق بالضبط `engine.ts:797-803` (نفس ترتيب الأدوار). SK الهجين بمعلومات `DirashaX3DH-PQ-v1` (`crypto.ts:270-272`) — تمييز صريح عن الكلاسيكي `DirashaX3DH-v1` (`crypto.ts:257-259`). **VERIFIED**.
- **ربط PQ بالهوية:** توقيع مركّب `DirashaPQSPK-v1:` + spkPub + pqPub يتحقق من العميل (`engine.ts:683-686`)، والتوليد `engine.ts:505-508`. **VERIFIED**.
- **منع الهبوط داخل المحرك:** pq:true ⇒ إلزامي hybrid بلا fallback (`engine.ts:646-653` تعليق التصميم، `engine.ts:668-693` البوابة)؛ مغلف pq:1 فاشل فكه يفشل مُغلقًا (`engine.ts:774-783`); اتساق flag/pqCt مفروض في الشكل (`engine.ts:260-265`). **VERIFIED**.
- **حد الهبوط المتبقي (سلوك فعلي):** قرار hybrid يعتمد على flag الخادم `device.pq` في الـbundle (`engine.ts:668`). **لا يوجد ذاكرة عميل لـ"هذا الطرف كان pq:true"** — خادم مخترق يعيد bundle بلا `pq` ⇒ هبوط كلاسيكي صامت. الشدة: **Medium** (يتطلب خادمًا شريرًا؛ عميل KT الميت لم يوفر كشفًا).
- **اختبار:** `tests/e2e-pq.test.ts` موجود (فحص وجوده VERIFIED) لكن لم يُنفذ ضمن هذا التدقيق المستقل؛ تصنيف الجاهزية: **implemented + PARTIALLY VERIFIED** (مُنفذ في الكود، غير مُعاد التحقق منه هنا).
- عمليًا: مغلفات pq الحية تحمل `pq:1` + `pqCt` على مستوى المغلف (`engine.ts:1021-1024`) مع فحص طول 1088B (`engine.ts:262`). **VERIFIED**.

## (e) تعدد الأجهزة (fleet model / DIRM1)

- جلسات لكل جهاز طرف: `session:<peerId>:<deviceId>` (`engine.ts:159-161`)، migration lazy من المفتاح القديم (`engine.ts:382-389`). **VERIFIED**.
- DIRM1: حاوية متعددة الأجهزة `engine.ts:959-961`, تحليل صارم `engine.ts:194-233`; وضع chunked يرسل DIR1 لكل جهاز (`engine.ts:950-957`) — يُستخدم لقنوات ctrl (`App.tsx:1678`) بسبب سقف النقل ~8KB. **VERIFIED**.
- `MAX_DEVICES = 6` (`crypto.ts:39`) بينما التعليقات تقول سقف الخادم 8 (`engine.ts:630`, `engine.ts:38`) — **تناقض توثيقي**: أجهزة 7-8 في الـbundle ستُقصّ بصمت `engine.ts:631`. الشدة: **Low** (فقدان تسليم لا تسريب).
- **تسريب محتمل بين أجهزة/حسابات:** لا يوجد — كل مغلف يُشفر لمفتاح الجلسة الخاص بالجهاز؛ `sd` تعلن جهاز المرسل (`engine.ts:1005`) و`verifyIdentityCurrency` تتحقق من ik لكل جهاز (`engine.ts:1113-1136`). لكن الشيك **يفشل مفتوحًا** عند فشل النقل (`engine.ts:1125` — `return true; // fail open (availability)`) — خادم يخنق الـbundle endpoint يعطل حارس الهوية للـbootstraps. الشدة: **Low** (متاحية-مقصودة، نطاق ضيق: bootstraps فقط).
- mixed-version tolerance: DIRM1 بغلاف واحد غير موجّه لنا يُقبل (`engine.ts:1082-1083`) — حافة توافق، لا تسريب (المغلف لا يفك إلا بمفاتيحنا).

## (f) مفاتيح المرسل للمجموعات (Sender Keys)

- **نموذج الثقة:** مفتاح المرسل 32B لكل (عضو، مجموعة) (`group.ts:184-224`)، يوزَّع pairwise داخل DIR1 (`App.tsx:1677-1686`) — أي يرث أمان X3DH/1:1. **VERIFIED**. السلسلة stateless: `mk_n = HKDF(senderKey, info='...|n')` (`group.ts:130-132`). **VERIFIED**.
- **العيوب:**
  1. **لا ربط بالعضوية:** `processControl` يقبل مفتاح مرسل من أي طرف لدينا جلسة 1:1 معه لأي groupId (`group.ts:235-254` — لا تحقق أن المرسل عضو في المجموعة؛ groupId يأتي من الـpayload نفسه). عضو شرير يمكنه **إعادة توزيع مفتاح مرسل أي عضو آخر إلى غير الأعضاء** بعد استلامه pairwise — وهجوم داخل المجموعة بنيوي (ملاحظة: نموذج Sender Keys لا يمنع الأعضاء من كشف المفاتيح؛ لكن الحد الأدنى المفقود: لا ربط groupId ببصمة قائمة أعضاء في AAD). الشدة: **Medium** (خارجي: عضو شرير كشف مفتاح؛ الدوران عند الطرد جزئي علاج).
  2. **لا رصيد للدوران على الأحداث المفقودة:** الدوران عند الطرد يعتمد على حدث WS `chat:evicted` من الخادم (`App.tsx:2839-2863`) — خادم يكبت الحدث ⇒ المطرود يبقى قادرًا على فك رسائل المرسلين الذين لم يدوروا. الشدة: **Medium** (ثقة خادم).
  3. **بلا Forward secrecy داخل المجموعة:** مفتاح المرسل ثابت حتى الدوران اليدوي — اختراق الجهاز يكشف كل رسائل المجموعة القديمة (طالما مخزنة) والقادمة لذلك المرسل. هذا معروف في Sender Keys، لكن لا يوجد دوران دوري مجدول في الكود (grep: `rotateSenderKey` مستخدم فقط عند الطرد `App.tsx:2852`). الشدة: **Medium**.
  4. **بلا حماية إعادة لعب:** لا تتبع `n` مُستهلكة في `decryptGroupMessage` (`group.ts:294-346` — فك أي n بمالك المفتاح ينجح دائمًا)؛ خادم/عضو يعيد إرسال `DIRG1` قديمة تظهر كرسالة "جديدة". الشدة: **Low** (إزعاج/تضليل، لا كشف سر).
  5. **key-request غير مقيد:** أي طرف يستطيع إنشاء جلسة 1:1 معنا يرسل `key-request` لأي groupId ⇒ نعيد توزيع مفتاحنا له (`App.tsx:3377-3383` + `App.tsx:1709-1721`). بلا تحقق عضوية، أي حساب مسجَّل يطلب مفتاح مرسل لمجموعة لا ينتمي إليها — **وإن صار يملك مفتاح مرسلنا يستطيع فك رسائلنا في تلك المجموعة** (وهي مطابقة للبند 1). الشدة: **High** كمسألة مركّبة مع غياب ربط العضوية (لاحظ: groupId معروف من رسائل سابقة/تخمين).
  - تخفيف موجود: ctrl يمر عبر DIR1 ⇒ الخادم لا يقرأه؛ لكن العضوية غير مُلزمة تشفيريًا. **VERIFIED** كوصف.

## (g) نقاط الضعف المكتشفة — ملخص بالشدة

| # | الشدة | الوصف | الدليل (file:line) |
|---|---|---|---|
| 1 | **Critical** | النص الصريح للرسائل ينام في IndexedDB غير مشفرة (`dirashaMessagesDB`, آخر 150 رسالة/محادثة) مع مفاتيح فك تشفير المرفقات (`e2eeFiles`) — يُلغي Forward Secrecy على القرص والخزنة لا تغطيه | `App.tsx:4144`, `App.tsx:4172`, `App.tsx:4202`, `App.tsx:4259`, `App.tsx:4346`, `App.tsx:4656`, `App.tsx:1826-1827`, `App.tsx:1841-1842`, `messages_cache_db.ts:4` |
| 2 | **High** | ثقة TOFU بلا سجل شفافية فعلي: الـbundle من الخادم؛ عميل KT (kt-client.ts) **كود ميت** غير مستورد ولا في الاختبارات — خادم/MITM يستبدل مفاتيح الطرف دون كشف عميل | `kt-client.ts` (grep: بلا مستوردين), `engine.ts:594-634` |
| 3 | **High** | طلب مفاتيح المجموعات بلا ربط عضوية: أي طرف بجلسة 1:1 يستلم مفتاح مرسلنا لأي groupId عبر key-request — ينتقل إلى تسريب محتوى مجموعة | `App.tsx:3377-3383`, `App.tsx:1709-1721`, `group.ts:235-254` |
| 4 | **Medium** | هبوط إجباري إلى نص صريح: خادم يعيد 404 على bundle ⇒ العميل يرسل plaintext، بلا تحذير أو ذاكرة هبوط | `engine.ts:602-614`, `App.tsx:4818-4821`, `App.tsx:1461-1468` |
| 5 | **Medium** | هبوط PQ يعتمد على flag الخادم بلا ذاكرة عميل لـpq:true السابق — خادم مخترق يهبط للكلاسيكي صامتًا | `engine.ts:668`, `engine.ts:616-634` |
| 6 | **Medium** | دوران مفاتيح المجموعة عند الطرد يعتمد على حدث خادم `chat:evicted`؛ كبت الحدث يُبقي المطرود قادرًا على الفك | `App.tsx:2839-2863` |
| 7 | **Medium** | مفاتيح الوسائط (`e2eeFiles`) صريحة في `dirashaOutboxDB` وكاش الرسائل (جزء من #1 لكن يستحق ترميمًا مستقلًا) | `App.tsx:4882`, `App.tsx:4850` |
| 8 | **Medium** | بلا FS داخل المجموعات: مفتاح المرسل ثابت بلا دوران دوري؛ اختراق الجهاز يكشف تاريخ المجموعة للمُرسل | `group.ts:184-224`, grep: `rotateSenderKey` فقط عند الطرد |
| 9 | **Low** | `verifyIdentityCurrency` يفشل مفتوحًا عند فشل النقل/429 (متاحية) — خنق الـendpoint يعطل حارس إعادة لعب الهوية للـbootstraps | `engine.ts:1124-1127` |
| 10 | **Low** | تناقض سقف الأجهزة: MAX_DEVICES=6 مقابل تعليق سقف الخادم 8 — أجهزة 7/8 تُقص بصمت | `crypto.ts:39`, `engine.ts:630-631` |
| 11 | **Low** | `emergencyRotate` لا يمحو `MessagesCacheDB`/`OutboxDB` — النصوص الصريحة القديمة تبقى بعد الدوران | `engine.ts:1397-1444` (لا استدعاء للكاش), `messages_cache_db.ts:130` |
| 12 | **Low** | JWT للـWebSocket يمر في query string (`?token=...`) — يتسرب لسجلات proxy/access-log | `socket_client.ts:137-141` |
| 13 | **Low** | إعادة لعب رسائل المجموعات ممكنة (بلا رصيد n مُستهلكة) — رسائل قديمة تعاد للعرض | `group.ts:294-346` |
| 14 | **Info** | الخزنة تحمي القرص فقط؛ كود بامتياز الصفحة يقرأ KEK عبر IndexedDB (موثق من المشروع نفسه) | `vault.ts:9-12`, `vault.ts:42-86` |
| 15 | **Info** | أسماء أعلام الحالة في localStorage (safety-number/rekey/distribution) — metadata فقط | `App.tsx:1626-1646`, `App.tsx:1763` |
| 16 | **Info** | بلا سقف احتفاظ لـOPK privs غير المستهلكة (قرار موثّق) | `engine.ts:1314-1322` |
| 17 | **Info** | service-worker: push عام بلا محتوى (جيد)؛ API لا يُخزن (جيد) | `service-worker.js:46-53`, `service-worker.js:181-230` |
| 18 | **Info** | token vault: وصول في الذاكرة فقط، refresh في HttpOnly cookie، امتصاص legacy مرة واحدة | `token_vault.ts:22-38`, `token_vault.ts:73-76` |

### ملاحظات إيجابية محقّقة (للإنصاف)
- derive-then-commit وحذف مفاتيح OPK بترتيب صارم (persist-then-delete) — `engine.ts:1301-1335`. **VERIFIED**.
- حراس إعادة اللعب الرباعي (bootstrappedEk/retiredEks/retiredIks/dropped-ledger) قبل قراءة أي مفتاح — `engine.ts:1241-1274`. **VERIFIED**.
- حجب أحجام الرسائل داخل AEAD — `padding.ts` + `engine.ts:996-997`. **VERIFIED**.
- fail-closed على 429/5xx في مسار الـbundle (يمنع خنقًا خارجيًا يهبط للتشفير) — `engine.ts:601-614`. **VERIFIED**.
- شارات UI تمنع عرض ciphertext الخام (`ChatWindow.tsx:789-794`, `ChatSidebar.tsx:2303-2307`) وفك المرفقات بتحقق ثلاثي (AEAD + size + sha256 بزمن ثابت) — `media.ts:228-242`, `E2eeMedia.tsx:75-93`. **VERIFIED**.
- Push notifications بلا محتوى رسالة — `service-worker.js:181-230`. **VERIFIED**.

---

## خلاصة التدقيق (حكم عام)

المحرك التشفيري نفسه (X3DH/PQXDH + Double Ratchet + Sender Keys + Vault + Backup) **مبني إتقانًا على مستوى البروتوكول** — الثوابت صحيحة، الترتيبات crash-safe، والحراس ضد إعادة اللعب حقيقية ومحللة. لكن:

1. **الادعاء "Forward Secrecy" لا يصمد على القرص**: كاش `dirashaMessagesDB` يخزن النص الصريح ومفاتيح الوسائط بلا خزنة. هذا أعطال قاتل لسردية "المفاتيح محمية محليًا".
2. **ثقة المفاتيح تعتمد على الخادم**: بلا عميل KT حي، وبلا ذاكرة هبوط، الخادم الشرير يفعل الكثير (استبدال هوية، هبوط plaintext، هبوط PQ، كبت دوران المجموعات). الحدود المضادة (fail-closed على 429) جيدة لكنها لا تعالج خادمًا شِرّيًا متعمدًا.
3. **المجموعات أضعف مستوى**: لا ربط عضوية في توزيع المفاتيح ولا دوران دوري ولا حماية إعادة لعب.

التوصيات ذات الأولوية (للمالك، خارج نطاق هذا التقرير التنفيذي): تشفير MessagesCacheDB عبر VaultKVStore-style KEK، ربط groupId ببصمة قائمة الأعضاء داخل ctrl/AAD، تفعيل عميل KT (مع استبدال `Buffer`)، وحذف النص من الكاش عند الدوران الطارئ.
