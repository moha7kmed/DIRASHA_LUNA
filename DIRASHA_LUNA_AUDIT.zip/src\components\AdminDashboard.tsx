/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Activity, AlertTriangle, Clock, Copy, 
  Database, ShieldAlert, Laptop, 
  MessageSquare, RefreshCw, Users, CheckCircle2,
  Server, BarChart3, AlertCircle, HardDrive, List, File, Loader2, KeyRound, Check, Plus, Trash2, Key
} from 'lucide-react';

interface AdminDashboardProps {
  accessToken: string;
  currentUser: any;
}

export function AdminDashboard({ accessToken, currentUser }: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'performance' | 'infrastructure' | 'logs' | 'api-keys'>('overview');
  const [loading, setLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [apiKeys, setApiKeys] = useState<any[]>([]);
  const [newKeyInput, setNewKeyInput] = useState('');
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [wsLiveConnected, setWsLiveConnected] = useState(false);
  
  const wsRef = useRef<WebSocket | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  const fetchSectionData = async (section: string) => {
    try {
      const response = await fetch(`/api/admin/dashboard/${section}`, {
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
      if (response.status === 403) return null;
      return await response.json();
    } catch (e) {
      return null;
    }
  };

  const loadAllData = async () => {
    const [overview, performance, queue, errors, database, redis, analytics, health, logs] = await Promise.all([
      fetchSectionData('overview'),
      fetchSectionData('performance'),
      fetchSectionData('queue'),
      fetchSectionData('errors'),
      fetchSectionData('database'),
      fetchSectionData('redis'),
      fetchSectionData('analytics'),
      fetchSectionData('health'),
      fetchSectionData('logs')
    ]);
    setDashboardData({ overview, performance, queue, errors, database, redis, analytics, health, logs });
  };

  const fetchApiKeys = async () => {
    try {
      const res = await fetch('/api/admin/system/api-keys', {
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
      if (res.ok) setApiKeys(await res.json());
    } catch(e) {}
  };

  useEffect(() => {
    if (activeTab === 'api-keys') {
        fetchApiKeys();
    }
  }, [activeTab]);

  useEffect(() => {
    let active = true;
    let reconnectTimeout: any;

    const connectWebSocket = () => {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws?token=${accessToken}`;
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        if (!active) return;
        setWsLiveConnected(true);
        ws.send(JSON.stringify({ event: 'admin:subscribe', payload: {} }));
      };

      ws.onmessage = (event) => {
        if (!active) return;
        try {
          const frame = JSON.parse(event.data);
          if (frame.event === 'admin:telemetry') {
            const telemetry = frame.payload;
            setDashboardData((prev: any) => {
              if (!prev) return prev;
              return {
                ...prev,
                overview: { ...prev.overview, ...telemetry }
              };
            });
            setLoading(false);
          }
        } catch (e) {}
      };

      ws.onclose = () => {
        if (!active) return;
        setWsLiveConnected(false);
        reconnectTimeout = setTimeout(connectWebSocket, 5000);
      };
      ws.onerror = () => ws.close();
    };

    connectWebSocket();
    loadAllData().then(() => { if (active) setLoading(false); });
    const poll = setInterval(loadAllData, 8000);

    return () => {
      active = false;
      clearInterval(poll);
      clearTimeout(reconnectTimeout);
      if (wsRef.current) wsRef.current.close();
    };
  }, [accessToken]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    showToast('تم النسخ', 'success');
  };

  if (loading || !dashboardData) {
    return (
      <div className="py-24 flex flex-col items-center justify-center gap-4 text-white">
        <Loader2 className="w-8 h-8 animate-spin text-white/50" />
        <span className="text-sm font-medium text-zinc-400">جاري تحميل بيانات النظام...</span>
      </div>
    );
  }

  const { overview, performance, queue, errors, database, redis, analytics, health } = dashboardData;

  const Card = ({ title, value, subtitle, icon: Icon, alert }: any) => (
    <div className={`bg-white/[0.02] backdrop-blur-2xl border ${alert ? 'border-red-500/50 bg-red-500/5' : 'border-white/[0.05]'} rounded-xl p-5 flex flex-col justify-between`}>
      <div className="flex justify-between items-start mb-4">
        <span className="text-xs font-semibold text-zinc-400">{title}</span>
        {Icon && <Icon className="w-4 h-4 text-zinc-400" />}
      </div>
      <div>
        <h3 className="text-2xl font-mono text-zinc-100">{value}</h3>
        {subtitle && <p className="text-xs text-zinc-500 mt-1">{subtitle}</p>}
      </div>
    </div>
  );

  return (
    <div className="space-y-6 text-zinc-100 font-sans" style={{ direction: 'ltr' }}>
      
      {toast && (
        <div className="fixed bottom-6 right-6 p-4 rounded-lg border border-white/[0.05] shadow-lg z-50 flex items-center gap-3 bg-zinc-800">
          {toast.type === 'success' ? <CheckCircle2 className="w-4 h-4 text-white" /> : <AlertTriangle className="w-4 h-4 text-red-400" />}
          <span className="text-sm font-medium">{toast.message}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white/[0.02] backdrop-blur-2xl border border-white/[0.05] rounded-xl p-5">
        <div>
          <h1 className="text-lg font-bold text-white">لوحة عمليات النظام (Production)</h1>
          <p className="text-xs text-zinc-400 mt-1">تتبع الأداء لحظياً ببيانات حقيقية</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-white/[0.02] px-3 py-1.5 rounded-md border border-white/5">
            <span className={`w-2 h-2 rounded-full ${wsLiveConnected ? 'bg-white' : 'bg-red-500'}`} />
            <span className="text-xs font-medium text-zinc-300">{wsLiveConnected ? 'Live' : 'Polling'}</span>
          </div>
          <button onClick={loadAllData} className="p-2 bg-white/5 hover:bg-white/10 rounded-md transition-colors border border-white/5">
            <RefreshCw className="w-4 h-4 text-zinc-300" />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-white/[0.02] backdrop-blur-2xl border border-white/[0.05] rounded-lg overflow-x-auto">
        {[
          { id: 'overview', label: 'نظرة عامة', icon: Activity },
          { id: 'performance', label: 'الأداء الفني', icon: BarChart3 },
          { id: 'infrastructure', label: 'البنية التحتية', icon: Server },
          { id: 'logs', label: 'السجلات والأعطال', icon: AlertCircle },
          { id: 'api-keys', label: 'إدارة الـ API', icon: KeyRound }
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id as any)}
            className={`flex items-center whitespace-nowrap gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors border ${activeTab === t.id ? 'bg-white/10 text-white border-white/[0.05]' : 'bg-transparent text-zinc-400 border-transparent hover:bg-white/5'}`}
          >
            <t.icon className="w-4 h-4" />
            {t.label}
          </button>
        ))}
      </div>

      {/* OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-6 animate-fade-in">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card title="المستخدمون النشطون" value={overview?.onlineUsers || 0} subtitle="عدد مقابس الويب النشطة" icon={Users} />
            <Card title="القنوات النشطة" value={overview?.activeConnections || 0} subtitle="عبر Redis" icon={Laptop} />
            <Card title="رسائل/دقيقة" value={overview?.messagesPerMinute || 0} subtitle="معدل التدفق اللحظي" icon={Activity} />
            <Card title="طابور المزامنة" value={overview?.writeQueueSize || 0} subtitle="العمليات الخلفية المعلقة" icon={List} />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="col-span-1 md:col-span-2 bg-white/[0.02] backdrop-blur-2xl border border-white/[0.05] rounded-xl p-5">
               <h3 className="text-sm font-semibold text-zinc-300 mb-4 flex items-center gap-2"><Clock className="w-4 h-4"/> إحصائيات الاستخدام التاريخية</h3>
               <div className="grid grid-cols-3 gap-4">
                 <div className="bg-white/[0.02] p-4 rounded-lg border border-white/5">
                   <span className="text-xs text-zinc-500">آخر ساعة</span>
                   <div className="mt-2 text-xl font-mono">{database?.historyStats?.lastHour || 0} رسالة</div>
                 </div>
                 <div className="bg-white/[0.02] p-4 rounded-lg border border-white/5">
                   <span className="text-xs text-zinc-500">آخر 24 ساعة</span>
                   <div className="mt-2 text-xl font-mono">{database?.historyStats?.last24Hours || 0} رسالة</div>
                 </div>
                 <div className="bg-white/[0.02] p-4 rounded-lg border border-white/5">
                   <span className="text-xs text-zinc-500">آخر 7 أيام</span>
                   <div className="mt-2 text-xl font-mono">{database?.historyStats?.last7Days || 0} رسالة</div>
                 </div>
               </div>
            </div>

            <div className="bg-white/[0.02] backdrop-blur-2xl border border-white/[0.05] rounded-xl p-5 space-y-4">
              <h3 className="text-sm font-semibold text-zinc-300 flex items-center gap-2"><Database className="w-4 h-4"/> حالة الأنظمة</h3>
              <ul>
                <li className="flex justify-between items-center py-2 border-b border-white/5 text-sm">
                  <span className="text-zinc-400">Redis Cache</span>
                  <span className={`px-2 py-1 rounded text-xs grid place-items-center ${redis?.status === 'connected' ? 'bg-zinc-800 text-zinc-300' : 'bg-red-500/20 text-red-400'}`}>{redis?.status || 'unknown'}</span>
                </li>
                <li className="flex justify-between items-center py-2 border-b border-white/5 text-sm">
                  <span className="text-zinc-400">PostgreSQL</span>
                  <span className={`px-2 py-1 rounded text-xs grid place-items-center ${health?.database === 'GREEN' ? 'bg-zinc-800 text-zinc-300' : 'bg-red-500/20 text-red-400'}`}>{health?.database || 'unknown'}</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* PERFORMANCE */}
      {activeTab === 'performance' && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-white/[0.02] backdrop-blur-2xl border border-white/[0.05] rounded-xl p-5">
            <h3 className="text-sm font-semibold text-zinc-300 mb-6 flex items-center gap-2"><BarChart3 className="w-4 h-4"/> تحليل زمن المعالجة (Latency)</h3>
            <div className="space-y-5">
              {[
                { label: 'وقت الاستقبال بالخادم (Queue)', val: performance?.avgQueueTime || 0 },
                { label: 'سرعة حفظ قاعدة البيانات (DB Write)', val: performance?.avgDbWriteTime || 0 },
                { label: 'البث اللاحق للأعضاء (Redis Pub)', val: performance?.avgRedisPubTime || 0 },
                { label: 'تأكيد التسليم (End-to-End)', val: performance?.avgDeliveryTime || 0 }
              ].map(v => (
                <div key={v.label} className="space-y-2">
                  <div className="flex justify-between text-xs text-zinc-400">
                    <span>{v.label}</span>
                    <span className="font-mono">{v.val.toFixed(1)} ms</span>
                  </div>
                  <div className="w-full bg-white/[0.02] h-1.5 rounded-full overflow-hidden border border-white/5">
                    <div className="bg-zinc-300 h-full" style={{ width: `${Math.min(100, (v.val / 100)*100)}%` }} />
                  </div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-3 gap-4 mt-8">
              <div className="text-center p-3 bg-white/[0.02] rounded-lg border border-white/5">
                <span className="block text-[10px] text-zinc-500 uppercase">P50</span>
                <span className="font-mono text-zinc-200">{performance?.percentiles?.p50 || 0}ms</span>
              </div>
              <div className="text-center p-3 bg-white/[0.02] rounded-lg border border-white/5">
                <span className="block text-[10px] text-zinc-500 uppercase">P95</span>
                <span className="font-mono text-zinc-200">{performance?.percentiles?.p95 || 0}ms</span>
              </div>
              <div className="text-center p-3 bg-white/[0.02] rounded-lg border border-white/5">
                <span className="block text-[10px] text-zinc-500 uppercase">P99</span>
                <span className="font-mono text-zinc-200">{performance?.percentiles?.p99 || 0}ms</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* INFRASTRUCTURE */}
      {activeTab === 'infrastructure' && (
        <div className="space-y-6 animate-fade-in">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card title="استهلاك المعالج (CPU)" value={`${overview?.cpuUsagePercentage || 0}%`} icon={Server} />
            <Card title="الذاكرة العشوائية (RAM)" value={`${Math.round((overview?.memoryUsageBytes || 0)/1024/1024)} MB`} subtitle={`متبقي ${Math.round((overview?.memoryFreeBytes||0)/1024/1024/1024)}GB`} icon={HardDrive} />
            <Card title="مدة التشغيل" value={overview?.uptime || '0ث'} icon={Clock} />
            <Card title="حجم قاعدة البيانات" value={database?.dbSize || '0'} icon={Database} />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white/[0.02] backdrop-blur-2xl border border-white/[0.05] rounded-xl p-5 space-y-4">
              <h3 className="text-sm font-semibold text-zinc-300 border-b border-white/5 pb-3">أكبر الجداول في Database</h3>
              <div className="space-y-2">
                {database?.topTables?.map((t:any) => (
                  <div key={t.table_name} className="flex justify-between items-center text-sm p-3 bg-white/[0.02] rounded-lg border border-white/5">
                    <span className="text-zinc-400 font-mono">{t.table_name}</span>
                    <span className="text-zinc-200 font-mono text-xs">{t.size}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white/[0.02] backdrop-blur-2xl border border-white/[0.05] rounded-xl p-5 space-y-4">
              <h3 className="text-sm font-semibold text-zinc-300 border-b border-white/5 pb-3">إحصائيات التخزين السحابي (Storage)</h3>
              <div className="grid grid-cols-2 gap-4 mb-4 text-center">
                <div className="p-3 bg-white/[0.02] rounded-lg border border-white/5">
                   <span className="block text-[10px] text-zinc-500">المساحة الإجمالية</span>
                   <span className="text-lg font-mono text-zinc-200">{(analytics?.storageAnalytics?.totalStorageBytes/1024/1024).toFixed(2)} MB</span>
                </div>
                <div className="p-3 bg-white/[0.02] rounded-lg border border-white/5">
                   <span className="block text-[10px] text-zinc-500">الملفات المرفوعة</span>
                   <span className="text-lg font-mono text-zinc-200">{analytics?.fileCount || 0} مقطع وصورة</span>
                </div>
              </div>
              <p className="text-xs text-zinc-500">أكثر المستخدمين استهلاكاً</p>
              {analytics?.storageAnalytics?.topStorageUsers?.slice(0,3).map((u:any) => (
                <div key={u.id} className="flex justify-between items-center text-sm p-2 bg-white/[0.02] rounded-lg border border-white/5">
                   <span className="text-zinc-400 truncate w-32">{u.username}</span>
                   <span className="text-zinc-200 font-mono text-xs">{(u.total_size/1024/1024).toFixed(1)} MB</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white/[0.02] backdrop-blur-2xl border border-white/[0.05] rounded-xl p-5">
             <h3 className="text-sm font-semibold text-zinc-300 mb-4 border-b border-white/5 pb-3">سجل الاستعلامات والأوامر البطيئة (Slow Queries)</h3>
             {database?.slowQueries?.length > 0 ? (
               <div className="space-y-3">
                 {database.slowQueries.map((q:any, i:number) => (
                   <div key={i} className="p-4 bg-white/[0.02] rounded-lg border border-white/5 flex flex-col gap-2">
                     <div className="flex justify-between items-start">
                       <span className="text-xs text-red-400 font-mono font-medium">{q.durationMs.toFixed(1)}ms استجابة</span>
                       <span className="text-[10px] text-zinc-500 font-mono">{new Date(q.timestamp).toLocaleTimeString()}</span>
                     </div>
                     <span className="text-sm text-zinc-300 font-mono">{q.sql}</span>
                   </div>
                 ))}
               </div>
             ) : (
               <div className="p-6 text-center text-zinc-500 text-sm bg-white/[0.02] rounded-lg border border-white/5">
                 لا توجد استعلامات بطيئة مسجلة. 
               </div>
             )}
          </div>
        </div>
      )}

      {/* LOGS & ERRORS */}
      {activeTab === 'logs' && (
        <div className="space-y-6 animate-fade-in">
          
          {/* Alerts Banner */}
          {health?.database === 'RED' || redis?.status === 'disconnected' || queue?.size > 1000 ? (
             <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/20 text-red-500 text-sm font-medium flex items-center gap-3">
               <AlertTriangle className="w-5 h-5" />
               عطل حرج بالنظام (Critical): يتطلب تدخل إداري لفحص الخوادم، تأكد من حالة قواعد البيانات والموزع.
             </div>
          ) : (
             <div className="p-3 rounded-lg bg-green-500/5 border border-green-500/10 text-zinc-400 text-sm font-medium flex items-center gap-3">
               <CheckCircle2 className="w-5 h-5 text-green-500/50" />
               لا توجد تنبيهات نشطة، النظام يعمل باستقرار تام.
             </div>
          )}

          <div className="bg-white/[0.02] backdrop-blur-2xl border border-white/[0.05] rounded-xl p-5">
             <div className="flex justify-between items-center mb-6">
                <h3 className="text-sm font-semibold text-zinc-300 flex items-center gap-2"><ShieldAlert className="w-4 h-4"/> الأخطاء والاستثناءات الكلية المرصودة ({errors?.errors?.length || 0})</h3>
             </div>
             {errors?.errors?.length > 0 ? (
               <div className="space-y-4">
                 {errors.errors.map((e:any, idx:number) => (
                   <div key={idx} className="p-4 bg-white/[0.02] rounded-lg border border-red-500/20 flex justify-between items-start gap-4">
                     <div className="space-y-2 flex-1">
                       <div className="flex items-center gap-2">
                         <span className="px-2 py-0.5 bg-red-500/10 text-red-400 text-[10px] font-mono rounded">
                           {e.source || 'SYSTEM'}
                         </span>
                         <span className="text-xs text-zinc-500 font-mono">{new Date(e.timestamp).toLocaleString()}</span>
                       </div>
                       <p className="text-sm font-medium text-zinc-200">{e.message}</p>
                       {e.stack && (
                         <div className="p-3 bg-white/[0.02] backdrop-blur-2xl rounded border border-white/5 mt-2 overflow-x-auto text-left" style={{ direction: 'ltr' }}>
                           <pre className="text-[10px] font-mono text-zinc-500">{e.stack.substring(0, 300)}...</pre>
                         </div>
                       )}
                     </div>
                     <button onClick={() => copyToClipboard(e.stack || e.message)} className="p-2 bg-white/5 hover:bg-white/10 rounded shrink-0 transition-colors border border-white/5 text-zinc-400">
                       <Copy className="w-4 h-4" />
                     </button>
                   </div>
                 ))}
               </div>
             ) : (
               <div className="p-8 text-center text-zinc-500 text-sm bg-white/[0.02] rounded-lg border border-white/5">
                 سجل الأخطاء فارغ. 
               </div>
             )}
          </div>
        </div>
      )}

      {/* API KEYS MANAGEMENT */}
      {activeTab === 'api-keys' && (
        <div className="space-y-6 animate-fade-in" style={{ direction: 'rtl' }}>
          
          <div className="bg-white/[0.02] backdrop-blur-2xl border border-white/[0.05] rounded-xl p-5">
            <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
              <KeyRound className="w-5 h-5 text-indigo-400" />
              مفاتيح API الاحتياطية (Gemini AI)
            </h3>
            <p className="text-sm text-zinc-400 mb-6">
              أضف مفاتيح Gemini API لتعمل كنظام احتياطي (Fallback). في حال نفاد الحصة أو تعطل المفتاح الأساسي، سينتقل النظام تلقائيًا للمفاتيح أدناه والمتاحة، وسيستخدم طراز Gemini 3.1 Flash Lite افتراضياً.
            </p>

            <div className="flex gap-2 mb-8">
              <input 
                type="text" 
                value={newKeyInput}
                onChange={e => setNewKeyInput(e.target.value)}
                placeholder="أدخل مفتاح Gemini API جديد (يبدأ بـ AIzaSy...)" 
                className="flex-1 bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-white font-mono text-sm outline-none focus:border-indigo-500/50 transition-colors"
                dir="ltr"
              />
              <button 
                onClick={async () => {
                  if (!newKeyInput) return;
                  try {
                    const res = await fetch('/api/admin/system/api-keys', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${accessToken}` },
                      body: JSON.stringify({ key_value: newKeyInput })
                    });
                    if (res.ok) {
                      showToast('تمت إضافة المفتاح بنجاح', 'success');
                      setNewKeyInput('');
                      fetchApiKeys();
                    } else {
                      const data = await res.json();
                      showToast(data.error || 'حدث خطأ', 'error');
                    }
                  } catch (e) {
                    showToast('خطأ في الاتصال', 'error');
                  }
                }}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
              >
                <Plus className="w-4 h-4" /> اضافة
              </button>
            </div>

            <div className="space-y-3">
              {apiKeys.length === 0 ? (
                 <div className="text-center p-8 bg-white/5 rounded-xl border border-white/5 text-zinc-500 text-sm">
                   جاري تحميل المفاتيح أو لا يوجد مفاتيح مسجلة...
                 </div>
              ) : apiKeys.map((k: any) => {
                const limit = 1500; // Gemini Flash Free Limit
                const usageRatio = Math.min((k.daily_usage_count || 0) / limit, 1);
                const perc = (usageRatio * 100).toFixed(1);
                return (
                 <div key={k.id} className="bg-white/5 border border-white/10 rounded-xl p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 relative overflow-hidden group">
                  
                  {/* Subtle background highlight if active */}
                  {k.is_current_active && (
                    <div className="absolute inset-0 bg-indigo-500/5 pointer-events-none" />
                  )}

                  <div className="flex-1 space-y-3 w-full relative z-10">
                    <div className="flex items-center gap-2">
                       <Key className={`w-4 h-4 ${k.is_current_active ? 'text-indigo-400' : 'text-zinc-400'}`} />
                       <span className={`font-mono text-sm bg-black/20 px-2 py-0.5 rounded ${k.is_current_active ? 'text-indigo-200' : 'text-zinc-200'}`}>{k.key_value}</span>
                       {!k.is_active && <span className="bg-red-500/20 text-red-400 text-[10px] px-2 py-0.5 rounded uppercase tracking-wider">متوقف</span>}
                       {k.is_current_active && <span className="bg-indigo-500/20 text-indigo-300 text-[10px] px-2 py-0.5 rounded uppercase tracking-wider flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse" /> قيد الاستخدام</span>}
                       {k.id === 'primary-env-key' && <span className="bg-emerald-500/20 text-emerald-300 text-[10px] px-2 py-0.5 rounded uppercase tracking-wider">المفتاح الأساسي (ENV)</span>}
                    </div>
                    
                    <div className="flex gap-4 text-xs font-mono text-zinc-500 flex-wrap">
                      <span>الخدمة: <span className="text-zinc-300">{k.service_name}</span></span>
                      <span className="text-indigo-400 font-bold bg-indigo-500/10 px-2 rounded">النموذج: gemini-2.5-flash</span>
                      <span>إجمالي الطلبات: <span className="text-zinc-300">{k.usage_count} مرة</span></span>
                      <span>إجمالي التوكنز الحقيقي المستهلك: <span className="text-emerald-400 font-bold">{parseInt(k.total_tokens || 0).toLocaleString()} توكن</span></span>
                      {k.id !== 'primary-env-key' && <span>تاريخ الإضافة: {new Date(k.created_at).toLocaleDateString()}</span>}
                    </div>

                    {/* Real Usage Progress Bar */}
                    <div className="space-y-1.5 w-full md:w-3/4">
                       <div className="flex justify-between text-[11px] font-mono">
                         <span className="text-zinc-400">الاستهلاك اليومي التقريبي (حد 1500 طلب)</span>
                         <span className={usageRatio > 0.8 ? 'text-red-400 font-bold' : usageRatio > 0.5 ? 'text-amber-400' : 'text-zinc-300'}>{k.daily_usage_count || 0} / {limit} طلب ({perc}%)</span>
                       </div>
                       <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden flex">
                         <div 
                           className={`h-full rounded-full transition-all duration-1000 ${usageRatio > 0.8 ? 'bg-red-500' : usageRatio > 0.5 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                           style={{ width: `${usageRatio * 100}%` }}
                         />
                       </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 shrink-0 relative z-10">
                        <button 
                          onClick={async () => {
                            try {
                               const res = await fetch(`/api/admin/system/api-keys/${k.id}/toggle`, {
                                 method: 'POST',
                                 headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${accessToken}` },
                                 body: JSON.stringify({ is_active: !k.is_active })
                               });
                               if (res.ok) { fetchApiKeys(); }
                            } catch (e) {}
                          }}
                          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${k.is_active ? 'bg-amber-500/20 text-amber-500 hover:bg-amber-500/30' : 'bg-green-500/20 text-green-500 hover:bg-green-500/30'}`}
                        >
                          {k.is_active ? 'إيقاف مؤقت' : 'تفعيل'}
                        </button>
                        
                        {k.id !== 'primary-env-key' && (
                          <button 
                            onClick={async () => {
                              if (!confirm('هل تأكد من حذف المفتاح الاحتياطي نهائياً؟')) return;
                              try {
                                const res = await fetch(`/api/admin/system/api-keys/${k.id}`, {
                                  method: 'DELETE',
                                  headers: { 'Authorization': `Bearer ${accessToken}` }
                                });
                                if(res.ok) fetchApiKeys();
                              } catch (e) {}
                            }}
                            className="p-1.5 bg-red-500/10 text-red-500 hover:bg-red-500/20 rounded-md transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                  </div>
                </div>
              )})}
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
