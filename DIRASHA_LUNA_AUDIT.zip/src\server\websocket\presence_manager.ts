/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { db } from '../database.ts';
import { redisCluster } from './redis_client.ts';
import type { PresenceStatus } from '../../types.ts';

export class PresenceManager {
  private static SESSION_KEY_PREFIX = 'presence:session:user:';
  private static CONSOLIDATED_KEY_PREFIX = 'presence:user:';
  private static SESSION_TTL_SECONDS = 60; // 60-second sliding expirations for socket sessions
  private static COOLDOWN_MS = 20000; // 20-seconds Adaptive Grace Cooldown to absorb network flickers (15-30s required)
  private static graceTimers = new Map<string, NodeJS.Timeout>();

  /**
   * Registers a brand new active session or tab connection. 
   * Updates state database to online and broadcasts changes if transitioning from offline.
   */
  public static async registerUserOnline(userId: string, connId: string): Promise<void> {
    const sessionKey = `${this.SESSION_KEY_PREFIX}${userId}:${connId}`;
    // console.log(`[PresenceManager] Registering active socket session: ${sessionKey}`);

    // Cancel and dismiss any pending offline grace transition timer for this user
    if (this.graceTimers.has(userId)) {
      // console.log(`[PresenceManager] Dismissing offline grace timer for User ${userId} (reconnected via session ${connId})`);
      clearTimeout(this.graceTimers.get(userId)!);
      this.graceTimers.delete(userId);
    }

    // Register/renew session key with a 65-second safety TTL
    await redisCluster.setTemp(sessionKey, 'alive', this.SESSION_TTL_SECONDS);

    // Set consolidated state tracker in Redis
    const consolidatedKey = `${this.CONSOLIDATED_KEY_PREFIX}${userId}`;
    await redisCluster.setTemp(consolidatedKey, 'online', this.SESSION_TTL_SECONDS);

    // Update database the status if they are currently marked offline
    const previous = await db.getUserById(userId);
    if (!previous || previous.onlineStatus === 'offline') {
      await db.updateUser(userId, { onlineStatus: 'online', lastSeen: new Date().toISOString() });
      await this.broadcastPresence(userId, 'online');
      // console.log(`[PresenceManager] Presence state transition: User ${userId} is now [ONLINE]`);
    }
  }

  /**
   * Re-asserts and extends the lease of an existing active connection session.
   */
  public static async refreshConnection(userId: string, connId: string): Promise<void> {
    const sessionKey = `${this.SESSION_KEY_PREFIX}${userId}:${connId}`;
    const consolidatedKey = `${this.CONSOLIDATED_KEY_PREFIX}${userId}`;

    await redisCluster.setTemp(sessionKey, 'alive', this.SESSION_TTL_SECONDS);
    await redisCluster.setTemp(consolidatedKey, 'online', this.SESSION_TTL_SECONDS);
  }

  /**
   * Handles a socket disconnect. 
   * Drops the associated connection session, estimates remaining active sessions across the cluster,
   * and Schedules a Graceful Offline Transition if count hits zero.
   */
  public static async registerUserOffline(
    userId: string,
    connId: string,
    onGracefulOfflineCompleted: () => void
  ): Promise<void> {
    const sessionKey = `${this.SESSION_KEY_PREFIX}${userId}:${connId}`;
    // console.log(`[PresenceManager] Unregistering session: ${sessionKey}`);

    // Immediately remove this session key from the cache
    await redisCluster.deleteTemp(sessionKey);

    // Check cluster-wide if any other tab or device session is still alive
    const remainingCount = await this.getActiveConnectionsCount(userId);
    // console.log(`[PresenceManager] User ${userId} remaining active session sessions: ${remainingCount}`);

    if (remainingCount > 0) {
      // User still has active sockets elsewhere (e.g., other tabs or devices) - keep online state
      return;
    }

    // If zero active sessions remain, initiate the graceful offline timer
    if (this.graceTimers.has(userId)) {
      clearTimeout(this.graceTimers.get(userId)!);
    }

    // console.log(`[PresenceManager] User ${userId} has 0 active connected sessions. Scheduling [OFFLINE] transition in ${(this.COOLDOWN_MS / 1000).toFixed(1)}s`);

    const timer = setTimeout(async () => {
      this.graceTimers.delete(userId);

      // Verify again that no new sessions were instantiated during the grace window
      const doubleCheckCount = await this.getActiveConnectionsCount(userId);
      if (doubleCheckCount === 0) {
        await db.updateUser(userId, { onlineStatus: 'offline', lastSeen: new Date().toISOString() });
        
        const consolidatedKey = `${this.CONSOLIDATED_KEY_PREFIX}${userId}`;
        await redisCluster.deleteTemp(consolidatedKey);

        await this.broadcastPresence(userId, 'offline');
        // console.log(`[PresenceManager] Grace timer completed. User ${userId} is officially [OFFLINE].`);
        onGracefulOfflineCompleted();
      } else {
        // console.log(`[PresenceManager] Grace timer canceled for user ${userId}. Found ${doubleCheckCount} active connection keys.`);
      }
    }, this.COOLDOWN_MS);

    this.graceTimers.set(userId, timer);
  }

  /**
   * Executes manual, administrative, or user-initiated presence state overrides (e.g., going "away").
   */
  public static async updateUserStatus(userId: string, status: PresenceStatus): Promise<void> {
    if (this.graceTimers.has(userId)) {
      clearTimeout(this.graceTimers.get(userId)!);
      this.graceTimers.delete(userId);
    }

    await db.updateUser(userId, { onlineStatus: status, lastSeen: new Date().toISOString() });

    const consolidatedKey = `${this.CONSOLIDATED_KEY_PREFIX}${userId}`;
    if (status === 'offline') {
      await redisCluster.deleteTemp(consolidatedKey);
    } else {
      await redisCluster.setTemp(consolidatedKey, status, this.SESSION_TTL_SECONDS);
    }

    await this.broadcastPresence(userId, status);
  }

  /**
   * Discovers and counts actual Cluster-wide Connection sessions registered in Redis for a specific User ID.
   */
  public static async getActiveConnectionsCount(userId: string): Promise<number> {
    const pattern = `${this.SESSION_KEY_PREFIX}${userId}:*`;
    const keys = await redisCluster.getKeys(pattern);
    return keys.length;
  }

  /**
   * Broadcasts a validated presence status payload to the global messaging layer.
   * BATCH-1 (DIR-2026-010p / AB-09): lastSeen is NEVER included in the global
   * broadcast — lastSeenVisibility ('nobody'/'contacts') is a per-viewer policy
   * the global channel cannot honor. Interested clients resolve lastSeen via
   * the authenticated REST surfaces (applyPrivacyForViewer).
   */
  private static async broadcastPresence(userId: string, status: PresenceStatus): Promise<void> {
    await redisCluster.publish('presence:broadcast', {
      event: 'presence:update',
      payload: {
        userId,
        status,
      },
    });
  }
}
