/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import 'dotenv/config';
import express, { Request, Response, NextFunction } from 'express';
import compression from 'compression';
import http from 'http';
import path from 'path';
import cookieParser from 'cookie-parser';
import { createServer as createViteServer } from 'vite';
import { db, pool, normalizePollPayload } from './src/server/database.ts';
import { assertCanSendMessage, assertMembershipFresh, MembershipStaleError, SendBlockedError } from './src/server/guards/sendGate.ts';
import { decidePushEndpointAllowed } from './src/server/guards/pushEndpoint.ts';
import { clientIp } from './src/server/lib/trustedClientIp.ts';
import { assertEncryptedIngress, E2eeRequiredError, E2eePolicyUnavailableError } from './src/server/guards/encryptionPolicy.ts';
import { getFallbackS3Config } from './src/server/services/storage.ts';
import { AuthService, TokenPayload, isTokenRevocationCheckable } from './src/server/services/auth.ts';
import { verifySecret } from './src/server/services/password.ts';
import { WebSocketChatServer, issueWsTicket } from './src/server/websocket/ws_server.ts';
import { BackgroundWriteQueue } from './src/server/websocket/write_queue.ts';
import { redisCluster } from './src/server/websocket/redis_client.ts';
import { WebPushService } from './src/server/services/push.ts';
import { DashboardStatsCollector } from './src/server/services/dashboard_stats.ts';
import { startModerationJobs } from './src/server/services/moderation_jobs.ts';
import { statusRouter } from './src/server/routes/status.ts';
import { apiKeysRouter } from './src/server/routes/apiKeys.ts';
import type { User, Chat } from './src/types.ts';
import crypto from 'crypto';
import { evaluateDisplayNameQuality, validateUsername, sanitizeDisplayName, normalizeUsername } from './src/lib/identityUtils.ts';
import fs from 'fs';
import { registerClassicAuthRoutes } from './src/server/routes/authClassic.ts';
import { registerPasskeyRoutes } from './src/server/routes/passkeys.ts';
import { registerStorageRoutes } from './src/server/routes/storage.ts';
import { registerE2eeRoutes } from './src/server/routes/e2ee.ts';
import { deleteDriveFileByOwner, extractGdriveFileIds } from './src/server/services/gdrive.ts';
import { registerKtRoutes } from './src/server/routes/kt.ts';
import { DistributedRateLimiter, RateLimitRuleName } from './src/server/services/rate_limiter.ts';
import { registerGroupCallRoutes } from './src/server/routes/groupCallRoutes.ts';
import { logStorageBoot } from './src/server/services/storage.ts';

// Extend Express Request typing globally
declare global {
  namespace Express {
    interface Request {
      user?: TokenPayload;
    }
  }
}

// Legacy Google OAuth + phone-OTP were permanently removed (username/password + PIN era).
// See src/server/routes/authClassic.ts for the current authentication flow.

// ── P0-hardening: module-level in-memory token-bucket rate limiter ────────────
// Per-key fixed-window counter (separate from the Project 5 distributed
// limiter in services/rate_limiter.ts — see that file for the Redis-backed,
// fail-closed core that now backs auth/e2ee/storage limits). Keys are
// namespaced by the caller, e.g. `report:<userId>`.
const restLimitBuckets = new Map<string, { count: number; resetAt: number }>();
function restLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const bucket = restLimitBuckets.get(key);
  if (!bucket || bucket.resetAt < now) {
    restLimitBuckets.set(key, { count: 1, resetAt: now + windowMs });
    return false; // within limit
  }
  bucket.count++;
  return bucket.count > max; // true = rate limited
}
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of restLimitBuckets) if (v.resetAt < now) restLimitBuckets.delete(k);
}, 60_000).unref();

// ── Scheduled messages: scheduleAt validation (REST contract) ─────────────────
// Clients send `scheduleAt` (ISO 8601 string) as a top-level field on message
// send bodies. Must be 1 minute..1 year in the future; otherwise the send is
// rejected with an Arabic 400. Absent/empty scheduleAt = immediate send.
function parseScheduleAt(raw: unknown): { date: Date | null; error?: string } {
  if (raw === undefined || raw === null || raw === '') return { date: null };
  if (typeof raw !== 'string') {
    return { date: null, error: 'موعد الإرسال غير صالح (مطلوب نص بتوقيت ISO 8601).' };
  }
  const trimmed = raw.trim();
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(trimmed)) {
    return { date: null, error: 'موعد الإرسال غير صالح (مطلوب تاريخ ISO 8601).' };
  }
  const d = new Date(trimmed);
  if (isNaN(d.getTime())) {
    return { date: null, error: 'موعد الإرسال غير صالح (مطلوب تاريخ ISO 8601).' };
  }
  const now = Date.now();
  if (d.getTime() < now + 60_000) {
    return { date: null, error: 'موعد الإرسال يجب أن يكون بعد 60 ثانية على الأقل من الآن.' };
  }
  if (d.getTime() > now + 365 * 24 * 60 * 60 * 1000) {
    return { date: null, error: 'موعد الإرسال يجب أن يكون خلال سنة واحدة على الأكثر.' };
  }
  return { date: d };
}

// ── P0-hardening: attachment URL allowlist (anti-SSRF / anti-tracking) ────────
// Message attachments may ONLY point at:
//   1. this server's own origin (same-host media served by us),
//   2. the managed fallback bucket base (S3_PUBLIC_BASE_URL, when configured),
//   3. the sender's own linked storage account publicBaseUrl,
//   4. Google Drive streaming hosts (drive.usercontent.google.com /
//      drive.google.com) — only when the SENDER's linked storage is Google
//      Drive (drive.file scope, uploaded via our ticket flow).
// Everything else — including `data:` URIs and arbitrary https hosts — is
// rejected so senders cannot weaponize recipients' clients into fetching
// attacker-controlled hosts (tracking pixels, SSRF relay, exploit URLs).
function collectAttachmentUrls(body: any): string[] {
  const urls: string[] = [];
  const push = (u: unknown) => { if (typeof u === 'string' && u.length > 0) urls.push(u); };
  if (Array.isArray(body?.attachments)) {
    for (const a of body.attachments) push(a?.url);
  }
  // Defensive: cover stray media-shaped fields some clients still send.
  for (const field of ['mediaUrl', 'imageUrl', 'videoUrl', 'audioUrl', 'fileUrl', 'thumbnailUrl']) {
    push(body?.[field]);
  }
  return urls;
}

function isAllowedAttachmentUrl(rawUrl: string, req: Request, linkedPublicBase: string | null, linkedProvider: string | null): boolean {
  let parsed: URL;
  try {
    parsed = new URL(rawUrl);
  } catch {
    return false; // data:, blob:, relative garbage, anything unparseable
  }
  if (parsed.protocol !== 'https:') return false;
  const targetHost = parsed.host.toLowerCase();
  // 0. Trusted map provider for location cards (OSM share-link, no credentials).
  if (targetHost === 'www.openstreetmap.org' && parsed.pathname === '/') return true;
  // 0b. Google Drive streaming hosts — ONLY for senders whose linked storage
  //     is their own Google Drive (drive.file scope). Recipients may render
  //     these attachment URLs from anyone; the gate here is on the SENDER
  //     having legitimately uploaded to Drive via our ticket flow.
  if ((targetHost === 'drive.usercontent.google.com' || targetHost === 'drive.google.com')
    && linkedProvider === 'gdrive') {
    return true;
  }
  // 1. Same-origin: compare against the request's own host (proxy-aware).
  const fwdHost = req.headers['x-forwarded-host'];
  const originHost = String(
    (typeof fwdHost === 'string' ? fwdHost.split(',')[0]?.trim() : undefined)
    || req.headers.host || '',
  ).toLowerCase();
  if (originHost && targetHost === originHost) return true;
  // 2. Managed fallback bucket base (env-configured constant).
  try {
    const fallback = getFallbackS3Config();
    if (fallback?.publicBaseUrl) {
      const managed = new URL(fallback.publicBaseUrl);
      if (managed.protocol === 'https:' && managed.host.toLowerCase() === targetHost) return true;
    }
  } catch { /* unconfigured fallback — skip */ }
  // 3. Sender's linked storage account public base URL.
  if (linkedPublicBase) {
    try {
      const linked = new URL(linkedPublicBase);
      if (linked.protocol === 'https:' && linked.host.toLowerCase() === targetHost) return true;
    } catch { /* malformed linked base — skip */ }
  }
  return false;
}

/** Fetch the caller's linked storage base + provider (db: getUserStorage). */
async function getLinkedStorageBase(userId: string): Promise<{ publicBaseUrl: string | null; provider: string | null }> {
  try {
    const linked = await db.getUserStorage(userId);
    if (!linked?.isActive) return { publicBaseUrl: null, provider: null };
    return {
      publicBaseUrl: typeof linked.publicBaseUrl === 'string' && linked.publicBaseUrl
        ? linked.publicBaseUrl.replace(/\/+$/, '')
        : null,
      provider: typeof linked.provider === 'string' ? linked.provider : null,
    };
  } catch {
    return { publicBaseUrl: null, provider: null };
  }
}

async function assertAttachmentUrlsAllowed(
  req: Request,
  body: any,
  senderId: string,
): Promise<void> {
  const urls = collectAttachmentUrls(body);
  if (urls.length === 0) return;
  const linked = await getLinkedStorageBase(senderId);
  for (const u of urls) {
    if (!isAllowedAttachmentUrl(u, req, linked.publicBaseUrl, linked.provider)) {
      throw new Error('ATTACHMENT_URL_BLOCKED');
    }
  }
}

// ── Phase-1 hardening: fail-fast production configuration checks ─────────────
// Before binding the port, verify every production secret exists and is not a
// known default/dev value. Secret VALUES are NEVER printed — only names.
// Critical checks (JWT/AUTH_PEPPER/COOKIE_SECRET/STORAGE_MASTER_KEY/DATABASE_URL
// /VAPID) abort the boot with process.exit(1). KT_SIGNING_KEY is warn-only:
// Key Transparency degrades to UNVERIFIED witness mode by design.
const DEV_DEFAULT_SECRET_VALUES: Record<string, string[]> = {
  JWT_SECRET: ['dirasha-development-secured-jwt-key-2026-core'],
  AUTH_PEPPER: ['dirasha-dev-only-pepper'],
  COOKIE_SECRET: ['dirasha-development-secured-cookie-secret-2026'],
  STORAGE_MASTER_KEY: ['dirasha-dev-only-storage-key'],
};
const GENERIC_WEAK_SECRET_VALUES = new Set([
  'changeme', 'change-me', 'secret', 'password', 'test', 'dev', 'development',
  'default', 'admin', 'example', 'sample', 'placeholder',
]);

function verifyProductionConfig(): void {
  if (process.env.NODE_ENV !== 'production') {
    console.log('[Boot Config] NODE_ENV != production — fail-fast secret checks skipped (development mode).');
    return;
  }

  const failures: string[] = [];
  const passed: string[] = [];

  const criticalSecrets: Array<{ name: string; value: string | undefined }> = [
    { name: 'JWT_SECRET', value: process.env.JWT_SECRET },
    { name: 'AUTH_PEPPER', value: process.env.AUTH_PEPPER },
    { name: 'COOKIE_SECRET', value: process.env.COOKIE_SECRET },
    { name: 'STORAGE_MASTER_KEY', value: process.env.STORAGE_MASTER_KEY },
  ];
  for (const { name, value } of criticalSecrets) {
    const devDefaults = DEV_DEFAULT_SECRET_VALUES[name] || [];
    if (!value || value.trim().length === 0) {
      failures.push(`${name}: MISSING`);
    } else if (devDefaults.includes(value) || GENERIC_WEAK_SECRET_VALUES.has(value.trim().toLowerCase())) {
      failures.push(`${name}: default/dev/weak value (set a real 32+ char random secret)`);
    } else if (value.length < 32) {
      failures.push(`${name}: too weak (< 32 chars)`);
    } else {
      passed.push(name);
    }
  }

  // DATABASE_URL: required in production — the in-memory store is a dev fallback,
  // never a production datastore (sessions/messages would vanish on restart).
  const databaseUrl = (process.env.DATABASE_URL || '').trim().replace(/^["']|["']$/g, '');
  if (!databaseUrl) {
    failures.push('DATABASE_URL: MISSING');
  } else if (!/^postgres(ql)?:\/\//i.test(databaseUrl)) {
    failures.push('DATABASE_URL: not a postgres:// connection string');
  } else {
    passed.push('DATABASE_URL');
  }

  // VAPID keys: required since push is live — an ephemeral keypair would
  // silently invalidate EVERY existing push subscription on the next restart.
  if (!process.env.VAPID_PUBLIC_KEY || !process.env.VAPID_PRIVATE_KEY) {
    failures.push('VAPID_PUBLIC_KEY/VAPID_PRIVATE_KEY: MISSING (push is live; ephemeral keys invalidate all subscriptions on restart)');
  } else {
    passed.push('VAPID_PUBLIC_KEY + VAPID_PRIVATE_KEY');
  }

  // P1-D (external-audit E2EE-08): KT_SIGNING_KEY is REQUIRED in production —
  // unverified witness mode is a documented availability fallback, not an
  // acceptable production posture (the client trust gate depends on witness
  // signatures). Non-production keeps the warn-only behavior.
  if (!process.env.KT_SIGNING_KEY) {
    if (process.env.NODE_ENV === 'production') {
      failures.push('KT_SIGNING_KEY: MISSING (production requires witness-signed transparency — clients gate on it)');
    } else {
      console.error('[Boot Config] WARNING: KT_SIGNING_KEY not set — Key Transparency runs in UNVERIFIED witness mode (dev only). Set a 32-byte base64 Ed25519 seed to enable verified witness signatures.');
    }
  } else {
    passed.push('KT_SIGNING_KEY');
  }

  if (failures.length > 0) {
    console.error('================================================================');
    console.error('[Boot Config] FATAL: production configuration check FAILED — refusing to start.');
    for (const f of failures) console.error(`  [BOOT CONFIG FAIL] ${f}`);
    console.error('[Boot Config] Set the missing/weak secrets via the environment (values are never logged). Exiting.');
    console.error('================================================================');
    process.exit(1);
  }

  // Startup log listing WHICH checks passed — names only, never values.
  console.log(`[Boot Config] Production configuration checks PASSED for: ${passed.join(', ')}.`);
}

async function startServer() {
  // Phase-1: fail fast on missing/default production secrets before anything
  // else consumes them.
  verifyProductionConfig();

  const app = express();
  const server = http.createServer(app);
  const PORT = parseInt(process.env.PORT || '3000', 10);

  // ── Project 5: Distributed rate limiting ──────────────────────────────────
  // Replaces the old per-process fixed-window Map with a Redis-backed atomic
  // counter service (single EVAL per check: INCR + PEXPIRE-on-first + compare),
  // shared across server instances and surviving restarts (TTL expires keys).
  // All limits are table-driven via RATE_LIMIT_RULES (services/rate_limiter.ts):
  //   - 'critical' rules (auth + e2ee crypto surfaces) FAIL CLOSED on Redis
  //     outages (deny + loud error log) — an outage must never silently
  //     disable credential/crypto protection.
  //   - 'throughput' rules degrade to the per-process local Map with loud
  //     logging (documented choice: keep message/storage throughput alive).
  // The local Map inside DistributedRateLimiter is ONLY a last-resort outage
  // fallback, never a silent downgrade.
  const distributedRateLimiter = new DistributedRateLimiter(redisCluster);
  const checkLimit = (rule: RateLimitRuleName, key: string): Promise<boolean> =>
    distributedRateLimiter.check(rule, key);

  // Initialize Admin Dashboard and Analytics tracking
  DashboardStatsCollector.initialize();


  // Express Config Middlewares
  app.use(compression());
  app.use(express.json({ limit: '5mb' }));
  app.use(express.urlencoded({ limit: '5mb', extended: true }));
  // Cookie signing secret must come from the environment in production.
  // The hardcoded fallback exists only so local development boots without a .env file.
  const COOKIE_SECRET = process.env.COOKIE_SECRET
    || (process.env.NODE_ENV === 'production' ? '' : 'dirasha-development-secured-cookie-secret-2026');
  if (!COOKIE_SECRET) {
    throw new Error('FATAL: COOKIE_SECRET environment variable is required in production.');
  }
  app.use(cookieParser(COOKIE_SECRET));

  // CORS or Security framing
  // P0-hardening: strict security headers + origin allowlist.
  // - ALLOWED_ORIGINS env (comma list) is authoritative in production.
  // - Without it, only local-dev browser origins pass (localhost/127.0.0.1).
  const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || '')
    .split(',').map(o => o.trim().replace(/\/$/, '')).filter(Boolean);
  const isLocalDevOrigin = (origin: string): boolean => {
    try { const u = new URL(origin); return ['localhost', '127.0.0.1', '[::1]'].includes(u.hostname); }
    catch { return false; }
  };
  const isOriginAllowed = (origin: string): boolean => {
    if (ALLOWED_ORIGINS.length > 0) return ALLOWED_ORIGINS.includes(origin.replace(/\/$/, ''));
    return isLocalDevOrigin(origin);
  };

  app.use((req, res, next) => {
    // --- Content Security Policy (strict: no unsafe-inline scripts — shield.js is external) ---
    const frameAncestors = process.env.ALLOWED_FRAME_ANCESTORS || "'self'";
    const csp = [
      "default-src 'self'",
      // Dev mode: Vite injects an inline module preamble (react-refresh) that a
      // strict policy blocks → white screen. Allow 'unsafe-inline' for scripts in
      // DEV ONLY; the production build has no inline scripts → strict 'self'.
      `script-src 'self'${process.env.NODE_ENV === 'production' ? '' : " 'unsafe-inline'"}`,
      "style-src 'self' 'unsafe-inline' https://fonts.cdnfonts.com", // Tailwind + SF Pro Display CDN
      "img-src 'self' data: blob: https:",         // avatars (dicebear) + BYO-Cloud media
      "media-src 'self' blob: https:",             // attachments stream from user buckets
      "connect-src 'self' ws: wss: https: blob:",  // API + WS + presigned PUT uploads
      "font-src 'self' data: https://fonts.cdnfonts.com", // SF Pro Display webfonts (SFPRODISPLAY)
      "worker-src 'self' blob:",
      "object-src 'none'",
      "base-uri 'self'",
      "form-action 'self'",
      `frame-ancestors ${frameAncestors}`,
    ].join('; ');
    res.setHeader('Content-Security-Policy', csp);
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Permissions-Policy', 'camera=(self), microphone=(self), geolocation=(), payment=()');
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    // XFO kept for legacy agents; modern browsers honor CSP frame-ancestors above.
    res.setHeader('X-Frame-Options', frameAncestors === "'self'" ? 'SAMEORIGIN' : 'ALLOWALL');

    // --- CORS: allowlist-based (never a blind wildcard) ---
    const reqOrigin = req.headers.origin;
    if (reqOrigin && isOriginAllowed(reqOrigin)) {
      res.setHeader('Access-Control-Allow-Origin', reqOrigin);
      res.setHeader('Vary', 'Origin');
      res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization, X-Admin-Secret');
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    }

    // --- CSRF defense-in-depth: Origin/Referer verification (OWASP CSRF CS —
    // "Using Standard Headers to Verify Origin"). Browsers cannot forge these
    // headers; non-browser clients without Origin pass (Bearer-auth APIs).
    // Literal "null" origin is never allowed (sandboxed/cross-origin redirects).
    if (req.path.startsWith('/api/') && !['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
      const checkOrigin = (raw: string | undefined): string | null => {
        if (!raw) return null;
        try { return new URL(raw).origin; } catch { return 'null'; }
      };
      const presented = checkOrigin(reqOrigin)
        || checkOrigin(req.headers.referer as string | undefined);
      if (presented === 'null') {
        return res.status(403).json({ error: 'Origin not allowed.' });
      }
      if (presented && !isOriginAllowed(presented)) {
        return res.status(403).json({ error: 'Origin not allowed.' });
      }
    }

    // Completely disable downstream browser caching for ALL API paths. We rely fully on IndexedDB client-side.
    if (req.path.startsWith('/api/')) {
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
      res.setHeader('Surrogate-Control', 'no-store');
    }

    if (req.method === 'OPTIONS') {
      res.sendStatus(200);
    } else {
      next();
    }
  });

  // Authentication check middleware
  async function requireAuth(req: Request, res: Response, next: NextFunction) {
    let token = '';
    let tokenFromUrl = false;
    const authHeader = req.headers.authorization;

    if (authHeader && authHeader.startsWith('Bearer ')) {
      token = authHeader.split(' ')[1];
    } else if (req.query.access_token) {
      // Support for HTML native elements (<audio>, <video>) that cannot send Auth headers.
      // P1-hardening: only short-lived media tokens are accepted via URL, and only for GET.
      token = req.query.access_token as string;
      tokenFromUrl = true;
    }

    if (!token) {
      return res.status(401).json({ error: 'Unauthorized: Access Token missing.' });
    }

    const decoded = AuthService.verifyAccessToken(token);

    if (!decoded) {
      return res.status(401).json({ error: 'Unauthorized: Token signature invalid or expired.' });
    }

    // URL-borne tokens must be media-scoped and read-only.
    if (tokenFromUrl && (!AuthService.isMediaToken(decoded) || req.method !== 'GET')) {
      return res.status(401).json({ error: 'Unauthorized: URL tokens are media-scoped and GET-only.' });
    }

    // AUTH-05 (external audit): media-scoped tokens are ONLY valid via the
    // URL gate below — never as general Bearer credentials.
    if (!tokenFromUrl && AuthService.isScopedMediaToken(decoded)) {
      return res.status(401).json({ error: 'Unauthorized: Media tokens are URL-scoped only.' });
    }

    // URL-borne tokens must be strictly scoped (aud:media) and read-only.
    if (tokenFromUrl && (!AuthService.isScopedMediaToken(decoded) || req.method !== 'GET')) {
      return res.status(401).json({ error: 'Unauthorized: URL tokens are media-scoped and GET-only.' });
    }

    // BATCH-4 (DIR-CB-03): URL media tokens are MEDIA-ROUTE-scoped — valid only
    // on the media-serving GET surfaces (/api/media/* and /uploads/*). A leaked
    // link can no longer pull arbitrary GET endpoints (chat metadata, exports,
    // message history) within its TTL.
    if (tokenFromUrl) {
      const p = req.path || '';
      if (!(p.startsWith('/api/media/') || p.startsWith('/uploads/') || p === '/uploads')) {
        console.warn(`[Security Alert] URL media token rejected on non-media route: ${p}`);
        return res.status(401).json({ error: 'Unauthorized: URL tokens are valid on media routes only.' });
      }
    }

    // Ensure user is not banned
    const uDB = await db.getUserById(decoded.userId);
    if (!uDB) {
      return res.status(401).json({ error: 'Unauthorized: Account not found.' });
    }
    if (uDB.isBanned) {
      if (uDB.bannedUntil && new Date(uDB.bannedUntil) > new Date()) {
         return res.status(403).json({ error: `Account is temporarily banned until ${uDB.bannedUntil}. Reason: ${uDB.banReason || 'Policy Violation'}` });
      } else if (!uDB.bannedUntil || new Date(uDB.bannedUntil) > new Date('2099-01-01')) {
         return res.status(403).json({ error: `Account permanently banned. Reason: ${uDB.banReason || 'Policy Violation'}` });
      } else if (uDB.bannedUntil && new Date(uDB.bannedUntil) <= new Date()) {
         // Auto-lift expired ban
         await db.banUser(uDB.id, false, 'system', 'Temporary ban expired');
      }
    }

    // AUTH-03 (external audit): live revocation check for checkable tokens
    // (jti+sid present) — a revoked session dies immediately on the API too,
    // not only at refresh time. Legacy pre-deploy tokens keep the grace path.
    if (isTokenRevocationCheckable(decoded)) {
      const liveSession = await db.getSessionById((decoded as any).sid);
      if (!liveSession || (liveSession as any).isRevoked) {
        return res.status(401).json({ error: 'Unauthorized: session revoked.' });
      }
    }

    req.user = decoded;
    next();
  }

  // BATCH-1 (DIR-2026-001): admin gate is the DURABLE role only — read fresh
  // from the DB (the JWT carries no role claim), no username matching, no
  // promotion side effects.
  async function requireAdmin(req: Request, res: Response, next: NextFunction) {
    requireAuth(req, res, async () => {
      try {
        const u = await db.getUserById(req.user!.userId);
        const callerRole = u?.role || 'user';
        if (callerRole === 'admin' || callerRole === 'developer') {
          next();
        } else {
          console.warn(`[Security Alert] Unauthorized admin API attempt by user: ${req.user?.username || 'none'} (role: ${callerRole})`);
          res.status(403).json({ error: '403 Forbidden: Developer privileges required.' });
        }
      } catch (err) {
        console.error('[Security Alert] requireAdmin DB lookup failed:', err);
        res.status(503).json({ error: 'Authorization unavailable.' });
      }
    });
  }

  /**
   * Privacy enforcement helper — makes lastSeenVisibility / avatarVisibility REAL:
   * 'nobody' → always hidden; 'contacts' → hidden unless viewer is in owner's contacts.
   */
  async function applyPrivacyForViewer(u: User, viewerId: string): Promise<User> {
    if (u.id === viewerId) return u;
    const priv: any = (u as any).privacySettings || {};
    let viewerIsContact = false;
    try {
      viewerIsContact = (await db.getContacts(u.id)).includes(viewerId);
    } catch { viewerIsContact = false; }
    const out: any = { ...u };
    if (priv.lastSeenVisibility === 'nobody' || (priv.lastSeenVisibility === 'contacts' && !viewerIsContact)) {
      out.lastSeen = undefined;
    }
    if (priv.avatarVisibility === 'nobody' || (priv.avatarVisibility === 'contacts' && !viewerIsContact)) {
      out.avatarUrl = undefined;
      out.photoURL = undefined;
    }
    return out;
  }

  // Classic credentials auth (username + password + PIN recovery) + BYO-Cloud storage routes
  registerClassicAuthRoutes(app, { requireAuth, checkLimit });
  registerPasskeyRoutes(app, { requireAuth, checkLimit });
  registerStorageRoutes(app, { requireAuth, checkLimit });
  registerE2eeRoutes(app, { requireAuth, checkLimit });
  // Key Transparency (Project 2): snapshot root/proof/replay-detect endpoints
  // + 5-min snapshot signer (dirty-only, best-effort).
  registerKtRoutes(app, { requireAuth });
  registerGroupCallRoutes(app, { requireAuth });
  logStorageBoot();

  // Admin dashboard API routes
  app.get('/api/admin/dashboard/overview', requireAdmin, (req, res) => {
    res.json(DashboardStatsCollector.getOverview());
  });

  app.get('/api/admin/dashboard/performance', requireAdmin, (req, res) => {
    res.json(DashboardStatsCollector.getPerformanceStats());
  });

  app.get('/api/admin/dashboard/queue', requireAdmin, (req, res) => {
    res.json(DashboardStatsCollector.getQueueStats());
  });

  app.get('/api/admin/dashboard/errors', requireAdmin, (req, res) => {
    res.json(DashboardStatsCollector.getErrorStats());
  });

  app.get('/api/admin/dashboard/database', requireAdmin, async (req, res) => {
    try {
      const stats = await DashboardStatsCollector.getDatabaseStats();
      res.json(stats);
    } catch (e: any) {
      console.error('[Server] Unhandled route error:', e);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.get('/api/admin/dashboard/redis', requireAdmin, async (req, res) => {
    try {
      const stats = await DashboardStatsCollector.getRedisStats();
      res.json(stats);
    } catch (e: any) {
      console.error('[Server] Unhandled route error:', e);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.get('/api/admin/dashboard/analytics', requireAdmin, async (req, res) => {
    try {
      const stats = await DashboardStatsCollector.getAnalytics();
      res.json(stats);
    } catch (e: any) {
      console.error('[Server] Unhandled route error:', e);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.get('/api/admin/dashboard/health', requireAdmin, (req, res) => {
    res.json(DashboardStatsCollector.getHealthStatus());
  });

  app.get('/api/admin/dashboard/logs', requireAdmin, (req, res) => {
    res.json(DashboardStatsCollector.getActivityLogs());
  });

  app.get('/api/admin/dashboard/search', requireAdmin, async (req, res) => {
    try {
      const { q } = req.query;
      const results = await DashboardStatsCollector.queryEntitiesSearch(String(q || ''));
      res.json(results);
    } catch (e: any) {
      console.error('[Server] Unhandled route error:', e);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.post('/api/admin/dashboard/log-activity', requireAdmin, (req, res) => {
    const { action, category, details } = req.body;
    // BATCH-5 (DIR-2026-052): admin-supplied log strings are bounded and
    // control-character-stripped — no log forging / log injection.
    const clean = (v: any, max: number) => String(v ?? '').replace(/[\x00-\x1f\x7f\u2028\u2029]/g, '').slice(0, max);
    DashboardStatsCollector.logAdminActivity(clean(action, 120), clean(category, 40), clean(details, 500), req.user!.userId, req.user!.username || '');
    res.json({ success: true });
  });

  // REST API Controller routing
  app.use('/api/statuses', requireAuth, statusRouter);
  app.use('/api/admin/system/api-keys', requireAdmin, apiKeysRouter);

  // Service Worker Static Endpoint
  app.get('/service-worker.js', (req, res) => {
    res.setHeader('Content-Type', 'application/javascript');
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0');
    res.sendFile(path.join(process.cwd(), 'src/service-worker.js'));
  });

  // PWA Manifest Endpoint
  app.get('/manifest.json', (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0');
    res.sendFile(path.join(process.cwd(), 'src/manifest.json'));
  });

  // Responsible-disclosure endpoints (RFC 9116):
  // /.well-known/security.txt is the conventional scanner/researcher lookup
  // path; /security is a friendly alias to the Arabic disclosure policy page.
  app.get('/.well-known/security.txt', (req, res) => {
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0');
    res.sendFile(path.join(process.cwd(), 'public/security.txt'));
  });

  app.get('/security', (req, res) => {
    res.redirect(302, '/security.html');
  });

  // Web Push Configuration/Subscription Endpoints
  app.get('/api/push/vapid-key', (req, res) => {
    const key = WebPushService.getPublicKey();
    res.json({ publicKey: key });
  });

  app.post('/api/push/subscribe', requireAuth, async (req, res) => {
    try {
      const { subscription } = req.body;
      if (!subscription || !subscription.endpoint) {
        return res.status(400).json({ error: 'Subscription object complete with endpoint is strictly required.' });
      }
      // BATCH-6 (F-3/F-13): the allowlist moved to a pure, tested guard with
      // the REAL vendor endpoint hosts (Mozilla autopush + WNS token
      // subdomains restored — Firefox/Edge push no longer breaks).
      const pushDecision = decidePushEndpointAllowed(subscription.endpoint);
      if (!pushDecision.allowed) {
        return res.status(400).json({ error: 'Unsupported push service endpoint.' });
      }
      if (!req.user || !req.user.userId) {
        return res.status(401).json({ error: 'Unauthorized user.' });
      }
      await db.savePushSubscription(req.user.userId, subscription);
      console.log(`[Web Push API] Registered device subscription for user ${req.user.userId}`);
      res.json({ success: true });
    } catch (e: any) {
      console.error('[Web Push API] Subscription register error:', e);
      console.error('[Server] Unhandled route error:', e);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 1. Health Probe for Kubernetes
  // P0-hardening: probes the actual datastore (SELECT 1, 2s budget) and reports
  // the active backend. Never throws — 'memory' is the safe fallback answer.
  app.get('/api/health', async (req, res) => {
    let backend = 'memory';
    try {
      const probe = await Promise.race([
        pool.query('SELECT 1'),
        new Promise<null>((resolve) => setTimeout(() => resolve(null), 2000)),
      ]);
      // In-memory fallback answers SELECT 1 with an empty generic result
      // (rowCount 0); a live PostgreSQL answers with rowCount 1.
      if (probe && probe.rowCount >= 1) backend = 'postgres';
    } catch {
      backend = 'memory';
    }
    res.status(200).json({ status: 'healthy', db: backend, timestamp: new Date().toISOString() });
  });

  // 1b. Debug endpoint to retrieve queue state and simulated failure status (admin-only)
  app.get('/api/debug/queue', requireAdmin, (req, res) => {
    res.json({
      queueLength: BackgroundWriteQueue.getActiveQueue().length,
      queue: BackgroundWriteQueue.getActiveQueue(),
      dbFailureSimulation: (globalThis as any).dbFailureSimulation === true,
      timestamp: new Date().toISOString()
    });
  });

  // 1c. Debug endpoint to toggle simulated database failure (admin-only)
  app.post('/api/debug/simulate-db-failure', requireAdmin, (req, res) => {
    const { enable } = req.body;
    (globalThis as any).dbFailureSimulation = enable === true;
    console.log(`[Debug] Database failure simulation toggled: ${(globalThis as any).dbFailureSimulation}`);
    res.json({
      success: true,
      dbFailureSimulation: (globalThis as any).dbFailureSimulation
    });
  });

  // 1b. Auth: Check if username is available (With 4 professional suggestions generated if taken - Stage 2)
  app.get('/api/auth/check-username', async (req, res) => {
    try {
      // BATCH-5 (DIR-2026-027): the endpoint is unauthenticated — throttle it
      // so it can no longer serve as a free username-enumeration oracle.
      if (restLimit(`username-check:${clientIp(req)}`, 30, 10 * 60 * 1000)) {
        return res.status(429).json({ error: 'طلبات كثيرة — حاول لاحقاً.' });
      }
      const rawUsername = (req.query.username as string || '').toLowerCase().trim();
      if (!rawUsername) {
        return res.status(400).json({ error: 'Username is strictly required.' });
      }

      const val = validateUsername(rawUsername);
      if (!val.isValid) {
        return res.status(200).json({ available: false, error: val.error, suggestions: [] });
      }

      const existingUser = await db.getUserByUsername(rawUsername);
      if (existingUser) {
        return res.status(200).json({ available: false, error: 'اسم المستخدم محجوز بالفعل.', suggestions: [] });
      }
      // Anti-impersonation: old usernames stay reserved forever after a change
      if (db.isUsernameReserved(rawUsername)) {
        return res.status(200).json({ available: false, error: 'هذا الاسم محفوظ من استخدام سابق — اختر اسماً آخر.', reserved: true, suggestions: [] });
      }
      // BATCH-1 review fix: operator handles are reserved too — check-username
      // must not advertise them as available (closes the handle-enumeration
      // oracle against ADMIN_USERNAMES).
      if (db.isAdminReservedName(rawUsername)) {
        return res.status(200).json({ available: false, error: 'هذا الاسم محجوز للإدارة — اختر اسماً آخر.', reserved: true, suggestions: [] });
      }
      if (!existingUser) {
        return res.status(200).json({ available: true });
      }

      // Generate 4 professional alternates if taken
      const base = rawUsername.substring(0, 15); // cut to fit format bounds
      const templates = [
        `${base}_pro`,
        `${base}_net`,
        `${base}_app`,
        `${base}99`,
        `${base}_dev`,
        `${base}7`,
        `${base}_co`
      ];

      const suggestions: string[] = [];
      // BATCH-6 (ADV-05): the suggestion generators apply the SAME reservation
      // filters as the registration path — operator handles (ADMIN_USERNAMES)
      // and previously-released reserved names are never advertised.
      const suggestable = (c: string): boolean =>
        !db.isAdminReservedName(c) && !db.isUsernameReserved(c);
      for (const t of templates) {
        if (suggestions.length >= 4) break;
        const checkVal = t.toLowerCase();
        if (suggestable(checkVal) && validateUsername(checkVal).isValid && !(await db.getUserByUsername(checkVal))) {
          suggestions.push(checkVal);
        }
      }

      // Add simple numeric fallback suggestions if needed
      let i = 1;
      while (suggestions.length < 4 && i < 100) {
        const fall = `${base}${i}`;
        if (suggestable(fall) && validateUsername(fall).isValid && !(await db.getUserByUsername(fall)) && !suggestions.includes(fall)) {
          suggestions.push(fall);
        }
        i++;
      }

      res.status(200).json({ 
        available: false, 
        message: 'ط§ط³ظ… ط§ظ„ظ…ط³طھط®ط¯ظ… ظ‡ط°ط§ ظ…ط­ط¬ظˆط² ط¨ط§ظ„ظپط¹ظ„ ظ„ظ„ط£ط³ظپ.', 
        suggestions 
      });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 1c. Auth: Assess Display Name Quality rating (Excellent / Good / Weak - Stage 3)
  app.get('/api/auth/eval-display-name', (req, res) => {
    try {
      const name = req.query.name as string || '';
      if (!name) {
        return res.status(400).json({ error: 'Display Name is strictly required.' });
      }
      const evaluation = evaluateDisplayNameQuality(name);
      res.status(200).json(evaluation);
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });
  // 4. Auth: Session Rotate & Token Refresh
  app.post('/api/auth/refresh', async (req, res) => {
    try {
      // P0-hardening: brute-force throttle — 60 attempts / 10 min per IP+username.
      const rlIp = req.ip || (req.headers['x-forwarded-for'] as string) || '127.0.0.1';
      const rlUsername = String(req.body?.username || '').toLowerCase();
      if (restLimit(`auth:refresh:${rlIp}:${rlUsername}`, 60, 10 * 60 * 1000)) {
        return res.status(429).json({ error: 'عدد كبير من المحاولات، حاول لاحقاً.' });
      }
      const refreshToken = req.cookies.refreshToken || req.body.refreshToken;
      if (!refreshToken) {
        return res.status(401).json({ error: 'Authentication failed: Refresh Token missing.' });
      }

      const ip = req.ip || req.headers['x-forwarded-for'] as string || '127.0.0.1';
      const userAgent = req.headers['user-agent'] || 'unrecognized-device';

      const result = await AuthService.rotateRefreshToken(refreshToken, userAgent, ip);
      if (!result) {
        // Attack warning: session stolen or re-use anomaly detected. Clear client cookie
        res.clearCookie('refreshToken', { httpOnly: true, secure: true, sameSite: 'none' });
        return res.status(403).json({ error: 'Access Denied: Revocation anomaly detected. Authenticate manually.' });
      }

      // Block if user is banned
      const uDB = await db.getUserById(result.user.id);
      if (uDB && uDB.isBanned) {
        if (uDB.bannedUntil && new Date(uDB.bannedUntil) > new Date()) {
          res.clearCookie('refreshToken', { httpOnly: true, secure: true, sameSite: 'none' });
          return res.status(403).json({ 
            error: `ظ‡ط°ط§ ط§ظ„ط­ط³ط§ط¨ ظ…ط­ط¸ظˆط± ظ…ط¤ظ‚طھط§ظ‹ ط­طھظ‰ ${new Date(uDB.bannedUntil).toLocaleString('ar-EG')}. ط§ظ„ط³ط¨ط¨: ${uDB.banReason || 'ط§ظ†طھظ‡ط§ظƒ ط³ظٹط§ط³ط© ط§ظ„ط®ط¯ظ…ط©'}` 
          });
        } else if (!uDB.bannedUntil || new Date(uDB.bannedUntil) > new Date('2099-01-01')) {
          res.clearCookie('refreshToken', { httpOnly: true, secure: true, sameSite: 'none' });
          return res.status(403).json({ 
            error: `ظ‡ط°ط§ ط§ظ„ط­ط³ط§ط¨ ظ…ط­ط¸ظˆط± ظ†ظ‡ط§ط¦ظٹط§ظ‹. ط§ظ„ط³ط¨ط¨: ${uDB.banReason || 'ط§ظ†طھظ‡ط§ظƒ ط³ظٹط§ط³ط© ط§ظ„ط®ط¯ظ…ط©'}` 
          });
        } else if (uDB.bannedUntil && new Date(uDB.bannedUntil) <= new Date()) {
          // Auto-lift expired ban
          await db.banUser(uDB.id, false, 'system', 'Temporary ban expired');
        }
      }

      // Bind rotated cookie credentials with SameSite=None for iframe support
      res.cookie('refreshToken', result.refreshToken, {
        httpOnly: true,
        secure: true,
        sameSite: 'none',
        maxAge: 7 * 24 * 60 * 60 * 1000
      });

      // F6 hardening: the rotated refresh token is delivered ONLY via the
      // HttpOnly cookie above — never mirrored in the JSON body.
      res.status(200).json({
        user: result.user,
        accessToken: result.accessToken,
        sessionId: result.sessionId
      });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 5. Auth: Logout
  app.post('/api/auth/logout', async (req, res) => {
    try {
      const { refreshToken } = req.cookies;
      if (refreshToken) {
        await AuthService.logout(refreshToken);
      }
      res.clearCookie('refreshToken', { httpOnly: true, secure: true, sameSite: 'none' });
      // OWASP Session CS: client-side cleanup on logout
      res.setHeader('Clear-Site-Data', '"cache", "storage"');
      res.status(200).json({ success: true, message: 'Logged out successfully.' });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 6. Auth: Fetch current active state
  app.get('/api/auth/me', requireAuth, async (req, res) => {
    const user = await db.getUserById(req.user!.userId);
    if (!user) {
      return res.status(404).json({ error: 'Connected identity not found.' });
    }
    res.status(200).json({ user });
  });

  // 6a. P1-hardening: short-lived media token for native elements (<audio>/<video>/<img>)
  // that cannot send Authorization headers. GET-scoped, 120s lifetime — replaces passing
  // long-lived access tokens in URLs (which leak into server/proxy logs).
  // WS-01 (external audit): short-lived single-use WebSocket tickets — the
  // access JWT no longer needs to ride the upgrade query string. 60s TTL,
  // origin-bound, one-time consumption (ws_server.ts owns the store).
  app.get('/api/ws-ticket', requireAuth, (req: Request, res: Response) => {
    const { ticket, exp } = issueWsTicket(req.user!.userId, req.headers.origin || null);
    return res.json({ ticket, exp });
  });

  app.get('/api/media-token', requireAuth, (req, res) => {
    try {
      // DIR-NEW-10 (external audit): optional per-file binding. With ?fileId=
      // the token is pinned to THAT single Drive file (resourceType 'media');
      // the media handlers reject a resource-bound token presented for any
      // other file. Without ?fileId= the response shape is exactly as before.
      const fileIdQ = req.query.fileId;
      const fileId = typeof fileIdQ === 'string' ? fileIdQ : '';
      if (fileId && !/^[A-Za-z0-9_-]{10,}$/.test(fileId)) {
        return res.status(400).json({ error: 'معرّف ملف غير صالح.' });
      }
      const mediaToken = AuthService.generateMediaToken(
        req.user!,
        fileId ? { resourceType: 'media', resourceId: fileId } : undefined,
      );
      res.status(200).json({
        mediaToken,
        expiresInSec: 120,
        usage: 'Append as ?access_token=<mediaToken> to GET media URLs',
        ...(fileId ? { resourceId: fileId } : {}),
      });
    } catch (err: any) {
      console.error('[Auth] media token issuance failed:', err?.message);
      res.status(500).json({ error: 'تعذر إصدار توكن الوسائط. حاول مرة أخرى.' });
    }
  });

  // 6a-2. Profile: Query current user details via GET (Resolves Issue #2)
  app.get('/api/users/me', requireAuth, async (req, res) => {
    try {
      const userId = req.user!.userId;
      const user = await db.getUserById(userId);
      if (!user) {
        return res.status(404).json({ error: 'User identity not found.' });
      }

      // Fetch user settings and block list from Postgres
      const settings = await db.getUserSettings(userId);
      const blockedUsers = await db.getBlockedUsers(userId);
      const unseenWarnings = await db.getUnseenWarnings(userId);

      if (unseenWarnings.length > 0) {
        await db.markWarningsSeen(userId);
      }

      const enrichedUser = {
        ...user,
        unseenWarnings,
        privacySettings: settings?.privacySettings || {
          lastSeenVisibility: settings?.privacy?.lastSeen || 'everyone',
          avatarVisibility: settings?.privacy?.avatar || 'everyone',
          statusVisibility: settings?.privacy?.status || 'everyone',
          allowDirectMessages: settings?.privacy?.allowDirectMessages || 'everyone',
          allowGroupInvites: settings?.privacy?.allowGroupInvites || 'everyone',
          readReceiptsEnabled: settings?.privacy?.readReceiptsEnabled !== false,
          typingIndicatorEnabled: settings?.privacy?.typingIndicatorEnabled !== false,
          screenLockEnabled: settings?.privacy?.screenLockEnabled || false,
          screenLockPasscode: settings?.privacy?.screenLockPasscode || ''
        },
        notificationSettings: settings?.notificationSettings || {
          enabled: settings?.notifications?.enabled !== false,
          privateMessages: settings?.notifications?.privateMessages !== false,
          groups: settings?.notifications?.groups !== false,
          showPreviews: settings?.notifications?.showPreviews !== false,
          reactionAlerts: settings?.notifications?.reactionAlerts !== false,
          sound: settings?.notifications?.Sound !== false,
          vibrate: settings?.notifications?.vibrate !== false
        },
        appearanceSettings: settings?.appearanceSettings || {
          theme: settings?.theme || 'dark',
          fontSize: settings?.fontSize || 'normal',
          chatWallpaper: settings?.chatWallpaper || '',
          sidebarWidth: settings?.sidebarWidth || 350
        },
        chatSettings: settings?.chatSettings || {
          enterToSend: settings?.chat?.enterToSend || false,
          mediaAutoDownload: settings?.chat?.mediaAutoDownload || 'wifi',
          archiveChats: settings?.chat?.archiveChats || false
        },
        blockedUsers: blockedUsers || []
      };

      res.status(200).json({ user: enrichedUser });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 6b. Profile: Update current user settings and metadata (With strict audit logging and quality evaluation)
  app.put('/api/users/me', requireAuth, async (req, res) => {
    try {
      const userId = req.user!.userId;
      // P0-hardening: profile-update spam throttle — 10/hour per user.
      if (restLimit(`users:me:${userId}`, 10, 60 * 60 * 1000)) {
        return res.status(429).json({ error: 'عدد كبير من المحاولات، حاول لاحقاً.' });
      }
      const user = await db.getUserById(userId);
      if (!user) {
        return res.status(404).json({ error: 'User identity not found.' });
      }

      const updates: any = { ...req.body };

      // Mass-assignment guard: profiles may never self-assign privileged or moderation fields.
      // These are writable only by the moderation/admin endpoints (requireModerator) and system flows.
      for (const forbiddenKey of ['role', 'verified', 'isBanned', 'bannedAt', 'bannedUntil', 'bannedBy', 'banReason',
        'mutedUntil', 'mutedAt', 'mutedBy', 'muteReason', 'mutedFromAiUntil', 'phoneNumber', 'profileCompleted', 'id']) {
        if (updates[forbiddenKey] !== undefined) {
          console.warn(`[Security Alert] Privileged field '${forbiddenKey}' stripped from profile update by user ${userId}`);
          delete updates[forbiddenKey];
        }
      }

      const isMuted = user.mutedUntil && new Date(user.mutedUntil) > new Date();
      // If muted, only allow settings updates (like notifications/privacy) but not profile identity
      if (isMuted) {
        if (updates.username || updates.displayName || updates.bio !== undefined || updates.avatarUrl !== undefined || updates.bannerUrl !== undefined) {
           return res.status(403).json({ error: 'Your account is restricted from updating profile details.' });
        }
      }

      // Update blocks table if blockedUsers list is supplied
      if (updates.blockedUsers !== undefined) {
        const currentBlocked = await db.getBlockedUsers(userId);
        const nextBlocked = updates.blockedUsers || [];
        
        // Find newly blocked
        for (const bid of nextBlocked) {
          if (!currentBlocked.includes(bid)) {
            await db.blockUser(userId, bid);
          }
        }
        // Find newly unblocked
        for (const bid of currentBlocked) {
          if (!nextBlocked.includes(bid)) {
            await db.unblockUser(userId, bid);
          }
        }
      }

      // Sync settings to user_settings table
      const settingsPayload: any = {};
      if (updates.privacySettings) {
        settingsPayload.privacySettings = updates.privacySettings;
        settingsPayload.privacy = {
          lastSeen: updates.privacySettings.lastSeenVisibility,
          avatar: updates.privacySettings.avatarVisibility,
          status: updates.privacySettings.statusVisibility,
          allowDirectMessages: updates.privacySettings.allowDirectMessages,
          allowGroupInvites: updates.privacySettings.allowGroupInvites,
          readReceiptsEnabled: updates.privacySettings.readReceiptsEnabled,
          typingIndicatorEnabled: updates.privacySettings.typingIndicatorEnabled,
          screenLockEnabled: updates.privacySettings.screenLockEnabled,
          screenLockPasscode: updates.privacySettings.screenLockPasscode
        };
      }
      if (updates.notificationSettings) {
        settingsPayload.notificationSettings = updates.notificationSettings;
        settingsPayload.notifications = {
          enabled: updates.notificationSettings.enabled,
          privateMessages: updates.notificationSettings.privateMessages,
          Sound: updates.notificationSettings.sound
        };
      }
      if (updates.appearanceSettings) {
        settingsPayload.appearanceSettings = updates.appearanceSettings;
        settingsPayload.theme = updates.appearanceSettings.theme;
        settingsPayload.fontSize = updates.appearanceSettings.fontSize;
      }
      if (updates.chatSettings) {
        settingsPayload.chatSettings = updates.chatSettings;
      }

      if (Object.keys(settingsPayload).length > 0) {
        await db.updateUserSettings(userId, settingsPayload);
      }

      // 1. Username change validation & audit trails (Stage 2)
      if (updates.username && updates.username !== user.username) {
        const valUsername = (u: string) => u.toLowerCase().trim();
        const cleanUsername = valUsername(updates.username);

        const validation = validateUsername(cleanUsername);
        if (!validation.isValid) {
          return res.status(400).json({ error: validation.error });
        }

        const collision = await db.getUserByUsername(cleanUsername);
        if (collision && collision.id !== userId) {
          return res.status(409).json({ error: 'اسم المستخدم محجوز ومستخدم بواسطة مستخدم آخر.' });
        }

        // BATCH-6 (ADV-01): the dedicated rename route's reservation guards
        // apply here too — operator handles and previously-released names are
        // reserved on EVERY username-change surface, and the old name is
        // reserved (via db.setUsername) exactly like the dedicated route.
        if (db.isAdminReservedName(cleanUsername)) {
          return res.status(409).json({ error: 'USERNAME_RESERVED', message: `اسم المستخدم "@${cleanUsername}" محجوز للإدارة.` });
        }
        if (db.isUsernameReserved(cleanUsername)) {
          return res.status(409).json({ error: 'USERNAME_RESERVED', message: `اسم المستخدم "@${cleanUsername}" محفوظ من استخدام سابق.` });
        }

        // Log to history and profile changes tables
        await db.logUsernameChange(userId, user.username, cleanUsername);
        await db.logProfileChange(userId, 'username', user.username, cleanUsername);
        updates.username = cleanUsername;
        // BATCH-6 (ADV-01): route through setUsername so the OLD name joins the
        // permanent reservation set (previously released for third parties).
        updates.__useSetUsername = true;
      }

      // 2. Display Name change validation & audit (Stage 3)
      if (updates.displayName && updates.displayName !== user.displayName) {
        const cleanDisplayName = sanitizeDisplayName(updates.displayName);
        const evaluation = evaluateDisplayNameQuality(cleanDisplayName);
        if (!evaluation.isValid) {
          return res.status(400).json({ error: evaluation.reason });
        }
        await db.logProfileChange(userId, 'displayName', user.displayName, cleanDisplayName);
        updates.displayName = cleanDisplayName;
      }

      // 3. Bio, Avatar and Banner updates audit tracker (Stage 1 & 5)
      if (updates.bio !== undefined && updates.bio !== user.bio) {
        await db.logProfileChange(userId, 'bio', user.bio || '', updates.bio || '');
      }
      if (updates.avatarUrl !== undefined && updates.avatarUrl !== user.avatarUrl) {
        await db.logProfileChange(userId, 'avatarUrl', user.avatarUrl || '', updates.avatarUrl || '');
        updates.photoURL = updates.avatarUrl; // Keep legacy fields synced
      }
      if (updates.bannerUrl !== undefined && updates.bannerUrl !== user.bannerUrl) {
        await db.logProfileChange(userId, 'bannerUrl', user.bannerUrl || '', updates.bannerUrl || '');
      }

      // 4. Update core user fields
      // BATCH-6 (ADV-01): username changes go through setUsername (reserves the
      // old name permanently) BEFORE the generic updateUser — and the username
      // key is removed from the generic payload so updateUser never renames.
      let updatedUser: any;
      if ((updates as any).__useSetUsername && updates.username) {
        await db.setUsername(userId, updates.username);
        delete (updates as any).__useSetUsername;
        const { username: _renamed, ...rest } = updates;
        void _renamed;
        updatedUser = await db.updateUser(userId, rest as any);
      } else {
        const { username: _ignored, ...restNoUsername } = updates as any;
        void _ignored;
        updatedUser = await db.updateUser(userId, restNoUsername as any);
      }
      if (!updatedUser) {
        return res.status(500).json({ error: 'Failed to update user profile records.' });
      }

      // Fetch freshly combined fully active user info
      const finalSettings = await db.getUserSettings(userId);
      const finalBlocked = await db.getBlockedUsers(userId);

      const enrichedUser = {
        ...updatedUser,
        privacySettings: finalSettings?.privacySettings || {
          lastSeenVisibility: finalSettings?.privacy?.lastSeen || 'everyone',
          avatarVisibility: finalSettings?.privacy?.avatar || 'everyone',
          statusVisibility: finalSettings?.privacy?.status || 'everyone',
          allowDirectMessages: finalSettings?.privacy?.allowDirectMessages || 'everyone',
          allowGroupInvites: finalSettings?.privacy?.allowGroupInvites || 'everyone',
          readReceiptsEnabled: finalSettings?.privacy?.readReceiptsEnabled !== false,
          typingIndicatorEnabled: finalSettings?.privacy?.typingIndicatorEnabled !== false,
          screenLockEnabled: finalSettings?.privacy?.screenLockEnabled || false,
          screenLockPasscode: finalSettings?.privacy?.screenLockPasscode || ''
        },
        notificationSettings: finalSettings?.notificationSettings || {
          enabled: finalSettings?.notifications?.enabled !== false,
          privateMessages: finalSettings?.notifications?.privateMessages !== false,
          groups: finalSettings?.notifications?.groups !== false,
          showPreviews: finalSettings?.notifications?.showPreviews !== false,
          reactionAlerts: finalSettings?.notifications?.reactionAlerts !== false,
          sound: finalSettings?.notifications?.Sound !== false,
          vibrate: finalSettings?.notifications?.vibrate !== false
        },
        appearanceSettings: finalSettings?.appearanceSettings || {
          theme: finalSettings?.theme || 'dark',
          fontSize: finalSettings?.fontSize || 'normal',
          chatWallpaper: finalSettings?.chatWallpaper || '',
          sidebarWidth: finalSettings?.sidebarWidth || 350
        },
        chatSettings: finalSettings?.chatSettings || {
          enterToSend: finalSettings?.chat?.enterToSend || false,
          mediaAutoDownload: finalSettings?.chat?.mediaAutoDownload || 'wifi',
          archiveChats: finalSettings?.chat?.archiveChats || false
        },
        blockedUsers: finalBlocked || []
      };

      // Publish to user private channel to sync across all of their active devices/tabs
      await redisCluster.publish(`user:updates:${userId}`, {
        event: 'user:profile_update',
        payload: { user: enrichedUser }
      });

      // Publish to global presence channel so other contacts update displays
      await redisCluster.publish('presence:broadcast', {
        event: 'user:presence_profile_update',
        // BATCH-1 (DIR-2026-010p): GLOBAL broadcast carries the public-surface
        // projection ONLY — never settings, passcode, ban/mute metadata,
        // lastSeen or session data. Full profile remains on the private
        // per-user channel (user:updates:<uid>) and the authenticated REST.
        payload: {
          userId,
          user: {
            id: enrichedUser.id,
            username: enrichedUser.username,
            displayName: enrichedUser.displayName,
            avatarUrl: enrichedUser.avatarUrl,
            verified: enrichedUser.verified,
          },
        },
      });

      res.status(200).json({ user: enrichedUser });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 6c. Sessions: Retrieve active user sessions
  app.get('/api/auth/sessions', requireAuth, async (req, res) => {
    try {
      const userId = req.user!.userId;
      // Rate limit: 30 list requests per user per minute (ActiveSessionsPanel
      // auto-refreshes every 30s; per-user not per-IP so shared NATs are fine).
      if (await checkLimit('auth:sessions:list', userId)) {
        return res.status(429).json({ error: 'طلبات كثيرة على قائمة الجلسات. حاول بعد قليل.' });
      }
      const sessions = await db.getUserSessions(userId);
      // Current-session identification: the client echoes its own sessionId
      // via the x-session-id header (same contract as revoke-others below).
      const currentSessionId = String(req.headers['x-session-id'] || '');
      // Defensive passthrough: map to known-safe fields only. Tolerates schema
      // drift (e.g. ip/last_active columns added by a parallel migration) and
      // guarantees secrets (refresh token, session IDs' tokens) never leave
      // the server. Missing fields serialize as undefined → omitted from JSON.
      const safeSessions = (Array.isArray(sessions) ? sessions : []).map((raw: any) => {
        const s = (raw && typeof raw === 'object') ? raw : {};
        const pick = (...keys: string[]): any => {
          for (const k of keys) {
            if (s[k] !== undefined && s[k] !== null) return s[k];
          }
          return undefined;
        };
        const id = pick('id');
        const userAgent = pick('userAgent', 'user_agent', 'deviceName', 'device_name');
        return {
          id,
          userAgent,
          ipAddress: pick('ipAddress', 'ip_address', 'ip'),
          lastActive: pick('lastActive', 'last_active', 'updatedAt', 'updated_at'),
          createdAt: pick('createdAt', 'created_at'),
          expiresAt: pick('expiresAt', 'expires_at'),
          isRevoked: pick('isRevoked', 'is_revoked') === true,
          // Devices & Active Sessions additions (ActiveSessionsPanel):
          sessionId: String(id || '').slice(0, 8),                 // short public id
          deviceLabel: AuthService.describeDevice(userAgent),      // Arabic label — full UA never leaves the server
          ip: pick('ipAddress', 'ip_address', 'ip'),               // spec alias of ipAddress
          current: Boolean(currentSessionId) && id === currentSessionId,
        };
      });
      res.status(200).json({ sessions: safeSessions });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 6c-2. Sessions: Check explicit current session revocation status (Prevents false security logout flags)
  app.get('/api/auth/sessions/check', requireAuth, async (req, res) => {
    // BATCH-6 (NEW-A-06): ownership gate — a session's revocation state is
    // visible only to its owner (was an unauthenticated-probing oracle).
    try {
      const sessionId = req.query.sessionId as string;
      if (!sessionId) {
        return res.status(400).json({ error: 'sessionId parameter is required.' });
      }
      const session = await db.getSessionById(sessionId);
      // BATCH-6 (NEW-A-06): only the session's OWNER may query its state.
      if (!session || session.userId !== req.user!.userId) {
        return res.status(404).json({ revoked: false }); // identical shape: no existence oracle
      }
      return res.status(200).json({ revoked: session.isRevoked });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 6d. Sessions: Revoke/delete a specific session
  app.delete('/api/auth/sessions/:sessionId', requireAuth, async (req, res) => {
    try {
      const { sessionId } = req.params;
      const userId = req.user!.userId;
      const session = await db.getSessionById(sessionId);
      
      if (session && session.userId === userId) {
        await db.revokeSession(sessionId);

        // Notify active socket connections of session revocation
        await redisCluster.publish(`user:updates:${userId}`, {
          event: 'session:revoked',
          payload: { sessionId }
        });

        res.status(200).json({ success: true, message: 'Session successfully revoked.' });
      } else {
        res.status(404).json({ error: 'Session not found or forbidden.' });
      }
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.post('/api/auth/sessions/revoke-others', requireAuth, async (req, res) => {
    try {
      const userId = req.user!.userId;
      // Rate limit: 5 bulk revocations per user per hour (destructive action).
      if (await checkLimit('auth:sessions:revoke-others', userId)) {
        return res.status(429).json({ error: 'عدد كبير من عمليات الإبطال الجماعي. حاول بعد ساعة.' });
      }
      const currentSessionId = req.headers['x-session-id'] as string;

      if (!currentSessionId) {
        return res.status(400).json({ error: 'معرّف جلستك الحالية (x-session-id) مطلوب حتى نبقي جهازك مسجّلاً.' });
      }

      await AuthService.revokeOtherSessions(userId, currentSessionId);

      // Live propagation: every OTHER connected device receives
      // `session:revoke_others` and App.tsx logs it out when its sessionId
      // differs from currentSessionId. Offline devices fail their next
      // refresh (rows revoked) and fall back to the logout-on-401 path.
      await redisCluster.publish(`user:updates:${userId}`, {
        event: 'session:revoke_others',
        payload: { currentSessionId }
      });

      await db.logAuthAction(userId, 'sessions_revoke_others', { ip: (req.headers['x-forwarded-for'] as string || req.ip || '').split(',')[0].trim() });

      res.status(200).json({ success: true, ok: true, message: 'تم إبطال جميع الجلسات الأخرى.' });
    } catch (err: any) {
      res.status(500).json({ error: 'حدث خطأ أثناء إبطال الجلسات الأخرى. حاول مرة أخرى.' });
    }
  });

  app.delete('/api/users/me', requireAuth, async (req, res) => {
    try {
      const userId = req.user!.userId;
      // BATCH-6 (NEW-A-05): irreversible destruction requires step-up — password
      // re-verification, a rate limiter, and an audit record BEFORE the wipe.
      const { password: deletePassword } = (req.body || {}) as { password?: string };
      const secrets = await db.getUserSecrets(userId);
      if (!secrets?.passwordHash) {
        return res.status(403).json({ error: 'Account deletion requires a password-protected account (re-register a password to enable deletion).' });
      }
      if (await checkLimit('auth:pin:change', `${userId}:account-delete:${clientIp(req)}`)) {
        return res.status(429).json({ error: 'محاولات كثيرة — حاول بعد 10 دقائق.' });
      }
      const okDelete = await verifySecret(String(deletePassword || ''), secrets.passwordHash);
      if (!okDelete) {
        await db.logAuthAction(userId, 'account_delete_failed', { ip: clientIp(req) });
        return res.status(403).json({ error: 'كلمة المرور غير صحيحة — الحذف مرفوض.' });
      }
      await db.logAuthAction(userId, 'account_deleted', { ip: clientIp(req) });
      await db.deleteUser(userId);
      
      // Notify user's socket to force disconnect
      await redisCluster.publish(`user:updates:${userId}`, {
        event: 'account:deleted',
        payload: { userId }
      });

      res.status(200).json({ success: true });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 6e-2. Export my account data (privacy-policy "download my data" — WhatsApp-grade
  // "request account info"). Scope is pinned by docs/SECURITY_PRIVACY_AUDIT.md §7:
  //   INCLUDED: account PUBLIC subset, own settings, contacts, blocked users,
  //     chats where the user is a MEMBER (db.getChatsForUser — membership is the
  //     isolation boundary), messages in those chats still visible to THIS user
  //     (deleted_for-filtered per viewer), attachment METADATA only (blobs live
  //     in the user's OWN Drive/S3 — never copied here), own session list
  //     (no refresh-token material), own auth-action log (IPs truncated as
  //     stored, F10), own E2EE PUBLIC keys only.
  //   NEVER included: other users' content beyond what the user's chats contain
  //     as a member, password hashes / user secrets, refresh tokens, E2EE
  //     private keys, storage credentials_encrypted.
  // Size limits (declared inside the payload): 200 messages per chat, 500
  //   auth-log entries, 50 sessions — the heavy cross-table surface is bounded
  //   and the payload STREAMS section-by-section (res.write), so no single
  //   O(whole-payload) JSON string is ever materialized in memory.
  app.get('/api/users/me/export', requireAuth, async (req, res) => {
    try {
      const userId = req.user!.userId;
      // 5/hour/user, critical class (fail-closed on Redis outage): the export is
      // a heavy cross-table query — a credential-grade budget so it can never be
      // used as a scrape or DoS lever.
      if (await checkLimit('export:data:user', userId)) {
        return res.status(429).json({ error: 'طلبات تصدير كثيرة. حاول بعد ساعة.' });
      }
      const [user, settings, contacts, blocks, chats] = await Promise.all([
        db.getUserById(userId),
        db.getUserSettings(userId),
        db.getContacts(userId),
        db.getBlockedUsers(userId),
        db.getChatsForUser(userId),
      ]);

      res.status(200);
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="dirasha-data-${userId.slice(0, 8)}.json"`);

      const MESSAGES_PER_CHAT = 200;
      const AUTH_LOG_LIMIT = 500;
      const SESSION_LIMIT = 50;

      // Account fields: PUBLIC subset only (no email — the account has none —
      // no secrets, no moderation flags, no settings-independent internals).
      const accountPublic = user ? {
        id: user.id,
        username: user.username,
        displayName: user.displayName,
        bio: user.bio || undefined,
        avatarUrl: user.avatarUrl || undefined,
        createdAt: user.createdAt,
        profileCompleted: user.profileCompleted,
      } : null;

      const write = (chunk: string) => res.write(chunk);

      write('{"format":"dirasha-export-v2",');
      write(`"exportedAt":${JSON.stringify(new Date().toISOString())},`);
      write(`"limits":{"messagesPerChat":${MESSAGES_PER_CHAT},"authLogEntries":${AUTH_LOG_LIMIT},"sessions":${SESSION_LIMIT},"note":"attachment file contents are NOT included — blobs live in the user's own cloud storage; only metadata is exported"},`);
      write(`"account":${JSON.stringify(accountPublic)},`);
      write(`"settings":${JSON.stringify(settings || {})},`);
      write(`"contacts":${JSON.stringify(contacts)},`);
      write(`"blockedUsers":${JSON.stringify(blocks)},`);

      // Chats + messages streamed one chat at a time. Ownership isolation:
      // getChatsForUser returns ONLY chats where the user is a member, and each
      // message is dropped when THIS user appears in its deleted_for list.
      write('"chats":[');
      const attachmentMetas: any[] = [];
      for (let i = 0; i < chats.length; i++) {
        const c = chats[i];
        const msgs = await db.getMessagesForChat(c.id, MESSAGES_PER_CHAT);
        const visible = msgs
          .filter(m => !(m.deletedFor || []).includes(userId))
          .map(m => {
            for (const a of (m.attachments || [])) {
              attachmentMetas.push({ messageId: m.id, chatId: m.chatId, id: (a as any).id || undefined, name: a.name, size: a.size, mimeType: a.mimeType, url: a.url });
            }
            return {
              id: m.id,
              chatId: m.chatId,
              senderId: m.senderId,
              senderName: m.senderName,
              content: m.content,
              type: m.type,
              attachments: m.attachments,
              reactions: m.reactions || {},
              createdAt: m.createdAt,
              editedAt: m.editedAt,
            };
          });
        write((i > 0 ? ',' : '') + JSON.stringify({
          id: c.id,
          type: c.type,
          name: c.name,
          lastActivity: c.updatedAt,
          messages: visible,
        }));
      }
      write('],');

      // Sessions: metadata only — the refresh-token field is stripped here even
      // though rows store a HASH, and revoked sessions are included for the audit trail.
      const sessions = (await db.getUserSessions(userId))
        .slice(0, SESSION_LIMIT)
        .map(s => ({
          id: s.id,
          userAgent: s.userAgent,
          ipAddress: s.ipAddress,
          isRevoked: s.isRevoked,
          expiresAt: s.expiresAt,
          createdAt: s.createdAt,
        }));
      const authLog = await db.getExportAuthLogs(userId, AUTH_LOG_LIMIT);
      const e2eePublicKeys = await db.getExportE2eePublicKeys(userId);

      write(`"attachmentsMetadata":${JSON.stringify(attachmentMetas)},`);
      write(`"sessions":${JSON.stringify(sessions)},`);
      write(`"authLog":${JSON.stringify(authLog)},`);
      write(`"e2eePublicKeys":${JSON.stringify(e2eePublicKeys)}`);
      write('}');
      res.end();
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      if (!res.headersSent) {
        res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
      } else {
        res.end();
      }
    }
  });

  // 6e. Settings Management (Cohesive relational theme, language, and privacy)
  app.get('/api/settings', requireAuth, async (req, res) => {
    try {
      const settings = await db.getUserSettings(req.user!.userId);
      res.status(200).json({ settings });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.put('/api/settings', requireAuth, async (req, res) => {
    try {
      const userId = req.user!.userId;
      const updated = await db.updateUserSettings(userId, req.body);

      // Broadcast changes across other user devices
      await redisCluster.publish(`user:updates:${userId}`, {
        event: 'user:settings_update',
        payload: { settings: updated }
      });

      res.status(200).json({ settings: updated, success: true });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Username change (Telegram parity) — unique-checked, audited, rate-limited
  app.put('/api/users/me/username', requireAuth, async (req, res) => {
    try {
      const userId = req.user!.userId;
      if (await checkLimit('username:change', userId)) {
        return res.status(429).json({ error: 'تغييرات كثيرة. حاول بعد ساعة.' });
      }
      const { newUsername } = req.body || {};
      if (!newUsername) return res.status(400).json({ error: 'newUsername مطلوب.' });
      const clean = normalizeUsername(String(newUsername));
      const validation = validateUsername(clean);
      if (!validation.isValid) {
        return res.status(400).json({ error: validation.error, field: 'username' });
      }
      const existing = await db.getUserByUsername(clean);
      if (existing && existing.id !== userId) {
        return res.status(409).json({ error: 'USERNAME_TAKEN', message: `اسم المستخدم "@${clean}" محجوز بالفعل.` });
      }
      const current = await db.getUserById(userId);
      if (db.isUsernameReserved(clean) && clean !== current?.username) {
        return res.status(409).json({ error: 'USERNAME_RESERVED', message: `اسم المستخدم "@${clean}" محفوظ من استخدام سابق.` });
      }
      // BATCH-1 (DIR-2026-001): operator handles are reserved from rename too —
      // renaming can no longer reach (or leave) an operator handle, and role
      // never derives from the name in any case.
      if (db.isAdminReservedName(clean) && clean !== current?.username) {
        return res.status(409).json({ error: 'USERNAME_RESERVED', message: `اسم المستخدم "@${clean}" محجوز للإدارة.` });
      }
      const old = current?.username || '';
      await db.setUsername(userId, clean);
      await db.logAuthAction(userId, 'username_changed', { from: old, to: clean, ip: (req.ip || '127.0.0.1').toString() });
      // Broadcast so other devices update
      redisCluster.publish(`user:updates:${userId}`, { event: 'user:settings_update', payload: {} }).catch(() => {});
      res.status(200).json({ ok: true, username: clean });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Call history (Calls tab) — real per-user log
  app.get('/api/calls', requireAuth, async (req, res) => {
    try {
      const log = db.getCallLog(req.user!.userId);
      const enriched = await Promise.all(log.map(async (e) => {
        const u = await db.getUserById(e.withUserId);
        return { ...e, avatarUrl: u?.avatarUrl || null };
      }));
      res.status(200).json({ calls: enriched });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Clear my call history (Calls tab "مسح السجل")
  app.delete('/api/calls', requireAuth, async (req, res) => {
    try {
      db.clearCallLog(req.user!.userId);
      res.status(200).json({ ok: true });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 6f. User Discovery: Paginated Search System (With advanced fuzzy match and rank matching - Stage 7)
  app.get('/api/users/search', requireAuth, async (req, res) => {
    try {
      const query = (req.query.query as string || '').trim();
      const page = parseInt(req.query.page as string || '1', 10);
      const limit = parseInt(req.query.limit as string || '15', 10);
      const userId = req.user!.userId;

      // P2-hardening: throttle directory scraping (authenticated enumeration vector).
      if (await checkLimit('search:user', userId)) {
        return res.status(429).json({ error: 'بحث كثير جداً. حاول بعد قليل.' });
      }

      const results = await db.searchUsersWithFuzzy(query, userId, page, limit);
      // Privacy enforcement: searchVisibility (nobody/contacts) — real filtering
      const visibleResults: any[] = [];
      for (const u of results) {
        const sv = (u as any).privacySettings?.searchVisibility || 'everyone';
        if (sv === 'nobody') continue;
        if (sv === 'contacts') {
          const contacts = await db.getContacts(u.id);
          if (!contacts.includes(userId)) continue;
        }
        visibleResults.push(u);
      }
      const users = await Promise.all(visibleResults.map(async (u) => {
        const userChats = await db.getChatsForUser(u.id);
        // Privacy enforcement: lastSeen/avatar/bio/search per owner's settings (contacts level included)
        const priv: any = u.privacySettings || {};
        const needsContact = priv.lastSeenVisibility === 'contacts' || priv.avatarVisibility === 'contacts' || priv.aboutVisibility === 'contacts';
        const viewerIsContact = needsContact
          ? ((await db.getContacts(u.id)) as string[]).includes(req.user!.userId)
          : false;
        let lastSeenOut = u.lastSeen;
        if (priv.lastSeenVisibility === 'nobody' || (priv.lastSeenVisibility === 'contacts' && !viewerIsContact)) {
          lastSeenOut = undefined;
        }
        let avatarOut = u.avatarUrl || u.photoURL;
        if (priv.avatarVisibility === 'nobody' || (priv.avatarVisibility === 'contacts' && !viewerIsContact)) {
          avatarOut = 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop';
        }
        let bioOut = u.bio;
        if (priv.aboutVisibility === 'nobody' || (priv.aboutVisibility === 'contacts' && !viewerIsContact)) {
          bioOut = undefined;
        }
        return {
          id: u.id,
          username: u.username,
          displayName: u.displayName,
          avatarUrl: avatarOut,
          photoURL: avatarOut,
          bannerUrl: u.bannerUrl,
          backgroundBannerUrl: u.backgroundBannerUrl,
          bannerShadowOpacity: u.bannerShadowOpacity,
          bgBannerShadowOpacity: u.bgBannerShadowOpacity,
          onlineStatus: u.onlineStatus,
          lastSeen: lastSeenOut,
          bio: bioOut,
          verified: u.verified,
          activeChatsCount: userChats.length
        };
      }));

      res.status(200).json({
        users,
        total: results.length
      });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 6g. Contacts Management Endpoints
  app.get('/api/contacts', requireAuth, async (req, res) => {
    try {
      const contactIds = await db.getContacts(req.user!.userId);
      const contacts = await Promise.all(contactIds.map(async (id) => await db.getUserById(id)));
      const filteredContacts = contacts.filter(Boolean);
      res.status(200).json({ contacts: filteredContacts });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.post('/api/contacts', requireAuth, async (req, res) => {
    try {
      const { contactId } = req.body;
      if (!contactId) return res.status(400).json({ error: 'contactId parameter is required.' });
      
      const success = await db.addContact(req.user!.userId, contactId);
      if (success) {
        res.status(200).json({ success: true, message: 'Contact successfully added.' });
      } else {
        res.status(400).json({ error: 'Failed to add contact: Invalid candidate.' });
      }
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.delete('/api/contacts/:contactId', requireAuth, async (req, res) => {
    try {
      const { contactId } = req.params;
      const success = await db.removeContact(req.user!.userId, contactId);
      res.status(200).json({ success, message: 'Contact removal dispatched.' });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 6h. Blocks Management Endpoints
  app.get('/api/blocks', requireAuth, async (req, res) => {
    try {
      const blockedIds = await db.getBlockedUsers(req.user!.userId);
      const blocked = await Promise.all(blockedIds.map(async id => await db.getUserById(id)));
      const filteredBlocked = blocked.filter(Boolean);
      res.status(200).json({ blocked_users: filteredBlocked });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.post('/api/blocks', requireAuth, async (req, res) => {
    try {
      const { blockedUserId } = req.body;
      if (!blockedUserId) return res.status(400).json({ error: 'blockedUserId is required.' });

      const success = await db.blockUser(req.user!.userId, blockedUserId);
      if (success) {
        res.status(200).json({ success: true, message: 'User blocked successfully.' });
      } else {
        res.status(400).json({ error: 'Failed to block target user.' });
      }
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.delete('/api/blocks/:blockedUserId', requireAuth, async (req, res) => {
    try {
      const { blockedUserId } = req.params;
      const success = await db.unblockUser(req.user!.userId, blockedUserId);
      res.status(200).json({ success, message: 'User unblocked.' });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 7. Users: Search and Contact lists
  // F5 hardening: the directory previously returned EVERY user in ONE response —
  // an unbounded scraping target. Now: 30/min/user distributed budget, pagination
  // (default 20, hard cap 100), and an explicit PUBLIC-FIELDS allowlist projection
  // (no email, no moderation/internal flags ever leave the server).
  app.get('/api/users', requireAuth, async (req, res) => {
    const t0 = performance.now();
    try {
      // F5: scrape budget — 30 directory requests / min / user (distributed).
      if (await checkLimit('users:directory:list', req.user!.userId)) {
        return res.status(429).json({ error: 'عدد كبير من الطلبات. حاول لاحقاً.' });
      }

      // F5: pagination — limit default 20, hard cap 100; offset non-negative.
      const parsedLimit = parseInt(req.query.limit as string, 10);
      const parsedOffset = parseInt(req.query.offset as string, 10);
      const limit = Math.min(Math.max(Number.isFinite(parsedLimit) ? parsedLimit : 20, 1), 100);
      const offset = Math.max(Number.isFinite(parsedOffset) ? parsedOffset : 0, 0);

      // Return everyone except currently logged in authenticated client
      const allUsers = await db.getUsers();
      // Privacy enforcement: searchVisibility on the directory too (nobody → hidden)
      const visibleAllUsers: any[] = [];
      for (const u of allUsers) {
        if (u.id === req.user!.userId) continue;
        const sv = (u as any).privacySettings?.searchVisibility || 'everyone';
        if (sv === 'nobody') continue;
        if (sv === 'contacts') {
          const contacts = await db.getContacts(u.id);
          if (!contacts.includes(req.user!.userId)) continue;
        }
        visibleAllUsers.push(u);
      }
      const activeChatsCountMap = await db.getUsersActiveChatsCount();
      // F5: paginate AFTER privacy visibility filtering (visibility never depends
      // on other users' rows) and BEFORE per-user enrichment, so each page costs
      // only its own contact lookups.
      const page = visibleAllUsers.slice(offset, offset + limit);
      const filtered = await Promise.all(page
        .map(async (u) => {
          const priv: any = u.privacySettings || {};
          const viewerIsContact = (priv.lastSeenVisibility === 'contacts' || priv.avatarVisibility === 'contacts' || priv.aboutVisibility === 'contacts')
            ? ((await db.getContacts(u.id)) as string[]).includes(req.user!.userId)
            : false;

          let lastSeen = u.lastSeen;
          if (priv.lastSeenVisibility === 'nobody') {
            lastSeen = undefined;
          } else if (priv.lastSeenVisibility === 'contacts' && !viewerIsContact) {
            lastSeen = undefined;
          }

          let bioOut = u.bio;
          if (priv.aboutVisibility === 'nobody' || (priv.aboutVisibility === 'contacts' && !viewerIsContact)) {
            bioOut = undefined;
          }

          let avatarUrl = u.avatarUrl;
          if (priv.avatarVisibility === 'nobody') {
            avatarUrl = 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop';
          } else if (priv.avatarVisibility === 'contacts' && !viewerIsContact) {
            avatarUrl = 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop';
          }

          // F5: PUBLIC-FIELDS ALLOWLIST — only profile data a stranger may see.
          // Private/internal fields (email, role, isBanned, mutedUntil, ban/mute
          // reasons, phone, secrets, settings…) are structurally excluded by
          // building the object field-by-field; never spread the raw user row.
          return {
            id: u.id,
            username: u.username,
            displayName: u.displayName,
            avatarUrl: avatarUrl,
            photoURL: avatarUrl,
            bannerUrl: u.bannerUrl,
            backgroundBannerUrl: u.backgroundBannerUrl,
            bannerShadowOpacity: u.bannerShadowOpacity,
            bgBannerShadowOpacity: u.bgBannerShadowOpacity,
            bio: bioOut,
            verified: u.verified,
            onlineStatus: u.onlineStatus,
            lastSeen: lastSeen,
            activeChatsCount: activeChatsCountMap[u.id] || 0
          };
        }));

      const t1 = performance.now();

      // Shape unchanged for existing consumers: `{ users: [...] }`.
      res.status(200).json({ users: filtered });
    } catch (err: any) {
      const t1 = performance.now();
      console.error('[Users Directory] listing failed:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 8. Chats Directory: Retrieve user's indexed chats along with aggregated statuses
  app.get('/api/chats', requireAuth, async (req, res) => {
    try {
      const userId = req.user!.userId;
      const chatsMetadata = await db.getOptimizedChatsForUser(userId);
      
      // Inject receipt status into the lastMessage to prevent the Sidebar showing "sent" while ChatWindow shows "read"
      const enrichedChats = await Promise.all(chatsMetadata.map(async (chat) => {
        if (chat.lastMessage) {
          const receipts = (await db.getMessageReceipts(chat.lastMessage.id)).filter(r => r.userId !== chat.lastMessage.senderId);
          let aggState = 'sent';
          if (receipts.length > 0) {
            const statuses = receipts.map(r => r.status);
            if (statuses.every(s => s === 'read')) {
              aggState = 'read';
            } else if (statuses.some(s => s === 'read' || s === 'delivered')) {
              aggState = 'delivered';
            }
          }
          chat.lastMessage.state = aggState;
        }
        return chat;
      }));

      res.status(200).json({ chats: enrichedChats });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 9. Chats: Create Room or Retrieve 1-to-1 if already exists
  app.post('/api/chats', requireAuth, async (req, res) => {
    try {
      const { type, name, memberIds: rawMemberIds } = req.body;
      // Channels omit memberIds (owner-only at creation) — normalize to [].
      let memberIds: string[] = rawMemberIds;
      if (type === 'channel' && !memberIds) memberIds = [];
      const userId = req.user!.userId;

      // P0-hardening: chat-creation flood throttle — 10/hour per user.
      if (restLimit(`chats:create:${userId}`, 10, 60 * 60 * 1000)) {
        return res.status(429).json({ error: 'عدد كبير من المحاولات، حاول لاحقاً.' });
      }

      if (!type || !['one-to-one', 'group', 'channel'].includes(type)) {
        return res.status(400).json({ error: 'type must be one-to-one|group|channel.' });
      }

      // Channels (Telegram parity): one-way broadcast spaces are created with
      // the owner ALONE — subscribers join via invite codes only, so memberIds
      // is optional/ignored for channels (never treated as direct adds).
      if (type === 'channel') {
        if (!Array.isArray(memberIds)) {
          return res.status(400).json({ error: 'Chat properties structure is invalid.' });
        }
      } else if (!memberIds || !Array.isArray(memberIds)) {
        return res.status(400).json({ error: 'Chat properties structure is invalid.' });
      }

      // Add self user to chat room if not existing
      const allMembers = Array.from(new Set([userId, ...memberIds]));

      let chat: Chat | null = null;
      let isNew = false;
      
      const sessionUser = await db.getUserById(userId);
      const isMuted = sessionUser?.mutedUntil && new Date(sessionUser.mutedUntil) > new Date();

      // Channel creation (Telegram parity): name 1..100, optional description,
      // creator = owner, no direct member adds (invite-code subscription only).
      if (type === 'channel') {
        const channelName = typeof name === 'string' ? name.trim() : '';
        if (!channelName || channelName.length > 100) {
          return res.status(400).json({ error: 'اسم القناة مطلوب (1-100 حرفاً).' });
        }
        if (isMuted) {
          return res.status(403).json({ error: 'حسابك مقيّد حالياً من إنشاء القنوات.' });
        }
        chat = await db.createChat('channel', channelName, [userId]);
        isNew = true;
        const description = typeof (req.body || {}).description === 'string'
          ? String((req.body as any).description).trim().slice(0, 500)
          : '';
        if (description) db.setChatInfo(chat.id, { description });
      } else if (type === 'one-to-one') {
        if (allMembers.length !== 2) {
          return res.status(400).json({ error: 'One-to-One chats must contain exactly 2 unique members.' });
        }
        const otherId = allMembers.find(m => m !== userId)!;

        // Privacy enforcement: blocks + DM policy on direct-chat creation
        if (await db.isBlocked(userId, otherId)) {
          return res.status(403).json({ error: 'لا يمكن بدء محادثة — أحدكما حظر الآخر.' });
        }
        const other = await db.getUserById(otherId);
        const adm = String(other?.privacySettings?.allowDirectMessages || 'everyone');
        if (adm === 'nobody') {
          return res.status(403).json({ error: 'هذا المستخدم لا يستقبل رسائل مباشرة.' });
        }
        if (adm === 'contacts') {
          const otherContacts = await db.getContacts(otherId);
          if (!otherContacts.includes(userId)) {
            return res.status(403).json({ error: 'المراسلة متاحة لجهات الاتصال فقط لهذا المستخدم.' });
          }
        }
        
        // Return existing is highly efficient
        const existing = await db.findOneToOneChat(userId, otherId);
        if (existing) {
          chat = existing;
          isNew = false;
        } else {
          chat = await db.createChat('one-to-one', null, allMembers);
          isNew = true;
        }
      } else {
        // Group chat creation
        if (isMuted) {
          return res.status(403).json({ error: 'Your account is currently restricted from creating groups.' });
        }

        // Privacy enforcement: allowGroupInvites — invitees with 'contacts' policy
        // can only be added by creators already in their contacts list.
        for (const inviteeId of allMembers) {
          if (inviteeId === userId) continue;
          const invitee = await db.getUserById(inviteeId);
          const policy = String(invitee?.privacySettings?.allowGroupInvites || 'everyone');
          // GROUP-01: 'nobody' is an ABSOLUTE block (the old code only handled
          // 'contacts' — a nobody-policy user could still be group-added here).
          if (policy === 'nobody') {
            return res.status(403).json({
              error: `لا يمكن إضافة ${invitee.displayName || 'هذا العضو'} — قد رفض الدعوات للمجموعات نهائيًا.`,
            });
          }
          if (policy === 'contacts') {
            const inviteeContacts = await db.getContacts(inviteeId);
            if (!inviteeContacts.includes(userId)) {
              return res.status(403).json({
                error: `لا يمكن إضافة ${invitee.displayName || 'هذا العضو'} — الإضافة للمجموعات متاحة لجهات اتصاله فقط.`,
              });
            }
          }
        }

        chat = await db.createChat('group', name || 'مجموعة جديدة غير مسمى', allMembers);
        isNew = true;
      }

      const otherMemberId = chat.type === 'one-to-one' ? allMembers.find(id => id !== userId) : null;
      const otherMember = otherMemberId ? await db.getUserById(otherMemberId) : null;

      const enrichedChat = {
        id: chat.id,
        type: chat.type,
        name: chat.name || (otherMember ? otherMember.displayName : 'ظ…ط³طھط®ط¯ظ… ط؛ط§ط¯ط± ط§ظ„ظ…ظ†طµط©'),
        avatarUrl: otherMember ? otherMember.avatarUrl : null,
        createdAt: chat.createdAt,
        updatedAt: chat.updatedAt,
        memberIds: allMembers,
        otherMember: otherMember ? {
          id: otherMember.id,
          displayName: otherMember.displayName,
          onlineStatus: otherMember.onlineStatus,
          lastSeen: otherMember.lastSeen,
        } : null,
        lastMessage: null,
        unreadCount: 0
      };

      if (isNew) {
        // Sync new chat across all active participants' devices/tabs
        for (const memberId of allMembers) {
          const specificOtherMemberId = chat.type === 'one-to-one' ? allMembers.find(id => id !== memberId) : null;
          const specificOtherMember = specificOtherMemberId ? await db.getUserById(specificOtherMemberId) : null;
          
          const specificEnrichedChat = {
            ...enrichedChat,
            name: chat.name || (specificOtherMember ? specificOtherMember.displayName : 'ظ…ط³طھط®ط¯ظ… ط؛ط§ط¯ط± ط§ظ„ظ…ظ†طµط©'),
            avatarUrl: specificOtherMember ? specificOtherMember.avatarUrl : null,
            otherMember: specificOtherMember ? {
              id: specificOtherMember.id,
              displayName: specificOtherMember.displayName,
              onlineStatus: specificOtherMember.onlineStatus,
              lastSeen: specificOtherMember.lastSeen,
            } : null,
          };
          
          await redisCluster.publish(`user:updates:${memberId}`, {
            event: 'chat:new',
            payload: { chat: specificEnrichedChat }
          });
        }
      }

      return res.status(isNew ? 201 : 200).json({ chat: enrichedChat, isNew });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // ── Group management (WhatsApp/TG parity) — all permission-gated ──────────
  // System event message: "فلان أضاف فلاناً" bubbles (WhatsApp parity)
  async function postGroupSystemMessage(chatId: string, actorId: string, text: string) {
    try {
      const id = 'msg-' + crypto.randomUUID();
      const now = new Date().toISOString();
      const actor = await db.getUserById(actorId);
      const payload = {
        id,
        chatId,
        senderId: actorId,
        senderName: actor?.displayName || 'النظام',
        body: text,
        content: text,
        type: 'system',
        metadata: { isSystem: true },
        state: 'sent',
        createdAt: now,
      };
      await db.createMessage(chatId, actorId, text, 'text', [], null, {}, id, now);
      const members = await db.getChatMembers(chatId);
      const pubs: Promise<any>[] = [redisCluster.publish(`chat:${chatId}`, { event: 'msg:new', payload })];
      for (const m of members) pubs.push(redisCluster.publish(`user:updates:${m.userId}`, { event: 'msg:new', payload }));
      await Promise.all(pubs);
    } catch (e: any) {
      console.error('[Groups] system message failed:', e.message);
    }
  }

  const requireGroupAdmin = async (req: Request, res: Response): Promise<boolean> => {
    const chatId = req.params.chatId;
    if (!db.getChatInfo(chatId)) {
      res.status(404).json({ error: 'المجموعة غير موجودة.' });
      return false;
    }
    if (!db.getChatRole(chatId, req.user!.userId)) {
      res.status(403).json({ error: 'لست عضواً في هذه المجموعة.' });
      return false;
    }
    return true;
  };

  // Group info (name/description/avatar) — permission-gated (whoCanEditInfo)
  app.put('/api/chats/:chatId/info', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      if (!(await requireGroupAdmin(req, res))) return;
      const { name, description, avatarUrl } = req.body || {};
      const perms = db.getChatPermissions(chatId);
      const isAdmin = db.isGroupAdmin(chatId, req.user!.userId);
      if (perms.whoCanEditInfo !== 'all' && !isAdmin) {
        return res.status(403).json({ error: 'تعديل معلومات المجموعة للمشرفين فقط.' });
      }
      // Granular admin rights (Telegram parity): admins need the editInfo right
      if (isAdmin && !db.adminCan(chatId, req.user!.userId, 'editInfo')) {
        return res.status(403).json({ error: 'لا تملك صلاحية تعديل معلومات المجموعة.' });
      }
      db.setChatInfo(chatId, {
        name: typeof name === 'string' && name.trim() ? name.trim().slice(0, 60) : undefined,
        description: typeof description === 'string' ? description.slice(0, 500) : undefined,
        avatarUrl: typeof avatarUrl === 'string' ? avatarUrl.slice(0, 500) : undefined,
      });
      if (typeof name === 'string' && name.trim()) {
        await postGroupSystemMessage(chatId, req.user!.userId, `${(await db.getUserById(req.user!.userId))?.displayName || 'مشرف'} غيّر اسم المجموعة إلى «${name.trim()}»`);
      }
      res.status(200).json({ ok: true, group: db.getChatInfo(chatId) });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Group permissions (whoCanSend / whoCanEditInfo) — admins only
  app.put('/api/chats/:chatId/permissions', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      if (!(await requireGroupAdmin(req, res))) return;
      if (!db.isGroupAdmin(chatId, req.user!.userId)) {
        return res.status(403).json({ error: 'الأذونات للمشرفين فقط.' });
      }
      const { whoCanSend, whoCanEditInfo, joinApproval } = req.body || {};
      if (whoCanSend && !['all', 'admins'].includes(whoCanSend)) {
        return res.status(400).json({ error: 'whoCanSend must be all|admins.' });
      }
      if (whoCanEditInfo && !['all', 'admins'].includes(whoCanEditInfo)) {
        return res.status(400).json({ error: 'whoCanEditInfo must be all|admins.' });
      }
      db.setChatPermissions(chatId, { whoCanSend, whoCanEditInfo });
      if (typeof joinApproval === 'boolean') db.setChatJoinApproval(chatId, joinApproval);
      res.status(200).json({ ok: true, permissions: db.getChatPermissions(chatId) });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Group detail with roles
  app.get('/api/chats/:chatId/group', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      if (!(await requireGroupAdmin(req, res))) return;
      const info = db.getChatInfo(chatId);
      if (!db.isGroupAdmin(chatId, req.user!.userId)) delete (info as any).inviteCode;
      const users = await Promise.all(info.members.map(async (m: any) => {
        const u = await db.getUserById(m.userId);
        return { ...m, displayName: u?.displayName || 'عضو', username: u?.username || '', avatarUrl: u?.avatarUrl || null };
      }));
      res.status(200).json({ group: { ...info, members: users } });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Add members — admins only (WhatsApp behavior)
  app.post('/api/chats/:chatId/members', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      if (!(await requireGroupAdmin(req, res))) return;
      if (!db.adminCan(chatId, req.user!.userId, 'addMembers')) {
        return res.status(403).json({ error: 'لا تملك صلاحية إضافة الأعضاء.' });
      }
      const { userIds } = req.body || {};
      if (!Array.isArray(userIds) || userIds.length === 0) {
        return res.status(400).json({ error: 'userIds مطلوب.' });
      }
      // Ban enforcement: banned users can never be re-added (defect fix)
      const bannedHit = userIds.filter((id: string) => db.isGroupBanned(chatId, id));
      if (bannedHit.length > 0) {
        return res.status(403).json({ error: 'أحد الأعضاء المحظورين لا يمكن إضافته مجدداً.' });
      }
      // GROUP-01 (external audit): enforce EVERY targeted user's
      // allowGroupInvites preference on the ADD path too (the create path
      // checked contacts-only; the add path checked nothing).
      for (const uid of userIds.slice(0, 50)) {
        if (typeof uid !== 'string' || uid === req.user!.userId) continue;
        const target = await db.getUserById(uid);
        const policy = String(target?.privacySettings?.allowGroupInvites || 'everyone');
        if (policy === 'nobody') {
          return res.status(403).json({ error: `لا يمكن إضافة ${target?.displayName || 'هذا العضو'} — قد رفض الدعوات للمجموعات نهائيًا.` });
        }
        if (policy === 'contacts') {
          const targetContacts = await db.getContacts(uid);
          if (!targetContacts.includes(req.user!.userId)) {
            return res.status(403).json({ error: `لا يمكن إضافة ${target?.displayName || 'هذا العضو'} — الإضافة للمجموعات متاحة لجهات اتصاله فقط.` });
          }
        }
      }
      // DIR-NEW-04: ATOMIC membership add + epoch bump (one PG transaction,
      // RETURNING, publish-after-commit; 503 on tx failure).
      const addIds = userIds.slice(0, 50).filter((id: string) => typeof id === 'string');
      let newMvAdd: number;
      try {
        newMvAdd = await db.applyMembershipChange(chatId, 'add', addIds);
      } catch (e: any) {
        if (String(e?.message || '').startsWith('MEMBERSHIP_TX_FAILED')) {
          return res.status(503).json({ error: 'تعذر تطبيق تغيير العضوية — أعد المحاولة.', code: 'MEMBERSHIP_TX_FAILED' });
        }
        throw e;
      }
      const memberIdsAfterAdd = (db.getChatInfo(chatId)?.members || []).map((m: any) => m.userId);
      for (const uid of memberIdsAfterAdd) {
        redisCluster.publish(`user:updates:${uid}`, { event: 'chat:membership_changed', payload: { chatId, addedUserIds: userIds.slice(0, 50).filter((id: string) => typeof id === 'string'), membershipVersion: newMvAdd } }).catch(() => {});
      }
      for (const uid of userIds.slice(0, 50)) {
        if (typeof uid !== 'string') continue;
        const [u, actor] = await Promise.all([db.getUserById(uid), db.getUserById(req.user!.userId)]);
        await postGroupSystemMessage(chatId, req.user!.userId, `${actor?.displayName || 'مشرف'} أضاف ${u?.displayName || 'عضواً'} إلى المجموعة`);
        redisCluster.publish(`user:updates:${uid}`, { event: 'chats:refresh', payload: {} }).catch(() => {});
      }
      res.status(200).json({ ok: true, group: db.getChatInfo(chatId) });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Remove member / leave — self-leave always allowed; removal is admin-only
  app.delete('/api/chats/:chatId/members/:userId', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      const targetId = req.params.userId;
      if (!(await requireGroupAdmin(req, res))) return;
      const isSelf = targetId === req.user!.userId;
      if (!isSelf && !db.isGroupAdmin(chatId, req.user!.userId)) {
        return res.status(403).json({ error: 'إزالة الأعضاء للمشرفين فقط.' });
      }
      // Owner cannot be removed by others
      if (!isSelf && db.getChatRole(chatId, targetId) === 'owner') {
        return res.status(403).json({ error: 'لا يمكن إزالة مالك المجموعة.' });
      }
      // DIR-NEW-04: ATOMIC membership change + epoch bump (one PG transaction
      // with RETURNING; memory mirror resynced from the authoritative value).
      // Events publish ONLY after the commit — a failed tx answers 503 and
      // broadcasts nothing.
      let newMv: number;
      try {
        newMv = await db.applyMembershipChange(chatId, 'remove', [targetId]);
      } catch (e: any) {
        if (String(e?.message || '').startsWith('MEMBERSHIP_TX_FAILED')) {
          return res.status(503).json({ error: 'تعذر تطبيق تغيير العضوية — أعد المحاولة.', code: 'MEMBERSHIP_TX_FAILED' });
        }
        throw e;
      }
      const remainingIds = (db.getChatInfo(chatId)?.members || []).map((m: any) => m.userId);
      for (const uid of remainingIds) {
        redisCluster.publish(`user:updates:${uid}`, { event: 'chat:membership_changed', payload: { chatId, removedUserId: targetId, membershipVersion: newMv } }).catch(() => {});
      }
      redisCluster.publish(`user:updates:${targetId}`, { event: 'chat:evicted', payload: { chatId, userId: targetId, membershipVersion: newMv } }).catch(() => {});
      const [actorR, targetU] = await Promise.all([db.getUserById(req.user!.userId), db.getUserById(targetId)]);
      db.addPastMember(chatId, targetId, targetU?.displayName || 'عضو', actorR?.displayName);
      await postGroupSystemMessage(chatId, req.user!.userId, `${actorR?.displayName || 'مشرف'} أزال ${targetU?.displayName || 'عضواً'} من المجموعة`);
      res.status(200).json({ ok: true, left: isSelf });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Promote/demote — owner only
  app.post('/api/chats/:chatId/promote', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      if (!(await requireGroupAdmin(req, res))) return;
      if (db.getChatRole(chatId, req.user!.userId) !== 'owner') {
        return res.status(403).json({ error: 'الترقية والتخفيض للمالك فقط.' });
      }
      const { userId, role } = req.body || {};
      if (!userId || !['admin', 'member'].includes(role)) {
        return res.status(400).json({ error: 'userId و role (admin|member) مطلوبان.' });
      }
      if (!db.getChatRole(chatId, userId)) {
        return res.status(404).json({ error: 'العضو غير موجود في المجموعة.' });
      }
      db.setChatRole(chatId, userId, role);
      const [actor, target] = await Promise.all([db.getUserById(req.user!.userId), db.getUserById(userId)]);
      await postGroupSystemMessage(chatId, req.user!.userId, `${actor?.displayName || 'المالك'} رقّى ${target?.displayName || 'عضواً'} إلى ${role === 'admin' ? 'مشرفاً' : 'عضواً'}`);
      res.status(200).json({ ok: true, group: db.getChatInfo(chatId) });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Leave group — owner transfer to first admin/member; last member deletes group
  app.post('/api/chats/:chatId/leave', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      if (!(await requireGroupAdmin(req, res))) return;
      const role = db.getChatRole(chatId, req.user!.userId)!;
      const info = db.getChatInfo(chatId);
      if (info.members.length === 1) {
        db.deleteChat(chatId);
        return res.status(200).json({ ok: true, deleted: true });
      }
      // DIR-NEW-04: atomic membership+bump; publish after commit only.
      let newMvLeave: number;
      try {
        newMvLeave = await db.applyMembershipChange(chatId, 'remove', [req.user!.userId]);
      } catch (e: any) {
        if (String(e?.message || '').startsWith('MEMBERSHIP_TX_FAILED')) {
          return res.status(503).json({ error: 'تعذر تطبيق تغيير العضوية — أعد المحاولة.', code: 'MEMBERSHIP_TX_FAILED' });
        }
        throw e;
      }
      const remainingIdsLeave = (db.getChatInfo(chatId)?.members || []).map((m: any) => m.userId);
      for (const uid of remainingIdsLeave) {
        redisCluster.publish(`user:updates:${uid}`, { event: 'chat:membership_changed', payload: { chatId, removedUserId: req.user!.userId, membershipVersion: newMvLeave } }).catch(() => {});
      }
      if (role === 'owner') {
        const nextOwner = info.members.find((m: any) => m.userId !== req.user!.userId && m.role === 'admin')
          || info.members.find((m: any) => m.userId !== req.user!.userId);
        if (nextOwner) db.setChatRole(chatId, nextOwner.userId, 'owner');
      }
      redisCluster.publish(`user:updates:${req.user!.userId}`, { event: 'chat:evicted', payload: { chatId, userId: req.user!.userId, membershipVersion: newMvLeave } }).catch(() => {});
      const leaver = await db.getUserById(req.user!.userId);
      db.addPastMember(chatId, req.user!.userId, leaver?.displayName || 'عضو');
      await postGroupSystemMessage(chatId, req.user!.userId, `${leaver?.displayName || 'عضو'} غادر المجموعة`);
      res.status(200).json({ ok: true, left: true });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Delete group — owner only
  app.delete('/api/chats/:chatId', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      if (!(await requireGroupAdmin(req, res))) return;
      if (db.getChatRole(chatId, req.user!.userId) !== 'owner') {
        return res.status(403).json({ error: 'حذف المجموعة للمالك فقط.' });
      }
      db.deleteChat(chatId);
      res.status(200).json({ ok: true });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Group invite code (WhatsApp parity) — admin creates/gets, anyone joins by code
  app.post('/api/chats/:chatId/invite', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      if (!(await requireGroupAdmin(req, res))) return;
      if (!db.isGroupAdmin(chatId, req.user!.userId)) {
        return res.status(403).json({ error: 'رابط الدعوة للمشرفين فقط.' });
      }
      const info = db.getChatInfo(chatId);
      const existing = (info as any)?.inviteCode;
      const make = () => 'd' + crypto.randomBytes(6).toString('base64url');
      const finalCode = existing || make();
      if (!existing) db.setChatInviteCode(chatId, finalCode);
      // Telegram-style expiry: 1d | 1w | never (default)
      const { expiresIn, usageLimit } = req.body || {};
      const map: Record<string, number | null> = { '1d': 86400_000, '1w': 7 * 86400_000, never: null };
      if (expiresIn && expiresIn in map) {
        const ms = map[expiresIn];
        db.setChatInviteExpiry(chatId, ms ? Date.now() + ms : null);
      }
      if (usageLimit !== undefined) {
        const lim = Number(usageLimit);
        if (!Number.isFinite(lim) || lim < 0 || lim > 1000) {
          return res.status(400).json({ error: 'usageLimit must be 0-1000 (0 = unlimited).' });
        }
        db.setInviteUsageLimit(chatId, lim);
      }
      res.status(200).json({ ok: true, code: finalCode, expiresAt: db.getChatInviteExpiry(chatId) });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Join group by invite code — expiry + optional admin-approval (Telegram parity)
  app.post('/api/chats/join', requireAuth, async (req, res) => {
    try {
      const { code } = req.body || {};
      if (!code || typeof code !== 'string') return res.status(400).json({ error: 'كود الدعوة مطلوب.' });
      const chatId = db.findChatByInviteCode(String(code).trim());
      if (!chatId) return res.status(404).json({ error: 'كود الدعوة غير صالح.' });
      const info = db.getChatInfo(chatId);
      // Channels join by invite too (Telegram parity) — that is their ONLY join path.
      if (!info || (info.type !== 'group' && info.type !== 'channel')) {
        return res.status(404).json({ error: 'المجموعة غير موجودة.' });
      }
      if (info.members.some((m: any) => m.userId === req.user!.userId)) {
        return res.status(200).json({ ok: true, chatId, alreadyMember: true });
      }
      const expiry = db.getChatInviteExpiry(chatId);
      if (expiry && Date.now() > expiry) {
        return res.status(410).json({ error: 'انتهت صلاحية رابط الدعوة.' });
      }
      // Block guard: blocked pair with the owner → reject join
      const ownerId = info.members.find((m: any) => m.role === 'owner')?.userId;
      if (ownerId && (await db.isBlocked(req.user!.userId, ownerId))) {
        return res.status(403).json({ error: 'لا يمكنك الانضمام — أحدكما حظر الآخر.' });
      }
      // Ban enforcement: banned users cannot rejoin via invite codes (defect fix)
      if (db.isGroupBanned(chatId, req.user!.userId)) {
        return res.status(403).json({ error: 'أنت محظور من هذه المجموعة.' });
      }
      // Invite usage limit (WhatsApp parity)
      if (!db.consumeInviteUsage(chatId)) {
        return res.status(403).json({ error: 'انتهت عدد استخدامات رابط الدعوة.' });
      }
      // Admin-approval mode: queue the request instead of joining.
      // Channels NEVER queue join requests — invite codes join immediately
      // (server rejects the join-requests endpoints for channels separately).
      if (info.type === 'group' && db.getChatJoinApproval(chatId)) {
        const requests = db.getChatJoinRequests(chatId);
        if (requests.some(r => r.userId === req.user!.userId)) {
          return res.status(200).json({ ok: true, pending: true, message: 'طلبك قيد المراجعة من مشرفي المجموعة.' });
        }
        const me = await db.getUserById(req.user!.userId);
        requests.push({ userId: req.user!.userId, displayName: me?.displayName || 'عضو', username: me?.username || '', at: Date.now() });
        db.setChatJoinRequests(chatId, requests);
        return res.status(200).json({ ok: true, pending: true, message: 'تم إرسال طلب الانضمام — بانتظار موافقة المشرفين.' });
      }
      // DIR-NEW-04: join via invite link is a membership change — atomic
      // add+bump (same epoch guarantee as admin-add/remove).
      try {
        await db.applyMembershipChange(chatId, 'add', [req.user!.userId]);
      } catch (e: any) {
        if (String(e?.message || '').startsWith('MEMBERSHIP_TX_FAILED')) {
          return res.status(503).json({ error: 'تعذر تطبيق تغيير العضوية — أعد المحاولة.', code: 'MEMBERSHIP_TX_FAILED' });
        }
        throw e;
      }
      // BATCH-2 (E2EE-02 residual): join is a membership change — remaining
      // members (incl. the joiner) learn the new epoch version immediately.
      const joinMv = db.getMembershipVersion(chatId);
      const joinMembers = (await db.getChatMembers(chatId)).map((m: any) => m.userId);
      for (const mid of joinMembers) {
        redisCluster.publish(`user:updates:${mid}`, { event: 'chat:membership_changed', payload: { chatId, membershipVersion: joinMv } }).catch(() => {});
      }
      const joiner = await db.getUserById(req.user!.userId);
      await postGroupSystemMessage(
        chatId,
        req.user!.userId,
        `${joiner?.displayName || 'عضو'} انضم إلى ${info.type === 'channel' ? 'القناة' : 'المجموعة'} عبر رابط الدعوة`,
      );
      res.status(200).json({ ok: true, chatId, chatType: info.type });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Join requests: list / approve / reject — admins only
  app.get('/api/chats/:chatId/join-requests', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      if (!(await requireGroupAdmin(req, res))) return;
      // Channels have no approval flow — invite codes are the only join path.
      if (db.getChatType(chatId) === 'channel') {
        return res.status(400).json({ error: 'القنوات تدعم الانضمام بالدعوة فقط حالياً.' });
      }
      if (!db.isGroupAdmin(chatId, req.user!.userId)) {
        return res.status(403).json({ error: 'طلبات الانضمام للمشرفين فقط.' });
      }
      res.status(200).json({ requests: db.getChatJoinRequests(chatId) });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.post('/api/chats/:chatId/join-requests/:userId', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      const targetId = req.params.userId;
      if (!(await requireGroupAdmin(req, res))) return;
      // Channels have no approval flow — invite codes are the only join path.
      if (db.getChatType(chatId) === 'channel') {
        return res.status(400).json({ error: 'القنوات تدعم الانضمام بالدعوة فقط حالياً.' });
      }
      if (!db.isGroupAdmin(chatId, req.user!.userId)) {
        return res.status(403).json({ error: 'طلبات الانضمام للمشرفين فقط.' });
      }
      const approve = String(req.body?.approve) === 'true';
      const requests = db.getChatJoinRequests(chatId);
      const idx = requests.findIndex(r => r.userId === targetId);
      if (idx === -1) return res.status(404).json({ error: 'الطلب غير موجود.' });
      const [reqUser] = requests.splice(idx, 1);
      db.setChatJoinRequests(chatId, requests);
      if (approve) {
        // DIR-NEW-04: approval-add is a membership change — atomic add+bump.
        try {
          await db.applyMembershipChange(chatId, 'add', [targetId]);
        } catch (e: any) {
          if (String(e?.message || '').startsWith('MEMBERSHIP_TX_FAILED')) {
            return res.status(503).json({ error: 'تعذر تطبيق تغيير العضوية — أعد المحاولة.', code: 'MEMBERSHIP_TX_FAILED' });
          }
          throw e;
        }
        // BATCH-2 (E2EE-02 residual): approval-add broadcasts too — all five
        // membership paths now notify remaining members (remove/leave/add/
        // join/approval/ban).
        const apprMv = db.getMembershipVersion(chatId);
        const apprMembers = (await db.getChatMembers(chatId)).map((m: any) => m.userId);
        for (const mid of apprMembers) {
          redisCluster.publish(`user:updates:${mid}`, { event: 'chat:membership_changed', payload: { chatId, membershipVersion: apprMv } }).catch(() => {});
        }
        await postGroupSystemMessage(chatId, req.user!.userId, `${reqUser.displayName} انضم إلى المجموعة بعد موافقة ${(await db.getUserById(req.user!.userId))?.displayName || 'المشرف'}`);
      }
      res.status(200).json({ ok: true, approved: approve });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // ── Channels (Telegram parity) ────────────────────────────────────────────
  // Subscriber count — visible to ANY member (owner/admin/member alike); the
  // count is not sensitive. Works for channels (and harmlessly for groups).
  app.get('/api/chats/:chatId/subscribers/count', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      const info = db.getChatInfo(chatId);
      if (!info) return res.status(404).json({ error: 'المحادثة غير موجودة.' });
      if (!db.getChatRole(chatId, req.user!.userId)) {
        return res.status(403).json({ error: 'لست مشتركاً في هذه القناة.' });
      }
      const count = await db.getChannelSubscriberCount(chatId);
      res.status(200).json({ count, type: info.type });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Disappearing messages timer (WhatsApp parity) — members may set for their chats
  app.put('/api/chats/:chatId/disappearing', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      if (!(await requireGroupAdmin(req, res))) return;
      const { timer } = req.body || {};
      if (!['off', '24h', '7d', '90d'].includes(timer)) {
        return res.status(400).json({ error: 'timer must be off|24h|7d|90d.' });
      }
      db.setChatDisappearingTimer(chatId, timer);
      const label: Record<string, string> = { off: 'إيقاف', '24h': '24 ساعة', '7d': '7 أيام', '90d': '90 يوماً' };
      await postGroupSystemMessage(chatId, req.user!.userId, `${(await db.getUserById(req.user!.userId))?.displayName || 'عضو'} ضبط الرسائل المتلاشية: ${label[timer as string]}`);
      res.status(200).json({ ok: true, timer: db.getChatDisappearingTimer(chatId) });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Slow mode (Telegram parity) — admins only; seconds between member messages
  app.put('/api/chats/:chatId/slow-mode', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      if (!(await requireGroupAdmin(req, res))) return;
      if (!db.isGroupAdmin(chatId, req.user!.userId)) {
        return res.status(403).json({ error: 'الوضع البطيء للمشرفين فقط.' });
      }
      const { seconds } = req.body || {};
      const allowed = [0, 10, 30, 60, 300, 900];
      if (!allowed.includes(Number(seconds))) {
        return res.status(400).json({ error: 'seconds must be one of 0|10|30|60|300|900.' });
      }
      db.setChatSlowMode(chatId, Number(seconds));
      res.status(200).json({ ok: true, slowMode: Number(seconds) });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Ban member from group (admin) — removal + permanent rejoin block
  app.post('/api/chats/:chatId/ban', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      if (!(await requireGroupAdmin(req, res))) return;
      if (!db.isGroupAdmin(chatId, req.user!.userId)) {
        return res.status(403).json({ error: 'الحظر للمشرفين فقط.' });
      }
      const { userId } = req.body || {};
      if (!userId || userId === req.user!.userId) return res.status(400).json({ error: 'userId مطلوب.' });
      if (db.getChatRole(chatId, userId) === 'owner') {
        return res.status(403).json({ error: 'لا يمكن حظر مالك المجموعة.' });
      }
      db.banGroupMember(chatId, userId);
      // BATCH-2 (DIR-CB-01): membership removal goes through the ATOMIC
      // applyMembershipChange (mv bump + roster tx), then the standard
      // broadcasts fire: membership_changed → REMAINING members (rotation
      // trigger), evicted → the banned user WITH its identity.
      const newMv = await db.applyMembershipChange(chatId, 'remove', [userId]);
      const remaining = (await db.getChatMembers(chatId)).map((m: any) => m.userId);
      for (const mid of remaining) {
        redisCluster.publish(`user:updates:${mid}`, { event: 'chat:membership_changed', payload: { chatId, membershipVersion: newMv } }).catch(() => {});
      }
      redisCluster.publish(`user:updates:${userId}`, { event: 'chat:evicted', payload: { chatId, userId, membershipVersion: newMv } }).catch(() => {});
      const [target, actor] = await Promise.all([db.getUserById(userId), db.getUserById(req.user!.userId)]);
      db.addPastMember(chatId, userId, target?.displayName || 'عضو', actor?.displayName);
      await postGroupSystemMessage(chatId, req.user!.userId, `${actor?.displayName || 'مشرف'} حظر ${target?.displayName || 'عضواً'} من المجموعة`);
      res.status(200).json({ ok: true, bans: db.getGroupBans(chatId) });
    } catch (e: any) {
      if (String(e?.message || '').startsWith('MEMBERSHIP_TX_FAILED')) {
        return res.status(503).json({ error: 'تعذر تطبيق تغيير العضوية — أعد المحاولة.', code: 'MEMBERSHIP_TX_FAILED' });
      }
      console.error('[Server] Unhandled route error:', e);
      return res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.post('/api/chats/:chatId/unban', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      if (!(await requireGroupAdmin(req, res))) return;
      if (!db.isGroupAdmin(chatId, req.user!.userId)) {
        return res.status(403).json({ error: 'رفع الحظر للمشرفين فقط.' });
      }
      const { userId } = req.body || {};
      db.unbanGroupMember(chatId, userId);
      res.status(200).json({ ok: true, bans: db.getGroupBans(chatId) });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Restrict member from sending in this group (Telegram parity)
  app.post('/api/chats/:chatId/restrict', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      if (!(await requireGroupAdmin(req, res))) return;
      if (!db.isGroupAdmin(chatId, req.user!.userId)) {
        return res.status(403).json({ error: 'الكتم داخل المجموعة للمشرفين فقط.' });
      }
      const { userId, minutes } = req.body || {};
      if (!userId || userId === req.user!.userId) return res.status(400).json({ error: 'userId مطلوب.' });
      const until = Number(minutes) > 0 ? Date.now() + Number(minutes) * 60_000 : -1;
      db.restrictGroupMember(chatId, userId, until);
      const [target, actor] = await Promise.all([db.getUserById(userId), db.getUserById(req.user!.userId)]);
      await postGroupSystemMessage(chatId, req.user!.userId, Number(minutes) > 0
        ? `${actor?.displayName || 'مشرف'} كتم ${target?.displayName || 'عضواً'} داخل المجموعة لمدة ${Number(minutes)} دقيقة`
        : `${actor?.displayName || 'مشرف'} كتم ${target?.displayName || 'عضواً'} داخل المجموعة دائماً`);
      res.status(200).json({ ok: true, remainingMs: db.getGroupRestriction(chatId, userId) });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Protected content (Telegram parity) — admins toggle; client disables copy/forward/download
  app.put('/api/chats/:chatId/protected', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      if (!(await requireGroupAdmin(req, res))) return;
      if (!db.isGroupAdmin(chatId, req.user!.userId)) {
        return res.status(403).json({ error: 'حماية المحتوى للمشرفين فقط.' });
      }
      const enabled = req.body?.enabled === true;
      db.setProtectedContent(chatId, enabled);
      await postGroupSystemMessage(chatId, req.user!.userId, `${(await db.getUserById(req.user!.userId))?.displayName || 'مشرف'} ${enabled ? 'فعّل' : 'أوقف'} حماية محتوى المجموعة`);
      res.status(200).json({ ok: true, protected: enabled });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Past members (WhatsApp parity) — admins only
  app.get('/api/chats/:chatId/past-members', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      if (!(await requireGroupAdmin(req, res))) return;
      if (!db.isGroupAdmin(chatId, req.user!.userId)) {
        return res.status(403).json({ error: 'الأعضاء السابقون للمشرفين فقط.' });
      }
      res.status(200).json({ pastMembers: db.getPastMembers(chatId) });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Granular admin rights (Telegram parity) — owner only
  app.post('/api/chats/:chatId/admin-rights', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      if (!(await requireGroupAdmin(req, res))) return;
      if (db.getChatRole(chatId, req.user!.userId) !== 'owner') {
        return res.status(403).json({ error: 'ضبط صلاحيات المشرفين للمالك فقط.' });
      }
      const { userId, right, value } = req.body || {};
      const rights = ['addMembers', 'editInfo', 'pinMessages', 'deleteMessages'];
      if (!userId || !rights.includes(right) || typeof value !== 'boolean') {
        return res.status(400).json({ error: 'userId و right و value مطلوبة.' });
      }
      if (db.getChatRole(chatId, userId) !== 'admin') {
        return res.status(400).json({ error: 'المستخدم ليس مشرفاً.' });
      }
      db.setAdminRight(chatId, userId, right, value);
      res.status(200).json({ ok: true, rights: db.getAdminRights(chatId, userId) });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Clear chat history for SELF (WhatsApp parity) — others keep their copy
  app.post('/api/chats/:chatId/clear-me', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      const userId = req.user!.userId;
      const members = await db.getChatMembers(chatId);
      if (!members.some(m => m.userId === userId)) {
        return res.status(403).json({ error: 'Access Denied: You are not a member of this chat.' });
      }
      const msgs = await db.getMessagesForChat(chatId, 10000);
      let cleared = 0;
      for (const m of msgs) {
        const full = await db.getMessageById(m.id);
        if (!full || (full.deletedFor || []).includes(userId)) continue;
        const deletedFor = [...(full.deletedFor || []), userId];
        await db.updateMessage(m.id, { deletedFor });
        cleared++;
      }
      res.status(200).json({ ok: true, cleared });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Group stats — admins only (WhatsApp "group info" parity)
  app.get('/api/chats/:chatId/stats', requireAuth, async (req, res) => {
    try {
      const chatId = req.params.chatId;
      if (!(await requireGroupAdmin(req, res))) return;
      if (!db.isGroupAdmin(chatId, req.user!.userId)) {
        return res.status(403).json({ error: 'الإحصائيات للمشرفين فقط.' });
      }
      const msgs = await db.getMessagesForChat(chatId, 10000);
      const real = msgs.filter((m: any) => !(m.metadata?.isSystem || m.type === 'system'));
      const bySender = new Map<string, number>();
      real.forEach((m: any) => bySender.set(m.senderId, (bySender.get(m.senderId) || 0) + 1));
      const topActive = await Promise.all(Array.from(bySender.entries())
        .sort((a, b) => b[1] - a[1]).slice(0, 5)
        .map(async ([uid, count]) => {
          const u = await db.getUserById(uid);
          return { userId: uid, displayName: u?.displayName || 'عضو', count };
        }));
      const last7 = real.filter((m: any) => Date.now() - new Date(m.createdAt).getTime() < 7 * 86400_000).length;
      res.status(200).json({
        totalMessages: real.length,
        messagesLast7Days: last7,
        memberCount: db.getChatInfo(chatId).members.length,
        topActive,
      });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

   // 10. Messages: Segmented history loading (Page cursor implementation)
   app.get('/api/telemetry/messages/:messageId', requireAuth, async (req, res) => {
    try {
      const { messageId } = req.params;

      // Authorization: only members of the message's chat may inspect its telemetry (IDOR guard)
      const targetMessage = await db.getMessageById(messageId);
      if (!targetMessage) {
        return res.status(404).json({ error: 'Message not found' });
      }
      const telemetryMembers = await db.getChatMembers(targetMessage.chatId);
      if (!telemetryMembers.some(m => m.userId === req.user!.userId)) {
        return res.status(403).json({ error: 'Access Denied: You are not a registered member of this chat conversation.' });
      }

      const dbInstance = (await import('./src/server/database.ts')).pool;
      
      const telemetryRes = await dbInstance.query(
        `SELECT * FROM message_status_telemetry WHERE message_id = $1 ORDER BY created_at ASC`,
        [messageId]
      );
      
      const receiptRes = await dbInstance.query(
        `SELECT user_id, status, updated_at FROM message_reads WHERE message_id = $1`,
        [messageId]
      );

      res.status(200).json({
        telemetry: telemetryRes.rows,
        currentReceipts: receiptRes.rows
      });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.get('/api/chats/:chatId/messages', requireAuth, async (req, res) => {
     try {
       const { chatId } = req.params;
       const limit = parseInt(req.query.limit as string) || 30;
       const before = req.query.before as string; // Timestamp cursor
       const afterTimestamp = req.query.afterTimestamp as string;

       // Validate user membership with dynamic auto-provisioning fallback for direct 1-to-1 rooms
       let members = await db.getChatMembers(chatId);
       if (members.length === 0 && chatId.startsWith('one_to_one_')) {
         const parts = chatId.replace('one_to_one_', '').split('___');
         if (parts.length === 2) {
           const [u1, u2] = parts;
           if (req.user!.userId === u1 || req.user!.userId === u2) {

             await db.createChat('one-to-one', '', [u1, u2], chatId);
             members = await db.getChatMembers(chatId);
           }
         }
       }

       const currentUserId = req.user!.userId;
       if (!members.some(m => m.userId === currentUserId)) {
         console.warn(`[API] Auth Denied: User ${currentUserId} is not in member index of room ${chatId}. Registered members:`, members.map(m => m.userId));
         return res.status(403).json({ error: 'Access Denied: You are not a registered member of this chat conversation.' });
       }
      const messages = await db.getMessagesForChat(chatId, limit, before, afterTimestamp);
      const viewerId = req.user!.userId;

      // Privacy: messages deleted FOR ME never cross the wire, and the
      // deletedFor arrays themselves are stripped from outgoing payloads.
      const forMe = messages.filter((m: any) => !((m.deletedFor || m.deleted_for || []) as string[]).includes(viewerId));
      const cleaned = forMe.map((m: any) => {
        const { deletedFor, deleted_for, ...rest } = m;
        return rest;
      });

      // Inject sender details and delivery receipt states
      const enrichedMessages = await Promise.all(cleaned.map(async (m: any) => {
        const senderObj = await db.getUserById(m.senderId);
        
        // Find receipt state (sending, sent, delivered, read)
        // Set delivery state to lowest mutual receipt state across members
        const receipts = (await db.getMessageReceipts(m.id)).filter(r => r.userId !== m.senderId);
        let aggState: 'sent' | 'delivered' | 'read' = 'sent';

        if (receipts.length > 0) {
          const statuses = receipts.map(r => r.status);
          if (statuses.every(s => s === 'read')) {
            aggState = 'read';
          } else if (statuses.some(s => s === 'read' || s === 'delivered')) {
            aggState = 'delivered';
          }
        }

        return {
          ...m,
          sender: senderObj ? {
            id: senderObj.id,
            username: senderObj.username,
            displayName: senderObj.displayName,
            avatarUrl: senderObj.avatarUrl,
            onlineStatus: senderObj.onlineStatus
            // BATCH-6 (ADV-03): lastSeen never rides msg:new fan-out (AB-09 parity)
          } : undefined,
          state: aggState
        };
      }));

      res.status(200).json({ messages: enrichedMessages });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 10c. In-chat message search (parameterized ILIKE — query is NEVER interpolated).
  //      Membership is validated here before db.searchMessagesInChat runs.
  app.get('/api/chats/:chatId/messages/search', requireAuth, async (req, res) => {
    try {
      const currentUserId = req.user!.userId;
      if (restLimit(`search:${currentUserId}`, 60, 60_000)) {
        return res.status(429).json({ error: 'Too many search requests. Please try again shortly.' });
      }
      const { chatId } = req.params;
      const q = String(req.query.q || '').trim();
      const limit = Math.min(parseInt(req.query.limit as string, 10) || 30, 100);
      if (!q) return res.status(400).json({ error: 'Search query (q) is required.' });
      if (q.length > 100) return res.status(400).json({ error: 'Search query too long (max 100 characters).' });

      // Membership check (same auto-provisioning fallback as the messages GET route)
      let members = await db.getChatMembers(chatId);
      if (members.length === 0 && chatId.startsWith('one_to_one_')) {
        const parts = chatId.replace('one_to_one_', '').split('___');
        if (parts.length === 2) {
          const [u1, u2] = parts;
          if (currentUserId === u1 || currentUserId === u2) {
            await db.createChat('one-to-one', '', [u1, u2], chatId);
            members = await db.getChatMembers(chatId);
          }
        }
      }
      if (!members.some(m => m.userId === currentUserId)) {
        return res.status(403).json({ error: 'Access Denied: You are not a member of this chat.' });
      }

      const results = await db.searchMessagesInChat(chatId, currentUserId, q, limit);
      // Privacy: never leak deletedFor arrays over the wire
      const cleaned = results.map((m: any) => {
        const { deletedFor, deleted_for, ...rest } = m;
        return rest;
      });
      res.status(200).json({ messages: cleaned });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 10d. Global message search across every chat the caller is a member of
  //      (membership enforced in SQL via the chat_members JOIN).
  app.get('/api/search/messages', requireAuth, async (req, res) => {
    try {
      const currentUserId = req.user!.userId;
      if (restLimit(`search:${currentUserId}`, 60, 60_000)) {
        return res.status(429).json({ error: 'Too many search requests. Please try again shortly.' });
      }
      const q = String(req.query.q || '').trim();
      const limit = Math.min(parseInt(req.query.limit as string, 10) || 40, 100);
      if (!q) return res.status(400).json({ error: 'Search query (q) is required.' });
      if (q.length > 100) return res.status(400).json({ error: 'Search query too long (max 100 characters).' });

      const results = await db.searchMessagesGlobal(currentUserId, q, limit);
      const cleaned = results.map((m: any) => {
        const { deletedFor, deleted_for, ...rest } = m;
        return rest;
      });
      res.status(200).json({ messages: cleaned });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 10e. Chat media gallery feed (images grid / files list), attachments JOIN messages.
  app.get('/api/chats/:chatId/media', requireAuth, async (req, res) => {
    try {
      const currentUserId = req.user!.userId;
      if (restLimit(`search:${currentUserId}`, 60, 60_000)) {
        return res.status(429).json({ error: 'Too many requests. Please try again shortly.' });
      }
      const { chatId } = req.params;
      const type = String(req.query.type || 'image') === 'file' ? 'file' : 'image';
      const limit = Math.min(parseInt(req.query.limit as string, 10) || 200, 500);

      // Membership check (same auto-provisioning fallback as the messages GET route)
      let members = await db.getChatMembers(chatId);
      if (members.length === 0 && chatId.startsWith('one_to_one_')) {
        const parts = chatId.replace('one_to_one_', '').split('___');
        if (parts.length === 2) {
          const [u1, u2] = parts;
          if (currentUserId === u1 || currentUserId === u2) {
            await db.createChat('one-to-one', '', [u1, u2], chatId);
            members = await db.getChatMembers(chatId);
          }
        }
      }
      if (!members.some(m => m.userId === currentUserId)) {
        return res.status(403).json({ error: 'Access Denied: You are not a member of this chat.' });
      }

      const items = await db.getChatMedia(chatId, currentUserId, type, limit);
      res.status(200).json({ media: items });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 10b. Messages: Sync historical or updated message state from Firestore (Migration Bridge)
  app.post('/api/chats/:chatId/messages/sync', requireAuth, async (req, res) => {
    try {
      const { chatId } = req.params;
      const { id, senderId, content, type = 'text', attachments = [], replyTo = null, reactions = {}, createdAt } = req.body;

      const serialized = JSON.stringify(req.body);
      const payloadSizeBytes = serialized.length;
      const requesterIp = req.ip || req.headers['x-forwarded-for'] || 'unknown';
      const userAgent = req.headers['user-agent'] || 'unknown';

      console.log(`[Sync] Fallback handler invoked - Post sync for chat: ${chatId}`);





      if (!id || !senderId) {
        console.warn(`[Sync] Rejected: Missing id or senderId on message: ${id}`);
        return res.status(400).json({ error: 'Missing mandatory message properties.' });
      }

      // F4 hardening: never trust arbitrary client-supplied ids. The sync bridge
      // deduplicates and mutates rows BY this id, so a malformed/colliding id
      // could poison unrelated rows. The id MUST match the server's
      // client_message_id format (UUID — the same format every client generates
      // via crypto.randomUUID()); anything else is rejected, never persisted.
      const SYNC_UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
      if (typeof id !== 'string' || !SYNC_UUID_RE.test(id)) {
        console.warn(`[Sync] Rejected: malformed message id format from user ${req.user!.userId} in chat ${chatId}`);
        return res.status(400).json({ error: 'معرّف الرسالة غير صالح (مطلوب UUID).' });
      }
      // F4 hardening: createdAt is honored only when it parses as a real date —
      // a malformed value must not poison the created_at column (server clock
      // would win, but the explicit 400 keeps the migration contract honest).
      let createdAtIso: string | undefined;
      if (createdAt !== undefined && createdAt !== null) {
        const parsedCreatedAt = new Date(String(createdAt));
        if (isNaN(parsedCreatedAt.getTime())) {
          return res.status(400).json({ error: 'تاريخ إنشاء الرسالة غير صالح (مطلوب تاريخ ISO 8601).' });
        }
        createdAtIso = parsedCreatedAt.toISOString();
      }

      // Validate user membership with dynamic auto-provisioning fallback for direct 1-to-1 rooms
      let members = await db.getChatMembers(chatId);
      if (members.length === 0 && chatId.startsWith('one_to_one_')) {
        const parts = chatId.replace('one_to_one_', '').split('___');
        if (parts.length === 2) {
          const [u1, u2] = parts;
          if (req.user!.userId === u1 || req.user!.userId === u2) {

            await db.createChat('one-to-one', '', [u1, u2], chatId);
            members = await db.getChatMembers(chatId);
          }
        }
      }

      const currentUserId = req.user!.userId;
      if (!members.some(m => m.userId === currentUserId)) {
        console.warn(`[API] Sync Auth Denied: User ${currentUserId} is not in member index of room ${chatId}. Registered members:`, members.map(m => m.userId));
        return res.status(403).json({ error: 'Access Denied: You are not a registered member of this chat conversation.' });
      }

      // Sender forgery protection: a client may only sync messages authored by itself.
      // Trusting body.senderId here would let any chat member publish messages under another identity.
      if (senderId !== currentUserId) {
        console.warn(`[Security Alert] Message sync forgery blocked: user ${currentUserId} attempted to write as ${senderId} in chat ${chatId}.`);
        return res.status(403).json({ error: 'Access Denied: senderId must match the authenticated user.' });
      }

      // F4 hardening: enforce the SAME unified send gate as the WS msg:send and
      // REST send paths (mute/ban/membership/whoCanSend/slow-mode/restrictions/
      // blocks/DM policy) BEFORE any persistence — the bridge previously bypassed
      // all of it. SendBlockedError gets the same 403 mute/blocked semantics.
      try {
        await assertCanSendMessage(db, currentUserId, chatId, { attachments });
      } catch (e: any) {
        if (e instanceof SendBlockedError) {
          return res.status(403).json({ error: e.reason });
        }
        throw e;
      }

      // BATCH-3 (DIR-AB-01 + AB-07): the sync bridge now enforces the SAME
      // attachment host allowlist and the SAME content bounds as WS/REST —
      // it was the last ingress persisting arbitrary-URL attachments and
      // unbounded text.
      if (typeof content === 'string' && content.length > 8000) {
        return res.status(400).json({ error: 'الرسالة طويلة جداً (الحد 8000 حرف).' });
      }
      const SYNC_ALLOWED_TYPES = new Set(['text', 'attachment', 'image', 'video', 'audio', 'file', 'poll', 'location', 'contact']);
      if (typeof type !== 'string' || !SYNC_ALLOWED_TYPES.has(type)) {
        return res.status(400).json({ error: 'نوع رسالة غير مسموح عبر المزامنة.', code: 'SYNC_TYPE_REJECTED' });
      }
      try {
        await assertAttachmentUrlsAllowed(req, req.body, currentUserId);
      } catch (e: any) {
        if (e?.message === 'ATTACHMENT_URL_BLOCKED') {
          return res.status(400).json({ error: 'رابط المرفق غير مسموح.' });
        }
        throw e;
      }

    // Membership-epoch gate (external-audit E2EE-01/E2EE-02): group sends
    // must declare the membership_version they were composed under. Stale or
    // future versions return 409 MEMBERSHIP_STALE with the current version so
    // the client rotates sender keys and retries once. Mirrors the WS gate.
    try {
      await assertMembershipFresh(db, chatId, (req.body || {}).mv);
    } catch (e: any) {
      if (e instanceof MembershipStaleError) {
        return res.status(409).json({ error: e.reason, code: 'MEMBERSHIP_STALE', expectedVersion: (e as any).expectedVersion });
      }
      throw e;
    }
    // E2EE ingress policy (external-audit E2EE-03/P0-B): eligible-chat content
    // must ALREADY be a wire envelope. Mirrors the WS gate.
    try {
      await assertEncryptedIngress(db, chatId, req.body?.content);
    } catch (e: any) {
      if (e instanceof E2eeRequiredError) {
        return res.status(400).json({ error: e.reason, code: 'E2EE_REQUIRED' });
      }
      if (e instanceof E2eePolicyUnavailableError) {
        return res.status(503).json({ error: e.reason, code: 'E2EE_POLICY_UNAVAILABLE' });
      }
      throw e;
    }



      // If message is already stored locally, update any mutable attributes (like reactions, content, attachments, replyTo)
      const existing = await db.getMessageById(id);
      if (existing) {
        // Ownership check: members must not rewrite each other's messages through the sync bridge
        if (existing.senderId !== currentUserId) {
          return res.status(403).json({ error: 'Access Denied: cannot mutate a message authored by another user.' });
        }
        // BATCH-3 (DIR-AB-03): tombstones are terminal — a deleted message can
        // never be resurrected through the sync bridge (or cache/mirror).
        if (existing.deletedAt) {
          return res.status(409).json({ error: 'الرسالة محذوفة — لا يمكن تعديلها.', code: 'MESSAGE_TOMBSTONED' });
        }
        // Deep compare reactions, content, and attachments to prevent redundant I/O writes
        const hasContentChange = existing.content !== content;
        const hasTypeChange = existing.type !== type;
        const hasAttachmentsChange = JSON.stringify(existing.attachments) !== JSON.stringify(attachments);
        const hasReactionsChange = JSON.stringify(existing.reactions) !== JSON.stringify(reactions);
        const hasReplyToChange = JSON.stringify(existing.replyTo) !== JSON.stringify(replyTo);

        const hasChanges = hasContentChange || hasTypeChange || hasAttachmentsChange || hasReactionsChange || hasReplyToChange;

        if (hasChanges) {

          const updated = await db.updateMessage(id, {
            content: content || '',
            type: (type as any) || 'text',
            attachments: attachments || [],
            replyTo: replyTo || null,
            reactions: reactions || {},
          });
          return res.status(200).json({ success: true, message: updated, alreadyExisted: true, updated: true });
        } else {

          return res.status(200).json({ success: true, message: existing, alreadyExisted: true, updated: false });
        }
      }


      // Create a fresh message record in our relational SQL database with exact parameters
      const message = await db.createMessage(
        chatId,
        senderId,
        content || '',
        (type as any),
        attachments,
        replyTo,
        reactions,
        id,
        createdAtIso
      );

      res.status(201).json({ success: true, message, updated: true });
    } catch (err: any) {
      console.error(`[Sync] Error in message sync handler:`, err.message);
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Send or forward message via HTTP
  app.post('/api/chats/:chatId/messages', requireAuth, async (req, res) => {
    try {
      const { chatId } = req.params;
      const { content, type = 'text', attachments = [], replyTo = null, poll = null, scheduleAt } = req.body;
      const currentUserId = req.user!.userId;

      // Scheduled send (v5): validate scheduleAt BEFORE any persistence —
      // ISO 8601, 1 minute..1 year in the future; absent = immediate send.
      const schedule = parseScheduleAt(scheduleAt);
      if (schedule.error) {
        return res.status(400).json({ error: schedule.error });
      }

      // Poll pass-through (WhatsApp parity): reject malformed poll payloads
      // early; valid polls persist via createMessage (explicit arg or the
      // structured application/x-dirasha-poll attachment inside `attachments`).
      let pollData: any = null;
      if (poll) {
        pollData = normalizePollPayload(poll);
        if (!pollData) {
          return res.status(400).json({ error: 'بيانات التصويت غير صالحة (السؤال 1-200 حرفاً، الخيارات 2-10 بحد 100 حرف).' });
        }
      }

      // P0-hardening: bound text payload size (mirrors the WS guard).
      if (typeof content === 'string' && content.length > 8000) {
        return res.status(400).json({ error: 'الرسالة طويلة جداً (الحد 8000 حرف).' });
      }

      // P0-hardening: attachment URL allowlist — same-origin, managed fallback
      // bucket, or the sender's linked storage base only (rejects data: et al).
      try {
        await assertAttachmentUrlsAllowed(req, req.body, currentUserId);
      } catch (e: any) {
        if (e?.message === 'ATTACHMENT_URL_BLOCKED') {
          return res.status(400).json({ error: 'رابط المرفق غير مسموح.' });
        }
        throw e;
      }

      // Validate user membership with dynamic auto-provisioning fallback for direct 1-to-1 rooms
      // (kept BEFORE the gate so auto-provisioned rooms can pass the membership check inside it)
      let members = await db.getChatMembers(chatId);
      if (members.length === 0 && chatId.startsWith('one_to_one_')) {
        const parts = chatId.replace('one_to_one_', '').split('___');
        if (parts.length === 2) {
          const [u1, u2] = parts;
          if (currentUserId === u1 || currentUserId === u2) {
            await db.createChat('one-to-one', '', [u1, u2], chatId);
            members = await db.getChatMembers(chatId);
          }
        }
      }

      // Unified send gate — mute/ban/membership/whoCanSend/slow-mode/restrictions/
      // blocks/DM policy, identical policy to the WebSocket msg:send path.
      try {
        await assertCanSendMessage(db, currentUserId, chatId, { attachments });
      } catch (e: any) {
        if (e instanceof SendBlockedError) {
          return res.status(403).json({ error: e.reason });
        }
        throw e;
      }
    // Membership-epoch gate (external-audit E2EE-01/E2EE-02): group sends
    // must declare the membership_version they were composed under. Stale or
    // future versions return 409 MEMBERSHIP_STALE with the current version so
    // the client rotates sender keys and retries once. Mirrors the WS gate.
    try {
      await assertMembershipFresh(db, chatId, (req.body || {}).mv);
    } catch (e: any) {
      if (e instanceof MembershipStaleError) {
        return res.status(409).json({ error: e.reason, code: 'MEMBERSHIP_STALE', expectedVersion: (e as any).expectedVersion });
      }
      throw e;
    }
    // E2EE ingress policy (external-audit E2EE-03/P0-B): eligible-chat content
    // must ALREADY be a wire envelope. Mirrors the WS gate.
    try {
      await assertEncryptedIngress(db, chatId, req.body?.content);
    } catch (e: any) {
      if (e instanceof E2eeRequiredError) {
        return res.status(400).json({ error: e.reason, code: 'E2EE_REQUIRED' });
      }
      if (e instanceof E2eePolicyUnavailableError) {
        return res.status(503).json({ error: e.reason, code: 'E2EE_POLICY_UNAVAILABLE' });
      }
      throw e;
    }



      const id = crypto.randomUUID();
      const nowIso = new Date().toISOString();

      const message = await db.createMessage(
        chatId,
        currentUserId,
        content || '',
        type || 'text',
        attachments || [],
        replyTo || null,
        {}, // reactions initial
        id,
        nowIso,
        undefined, // clientMessageId
        undefined, // expiresAt
        pollData,
        schedule.date // 13th arg: null = immediate, Date = scheduled (no fan-out here)
      );

      // Scheduled send: persist ONLY — no live fan-out. The 5-minute
      // deliverScheduledMessages sweep broadcasts msg:new (chat room +
      // per-member user channels, identical payload shape) when due.
      if (schedule.date) {
        // BATCH-6 (ADV-03): persist the membership epoch the message was
        // composed under — the delivery sweep fail-closes on a stale epoch.
        try {
          const composeMv = (req.body || {}).mv;
          if (composeMv != null) {
            await pool.query('UPDATE messages SET compose_mv = $1 WHERE id = $2', [Number(composeMv) || null, message.id]);
          }
        } catch { /* epoch marking is best-effort; sweep treats NULL as legacy */ }
        return res.status(201).json({
          success: true,
          message,
          scheduled: true,
          scheduledAt: message.scheduledAt
        });
      }

      const senderObj = await db.getUserById(currentUserId);
      const msgNewPayload = {
        ...message,
        state: 'sent',
        sender: senderObj ? {
          id: senderObj.id,
          username: senderObj.username,
          displayName: senderObj.displayName,
          avatarUrl: senderObj.avatarUrl,
          onlineStatus: senderObj.onlineStatus
          // BATCH-6 (ADV-03): lastSeen never rides msg:new fan-out (AB-09 parity)
        } : undefined
      };

      // Publish to Redis targets in parallel so all websockets (sender and others) update real-time
      const pubPromises = [
        redisCluster.publish(`chat:${chatId}`, {
          event: 'msg:new',
          payload: msgNewPayload
        })
      ];

      for (const memb of members) {
        pubPromises.push(
          redisCluster.publish(`user:updates:${memb.userId}`, {
            event: 'msg:new',
            payload: msgNewPayload
          })
        );
      }
      await Promise.all(pubPromises);

      res.status(201).json({ success: true, message: msgNewPayload });
    } catch (err: any) {
      console.error('[REST Message Send] Exception:', err);
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 10c. Message Mutation & Synchronization Routes

  // Edit message
  // 7. Messages: Core operations
  app.post('/api/messages', requireAuth, async (req, res) => {
    try {
    const { chatId, content, type, attachments, expiresAt, poll = null, scheduleAt } = req.body;
    const senderId = req.user!.userId;

    // Scheduled send (v5): same scheduleAt contract as the chat-scoped route —
    // ISO 8601, 1 minute..1 year in the future; absent = immediate send.
    const schedule = parseScheduleAt(scheduleAt);
    if (schedule.error) {
      return res.status(400).json({ error: schedule.error });
    }

    // Poll pass-through (WhatsApp parity) — same validation as the chat route.
      let pollData: any = null;
      if (poll) {
        pollData = normalizePollPayload(poll);
        if (!pollData) {
          return res.status(400).json({ error: 'بيانات التصويت غير صالحة (السؤال 1-200 حرفاً، الخيارات 2-10 بحد 100 حرف).' });
        }
      }

      if (!chatId) {
        return res.status(400).json({ error: 'chatId is required.' });
      }

      // P0-hardening: bound text payload size (mirrors the WS guard).
      if (typeof content === 'string' && content.length > 8000) {
        return res.status(400).json({ error: 'الرسالة طويلة جداً (الحد 8000 حرف).' });
      }

      // P0-hardening: attachment URL allowlist — same-origin, managed fallback
      // bucket, or the sender's linked storage base only (rejects data: et al).
      try {
        await assertAttachmentUrlsAllowed(req, req.body, senderId);
      } catch (e: any) {
        if (e?.message === 'ATTACHMENT_URL_BLOCKED') {
          return res.status(400).json({ error: 'رابط المرفق غير مسموح.' });
        }
        throw e;
      }

      // Unified send gate — mute/ban/membership/whoCanSend/slow-mode/restrictions/
      // blocks/DM policy, identical policy to the WebSocket msg:send path.
      try {
        await assertCanSendMessage(db, senderId, chatId, { attachments });
      } catch (e: any) {
        if (e instanceof SendBlockedError) {
          return res.status(403).json({ error: e.reason });
        }
        throw e;
      }
    // Membership-epoch gate (external-audit E2EE-01/E2EE-02): group sends
    // must declare the membership_version they were composed under. Stale or
    // future versions return 409 MEMBERSHIP_STALE with the current version so
    // the client rotates sender keys and retries once. Mirrors the WS gate.
    try {
      await assertMembershipFresh(db, chatId, (req.body || {}).mv);
    } catch (e: any) {
      if (e instanceof MembershipStaleError) {
        return res.status(409).json({ error: e.reason, code: 'MEMBERSHIP_STALE', expectedVersion: (e as any).expectedVersion });
      }
      throw e;
    }
    // E2EE ingress policy (external-audit E2EE-03/P0-B): eligible-chat content
    // must ALREADY be a wire envelope. Mirrors the WS gate.
    try {
      await assertEncryptedIngress(db, chatId, req.body?.content);
    } catch (e: any) {
      if (e instanceof E2eeRequiredError) {
        return res.status(400).json({ error: e.reason, code: 'E2EE_REQUIRED' });
      }
      if (e instanceof E2eePolicyUnavailableError) {
        return res.status(503).json({ error: e.reason, code: 'E2EE_POLICY_UNAVAILABLE' });
      }
      throw e;
    }



      // Use the robust core createMessage method from the DB engine
      // it handles chat.updated_at, receipts, enrichment, and attachments in one transaction
      const message = await db.createMessage(
        chatId,
        senderId,
        content || '',
        type === 'image' || type === 'attachment' ? 'attachment' : 'text',
        attachments || [],
        null, // replyTo
        {},   // reactions
        undefined, // customId
        undefined, // createdAt
      undefined, // clientMessageId
      expiresAt,
      pollData,
      schedule.date // 13th arg: null = immediate, Date = scheduled (no fan-out here)
    );

      // Scheduled send: persist ONLY — the deliverScheduledMessages sweep
      // broadcasts msg:new when due. Skip the immediate fan-out entirely.
      if (schedule.date) {
        // BATCH-6 (ADV-03): persist the membership epoch the message was
        // composed under — the delivery sweep fail-closes on a stale epoch.
        try {
          const composeMv = (req.body || {}).mv;
          if (composeMv != null) {
            await pool.query('UPDATE messages SET compose_mv = $1 WHERE id = $2', [Number(composeMv) || null, message.id]);
          }
        } catch { /* epoch marking is best-effort; sweep treats NULL as legacy */ }
        return res.status(201).json({
          success: true,
          message,
          scheduled: true,
          scheduledAt: message.scheduledAt
        });
      }

      // Real-time broadcast — MUST match the client's event name (msg:new);
      // 'message:new' was a silent mismatch: REST-sent messages never arrived live.
      await redisCluster.publish(`chat:${chatId}`, {
        event: 'msg:new',
        payload: message
      });

      res.status(201).json({ message });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.put('/api/messages/:messageId', requireAuth, async (req, res) => {
    try {
      const { messageId } = req.params;
      const { content } = req.body;
      const userId = req.user!.userId;

      const message = await db.getMessageById(messageId);
      if (!message) {
        return res.status(404).json({ error: 'Message not found' });
      }

      if (message.senderId !== userId) {
        return res.status(403).json({ error: 'Only the sender can edit this message' });
      }

      // BATCH-3 (DIR-AB-03): tombstones are terminal — deleted-for-everyone
      // messages can no longer be overwritten (content resurrection closed).
      if (message.deletedAt) {
        return res.status(409).json({ error: 'الرسالة محذوفة للجميع — لا يمكن تعديلها.', code: 'MESSAGE_TOMBSTONED' });
      }

      // GROUP-02 (external audit): the editor must STILL be a member of the
      // chat — a former member must not be able to rewrite history.
      const editMembersNow = await db.getChatMembers(message.chatId);
      if (!editMembersNow.some((m: any) => m.userId === userId)) {
        return res.status(403).json({ error: 'لا يمكنك تعديل رسالة في محادثة لم تعد عضواً فيها.' });
      }

      // E2EE-03/P0-B (external audit): edited content for an E2EE-eligible chat
      // must ALREADY be a wire envelope — no plaintext edit substitutions.
      try {
        await assertEncryptedIngress(db, message.chatId, content);
      } catch (e: any) {
        if (e instanceof E2eeRequiredError) {
          return res.status(400).json({ error: e.reason, code: 'E2EE_REQUIRED' });
        }
        throw e;
      }

      const updated = await db.updateMessage(messageId, {
        content,
        editedAt: new Date().toISOString()
      });

      if (!updated) {
        return res.status(500).json({ error: 'Failed to update message' });
      }

      // Publish to cluster
      const editEvent = {
        event: 'msg:edit',
        payload: {
          chatId: message.chatId,
          messageId,
          senderId: userId,
          content,
          editedAt: updated.editedAt
        }
      };
      await redisCluster.publish(`chat:${message.chatId}`, editEvent);

      // ALSO broadcast edit to all chat members' private channels so views update instantly
      const editMembers = await db.getChatMembers(message.chatId);
      for (const memb of editMembers) {
        await redisCluster.publish(`user:updates:${memb.userId}`, editEvent);
      }

      res.status(200).json({ success: true, message: updated });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Delete message for everyone
  app.post('/api/messages/:messageId/delete-everyone', requireAuth, async (req, res) => {
    try {
      const { messageId } = req.params;
      const userId = req.user!.userId;
      const { reason } = req.body || {};

      const message = await db.getMessageById(messageId);
      if (!message) {
        return res.status(404).json({ error: 'Message not found' });
      }

      // Check permissions: either the sender of the message OR admin/developer can delete
      const userRecord = await db.getUserById(userId);
      const isModerator = userRecord && (userRecord.role === 'admin' || userRecord.role === 'developer');

      if (message.senderId !== userId && !isModerator) {
        // Telegram parity: group admins WITH the deleteMessages right may delete
        // other members' messages in group chats.
        const chatInfo = db.getChatInfo(message.chatId);
        if (chatInfo?.type === 'group' && db.getChatRole(message.chatId, userId) && db.adminCan(message.chatId, userId, 'deleteMessages')) {
          // allowed via granular group admin right
        } else {
          return res.status(403).json({ error: 'Only the sender or administrative monitors can delete this message.' });
        }
      }

      // 1. Core Deleted Messages Vault copy before overwrite
      await db.saveDeletedMessage({
        messageId: message.id,
        chatId: message.chatId,
        senderId: message.senderId,
        originalContent: message.content,
        messageType: message.type,
        attachmentsMetadata: JSON.stringify(message.attachments || []),
        originalCreatedAt: message.createdAt,
        deletedBy: userId,
        deleteReason: reason || (isModerator ? 'Deleted by Administration moderator' : 'Deleted by sender via Delete for Everyone')
      });

      // 1b. F12: best-effort Drive blob deletion with the OWNER credentials.
      // The vault copy above preserves the audit trail; blobs are removed
      // from the third party (audit finding: files never deleted).
      try {
        const gdriveIds = extractGdriveFileIds(message.attachments || []);
        if (gdriveIds.length > 0) {
          void (async () => {
            for (const fid of gdriveIds) {
              const r = await deleteDriveFileByOwner(message.senderId, fid);
              console.log('[F12] drive delete', fid, r.ok ? 'ok' : ('failed: '+r.reason));
            }
          })().catch(() => {});
        }
      } catch { /* best-effort */ }

      // 2. Log in general Moderation Audit system
      await db.logModerationAction(
        'MESSAGE_DELETED_EVERYONE',
        userId,
        message.senderId,
        message.id,
        {
          chatId: message.chatId,
          deletedByRole: userRecord?.role || 'user',
          reason: reason || 'Delete for everyone'
        }
      );

      // Proceed with update
      const updated = await db.updateMessage(messageId, {
        content: 'ًںڑ« طھظ… ط­ط°ظپ ظ‡ط°ظ‡ ط§ظ„ط±ط³ط§ظ„ط© ظ„ط¯ظ‰ ط§ظ„ط¬ظ…ظٹط¹',
        deletedAt: new Date().toISOString()
      });

      const deleteEvent = {
        event: 'msg:delete:everyone',
        payload: {
          chatId: message.chatId,
          messageId,
          deletedAt: updated?.deletedAt
        }
      };
      await redisCluster.publish(`chat:${message.chatId}`, deleteEvent);

      // ALSO broadcast deletion to all chat members' private channels
      const deleteMembers = await db.getChatMembers(message.chatId);
      for (const memb of deleteMembers) {
        await redisCluster.publish(`user:updates:${memb.userId}`, deleteEvent);
      }

      res.status(200).json({ success: true, message: updated });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Delete message for me
  app.post('/api/messages/:messageId/delete-me', requireAuth, async (req, res) => {
    try {
      const { messageId } = req.params;
      const userId = req.user!.userId;

      const message = await db.getMessageById(messageId);
      if (!message) {
        return res.status(404).json({ error: 'Message not found' });
      }

      // Membership guard: hide-for-self still touches stored message metadata
      const deleteAllowedMembers = await db.getChatMembers(message.chatId);
      if (!deleteAllowedMembers.some(m => m.userId === userId)) {
        return res.status(403).json({ error: 'Access Denied: You are not a registered member of this chat.' });
      }

      const deletedFor = message.deletedFor || [];
      if (!deletedFor.includes(userId)) {
        deletedFor.push(userId);
        await db.updateMessage(messageId, { deletedFor });
      }

      // Notify other active sessions of the user to hide it
      await redisCluster.publish(`user:updates:${userId}`, {
        event: 'msg:delete:me',
        payload: {
          chatId: message.chatId,
          messageId
        }
      });

      res.status(200).json({ success: true });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Admin and moderator access routing check — durable role ONLY (BATCH-1)
  async function requireModerator(req: Request, res: Response, next: NextFunction) {
    requireAuth(req, res, async () => {
      try {
        const u = await db.getUserById(req.user!.userId);
        // BATCH-1 (DIR-2026-001): operator identity = durable role ONLY
        // (same roles the username path used to allow — no expansion, no
        // username matching, NO promotion side effect on read).
        const isOperator = !!u && (
          u.role === 'admin' ||
          u.role === 'developer'
        );

        if (isOperator) {
          next();
        } else {
          console.warn(`[Security Alert] Unauthorized administrative API access attempt by user: ${req.user?.username || u?.username || 'none'}`);
          res.status(403).json({ error: '403 Forbidden: Insufficient administrative privileges.' });
        }
      } catch (err: any) {
        console.error('[Moderation] privilege check failure:', err);
        res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
      }
    });
  }

  // Moderation reports routing

  // 1. Create Report (Accessible to public users)
  app.post('/api/moderation/reports', requireAuth, async (req, res) => {
    try {
      const reporterId = req.user!.userId;

      // P0-hardening: report flood throttle — 5/hour per user (on top of the
      // existing Redis-backed abuse ban below).
      if (restLimit(`moderation:report:${reporterId}`, 5, 60 * 60 * 1000)) {
        return res.status(429).json({ error: 'عدد كبير من المحاولات، حاول لاحقاً.' });
      }

      const { targetUserId, targetMessageId, category, description, targetType = 'User' } = req.body || {};

      // Body validations
      if (!targetUserId || !category) {
        return res.status(400).json({ error: 'Missing required parameters: targetUserId and category are required.' });
      }

      const validCategories = ['Spam', 'Harassment', 'Hate Speech', 'Violence', 'Inappropriate Content', 'Impersonation', 'Other'];
      if (!validCategories.includes(category)) {
        return res.status(400).json({ error: `Invalid category. Must be one of: ${validCategories.join(', ')}` });
      }

      if (description && description.length > 500) {
        return res.status(400).json({ error: 'Description exceeds maximum allowed length of 500 characters.' });
      }

      // Check rate limit (Abuse Protection)
      const isBanned = await redisCluster.getTemp(`ban:report:${reporterId}`);
      if (isBanned) {
        return res.status(429).json({ 
          error: 'طھظ… ط­ط¸ط±ظƒ ظ…ط¤ظ‚طھط§ظ‹ ظ…ظ† طھظ‚ط¯ظٹظ… ط§ظ„ط¨ظ„ط§ط؛ط§طھ ظ„ظ…ط¯ط© ط³ط§ط¹ط© ط¨ط³ط¨ط¨ ظپط±ط· ط§ظ„ط§ط³طھط®ط¯ط§ظ… ظˆط¥ط±ط³ط§ظ„ ط¨ظ„ط§ط؛ط§طھ ظ…ظƒط±ط±ط©.' 
        });
      }

      const recentCount = await db.getReporterRecentCount(reporterId, 10);
      if (recentCount >= 10) {
        // Apply temporary banned state in Redis for 1 hour (3600s)
        await redisCluster.setTemp(`ban:report:${reporterId}`, 'active', 3600);

        // Log abuse attempt to Audit Log
        await db.logModerationAction(
          'USER_REPORTING_RATE_LIMITED',
          reporterId,
          reporterId,
          null,
          {
            recentCount,
            reason: 'Exceeded rate limit of 10 reports within 10 minutes.'
          }
        );

        return res.status(429).json({ 
          error: 'طھط¬ط§ظˆط²طھ ط§ظ„ط­ط¯ ط§ظ„ظ…ط³ظ…ظˆط­ ط¨ظ‡ ظ„طھظ‚ط¯ظٹظ… ط§ظ„ط¨ظ„ط§ط؛ط§طھ (10 ط¨ظ„ط§ط؛ط§طھ ظپظٹ 10 ط¯ظ‚ط§ط¦ظ‚). طھظ… ط­ط¸ط± طھظ‚ط¯ظٹظ… ط§ظ„ط¨ظ„ط§ط؛ط§طھ ظ„ط­ط³ط§ط¨ظƒ ظ…ط¤ظ‚طھط§ظ‹ ظ„ظ…ط¯ط© ط³ط§ط¹ط©.' 
        });
      }

      // Target verification (user must exist)
      const targetUser = await db.getUserById(targetUserId);
      if (!targetUser) {
        return res.status(404).json({ error: 'Target user not found.' });
      }

      // Message verification (if supplied)
      if (targetMessageId) {
        const msg = await db.getMessageById(targetMessageId);
        if (!msg) {
          return res.status(404).json({ error: 'Target message not found.' });
        }
      }

      // Generate report id
      const reportId = crypto.randomUUID();

      const newReport = await db.createReport({
        reportId,
        reporterId,
        targetUserId,
        targetMessageId,
        category,
        description,
        status: 'Pending',
        targetType
      });

      // Broadcast to live admins for immediate UI update
      DashboardStatsCollector.broadcastNewReport(newReport);

      // Log report creation event in Audit Logs
      await db.logModerationAction(
        'REPORT_CREATED',
        reporterId,
        targetUserId,
        reportId,
        {
          category,
          targetMessageId
        }
      );

      // Real-time Notification Event over Redis to admins and developers
      try {
        const allUsers = await db.getUsers();
        const moderators = allUsers.filter(u => u.role === 'admin' || u.role === 'developer');

        const reportNotification = {
          event: 'moderation:report:new',
          payload: {
            reportId,
            reporterId,
            targetUserId,
            targetMessageId,
            category,
            description,
            status: 'Pending',
            createdAt: new Date().toISOString()
          }
        };

        for (const mod of moderators) {
          await redisCluster.publish(`user:updates:${mod.id}`, reportNotification);
        }
      } catch (wsErr: any) {
        console.error('[Websocket Notification] Failed broadcasting report notification:', wsErr.message);
      }

      res.status(201).json({ success: true, report: newReport });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 2. Get single report details (Moderators only)
  app.get('/api/moderation/reports/:reportId', requireModerator, async (req, res) => {
    try {
      const { reportId } = req.params;
      const report = await db.getReportById(reportId);
      if (!report) {
         return res.status(404).json({ error: 'Report not found' });
      }
      res.status(200).json({ success: true, report });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 3. Get lists of reports (Moderators only with pagination and filters)
  app.get('/api/moderation/reports', requireModerator, async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string || '50', 10);
      const offset = parseInt(req.query.offset as string || '0', 10);
      const category = req.query.category as string || undefined;
      const status = req.query.status as string || undefined;

      const reportsList = await db.getReports(limit, offset, category, status);
      res.status(200).json({ success: true, reports: reportsList });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 4. Update status of a report (Moderators only)
  app.post('/api/moderation/reports/:reportId/status', requireModerator, async (req, res) => {
    try {
      const { reportId } = req.params;
      const { status } = req.body || {};
      const actorUserId = req.user!.userId;

      const validStatuses = ['Pending', 'Under Review', 'Resolved', 'Rejected'];
      if (!status || !validStatuses.includes(status)) {
        return res.status(400).json({ error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` });
      }

      const report = await db.getReportById(reportId);
      if (!report) {
        return res.status(404).json({ error: 'Report not found' });
      }

      const success = await db.updateReportStatus(reportId, status);
      if (!success) {
        return res.status(500).json({ error: 'Failed updating report status record.' });
      }

      // Log event in audit logs
      await db.logModerationAction(
        'REPORT_STATUS_UPDATED',
        actorUserId,
        report.targetUserId,
        reportId,
        {
          oldStatus: report.status,
          newStatus: status
        }
      );

      // Notify the reporter if needed (optional)
      await redisCluster.publish(`user:updates:${report.reporterId}`, {
        event: 'moderation:report:update',
        payload: { reportId, status }
      });

      res.status(200).json({ success: true, status });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Enforcement logs routing
  app.get('/api/moderation/users/:userId/enforcement', requireModerator, async (req, res) => {
    try {
      const { userId } = req.params;
      const history = await db.getEnforcementHistory(userId);
      res.json(history);
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.get('/api/moderation/users/:userId/reports', requireModerator, async (req, res) => {
    try {
      const { userId } = req.params;
      const reports = await db.getReportsForUser(userId);
      res.json(reports);
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Staff notes routing
  app.get('/api/moderation/users/:userId/notes', requireModerator, async (req, res) => {
    try {
      const { userId } = req.params;
      const notes = await db.getUserNotes(userId);
      res.json(notes);
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.post('/api/moderation/users/:userId/notes', requireModerator, async (req, res) => {
    try {
      const { userId } = req.params;
      const { content } = req.body;
      const authorId = req.user!.userId;
      if (!content) return res.status(400).json({ error: 'Note content is required.' });

      const id = await db.addUserNote(userId, authorId, content);
      res.json({ success: true, id });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // User warnings routing
  app.get('/api/moderation/users/:userId/warnings', requireModerator, async (req, res) => {
    try {
      const { userId } = req.params;
      const warnings = await db.getUserWarnings(userId);
      res.json(warnings);
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.post('/api/moderation/users/:userId/warnings', requireModerator, async (req, res) => {
    try {
      const { userId } = req.params;
      const { reason, severity = 1 } = req.body;
      const moderatorId = req.user!.userId;
      if (!reason) return res.status(400).json({ error: 'Warning reason is required.' });

      const id = await db.addWarning(userId, moderatorId, reason, severity);
      
      await db.logModerationAction(
        'USER_WARNED',
        moderatorId,
        userId,
        reason,
        { severity }
      );

      // Notify user via WebSocket
      await redisCluster.publish(`user:updates:${userId}`, {
        event: 'user:warning',
        payload: { reason, severity, timestamp: new Date().toISOString() }
      });

      res.json({ success: true, id });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.delete('/api/moderation/users/:userId/warnings', requireModerator, async (req, res) => {
    try {
      const { userId } = req.params;
      const moderatorId = req.user!.userId;
      await db.clearWarnings(userId, moderatorId);
      res.json({ success: true });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });


  // Deleted messages vault routing

  // 1. Search, list & scan deleted messages vault
  app.get('/api/moderation/vault', requireModerator, async (req, res) => {
    try {
      const queryStr = req.query.query as string || undefined;
      const limit = parseInt(req.query.limit as string || '50', 10);

      const items = await db.searchDeletedMessages(queryStr, limit);
      // BATCH-5 (DIR-2026-021): vault READS are audited — silent full-content
      // reads are a compliance gap; every access leaves a durable trace.
      try {
        await db.logModerationAction('VAULT_READ', req.user!.userId, 'system', 'vault-listing', {
          limit,
          results: items.length,
        });
      } catch { /* audit best-effort */ }
      res.status(200).json({ success: true, deletedMessages: items });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 2. Fetch single message vault history details
  app.get('/api/moderation/vault/:messageId', requireModerator, async (req, res) => {
    try {
      const { messageId } = req.params;
      const item = await db.getDeletedMessage(messageId);
      if (!item) {
        return res.status(404).json({ error: 'Archived deleted message not found in the safety vault.' });
      }
      // BATCH-5 (DIR-2026-021): per-message vault reads are audited too.
      try {
        await db.logModerationAction('VAULT_READ', req.user!.userId, item.senderId || 'system', messageId, { single: true });
      } catch { /* audit best-effort */ }
      res.status(200).json({ success: true, deletedMessage: item });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Mute, ban, and unmute routing
  
  app.get('/api/moderation/users', requireModerator, async (req, res) => {
    try {
      const { limit = '50', offset = '0', filter } = req.query;
      const users = await db.getModerationUsers(parseInt(limit as string, 10), parseInt(offset as string, 10), filter as string);
      res.json(users);
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.get('/api/moderation/users/:userId/stats', requireModerator, async (req, res) => {
    try {
      const { userId } = req.params;
      const stats = await db.getModerationUserStats(userId);
      res.json(stats);
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.post('/api/moderation/users/:userId/mute', requireModerator, async (req, res) => {
    try {
      const { userId } = req.params;
      const { durationHours: rawHours, reason } = req.body;
      const moderatorId = req.user!.userId;

      if (!reason) return res.status(400).json({ error: 'Reason required for muting.' });

      const durationHours = typeof rawHours === 'string' ? parseInt(rawHours, 10) : Number(rawHours);
      if (isNaN(durationHours)) {
        return res.status(400).json({ error: 'Invalid or missing duration value structure.' });
      }

      let mutedUntil: Date | null = null;
      if (durationHours === -1) {
        mutedUntil = new Date('2099-12-31');
      } else if (durationHours > 0) {
        mutedUntil = new Date();
        mutedUntil.setHours(mutedUntil.getHours() + durationHours);
      } else {
        return res.status(400).json({ error: 'Duration hours must be positive or -1 for permanent.' });
      }

      await db.muteUser(userId, mutedUntil, moderatorId, reason);

      await db.logModerationAction(
        'USER_MUTED',
        moderatorId,
        userId,
        `Muted for ${durationHours === -1 ? 'permanent' : durationHours + ' hours'}`,
        { durationHours, reason }
      );

      // BROADCAST TO WEBSOCKET
      await redisCluster.publish(`user:updates:${userId}`, {
        event: 'user:moderation_update',
        payload: {
          mutedUntil: mutedUntil.toISOString(),
          muteReason: reason,
          type: 'MUTE'
        }
      });

      res.json({ success: true, mutedUntil });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.post('/api/moderation/users/:userId/unmute', requireModerator, async (req, res) => {
    try {
      const { userId } = req.params;
      const moderatorId = req.user!.userId;

      await db.muteUser(userId, null, moderatorId, 'Unmuted by moderator');

      await db.logModerationAction(
        'USER_UNMUTED',
        moderatorId,
        userId,
        'User unmuted manually.',
        {}
      );

      // BROADCAST TO WEBSOCKET
      await redisCluster.publish(`user:updates:${userId}`, {
        event: 'user:moderation_update',
        payload: {
          mutedUntil: null,
          type: 'UNMUTE'
        }
      });

      res.json({ success: true });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.post('/api/moderation/users/:userId/ban', requireModerator, async (req, res) => {
    try {
      const { userId } = req.params;
      const { durationHours: rawHours, reason } = req.body;
      const moderatorId = req.user!.userId;

      if (!reason) return res.status(400).json({ error: 'Reason required for banning.' });

      const durationHours = typeof rawHours === 'string' ? parseInt(rawHours, 10) : Number(rawHours);
      if (isNaN(durationHours)) {
        return res.status(400).json({ error: 'Invalid or missing duration value structure.' });
      }

      let bannedUntil: Date | null = null;
      if (durationHours === -1) {
        bannedUntil = new Date('2099-12-31');
      } else if (durationHours > 0) {
        bannedUntil = new Date();
        bannedUntil.setHours(bannedUntil.getHours() + durationHours);
      } else {
        return res.status(400).json({ error: 'Duration hours must be positive or -1 for permanent.' });
      }

      await db.banUser(userId, true, moderatorId, reason, bannedUntil);

      await db.logModerationAction(
        'USER_BANNED',
        moderatorId,
        userId,
        `Banned for ${durationHours === -1 ? 'permanent' : durationHours + ' hours'}`,
        { durationHours, reason }
      );

      // BROADCAST TO WEBSOCKET - This will trigger termination in WS server
      await redisCluster.publish(`user:updates:${userId}`, {
        event: 'user:banned',
        payload: { reason, bannedUntil: bannedUntil.toISOString() }
      });

      res.json({ success: true, bannedUntil });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.post('/api/moderation/users/:userId/warnings', requireModerator, async (req, res) => {
    try {
      const { userId } = req.params;
      const { severity, reason } = req.body;
      const moderatorId = req.user!.userId;

      if (!reason) return res.status(400).json({ error: 'Reason required for warning.' });

      await db.warnUser(userId, moderatorId, reason, severity);

      await db.logModerationAction(
        'USER_WARNED',
        moderatorId,
        userId,
        `User Warned. Severity: ${severity}. Reason: ${reason}`,
        { severity, reason }
      );

      // BROADCAST TO WEBSOCKET
      await redisCluster.publish(`user:updates:${userId}`, {
        event: 'user:warning',
        payload: { severity, reason, timestamp: new Date().toISOString() }
      });

      res.json({ success: true });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.post('/api/moderation/users/:userId/unban', requireModerator, async (req, res) => {
    try {
      const { userId } = req.params;
      const moderatorId = req.user!.userId;

      await db.banUser(userId, false, moderatorId, 'Unbanned by moderator');

      await db.logModerationAction(
        'USER_UNBANNED',
        moderatorId,
        userId,
        'User unbanned manually.',
        {}
      );

      // No need to broadcast user:unbanned unless we want to allow login instantly without status polling
      // Actually login API already checks DB status.

      res.json({ success: true });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 3. View Moderation General Audit Logs
  app.get('/api/moderation/audit-logs', requireModerator, async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string || '100', 10);
      const offset = parseInt(req.query.offset as string || '0', 10);
      const eventType = req.query.eventType as string || undefined;

      const logs = await db.getModerationLogs(limit, offset, eventType);
      res.status(200).json({ success: true, auditLogs: logs });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // 4. Update user's role or status (Moderators only)
  // P0-hardening: privilege-escalation shield.
  //   (a) assigning 'admin'/'developer' additionally requires requireAdmin-level
  //       (durable-role authority — BATCH-1) — a plain moderator role cannot mint operators;
  //   (b) self-target forbidden;
  //   (c) a moderator (non-admin caller) may assign at most 'moderator';
  //   (d) nobody may assign a role ≥ their own rank — only developers create developers.
  const ROLE_RANK: Record<string, number> = { user: 0, moderator: 1, admin: 2, developer: 3 };
  app.post('/api/moderation/users/:userId/role', requireModerator, async (req, res) => {
    try {
      const { userId } = req.params;
      const { role, reason } = req.body || {};
      const actorUserId = req.user!.userId;

      // (b) Self-target forbidden — no operator may edit their own role.
      if (userId === actorUserId) {
        return res.status(400).json({ error: 'لا يمكنك تعديل دورك بنفسك.' });
      }

      // BATCH-5 (DIR-2026-007): 'banned' is NOT a role — bans go through the ban
      // endpoint (isBanned); assigning a pseudo-role silently no-ops the ban.
      const validRoles = ['user', 'moderator', 'admin', 'developer'];
      if (!role || !validRoles.includes(role)) {
        return res.status(400).json({ error: `Invalid role. Must be one of: ${validRoles.join(', ')}` });
      }

      const actor = await db.getUserById(actorUserId);
      if (!actor) {
        return res.status(404).json({ error: 'Caller identity not found.' });
      }

      const callerRole = actor.role || 'user';
      const callerRank = ROLE_RANK[callerRole] ?? 0;
      const targetRank = ROLE_RANK[role] ?? 0;

      // (a) BATCH-1 (DIR-2026-001): only the durable 'developer' role may mint
      // 'admin'/'developer' — env-username authority removed.
      if (role === 'admin' || role === 'developer') {
        if (callerRole !== 'developer') {
          console.warn(`[Security Alert] Role escalation attempt to '${role}' by non-developer caller: ${actor.username || actorUserId}`);
          return res.status(403).json({ error: '403 Forbidden: Developer privileges required.' });
        }
      }

      // (c)+(d) Rank ceiling: admins/developers may only assign strictly below
      // their own rank (developer is the sole exception — developers create
      // developers); a moderator-rank caller may assign at most 'moderator'.
      if (role !== 'banned') {
        const canAssign = callerRank >= 2
          ? targetRank < callerRank
            || (callerRole === 'developer' && role === 'developer')
          : callerRank >= 1 && targetRank <= 1;
        if (!canAssign) {
          return res.status(403).json({ error: 'لا يمكنك تعيين دور يساوي أو يتجاوز مستواك.' });
        }
      }

      const userRecord = await db.getUserById(userId);
      if (!userRecord) {
        return res.status(404).json({ error: 'User not found.' });
      }

      await db.updateUser(userId, { role });

      // Log in audit logs
      await db.logModerationAction(
        role === 'banned' ? 'USER_BANNED' : 'USER_ROLE_UPDATED',
        actorUserId,
        userId,
        userId,
        {
          oldRole: userRecord.role || 'user',
          newRole: role,
          reason: reason || 'Administration Action'
        }
      );

      // If they are banned, revoke sessions and update live sockets
      if (role === 'banned') {
        try {
          await db.revokeOtherUserSessions(userId, '');
        } catch (_) {}
      }

      res.status(200).json({ success: true, role });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Database Reset & Full Wipe Endpoint (Admin / System Reset)
  // ─────────────────────────────────────────────────────────────────────────────
  // BATCH-1 (DIR-2026-001): explicit, auditable, ONE-TIME operator provisioning.
  //   - Disabled unless OPERATOR_BOOTSTRAP_SECRET is set in the environment.
  //   - Caller must be an authenticated user AND present the secret.
  //   - Consumed exactly once (durable marker in system_api_keys), then 403.
  //   - Promotes the CALLER to 'developer'; audit-logged.
  //   - NEVER derives anything from username; operator handles in ADMIN_USERNAMES
  //     stay reserved from public registration/rename (anti-impersonation only).
  app.post('/api/admin/bootstrap-operator', requireAuth, async (req, res) => {
    try {
      const secret = process.env.OPERATOR_BOOTSTRAP_SECRET || '';
      if (!secret) {
        return res.status(404).json({ error: 'Operator bootstrap is disabled (OPERATOR_BOOTSTRAP_SECRET not set).' });
      }
      const presented = String(req.headers['x-bootstrap-secret'] || '');
      const a = crypto.createHash('sha256').update(presented).digest();
      const b = crypto.createHash('sha256').update(secret).digest();
      if (presented.length === 0 || !crypto.timingSafeEqual(a, b)) {
        console.warn(`[Security Alert] Operator bootstrap attempt with invalid secret (ip=${req.ip || 'unknown'})`);
        return res.status(403).json({ error: '403 Forbidden: Invalid bootstrap secret.' });
      }
      // BATCH-1 review fix (atomic claim): CLAIM-FIRST via the PRIMARY KEY —
      // INSERT ... ON CONFLICT (id) DO NOTHING; the promotion runs only if the
      // insert won (rowCount 1). Memory fallback mirrors ON CONFLICT semantics
      // (existing id → rowCount 0), so exactly one call can ever win.
      const claim = await pool.query(
        `INSERT INTO system_api_keys (id, key_value, service_name, added_by)
         VALUES ('operator-bootstrap', 'consumed', 'operator-bootstrap', $1)
         ON CONFLICT (id) DO NOTHING`,
        [req.user!.userId]
      );
      if (!claim.rowCount || claim.rowCount < 1) {
        return res.status(403).json({ error: 'Operator bootstrap already consumed. Use an existing developer account.' });
      }
      const user = await db.getUserById(req.user!.userId);
      if (!user) return res.status(404).json({ error: 'Caller identity not found.' });
      if (user.role === 'admin' || user.role === 'developer') {
        return res.status(200).json({ ok: true, alreadyOperator: true });
      }
      await db.updateUser(user.id, { role: 'developer' });
      await db.logAuthAction(user.id, 'operator_bootstrap', { ip: (req.ip || '').toString() });
      console.warn(`[AUDIT][OPERATOR-BOOTSTRAP] user=${user.username || user.id} promoted to developer (one-time bootstrap)`);
      res.status(200).json({ ok: true, role: 'developer' });
    } catch (err: any) {
      console.error('[Server] bootstrap-operator failed:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  app.post('/api/admin/reset-database', async (req, res) => {
    try {
      // BATCH-1 review fix (DIR-2026-006): the brute-force guard counts FAILED
      // attempts too — it must run BEFORE the authorization gates, otherwise
      // wrong-secret guesses consume nothing and stay unthrottled.
      const wipeRlKey = clientIp(req); // BATCH-7b (NEW-A-09): hardened attribution — the raw req.ip claim in the prior commit was FALSE (fix never landed); now real
      if (restLimit(`admin:wipe:${wipeRlKey}`, 3, 60 * 60 * 1000)) {
        return res.status(429).json({ error: 'Too many wipe attempts — locked for one hour.' });
      }

      const authHeader = req.headers.authorization;
      let isAuthorized = false;

      if (authHeader && authHeader.startsWith('Bearer ')) {
        const token = authHeader.substring(7);
        const payload = AuthService.verifyAccessToken(token);
        if (payload) {
          const user = await db.getUserById(payload.userId);
          if (user && (user.role === 'admin' || user.role === 'developer')) {
            isAuthorized = true;
          }
        }
      }

      // Optional system destroy key must be configured via environment — never hardcoded
      const adminSecret = process.env.ADMIN_WIPE_SECRET || '';
      if (adminSecret) {
        // BATCH-1 (DIR-2026-006): constant-time compare — hash both sides to
        // equalize length, then timingSafeEqual.
        const presented = String(req.headers['x-admin-secret'] || '');
        if (presented.length > 0) {
          const a = crypto.createHash('sha256').update(presented).digest();
          const b = crypto.createHash('sha256').update(adminSecret).digest();
          if (crypto.timingSafeEqual(a, b)) isAuthorized = true;
        }
      }

      // Hard gate
      if (!isAuthorized) {
        console.warn(`[Security Alert] Unauthorized database wipe attempt from IP: ${req.ip || req.headers['x-forwarded-for'] || 'unknown'}`);
        return res.status(403).json({ error: '403 Forbidden: Administrative authorization required.' });
      }

      // BATCH-1 (DIR-2026-006): explicit destructiveness confirmation — a blind
      // single POST (CSRF/exploit style) can no longer wipe anything.
      if (String((req.body || {}).confirm || '') !== 'RESET-DIRASHA') {
        return res.status(400).json({ error: 'Confirmation required: send {"confirm":"RESET-DIRASHA"} to execute the wipe.' });
      }

      // BATCH-1 (DIR-2026-006): DURABLE AUDIT BEFORE the destructive action
      // (the wipe truncates the moderation tables — auth_logs is wiped too, so
      // the console audit line is the durable record here; auth action is
      // best-effort where an actor token is available).
      console.warn(`[AUDIT][RESET-DATABASE] wipe EXECUTED by=${req.user?.username || 'x-admin-secret'} ip=${req.ip || 'unknown'} at=${new Date().toISOString()}`);
      try {
        const authHdr = req.headers.authorization;
        if (authHdr?.startsWith('Bearer ')) {
          const p = AuthService.verifyAccessToken(authHdr.substring(7));
          if (p) await db.logAuthAction(p.userId, 'admin_reset_database', { ip: (req.ip || '').toString() });
        }
      } catch { /* best-effort audit */ }

      await db.resetAndWipeAllUsersAndData();
      res.status(200).json({ success: true, message: 'Database wiped and reset successfully. Ready for fresh registrations.' });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Toggle Reaction
  app.post('/api/messages/:messageId/react', requireAuth, async (req, res) => {
    try {
      const { messageId } = req.params;
      const { emoji } = req.body;
      const userId = req.user!.userId;

      const message = await db.getMessageById(messageId);
      if (!message) {
        return res.status(404).json({ error: 'Message not found' });
      }

      // BATCH-3 review follow-up: reactions on tombstoned messages are refused
      // (metadata consistency with the delete-for-everyone semantics).
      if (message.deletedAt) {
        return res.status(409).json({ error: 'الرسالة محذوفة — لا يمكن التفاعل معها.', code: 'MESSAGE_TOMBSTONED' });
      }

      // Membership guard: reactions mutate chat-visible state, so only chat members may toggle them
      const reactAllowedMembers = await db.getChatMembers(message.chatId);
      if (!reactAllowedMembers.some(m => m.userId === userId)) {
        return res.status(403).json({ error: 'Access Denied: You are not a registered member of this chat.' });
      }

      const reactions = { ...(message.reactions || {}) };
      const usersReacted = [...(reactions[emoji] || [])];
      
      const idx = usersReacted.indexOf(userId);
      if (idx > -1) {
        usersReacted.splice(idx, 1);
      } else {
        usersReacted.push(userId);
      }

      if (usersReacted.length === 0) {
        delete reactions[emoji];
      } else {
        reactions[emoji] = usersReacted;
      }

      await db.updateMessage(messageId, { reactions });

      const reactEvent = {
        event: 'msg:react',
        payload: {
          chatId: message.chatId,
          messageId,
          reactions
        }
      };
      await redisCluster.publish(`chat:${message.chatId}`, reactEvent);

      // ALSO broadcast reactions to all chat members' private channels
      const reactMembers = await db.getChatMembers(message.chatId);
      for (const memb of reactMembers) {
        await redisCluster.publish(`user:updates:${memb.userId}`, reactEvent);
      }

      res.status(200).json({ success: true, reactions });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Poll vote (WhatsApp parity): applies single/multi-choice rules via db.votePoll
  // and broadcasts the canonical updated poll as msg:poll:update (mirrors msg:edit).
  app.post('/api/messages/:messageId/poll-vote', requireAuth, async (req, res) => {
    try {
      const { messageId } = req.params;
      const userId = req.user!.userId;

      if (restLimit(`pollvote:${userId}`, 30, 60_000)) {
        return res.status(429).json({ error: 'طلبات كثيرة جداً — حاول بعد قليل.' });
      }

      const { optionIndexes } = req.body || {};
      if (!Array.isArray(optionIndexes) || optionIndexes.some(i => !Number.isInteger(i))) {
        return res.status(400).json({ error: 'optionIndexes يجب أن تكون مصفوفة أرقام صحيحة.' });
      }

      const message = await db.getMessageById(messageId);
      if (!message || message.deletedAt) {
        return res.status(404).json({ error: 'الرسالة غير موجودة.' });
      }
      if (!message.poll) {
        return res.status(400).json({ error: 'هذه الرسالة ليست تصويتاً.' });
      }

      // Membership guard: only chat members may vote
      const voteMembers = await db.getChatMembers(message.chatId);
      if (!voteMembers.some(m => m.userId === userId)) {
        return res.status(403).json({ error: 'غير مصرح: لست عضواً في هذه المحادثة.' });
      }

      const updated = await db.votePoll(message.chatId, messageId, userId, optionIndexes);
      if (!updated) {
        return res.status(500).json({ error: 'تعذر تسجيل التصويت.' });
      }

      const pollEvent = {
        event: 'msg:poll:update',
        payload: {
          chatId: message.chatId,
          messageId,
          poll: updated
        }
      };
      await redisCluster.publish(`chat:${message.chatId}`, pollEvent);

      // ALSO broadcast the poll update to all chat members' private channels
      for (const memb of voteMembers) {
        await redisCluster.publish(`user:updates:${memb.userId}`, pollEvent);
      }

      res.status(200).json({ success: true, poll: updated });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Toggle Star
  app.post('/api/messages/:messageId/star', requireAuth, async (req, res) => {
    try {
      const { messageId } = req.params;
      const userId = req.user!.userId;

      const message = await db.getMessageById(messageId);
      if (!message) {
        return res.status(404).json({ error: 'Message not found' });
      }

      // BATCH-3 review follow-up: stars on tombstoned messages are refused.
      if (message.deletedAt) {
        return res.status(409).json({ error: 'الرسالة محذوفة — لا يمكن تمييزها بنجمة.', code: 'MESSAGE_TOMBSTONED' });
      }

      // Membership guard: only chat members may star its messages
      const starAllowedMembers = await db.getChatMembers(message.chatId);
      if (!starAllowedMembers.some(m => m.userId === userId)) {
        return res.status(403).json({ error: 'Access Denied: You are not a registered member of this chat.' });
      }

      const starredBy = [...(message.starredBy || [])];
      const idx = starredBy.indexOf(userId);
      let isStarred = false;

      if (idx > -1) {
        starredBy.splice(idx, 1);
      } else {
        starredBy.push(userId);
        isStarred = true;
      }

      await db.updateMessage(messageId, { starredBy });

      // Sync across user's active devices
      await redisCluster.publish(`user:updates:${userId}`, {
        event: 'msg:star',
        payload: {
          chatId: message.chatId,
          messageId,
          starredBy,
          isStarred
        }
      });

      res.status(200).json({ success: true, starredBy, isStarred });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Toggle Pin
  app.post('/api/messages/:messageId/pin', requireAuth, async (req, res) => {
    try {
      const { messageId } = req.params;
      const userId = req.user!.userId;

      const message = await db.getMessageById(messageId);
      if (!message) {
        return res.status(404).json({ error: 'Message not found' });
      }

      // BATCH-3 review follow-up: pinning tombstoned messages is refused.
      if (message.deletedAt) {
        return res.status(409).json({ error: 'الرسالة محذوفة — لا يمكن تثبيتها.', code: 'MESSAGE_TOMBSTONED' });
      }

      // Membership guard: pinning alters shared chat state, so only chat members may toggle it
      const pinAllowedMembers = await db.getChatMembers(message.chatId);
      if (!pinAllowedMembers.some(m => m.userId === userId)) {
        return res.status(403).json({ error: 'Access Denied: You are not a registered member of this chat.' });
      }

      // Granular admin rights (Telegram parity): pinning a group message
      // requires the pinMessages admin right (owner always allowed; DMs free)
      const chatInfo = db.getChatInfo(message.chatId);
      if (chatInfo?.type === 'group' && !db.adminCan(message.chatId, userId, 'pinMessages')) {
        return res.status(403).json({ error: 'التثبيت متاح لمن يملك صلاحية التثبيت فقط.' });
      }

      const targetPinState = !message.isPinned;
      await db.updateMessage(messageId, { isPinned: targetPinState });

      // Notify all users in the chat via WebSocket of the Pin adjustment
      const pinEvent = {
        event: 'msg:pin',
        payload: {
          chatId: message.chatId,
          messageId,
          isPinned: targetPinState
        }
      };
      await redisCluster.publish(`chat:${message.chatId}`, pinEvent);

      // ALSO broadcast pin event to all chat members' private channels
      const pinMembers = await db.getChatMembers(message.chatId);
      for (const memb of pinMembers) {
        await redisCluster.publish(`user:updates:${memb.userId}`, pinEvent);
      }

      res.status(200).json({ success: true, isPinned: targetPinState });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Fetch all starred messages from the single source of truth database
  app.get('/api/messages/starred', requireAuth, async (req, res) => {
    try {
      const userId = req.user!.userId;
      const msgs = await db.getStarredMessagesForUser(userId);
      const starred = await Promise.all(msgs.map(async (m) => {
        const sender = await db.getUserById(m.senderId);
        return {
          id: m.id,
          chatId: m.chatId,
          senderName: sender?.displayName || m.senderName || 'ظ…ط³طھط®ط¯ظ… ط؛ظٹط± ظ…ط¹ط±ظˆظپ',
          content: m.content,
          createdAt: m.createdAt,
          userId: userId
        };
      }));
      res.status(200).json({ starred });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  // Create uploads directory if it doesn't exist
  const uploadsPath = path.join(process.cwd(), 'uploads');
  if (!fs.existsSync(uploadsPath)) {
    fs.mkdirSync(uploadsPath, { recursive: true });
  }

  // Serve static uploads
  // BATCH-6 (ADV-08): the static mount is gated — requireAuth accepts URL
  // media tokens for media tags (GET-only, media-scoped per CB-03), so the
  // directory is no longer world-readable without any credential.
  app.use('/uploads', requireAuth, express.static(uploadsPath));

  // Strict JSON constraints across API layers to block HTML leaks
  app.all('/api/*', (req, res) => {
    res.status(404).json({ error: `Not Found: The API route '${req.originalUrl}' is not recognized.` });
  });

  // Initialize real-time WebSocket server
  const wsServer = new WebSocketChatServer(server);

  // Frontend routing with Vite integration
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve Static production outputs
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Local server-side presence tracking
  // Note: Firestore security rules restrict list and write access to authenticated clients.
  // The backend server will track websocket sessions locally, and the client-to-client 
  // heartbeat consensus will keep the display states completely synced and real-time.
  console.log('[PresenceWatchdog] Server-side presence listener initialized in passive cluster-tracking mode.');

  // Start backdrop moderation jobs
  startModerationJobs();

  // Bind server on port 3000 at 0.0.0.0 (required container protocol)
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[dirasha] High-performance full-stack server running successfully at http://localhost:${PORT}`);
  });
}

startServer();

// Graceful shutdown: flush pending durability work before exit.
process.on("SIGTERM", async () => { try { const { flushPendingWrites } = await import("./src/server/database.ts"); await flushPendingWrites(); } catch {} process.exit(0); });
process.on("SIGINT", async () => { try { const { flushPendingWrites } = await import("./src/server/database.ts"); await flushPendingWrites(); } catch {} process.exit(0); });
