/**
 * P1-D (external-audit E2EE-08) — Key Transparency trust gate.
 * Run: npx vitest run tests/kt-gate.test.ts
 */
import { describe, it, expect, beforeEach } from 'vitest';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  getPeerKtVerification, isKtEnforced, resetKtVerdicts, fetchAndVerifyFleetProofGated,
} from '../src/lib/e2ee/kt-client.ts';

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const engineSrc = fs.readFileSync(path.join(repoRoot, 'src/lib/e2ee/engine.ts'), 'utf8');
const serverSrc = fs.readFileSync(path.join(repoRoot, 'server.ts'), 'utf8');

describe('P1-D — KT trust gate (E2EE-08)', () => {
  beforeEach(() => resetKtVerdicts());

  it('verdict cache: unknown peer → known:false, verified:false', () => {
    expect(getPeerKtVerification('nobody')).toEqual({ verified: false, known: false });
  });

  it('enforcement switch: witness pinned = ON, absent = OFF, escape hatch honored', () => {
    (globalThis as any).KT_WITNESS_PUB = 'TEST-WITNESS-KEY';
    expect(isKtEnforced()).toBe(true);
    delete (globalThis as any).KT_WITNESS_PUB;
    expect(isKtEnforced()).toBe(false);
  });

  it('gated wrapper records per-peer verdicts (verified only for verified+sig+ok)', async () => {
    const bodies: any[] = [
      { snapshot: { treeVersion: 1, rootHash: 'r1', signature: 'sig' }, entries: [] },
      { snapshot: { treeVersion: 1, rootHash: 'r1' }, entries: [] },
    ];
    let call = 0;
    const realFetch = globalThis.fetch;
    (globalThis as any).fetch = async () => ({
      ok: true, status: 200,
      json: async () => bodies[Math.min(call++, bodies.length - 1)],
      text: async () => '',
    });
    try {
      (globalThis as any).KT_WITNESS_PUB = 'TEST-WITNESS-KEY';
      const r1 = await fetchAndVerifyFleetProofGated('peer-x', 'c1', async () => ({}));
      expect(typeof r1.verified).toBe('boolean');
      expect(r1.verified).toBe(false);
      const after1 = getPeerKtVerification('peer-x');
      expect(after1.known).toBe(true);
      expect(after1.verified).toBe(false);
    } finally {
      globalThis.fetch = realFetch;
      delete (globalThis as any).KT_WITNESS_PUB;
      resetKtVerdicts();
    }
  });

  it('engine gate: ensureKtVerified blocks unverified peers before any use (static)', () => {
    expect(engineSrc).toContain('await this.ensureKtVerified(peerId);');
    expect(engineSrc).toContain('KT_UNVERIFIED_PEER');
    expect(engineSrc).toContain('fetchAndVerifyFleetProofGated');
    // The eager fire-and-forget check REMAINS by design (flag upkeep); the
    // enforcement is the synchronous gate above it.
    expect(engineSrc).toContain('void this.verifyFleetTransparency(peerId, capped)');
  });

  it('server: KT_SIGNING_KEY is production-required (fail-fast, not warn-only)', () => {
    expect(serverSrc).toContain("failures.push('KT_SIGNING_KEY: MISSING");
    expect(serverSrc).toContain("NODE_ENV === 'production'");
  });
});
