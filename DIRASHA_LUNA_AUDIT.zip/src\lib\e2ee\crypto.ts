/**
 * Dirasha E2EE — crypto primitives & protocol constants.
 *
 * Single source of truth for every protocol constant (E2EE-SPEC.md):
 *   - wire prefix 'DIR1:', version 1
 *   - info strings 'DirashaRoot-v1' (KDF_RK), 'DirashaX3DH-v1' (X3DH SK), 'DirashaSPK-v1:' (SPK sig)
 *   - AD string `${v}|${ik}|${dh}|${pn}|${n}` (built ONLY via aadString(), never inline)
 *   - MAX_SKIP 2000, ChaCha20-Poly1305 with 12-byte nonce, HKDF/HMAC-SHA256
 *
 * Primitives (all audited noble 1.x):
 *   - X25519 + Ed25519        → @noble/curves/ed25519
 *   - HKDF-SHA256, HMAC-SHA256 → @noble/hashes
 *   - ChaCha20-Poly1305        → @noble/ciphers (subpath './chacha'; './web' is the 2.x name)
 *
 * Browser + Node compatible: base64/UTF8/randomness all go through feature
 * detection (Buffer → btoa/atob fallback, globalThis.crypto for randomness).
 */

import { x25519, ed25519 } from '@noble/curves/ed25519';
import { hkdf } from '@noble/hashes/hkdf';
import { hmac } from '@noble/hashes/hmac';
import { sha256 } from '@noble/hashes/sha256';
import { chacha20poly1305 } from '@noble/ciphers/chacha';
// Post-quantum (PQXDH, FIPS-203): ML-KEM-768 from the audited noble family.
import { ml_kem768 } from '@noble/post-quantum/ml-kem.js';

/* ══ Protocol constants — DO NOT duplicate these inline anywhere else ══ */

/** Wire prefix of every encrypted message. */
export const WIRE_PREFIX = 'DIR1:';
/**
 * Multi-device wire prefix: 'DIRM1:' + b64(JSON {v:1, devices:[{d, env}]}) —
 * used only when the peer bundle advertises MORE than one device.
 */
export const WIRE_PREFIX_MULTI = 'DIRM1:';
/** DeviceId of legacy (pre-multi-device) peers / sessions migrated from plain keys. */
export const LEGACY_DEVICE_ID = 'default';
/** Hard cap on peer devices we encrypt for in one message (server contract: 1..8). */
export const MAX_DEVICES = 6; // must match server fleet cap (transport ceiling bounds fan-out size)
/** Envelope version + the `v` field of the AD string. */
export const WIRE_VERSION = 1;
/** KDF_RK info string (Double Ratchet root chain). */
export const INFO_ROOT = 'DirashaRoot-v1';
/** X3DH shared-secret HKDF info string. */
export const INFO_X3DH = 'DirashaX3DH-v1';
/**
 * PQXDH hybrid shared-secret HKDF info string (design doc §3.2): the PQ-hybrid
 * derivation uses a DISTINCT info string so a classical-only SK can never
 * collide with a hybrid SK for the same DH material (downgrade evidence).
 */
export const INFO_X3DH_PQ = 'DirashaX3DH-PQ-v1';
/** Prefix of the UTF8 string signed by IK_sig over the SPK public key. */
export const SPK_SIG_PREFIX = 'DirashaSPK-v1:';
/**
 * PQXDH (design doc §3.1): IK_sig signs the SPK pub AND the ML-KEM-768 PQ
 * prekey pub TOGETHER — 'DirashaPQSPK-v1:' + b64(spkPub) + b64(pqPub) —
 * cryptographically binding the quantum prekey to the classical identity.
 */
export const PQ_SPK_SIG_PREFIX = 'DirashaPQSPK-v1:';
/**
 * Grep-able single source of the AAD construction used by BOTH encrypt and
 * decrypt. The AD bytes are UTF8(aadString(v, ik, dh, pn, n)).
 */
export const AAD_TEMPLATE = '${v}|${ik}|${dh}|${pn}|${n}';
/** Maximum number of message keys we may skip / hold as skipped keys. */
export const MAX_SKIP = 2000;
/** ChaCha20-Poly1305 nonce length. */
export const NONCE_BYTES = 12;
/** Symmetric key / DH output length. */
export const KEY_BYTES = 32;
/** Length (bytes) of Ed25519 signatures. */
export const SIG_BYTES = 64;
/** X3DH leading constant when DH4 absent: 32 × 0xFF. */
export const FF32 = new Uint8Array(32).fill(0xff);
/** Canonical Signal X3DH: F = 32 × 0x00 when DH4 (OPK) is included. */
export const ZERO32 = new Uint8Array(32);
/* ── ML-KEM-768 (FIPS-203) wire sizes (measured, @noble/post-quantum 0.7.1) ── */
/** ML-KEM-768 public (encapsulation) key length in bytes. */
export const PQ_PUB_BYTES = ml_kem768.lengths.publicKey; // 1184
/** ML-KEM-768 ciphertext (encapsulation output) length in bytes. */
export const PQ_CT_BYTES = ml_kem768.lengths.cipherText; // 1088
/** ML-KEM-768 shared secret length in bytes. */
export const PQ_SS_BYTES = ml_kem768.lengths.msg; // 32

/* ══ Encoding helpers (browser + node) ══ */

function nodeBuffer(): any {
  return (globalThis as any).Buffer;
}

/** Std-alphabet base64 encode of arbitrary bytes. */
export function b64encode(bytes: Uint8Array): string {
  const B = nodeBuffer();
  if (B) return B.from(bytes).toString('base64');
  let bin = '';
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin);
}

/** Std-alphabet base64 decode. Throws on invalid input. */
export function b64decode(s: string): Uint8Array {
  const B = nodeBuffer();
  if (B) return new Uint8Array(B.from(s, 'base64'));
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export function utf8Encode(s: string): Uint8Array {
  return new TextEncoder().encode(s);
}

export function utf8Decode(b: Uint8Array): string {
  return new TextDecoder().decode(b);
}

/** Cryptographically secure random bytes. */
export function randomBytes(n: number): Uint8Array {
  const c = (globalThis as any).crypto;
  if (c && typeof c.getRandomValues === 'function') {
    const out = new Uint8Array(n);
    c.getRandomValues(out);
    return out;
  }
  const B = nodeBuffer();
  if (B && typeof B.randomBytes === 'function') return new Uint8Array(B.randomBytes(n));
  throw new Error('no secure random source available');
}

/** RFC-4122 v4 UUID (crypto.randomUUID when available, secure-random fallback otherwise). */
export function randomDeviceId(): string {
  const c = (globalThis as any).crypto;
  if (c && typeof c.randomUUID === 'function') return c.randomUUID();
  const b = randomBytes(16);
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  const hex = Array.from(b, (x: number) => x.toString(16).padStart(2, '0')).join('');
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

export function concatBytes(...parts: Uint8Array[]): Uint8Array {
  const total = parts.reduce((a, p) => a + p.length, 0);
  const out = new Uint8Array(total);
  let off = 0;
  for (const p of parts) {
    out.set(p, off);
    off += p.length;
  }
  return out;
}

function bytesToHex(b: Uint8Array): string {
  let s = '';
  for (let i = 0; i < b.length; i++) s += b[i].toString(16).padStart(2, '0');
  return s;
}

/* ══ Asymmetric primitives ══ */

export interface NobleKeyPair {
  priv: Uint8Array;
  pub: Uint8Array;
}

/** Fresh X25519 key pair (identity / SPK / OPK / ratchet / ephemeral). */
export function generateX25519(): NobleKeyPair {
  const priv = x25519.utils.randomPrivateKey();
  return { priv, pub: x25519.getPublicKey(priv) };
}

export function generateEd25519(): NobleKeyPair {
  const priv = ed25519.utils.randomPrivateKey();
  return { priv, pub: ed25519.getPublicKey(priv) };
}

/** X25519 ECDH shared secret (32 bytes). Throws on invalid keys. */
export function x25519Shared(priv: Uint8Array, pub: Uint8Array): Uint8Array {
  return x25519.getSharedSecret(priv, pub);
}

export function ed25519Sign(message: Uint8Array, priv: Uint8Array): Uint8Array {
  return ed25519.sign(message, priv);
}

/** Constant-time Ed25519 verification; returns false on any mismatch. */
export function ed25519Verify(sig: Uint8Array, message: Uint8Array, pub: Uint8Array): boolean {
  try {
    return ed25519.verify(sig, message, pub);
  } catch {
    return false;
  }
}

/* ── ML-KEM-768 (PQXDH, design doc §3) ────────────────────────────────────── */

export interface MlKem768KeyPair {
  /** 1184-byte encapsulation (public) key. */
  pub: Uint8Array;
  /** 2400-byte decapsulation (private) key — NEVER leaves the device. */
  priv: Uint8Array;
}

/** Fresh ML-KEM-768 key pair (the per-device PQ prekey, design doc §3.1). */
export function generateMlKem768(): MlKem768KeyPair {
  const kp = ml_kem768.keygen();
  return { pub: kp.publicKey, priv: kp.secretKey };
}

/**
 * ML-KEM-768 encapsulation (initiator): returns the 1088-byte ciphertext that
 * rides the bootstrap envelope as `pqCt` plus the 32-byte PQ shared secret
 * (PQ_SS) that is mixed into the hybrid X3DH IKM. Throws on an invalid key.
 */
export function pqEncapsulate(pqPub: Uint8Array): { ct: Uint8Array; ss: Uint8Array } {
  const out = ml_kem768.encapsulate(pqPub);
  return { ct: out.cipherText, ss: out.sharedSecret };
}

/**
 * ML-KEM-768 decapsulation (responder): recovers PQ_SS from the bootstrap's
 * `pqCt` with the local PQ prekey private key. Throws on malformed input —
 * a tampered ciphertext decapsulates to a WRONG secret (implicit rejection
 * keeps it deterministic), which then fails the session AEAD (fail closed,
 * design doc §4 test 5).
 */
export function pqDecapsulate(pqCt: Uint8Array, pqPriv: Uint8Array): Uint8Array {
  return ml_kem768.decapsulate(pqCt, pqPriv);
}

/* ══ KDFs (Double Ratchet, per Signal spec) ══ */

/**
 * KDF_RK: HKDF-SHA256(ikm = DH output, salt = current root key,
 * info = 'DirashaRoot-v1', 64B) → [rk' = out[0:32], ck' = out[32:64]].
 */
export function kdfRk(rk: Uint8Array, dhOut: Uint8Array): { rk: Uint8Array; ck: Uint8Array } {
  const out = hkdf(sha256, dhOut, rk, utf8Encode(INFO_ROOT), 2 * KEY_BYTES);
  return { rk: out.slice(0, KEY_BYTES), ck: out.slice(KEY_BYTES, 2 * KEY_BYTES) };
}

/**
 * KDF_CK: mk = HMAC-SHA256(ck, 0x01), ck' = HMAC-SHA256(ck, 0x02).
 */
export function kdfCk(ck: Uint8Array): { mk: Uint8Array; ck: Uint8Array } {
  return {
    mk: hmac(sha256, ck, new Uint8Array([0x01])),
    ck: hmac(sha256, ck, new Uint8Array([0x02])),
  };
}

/**
 * X3DH SK: HKDF-SHA256(ikm = F || DH1 || DH2 || DH3 [|| DH4],
 * salt = zeros(32), info = 'DirashaX3DH-v1', 32B).
 * F = FF32 (32 × 0xFF, Curve25519 constant per Signal's X3DH spec).
 */
export function x3dhSk(ikm: Uint8Array): Uint8Array {
  return hkdf(sha256, ikm, new Uint8Array(KEY_BYTES), utf8Encode(INFO_X3DH), KEY_BYTES);
}

/**
 * PQXDH hybrid SK (design doc §3.2): HKDF-SHA256 over the SINGLE mixed IKM
 *   F || DH1 || DH2 || DH3 [|| DH4] || PQ_SS
 * with salt = zeros(32), info = 'DirashaX3DH-PQ-v1', 32B — the documented
 * Signal PQXDH pattern (all secret material concatenated at the HKDF-Extract
 * input level; PQ_SS enters as one extra suffix block after the DH block).
 * The distinct info string makes a classical and a hybrid SK for the same
 * DH material computationally independent (no silent-downgrade ambiguity).
 */
export function x3dhSkPq(ikm: Uint8Array): Uint8Array {
  return hkdf(sha256, ikm, new Uint8Array(KEY_BYTES), utf8Encode(INFO_X3DH_PQ), KEY_BYTES);
}

/* ══ AAD (single source — encrypt and decrypt MUST both go through this) ══ */

/** Canonical AD string: `${v}|${ik}|${dh}|${pn}|${n}` (grep AAD_TEMPLATE). */
export function aadString(v: number, ik: string, dh: string, pn: number, n: number): string {
  return `${v}|${ik}|${dh}|${pn}|${n}`;
}

/* ══ AEAD ══ */

/** ChaCha20-Poly1305 seal: returns ciphertext || 16-byte tag. */
export function aeadSeal(key: Uint8Array, nonce: Uint8Array, plaintext: Uint8Array, aad: Uint8Array): Uint8Array {
  return chacha20poly1305(key, nonce, aad).encrypt(plaintext);
}

/** ChaCha20-Poly1305 open: throws on tag verification failure (never mutates inputs). */
export function aeadOpen(key: Uint8Array, nonce: Uint8Array, ciphertext: Uint8Array, aad: Uint8Array): Uint8Array {
  return chacha20poly1305(key, nonce, aad).decrypt(ciphertext);
}

/* ══ Safety number (deterministic, identical on both sides) ══ */

/**
 * 60-digit safety number from the two peers' identity DH public keys (b64).
 * sha256 over UTF8(sorted([ikA, ikB]).join(':')) → hex → twelve 5-hex-char
 * chunks, each mapped via parseInt(chunk, 16) % 100000, zero-padded to 5
 * digits → 60 digits. Deterministic and order-independent.
 */
export function safetyNumber(ikA: string, ikB: string): string {
  const hex = bytesToHex(sha256(utf8Encode([ikA, ikB].sort().join(':'))));
  let digits = '';
  for (let i = 0; i < 12; i++) {
    const chunk = hex.slice(i * 5, i * 5 + 5);
    digits += String(parseInt(chunk, 16) % 100000).padStart(5, '0');
  }
  return digits;
}
