/**
 * F6 — refresh token NEVER travels in the JSON response body.
 *
 * The refresh token's ONLY transport is the server-set HttpOnly cookie
 * (src/lib/token_vault.ts documents this contract; the client refresh flow
 * reads only accessToken/user/sessionId from the body).
 *
 * server.ts boots at import time, so per the audit-fix directive these are
 * static-source (grep-style) tests over the session-issuing route blocks:
 *   POST /api/auth/refresh      (server.ts)
 *   POST /api/auth/register     (routes/authClassic.ts)
 *   POST /api/auth/login        (routes/authClassic.ts)
 *   POST /api/auth/recover/reset(routes/authClassic.ts)
 *
 * Also pins the cookie flags (httpOnly + secure) and guards against a client
 * regression that would re-introduce body.refreshToken reads.
 *
 * Run: npx vitest run tests/refresh-token-body.test.ts
 */
import { describe, it, expect } from 'vitest';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const serverSrc = fs.readFileSync(path.join(repoRoot, 'server.ts'), 'utf8');
const authClassicSrc = fs.readFileSync(path.join(repoRoot, 'src/server/routes/authClassic.ts'), 'utf8');
const appSrc = fs.readFileSync(path.join(repoRoot, 'src/App.tsx'), 'utf8');
const tokenVaultSrc = fs.readFileSync(path.join(repoRoot, 'src/lib/token_vault.ts'), 'utf8');

/** Extract a route block: from its registration line to the next route/comment banner. */
function extractBlock(src: string, needle: string, endNeedles: string[]): string {
  const start = src.indexOf(needle);
  expect(start, `route not found: ${needle}`).toBeGreaterThan(-1);
  let end = src.length;
  for (const n of endNeedles) {
    const idx = src.indexOf(n, start + needle.length);
    if (idx !== -1 && idx < end) end = idx;
  }
  return src.slice(start, end);
}

/** A `refreshToken:` JSON key anywhere in a 2xx res.json body = F6 violation. */
function assertNoRefreshTokenKey(block: string, label: string): void {
  expect(block, `${label}: refreshToken leaked into a JSON body`).not.toMatch(/refreshToken\s*:/);
}

describe('F6 — refresh token is cookie-only (never in the JSON body)', () => {
  it('POST /api/auth/refresh returns NO refreshToken key; cookie flags are httpOnly/secure', () => {
    const block = extractBlock(serverSrc, "app.post('/api/auth/refresh'", ["app.post('/api/auth/logout'"]);
    assertNoRefreshTokenKey(block, '/api/auth/refresh');
    expect(block).toContain("res.cookie('refreshToken'");
    expect(block).toMatch(/httpOnly:\s*true/);
    expect(block).toMatch(/secure:\s*true/);
  });

  it('POST /api/auth/register returns NO refreshToken key; cookie is bound HttpOnly', () => {
    const block = extractBlock(authClassicSrc, "app.post('/api/auth/register'", ['/* ==================== LOGIN']);
    assertNoRefreshTokenKey(block, '/api/auth/register');
    expect(block).toContain('bindRefreshCookie(res,');
  });

  it('POST /api/auth/login returns NO refreshToken key; cookie is bound HttpOnly', () => {
    const block = extractBlock(authClassicSrc, "app.post('/api/auth/login'", ['/* ==================== RECOVERY']);
    assertNoRefreshTokenKey(block, '/api/auth/login');
    expect(block).toContain('bindRefreshCookie(res,');
  });

  it('POST /api/auth/recover/reset returns NO refreshToken key; cookie is bound HttpOnly', () => {
    const block = extractBlock(authClassicSrc, "app.post('/api/auth/recover/reset'", ['/* ==================== PASSWORD CHANGE']);
    assertNoRefreshTokenKey(block, '/api/auth/recover/reset');
    expect(block).toContain('bindRefreshCookie(res,');
  });

  it('the shared cookie binder sets httpOnly + secure (+ SameSite=None for iframe support)', () => {
    expect(authClassicSrc).toMatch(/res\.cookie\('refreshToken'[^;]*\{[^}]*httpOnly:\s*true[^}]*secure:\s*true/s);
    expect(authClassicSrc).toMatch(/sameSite:\s*'none'/);
  });

  it('the client refresh flow reads only accessToken/user/sessionId — never body.refreshToken', () => {
    // App.tsx refresh calls must not READ a refreshToken field off the response
    // body (sending the legacy token for cookie migration is allowed).
    expect(appSrc).not.toMatch(/\bdata\.refreshToken\b/);
    expect(appSrc).not.toMatch(/\.refreshToken\s*\)/); // no body.refreshToken reads
    // token_vault documents + enforces the cookie-only contract.
    expect(tokenVaultSrc).toContain('HttpOnly');
  });

  // FOLLOW-UP (other workstream): routes/passkeys.ts:508 still mirrors
  // sessionBundle.refreshToken into the passkey-login JSON body. passkeys.ts is
  // explicitly out of scope for this fix wave (do-NOT-touch list), so this is
  // documented as a pending assertion instead of failing the suite. Flip to a
  // hard assertion when the passkeys workstream removes it.
  it.skip('POST /api/auth/passkeys/login-verify returns NO refreshToken key (PENDING passkeys workstream)', () => {
    const passkeysSrc2 = fs.readFileSync(path.join(repoRoot, 'src/server/routes/passkeys.ts'), 'utf8');
    expect(passkeysSrc2).not.toMatch(/refreshToken\s*:/);
  });
});
