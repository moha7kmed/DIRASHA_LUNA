/**
 * Data-only SQL backup of the chat-domain tables.
 *
 * Usage:
 *   npm run backup                 (writes ./backups/pg-backup-YYYYMMDD-HHmmss.sql)
 *   npx tsx scripts/pg-backup.ts --dry-run
 *                                  (prints table names + row counts, writes nothing;
 *                                   works without a reachable DB — counts shown as
 *                                   'unavailable' when DATABASE_URL is unset/unreachable)
 *
 * - Connects using the DATABASE_URL env var (Aiven-style Postgres URL from .env).
 * - Emits INSERT statements (batched per table) with properly escaped literals.
 *   psql COPY-to-stdout is NOT available on managed instances, so rows are
 *   streamed with a pg cursor and serialized here.
 * - Keeps the last 14 backups in ./backups and deletes older ones.
 * - NEVER prints the connection string or any of its parts.
 */
import fs from 'fs';
import path from 'path';
import 'dotenv/config';
import pg from 'pg';
import Cursor from 'pg-cursor';

const KEEP_BACKUPS = 14;
const BATCH_SIZE = 500; // rows per INSERT statement
const CURSOR_CHUNK = 1000; // rows fetched per cursor read

// Order matters only for readability/restore convenience; the generated dump
// sets session_replication_role = replica so FK order is not enforced.
const BACKUP_TABLES: string[] = [
  'chats',
  'chat_members',
  'contacts',
  'blocks',
  'statuses',
  'user_settings',
  'user_sessions',
  'push_subscriptions',
  'messages',
  'message_reads',
  'message_reactions',
  'message_stars',
  'message_pins',
  'attachments',
  'reports',
];

// ---------------------------------------------------------------------------
// Literal escaping
// ---------------------------------------------------------------------------

function pgArrayLiteral(arr: any[]): string {
  // Postgres array text format: {elem,elem,...} with quoted strings.
  const items = arr.map((v) => {
    if (v === null || v === undefined) return 'NULL';
    if (typeof v === 'boolean') return v ? 't' : 'f';
    if (typeof v === 'number') return String(v);
    const s = String(v).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    return `"${s}"`;
  });
  return `{${items.join(',')}}`;
}

function sqlLiteral(value: any): string {
  if (value === null || value === undefined) return 'NULL';
  switch (typeof value) {
    case 'boolean':
      return value ? 'TRUE' : 'FALSE';
    case 'number':
      return Number.isFinite(value) ? String(value) : 'NULL';
    case 'bigint':
      return String(value);
    case 'string':
      return `'${value.replace(/'/g, "''")}'`;
    default:
      break;
  }
  if (value instanceof Date) {
    return `'${value.toISOString()}'`;
  }
  if (Buffer.isBuffer(value)) {
    // bytea -> hex literal
    return `'\\x${value.toString('hex')}'::bytea`;
  }
  if (Array.isArray(value)) {
    return `'${pgArrayLiteral(value).replace(/'/g, "''")}'`;
  }
  if (typeof value === 'object') {
    // json/jsonb columns arrive as objects
    return `'${JSON.stringify(value).replace(/'/g, "''")}'::jsonb`;
  }
  return `'${String(value).replace(/'/g, "''")}'`;
}

// ---------------------------------------------------------------------------
// Row streaming + INSERT serialization
// ---------------------------------------------------------------------------

async function dumpTable(client: pg.PoolClient, table: string, out: fs.WriteStream): Promise<number> {
  // Column list is taken from the table itself so the INSERTs are explicit.
  const colsRes = await client.query<{ column_name: string }>(
    `SELECT column_name FROM information_schema.columns WHERE table_schema = 'public' AND table_name = $1 ORDER BY ordinal_position`,
    [table]
  );
  const cols = colsRes.rows.map((r) => `"${r.column_name}"`);
  if (cols.length === 0) {
    out.write(`-- table ${table}: no columns found (skipped)\n\n`);
    return 0;
  }

  const cursor = new Cursor(`SELECT * FROM "${table}"`);
  await (client.query as any)(cursor);
  let rowCount = 0;
  let batch: any[] = [];

  const flushBatch = () => {
    if (batch.length === 0) return;
    const valuesSql = batch
      .map((row) => `(${cols.map((_, i) => sqlLiteral(row[i])).join(', ')})`)
      .join(',\n  ');
    out.write(`INSERT INTO "${table}" (${cols.join(', ')}) VALUES\n  ${valuesSql};\n`);
    rowCount += batch.length;
    batch = [];
  };

  try {
    // Stream rows in chunks; each read resolves with the next batch of rows.
    for (;;) {
      const rows: any[] = await cursor.read(CURSOR_CHUNK);
      if (rows.length === 0) break;
      for (const row of rows) {
        batch.push(Object.values(row));
        if (batch.length >= BATCH_SIZE) flushBatch();
      }
    }
    flushBatch();
  } finally {
    await cursor.close().catch(() => {});
  }
  return rowCount;
}

// ---------------------------------------------------------------------------
// Retention
// ---------------------------------------------------------------------------

function pruneOldBackups(dir: string, keep: number): string[] {
  const files = fs
    .readdirSync(dir)
    .filter((f) => /^pg-backup-\d{8}-\d{6}\.sql$/.test(f))
    .sort()
    .reverse();
  const removed: string[] = [];
  for (const f of files.slice(keep)) {
    try {
      fs.unlinkSync(path.join(dir, f));
      removed.push(f);
    } catch (e: any) {
      console.warn(`[backup] could not delete ${f}: ${e?.message ?? e}`);
    }
  }
  return removed;
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async function getRowCounts(): Promise<{ ok: boolean; counts: Record<string, number> }> {
  const url = process.env.DATABASE_URL;
  const counts: Record<string, number> = {};
  if (!url) return { ok: false, counts };
  const pool = new pg.Pool({ connectionString: url, ssl: { rejectUnauthorized: false }, max: 1, connectionTimeoutMillis: 8000 });
  try {
    for (const t of BACKUP_TABLES) {
      try {
        const r = await pool.query<{ n: string }>(`SELECT COUNT(*)::text AS n FROM "${t}"`);
        counts[t] = parseInt(r.rows[0]?.n ?? '0', 10);
      } catch {
        counts[t] = -1; // table missing / not bootstrapped yet
      }
    }
    return { ok: true, counts };
  } catch {
    return { ok: false, counts };
  } finally {
    await pool.end().catch(() => {});
  }
}

async function dryRun(): Promise<void> {
  const { ok, counts } = await getRowCounts();
  console.log('[backup] DRY RUN — no files will be written.');
  console.log(`[backup] ${BACKUP_TABLES.length} chat-domain tables in dump order:`);
  for (const t of BACKUP_TABLES) {
    if (!ok) {
      console.log(`  - ${t} (rows: unavailable — DATABASE_URL unset or unreachable)`);
    } else if (counts[t] === -1) {
      console.log(`  - ${t} (rows: table not present)`);
    } else {
      console.log(`  - ${t} (rows: ${counts[t]})`);
    }
  }
  console.log('[backup] dry run complete. Run "npm run backup" to produce a dump.');
}

async function main(): Promise<void> {
  if (process.argv.includes('--dry-run')) {
    await dryRun();
    return;
  }

  const url = process.env.DATABASE_URL;
  if (!url) {
    console.error('[backup] DATABASE_URL is not set — nothing to back up. (Connection details are never printed.)');
    process.exit(1);
  }

  const startedAt = new Date();
  const stamp = startedAt.toISOString().replace(/[^0-9]/g, '').slice(0, 14); // YYYYMMDDHHMMSS
  const fileName = `pg-backup-${stamp.slice(0, 8)}-${stamp.slice(8)}.sql`;
  const backupDir = path.join(process.cwd(), 'backups');
  fs.mkdirSync(backupDir, { recursive: true });
  const outPath = path.join(backupDir, fileName);
  const tmpPath = outPath + '.tmp';

  const pool = new pg.Pool({ connectionString: url, ssl: { rejectUnauthorized: false }, max: 1 });
  const out = fs.createWriteStream(tmpPath, { encoding: 'utf8' });

  try {
    out.write(`-- Dirasha data-only SQL backup\n`);
    out.write(`-- Generated: ${startedAt.toISOString()}\n`);
    out.write(`-- Tables: ${BACKUP_TABLES.join(', ')}\n`);
    out.write(`-- Restore hint: psql "$DATABASE_URL" -f this-file.sql\n`);
    out.write(`\nBEGIN;\nSET session_replication_role = replica;\n\n`);

    const client = await pool.connect();
    const counts: Record<string, number> = {};
    try {
      for (const table of BACKUP_TABLES) {
        out.write(`-- ==== ${table} ====\n`);
        try {
          counts[table] = await dumpTable(client, table, out);
          out.write(`-- ${table}: ${counts[table]} rows\n\n`);
        } catch (e: any) {
          out.write(`-- ${table}: FAILED (${String(e?.message ?? e).replace(/'/g, "''")})\n\n`);
          counts[table] = -1;
        }
      }
    } finally {
      client.release();
    }

    out.write(`COMMIT;\n`);
    out.write(`-- Row counts: ${BACKUP_TABLES.map((t) => `${t}=${counts[t] ?? 0}`).join(', ')}\n`);

    await new Promise<void>((resolve, reject) => {
      out.end((err?: Error | null) => (err ? reject(err) : resolve()));
    });
    fs.renameSync(tmpPath, outPath);

    const totalRows = Object.values(counts).filter((n) => n > 0).reduce((a, b) => a + b, 0);
    const failed = BACKUP_TABLES.filter((t) => counts[t] === -1);
    const durationMs = Date.now() - startedAt.getTime();
    console.log(`[backup] wrote ${outPath} (${totalRows} rows across ${BACKUP_TABLES.length - failed.length}/${BACKUP_TABLES.length} tables, ${durationMs}ms)`);
    if (failed.length > 0) {
      console.warn(`[backup] tables skipped: ${failed.join(', ')}`);
    }

    const removed = pruneOldBackups(backupDir, KEEP_BACKUPS);
    if (removed.length > 0) {
      console.log(`[backup] retention: deleted ${removed.length} old backup(s), keeping last ${KEEP_BACKUPS}`);
    }
  } catch (e: any) {
    out.end(() => {
      try { fs.unlinkSync(tmpPath); } catch { /* ignore */ }
    });
    console.error(`[backup] FAILED: ${e?.message ?? e}`);
    process.exitCode = 1;
  } finally {
    await pool.end().catch(() => {});
  }
}

main().catch((e) => {
  console.error(`[backup] fatal: ${e?.message ?? e}`);
  process.exit(1);
});
