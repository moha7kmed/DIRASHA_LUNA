import { useState } from 'react';
import { ImageOff } from 'lucide-react';

interface MediaGateProps {
  src: string;
  alt?: string;
  autoDownload: string; // 'always' | 'wifi' | 'never'
  onOpen?: () => void;
}

/**
 * MediaGate — makes chatSettings.mediaAutoDownload REAL on the client.
 * 'never' → always tap-to-load. 'wifi' → auto-load on unmetered connections
 * only (Network Information API when available, else treated as wifi).
 */
export function MediaGate({ src, alt, autoDownload, onOpen }: MediaGateProps) {
  const conn = (navigator as any).connection?.effectiveType || 'wifi';
  // '4g' is Chrome's normal fast-connection value (wifi/ethernet report it
  // too!) — treating it as cellular made every image tap-to-load for all.
  const isCellular = ['slow-2g', '2g', '3g'].includes(conn);
  const mode = autoDownload || 'wifi';
  const blocked = mode === 'never' || (mode === 'wifi' && isCellular);
  const [loaded, setLoaded] = useState(!blocked);
  const [error, setError] = useState(false);
  const [attempt, setAttempt] = useState(0);

  if (!loaded) {
    return (
      <button
        onClick={() => setLoaded(true)}
        className="w-full h-36 rounded-2xl bg-black/30 border border-white/10 flex flex-col items-center justify-center gap-2 text-zinc-300 hover:bg-black/40 transition-colors"
      >
        <ImageOff size={22} />
        <span className="text-[11px] px-3 text-center">اضغط لتحميل الوسائط — توفير البيانات مفعّل</span>
      </button>
    );
  }

  if (error) {
    return (
      <div
        onClick={() => { setError(false); setAttempt(a => a + 1); }}
        className="w-full h-36 rounded-2xl bg-black/30 border border-rose-500/20 flex flex-col items-center justify-center gap-2 text-rose-300 cursor-pointer hover:bg-black/40 transition-colors">
        <ImageOff size={22} />
        <span className="text-[11px] px-3 text-center">تعذر تحميل الوسائط — اضغط لإعادة المحاولة</span>
      </div>
    );
  }

  return (
    <img
      key={attempt}
      src={src}
      alt={alt}
      onError={() => setError(true)}
      onLoad={(e) => {
        const img = e.currentTarget;
        if (img.naturalHeight > 400) img.style.maxHeight = '400px';
      }}
      onClick={onOpen}
      style={{ maxWidth: '100%', borderRadius: 16, cursor: onOpen ? 'pointer' : 'default', display: 'block' }}
    />
  );
}
