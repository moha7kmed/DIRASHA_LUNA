/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Shared message-send authorization gate.
 *
 * Extracted from the WebSocket `msg:send` path so that BOTH the WS handler and
 * the REST message endpoints enforce the exact same policy set, in the same
 * order. The gate has zero dependency on ws/sockets: all context arrives via
 * parameters (the `db` instance, senderId, chatId, payload).
 *
 * Enforcement order (semantics preserved verbatim from the WS handler):
 *   1. Media architecture guard — inline base64 `data:` attachment URLs rejected
 *   2. Mute status (moderation)
 *   3. Ban status (moderation)
 *   4. Chat membership
 *   5. Channel broadcast gate — chats.type='channel' allows posting to
 *      owner/admin roles only (subscribers get the Arabic rejection)
 *   6. Group `whoCanSend = 'admins'` permission gate
 *   7. Slow mode (Telegram parity) — shared module-level limiter (WS + REST)
 *   8. Per-member group restrictions (Telegram parity)
 *   9. Blocks between DM parties (either direction) — skipped for channels
 *  10. DM policy `allowDirectMessages` (everyone/contacts/nobody) — skipped for channels
 *
 * On success it records the slow-mode timestamp (only after every gate passed)
 * and returns the chat info plus the sender's membership record so callers can
 * continue with their send-specific bookkeeping.
 */

export class SendBlockedError extends Error {
  constructor(public reason: string) {
    super(reason);
    this.name = "SendBlockedError";
  }
}

/**
 * Membership-epoch gate (external-audit E2EE-01/E2EE-02): group messages must
 * be composed under the CURRENT durable membership_version. Stale (lower) or
 * future (higher) versions are rejected so no message can cross a membership
 * boundary under an old sender-key epoch — including offline members who never
 * received the rotation event (they fail closed and must refresh+rotate).
 */
export class MembershipStaleError extends Error {
  constructor(
    public reason: string,
    public expectedVersion: number,
  ) {
    super(reason);
    this.name = "MembershipStaleError";
  }
}

// Slow-mode last-send timestamps per chat per user (ephemeral — resets on boot).
// Module-level so every ingress path (WS + REST) shares the same limiter state.
const slowModeLast = new Map<string, Map<string, number>>();

export async function assertCanSendMessage(
  db: any,
  senderId: string,
  chatId: string,
  payload?: { attachments?: any[] },
): Promise<{ chat: any; member: any }> {
  const attachments = payload?.attachments || [];

  // MEDIA ARCHITECTURE GUARD: media must live in external object storage.
  // Inline base64 payloads are rejected — clients must presign+PUT first.
  if (
    Array.isArray(attachments) &&
    attachments.some((a) => typeof a?.url === "string" && a.url.startsWith("data:"))
  ) {
    throw new SendBlockedError(
      "يجب رفع الملفات إلى التخزين السحابي أولاً قبل الإرسال.",
    );
  }

  const members = await db.getChatMembers(chatId);
  const sender = await db.getUserById(senderId);

  // MODERATION CHECK: Mute Status
  if (sender?.mutedUntil) {
    const mutedUntil = new Date(sender.mutedUntil);
    if (mutedUntil > new Date()) {
      const err = new SendBlockedError(
        sender.muteReason || "لقد تم تقييد حسابك من إرسال الرسائل حالياً.",
      );
      // Structured context so socket transports can reproduce the rich
      // 'moderation:mute_report' event without knowing which gate fired.
      (err as any).kind = "mute";
      (err as any).chatId = chatId;
      (err as any).mutedUntil = sender.mutedUntil;
      throw err;
    }
  }

  // MODERATION CHECK: Ban Status
  if (sender?.isBanned) {
    const err = new SendBlockedError(
      sender.banReason || "Your account has been banned.",
    );
    (err as any).kind = "ban";
    throw err;
  }

  if (!members.some((m) => m.userId === senderId)) {
    throw new SendBlockedError("Unauthorized room transmission.");
  }

  // ── Privacy enforcement (server-side, real settings) ──
  // CHANNELS (Telegram parity): one-way broadcast — only owner/admins may post.
  // Subscribers (role 'member') always get the broadcast rejection, regardless
  // of whoCanSend/slow-mode/mentions settings (those are group-only concepts).
  const chat = db.getChatInfo(chatId);
  if (chat?.type === "channel") {
    const role = db.getChatRole(chatId, senderId);
    if (role !== "owner" && role !== "admin") {
      throw new SendBlockedError(
        "القناة للبث فقط — المشرفون فقط ينشرون.",
      );
    }
  }

  // Group permission gate: whoCanSend = 'admins' restricts posting to admins.
  if (
    chat?.type === "group" &&
    chat.permissions?.whoCanSend === "admins" &&
    !db.isGroupAdmin(chatId, senderId)
  ) {
    throw new SendBlockedError("الإرسال في هذه المجموعة للمشرفين فقط.");
  }

  // Slow mode (Telegram parity): non-admins wait N seconds between messages.
  const slowSeconds = db.getChatSlowMode(chatId);
  const slowModeApplies =
    chat?.type === "group" && slowSeconds > 0 && !db.isGroupAdmin(chatId, senderId);
  if (slowModeApplies) {
    const last = slowModeLast.get(chatId)?.get(senderId) || 0;
    const waitMs = last + slowSeconds * 1000 - Date.now();
    if (waitMs > 0) {
      throw new SendBlockedError(
        `الوضع البطيء مفعّل — انتظر ${Math.ceil(waitMs / 1000)} ثانية قبل الإرسال.`,
      );
    }
  }

  // Restricted member gate (Telegram parity): per-member group mute
  if (chat?.type === "group") {
    const restrictedMs = db.getGroupRestriction(chatId, senderId);
    if (restrictedMs > 0) {
      const label =
        restrictedMs === Number.MAX_SAFE_INTEGER
          ? "دائماً"
          : `${Math.ceil(restrictedMs / 60000)} دقيقة متبقية`;
      throw new SendBlockedError(
        `المشرفون كتموك في هذه المجموعة (${label}).`,
      );
    }
  }

  // 1) Blocks: a blocked pair cannot exchange direct messages (either direction).
  // 2) DM policy: recipient's allowDirectMessages gate (everyone/contacts/nobody).
  //    Never applies to channels — a 2-subscriber channel is not a DM pair.
  const dmPeers = members.filter((m: any) => m.userId !== senderId);
  if (chat?.type !== "channel" && members.length === 2 && dmPeers.length === 1) {
    if (await db.isBlocked(senderId, dmPeers[0].userId)) {
      throw new SendBlockedError("لا يمكن إتمام الإرسال — أحدكما حظر الآخر.");
    }
    const recipient = await db.getUserById(dmPeers[0].userId);
    const adm = String(recipient?.privacySettings?.allowDirectMessages || "everyone");
    if (adm === "nobody") {
      throw new SendBlockedError("هذا المستخدم لا يستقبل رسائل مباشرة.");
    }
    if (adm === "contacts") {
      const recipientContacts = await db.getContacts(dmPeers[0].userId);
      if (!recipientContacts.includes(senderId)) {
        throw new SendBlockedError(
          "المراسلة متاحة لجهات الاتصال فقط لهذا المستخدم.",
        );
      }
    }
  }

  // Record slow-mode timestamp only after every gate has passed
  if (slowModeApplies) {
    if (!slowModeLast.has(chatId)) slowModeLast.set(chatId, new Map());
    slowModeLast.get(chatId)!.set(senderId, Date.now());
  }

  const member = members.find((m: any) => m.userId === senderId) || null;
  return { chat, member };
}

/**
 * Membership-epoch check for GROUP sends (external-audit E2EE-01/E2EE-02).
 * The client declares the membership_version it composed the message under;
 * anything other than the server's current value is rejected — stale versions
 * (member missed the rotation event) and future versions (forged/impossible)
 * both fail closed. Returns the server's current version for recovery.
 * 1:1 and channel chats are skipped (no sender-key epochs there).
 */
export async function assertMembershipFresh(
  db: any,
  chatId: string,
  clientMv: unknown,
): Promise<number> {
  const chat = db.getChatInfo(chatId);
  if (!chat) throw new SendBlockedError("المحادثة غير موجودة.");
  if (chat.type !== "group") return db.getMembershipVersion(chatId);
  const serverMv = db.getMembershipVersion(chatId);
  const mv = Number(clientMv);
  if (!Number.isFinite(mv)) {
    throw new MembershipStaleError(
      "نسخة عضوية المجموعة مطلوبة — حدّث التطبيق وأعد الإرسال.",
      serverMv,
    );
  }
  if (mv !== serverMv) {
    throw new MembershipStaleError(
      "تركيبة المجموعة تغيّرت — سيُعاد توليد مفاتيح التشفير ثم إعادة الإرسال.",
      serverMv,
    );
  }
  return serverMv;
}
