/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, Suspense } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { AuthScreen } from './components/PhoneAuthScreen.tsx';
import { ChatSidebar } from './components/ChatSidebar.tsx';
import { ChatWindow } from './components/ChatWindow.tsx';
// Call-critical surfaces stay eager (call UX latency matters); core chat
// surfaces (ChatSidebar/ChatWindow/ToastProvider) also stay eager.
import { CallInterface } from './components/CallInterface.tsx';
import type { GroupCallTile } from './components/GroupCallView.tsx';
import { GroupCallMesh } from './lib/groupCallMesh.ts';
import { ShieldCheck, Cpu, Activity, Lock, AlertTriangle, Bell, Download, X, Share, Plus, Phone, Video, Users } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import type { ClientMessage } from './types.ts';
import { RealTimeSocketClient } from './lib/socket_client.ts';
import { OutboxDB } from './lib/outbox_db.ts';
import { SocketManager } from './lib/socket_manager.ts';
import { MessagesCacheDB } from './lib/messages_cache_db.ts';
import { ChatsCacheDB } from './lib/chats_cache_db.ts';
import * as TokenVault from './lib/token_vault.ts';
import { tuneOpusSdp, optsForMode, buildAudioConstraints } from './lib/audioTuning.ts';
import { buildVideoConstraints, tuneVideoSender, preferEfficientVideoCodecs } from './lib/videoTuning.ts';
import { DirashaE2EE } from './lib/e2ee/engine.ts';
// Media E2EE: attachment bytes are encrypted client-side; only the encrypted
// blob is uploaded, the decryption payload rides INSIDE the text envelope.
import { encryptAttachment, buildEncryptedPayload, parseEncryptedPayload, isAlreadyEncryptedAttachment } from './lib/e2ee/media.ts';
import { VaultKVStore, IndexedDBKekStore } from './lib/e2ee/vault.ts';
import { fetchAllUsersPaginated } from './lib/users_paging.ts';
// Group E2EE (Sender Keys): one sender key per member per group; messages are
// 'DIRG1:...' envelopes; member keys travel PAIRWISE through the 1:1 engine
// as ctrl payloads ('dirasha-ctrl-v1') relayed over the 'e2ee:ctrl' WS channel.
import { GroupCrypto, GROUP_WIRE_PREFIX, GROUP_CTRL_KIND, isCtrlPayload, isRosterMember, rosterMemberIds, SELF } from './lib/e2ee/group.ts';
import { IndexedDBKVStore } from './lib/e2ee/store.ts';
import { uploadFileToDrive } from './lib/storageUtils.ts';
// Task C (verified state + rekey warning): shared localStorage key builders
// ('e2eeVerified' / 'e2eeRekey' / 'e2eeLastSN') live next to the safety modal.
import { e2eeVerifiedKey, e2eeRekeyFlagKey, e2eeLastSnKey } from './components/E2eeSafetyModal.tsx';

// ── Code-splitting ─────────────────────────────────────────────────────────
// Heavy, feature-isolated components rendered conditionally in App are lazy:
// their code moves into separate async chunks fetched on first open. Each
// render site is wrapped in <Suspense fallback={<LazyChunkFallback />}>.
// NOTE: AdminDashboard / GroupCreateModal / GroupSettingsPanel / TwoFactorCard /
// StorageLinkCard / MediaGate are imported by ChatSidebar/ChatWindow (kept
// eager intentionally — core UX), so they cannot be split from App alone.
const UserProfileModal = React.lazy(() => import('./components/UserProfileModal.tsx').then(m => ({ default: m.UserProfileModal })));
const E2eeBackupPanel = React.lazy(() => import('./components/E2eeBackupPanel.tsx').then(m => ({ default: m.E2eeBackupPanel })));
const ActiveSessionsPanel = React.lazy(() => import('./components/ActiveSessionsPanel.tsx').then(m => ({ default: m.ActiveSessionsPanel })));
const ImageEditor = React.lazy(() => import('./components/ImageEditor.tsx').then(m => ({ default: m.ImageEditor })));
const VideoStudio = React.lazy(() => import('./components/VideoStudio.tsx').then(m => ({ default: m.VideoStudio })));
const ReportModal = React.lazy(() => import('./components/ReportModal.tsx').then(m => ({ default: m.ReportModal })));
const ModerationCenter = React.lazy(() => import('./components/ModerationCenter.tsx').then(m => ({ default: m.ModerationCenter })));
const GroupCallView = React.lazy(() => import('./components/GroupCallView.tsx').then(m => ({ default: m.GroupCallView })));

/** Minimal dark-theme spinner shown while an async chunk loads. */
function LazyChunkFallback() {
  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-[#0a0a0a]/95 backdrop-blur-md">
      <div className="w-8 h-8 rounded-full border-2 border-white/10 border-t-emerald-500 animate-spin" />
    </div>
  );
}

/* ══ Security event monitoring (structured, content-free, bounded ring) ══════
 *
 * Single choke point for client-side security events. Every event is:
 *   1. logged as ONE structured console.warn line ([SEC-EVENT] JSON), and
 *   2. stored into a bounded localStorage ring 'secEvents:<uid>' (max 50,
 *      oldest evicted first) so a user can review/share their device's
 *      security history without any server round-trip.
 * Existing toast surfaces stay exactly where they are — pushSecurityEvent is
 * ADDITIVE and never replaces or blocks a user-facing flow.
 *
 * CONTENT-FREE BY CONTRACT: `detail` may carry ONLY metadata (ids, kinds,
 * reasons, HTTP statuses). Detail values are sanitized defensively (scalars
 * only, strings truncated to 200 chars) and must never include message text,
 * attachment data, contact lists or any other user content.
 *
 * Event kinds (documented in docs/security/REMEDIATION_EXECUTION_PLAN.md, F19):
 *   - 'identity-change'   : a peer's identity/fleet keys were re-registered
 *                           (server 'e2ee:rekey' signal → local session drop).
 *   - 'kt-failure'        : Key Transparency verification failure / flag raise
 *                           (emitted by kt-client.ts via the window bridge).
 *   - 'pq-downgrade'      : a PQ downgrade attempt was rejected (TamperedError
 *                           'pq downgraded' on the send path).
 *   - 'tamper-detected'   : any other TamperedError on the send path.
 *   - 'authz-denied'      : authorization denial — e.g. a group key-request
 *                           from a non-member dropped (audit H1 choke point).
 *   - 'rate-limit'        : a client-observed rate-limit trip (HTTP 429).
 *   - 'migration-failure' : a token/credential migration failure (legacy
 *                           refresh-token discard after a revocation anomaly).
 *   - 'backup-failure'    : an E2EE backup/export failure (reserved kind —
 *                           emitted via the same bridge by backup surfaces).
 *   - 'auth-alert'        : server-pushed auth security alerts (new login,
 *                           failed attempt, password change).
 *
 * Transport failures are NEVER events by themselves (availability-first:
 * flaky networks must not pollute the security log) — only definitive
 * contradictions, denials and limit trips are recorded.
 */
export type SecurityEventKind =
  | 'identity-change'
  | 'kt-failure'
  | 'downgrade'
  | 'pq-downgrade'
  | 'tamper-detected'
  | 'authz-denied'
  | 'rate-limit'
  | 'migration-failure'
  | 'backup-failure'
  | 'auth-alert';

const SEC_EVENTS_MAX = 50; // bounded ring size per uid
const SEC_DETAIL_STR_MAX = 200; // per-string cap (defensive, metadata only)

function secEventUid(): string {
  try {
    const stored = localStorage.getItem('dirasha_user');
    if (stored) {
      const u = JSON.parse(stored);
      const uid = u?.uid || u?.id;
      if (typeof uid === 'string' && uid) return uid;
    }
  } catch { /* fall through to anon */ }
  return 'anon';
}

/** Defensive detail sanitizer: scalars only, strings truncated, no objects. */
function sanitizeSecDetail(detail: Record<string, unknown>): Record<string, string | number | boolean> {
  const out: Record<string, string | number | boolean> = {};
  for (const [k, v] of Object.entries(detail || {})) {
    if (typeof v === 'string') out[k] = v.slice(0, SEC_DETAIL_STR_MAX);
    else if (typeof v === 'number' && Number.isFinite(v)) out[k] = v;
    else if (typeof v === 'boolean') out[k] = v;
    // arrays/objects/functions/undefined are dropped — content cannot sneak in
  }
  return out;
}

/** The ONE entry point for client security events (also the engine bridge). */
export function pushSecurityEvent(kind: SecurityEventKind, detail: Record<string, unknown> = {}): void {
  try {
    const entry = { kind, at: new Date().toISOString(), ...sanitizeSecDetail(detail) };
    console.warn('[SEC-EVENT]', JSON.stringify(entry));
    const key = `secEvents:${secEventUid()}`;
    let arr: unknown[] = [];
    try {
      const raw = localStorage.getItem(key);
      const parsed = raw ? JSON.parse(raw) : [];
      if (Array.isArray(parsed)) arr = parsed;
    } catch { /* corrupt ring → restart empty */ }
    arr.push(entry);
    while (arr.length > SEC_EVENTS_MAX) arr.shift(); // bounded: oldest evicted
    localStorage.setItem(key, JSON.stringify(arr));
  } catch { /* monitoring must NEVER throw into app flows */ }
}

// Module-scope bridge install: kt-client.ts (engine paths, fire-and-forget)
// calls (globalThis as any).pushSecurityEvent — available from the moment the
// App module loads, before any React component mounts.
if (typeof window !== 'undefined') {
  (window as any).pushSecurityEvent = pushSecurityEvent;
}

function isTokenExpired(token: string | null): boolean {
  if (!token) return true;
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return true;
    // Decode base64 payload safely and parses json
    const payload = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
    if (!payload.exp) return false;
    return payload.exp * 1000 < Date.now() + 10000; // 10-second buffer
  } catch (e) {
    return true;
  }
}

import { ToastProvider, useToast } from './components/ToastProvider.tsx';

// T5: Multi-provider ICE configuration — pluggable via env only, so a private
// coturn can replace the public defaults without touching any call code.
function buildIceConfig(): RTCIceServer[] {
  const env = (import.meta.env as any) || {};
  const DEFAULT_STUNS = 'stun:stun.l.google.com:19302,stun:stun1.l.google.com:19302,stun:stun2.l.google.com:19302,stun:stun3.l.google.com:19302,stun:stun.relay.metered.ca:80,stun:global.stun.twilio.com:3478';
  const DEFAULT_TURNS = 'turn:openrelay.metered.ca:80,turn:openrelay.metered.ca:443,turn:openrelay.metered.ca:443?transport=tcp';
  const stunUrls = String(env.VITE_STUN_URLS || env.STUN_URLS || DEFAULT_STUNS)
    .split(',').map((s: string) => s.trim()).filter(Boolean);
  const turnUrls = String(env.VITE_TURN_URLS || env.TURN_URLS || DEFAULT_TURNS)
    .split(',').map((s: string) => s.trim()).filter(Boolean);
  const turnUsername = String(env.VITE_TURN_USERNAME || env.TURN_USERNAME || 'openrelay');
  const turnCredential = String(env.VITE_TURN_CREDENTIAL || env.TURN_CREDENTIAL || 'openrelay');
  const iceServers: RTCIceServer[] = stunUrls.map(urls => ({ urls }));
  if (turnUrls.length > 0) {
    iceServers.push({ urls: turnUrls, username: turnUsername, credential: turnCredential });
  }
  return iceServers;
}

/**
 * Quiet-hours enforcement: suppresses notification sound/vibration/desktop
 * popups inside the user's configured window (supports overnight ranges).
 */
function isWithinQuietHours(qh: any, now = new Date()): boolean {
  if (!qh?.enabled || !qh.from || !qh.to) return false;
  const [fh, fm] = String(qh.from).split(':').map(Number);
  const [th, tm] = String(qh.to).split(':').map(Number);
  if (Number.isNaN(fh) || Number.isNaN(th)) return false;
  const mins = now.getHours() * 60 + now.getMinutes();
  const from = fh * 60 + (fm || 0);
  const to = th * 60 + (tm || 0);
  return from <= to ? (mins >= from && mins < to) : (mins >= from || mins < to);
}

/**
 * Audio sender priority (WebRTC API): mark the audio sender high-priority with
 * an explicit max bitrate so network congestion degrades video — never voice.
 */
async function tuneAudioSender(pc: RTCPeerConnection | null, mode?: string) {
  if (!pc) return;
  try {
    const sender = pc.getSenders().find(s => s.track?.kind === 'audio');
    if (!sender) return;
    const bitrate = optsForMode(mode).maxBitrate;
    const params = sender.getParameters();
    params.encodings = params.encodings?.length ? params.encodings : [{}];
    params.encodings[0].maxBitrate = bitrate;
    params.encodings[0].priority = 'high';
    params.encodings[0].networkPriority = 'high';
    await sender.setParameters(params).catch(() => {});
  } catch { /* non-fatal */ }
}

/**
 * Call-environment advisories (fire once per call, non-blocking):
 * 1) Headphone check — speakers-only + echo cancellation → suggest headphones.
 * 2) Cellular advisory — slow mobile data → recommend WiFi for stability.
 */
/**
 * getUserMedia with a stall watchdog: on weak phones under device contention
 * the capture promise can hang indefinitely (no resolve, no reject). We race a
 * timeout, stop half-opened tracks, and retry once with relaxed constraints
 * before surfacing a clear error instead of a dead "calling…" screen.
 */
async function gUMWithWatchdog(
  constraints: MediaStreamConstraints,
  timeoutMs = 10000,
  retries = 1,
): Promise<MediaStream> {
  for (let attempt = 0; attempt <= retries; attempt++) {
    let stream: MediaStream | null = null;
    try {
      stream = await Promise.race([
        navigator.mediaDevices.getUserMedia(constraints),
        new Promise<MediaStream>((_, reject) =>
          setTimeout(() => reject(new Error('gum-watchdog-timeout')), timeoutMs),
        ),
      ]);
      return stream as MediaStream;
    } catch (err: any) {
      // Stop any late-resolving stream so tracks don't leak past the watchdog
      Promise.race([
        navigator.mediaDevices.getUserMedia(constraints).catch(() => null),
      ]).then((late) => {
        (late as MediaStream | null)?.getTracks().forEach(t => t.stop());
      });
      if (attempt < retries) {
        console.warn('[CallManager] gUM stalled/failed — retrying with relaxed constraints:', err?.message);
        constraints = {
          audio: true,
          video: (constraints.video && typeof constraints.video === 'object')
            ? { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } } as MediaTrackConstraints
            : constraints.video,
        };
        continue;
      }
      throw err;
    }
  }
  throw new Error('unreachable');
}

/**
 * WhatsApp-parity media acquisition: getUserMedia raced against a SINGLE hard
 * timeout — no aggressive early watchdog and no retry that could abort while
 * the user is still reading the browser permission prompt. On a real device
 * the prompt stays pending until the user taps Allow, so 1:1 calls give audio
 * up to 45s (prompt reaction time) and video 15s (best-effort). A late-resolving
 * stream after the timeout is stopped so tracks never leak.
 */
function gUMWithTimeout(
  constraints: MediaStreamConstraints,
  timeoutMs: number,
  timeoutError: Error,
): Promise<MediaStream> {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      reject(timeoutError);
    }, timeoutMs);
    navigator.mediaDevices.getUserMedia(constraints).then(
      (stream) => {
        if (settled) {
          // Resolved after the timeout already fired — release the tracks.
          stream.getTracks().forEach(t => { try { t.stop(); } catch (_) {} });
          return;
        }
        settled = true;
        clearTimeout(timer);
        resolve(stream);
      },
      (err) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        reject(err);
      },
    );
  });
}

// 1:1 call media windows: audio must survive a slow permission prompt; video
// is best-effort and downgrades the call to voice on any failure.
const AUDIO_GUM_TIMEOUT_MS = 45000;
const VIDEO_GUM_TIMEOUT_MS = 15000;
const MIC_FAILURE_MSG = 'تعذر الحصول على المايك — تحقق من إذن المايكروفون ثم أعد المحاولة.';
const CAMERA_DOWNGRADE_MSG = '📺 لم يتم منح إذن الكاميرا — المتابعة كمكالمة صوتية';

async function adviseCallEnvironment(showToast: (t: string, type: string) => void) {
  try {
    if (!navigator.mediaDevices?.enumerateDevices) return;
    const devices = await navigator.mediaDevices.enumerateDevices();
    const audioOutputs = devices.filter(d => d.kind === 'audiooutput').length;
    if (audioOutputs <= 1 && (window as any).showGlobalToast) {
      showToast('💡 نصيحة: استخدم سماعات رأس لصوت أوضح ولمنع الصدى.', 'info');
    }
    const conn = (navigator as any).connection;
    if (conn && ['slow-2g', '2g', '3g'].includes(conn.effectiveType) && (window as any).showGlobalToast) {
      showToast('📶 شبكة بيانات بطيئة — مكالمة عبر WiFi أكثر ثباتاً ووضوحاً.', 'info');
    }
  } catch { /* advisory only */ }
}

/* P1-H (external-audit AUTH-05): short-lived SCOPED media tokens for the
 * App-level attachment paths — the long-lived access JWT must never appear in
 * media URLs (server-side policy already restricts query tokens to
 * purpose:'media' GETs). Cached ~90s with an in-flight guard; failures leave
 * URLs WITHOUT a token (honest 401 — no silent fallback to the access JWT).
 * Mirrors the ChatWindow.tsx helper of the same pattern.
 */
let appMediaTokenCache: { token: string; exp: number } | null = null;
const appMediaTokenInflight: { p: Promise<string | null> | null } = { p: null };
async function getAppScopedMediaToken(accessToken: string): Promise<string | null> {
  if (appMediaTokenCache && appMediaTokenCache.exp > Date.now() + 5000) return appMediaTokenCache.token;
  if (appMediaTokenInflight.p) return appMediaTokenInflight.p;
  const p = (async () => {
    try {
      const res = await fetch('/api/media-token', { headers: { Authorization: 'Bearer ' + accessToken } });
      const d = await res.json().catch(() => null);
      if (!res.ok || !d?.token) return null;
      appMediaTokenCache = { token: String(d.token), exp: Date.now() + 90_000 };
      return appMediaTokenCache.token;
    } catch {
      return null;
    } finally {
      appMediaTokenInflight.p = null;
    }
  })();
  appMediaTokenInflight.p = p;
  return p;
}

function AppContent() {
  const { showToast } = useToast();
  
  // Set up global hook for components that might not have easy access
  useEffect(() => {
    (window as any).showGlobalToast = showToast;
  }, [showToast]);

  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [currentUser, setCurrentUser] = useState<any | null>(null);
  const [checkingAuth, setCheckingAuth] = useState(true);
  const [isFreshLogin, setIsFreshLogin] = useState(false);
  const [showPWAInstallPrompt, setShowPWAInstallPrompt] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  
  // Real-time security PIN lock states
  const [passcodeUnlocked, setPasscodeUnlocked] = useState<boolean>(false);
  const [typedPin, setTypedPin] = useState<string>('');
  const [pinError, setPinError] = useState<string | null>(null);
  const [pinShake, setPinShake] = useState<boolean>(false);

  // AUTH-04 (external audit): the screen lock is a UI convenience ONLY — it is
  // NOT a security boundary and never decrypts anything. There is NO default
  // passcode: while no passcode has been set the lock screen must not appear
  // at all (feature disabled until the user sets one), and the PIN comparison
  // never falls back to a well-known constant.
  const screenLockPasscode = typeof currentUser?.privacySettings?.screenLockPasscode === 'string'
    ? currentUser.privacySettings.screenLockPasscode
    : '';
  const showLockScreen = !!currentUser?.privacySettings?.screenLockEnabled
    && screenLockPasscode.length === 4
    && !passcodeUnlocked;

  const handleKeyPress = (num: string) => {
    if (typedPin.length >= 4) return;
    setPinError(null);
    const newPin = typedPin + num;
    setTypedPin(newPin);

    if (newPin.length === 4) {
      // Fail-closed: with no 4-digit passcode set nothing ever matches (and
      // the lock screen is gated off above anyway).
      const correctPin = screenLockPasscode;
      if (correctPin.length === 4 && newPin === correctPin) {
        setPasscodeUnlocked(true);
        setTypedPin('');
      } else {
        setPinShake(true);
        setPinError('INVALID PIN');
        setTimeout(() => {
          setPinShake(false);
          setTypedPin('');
        }, 800);
      }
    }
  };

  const handleBackspace = () => {
    setPinError(null);
    setTypedPin(prev => prev.slice(0, -1));
  };

  useEffect(() => {
    if (!showLockScreen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key >= '0' && e.key <= '9') {
        handleKeyPress(e.key);
      } else if (e.key === 'Backspace') {
        handleBackspace();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showLockScreen, typedPin]);

  // Stable primitive identifier
  const currentUserId = currentUser?.uid || currentUser?.id || '';

  const queryClient = useQueryClient();
  const [targetStatusData, setTargetStatusData] = useState<{ statusId: string; userId: string } | null>(null);
  const [statusFile, setStatusFile] = useState<File | null>(null);
  const [isUploadingStatus, setIsUploadingStatus] = useState(false);

  const handleStatusFileChange = (file: File | null) => {
    if (!file) {
      setStatusFile(null);
      return;
    }

    // Limit maximum size to 7MB (7 * 1024 * 1024 bytes)
    const MAX_METADATA_SIZE = 7 * 1024 * 1024;
    if (file.size > MAX_METADATA_SIZE) {
      if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
        (window as any).showGlobalToast('حجم الملف كبير جداً! أقصى حجم مسموح به للحالة هو 7 ميجابايت', 'error');
      }
      return;
    }

    // Limit maximum video duration to 1 minute (60 seconds)
    if (file.type.startsWith('video/')) {
      const tempVideo = document.createElement('video');
      tempVideo.preload = 'metadata';
      tempVideo.src = URL.createObjectURL(file);
      tempVideo.onloadedmetadata = () => {
        URL.revokeObjectURL(tempVideo.src);
        if (tempVideo.duration > 61) { // 61 seconds to capture minor encoding roundings gracefully
          if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
            (window as any).showGlobalToast('حالة الفيديو طويلة جداً! يجب ألا تزيد مدة الحالة عن دقيقة واحدة', 'error');
          }
        } else {
          setStatusFile(file);
        }
      };
      
      tempVideo.onerror = () => {
        URL.revokeObjectURL(tempVideo.src);
        if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
          (window as any).showGlobalToast('عذراً، فشل قراءة ملف الفيديو المحدد', 'error');
        }
      };
      return;
    }

    // Set normal image files directly
    setStatusFile(file);
  };

  const performSilentTokenRefresh = async () => {
    try {
      // P1-hardening: refresh token comes from the HttpOnly cookie (credentials:
      // same-origin). The legacy localStorage token is sent once for migration.
      const legacyRefresh = TokenVault.getLegacyRefreshToken();
      const res = await fetch('/api/auth/refresh', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ refreshToken: legacyRefresh || '' })
      });
      if (res.ok) {
        const data = await res.json();
        if (data.accessToken && data.user) {
          console.log('[App Security Engine] Silent token refresh executed.');
          setAccessToken(data.accessToken);
          setCurrentUser(data.user);
          TokenVault.setAccessToken(data.accessToken);
          localStorage.setItem('dirasha_user', JSON.stringify(data.user));
          if (data.sessionId) {
            TokenVault.setSessionId(data.sessionId);
          }
          TokenVault.clearLegacyRefreshToken();
          // E2EE: re-confirm registration after each successful token
          // acquisition (idempotent, fire-and-forget).
          e2eeRef.current?.ensureRegistered().catch(() => {});
          return data.accessToken;
        }
      } else if (res.status === 403) {
        // Revocation anomaly — the legacy token is dead server-side; discard it.
        TokenVault.clearLegacyRefreshToken();
      }
    } catch (err) {
      console.warn('[App Security Engine] Silent token refresh error:', err);
    }
    return null;
  };

  // WebSocket custom infrastructure states
  const [websocketConnected, setWebsocketConnected] = useState(false);
  const socketClientRef = useRef<RealTimeSocketClient | null>(null);
  const joinedRoomsRef = useRef<Set<string>>(new Set());

  // WebRTC Call state definitions
  const [activeCall, setActiveCall] = useState<{
    callId: string;
    chatId: string;
    role: 'caller' | 'callee';
    partnerId: string;
    partnerName: string;
    partnerAvatar?: string;
    status: 'calling' | 'ringing' | 'connecting' | 'connected' | 'ended';
    type: 'voice' | 'video';
    // True when the call started as 'video' but the camera was denied/unavailable
    // and the call continues as voice (WhatsApp parity — never kill the call).
    videoDowngraded?: boolean;
    offer?: any;
  } | null>(null);

  const activeCallRef = useRef<typeof activeCall>(null);
  useEffect(() => {
    activeCallRef.current = activeCall;
  }, [activeCall]);

  const localStreamRef = useRef<MediaStream | null>(null);
  const [localStream, setLocalStreamState] = useState<MediaStream | null>(null);
  const remoteStreamRef = useRef<MediaStream | null>(null);
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const [peerConnectionState, setPeerConnectionState] = useState<RTCPeerConnection | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const iceCandidatesBufferRef = useRef<RTCIceCandidateInit[]>([]);

  // T1: ICE healing state — grace timer for 'disconnected' + one-shot 'failed' restart
  const iceGraceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const failedRestartTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const failedEndTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const iceRestartAttemptedRef = useRef(false);
  const weakVideoTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // ── Group-call state (FULLY separate from the 1:1 activeCall machine) ──
  const [groupCallState, setGroupCallState] = useState<{
    groupCallId: string;
    chatId: string;
    chatName: string;
    initiatorId: string;
    type: 'voice' | 'video';
    status: 'joining' | 'connecting' | 'connected' | 'ended';
  } | null>(null);
  const groupCallStateRef = useRef<typeof groupCallState>(null);
  useEffect(() => { groupCallStateRef.current = groupCallState; }, [groupCallState]);

  const [groupCallTiles, setGroupCallTiles] = useState<GroupCallTile[]>([]);
  const groupCallTilesRef = useRef<GroupCallTile[]>([]);
  useEffect(() => { groupCallTilesRef.current = groupCallTiles; }, [groupCallTiles]);

  const [groupRemoteStreams, setGroupRemoteStreams] = useState<Record<string, MediaStream>>({});
  const [groupLocalStream, setGroupLocalStreamState] = useState<MediaStream | null>(null);
  const groupLocalStreamRef = useRef<MediaStream | null>(null);
  const groupMeshRef = useRef<GroupCallMesh | null>(null);
  const [groupIsMuted, setGroupIsMuted] = useState(false);
  const [groupIsCameraOff, setGroupIsCameraOff] = useState(false);
  // Group screen sharing: the getDisplayMedia stream replaces the camera in
  // every mesh video sender via mesh.setScreenShare().
  const [groupScreenShare, setGroupScreenShare] = useState<{ stream: MediaStream; track: MediaStreamTrack } | null>(null);
  const groupScreenShareRef = useRef<{ stream: MediaStream; track: MediaStreamTrack } | null>(null);
  useEffect(() => { groupScreenShareRef.current = groupScreenShare; }, [groupScreenShare]);
  const groupScreenEndedHandlerRef = useRef<(() => void) | null>(null);
  const groupCameraWasEnabledRef = useRef<boolean>(true);
  const [groupIncomingInvite, setGroupIncomingInvite] = useState<{
    groupCallId: string;
    chatId: string;
    chatName: string;
    initiatorId: string;
    initiatorName: string;
    type: 'voice' | 'video';
  } | null>(null);
  const groupInviteTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const cleanupCallState = () => {
    console.log('[CallManager] Performing PeerConnection & MediaStream Cleanup');

    // T1: clear any pending ICE healing timers on teardown
    if (iceGraceTimerRef.current) { clearTimeout(iceGraceTimerRef.current); iceGraceTimerRef.current = null; }
    if (failedRestartTimerRef.current) { clearTimeout(failedRestartTimerRef.current); failedRestartTimerRef.current = null; }
    if (failedEndTimerRef.current) { clearTimeout(failedEndTimerRef.current); failedEndTimerRef.current = null; }
    iceRestartAttemptedRef.current = false;

    setActiveCall(null);
    setRemoteStream(null);
    iceCandidatesBufferRef.current = [];

    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop());
      localStreamRef.current = null;
    }
    setLocalStreamState(null);

    if (peerConnectionRef.current) {
      try {
        peerConnectionRef.current.close();
      } catch (e) {}
      peerConnectionRef.current = null;
    }
    setPeerConnectionState(null);
    
    remoteStreamRef.current = null;
  };

  const dispatchSystemCallMessage = async (call: any, reason: string) => {
    if (!call || !call.chatId || !currentUser || !socketClientRef.current || !websocketConnected) return;

    let content = '';
    const isVideo = call.type === 'video';
    
    // Logic: Map reasons and status into nice Arabic localization strings without the emoji phone string
    if (reason === 'no-answer' || (reason === 'ended' && (call.status === 'ringing' || call.status === 'dialing'))) {
       content = `مكالمة ${isVideo ? 'فيديو ' : ''}فائتة`;
    } else if (reason === 'busy') {
       content = `مشغول - مكالمة ${isVideo ? 'فيديو ' : 'صوتية '}`;
    } else if (reason === 'rejected') {
       content = `مكالمة ${isVideo ? 'فيديو ' : ''}مرفوضة`;
    } else if (reason === 'ended' && (call.status === 'connected' || call.status === 'connecting')) {
       content = `انتهت مكالمة ال${isVideo ? 'فيديو' : 'صوت'}`;
    } else if (reason === 'disconnected') {
       content = `انقطع الاتصال - مكالمة ${isVideo ? 'فيديو ' : ''}`;
    } else {
       content = `مكالمة ${isVideo ? 'فيديو ' : ''}${reason === 'ended' ? 'فائتة' : reason}`;
    }

    const clientMessageId = crypto.randomUUID();
    const nowIso = new Date().toISOString();

    console.log('[dispatchSystemCallMessage] Dispatching call log item:', content, call.chatId);

    // BATCH-3 (DIR-CB-05): call-log text rides the SAME encryption choke point
    // as every other send — plaintext call logs were rejected by the ingress
    // gate and silently lost. Encryption failure = skip the log (fail-closed,
    // metadata-tier content) — never a plaintext fallback.
    let wireContent = content;
    try {
      wireContent = await encryptContentForChat(call.chatId, content);
    } catch (e: any) {
      console.warn('[dispatchSystemCallMessage] skipped (encryption unavailable):', e?.message || e);
      return;
    }

    socketClientRef.current.emit('msg:send', {
      tempMessageId: clientMessageId,
      chatId: call.chatId,
      content: wireContent,
      type: 'call',
      attachments: [],
      replyTo: null,
      mv: (rawChatsRef.current || []).find((c: any) => c?.id === call.chatId)?.membershipVersion,
      clientSendTimestamp: Date.now()
    });
  };

  const handleEndCall = () => {
    const currentCall = activeCallRef.current;
    if (!currentCall) return;

    console.log(`[CallManager] Ending voice call: ${currentCall.callId}`);
    if (socketClientRef.current) {
      socketClientRef.current.emit('call:end', {
        callId: currentCall.callId,
        receiverId: currentCall.partnerId,
        reason: 'ended'
      });
      
      // Dispatch system message log if we are the caller (to avoid duplicate from both sides)
      if (currentCall.role === 'caller') {
        dispatchSystemCallMessage(currentCall, 'ended');
      }
    }

    setActiveCall(prev => prev ? { ...prev, status: 'ended' } : null);
    setTimeout(() => {
      cleanupCallState();
    }, 1000);
  };

  // T1: coordinated ICE restart — heal the local ICE agent and ask the peer
  // to restart theirs so both sides re-gather candidates in sync.
  const requestIceRestart = (pc: RTCPeerConnection, callId: string, peerId: string, reason: string) => {
    console.log(`[CallManager] Requesting ICE restart for call ${callId} (trigger: ${reason})`);
    try {
      pc.restartIce();
    } catch (e) {
      console.warn('[CallManager] restartIce() unavailable on this browser:', e);
    }
    if (socketClientRef.current) {
      socketClientRef.current.emit('call:signal', {
        callId,
        receiverId: peerId,
        signal: { iceRestart: true },
        sentAt: Date.now()
      });
    }
  };

  // ── Group-call handlers (mesh, ≤4 participants) ──────────────────────

  const teardownGroupCall = (leaveServer = true) => {
    const gc = groupCallStateRef.current;
    if (leaveServer && gc && gc.groupCallId) {
      try {
        socketClientRef.current?.emit('groupcall:leave', { groupCallId: gc.groupCallId });
      } catch (_) { /* non-fatal */ }
      fetch(`/api/group-calls/${encodeURIComponent(gc.groupCallId)}/leave`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${accessToken}` }
      }).catch(() => { /* idempotent — best effort */ });
    }
    if (groupMeshRef.current) {
      groupMeshRef.current.leave();
      groupMeshRef.current = null;
    }
    // Screen share must never outlive the call: detach its 'ended' listener
    // and stop the getDisplayMedia tracks (the camera tracks are stopped below).
    const sharedScreen = groupScreenShareRef.current;
    const endedHandler = groupScreenEndedHandlerRef.current;
    if (sharedScreen && endedHandler) {
      try { sharedScreen.track.removeEventListener('ended', endedHandler); } catch (_) { /* already detached */ }
    }
    groupScreenEndedHandlerRef.current = null;
    groupScreenShareRef.current = null;
    if (sharedScreen) {
      sharedScreen.stream.getTracks().forEach(t => { try { t.stop(); } catch (_) { /* already stopped */ } });
    }
    setGroupScreenShare(null);
    if (groupLocalStreamRef.current) {
      groupLocalStreamRef.current.getTracks().forEach(t => t.stop());
      groupLocalStreamRef.current = null;
    }
    setGroupLocalStreamState(null);
    setGroupRemoteStreams({});
    setGroupCallTiles([]);
    setGroupIsMuted(false);
    setGroupIsCameraOff(false);
    setGroupCallState(null);
  };

  const leaveGroupCall = () => {
    console.log('[GroupCallManager] Leaving group call');
    teardownGroupCall(true);
    if ((window as any).showGlobalToast) {
      (window as any).showGlobalToast('تمت مغادرة المكالمة الجماعية.', 'info');
    }
  };

  /** Shared mesh dial: acquire media (gUM watchdog), join the mesh, wire signaling to the WS relay. */
  const joinGroupMesh = async (
    gc: { groupCallId: string; chatId: string; chatName: string; initiatorId: string; type: 'voice' | 'video' },
    roster: string[],
  ) => {
    if (!currentUserId || !socketClientRef.current) return;

    setGroupCallTiles(roster
      .filter(id => id && id !== currentUserId)
      .map(id => ({
        userId: id,
        displayName: allUsersRef.current[id]?.displayName || 'عضو المجموعة',
        avatarUrl: allUsersRef.current[id]?.avatarUrl,
        state: 'connecting' as const,
      })));

    try {
      const stream = await gUMWithWatchdog({
        // Audio-processing toggles (user settings) — same pattern as the 1:1 call
        audio: { ...buildAudioConstraints(currentUser?.chatSettings?.audioProcessing) },
        // Bounded video capture (720p30, hard max)
        video: gc.type === 'video' ? { facingMode: 'user', ...buildVideoConstraints() } : false
      }).catch(err => {
        console.error('[GroupCallManager] Media permission error:', err);
        throw new Error('تعذر الوصول إلى الكاميرا أو الميكروفون. يرجى تفعيل إذن الكاميرا والميكروفون في المتصفح.');
      });

      groupLocalStreamRef.current = stream;
      setGroupLocalStreamState(stream);
      adviseCallEnvironment((window as any).showGlobalToast ?? (() => {}));

      const mesh = new GroupCallMesh();
      groupMeshRef.current = mesh;
      await mesh.join({
        groupCallId: gc.groupCallId,
        myId: currentUserId,
        participants: roster,
        getUserMediaStream: async () => stream,
        // T5 parity: same multi-provider ICE config + optional relay-only privacy policy
        iceServers: buildIceConfig(),
        iceTransportPolicy: currentUser?.privacySettings?.callRelayEnabled ? 'relay' : 'all',
        sendSignal: (groupCallId, toUserId, signal) => {
          socketClientRef.current?.emit('groupcall:signal', {
            groupCallId,
            receiverId: toUserId,
            signal,
            sentAt: Date.now()
          });
        },
        callbacks: {
          onTrack: (peerId, remoteStream) => {
            setGroupRemoteStreams(prev => ({ ...prev, [peerId]: remoteStream }));
          },
          onParticipantConnected: (peerId) => {
            setGroupCallTiles(prev => prev.map(t => t.userId === peerId ? { ...t, state: 'connected' } : t));
            setGroupCallState(prev => prev && prev.groupCallId === gc.groupCallId && prev.status === 'connecting'
              ? { ...prev, status: 'connected' } : prev);
          },
          onParticipantLeft: (peerId) => {
            setGroupCallTiles(prev => prev.map(t => t.userId === peerId ? { ...t, state: 'left' } : t));
          },
          onError: (peerId, err) => {
            console.warn(`[GroupCallManager] Mesh error for peer ${peerId || '?'}:`, err);
          },
        },
      });

      // Presence broadcast: existing participants learn to dial us (late joiner).
      socketClientRef.current.emit('groupcall:joined', { groupCallId: gc.groupCallId });

      setGroupCallState(prev => prev && prev.groupCallId === gc.groupCallId && prev.status === 'joining'
        ? { ...prev, status: 'connecting' } : prev);
    } catch (err: any) {
      console.error('[GroupCallManager] Mesh join failed:', err);
      if ((window as any).showGlobalToast) {
        (window as any).showGlobalToast(err.message || 'تعذر بدء المكالمة الجماعية.', 'error');
      }
      teardownGroupCall(true);
    }
  };

  /** Entry point (initiator): REST create → REST join → WS announce → mesh dial. */
  const startGroupCall = async (chat: any, callType: 'voice' | 'video') => {
    if (!accessToken || !currentUserId) return;
    if (activeCallRef.current || groupCallStateRef.current) {
      if ((window as any).showGlobalToast) {
        (window as any).showGlobalToast('أنت في مكالمة بالفعل — أنهِ المكالمة الحالية أولاً.', 'error');
      }
      return;
    }

    setGroupCallState({
      groupCallId: '',
      chatId: chat.id,
      chatName: chat.name || 'المجموعة',
      initiatorId: currentUserId,
      type: callType,
      status: 'joining',
    });

    try {
      const authHeaders = { 'Authorization': `Bearer ${accessToken}`, 'Content-Type': 'application/json' };

      const createRes = await fetch('/api/group-calls', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ chatId: chat.id })
      });
      if (!createRes.ok) {
        const data = await createRes.json().catch(() => ({}));
        throw new Error(data.error || 'تعذر إنشاء المكالمة الجماعية.');
      }
      const session = await createRes.json();

      // Join immediately: adds the initiator to the roster so the announce
      // broadcast passes server-side participant validation.
      const joinRes = await fetch(`/api/group-calls/${encodeURIComponent(session.groupCallId)}/join`, {
        method: 'POST',
        headers: authHeaders
      });
      if (!joinRes.ok) {
        const data = await joinRes.json().catch(() => ({}));
        throw new Error(data.error || 'تعذر الانضمام إلى المكالمة الجماعية.');
      }
      const roster = await joinRes.json();
      const rosterIds: string[] = (roster.participants || []).map((p: any) => typeof p === 'string' ? p : p.userId);

      const gc = {
        groupCallId: session.groupCallId,
        chatId: chat.id,
        chatName: chat.name || 'المجموعة',
        initiatorId: currentUserId,
        type: callType,
      };
      setGroupCallState(prev => prev && !prev.groupCallId ? { ...prev, groupCallId: session.groupCallId } : prev);

      // One-shot invite broadcast to chat members (server validates the session).
      socketClientRef.current?.emit('groupcall:announce', {
        groupCallId: session.groupCallId,
        chatId: chat.id,
        chatName: gc.chatName,
        callType,
        initiatorName: currentUser?.displayName || currentUser?.username || ''
      });

      await joinGroupMesh(gc, rosterIds);
    } catch (err: any) {
      if ((window as any).showGlobalToast) {
        (window as any).showGlobalToast(err.message || 'تعذر بدء المكالمة الجماعية.', 'error');
      }
      teardownGroupCall(true);
    }
  };

  /** Entry point (invitee): ringing banner accept → REST join → mesh dial. */
  const joinIncomingGroupCall = async (invite: NonNullable<typeof groupIncomingInvite>) => {
    if (groupInviteTimerRef.current) { clearTimeout(groupInviteTimerRef.current); groupInviteTimerRef.current = null; }
    setGroupIncomingInvite(null);

    if (activeCallRef.current || groupCallStateRef.current) {
      if ((window as any).showGlobalToast) {
        (window as any).showGlobalToast('أنت في مكالمة بالفعل — لا يمكن الانضمام الآن.', 'error');
      }
      return;
    }
    if (!accessToken || !currentUserId) return;

    setGroupCallState({
      groupCallId: invite.groupCallId,
      chatId: invite.chatId,
      chatName: invite.chatName,
      initiatorId: invite.initiatorId,
      type: invite.type,
      status: 'joining',
    });

    try {
      const joinRes = await fetch(`/api/group-calls/${encodeURIComponent(invite.groupCallId)}/join`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${accessToken}`, 'Content-Type': 'application/json' }
      });
      if (!joinRes.ok) {
        const data = await joinRes.json().catch(() => ({}));
        if (joinRes.status === 404) throw new Error('انتهت هذه المكالمة الجماعية بالفعل.');
        if (joinRes.status === 409) throw new Error('المكالمة الجماعية ممتلئة (الحد الأقصى 4 مشاركين).');
        throw new Error(data.error || 'تعذر الانضمام إلى المكالمة الجماعية.');
      }
      const roster = await joinRes.json();
      const rosterIds: string[] = (roster.participants || []).map((p: any) => typeof p === 'string' ? p : p.userId);

      await joinGroupMesh({
        groupCallId: roster.groupCallId || invite.groupCallId,
        chatId: roster.chatId || invite.chatId,
        chatName: invite.chatName,
        initiatorId: roster.initiatorId || invite.initiatorId,
        type: invite.type,
      }, rosterIds);
    } catch (err: any) {
      if ((window as any).showGlobalToast) {
        (window as any).showGlobalToast(err.message || 'تعذر الانضمام إلى المكالمة الجماعية.', 'error');
      }
      teardownGroupCall(true);
    }
  };

  const dismissGroupInvite = () => {
    if (groupInviteTimerRef.current) { clearTimeout(groupInviteTimerRef.current); groupInviteTimerRef.current = null; }
    setGroupIncomingInvite(null);
  };

  const toggleGroupMute = () => {
    const stream = groupLocalStreamRef.current;
    if (!stream) return;
    const nextMuted = !groupIsMuted;
    stream.getAudioTracks().forEach(t => { t.enabled = !nextMuted; });
    setGroupIsMuted(nextMuted);
  };

  const toggleGroupCamera = () => {
    const stream = groupLocalStreamRef.current;
    if (!stream) return;
    const nextOff = !groupIsCameraOff;
    stream.getVideoTracks().forEach(t => { t.enabled = !nextOff; });
    // While screen sharing the camera is parked (not sent); keep the
    // post-share restore target in sync with the user's intent.
    if (groupScreenShareRef.current) {
      groupCameraWasEnabledRef.current = !nextOff;
    }
    setGroupIsCameraOff(nextOff);
  };

  // ── Group screen sharing ───────────────────────────────────────────────
  // Enable: getDisplayMedia → mesh.setScreenShare(screenTrack) → every peer's
  // video sender gets replaceTrack(screenTrack). The camera track is parked
  // (enabled=false) and restored (enabled + mesh.setScreenShare(null)) after.
  const stopGroupScreenShare = async (notify: boolean) => {
    const shared = groupScreenShareRef.current;
    const mesh = groupMeshRef.current;
    const stream = groupLocalStreamRef.current;

    const endedHandler = groupScreenEndedHandlerRef.current;
    groupScreenEndedHandlerRef.current = null;
    groupScreenShareRef.current = null;
    setGroupScreenShare(null);

    if (shared && endedHandler) {
      // Detach BEFORE stopping the track — stop() itself fires 'ended'.
      try { shared.track.removeEventListener('ended', endedHandler); } catch (_) { /* already detached */ }
    }
    if (shared) {
      shared.stream.getTracks().forEach(t => { try { t.stop(); } catch (_) { /* already stopped */ } });
    }

    // Restore the camera into every sender (mesh keeps its camera reference).
    if (mesh) {
      try { await mesh.setScreenShare(null); } catch (err) {
        console.warn('[GroupCallManager] Failed to restore camera after screen share:', err);
      }
    }
    const cameraTrack = stream?.getVideoTracks()[0];
    if (cameraTrack && cameraTrack.readyState === 'live' && groupCameraWasEnabledRef.current) {
      cameraTrack.enabled = true;
      setGroupIsCameraOff(false);
    }

    if (notify && (window as any).showGlobalToast) {
      (window as any).showGlobalToast('تم إيقاف مشاركة الشاشة', 'info');
    }
  };

  const toggleGroupScreenShare = async () => {
    const mesh = groupMeshRef.current;
    const stream = groupLocalStreamRef.current;
    if (!mesh || !stream) return;

    if (groupScreenShareRef.current) {
      await stopGroupScreenShare(true);
      return;
    }

    const md = navigator.mediaDevices as MediaDevices & {
      getDisplayMedia?: (constraints: MediaStreamConstraints) => Promise<MediaStream>;
    };
    if (!md?.getDisplayMedia) return;

    try {
      const screenStream = await md.getDisplayMedia({
        video: { frameRate: { ideal: 15, max: 15 } },
        audio: false
      });
      const screenTrack = screenStream.getVideoTracks()[0];
      // Guard: never wire an already-ended track into the senders.
      if (!screenTrack || screenTrack.readyState !== 'live') {
        screenStream.getTracks().forEach(t => { try { t.stop(); } catch (_) {} });
        return;
      }

      const cameraTrack = stream.getVideoTracks()[0];
      groupCameraWasEnabledRef.current = cameraTrack ? cameraTrack.enabled : true;
      // Park the camera while the screen is being sent instead.
      if (cameraTrack) cameraTrack.enabled = false;

      await mesh.setScreenShare(screenTrack);

      // Browser's native 'Stop sharing' bar → auto-restore the camera.
      const onScreenEnded = () => {
        console.log('[GroupCallManager] Screen track ended externally — restoring camera');
        stopGroupScreenShare(true);
      };
      groupScreenEndedHandlerRef.current = onScreenEnded;
      screenTrack.addEventListener('ended', onScreenEnded);

      groupScreenShareRef.current = { stream: screenStream, track: screenTrack };
      setGroupScreenShare({ stream: screenStream, track: screenTrack });

      if ((window as any).showGlobalToast) {
        (window as any).showGlobalToast('🖥 بدأت مشاركة الشاشة', 'success');
      }
    } catch (err: any) {
      // Permission denial / cancelled picker: silent toast.
      if (err?.name === 'NotAllowedError') {
        if ((window as any).showGlobalToast) {
          (window as any).showGlobalToast('تم إلغاء مشاركة الشاشة', 'info');
        }
      } else {
        console.warn('[GroupCallManager] Screen share failed:', err);
        if ((window as any).showGlobalToast) {
          (window as any).showGlobalToast('تعذر بدء مشاركة الشاشة', 'error');
        }
      }
    }
  };

  const startVoiceCall = async (partnerId: string, partnerName: string, partnerAvatar?: string, callType: 'voice' | 'video' = 'voice', chatId?: string) => {
    if (!partnerId) return;
    
    const callId = `call-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    console.log(`[CallManager] Starting ${callType} call to ${partnerId} (ID: ${callId}) at local timestamp: ${Date.now()}`);

    iceCandidatesBufferRef.current = [];

    setActiveCall({
      callId,
      chatId: chatId || '',
      role: 'caller',
      partnerId,
      partnerName,
      partnerAvatar,
      status: 'calling',
      type: callType
    });

    try {
      // ── WhatsApp-parity media acquisition (caller side) ────────────────────
      // Step 1: AUDIO is MANDATORY with a LONG window (45s) — no 10s watchdog:
      // on real devices the permission prompt stays pending until the user
      // reacts, and a short watchdog killed outgoing calls on slow devices.
      let effectiveType: 'voice' | 'video' = callType;
      let audioStream: MediaStream;
      try {
        console.log(`[CallManager] Caller requesting AUDIO tracks (45s window) for: ${callType}`);
        audioStream = await gUMWithTimeout(
          {
            // Audio-processing toggles (user settings)
            audio: { ...buildAudioConstraints(currentUser?.chatSettings?.audioProcessing) },
            video: false
          },
          AUDIO_GUM_TIMEOUT_MS,
          new Error(MIC_FAILURE_MSG),
        );
      } catch (err: any) {
        console.error('[CallManager] Caller audio acquisition failed:', err?.name, err?.message);
        throw new Error(MIC_FAILURE_MSG);
      }

      // Step 2: VIDEO is BEST-EFFORT (15s). Any failure/denial → the call
      // continues as VOICE: flip activeCall type, toast the downgrade, and
      // simply never add a video track to the PC (nothing to remove — video is
      // acquired before the PC exists).
      let videoTrack: MediaStreamTrack | null = null;
      if (callType === 'video') {
        try {
          const videoStream = await gUMWithTimeout(
            {
              // Bounded video capture (720p30, hard max) — encoder-safe on weak devices
              video: { facingMode: 'user', ...buildVideoConstraints() }
            },
            VIDEO_GUM_TIMEOUT_MS,
            new Error('video-acquisition-timeout'),
          );
          videoTrack = videoStream.getVideoTracks()[0] || null;
        } catch (err: any) {
          console.log(`[CallManager] Caller video unavailable (${err?.name || err}) — downgrading to voice call`);
          videoTrack = null;
          effectiveType = 'voice';
          setActiveCall(prev => prev && prev.callId === callId ? { ...prev, type: 'voice', videoDowngraded: true } : prev);
          (window as any).showGlobalToast?.(CAMERA_DOWNGRADE_MSG, 'info');
        }
      }

      // One local stream: audio always present, video only when actually captured.
      const stream = audioStream;
      if (videoTrack) stream.addTrack(videoTrack);

      localStreamRef.current = stream;
      setLocalStreamState(stream);
      adviseCallEnvironment((window as any).showGlobalToast ?? (() => {}));

      const pc = new RTCPeerConnection({
        // Privacy: relay-only mode hides the user's IP from the peer (TURN
        // enforced, STUN skipped) when callRelayEnabled is set.
        iceTransportPolicy: currentUser?.privacySettings?.callRelayEnabled ? 'relay' : 'all',
        // T5: multi-provider ICE servers resolved from env (STUN_URLS / TURN_*)
        iceServers: buildIceConfig()
      });
      peerConnectionRef.current = pc;
      setPeerConnectionState(pc);
      console.log('[CallManager] RTCPeerConnection created successfully (Caller role)');

      stream.getTracks().forEach((track) => {
        pc.addTrack(track, stream);
      });
      tuneAudioSender(pc, currentUser?.chatSettings?.audioMode);
      tuneVideoSender(pc);
      preferEfficientVideoCodecs(pc);

      pc.onicecandidate = (event) => {
        if (event.candidate && socketClientRef.current) {
          socketClientRef.current.emit('call:signal', {
            callId,
            receiverId: partnerId,
            signal: { candidate: event.candidate.toJSON() },
            sentAt: Date.now()
          });
        }
      };

      pc.ontrack = (event) => {
        console.log('[CallManager] RTCPeerConnection Event: ontrack executed! (Caller)', event.track.kind);
        
        let streamToUse = (event.streams && event.streams[0]) || remoteStreamRef.current;
        if (!streamToUse) {
          streamToUse = new MediaStream();
        }
        
        const hasTrack = streamToUse.getTracks().some(t => t.id === event.track.id);
        if (!hasTrack) {
          streamToUse.addTrack(event.track);
        }

        remoteStreamRef.current = streamToUse;
        // STABLE stream: same object across ontrack events — re-creating a
        // MediaStream here re-assigned srcObject on every track (render stutter)
        setRemoteStream(streamToUse);

        // T2: ontrack only means media is arriving — stay 'connecting' until
        // the transport actually reports 'connected'.
        setActiveCall(prev => {
          if (prev) {
            console.log('[CallManager] Transitioning call status to connecting (ontrack received)');
            return { ...prev, status: 'connecting' };
          }
          return null;
        });
      };

      pc.onconnectionstatechange = () => {
        console.log(`[CallManager] RTCPeerConnection Event: connectionState changed = ${pc.connectionState}`);
        if (pc.connectionState === 'connected') {
          // T2: transport truly established — now flip to 'connected'
          setActiveCall(prev => prev && prev.status !== 'connected' && prev.status !== 'ended' ? { ...prev, status: 'connected' } : prev);
          // Network recovered: auto-restore video that weak-network degraded
          if (weakVideoTimerRef.current) { clearTimeout(weakVideoTimerRef.current); weakVideoTimerRef.current = null; }
          const localVideo = localStreamRef.current?.getVideoTracks?.()[0];
          if (localVideo && !localVideo.enabled && callType === 'video') {
            localVideo.enabled = true;
            if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
              (window as any).showGlobalToast('✅ عادت الشبكة — الفيديو يعمل مجدداً.', 'success');
            }
          }
        } else if (pc.connectionState === 'failed') {
          // T1: one healing attempt (restartIce + peer signal) before giving up
          if (!iceRestartAttemptedRef.current) {
            iceRestartAttemptedRef.current = true;
            failedRestartTimerRef.current = setTimeout(() => {
              requestIceRestart(pc, callId, partnerId, 'connectionState=failed');
            }, 1500);
            failedEndTimerRef.current = setTimeout(() => {
              if (peerConnectionRef.current && peerConnectionRef.current.connectionState === 'failed') {
                console.log('[CallManager] ICE restart did not recover the call (still failed) — ending');
                handleEndCall();
              }
            }, 9500); // 1.5s restart delay + 8s recovery window
          } else {
            handleEndCall();
          }
        } else if (pc.connectionState === 'disconnected') {
          // Weak-network smart degradation: drop video ONLY if the drop
          // persists 4s (a transient blip during setup must NOT kill video).
          const localVideo = localStreamRef.current?.getVideoTracks?.()[0];
          if (localVideo && localVideo.enabled && callType === 'video') {
            if (weakVideoTimerRef.current) clearTimeout(weakVideoTimerRef.current);
            weakVideoTimerRef.current = setTimeout(() => {
              if (pc.connectionState === 'disconnected' || pc.connectionState === 'failed') {
                localVideo.enabled = false;
                if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                  (window as any).showGlobalToast('📉 ضعف في الشبكة — تم إيقاف الفيديو تلقائياً حفاظاً على الصوت.', 'info');
                }
              }
            }, 4000);
          }
        } else if (pc.connectionState === 'closed') {
          handleEndCall();
        }
      };

      // T1: ICE-level disconnect detection — 3s grace, then coordinated restart
      pc.oniceconnectionstatechange = () => {
        console.log(`[CallManager] RTCPeerConnection Event: iceConnectionState changed = ${pc.iceConnectionState}`);
        if (pc.iceConnectionState === 'disconnected') {
          if (iceGraceTimerRef.current) clearTimeout(iceGraceTimerRef.current);
          iceGraceTimerRef.current = setTimeout(() => {
            if (pc.iceConnectionState === 'disconnected' && pc.connectionState !== 'closed') {
              requestIceRestart(pc, callId, partnerId, 'iceConnectionState=disconnected');
            }
          }, 3000);
        } else if (iceGraceTimerRef.current) {
          // Network recovered before the grace window expired
          clearTimeout(iceGraceTimerRef.current);
          iceGraceTimerRef.current = null;
        }
      };

      const offer = await pc.createOffer();
      // Opus tuning (FEC + DTX + bitrate) — free audio-quality stack
      const tunedOffer = tuneOpusSdp(offer.sdp, optsForMode(currentUser?.chatSettings?.audioMode));
      await pc.setLocalDescription({ type: 'offer', sdp: tunedOffer });

      if (socketClientRef.current) {
        console.log(`[CallManager] Emitting call:initiate with sentAt timestamp: ${Date.now()}`);
        socketClientRef.current.emit('call:initiate', {
          callId,
          calleeId: partnerId,
          offer: { type: 'offer', sdp: tunedOffer },
          // effectiveType: a video call whose camera failed rings as VOICE on
          // the callee side (the offer SDP is audio-only after the downgrade).
          type: effectiveType,
          chatId: activeCallRef.current?.chatId || '',
          sentAt: Date.now()
        });
      }
    } catch (err: any) {
      // Non-blocking toast instead of alert() — an alert freezes the whole
      // main thread mid-call and leaves the UI dead behind the dialog.
      (window as any).showGlobalToast?.(err.message || 'حدث خطأ أثناء إجراء المكالمة.', 'error');
      setActiveCall(null);
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach(t => t.stop());
        localStreamRef.current = null;
      }
      setLocalStreamState(null);
    }
  };

  const acceptVoiceCall = async () => {
    const currentCall = activeCallRef.current;
    if (!currentCall || currentCall.role !== 'callee') {
      console.warn('[CallManager] acceptVoiceCall bypassed: state mismatch or no active call', currentCall);
      return;
    }

    const { callId, partnerId } = currentCall;
    let callType = currentCall.type;
    console.log(`[CallManager] Accepting ${callType} call ${callId} from ${partnerId} at local timestamp: ${Date.now()}`);

    setActiveCall(prev => prev ? { ...prev, status: 'connecting' } : null);

    try {
      // ── WhatsApp-parity media acquisition (callee side) ────────────────────
      // Step 1: AUDIO is MANDATORY with a LONG window (45s) — the browser
      // permission prompt stays pending until the user reacts, and the old 10s
      // watchdog used to fire mid-prompt and kill the call the instant the
      // callee pressed Accept on real devices.
      let audioStream: MediaStream;
      try {
        console.log(`[CallManager] Callee requesting AUDIO tracks (45s window) for: ${callType}`);
        audioStream = await gUMWithTimeout(
          {
            audio: { ...buildAudioConstraints(currentUser?.chatSettings?.audioProcessing) },
            video: false
          },
          AUDIO_GUM_TIMEOUT_MS,
          new Error(MIC_FAILURE_MSG),
        );
      } catch (err: any) {
        console.error('[CallManager] Callee audio acquisition failed:', err?.name, err?.message);
        throw new Error(MIC_FAILURE_MSG);
      }

      // Step 2: VIDEO is BEST-EFFORT with its own 15s window. Any failure or
      // denial → continue as a VOICE call (flip the state machine, never close).
      let videoTrack: MediaStreamTrack | null = null;
      if (callType === 'video') {
        try {
          const videoStream = await gUMWithTimeout(
            { video: { facingMode: 'user', ...buildVideoConstraints() } },
            VIDEO_GUM_TIMEOUT_MS,
            new Error('video-acquisition-timeout'),
          );
          videoTrack = videoStream.getVideoTracks()[0] || null;
        } catch (err: any) {
          console.log(`[CallManager] Callee video unavailable (${err?.name || err}) — downgrading to voice call`);
          videoTrack = null;
          callType = 'voice';
          setActiveCall(prev => prev ? { ...prev, type: 'voice', videoDowngraded: true } : prev);
          (window as any).showGlobalToast?.(CAMERA_DOWNGRADE_MSG, 'info');
        }
      }

      // One local stream: audio always present, video only when actually captured.
      const stream = audioStream;
      if (videoTrack) stream.addTrack(videoTrack);

      localStreamRef.current = stream;
      setLocalStreamState(stream);
      adviseCallEnvironment((window as any).showGlobalToast ?? (() => {}));

      const pc = new RTCPeerConnection({
        // Privacy: relay-only mode hides the user's IP from the peer (TURN
        // enforced, STUN skipped) when callRelayEnabled is set.
        iceTransportPolicy: currentUser?.privacySettings?.callRelayEnabled ? 'relay' : 'all',
        // T5: multi-provider ICE servers resolved from env (STUN_URLS / TURN_*)
        iceServers: buildIceConfig()
      });
      peerConnectionRef.current = pc;
      setPeerConnectionState(pc);
      console.log('[CallManager] RTCPeerConnection created successfully (Callee role)');

      stream.getTracks().forEach((track) => {
        pc.addTrack(track, stream);
      });
      tuneAudioSender(pc, currentUser?.chatSettings?.audioMode);
      tuneVideoSender(pc);
      preferEfficientVideoCodecs(pc);

      pc.onicecandidate = (event) => {
        if (event.candidate && socketClientRef.current) {
          socketClientRef.current.emit('call:signal', {
            callId,
            receiverId: partnerId,
            signal: { candidate: event.candidate.toJSON() },
            sentAt: Date.now()
          });
        }
      };

      pc.ontrack = (event) => {
        console.log('[CallManager] RTCPeerConnection Event: ontrack executed! (Callee)', event.track.kind);
        
        let streamToUse = (event.streams && event.streams[0]) || remoteStreamRef.current;
        if (!streamToUse) {
          streamToUse = new MediaStream();
        }
        
        const hasTrack = streamToUse.getTracks().some(t => t.id === event.track.id);
        if (!hasTrack) {
          streamToUse.addTrack(event.track);
        }

        remoteStreamRef.current = streamToUse;
        // STABLE stream: same object across ontrack events — re-creating a
        // MediaStream here re-assigned srcObject on every track (render stutter)
        setRemoteStream(streamToUse);

        // T2: ontrack only means media is arriving — stay 'connecting' until
        // the transport actually reports 'connected'.
        setActiveCall(prev => {
          if (prev) {
            console.log('[CallManager] Callee: Transitioning status to connecting (ontrack received)');
            return { ...prev, status: 'connecting' };
          }
          return null;
        });
      };

      pc.onconnectionstatechange = () => {
        console.log(`[CallManager] RTCPeerConnection Event: connectionState changed = ${pc.connectionState}`);
        if (pc.connectionState === 'connected') {
          // T2: transport truly established — now flip to 'connected'
          setActiveCall(prev => prev && prev.status !== 'connected' && prev.status !== 'ended' ? { ...prev, status: 'connected' } : prev);
          // Network recovered: auto-restore video that weak-network degraded
          if (weakVideoTimerRef.current) { clearTimeout(weakVideoTimerRef.current); weakVideoTimerRef.current = null; }
          const localVideo = localStreamRef.current?.getVideoTracks?.()[0];
          if (localVideo && !localVideo.enabled && callType === 'video') {
            localVideo.enabled = true;
            if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
              (window as any).showGlobalToast('✅ عادت الشبكة — الفيديو يعمل مجدداً.', 'success');
            }
          }
        } else if (pc.connectionState === 'failed') {
          // T1: one healing attempt (restartIce + peer signal) before giving up
          if (!iceRestartAttemptedRef.current) {
            iceRestartAttemptedRef.current = true;
            failedRestartTimerRef.current = setTimeout(() => {
              requestIceRestart(pc, callId, partnerId, 'connectionState=failed');
            }, 1500);
            failedEndTimerRef.current = setTimeout(() => {
              if (peerConnectionRef.current && peerConnectionRef.current.connectionState === 'failed') {
                console.log('[CallManager] Callee: ICE restart did not recover the call (still failed) — ending');
                handleEndCall();
              }
            }, 9500); // 1.5s restart delay + 8s recovery window
          } else {
            handleEndCall();
          }
        } else if (pc.connectionState === 'disconnected') {
          // Weak-network smart degradation (callee side): drop video for audio
          const localVideo = localStreamRef.current?.getVideoTracks?.()[0];
          if (localVideo && localVideo.enabled && activeCallRef.current?.type === 'video') {
            localVideo.enabled = false;
            if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
              (window as any).showGlobalToast('📉 ضعف في الشبكة — تم إيقاف الفيديو تلقائياً حفاظاً على الصوت.', 'info');
            }
          }
        } else if (pc.connectionState === 'closed') {
          handleEndCall();
        }
      };

      // T1: ICE-level disconnect detection — 3s grace, then coordinated restart
      pc.oniceconnectionstatechange = () => {
        console.log(`[CallManager] RTCPeerConnection Event: iceConnectionState changed = ${pc.iceConnectionState}`);
        if (pc.iceConnectionState === 'disconnected') {
          if (iceGraceTimerRef.current) clearTimeout(iceGraceTimerRef.current);
          iceGraceTimerRef.current = setTimeout(() => {
            if (pc.iceConnectionState === 'disconnected' && pc.connectionState !== 'closed') {
              requestIceRestart(pc, callId, partnerId, 'iceConnectionState=disconnected');
            }
          }, 3000);
        } else if (iceGraceTimerRef.current) {
          // Network recovered before the grace window expired
          clearTimeout(iceGraceTimerRef.current);
          iceGraceTimerRef.current = null;
        }
      };

      const cachedOffer = (currentCall as any).offer;
      if (!cachedOffer) {
        throw new Error('بيانات الاتصال غير صالحة.');
      }

      console.log('[CallManager] RTCSessionDescription: Running setRemoteDescription on Offer SDP');
      await pc.setRemoteDescription(new RTCSessionDescription(cachedOffer));
      console.log('[CallManager] RTCSessionDescription: setRemoteDescription successful!');

      while (iceCandidatesBufferRef.current.length > 0) {
        const candidate = iceCandidatesBufferRef.current.shift();
        if (candidate) {
          console.log('[CallManager] Flushing buffered candidate into PeerConnection:', candidate);
          await pc.addIceCandidate(new RTCIceCandidate(candidate)).catch(e => {
            console.warn('[CallManager] Deferred candidate injection failure:', e);
          });
        }
      }

      const answer = await pc.createAnswer();
      // Opus tuning applied to the answer as well (symmetric quality params)
      const tunedAnswer = tuneOpusSdp(answer.sdp, optsForMode(currentUser?.chatSettings?.audioMode));
      await pc.setLocalDescription({ type: 'answer', sdp: tunedAnswer });

      if (socketClientRef.current) {
        console.log(`[CallManager] Emitting call:respond with accepted: true and answer SDP`);
        socketClientRef.current.emit('call:respond', {
          callId,
          callerId: partnerId,
          accepted: true,
          answer: { type: 'answer', sdp: tunedAnswer },
          sentAt: Date.now()
        });
      }
    } catch (err: any) {
      // Non-blocking toast instead of alert() — same freeze hazard on the
      // callee side while the ringing UI is up.
      (window as any).showGlobalToast?.(err.message || 'فشل قبول المكالمة.', 'error');
      rejectVoiceCall();
    }
  };

  const rejectVoiceCall = () => {
    const currentCall = activeCallRef.current;
    if (!currentCall) return;

    console.log(`[CallManager] Rejecting call ${currentCall.callId}`);
    if (socketClientRef.current) {
      socketClientRef.current.emit('call:respond', {
        callId: currentCall.callId,
        callerId: currentCall.partnerId,
        accepted: false,
        reason: 'rejected'
      });
    }

    cleanupCallState();
  };

  // WhatsApp parity: decline with a quick reason — auto-sends it as a chat message
  const rejectVoiceCallWithMessage = async (reasonLabel: string) => {
    const currentCall = activeCallRef.current;
    if (!currentCall) return;
    if (socketClientRef.current) {
      socketClientRef.current.emit('call:respond', {
        callId: currentCall.callId,
        callerId: currentCall.partnerId,
        accepted: false,
        reason: 'declined-with-message'
      });
    }
    try {
      if (currentCall.chatId) {
        let declineContent = `📞 لا أستطيع التحدث الآن — ${reasonLabel}`;
        // E2EE: encrypt for eligible 1:1 peers; fall back to plaintext if the
        // peer has no E2EE bundle (never block the call decline itself).
        const declinePeer = e2eePeerForChat(currentCall.chatId);
        if (declinePeer && e2eeRef.current) {
          try {
            declineContent = (await e2eeRef.current.encryptMessage(declinePeer, declineContent)).content;
          } catch (_) { /* plaintext fallback */ }
        }
        await fetch(`/api/chats/${currentCall.chatId}/messages`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${TokenVault.getAccessToken()}` },
          body: JSON.stringify({ content: declineContent }),
        });
      }
    } catch (_) { /* call still declined */ }
    cleanupCallState();
  };

  useEffect(() => {
    if (websocketConnected) {

    }
  }, [websocketConnected]);

  // Chat layouts (Raw storage with instant Cache-First hydration on boots)
  const [rawChats, setRawChats] = useState<any[]>(() => {
    try {
      if (typeof window !== 'undefined') {
        const storedUser = localStorage.getItem('dirasha_user');
        if (storedUser) {
          const parsed = JSON.parse(storedUser);
          const userId = parsed?.uid || parsed?.id;
          if (userId) {
            const cached = localStorage.getItem(`chats_list_${userId}`);
            if (cached) {
              const parsedChats = JSON.parse(cached);
              if (Array.isArray(parsedChats)) return parsedChats;
            }
          }
        }
      }
    } catch (_) {}
    return [];
  });
  const rawChatsRef = useRef<any[]>([]);
  useEffect(() => {
    rawChatsRef.current = rawChats;
  }, [rawChats]);

  // Network Status Monitor (Offline First capability)
  const [isOnline, setIsOnline] = useState<boolean>(typeof navigator !== 'undefined' ? navigator.onLine : true);

  // Moderation & Administrative Systems States
  const [unreadReportsCount, setUnreadReportsCount] = useState<number>(0);
  const [showModerationCenter, setShowModerationCenter] = useState<boolean>(false);
  const [reportingUserId, setReportingUserId] = useState<string | null>(null);
  const [reportingMessage, setReportingMessage] = useState<{
    messageId: string;
    senderId: string;
    senderName: string;
    content: string;
  } | null>(null);

  useEffect(() => {
    const handleOnlineEvent = () => {
      setIsOnline(true);
      console.log('[App Network Watcher] Client transitioned to [ONLINE] mode.');
    };
    const handleOfflineEvent = () => {
      setIsOnline(false);
      console.log('[App Network Watcher] Client transitioned to [OFFLINE] mode.');
    };
    window.addEventListener('online', handleOnlineEvent);
    window.addEventListener('offline', handleOfflineEvent);
    return () => {
      window.removeEventListener('online', handleOnlineEvent);
      window.removeEventListener('offline', handleOfflineEvent);
    };
  }, []);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);

  // Global hook: lets the group-creation modal open the fresh chat instantly.
  useEffect(() => {
    (window as any).__openDirashaChat = (chatId: string) => setActiveChatId(chatId);
  }, []);
  const activeChatIdRef = useRef<string | null>(null);

  useEffect(() => {
    activeChatIdRef.current = activeChatId;
  }, [activeChatId]);

  const [rawMessages, setRawMessages] = useState<any[]>([]);
  const rawMessagesRef = useRef<any[]>([]);
  useEffect(() => { rawMessagesRef.current = rawMessages; }, [rawMessages]);

  // E2EE panels (encrypted export + active-sessions management)
  const [backupPanel, setBackupPanel] = useState<{ id: string; name: string } | null>(null);
  const [sessionsPanelOpen, setSessionsPanelOpen] = useState(false);

  // ── E2EE engine (Agent I integration) ──────────────────────────────────────
  // Single engine instance per logged-in account. namespace = user id for
  // multi-account isolation (separate IndexedDB key space per account); the
  // instance is recreated whenever the logged-in user changes (logout → login
  // as a different user), so keys never leak across accounts.
  const e2eeRef = useRef<DirashaE2EE | null>(null);
  const e2eeOwnerUidRef = useRef<string>('');
  useEffect(() => {
    const uid = currentUserId;
    if (!uid) {
      e2eeRef.current = null;
      e2eeOwnerUidRef.current = '';
      // F2: unbind the encrypted message cache from any account on logout.
      MessagesCacheDB.setOwnerUid(null);
      OutboxDB.setOwnerUid(null);
      return;
    }
    if (e2eeOwnerUidRef.current === uid && e2eeRef.current) return;
    // F2 (audit CRITICAL): the local message cache is encrypted under a
    // per-account, non-extractable cache KEK ('dirasha-cache-vault', key id
    // `cache-kek:<uid>` — SEPARATE from the engine vault's KEK). Legacy
    // plaintext entries migrate verify-then-keep (resumable, never delete
    // before verify) — honest limits documented in messages_cache_db.ts.
    MessagesCacheDB.setOwnerUid(uid);
    void MessagesCacheDB.migrateAll().catch(() => {});
    OutboxDB.setOwnerUid(uid);
    const vaultStore = new VaultKVStore(new IndexedDBKVStore(), new IndexedDBKekStore());
    void vaultStore.migrateExisting().catch(() => {}); // legacy plaintext -> encrypted (best-effort)
    e2eeRef.current = new DirashaE2EE({
      authHeaders: () => ({ Authorization: 'Bearer ' + TokenVault.getAccessToken() }),
      namespace: uid,
      store: vaultStore,
    });
    e2eeOwnerUidRef.current = uid;
    // Fire-and-forget registration — never blocks login UX. The engine is
    // idempotent (short-circuits on a locally-registered identity).
    e2eeRef.current.ensureRegistered().catch(() => {});
  }, [currentUserId]);

  // ── Group E2EE engine (Sender Keys) ─────────────────────────────────────────
  // One GroupCrypto instance per logged-in account (same lifecycle pattern as
  // the 1:1 engine above): namespace = user id for multi-account isolation and
  // a fresh instance on account change so sender keys never leak across
  // accounts. Holds our own sender key per group ('gsk:<groupId>') plus the
  // member keys received pairwise from other members ('gmi:<groupId>:<peer>').
  const groupCryptoRef = useRef<GroupCrypto | null>(null);
  // P0-A (external-audit E2EE-01/02): per-chat rekey-in-flight guard — while a
  // membership change is being processed (rotation + pairwise re-distribution),
  // group sends in that chat are blocked so no message ever leaves under a
  // stale sender-key epoch.
  const rekeyPendingRef = useRef<Set<string>>(new Set<string>());
  const groupCryptoOwnerUidRef = useRef<string>('');
  useEffect(() => {
    const uid = currentUserId;
    if (!uid) {
      groupCryptoRef.current = null;
      groupCryptoOwnerUidRef.current = '';
      return;
    }
    if (groupCryptoOwnerUidRef.current === uid && groupCryptoRef.current) return;
    groupCryptoRef.current = new GroupCrypto({ store: new VaultKVStore(new IndexedDBKVStore(), new IndexedDBKekStore()), namespace: uid });
    groupCryptoOwnerUidRef.current = uid;
  }, [currentUserId]);

  // Group eligibility: REGULAR group chats only ('chat.type === "group"').
  // Channels are one-way broadcast spaces and DMs ride the pairwise DIR1
  // engine — both are excluded from the group sender-key path.
  const isE2eeGroupChat = (chat: any | null | undefined): boolean =>
    !!chat && chat.type === 'group';

  // Member list source: chats hydrate with `memberIds` (array of user ids) or
  // `members` (array of member objects). Others = every member except me.
  // F3: delegated to the canonical rosterMemberIds() helper in group.ts (the
  // same helper guards the key-request handler and the distribution choke
  // point below — single source of the LOCAL roster shape).
  const groupMemberIdsOf = (chat: any): string[] => rosterMemberIds(chat, currentUserId);

  // Distribution bookkeeping: localStorage flag 'dist:<groupId>:<peerId>' =
  // keyId of the sender key we last distributed to that member. The next send
  // / chat open re-distributes whenever our current keyId differs (rotation or
  // a fresh key), so failures only delay distribution, never lose it.
  const groupDistFlagKey = (groupId: string, peerId: string): string =>
    `dist:${groupId}:${peerId}`;
  const readGroupDistFlag = (groupId: string, peerId: string): number | null => {
    try {
      const raw = localStorage.getItem(groupDistFlagKey(groupId, peerId));
      if (raw === null) return null;
      const n = Number(raw);
      return Number.isFinite(n) && n > 0 ? n : null;
    } catch {
      return null;
    }
  };
  const setGroupDistFlag = (groupId: string, peerId: string, keyId: number): void => {
    try { localStorage.setItem(groupDistFlagKey(groupId, peerId), String(keyId)); } catch {}
  };
  const clearGroupDistFlag = (groupId: string, peerId: string): void => {
    try { localStorage.removeItem(groupDistFlagKey(groupId, peerId)); } catch {}
  };
  const clearGroupDistFlags = (groupId: string): void => {
    try {
      const prefix = `dist:${groupId}:`;
      const stale: string[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith(prefix)) stale.push(k);
      }
      stale.forEach((k) => localStorage.removeItem(k));
    } catch {}
  };

  // In-flight guard so concurrent triggers (chat open + send + ctrl) never
  // double-send the same distribution envelope.
  const groupDistInFlightRef = useRef<Set<string>>(new Set());

  // Send OUR sender key for `groupId` to `peerId` pairwise (DIR1 envelope
  // inside the 'e2ee:ctrl' WS channel). Cheap no-op when the flag already
  // matches our current keyId. Returns true when the peer has our key.
  // F3 (audit H1) DISTRIBUTION-SIDE choke point: the recipient MUST be a
  // member of the group per the LOCAL chat roster — key material never
  // leaves for non-members no matter which caller path led here. (Both known
  // callers — ensureGroupDistribution and the key-request handler — already
  // filter by the roster; this in-function guard makes the invariant hold for
  // any future caller too. Honest limitation, see rosterMemberIds in
  // group.ts: the roster is client-side; the server relay ALSO enforces
  // membership server-side — both layers.)
  const distributeGroupKeyToPeer = async (groupId: string, peerId: string): Promise<boolean> => {
    const gc = groupCryptoRef.current;
    const engine = e2eeRef.current;
    if (!gc || !engine || !groupId || !peerId || peerId === currentUserId) return false;
    const rosterChat = (rawChatsRef.current || []).find((c: any) => c?.id === groupId);
    if (!rosterChat || rosterChat.type !== 'group' || !isRosterMember(rosterChat, peerId, currentUserId)) {
      console.warn('[E2EE] distribution suppressed — peer not in the local roster for this group');
      return false;
    }
    const inflightKey = `${groupId}:${peerId}`;
    if (groupDistInFlightRef.current.has(inflightKey)) return false;
    groupDistInFlightRef.current.add(inflightKey);
    try {
      const { keyId } = await gc.ensureSenderKey(groupId);
      if (readGroupDistFlag(groupId, peerId) === keyId) return true;
      const ctrl = await gc.distributionPayload(groupId);
      const enc = await engine.encryptMessage(peerId, ctrl, { chunked: true });
      const chunks = enc.contents || [enc.content];
      for (const chunk of chunks) {
        socketClientRef.current?.emit('e2ee:ctrl', { toUserId: peerId, groupId, payload: chunk });
      }
      if (localStorage.getItem('e2eeDebug')) console.log('[E2EE-EMIT] distribution ctrl ->', peerId, 'chunks=', chunks.length);
      setGroupDistFlag(groupId, peerId, keyId);
      return true;
    } catch (e) {
      console.warn('[E2EE-DIST-ERR] ctrl to ', peerId, 'failed:', e?.name || '', e?.message || e);
      // Peer unregistered / transport failure → flag stays unset; the next
      // send or chat open retries automatically.
      return false;
    } finally {
      groupDistInFlightRef.current.delete(inflightKey);
    }
  };

  // Full distribution sweep for a group: ensure our sender key exists, then
  // push it pairwise to every OTHER member whose flag is stale.
  const ensureGroupDistribution = async (chat: any): Promise<void> => {
    if (!isE2eeGroupChat(chat) || !currentUserId) return;
    const members = groupMemberIdsOf(chat);
    if (members.length === 0) return;
    await Promise.all(members.map((peerId) =>
      distributeGroupKeyToPeer(chat.id, peerId).catch((e) => console.warn('[E2EE-DIST] failed for ', peerId, e?.message || e))
    ));
  };


  // P0-A rotate-on-membership helper (external-audit E2EE-01/E2EE-02): rotate
  // sender key + wipe stale dist flags + re-distribute under the new epoch,
  // remembering the server membership_version. Sends in the chat are blocked
  // until re-distribution completes (rekeyPendingRef).
  const rotateGroupForMembership = (chatId: string, newMv: number | undefined) => {
    const chat = (rawChatsRef.current || []).find((c: any) => c?.id === chatId);
    if (!isE2eeGroupChat(chat)) return;
    (async () => {
      const gc = groupCryptoRef.current;
      if (!gc) return;
      rekeyPendingRef.current.add(chatId);
      try {
        clearGroupDistFlags(chatId);
        await gc.rotateSenderKey(chatId);
        if (typeof newMv === 'number') await gc.setMembershipVersion(chatId, newMv);
        await ensureGroupDistribution(chatId);
      } finally {
        rekeyPendingRef.current.delete(chatId);
      }
      showToast('أُعيد توليد مفاتيح التشفير للمجموعة', 'info');
    })().catch((e) => {
      rekeyPendingRef.current.delete(chatId);
      console.warn('[E2EE-CTRL] rotation helper failed:', e?.message || e);
    });
  };

  // Key-request: fire-and-forget ctrl asking peerId to re-send their sender
  // key for groupId (sent when a DIRG1 message failed to decrypt).
  const requestGroupKeyFrom = async (groupId: string, peerId: string): Promise<void> => {
    const engine = e2eeRef.current;
    if (!engine || !groupId || !peerId) return;
    const enc = await engine.encryptMessage(peerId, JSON.stringify({
      kind: GROUP_CTRL_KIND,
      type: 'key-request',
      groupId,
    }));
    const chunks = enc.contents || [enc.content];
    for (const chunk of chunks) {
      socketClientRef.current?.emit('e2ee:ctrl', { toUserId: peerId, groupId, payload: chunk });
    }
  };

  // Trigger: distribution when an eligible group chat is OPENED (also re-runs
  // once the chat list hydrates — the flag short-circuit keeps it cheap).
  useEffect(() => {
    if (!activeChatId || !currentUserId) return;
    const chat = (rawChatsRef.current || []).find((c: any) => c?.id === activeChatId);
    if (!isE2eeGroupChat(chat)) return;
    ensureGroupDistribution(chat);
  }, [activeChatId, rawChats]);

  // E2EE eligibility: chat must be a 1:1 DM with a known other member.
  // Falls back to parsing the deterministic one_to_one_<a>___<b> chat id when
  // the chat list has not hydrated yet (history fetch can race chat loading).
  const e2eePeerForChat = (chatId: string | null | undefined): string | null => {
    if (!chatId || !currentUserId) return null;
    const chat = (rawChatsRef.current || []).find((c: any) => c?.id === chatId);
    if (chat) {
      if (chat.type !== 'one-to-one') return null;
      const peer = chat.otherMember?.id ||
        (Array.isArray(chat.memberIds) ? chat.memberIds.find((m: string) => m && m !== currentUserId) : undefined);
      return peer && peer !== currentUserId ? String(peer) : null;
    }
    const sep = chatId.indexOf('___');
    if (chatId.startsWith('one_to_one_') && sep > 0) {
      const a = chatId.slice('one_to_one_'.length, sep);
      const b = chatId.slice(sep + 3);
      const peer = a === currentUserId ? b : b === currentUserId ? a : null;
      return peer && peer !== currentUserId ? peer : null;
    }
    return null;
  };

  // ── F8 (audit): plaintext-downgrade memory surfaced in the UI ───────────────
  // The engine persists 'e2eeDowngraded:<peerId>' whenever a send to that peer
  // was downgraded to PLAINTEXT because the peer had no E2EE bundle (definitive
  // 404 / registered:false), and clears it on the next successful encryption.
  // For the ACTIVE chat we read that memory and hand it to ChatWindow, which
  // renders the "هذه المحادثة غير مشفرة طرف-لطرف (الطرف غير مسجل)" badge in
  // place of the lock — no silent downgrade. E2EE-09: the plaintext send
  // itself is now FAIL-CLOSED (aborts unless the explicit per-chat plaintext
  // opt-in 'e2eeAllowPlaintext:<chatId>' exists — see handleSendMessage).
  const [activeChatDowngraded, setActiveChatDowngraded] = useState(false);
  useEffect(() => {
    let alive = true;
    const peer = e2eePeerForChat(activeChatId);
    const engine = e2eeRef.current;
    if (!peer || !engine) {
      setActiveChatDowngraded(false);
      return;
    }
    engine.wasDowngraded(peer)
      .then((v: boolean) => { if (alive) setActiveChatDowngraded(v); })
      .catch(() => { /* engine unavailable — keep the last known state */ });
    return () => { alive = false; };
  }, [activeChatId]);

  // ── Safety-number bookkeeping (Task C) ──────────────────────────────────────
  // 'e2eeLastSN:<myId>:<peerId>' — recorded on EVERY successful safety fetch.
  // A number that DIFFERS from the last recorded one means the peer
  // re-registered their identity keys → raise the 'e2eeRekey:<myId>:<peerId>'
  // warning flag and auto-clear any stale 'e2eeVerified:<myId>:<peerId>'
  // reference (the verified state only survives while numbers keep matching).
  const markE2eeRekey = (peerId: string | null | undefined): void => {
    if (!currentUserId || !peerId) return;
    try {
      localStorage.setItem(e2eeRekeyFlagKey(currentUserId, String(peerId)), '1');
    } catch { /* storage unavailable */ }
  };

  const recordSafetyNumberFetch = (peerId: string, safetyNumber: string): void => {
    if (!currentUserId || !peerId || !safetyNumber) return;
    const clean = String(safetyNumber).replace(/\s/g, '');
    if (!clean) return;
    try {
      const key = e2eeLastSnKey(currentUserId, peerId);
      const last = localStorage.getItem(key);
      if (last !== null && last !== clean) markE2eeRekey(peerId);
      const verifiedKey = e2eeVerifiedKey(currentUserId, peerId);
      const verified = localStorage.getItem(verifiedKey);
      if (verified !== null && verified !== clean) {
        // Numbers DIFFER → the stored verification is stale; clear it.
        localStorage.removeItem(verifiedKey);
      }
      localStorage.setItem(key, clean);
    } catch { /* storage unavailable */ }
  };

  // History decrypt: for the given chat, decrypt any DIR1 contents in a
  // fetched batch (Promise.all) before the batch reaches setRawMessages/cache.
  // Decrypt failures NEVER throw — failed items keep the raw ciphertext in
  // e2eeRaw, clear content, and set e2eeError for placeholder rendering.

  // P0-B (external-audit E2EE-03): single encryption choke point for ALL
  // message-carrying operations - main send, edit, schedule, forward. Throws
  // when encryption is unavailable (fail-closed; callers abort, never send
  // plaintext).
  const encryptContentForChat = async (chatId: string, text: string): Promise<string> => {
    const chat = (rawChatsRef.current || []).find((c: any) => c?.id === chatId);
    if (chat && chat.type === 'group') {
      const gc = groupCryptoRef.current;
      if (!gc) throw new Error('E2EE group crypto unavailable');
      await ensureGroupDistribution(chat);
      return gc.encryptGroupMessage(chatId, text, String(currentUserId || ''), Number((chat as any)?.membershipVersion) || 1);
    }
    const peer = e2eePeerForChat(chatId);
    const engine = e2eeRef.current;
    if (!peer || !engine) throw new Error('E2EE unavailable for this chat');
    const enc = await engine.encryptMessage(peer, text);
    return enc.content;
  };

  const decryptContentForChat = async (chatId: string, content: string, senderId: string): Promise<string> => {
    if (typeof content !== 'string') return content;
    const isEnvelope = content.startsWith('DIR1:') || content.startsWith('DIRM1:') || content.startsWith('DIRG1:');
    if (!isEnvelope) return content;
    const chat = (rawChatsRef.current || []).find((c: any) => c?.id === chatId);
    const isGroup = !!(chat && chat.type === 'group');
    if (isGroup) {
      const gc = groupCryptoRef.current;
      if (!gc) throw new Error('group crypto unavailable');
      const r = await gc.decryptGroupMessage(chatId, senderId || 'self', content);
      if ('plaintext' in r) return r.plaintext;
      throw new Error(r.error || 'decrypt failed');
    }
    const peer = e2eePeerForChat(chatId);
    const engine = e2eeRef.current;
    if (!engine || !peer) throw new Error('E2EE unavailable');
    const r = await engine.decryptMessage(peer, content);
    if ('plaintext' in r) return r.plaintext;
    throw new Error((r as any).error || 'decrypt failed');
  };

  const decryptHistoryMessages = async (chatId: string, msgs: any[]): Promise<any[]> => {
    const engine = e2eeRef.current;
    if (!engine || !Array.isArray(msgs) || msgs.length === 0) return msgs;
    // Group chats decrypt DIRG1 envelopes via GroupCrypto (per-sender member
    // keys); 1:1 chats decrypt DIR1 envelopes via the pairwise engine.
    const chat = (rawChatsRef.current || []).find((c: any) => c?.id === chatId);
    const isGroup = isE2eeGroupChat(chat);
    const peerId = isGroup ? null : e2eePeerForChat(chatId);
    if (!peerId && !isGroup) return msgs;
    const gc = isGroup ? groupCryptoRef.current : null;
    if (isGroup && !gc) return msgs;
    const targets = msgs
      .map((m, i) => ({ m, i }))
      .filter(({ m }) => m && typeof m.content === 'string' && (
        m.content.startsWith('DIR1:') || m.content.startsWith('DIRM1:') ||
        (isGroup && m.content.startsWith(GROUP_WIRE_PREFIX))
      ));
    if (targets.length === 0) return msgs;
    const results = await Promise.all(targets.map(({ m }) =>
      (isGroup && m.content.startsWith(GROUP_WIRE_PREFIX))
        ? gc!.decryptGroupMessage(chatId, String(m.senderId || ''), m.content)
        : engine.decryptMessage(peerId as string, m.content)
    ));
    const out = msgs.slice();
    targets.forEach(({ m, i }, k) => {
      const r = results[k];
      const item = { ...out[i] };
      item.e2ee = true;
      if (r && 'plaintext' in r && typeof r.plaintext === 'string') {
        if (isGroup) {
          // Media E2EE (groups): the plaintext is the same 'dirasha-msg-v1'
          // container used by 1:1 — parse it so the text AND the attachment
          // payloads (e2eeFiles) reach the renderer. Legacy group plaintext
          // (pre-container) falls back to pure text inside
          // parseEncryptedPayload.
          try {
            const parsed = parseEncryptedPayload(r.plaintext);
            item.content = parsed.text;
            if (parsed.files.length > 0) item.e2eeFiles = parsed.files;
          } catch {
            // Container claimed our kind but was structurally invalid (tamper).
            item.e2eeRaw = m.content;
            item.content = '';
            item.e2eeError = true;
          }
          out[i] = item;
          return;
        }
        // Media E2EE: the plaintext is our payload container — parse it so the
        // text AND the attachment payloads (e2eeFiles) reach the renderer.
        try {
          const parsed = parseEncryptedPayload(r.plaintext);
          item.content = parsed.text;
          if (parsed.files.length > 0) item.e2eeFiles = parsed.files;
        } catch {
          // Container claimed our kind but was structurally invalid (tamper).
          item.e2eeRaw = m.content;
          item.content = '';
          item.e2eeError = true;
        }
      } else {
        // Task C: RekeyDetectedError on the 1:1 pairwise path → raise the
        // rekey warning flag for this DM (GroupCrypto never emits it).
        if (r && 'error' in r && (r as { error: string }).error === 'RekeyDetectedError') {
          markE2eeRekey(peerId);
        }
        item.e2eeRaw = m.content;
        item.content = '';
        item.e2eeError = true;
      }
      out[i] = item;
    });
    return out;
  };

  const [loadingMessages, setLoadingMessages] = useState(false);
  const [hasMoreMessages, setHasMoreMessages] = useState(false);
  const [highlightMsgId, setHighlightMsgId] = useState<string | null>(null);

  // High-performance client-side Local Outbox Queue with IndexedDB persistence
  const [outboxQueue, setOutboxQueue] = useState<any[]>([]);

  // Track retry counts and next activation timer for outbox messages in-memory
  const outboxMetaRef = useRef<Record<string, { retryCount: number; nextRetryTime: number }>>({});
  const outboxQueueRef = useRef<any[]>([]);
  const sentTimestampsRef = useRef<Record<string, number>>({});

  // Sync state and ref
  useEffect(() => {
    outboxQueueRef.current = outboxQueue;
  }, [outboxQueue]);

  // Load initial outbox from IndexedDB once
  useEffect(() => {
    const loadOutbox = async () => {
      try {

        const items = await OutboxDB.getAll();

        setOutboxQueue(items);
        outboxQueueRef.current = items;

        
        // If there are pending outbox items, force immediate processing and reset pacing
        const pendingCount = items.filter(u => u.status === 'pending').length;
        if (pendingCount > 0) {

          items.forEach((item) => {
            if (item.status !== 'failed') {
              outboxMetaRef.current[item.id] = { retryCount: 0, nextRetryTime: 0 };
              delete sentTimestampsRef.current[item.id];
            }
          });
        }
      } catch (err) {
        console.error('Failed to load outbox from IndexedDB:', err);
      }
    };
    loadOutbox();
  }, []);

  const removeFromOutbox = (tempId: string) => {
    if (!tempId) return;
    delete sentTimestampsRef.current[tempId];
    setOutboxQueue((prev) => {
      const next = prev.filter((item) => item.id !== tempId);
      outboxQueueRef.current = next;

      OutboxDB.remove(tempId).catch((err) => console.error('[IndexedDB] err deleting item:', err));
      return next;
    });
  };
  
  // Real-time tracking states
  const [allUsers, setAllUsers] = useState<Record<string, any>>({});
  const allUsersRef = useRef<Record<string, any>>({});
  useEffect(() => {
    allUsersRef.current = allUsers;
  }, [allUsers]);

  const [presenceTick, setPresenceTick] = useState(0);
  const [expiryTick, setExpiryTick] = useState(0);

  // Interval to re-evaluate expiring messages every 5 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setExpiryTick(prev => prev + 1);
    }, 5000);
    return () => clearInterval(timer);
  }, []);
  const [viewUserProfileId, setViewUserProfileId] = useState<string | null>(null);

  // Keep currentUser and allUsers synced reactively
  useEffect(() => {
    if (currentUser && currentUserId) {
      setAllUsers((prev) => {
        const existing = prev[currentUserId];
        if (
          existing &&
          existing.displayName === currentUser.displayName &&
          existing.username === currentUser.username &&
          existing.avatarUrl === (currentUser.avatarUrl || currentUser.photoURL) &&
          existing.bio === currentUser.bio &&
          existing.bannerUrl === currentUser.bannerUrl
        ) {
          return prev;
        }
        return {
          ...prev,
          [currentUserId]: {
            ...existing,
            ...currentUser,
            id: currentUserId,
            avatarUrl: currentUser.avatarUrl || currentUser.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop'
          }
        };
      });
    }
  }, [currentUser, currentUserId]);

  // Firestore quota and user activity monitoring
  const [quotaExceeded, setQuotaExceeded] = useState(() => {
    return localStorage.getItem('firestore_quota_exceeded') === 'true';
  });
  const lastUserActivity = useRef<number>(Date.now());
  const idleTimerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const handleQuota = () => {
      setQuotaExceeded(true);
      localStorage.setItem('firestore_quota_exceeded', 'true');
    };
    window.addEventListener('firestore-quota-exceeded', handleQuota);
    
    // Configurable idle timeout (30 seconds)
    const PRESENCE_IDLE_TIMEOUT = 30000;

    const updatePresenceStatus = (status: 'online' | 'offline' | 'away') => {
      if (socketClientRef.current && socketClientRef.current.isConnected()) {
        socketClientRef.current.emit('presence:status', { status });
      }
    };

    // Monitor user active signals to update presence status
    const handleActivity = () => {
      const now = Date.now();
      const wasIdle = (now - lastUserActivity.current) > PRESENCE_IDLE_TIMEOUT;
      lastUserActivity.current = now;

      if (wasIdle) {
        updatePresenceStatus('online');
      }

      if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
      idleTimerRef.current = setTimeout(() => {
        updatePresenceStatus('offline');
      }, PRESENCE_IDLE_TIMEOUT);
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        updatePresenceStatus('offline');
        if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
      } else {
        updatePresenceStatus('online');
        handleActivity();
      }
    };

    window.addEventListener('mousemove', handleActivity);
    window.addEventListener('keydown', handleActivity);
    window.addEventListener('click', handleActivity);
    window.addEventListener('scroll', handleActivity);
    window.addEventListener('touchstart', handleActivity);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // Explicitly set online on startup
    setTimeout(() => updatePresenceStatus('online'), 1500);

    return () => {
      window.removeEventListener('firestore-quota-exceeded', handleQuota);
      window.removeEventListener('mousemove', handleActivity);
      window.removeEventListener('keydown', handleActivity);
      window.removeEventListener('click', handleActivity);
      window.removeEventListener('scroll', handleActivity);
      window.removeEventListener('touchstart', handleActivity);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
    };
  }, []);

  // Web Push Notifications Registration & Subscription
  const setupWebPushNotifications = async () => {
    if (!import.meta.env.PROD) return; // dev mode: no SW registration at all
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      console.warn('[WebPush Client] Service Worker or Push Notifications not supported in this browser.');
      return;
    }

    try {
      // Register SW silently
      const registration = await navigator.serviceWorker.register('/service-worker.js', {
        scope: '/'
      });

      let permission = Notification.permission;
      if (permission === 'default') {
        permission = await Notification.requestPermission();
      }

      if (permission !== 'granted') {
        return;
      }

      const vapidRes = await fetch('/api/push/vapid-key');
      const { publicKey } = await vapidRes.json();
      if (!publicKey) return;

      let subscription = await registration.pushManager.getSubscription();
      
      const urlBase64ToUint8Array = (base64String: string) => {
        const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
        const base64 = (base64String + padding).replace(/\-/g, '+').replace(/_/g, '/');
        const rawData = window.atob(base64);
        const outputArray = new Uint8Array(rawData.length);
        for (let i = 0; i < rawData.length; ++i) {
          outputArray[i] = rawData.charCodeAt(i);
        }
        return outputArray;
      };

      const convertedVapidKey = urlBase64ToUint8Array(publicKey);

      if (!subscription) {
        subscription = await registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: convertedVapidKey
        });
      }

      if (accessToken) {
        await fetch('/api/push/subscribe', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          body: JSON.stringify({ subscription })
        });
      }
    } catch (e) {
      // Silence background errors
    }
  };

  // Capture beforeinstallprompt event for Chromium browsers (Chrome, Edge, Android)
  useEffect(() => {
    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      console.log('[PWA App] beforeinstallprompt event captured successfully.');
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
  }, []);

  // Show smart iPhone-style PWA modal after checking user standalone state
  useEffect(() => {
    if (accessToken && currentUser) {
      // Auto-trigger setupWebPushNotifications silently in the backgrounds
      setupWebPushNotifications();

      // Check if already launched as standalone app (already installed)
      const isStandalone = window.matchMedia('(display-mode: standalone)').matches || (navigator as any).standalone === true;
      
      if (!isStandalone) {
        const lastDismissed = localStorage.getItem('pwa_install_prompt_dismissed_at');
        const twentyFourHours = 24 * 60 * 60 * 1000;
        const isDismissedRecently = lastDismissed && (Date.now() - parseInt(lastDismissed, 10) < twentyFourHours);
        
        if (!isDismissedRecently) {
          const timer = setTimeout(() => {
            setShowPWAInstallPrompt(true);
          }, 3000); // Elegant delayed arrival
          return () => clearTimeout(timer);
        }
      }
    }
  }, [accessToken, currentUser]);

  const handleInstallPWA = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      try {
        const choiceResult = await deferredPrompt.userChoice;
        if (choiceResult.outcome === 'accepted') {
          console.log('[PWA App] User accepted installation.');
          setShowPWAInstallPrompt(false);
        }
        setDeferredPrompt(null);
      } catch (err) {
        console.warn('[PWA App] Error during PWA choice prompt execution:', err);
      }
    } else {
      // Manual instruction or iOS info fallback
      const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
      if (isIOS) {
        console.log('[PWA App] iOS manual instructions visible in modal.');
      } else {
        alert('تثبيت التطبيق: انقر على زر الخيارات (⋮) أعلى اليمين أو اليسار، ثم اضغط على "إضافة إلى الشاشة الرئيسية" (Add to Home screen).');
      }
    }
  };

  const handleDismissPWAInstall = () => {
    setShowPWAInstallPrompt(false);
    localStorage.setItem('pwa_install_prompt_dismissed_at', Date.now().toString());
  };

  // Receive routing messages from Service Worker (e.g. click navigation redirect)
  useEffect(() => {
    if (!('serviceWorker' in navigator)) return;

    const handleSWMessage = (event: MessageEvent) => {
      if (!event.data) return;
      
      if (event.data.type === 'NAVIGATE_CHAT') {
        const targetChatId = event.data.chatId;
        console.log('[WebPush App] Navigating to active chat ID from SW:', targetChatId);
        setActiveChatId(targetChatId);
      } else if (event.data.type === 'INCOMING_CALL_ACTION') {
        const { action, callId } = event.data;
        console.log('[WebPush App] Incoming call action message from SW:', action, 'Call ID:', callId);
        if (action === 'answer') {
          // Delay briefly to allow activeCall to hydrate from socket/state if needed
          setTimeout(() => {
            acceptVoiceCall();
          }, 800);
        }
      }
    };

    navigator.serviceWorker.addEventListener('message', handleSWMessage);
    return () => {
      navigator.serviceWorker.removeEventListener('message', handleSWMessage);
    };
  }, []);

  // Support answering calls or routing to specific chats via deep link query parameters
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const chatId = params.get('chatId');
    if (chatId) {
      console.log('[PWA DeepLink] Detected target chatId in URL query:', chatId);
      setActiveChatId(chatId);
      // Clean up query parameters dynamically to keep the address bar clean
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, []);

  // Support answering calls directly via deep link query parameters on active web sockets
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const callId = params.get('callId');
    const action = params.get('action');
    if (callId && action === 'answer') {
      console.log('[PWA DeepLink] Detected call answer query parameters. Triggering call acceptance...');
      window.history.replaceState({}, document.title, window.location.pathname);
      
      const timer = setTimeout(() => {
        acceptVoiceCall();
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [websocketConnected]);

  // WebSocket event handling and synchronization
  useEffect(() => {
    if (!accessToken || !currentUserId) {
      if (socketClientRef.current) {
        socketClientRef.current.disconnect();
        socketClientRef.current = null;
      }
      setWebsocketConnected(false);
      return;
    }

    if (!socketClientRef.current) {
      socketClientRef.current = SocketManager.getInstance();
    }

    const client = socketClientRef.current;
    
    if (isTokenExpired(accessToken)) {
      console.warn('[Socket Pipeline] Active access token is expired or close to expiry. Requesting fresh silent token refresh...');
      performSilentTokenRefresh();
      return;
    }

    client.connect(accessToken);

    const unsubStatus = client.on('status:change', (status: { connected: boolean }) => {
      setWebsocketConnected(status.connected);
    });

    const unsubHeartbeat = client.on('heartbeat:state', (payload: { state: string }) => {

      setWebsocketConnected(payload.state === 'CONNECTED' || payload.state === 'DEGRADED');
    });

    const unsubAuthReady = client.on('auth:ready', (payload: any) => {
      // E2EE: re-confirm registration after each successful auth (idempotent,
      // fire-and-forget — never blocks the chat UX).
      e2eeRef.current?.ensureRegistered().catch(() => {});
    });

    const unsubMsgAck = client.on('msg:ack', (ack: any) => {
      const outboxItem = outboxQueueRef.current.find(item => item.id === ack.tempMessageId);

      if (ack.tempMessageId) {
        removeFromOutbox(ack.tempMessageId);
      }

      setRawMessages((prev) => {
        const exists = prev.some((m) => m.id === ack.tempMessageId || m.id === ack.messageId);
        if (exists) {
          return prev.map((m) => {
            if (m.id === ack.tempMessageId || m.id === ack.messageId) {
              const newState = ack.status || 'sent';
              const currentState = m.state || 'sent';
              // Check STATE_ORDER to prevent downgrading (e.g. read -> sent)
              const STATE_ORDER: Record<string, number> = { 'pending': 0, 'sending': 1, 'sent': 2, 'delivered': 3, 'read': 4, 'deleted': 5 };
              const resolvedState = STATE_ORDER[newState] > STATE_ORDER[currentState] ? newState : currentState;

              return { ...m, id: ack.messageId, state: resolvedState };
            }
            return m;
          });
        } else if (outboxItem) {
          const wasE2ee = !!(outboxItem as any).e2ee;
          const isGroupE2eeAck = wasE2ee && typeof outboxItem.content === 'string' && outboxItem.content.startsWith(GROUP_WIRE_PREFIX);
          const reconstructed = {
            id: ack.messageId,
            chatId: outboxItem.chatId,
            senderId: outboxItem.senderId,
            senderName: currentUser?.displayName || currentUser?.username || 'User',
            // E2EE: the outbox carries ciphertext — we can't decrypt our own
            // sent envelope, so reconstruct as the lock placeholder instead of
            // leaking 'DIR1:...' into the UI. Attachment payloads (e2eeFiles)
            // survive in the outbox so E2eeMedia CAN still decrypt own media.
            content: wasE2ee ? '' : outboxItem.content,
            e2ee: wasE2ee,
            e2eeError: wasE2ee,
            ...(wasE2ee ? { e2eeRaw: outboxItem.content } : {}),
            ...((outboxItem as any).e2eeFiles ? { e2eeFiles: (outboxItem as any).e2eeFiles } : {}),
            createdAt: ack.createdAt || outboxItem.createdAt,
            state: 'sent',
            type: outboxItem.type,
            attachments: outboxItem.attachments || [],
            replyTo: outboxItem.replyTo
          };
          // GROUP E2EE: DIRG1 envelopes ARE self-decryptable (GroupCrypto SELF
          // path) — recover the plaintext text + media payloads (e2eeFiles)
          // async so the reconstructed copy shows real content instead of the
          // lock placeholder. 1:1 DIR1 stays on the placeholder (no self key).
          if (isGroupE2eeAck && groupCryptoRef.current && ack.messageId) {
            const gcAck = groupCryptoRef.current;
            const ackMsgId = ack.messageId;
            const ackChatId = outboxItem.chatId;
            const encContent = outboxItem.content;
            gcAck.decryptGroupMessage(ackChatId, SELF, encContent)
              .then((r) => {
                if (!(r && 'plaintext' in r && typeof r.plaintext === 'string')) return;
                try {
                  const parsed = parseEncryptedPayload(r.plaintext);
                  setRawMessages((prev2) => prev2.map((m) => {
                    if (m.id !== ackMsgId) return m;
                    const { e2eeError: _dropErr, e2eeRaw: _dropRaw, ...rest } = m;
                    return {
                      ...rest,
                      content: parsed.text,
                      ...(parsed.files.length > 0 ? { e2eeFiles: parsed.files } : {}),
                    };
                  }));
                } catch { /* keep the lock placeholder */ }
              })
              .catch(() => {});
          }
          return [...prev, reconstructed];
        }
        return prev;
      });

      setRawChats((prev) => {
        return prev.map((chat) => {
          if (chat.lastMessage && (chat.lastMessage.id === ack.tempMessageId || chat.lastMessage.id === ack.messageId)) {
            const newState = ack.status || 'sent';
            const currentState = chat.lastMessage.state || 'sent';
            const STATE_ORDER: Record<string, number> = { 'pending': 0, 'sending': 1, 'sent': 2, 'delivered': 3, 'read': 4, 'deleted': 5 };
            const resolvedState = STATE_ORDER[newState] > STATE_ORDER[currentState] ? newState : currentState;

            return {
              ...chat,
              lastMessage: {
                ...chat.lastMessage,
                id: ack.messageId,
                state: resolvedState
              }
            };
          }
          return chat;
        });
      });
    });

    return () => {
      unsubStatus();
      unsubHeartbeat();
      unsubAuthReady();
      unsubMsgAck();
    }
  }, [accessToken, currentUser]);

  // Core WS Event Bindings
  useEffect(() => {
    if (!accessToken || !currentUserId) return;

    const client = socketClientRef.current;
    if (!client) return;

    // Constant order for message delivery states to prevent backward transitions (e.g. read -> delivered)
    const STATE_ORDER: Record<string, number> = { 
      'pending': 0, 
      'sending': 1, 
      'sent': 2, 
      'delivered': 3, 
      'read': 4, 
      'deleted': 5 
    };

    // E2EE own-echo: fields the optimistic local copy keeps when a server echo
    // of OUR message arrives — plaintext text, original (rich) attachments and
    // the media decryption payloads (media E2EE).
    const ownEchoPreserve = (m: any) => ({
      content: m.content,
      e2ee: m.e2ee,
      attachments: m.attachments,
      ...(m?.e2eeFiles ? { e2eeFiles: m.e2eeFiles } : {}),
    });

    const unsubMsgNew = client.on('msg:new', (msg: any) => {
      const beforeIds = rawChatsRef.current.map(c => c.id);

      if (msg.clientMessageId) {
        removeFromOutbox(msg.clientMessageId);
      } else if (msg.id) {
        removeFromOutbox(msg.id);
      }
      
      setRawMessages((prev) => {
        if (msg.chatId !== activeChatIdRef.current) return prev;
        // E2EE own-echo guard: a server echo of OUR message must never replace
        // the local content (locally we keep the plaintext optimistic copy).
        const isOwnEcho = msg.senderId === currentUserId;
        if (prev.some((m) => m.id === msg.id)) {
          return prev.map((m) => {
            if (m.id === msg.id) {
              const newState = msg.state || 'sent';
              const currentState = m.state || 'sent';
              // Only update if state is "further" in lifecycle
              if (STATE_ORDER[newState] > STATE_ORDER[currentState]) {
                return { ...m, ...msg, ...(isOwnEcho ? { ...ownEchoPreserve(m) } : {}) };
              }
              return { ...m, ...msg, state: currentState, ...(isOwnEcho ? { ...ownEchoPreserve(m) } : {}) };
            }
            return m;
          });
        }
        if (isOwnEcho && typeof msg.content === 'string' && (msg.content.startsWith('DIR1:') || msg.content.startsWith('DIRM1:') || msg.content.startsWith(GROUP_WIRE_PREFIX))) {
          // Own echo without a local optimistic copy (e.g. ack reconstruction
          // missed): 1:1 DIR1 envelopes cannot be self-decrypted — render the
          // lock placeholder and keep the ciphertext in e2eeRaw. GROUP DIRG1
          // envelopes ARE self-decryptable (GroupCrypto SELF path): recover
          // the plaintext text + media payloads (e2eeFiles) async so the
          // sender sees their own message content and attachments again.
          if (msg.content.startsWith(GROUP_WIRE_PREFIX) && groupCryptoRef.current) {
            const gcEcho = groupCryptoRef.current;
            const encContent = msg.content;
            gcEcho.decryptGroupMessage(msg.chatId, SELF, encContent)
              .then((r) => {
                if (!(r && 'plaintext' in r && typeof r.plaintext === 'string')) return;
                try {
                  const parsed = parseEncryptedPayload(r.plaintext);
                  setRawMessages((prev2) => prev2.map((m) => {
                    if (m.id !== msg.id) return m;
                    const { e2eeError: _dropErr, e2eeRaw: _dropRaw, ...rest } = m;
                    return {
                      ...rest,
                      content: parsed.text,
                      ...(parsed.files.length > 0 ? { e2eeFiles: parsed.files } : {}),
                    };
                  }));
                } catch { /* keep the lock placeholder */ }
              })
              .catch(() => {});
          }
          return [...prev, { ...msg, e2ee: true, e2eeRaw: msg.content, content: '', e2eeError: true }]
            .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
        }
        return [...prev, msg].sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
      });

      // E2EE receive path: peer DIR1 envelopes for the ACTIVE chat are
      // decrypted async and patched into rawMessages by id. Non-DIR1 content
      // is untouched; failures fall back to the lock placeholder.
      const e2eePeerMsg = msg.senderId !== currentUserId ? e2eePeerForChat(msg.chatId) : null;
      if (e2eePeerMsg && typeof msg.content === 'string' && (msg.content.startsWith('DIR1:') || msg.content.startsWith('DIRM1:'))) {
        const encContent = msg.content;
        const engineForMsg = e2eeRef.current;
        if (engineForMsg) {
          engineForMsg.decryptMessage(e2eePeerMsg, encContent)
            .then((r) => {
              // Task C: a RekeyDetectedError means the peer's identity keys
              // changed since our last session — raise the rekey warning flag
              // (ChatWindow renders the persistent amber banner for this DM).
              if (r && 'error' in r && (r as { error: string }).error === 'RekeyDetectedError') {
                markE2eeRekey(e2eePeerMsg);
              }
              setRawMessages((prev) => prev.map((m) => {
                if (m.id !== msg.id) return m;
                if (r && 'plaintext' in r && typeof r.plaintext === 'string') {
                  // Media E2EE: parse the payload container — text becomes the
                  // plaintext text; attachment payloads ride along as e2eeFiles.
                  try {
                    const parsed = parseEncryptedPayload(r.plaintext);
                    return {
                      ...m,
                      content: parsed.text,
                      e2ee: true,
                      ...(parsed.files.length > 0 ? { e2eeFiles: parsed.files } : {}),
                    };
                  } catch {
                    // Container claimed our kind but was malformed (tamper).
                    return { ...m, e2ee: true, e2eeRaw: encContent, content: '', e2eeError: true };
                  }
                }
                return { ...m, e2ee: true, e2eeRaw: encContent, content: '', e2eeError: true };
              }));
            })
            .catch(() => {});
        }
      }

      // GROUP E2EE receive path: peer DIRG1 envelopes for the ACTIVE chat are
      // decrypted with the sender's member key (received pairwise via ctrl)
      // and patched into rawMessages by id. Non-DIRG1 content is untouched;
      // failures fall back to the lock placeholder + a fire-and-forget
      // key-request so the sender re-distributes their sender key to us.
      if (
        msg.chatId === activeChatIdRef.current &&
        msg.senderId !== currentUserId &&
        typeof msg.content === 'string' &&
        msg.content.startsWith(GROUP_WIRE_PREFIX)
      ) {
        const encContent = msg.content;
        const gcForMsg = groupCryptoRef.current;
        if (gcForMsg) {
          gcForMsg.decryptGroupMessage(msg.chatId, String(msg.senderId || ''), encContent)
            .then((r) => {
              const ok = r && 'plaintext' in r && typeof r.plaintext === 'string';
              setRawMessages((prev) => prev.map((m) => {
                if (m.id !== msg.id) return m;
                if (ok) {
                  // Media E2EE (groups): the plaintext is the same
                  // 'dirasha-msg-v1' container used by 1:1 — parse it so the
                  // text AND the attachment payloads (e2eeFiles) reach the
                  // renderer. Legacy group plaintext (pre-container) falls
                  // back to pure text inside parseEncryptedPayload.
                  try {
                    const parsed = parseEncryptedPayload((r as { plaintext: string }).plaintext);
                    return {
                      ...m,
                      content: parsed.text,
                      e2ee: true,
                      ...(parsed.files.length > 0 ? { e2eeFiles: parsed.files } : {}),
                    };
                  } catch {
                    return { ...m, e2ee: true, e2eeRaw: encContent, content: '', e2eeError: true };
                  }
                }
                return { ...m, e2ee: true, e2eeRaw: encContent, content: '', e2eeError: true };
              }));
              if (!ok) {
                requestGroupKeyFrom(msg.chatId, String(msg.senderId)).catch(() => {});
              }
            })
            .catch(() => {});
        }
      }

      setRawChats((prev) => {
        const updated = prev.map((chat) => {
          if (chat.id === msg.chatId) {
            const isNotActiveChat = msg.chatId !== activeChatIdRef.current;
            const incUnread = isNotActiveChat && msg.senderId !== currentUserId;
            
            const newState = msg.state || 'sent';
            const resolvedState = newState;

            const isNewer = !chat.lastMessage || new Date(msg.createdAt).getTime() >= new Date(chat.lastMessage.createdAt).getTime();

            return {
              ...chat,
              unreadCount: incUnread ? (chat.unreadCount || 0) + 1 : (msg.chatId === activeChatIdRef.current ? 0 : (chat.unreadCount || 0)),
              updatedAt: isNewer ? msg.createdAt : chat.updatedAt,
              lastMessage: isNewer ? {
                id: msg.id,
                content: msg.content,
                createdAt: msg.createdAt,
                senderId: msg.senderId,
                state: resolvedState
              } : chat.lastMessage
            };
          }
          return chat;
        });

        return updated.sort((a, b) => {
          const timeA = a.lastMessage ? new Date(a.lastMessage.createdAt).getTime() : new Date(a.updatedAt || 0).getTime();
          const timeB = b.lastMessage ? new Date(b.lastMessage.createdAt).getTime() : new Date(b.updatedAt || 0).getTime();
          return timeB - timeA;
        });
      });

      // Play arrival sound and emit delivery receipt
      if (msg.senderId !== currentUserId) {
        // Emit a direct message delivery receipt event back to the server
        if (socketClientRef.current) {

          socketClientRef.current.emit('msg:delivered', { chatId: msg.chatId, messageId: msg.id });
        }

        try {
          // Notification pipeline: per-chat mute → quiet hours → master toggles → sound + vibration
          const chatMutes: Record<string, number> = (currentUser as any)?.chatMutes || {};
          const muteVal = chatMutes[msg.chatId];
          const isChatMuted = muteVal === -1 || (typeof muteVal === 'number' && muteVal > Date.now());
          const notifOn = currentUser?.notificationSettings?.enabled !== false;
          const quiet = isWithinQuietHours((currentUser as any)?.notificationSettings?.quietHours);
          const chatType = (rawChatsRef.current || []).find((c: any) => c.id === msg.chatId)?.type;
          const groupAllowed = chatType === 'group'
            ? currentUser?.notificationSettings?.groupMessagesEnabled !== false
            : true;
          // WhatsApp parity: @mentions bypass mute AND quiet hours
          const mentionedMe = Array.isArray((msg as any).metadata?.mentions) &&
            (msg as any).metadata.mentions.includes(currentUserId);
          // Telegram parity: highlight keywords bypass mute AND quiet hours
          const hitKeyword = (((currentUser as any)?.notificationSettings?.highlightWords as string[]) || [])
            .some(w => w && String(msg.content || '').toLowerCase().includes(String(w).toLowerCase()));
          if ((!isChatMuted && notifOn && !quiet && groupAllowed) || (mentionedMe && notifOn) || (hitKeyword && notifOn)) {
            // Per-chat override (WhatsApp parity): custom tone + vibration win per chat
            const ovr = ((currentUser as any)?.chatNotifOverrides || {})[msg.chatId] || {};
            const soundEnabledOvr = ovr.soundUrl ? true : currentUser?.notificationSettings?.soundEnabled !== false;
            if (soundEnabledOvr) {
              const audio = new Audio(ovr.soundUrl || currentUser?.notificationSettings?.soundUrl || 'https://assets.mixkit.co/active_storage/sfx/2869/2869-120.wav');
              audio.volume = ((currentUser?.notificationSettings?.soundVolume ?? 80) / 100);
              audio.play().catch(() => {});
            }
            const vibrateOvr = ovr.vibrate || 'default';
            if ((vibrateOvr !== 'off') && (currentUser?.notificationSettings?.vibration !== false) && (navigator as any).vibrate) {
              try { (navigator as any).vibrate(vibrateOvr === 'on' ? [80, 40, 80] : 120); } catch (_) {}
            }
          }
        } catch (_) {}
      }
    });

    // Message read status update
    const unsubStateChange = client.on('msg:state:change', (change: any) => {
      let targetTime = change.targetCreatedAt 
        ? new Date(change.targetCreatedAt).getTime() 
        : new Date(change.updatedAt).getTime();

      // Immediately patch the IndexedDB explicitly
      MessagesCacheDB.get(change.chatId).then(cached => {
        if (cached && cached.length > 0) {
          let modified = false;
          const updatedCache = cached.map(m => {
            if (m.id === change.lastMessageId || new Date(m.createdAt).getTime() <= targetTime) {
              if (m.senderId === currentUserId) {
                const newState = change.state || change.status;
                const currentState = m.state || 'sent';
                if (STATE_ORDER[newState] > STATE_ORDER[currentState]) {
                  modified = true;
                  return { ...m, state: newState };
                }
              }
            }
            return m;
          });
          if (modified) {
            MessagesCacheDB.put(change.chatId, updatedCache).catch(() => {});
          }
        }
      }).catch(() => {});

      setRawMessages((prev) => {
        return prev.map((m) => {
          if (m.chatId === change.chatId) {
            if (m.id === change.lastMessageId || new Date(m.createdAt).getTime() <= targetTime) {
              if (m.senderId === currentUserId) {
                const newState = change.state || change.status;
                const currentState = m.state || 'sent';
                if (STATE_ORDER[newState] > STATE_ORDER[currentState]) {
                  return { ...m, state: newState };
                }
              }
            }
          }
          return m;
        });
      });

      // ALSO update the lastMessage state in the main conversations listing so checkmarks update instantly!
      setRawChats((prev) => {
        let targetTime = change.targetCreatedAt 
          ? new Date(change.targetCreatedAt).getTime() 
          : new Date(change.updatedAt).getTime();
          
        return prev.map((chat) => {
          if (chat.id === change.chatId && chat.lastMessage) {
            const lastMessageIsSender = chat.lastMessage.senderId === currentUserId;
            if (lastMessageIsSender && (chat.lastMessage.id === change.lastMessageId || new Date(chat.lastMessage.createdAt).getTime() <= targetTime)) {
              const newState = change.state || change.status;
              const currentState = chat.lastMessage.state || 'sent';
              if (STATE_ORDER[newState] > STATE_ORDER[currentState]) {
                return {
                  ...chat,
                  lastMessage: {
                    ...chat.lastMessage,
                    state: newState
                  }
                };
              }
            }
          }
          return chat;
        });
      });
    });

    // Ephemeral typing indicators
    const unsubTyping = client.on('presence:typing', (typing: any) => {

      if (typing.isTyping) {

      }
      setRawChats((prev) => {
        return prev.map((chat) => {
          if (chat.id === typing.chatId) {
            const currentTypingMap = { ...(chat.typing || {}) };
            if (typing.isTyping) {
              currentTypingMap[typing.userId] = typing.displayName;
            } else {
              delete currentTypingMap[typing.userId];
            }
            return { ...chat, typing: currentTypingMap };
          }
          return chat;
        });
      });
    });

    // Handle new users being created in real-time
    const unsubUserCreated = client.on('user:created', (payload: any) => {

      if (payload.user && payload.user.id !== currentUserId) {
        setAllUsers((prev) => {
          if (prev[payload.user.id]) return prev;
          return {
            ...prev,
            [payload.user.id]: {
              ...payload.user,
              avatarUrl: payload.user.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop'
            }
          };
        });
      }
    });

    // Live Presence Indicator
    const unsubPresence = client.on('presence:update', (presence: any) => {
      setAllUsers((prev) => {
        const target = prev[presence.userId] || { id: presence.userId };
        return {
          ...prev,
          [presence.userId]: {
            ...target,
            onlineStatus: presence.status,
            // BATCH-1 review fix (AB-09): the global broadcast no longer
            // carries lastSeen — keep the previously-known value instead of
            // clobbering it to undefined on every presence flip.
            ...(presence.lastSeen !== undefined ? { lastSeen: presence.lastSeen } : {}),
          }
        };
      });
    });
    
    // Sync profile upgrades across this user's sessions
    const unsubUserProfileUpdate = client.on('user:profile_update', (payload: any) => {
      if (payload.user && payload.user.id === currentUserId) {
        setCurrentUser(payload.user);
        localStorage.setItem('dirasha_user', JSON.stringify(payload.user));
        
        // Also sync into allUsers for consistent UI rendering in shared components
        setAllUsers((prev) => ({
          ...prev,
          [payload.user.id]: {
            ...(prev[payload.user.id] || {}),
            ...payload.user
          }
        }));
      }
    });

    // Sync profile upgrades from other contacts
    const unsubPresenceProfileUpdate = client.on('user:presence_profile_update', (payload: any) => {
      setAllUsers((prev) => {
        const target = prev[payload.userId] || { id: payload.userId };
        return {
          ...prev,
          [payload.userId]: {
            ...target,
            ...payload.user
          }
        };
      });
      // Force immediate update of rawChats so any derived state (like chats list) updates instantly
      setRawChats((prev) =>
        prev.map((chat) => {
          // If it's a direct chat with this user, update its snapshots
          if (chat.type === 'one-to-one' && (chat.otherMember?.id === payload.userId || chat.memberIds?.includes(payload.userId))) {
            const updatedOtherMember = (chat.otherMember?.id === payload.userId) ? { ...chat.otherMember, ...payload.user } : chat.otherMember;
            return {
              ...chat,
              name: (chat.otherMember?.id === payload.userId) ? (payload.user.displayName || chat.name) : chat.name,
              avatarUrl: (chat.otherMember?.id === payload.userId) ? (payload.user.avatarUrl || payload.user.photoURL || chat.avatarUrl) : chat.avatarUrl,
              otherMember: updatedOtherMember
            };
          }
          // If it's a group chat where they are a member, the 'chats' memo will already use allUsers
          // but we can also update any cached member snapshots if they exist
          if (chat.type === 'group' && chat.members) {
             return {
               ...chat,
               members: chat.members.map((m: any) => m.id === payload.userId ? { ...m, ...payload.user } : m)
             };
          }
          return chat;
        })
      );
    });

    // Sync apps settings updates across this user's sessions
    const unsubUserSettingsUpdate = client.on('user:settings_update', (payload: any) => {

      setCurrentUser((prev: any) => {
        if (!prev) return prev;
        const updated = { ...prev, ...payload.settings };
        localStorage.setItem('dirasha_user', JSON.stringify(updated));
        return updated;
      });
    });

    // Live chat-list sync: refresh on group membership/info changes or eviction
    const refetchChats = async () => {
      try {
        const res = await fetch('/api/chats', { headers: { Authorization: `Bearer ${TokenVault.getAccessToken()}` } });
        if (res.ok) {
          const d = await res.json();
          setRawChats(d.chats || d || []);
        }
      } catch { /* offline — caches hold */ }
    };
    const unsubChatsRefresh = client.on('chats:refresh', () => { refetchChats(); });
    // GROUP E2EE rotation: 'chat:evicted' fires when a member is removed from
    // (or leaves) a group chat — the documented trigger for sender-key
    // rotation. If I'm still in the group, the removed/leaving member must
    // never read future traffic: rotate our sender key, wipe the stale
    // distribution flags and re-distribute the fresh key to the remaining
    // members. If I'm the one leaving, just forget every key for the group.
    // P0-A rotate-on-membership helper (external-audit E2EE-01/E2EE-02):
    // rotate sender key + wipe stale dist flags + re-distribute under the new
    // epoch, remembering the server membership_version. Sends in the chat are
    // blocked until re-distribution completes (rekeyPendingRef).
    const unsubChatEvicted = client.on('chat:evicted', (payload: any) => {
      const evictChatId = String(payload?.chatId || payload?.groupId || payload?.id || '');
      if (evictChatId) {
        const removedUserId = String(payload?.userId || payload?.removedUserId || payload?.memberId || '');
        if (removedUserId && removedUserId === currentUserId) {
          // I was the one removed/leaving — forget every sender/member key for it.
          groupCryptoRef.current?.deleteGroup(evictChatId).catch(() => {});
          clearGroupDistFlags(evictChatId);
        }
        // Non-self evictions no longer rotate here — rotation is driven by
        // 'chat:membership_changed' (sent to ALL current members). The old
        // code rotated only the removed user (who received the sole event).
      }
      refetchChats();
    });
    const unsubChatMembership = client.on('chat:membership_changed', (payload: any) => {
      const mvChatId = String(payload?.chatId || '');
      const newMv = Number(payload?.membershipVersion);
      if (!mvChatId || !Number.isFinite(newMv)) return;
      rotateGroupForMembership(mvChatId, newMv);
      refetchChats();
    });
    // Security alert: new login from an unrecognized device (other devices alert)
    const unsubNewLogin = client.on('security:new_login', (payload: any) => {
      if (payload?.sessionId && payload.sessionId === TokenVault.getSessionId()) return; // this device
      pushSecurityEvent('auth-alert', { kind: 'new_login' });
      if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
        (window as any).showGlobalToast('🔔 تسجيل دخول جديد من جهاز آخر — إن لم تكن أنت، غيّر كلمة المرور فوراً.', 'error');
      }
    });

    // Security alert: unified live security push (new login IP / failed attempts / password change)
    const unsubSecurityAlert = client.on('security:alert', (payload: any) => {
      // Monitoring: server-pushed auth alert (metadata only — title/body may
      // carry user-facing text, so only the structured kind is recorded).
      pushSecurityEvent('auth-alert', { kind: typeof payload?.kind === 'string' ? payload.kind : 'alert' });
      const title = payload?.title || 'تنبيه أمني';
      const body = payload?.body || '';
      const text = title + (body ? ' — ' + body : '');
      if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
        if (payload?.kind === 'new_login') {
          (window as any).showGlobalToast(text, 'info');
        } else {
          // failed_attempt / password_changed → alarming toast (ToastProvider supports 'error')
          (window as any).showGlobalToast(text, 'error');
        }
      }
    });

    // Security: Handle session revocation and account deletion
    const unsubSessionRevoked = client.on('session:revoked', (payload: any) => {
      const mySessionId = TokenVault.getSessionId();
      if (payload.sessionId === mySessionId) {
        handleLogout();
        console.log('[Security] Current session revoked from server.');
      }
    });

    const unsubSessionRevokeOthers = client.on('session:revoke_others', (payload: any) => {
      const mySessionId = TokenVault.getSessionId();
      if (payload.currentSessionId !== mySessionId) {
        handleLogout();
        console.log('[Security] Other session revoked this session.');
      }
    });

    const unsubAccountDeleted = client.on('account:deleted', () => {
      handleLogout();
      console.log('[Security] Account has been deleted.');
    });

    const unsubAuthRevoked = client.on('auth:revoked', (payload: any) => {
      if ((window as any).showGlobalToast) {
        (window as any).showGlobalToast(payload?.reason || 'تم حظر حسابك وتسجيل خروجك.', 'error');
      }
      handleLogout();
    });

    const unsubUserWarning = client.on('user:warning', (payload: any) => {
      if ((window as any).showGlobalToast) {
        (window as any).showGlobalToast(`تحذير إداري: ${payload.reason}`, 'error');
      }
    });

    const unsubModerationUpdate = client.on('user:moderation_update', (payload: any) => {
      if (payload.type === 'MUTE') {
        if ((window as any).showGlobalToast) {
          (window as any).showGlobalToast(`تم تقييد حسابك. السبب: ${payload.muteReason}`, 'error');
        }
      } else if (payload.type === 'UNMUTE') {
        if ((window as any).showGlobalToast) {
          (window as any).showGlobalToast('تم إزالة التقييد عن حسابك.', 'success');
        }
      }
      
      setCurrentUser((prev: any) => {
        if (!prev) return prev;
        const updated = { ...prev, mutedUntil: payload.mutedUntil, muteReason: payload.muteReason };
        localStorage.setItem('dirasha_user', JSON.stringify(updated));
        return updated;
      });
    });

    const unsubMuteReport = client.on('moderation:mute_report', (payload: any) => {
      if ((window as any).showGlobalToast) {
        (window as any).showGlobalToast(`أنت مقيد ولا يمكنك إرسال الرسائل. السبب: ${payload.reason}`, 'error');
      }
    });

    // Stream new chats/rooms instantly
    const unsubChatNew = client.on('chat:new', (payload: any) => {

      setRawChats((prev) => {
        if (prev.some((c) => c.id === payload.chat.id)) return prev;
        return [payload.chat, ...prev];
      });
    });

    // Stream edited messages
    const unsubMsgEdit = client.on('msg:edit', (payload: any) => {
      // P0-B (external-audit E2EE-03): edit content may now be an E2EE
      // envelope — decrypt before display. Own DM edits keep the optimistic
      // local content (self-DIR1 envelopes are undecryptable by design);
      // peers decrypt. Groups decrypt via SELF (sender can decrypt own).
      (async () => {
        let content = payload.content;
        let failed = false;
        if (typeof content === 'string' && payload.chatId && (content.startsWith('DIR1:') || content.startsWith('DIRM1:') || content.startsWith('DIRG1:')))
        {
          const me = currentUserId;
          const isGroupEnvelope = content.startsWith('DIRG1:');
          const isSelfDmEdit = !isGroupEnvelope && String(payload.senderId || '') === me;
          if (isSelfDmEdit) {
            content = null; // keep local optimistic content
          } else {
            try {
              content = await decryptContentForChat(payload.chatId, content, String(payload.senderId || 'self'));
            } catch {
              failed = true;
            }
// keep envelope marker off — content stays the failed-plaintext marker
          }
        }
        const applyEdit = (m: any) => m.id === payload.messageId
          ? { ...m, ...(content !== null ? { content } : {}), ...(failed ? { e2eeError: true } : {}), editedAt: payload.editedAt }
          : m;
        setRawMessages((prev) => prev.map(applyEdit));
        setRawChats((prev) => prev.map((chat) => {
          if (chat.id === payload.chatId && chat.lastMessage?.id === payload.messageId) {
            return { ...chat, lastMessage: { ...chat.lastMessage, ...(content !== null ? { content } : {}) } };
          }
          return chat;
        }));
      })();
    });

    // Stream deleted messages for everyone
    const unsubMsgDeleteEveryone = client.on('msg:delete:everyone', (payload: any) => {

      setRawMessages((prev) =>
        prev.map((m) =>
          m.id === payload.messageId
            ? { ...m, content: '🚫 Message deleted', state: 'deleted', deletedAt: payload.deletedAt, attachments: [] }
            : m
        )
      );
      setRawChats((prev) =>
        prev.map((chat) => {
          if (chat.id === payload.chatId && chat.lastMessage?.id === payload.messageId) {
            return {
              ...chat,
              lastMessage: {
                ...chat.lastMessage,
                content: '🚫 Message deleted',
                state: 'deleted'
              }
            };
          }
          return chat;
        })
      );
    });

    // Stream deleted messages for single user (me)
    const unsubMsgDeleteMe = client.on('msg:delete:me', (payload: any) => {

      setRawMessages((prev) => prev.filter((m) => m.id !== payload.messageId));
    });

    // Stream message reactions toggle update
    const unsubMsgReact = client.on('msg:react', (payload: any) => {
      setRawMessages((prev) =>
        prev.map((m) =>
          m.id === payload.messageId
            ? { ...m, reactions: payload.reactions }
            : m
        )
      );
      // Reaction notifications (WhatsApp parity): someone reacted to MY message
      try {
        const mine = rawMessagesRef?.current?.some?.((m: any) => m.id === payload.messageId && m.senderId === currentUserId);
        const reactor = payload.reactorId && payload.reactorId !== currentUserId;
        if (mine && reactor && currentUser?.notificationSettings?.reactionNotifications !== false) {
          if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
            (window as any).showGlobalToast(`${payload.emoji || 'تفاعل'} تفاعل أحدهم مع رسالتك.`, 'info');
          }
        }
      } catch (_) { /* non-fatal */ }
    });

    // Stream message star updates
    const unsubMsgStar = client.on('msg:star', (payload: any) => {

      setRawMessages((prev) =>
        prev.map((m) =>
          m.id === payload.messageId
            ? { ...m, starredBy: payload.starredBy }
            : m
        )
      );
      window.dispatchEvent(new Event('starred-messages-updated'));
    });

    // Stream message pin adjustments
    const unsubMsgPin = client.on('msg:pin', (payload: any) => {

      setRawMessages((prev) =>
        prev.map((m) =>
          m.id === payload.messageId
            ? { ...m, isPinned: payload.isPinned }
            : m
        )
      );
    });

    // Real-Time WebRTC Call Signal Receivers
    const unsubCallInitiate = client.on('call:initiate', (payload: any) => {
      const receiveTimestamp = Date.now();
      const latency = receiveTimestamp - (payload.sentAt || receiveTimestamp);
      console.log(`[Latency Monitor] [call:initiate] Incoming call received in ${latency}ms after emit. Initializing Ringing.`);
      console.log('[Socket] Incoming call payload details:', payload);
      
      const currentCall = activeCallRef.current;
      if (peerConnectionRef.current || currentCall) {
        console.log('[CallManager] Peer is currently busy, sending busy rejection');
        client.emit('call:respond', {
          callId: payload.callId,
          callerId: payload.callerId,
          accepted: false,
          reason: 'busy'
        });
        return;
      }

      // Busy while inside a group call (mesh lives outside peerConnectionRef)
      if (groupCallStateRef.current) {
        client.emit('call:respond', {
          callId: payload.callId,
          callerId: payload.callerId,
          accepted: false,
          reason: 'busy'
        });
        return;
      }

      const otherUser = allUsersRef.current[payload.callerId];
      // Notification setting: call notifications can be silenced entirely —
      // the caller hears it ring forever while this side stays silent.
      if (currentUser?.notificationSettings?.callNotifications === false) {
        client.emit('call:respond', {
          callId: payload.callId,
          callerId: payload.callerId,
          accepted: false,
          reason: 'notifications disabled'
        });
        return;
      }

      // Ref-first sync: the ringing UI is clickable the instant it renders, and
      // a very fast tap could otherwise reach acceptVoiceCall before React's
      // effect mirror synced activeCallRef — observed live as "bypassed: state
      // mismatch" on a 160ms click. Writing the ref synchronously kills the race.
      const incomingCall: NonNullable<typeof activeCall> = {
        callId: payload.callId,
        chatId: payload.chatId || '',
        role: 'callee',
        partnerId: payload.callerId,
        partnerName: otherUser?.displayName || payload.callerName || 'شريك اتصال',
        partnerAvatar: otherUser?.avatarUrl,
        status: 'ringing',
        type: payload.type || 'voice',
        offer: payload.offer
      };
      activeCallRef.current = incomingCall;
      setActiveCall(incomingCall);
    });

    const unsubCallRespond = client.on('call:respond', async (payload: any) => {
      const receiveTimestamp = Date.now();
      const latency = receiveTimestamp - (payload.sentAt || receiveTimestamp);
      console.log(`[Latency Monitor] [call:respond] Call response packet received in ${latency}ms after send. Status: ${payload.accepted ? 'Accepted' : 'Rejected'}`);
      console.log('[Socket] Call respond received payload:', payload);
      
      const currentCall = activeCallRef.current;
      console.log('[CALL_RESPOND_DEBUG]', {
        activeCall: currentCall,
        activeCallId: currentCall?.callId,
        payloadCallId: payload?.callId,
        peerConnectionExists: !!peerConnectionRef.current,
        callState: currentCall?.status
      });

      if (!peerConnectionRef.current || !currentCall || currentCall.callId !== payload.callId) {
        console.warn('[CallManager] Call respondent condition check failed. Ignoring respond packet.');
        return;
      }

      if (!payload.accepted) {
        console.log(`[CallManager] Call was rejected. reason: ${payload.reason}`);
        dispatchSystemCallMessage(currentCall, payload.reason || 'rejected');
        setActiveCall(prev => prev ? { ...prev, status: 'ended' } : null);
        setTimeout(() => {
          cleanupCallState();
        }, 2000);
        return;
      }

      console.log('[CallManager] Transitioning status to connecting');
      setActiveCall(prev => prev ? { ...prev, status: 'connecting' } : null);
      try {
        console.log('[CallManager] RTCSessionDescription: Running setRemoteDescription with Answer SDP');
        await peerConnectionRef.current.setRemoteDescription(new RTCSessionDescription(payload.answer));
        console.log('[CallManager] RTCSessionDescription: setRemoteDescription successful! (Caller)');
        
        while (iceCandidatesBufferRef.current.length > 0) {
          const candidate = iceCandidatesBufferRef.current.shift();
          if (candidate) {
            console.log('[CallManager] Flushing buffered candidate into PeerConnection:', candidate);
            await peerConnectionRef.current.addIceCandidate(new RTCIceCandidate(candidate)).catch(e => {
              console.warn('[CallManager] Flushed candidate append failed:', e);
            });
          }
        }
      } catch (err: any) {
        console.error('[CallManager] SDP Answer installation failed:', err);
        handleEndCall();
      }
    });

    const unsubCallSignal = client.on('call:signal', async (payload: any) => {
      const receiveTimestamp = Date.now();
      const latency = receiveTimestamp - (payload.sentAt || receiveTimestamp);
      console.log(`[Latency Monitor] [call:signal] Dynamic WebRTC signal received in ${latency}ms.`);

      const currentCall = activeCallRef.current;
      if (!currentCall || currentCall.callId !== payload.callId) return;

      // T1: peer-driven ICE restart coordination
      if (payload.signal?.iceRestart === true) {
        console.log('[CallManager] Peer requested ICE restart — restarting local ICE agent');
        try {
          peerConnectionRef.current?.restartIce();
        } catch (err: any) {
          console.warn('[CallManager] Peer-initiated restartIce() failed:', err?.message);
        }
        return;
      }

      const candidateInit = payload.signal?.candidate;
      if (!candidateInit) return;

      if (peerConnectionRef.current && peerConnectionRef.current.remoteDescription) {
        console.log('[CallManager] Dynamically appending candidate:', candidateInit);
        await peerConnectionRef.current.addIceCandidate(new RTCIceCandidate(candidateInit)).catch(err => {
          console.warn('[CallManager] Dynamic ICE append failed:', err);
        });
      } else {
        console.log('[CallManager] buffering candidate because remote description is not set yet');
        iceCandidatesBufferRef.current.push(candidateInit);
      }
    });

    const unsubCallEnd = client.on('call:end', (payload: any) => {
      const currentCall = activeCallRef.current;
      if (!currentCall || currentCall.callId !== payload.callId) return;
      console.log('[Socket] Call end packet received:', payload);
      
      if (currentCall.role === 'caller') {
        dispatchSystemCallMessage(currentCall, payload.reason || 'ended');
      }
      
      setActiveCall(prev => prev ? { ...prev, status: 'ended' } : null);
      setTimeout(() => {
        cleanupCallState();
      }, 1000);
    });

    // T3/T4: server-side missed call broadcast → in-app toast (callee side)
    const unsubCallMissed = client.on('call:missed', (payload: any) => {
      console.log('[CallManager] Missed call notification received:', payload);
      if ((window as any).showGlobalToast) {
        (window as any).showGlobalToast(`📞 مكالمة فائتة من ${payload.callerName || 'رقم غير معروف'}`, 'error');
      }
    });

    // T4: server-side rejection (offline callee / DM policy / unknown callers)
    const unsubCallRejected = client.on('call:rejected', (payload: any) => {
      const currentCall = activeCallRef.current;
      if (!currentCall || currentCall.callId !== payload.callId) return;
      console.log(`[CallManager] Call ${payload.callId} rejected by server: ${payload.reason}`);
      if ((window as any).showGlobalToast) {
        (window as any).showGlobalToast(`تعذر إتمام المكالمة: ${payload.reason || 'مرفوضة'}`, 'error');
      }
      cleanupCallState();
    });

    // ── Group-call signaling receivers (mesh ≤4, separate from 1:1 state) ──
    const unsubGroupInvite = client.on('groupcall:invite', (payload: any) => {
      if (!payload?.groupCallId || !payload?.chatId) return;
      console.log('[GroupCallManager] Group-call invite received:', payload);
      if (groupCallStateRef.current) return; // already in a group call
      if (activeCallRef.current || peerConnectionRef.current) {
        if ((window as any).showGlobalToast) {
          (window as any).showGlobalToast(`📞 ${payload.initiatorName || 'أحد الأعضاء'} بدأ مكالمة جماعية — أنت في مكالمة أخرى.`, 'info');
        }
        return;
      }
      if (groupInviteTimerRef.current) clearTimeout(groupInviteTimerRef.current);
      setGroupIncomingInvite({
        groupCallId: payload.groupCallId,
        chatId: payload.chatId,
        chatName: payload.chatName || 'مجموعة',
        initiatorId: payload.initiatorId || '',
        initiatorName: payload.initiatorName || 'أحد الأعضاء',
        type: payload.callType === 'video' ? 'video' : 'voice',
      });
      // One-shot broadcast → client-side auto-dismiss after 45s
      groupInviteTimerRef.current = setTimeout(() => {
        setGroupIncomingInvite(null);
        groupInviteTimerRef.current = null;
      }, 45000);
    });

    const unsubGroupSignal = client.on('groupcall:signal', (payload: any) => {
      const gc = groupCallStateRef.current;
      if (!gc || !payload?.groupCallId || payload.groupCallId !== gc.groupCallId) return;
      groupMeshRef.current?.handleSignal(payload.senderId, payload.signal);
    });

    const unsubGroupPeerJoined = client.on('groupcall:peer-joined', (payload: any) => {
      const gc = groupCallStateRef.current;
      if (!gc || !payload?.groupCallId || payload.groupCallId !== gc.groupCallId) return;
      const uid = payload.userId;
      if (!uid || uid === currentUserId) return;
      console.log(`[GroupCallManager] Peer joined: ${uid}`);
      setGroupCallTiles(prev => prev.some(t => t.userId === uid) ? prev : [
        ...prev,
        {
          userId: uid,
          displayName: allUsersRef.current[uid]?.displayName || 'عضو المجموعة',
          avatarUrl: allUsersRef.current[uid]?.avatarUrl,
          state: 'connecting' as const,
        },
      ]);
      // Dial the late joiner: impolite peers offer immediately, polite wait.
      groupMeshRef.current?.addPeer(uid);
    });

    const unsubGroupPeerLeft = client.on('groupcall:peer-left', (payload: any) => {
      const gc = groupCallStateRef.current;
      if (!gc || !payload?.groupCallId || payload.groupCallId !== gc.groupCallId) return;
      const uid = payload.userId;
      if (!uid) return;
      console.log(`[GroupCallManager] Peer left: ${uid}`);
      groupMeshRef.current?.handlePeerLeft(uid);
      setGroupRemoteStreams(prev => {
        const next = { ...prev };
        delete next[uid];
        return next;
      });
      const remaining = groupCallTilesRef.current.filter(t => t.userId !== uid && t.state !== 'left');
      if (remaining.length === 0 && gc.status !== 'joining') {
        // Everyone else is gone — close the call locally.
        if ((window as any).showGlobalToast) {
          (window as any).showGlobalToast('انتهت المكالمة الجماعية — غادر جميع المشاركين.', 'info');
        }
        teardownGroupCall(true);
      } else {
        setGroupCallTiles(prev => prev.map(t => t.userId === uid ? { ...t, state: 'left' as const } : t));
      }
    });

    const unsubModerationReport = client.on('moderation:new_report', (report: any) => {
      const stored = localStorage.getItem('dirasha_user');
      if (stored) {
        try {
          const u = JSON.parse(stored);
          if (u?.role === 'admin' || u?.role === 'developer') {
            setUnreadReportsCount(prev => prev + 1);
            if ((window as any).showGlobalToast) {
              (window as any).showGlobalToast(`بلاغ جديد: ${report.category}`, 'info');
            }
            const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/1120/1120-120.wav');
            audio.volume = 0.45;
            audio.play().catch(() => {});
          }
        } catch (_) {}
      }
    });

    // E2EE rekey: when the server signals a peer's keys were re-registered /
    // rotated, drop the local ratchet session so the next send re-runs X3DH
    // with the peer's fresh bundle — and raise the 'e2eeRekey' warning flag
    // (Task C) so the ChatWindow amber banner shows for that DM.
    // Multi-device: a peer registered a NEW device → drop our cached device
    // list for that peer so the next send fan-outs to the fresh fleet.
    const unsubDevicesChanged = client.on('e2ee:devices_changed', (payload: any) => {
      const peerId = payload?.userId;
      if (peerId && e2eeRef.current) {
        try { e2eeRef.current.clearDeviceCache(peerId); } catch { /* engine swapped */ }
      }
    });
    const unsubE2eeRekey = client.on('e2ee:rekey', (payload: any) => {
      const peerId = payload?.userId || payload?.uid || payload?.peerId;
      if (peerId && typeof peerId === 'string') {
        // Monitoring: identity/fleet key change observed (metadata only).
        pushSecurityEvent('identity-change', { peerId });
        markE2eeRekey(peerId);
        e2eeRef.current?.deleteSession(peerId).catch(() => {});
      }
    });

    // GROUP E2EE ctrl channel: sender-key distribution payloads and key
    // requests travel PAIRWISE — the outer DIR1 envelope is opened by the 1:1
    // engine, then the inner 'dirasha-ctrl-v1' JSON is applied to GroupCrypto.
    // Ctrl payloads are control-plane only: they are never persisted as
    // messages and never render anywhere (nothing to filter in the UI).
    //   'sender-key'  → store the peer's sender key for that group.
    //   'key-request' → the peer failed to decrypt us — reset their dist flag
    //                    and re-send OUR sender key (fresh keyId after rotation).
    const unsubE2eeCtrl = client.on('e2ee:ctrl', (frame: any) => {
      const fromUserId = frame?.fromUserId;
      const groupId = frame?.groupId;
      const payload = frame?.payload;
      if (!fromUserId || typeof fromUserId !== 'string' || !groupId || typeof payload !== 'string') return;
      (async () => {
        const engine = e2eeRef.current;
        const gc = groupCryptoRef.current;
        if (!engine || !gc) return;
        const r = await engine.decryptMessage(fromUserId, payload);
        if (!r || !('plaintext' in r) || typeof r.plaintext !== 'string') return;
        let parsed: unknown;
        try { parsed = JSON.parse(r.plaintext); } catch { return; }
        const p = parsed as any;
        if (!p || typeof p !== 'object' || p.kind !== GROUP_CTRL_KIND) return;
        if (p.type === 'key-request') {
          if (typeof p.groupId === 'string' && p.groupId) {
            // F3 (audit H1): the requesting peer MUST be a member of the group
            // per the LOCAL chat roster (rawChatsRef membership for that
            // group). Anything else is dropped SILENTLY (log-only) — an
            // outbound 'e2ee:ctrl' frame is never emitted, so no sender-key
            // material can leak to a non-member even if the frame somehow
            // reached this handler. (Honest limitation, see rosterMemberIds
            // in group.ts: the roster is client-side; the server relay ALSO
            // enforces membership server-side via db.getChatMembers — both
            // layers. A stale local roster can only over-DENY, never
            // over-grant; the requester's own retry paths recover after
            // hydration.)
            const requestChat = (rawChatsRef.current || []).find((c: any) => c?.id === p.groupId);
            if (!isRosterMember(requestChat, fromUserId, currentUserId)) {
              console.warn('[E2EE] key-request from non-member dropped');
              // Monitoring: authorization denial on the key-distribution path.
              pushSecurityEvent('authz-denied', { scope: 'group-key-request', fromPeerId: fromUserId });
              return;
            }
            clearGroupDistFlag(p.groupId, fromUserId);
            await distributeGroupKeyToPeer(p.groupId, fromUserId);
          }
          return;
        }
        if (isCtrlPayload(parsed)) {
          await gc.processControl(fromUserId, parsed);
        }
      })().catch(() => {});
    });

    return () => {
      joinedRoomsRef.current.clear();
      unsubModerationReport();
      unsubE2eeRekey();
      unsubDevicesChanged();
      unsubE2eeCtrl();
      unsubMsgNew();
      unsubStateChange();
      unsubTyping();
      unsubUserCreated();
      unsubPresence();
      unsubUserProfileUpdate();
      unsubPresenceProfileUpdate();
      unsubUserSettingsUpdate();
      unsubChatNew();
      unsubMsgEdit();
      unsubMsgDeleteEveryone();
      unsubMsgDeleteMe();
      unsubMsgReact();
      unsubMsgStar();
      unsubMsgPin();
      unsubSessionRevoked();
      unsubSessionRevokeOthers();
      unsubAccountDeleted();
      unsubAuthRevoked();
      unsubUserWarning();
      unsubModerationUpdate();
      unsubMuteReport();
      unsubChatsRefresh();
      unsubChatEvicted();
      unsubNewLogin();
      unsubSecurityAlert();
      unsubCallInitiate();
      unsubCallRespond();
      unsubCallSignal();
      unsubCallEnd();
      unsubCallMissed();
      unsubCallRejected();
      unsubGroupInvite();
      unsubGroupSignal();
      unsubGroupPeerJoined();
      unsubGroupPeerLeft();
      if (groupInviteTimerRef.current) { clearTimeout(groupInviteTimerRef.current); groupInviteTimerRef.current = null; }
    };
  }, [accessToken, currentUserId]);

  // Join Room over WebSocket when activeChatId changes
  useEffect(() => {
    if (activeChatId && socketClientRef.current && websocketConnected) {
      // Clear local unread status immediately for better UX
      setRawChats(prev => prev.map(chat => {
        if (chat.id === activeChatId && chat.unreadCount > 0) {
          return { ...chat, unreadCount: 0 };
        }
        return chat;
      }));

      // Always emit msg:read when switching to a chat, regardless of join state
      socketClientRef.current.emit('msg:read', { chatId: activeChatId, lastMessageId: 'latest' });

      if (!joinedRoomsRef.current.has(activeChatId)) {
        socketClientRef.current.joinRoom(activeChatId);
        joinedRoomsRef.current.add(activeChatId);
      }
    }
  }, [activeChatId, websocketConnected]);

  // Join all chat rooms over WebSocket to receive background real-time messages and updates across devices
  useEffect(() => {
    if (rawChats.length > 0 && socketClientRef.current && websocketConnected) {
      const socket = socketClientRef.current;
      rawChats.forEach(chat => {
        if (!joinedRoomsRef.current.has(chat.id)) {

          socket.joinRoom(chat.id);
          joinedRoomsRef.current.add(chat.id);
        }
      });
    }
  }, [rawChats, websocketConnected]);

  // 1c. Presence ticker to force-update and clean stale online statuses dynamically on the client
  useEffect(() => {
    const timer = setInterval(() => {
      setPresenceTick((prev) => prev + 1);
    }, 2000); // Trigger visual refresh every 2 seconds for ultra-responsive "last seen" indicators

    return () => clearInterval(timer);
  }, []);

  // 1d. Live active current user sync from Relational Database via REST
  useEffect(() => {
    if (!currentUserId || !accessToken) return;

    const fetchMe = async () => {
      try {
        const res = await fetch('/api/users/me', {
          headers: { 'Authorization': `Bearer ${accessToken}` }
        });
        if (res.ok) {
          const { user } = await res.json();
          if (user) {
            setCurrentUser((prev: any) => {
              if (!prev) return { id: currentUserId, uid: currentUserId, ...user };
              return { ...prev, ...user, id: currentUserId, uid: currentUserId };
            });

            // Display unseen offline warnings
            if (user.unseenWarnings && user.unseenWarnings.length > 0) {
              if ((window as any).showGlobalToast) {
                user.unseenWarnings.forEach((warning: any) => {
                  (window as any).showGlobalToast(`تحذير إداري: ${warning.reason}`, 'error');
                });
              }
            }
            // Display mute status notification if active
            if (user.mutedUntil && new Date(user.mutedUntil) > new Date()) {
               if ((window as any).showGlobalToast) {
                  (window as any).showGlobalToast(`حسابك مقيد مؤقتاً ولن تتمكن من النشر أو الإرسال.`, 'error');
               }
            }
          }
        }
      } catch (err) {

      }
    };

    fetchMe();
    const interval = setInterval(fetchMe, 120000); // Check for server-side profile updates every 120 seconds
    return () => clearInterval(interval);
  }, [currentUserId, accessToken]);

  // Fetch pending reports count for moderators
  useEffect(() => {
    if (!accessToken || !currentUser) return;
    const role = currentUser.role;
    if (role === 'admin' || role === 'developer') {
      fetch('/api/moderation/reports?status=Pending', {
        headers: { 'Authorization': `Bearer ${accessToken}` }
      })
        .then(res => res.json())
        .then(data => {
          if (data.success && data.reports) {
            setUnreadReportsCount(data.reports.length);
          }
        })
        .catch(() => {});
    }
  }, [accessToken, currentUser]);

  // 1. Silent token refresh (Startup dual-check - Stage 4)
  useEffect(() => {
    const initAuth = async () => {
      try {
        const storedUser = localStorage.getItem('dirasha_user');
        const storedToken = TokenVault.getAccessToken(); // P1: memory vault (absorbs legacy LS token once)
        if (storedUser && storedToken) {
          try {
            const parsed = JSON.parse(storedUser);
            let res = await fetch('/api/users/me', {
              headers: { 'Authorization': `Bearer ${storedToken}` }
            });
            if (res.ok) {
              const data = await res.json();
              const verifiedUser = { ...parsed, ...data.user, id: parsed.uid || parsed.id, uid: parsed.uid || parsed.id };
              setCurrentUser(verifiedUser);
              setAccessToken(storedToken);
              TokenVault.setAccessToken(storedToken);
              localStorage.setItem('dirasha_user', JSON.stringify(verifiedUser));

              if (data.user?.unseenWarnings && data.user.unseenWarnings.length > 0) {
                if ((window as any).showGlobalToast) {
                   data.user.unseenWarnings.forEach((warning: any) => {
                     (window as any).showGlobalToast(`تحذير إداري: ${warning.reason}`, 'error');
                   });
                }
              }
              if (data.user?.mutedUntil && new Date(data.user.mutedUntil) > new Date()) {
                 if ((window as any).showGlobalToast) {
                    (window as any).showGlobalToast(`حسابك مقيد مؤقتاً ولن تتمكن من النشر أو الإرسال.`, 'error');
                 }
              }

            } else {

              // P1-hardening: cookie-based refresh (legacy LS token sent once for migration)
              const storedRefToken = TokenVault.getLegacyRefreshToken();
              const refreshRes = await fetch('/api/auth/refresh', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'same-origin',
                body: JSON.stringify({ refreshToken: storedRefToken || '' })
              });
              if (refreshRes.ok) {
                const data = await refreshRes.json();
                if (data.accessToken && data.user) {

                  const verifiedUser = { ...parsed, ...data.user, id: data.user.id, uid: data.user.id };
                  setCurrentUser(verifiedUser);
                  setAccessToken(data.accessToken);
                  TokenVault.setAccessToken(data.accessToken);
                  localStorage.setItem('dirasha_user', JSON.stringify(verifiedUser));
                  if (data.sessionId) {
                    TokenVault.setSessionId(data.sessionId);
                  }
                  TokenVault.clearLegacyRefreshToken();
                  return;
                }
              } else if (refreshRes.status === 403) {
                // Revocation anomaly — legacy token dead server-side; discard it.
                pushSecurityEvent('migration-failure', { stage: 'legacy-refresh-token', status: 403 });
                TokenVault.clearLegacyRefreshToken();
              }
              localStorage.removeItem('dirasha_user');
              TokenVault.clearVault();
              setCurrentUser(null);
              setAccessToken(null);
            }
          } catch (_) {
            try {
              const parsed = JSON.parse(storedUser);
              setCurrentUser(parsed);
              setAccessToken(storedToken);
            } catch (_) {}
          }
        } else {
          try {

            // P1-hardening: cookie-based refresh (legacy LS token sent once for migration)
            const storedRefToken = TokenVault.getLegacyRefreshToken();
            const refreshRes = await fetch('/api/auth/refresh', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              credentials: 'same-origin',
              body: JSON.stringify({ refreshToken: storedRefToken || '' })
            });
            if (refreshRes.ok) {
              const data = await refreshRes.json();
              if (data.accessToken && data.user) {

                const verifiedUser = { ...data.user, id: data.user.id, uid: data.user.id };
                setCurrentUser(verifiedUser);
                setAccessToken(data.accessToken);
                TokenVault.setAccessToken(data.accessToken);
                localStorage.setItem('dirasha_user', JSON.stringify(verifiedUser));
                if (data.sessionId) {
                  TokenVault.setSessionId(data.sessionId);
                }
                TokenVault.clearLegacyRefreshToken();
              } else {
                setCurrentUser(null);
                setAccessToken(null);
              }
            } else if (refreshRes.status === 403) {
              // Revocation anomaly — legacy token dead server-side; discard it.
              pushSecurityEvent('migration-failure', { stage: 'legacy-refresh-token', status: 403 });
              TokenVault.clearLegacyRefreshToken();
            } else {
              setCurrentUser(null);
              setAccessToken(null);
            }
          } catch (_) {
            setCurrentUser(null);
            setAccessToken(null);
          }
        }
      } finally {
        setCheckingAuth(false);
      }
    };
    initAuth();
  }, []);

  // Immediate Service Worker registration (production only).
  // In development we actively PURGE any stale SW/caches — a cached legacy shell
  // was the white-screen culprit.
  useEffect(() => {
    let focusListener: (() => void) | null = null;
    let registrationInstance: ServiceWorkerRegistration | null = null;

    if (import.meta.env.DEV) {
      navigator.serviceWorker?.getRegistrations?.().then((regs) => regs.forEach((r) => r.unregister()));
      if ('caches' in window) {
        caches.keys().then((keys) => keys.forEach((k) => caches.delete(k)));
      }
      return;
    }

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/service-worker.js', { scope: '/' })
        .then((registration) => {
          registrationInstance = registration;
          console.log('[ServiceWorker] Registered successfully with scope:', registration.scope);
          
          // Force worker update check immediately on app load
          registration.update().catch((err) => console.debug('[ServiceWorker] Update check deferred:', err));

          // Check for updates when the tab gains focus or user returns to the app
          focusListener = () => {
            if (registrationInstance) {
              registrationInstance.update().catch((err) => console.debug('[ServiceWorker] Update check on focus deferred:', err));
            }
          };
          window.addEventListener('focus', focusListener);
        })
        .catch((err) => console.warn('[ServiceWorker] Caching sw activation deferred:', err));

      // Force instant client page reload when the new service worker is installed & activated
      let refreshing = false;
      const handleControllerChange = () => {
        if (!refreshing) {
          refreshing = true;
          console.log('[ServiceWorker] New Service Worker activated. Forcing page reload to update assets...');
          window.location.reload();
        }
      };
      
      navigator.serviceWorker.addEventListener('controllerchange', handleControllerChange);
      
      return () => {
        if (focusListener) {
          window.removeEventListener('focus', focusListener);
        }
        navigator.serviceWorker.removeEventListener('controllerchange', handleControllerChange);
      };
    }
  }, []);

  // 1b. Periodic background token refresh every 10 minutes (Stage 4)
  useEffect(() => {
    if (!accessToken || !currentUserId) return;
    const interval = window.setInterval(() => {
      performSilentTokenRefresh();
    }, 10 * 60 * 1000); // 10 minutes
    return () => clearInterval(interval);
  }, [accessToken, currentUserId]);

  // 1c. Proactive token re-verification on reconnection/tab activation
  useEffect(() => {
    if (!accessToken || !currentUserId) return;
    const handleReverificationEvents = () => {
      if (isTokenExpired(accessToken)) {
        console.log('[App Recovery] Window focus or internet connection restored with expired token. Triggering auto-recovery...');
        performSilentTokenRefresh();
      }
    };
    window.addEventListener('focus', handleReverificationEvents);
    window.addEventListener('online', handleReverificationEvents);
    return () => {
      window.removeEventListener('focus', handleReverificationEvents);
      window.removeEventListener('online', handleReverificationEvents);
    };
  }, [accessToken, currentUserId]);

  // 2. Fetch or sync available user registries to map names and presence styles
  useEffect(() => {
    if (!currentUserId || !accessToken) return;
    
    const fetchAllUsersList = async () => {
      try {
        const pageUsers = await fetchAllUsersPaginated(accessToken);
        {
          const data = { users: pageUsers };
          if (data && data.users) {
            const uMap: Record<string, any> = {};
            data.users.forEach((u: any) => {
              uMap[u.id] = { id: u.id, ...u, avatarUrl: u.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop' };
            });
            if (currentUser && currentUserId) {
              uMap[currentUserId] = {
                ...currentUser,
                id: currentUserId,
                avatarUrl: currentUser.avatarUrl || currentUser.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop'
              };
            }
            setAllUsers(uMap);
          }
        }
      } catch (err) {

      }
    };

    fetchAllUsersList();
    const interval = setInterval(fetchAllUsersList, 120000); // Poll user lists every 120 seconds
    return () => clearInterval(interval);
  }, [currentUserId, accessToken]);

  // Synchronize Active Device Session in Firestore & listen for forced logout
  useEffect(() => {
    if (!currentUserId || !accessToken) return;

    const checkSessionRevoked = async () => {
      const activeSessionId = TokenVault.getSessionId();
      if (!activeSessionId) return; // Wait until a valid session is configured

      try {
        const res = await fetch(`/api/auth/sessions/check?sessionId=${encodeURIComponent(activeSessionId)}`, {
          headers: { 'Authorization': `Bearer ${accessToken}` }
        });
        if (res.ok) {
          const data = await res.json();
          if (data.revoked === true) {
            localStorage.removeItem('dirasha_user');
            TokenVault.clearVault();
            setCurrentUser(null);
            setAccessToken(null);
            alert('SECURITY: Session terminated remotely.');
          }
        }
      } catch (err) {

      }
    };

    // Poll active sessions checklist
    const interval = setInterval(checkSessionRevoked, 120000); // Poll session status every 120 seconds
    return () => clearInterval(interval);
  }, [currentUserId, accessToken]);

  // Track new message arrivals across all chat threads to play notification pop sound & show browser alerts
  const lastMidsRef = useRef<Record<string, string>>({});
  const initialLoadRef = useRef(true);

  useEffect(() => {
    if (!currentUserId || rawChats.length === 0) {
      if (rawChats.length === 0 && !currentUserId) {
        lastMidsRef.current = {};
        initialLoadRef.current = true;
      }
      return;
    }

    let hasNewArrival = false;
    let newMsgData: { senderName: string; content: string; avatarUrl: string; chatId: string; metadata?: any } | null = null;

    rawChats.forEach(chat => {
      const lastMsg = chat.lastMessage;
      if (lastMsg && lastMsg.senderId !== currentUserId) {
        const key = lastMsg.createdAt + '_' + lastMsg.senderId;
        const prevKey = lastMidsRef.current[chat.id];
        
        if (prevKey && prevKey !== key) {
          const isActiveAndFocused = chat.id === activeChatIdRef.current && typeof document !== 'undefined' && document.hasFocus();
          if (!isActiveAndFocused && (chat.type !== 'group' || currentUser?.notificationSettings?.groupMessagesEnabled !== false)) {
            hasNewArrival = true;
            const sender = allUsers[lastMsg.senderId];
            newMsgData = {
              senderName: sender?.displayName || lastMsg.senderName || 'Member',
              content: lastMsg.content,
              avatarUrl: sender?.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop',
              chatId: chat.id,
              metadata: (lastMsg as any).metadata,
            };
          }
        }
        lastMidsRef.current[chat.id] = key;
      }
    });

    if (initialLoadRef.current) {
      initialLoadRef.current = false;
      rawChats.forEach(chat => {
        const lastMsg = chat.lastMessage;
        if (lastMsg && lastMsg.senderId !== currentUserId) {
          lastMidsRef.current[chat.id] = lastMsg.createdAt + '_' + lastMsg.senderId;
        }
      });
      return;
    }

    if (hasNewArrival && newMsgData) {
      // Notification pipeline: per-chat mute → quiet hours → toggles → sound + vibration + preview
      const chatMutes: Record<string, number> = (currentUser as any)?.chatMutes || {};
      const muteVal = chatMutes[newMsgData.chatId];
      const isChatMuted = muteVal === -1 || (typeof muteVal === 'number' && muteVal > Date.now());
      const notifOn = currentUser?.notificationSettings?.enabled !== false;
      const quiet = isWithinQuietHours((currentUser as any)?.notificationSettings?.quietHours);
      const mentionedMe = Array.isArray((newMsgData as any).metadata?.mentions) &&
        (newMsgData as any).metadata.mentions.includes(currentUserId);
      const hitKeyword = (((currentUser as any)?.notificationSettings?.highlightWords as string[]) || [])
        .some(w => w && String(newMsgData.content || '').toLowerCase().includes(String(w).toLowerCase()));
      if ((!isChatMuted && notifOn && !quiet) || (mentionedMe && notifOn) || (hitKeyword && notifOn)) {
        const ovr2 = ((currentUser as any)?.chatNotifOverrides || {})[newMsgData.chatId] || {};
        const soundEnabledOvr = ovr2.soundUrl ? true : currentUser?.notificationSettings?.soundEnabled !== false;
        if (soundEnabledOvr) {
          try {
            const audio = new Audio(ovr2.soundUrl || currentUser?.notificationSettings?.soundUrl || 'https://assets.mixkit.co/active_storage/sfx/2869/2869-120.wav');
            audio.volume = ((currentUser?.notificationSettings?.soundVolume ?? 80) / 100);
            audio.play().catch(() => {});
          } catch (_) {}
        }
        const vibrateOvr2 = ovr2.vibrate || 'default';
        if ((vibrateOvr2 !== 'off') && (currentUser?.notificationSettings?.vibration !== false) && (navigator as any).vibrate) {
          try { (navigator as any).vibrate(vibrateOvr2 === 'on' ? [80, 40, 80] : 120); } catch (_) {}
        }
      }

      // In-app popup toast (Telegram popups parity) — separate toggle from sound.
      // Project 7: content preview requires the privacy opt-in
      // privacySettings.notificationPreviewEnabled (default FALSE → generic).
      if (newMsgData && currentUser?.notificationSettings?.inAppToasts !== false && !isChatMuted) {
        const previewAllowed = currentUser?.privacySettings?.notificationPreviewEnabled === true &&
                               currentUser?.notificationSettings?.previewEnabled !== false;
        const preview = previewAllowed
          ? `${newMsgData.senderName}: ${String(newMsgData.content || '').slice(0, 60)}`
          : `رسالة جديدة من ${newMsgData.senderName}`;
        if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
          (window as any).showGlobalToast(preview, 'info');
        }
      }

      // Local (foreground) desktop notification — constructed client-side only,
      // never via the server push. Content preview still gated by the privacy
      // opt-in (default FALSE → generic 'رسالة جديدة').
      const desktopEnabled = !isChatMuted && notifOn &&
                             currentUser?.notificationSettings?.desktopNotifications === true;
      const previewOn = currentUser?.privacySettings?.notificationPreviewEnabled === true &&
                        currentUser?.notificationSettings?.previewEnabled !== false;
      if (desktopEnabled && typeof window !== 'undefined' && 'Notification' in window) {
        if (Notification.permission === 'granted') {
          new Notification(newMsgData.senderName, {
            body: previewOn ? newMsgData.content : 'رسالة جديدة',
            icon: newMsgData.avatarUrl
          });
        } else if (Notification.permission !== 'denied') {
          Notification.requestPermission().then(permission => {
            if (permission === 'granted' && newMsgData) {
              new Notification(newMsgData.senderName, {
                body: previewOn ? newMsgData.content : 'رسالة جديدة',
                icon: newMsgData.avatarUrl
              });
            }
          });
        }
      }
    }
  }, [rawChats, currentUserId, currentUser?.notificationSettings, currentUser?.chatMutes, allUsers]);

  // 3. Connect real-time list of conversational chat threads via React Query (Cache-First + SWR)
  const { data: chatsData } = useQuery({
    queryKey: ['chats', currentUserId],
    queryFn: async () => {
      const res = await fetch('/api/chats', {
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
      if (!res.ok) throw new Error('Failed to fetch chats');
      const data = await res.json();
      return data.chats || [];
    },
    enabled: !!accessToken && !!currentUserId,
    initialData: () => {
      try {
        const cached = localStorage.getItem(`chats_list_${currentUserId}`);
        return cached ? JSON.parse(cached) : undefined;
      } catch (_) {
        return undefined;
      }
    },
    staleTime: 1000 * 30, // 30 seconds stale time
  });

  // Sync React Query updates to rawChats local state for real-time websocket merges
  useEffect(() => {
    if (chatsData) {
      setRawChats(chatsData);
      localStorage.setItem(`chats_list_${currentUserId}`, JSON.stringify(chatsData));
      // Save asynchronously to high performance IndexedDB store
      ChatsCacheDB.put(currentUserId, chatsData).catch((err) => {
        console.warn('[ChatsCacheDB] Save failed:', err);
      });
    }
  }, [chatsData, currentUserId]);

  // P0-A (external-audit E2EE-01/02): membership-version reconciliation — when
  // the chats list hydrates, any E2EE group whose server membership_version is
  // NEWER than our locally remembered one means we missed a rotation event
  // while offline: rotate + re-distribute + remember. First sight of a group
  // just remembers the version (no rotation).
  useEffect(() => {
    if (!chatsData || !groupCryptoRef.current) return;
    (async () => {
      for (const chat of (chatsData as any[])) {
        if (!isE2eeGroupChat(chat)) continue;
        const serverMv = Number((chat as any)?.membershipVersion);
        if (!Number.isFinite(serverMv) || serverMv < 1) continue;
        const gc = groupCryptoRef.current;
        if (!gc) continue;
        const localMv = await gc.getMembershipVersion(chat.id);
        if (localMv !== null && serverMv > localMv) {
          rotateGroupForMembership(chat.id, serverMv);
        } else if (localMv === null) {
          await gc.setMembershipVersion(chat.id, serverMv);
        }
      }
    })();
  }, [chatsData]);

  // High performance async hydration from ChatsCacheDB at boot time
  useEffect(() => {
    if (currentUserId) {
      ChatsCacheDB.get(currentUserId).then((cached) => {
        if (cached && Array.isArray(cached) && cached.length > 0) {
          setRawChats((prev) => (prev.length === 0 ? cached : prev));
          queryClient.setQueryData(['chats', currentUserId], cached);
        }
      }).catch((err) => {
        console.warn('[ChatsCacheDB] Async hydration failed:', err);
      });
    }
  }, [currentUserId, queryClient]);

  // Prefetch chats query instantly upon successful login
  useEffect(() => {
    if (accessToken && currentUserId) {
      queryClient.prefetchQuery({
        queryKey: ['chats', currentUserId],
        queryFn: async () => {
          const res = await fetch('/api/chats', {
            headers: { 'Authorization': `Bearer ${accessToken}` }
          });
          if (!res.ok) throw new Error('Failed to fetch chats');
          const data = await res.json();
          return data.chats || [];
        }
      });
    }
  }, [accessToken, currentUserId, queryClient]);

  // 3b. Unified Client-Side State Computing layer (Single Source of Truth)
  const chats = React.useMemo(() => {
    if (!currentUserId) return [];
    const mapped = rawChats.map(d => {
      const otherUserId = d.memberIds?.find((id: string) => id !== currentUserId) || d.members?.find((m: any) => m.id !== currentUserId)?.id;
      const otherUser = otherUserId ? allUsers[otherUserId] : null;
      const otherUserFallback = d.otherMember || d.members?.find((m: any) => m.id !== currentUserId);

      // Extract writing/playing statuses
      const typingMap = d.typing || {};
      const activeTypersForChat = Object.entries(typingMap)
        .filter(([uid, displayName]) => displayName && uid !== currentUserId)
        .map(([_, displayName]) => displayName as string);

      const recordingMap = d.recording || {};
      const activeRecordersForChat = Object.entries(recordingMap)
        .filter(([uid, displayName]) => displayName && uid !== currentUserId)
        .map(([_, displayName]) => displayName as string);

      // RESOLVE LATEST DATA: Use allUsers (real-time presence map) as the source of truth for display details
      const finalName = d.type === 'one-to-one'
        ? (otherUser?.displayName || otherUserFallback?.displayName || d.name || 'Dirasha User')
        : (d.name || 'Secure Group');

      const finalAvatar = d.type === 'one-to-one'
        ? (otherUser?.avatarUrl || otherUserFallback?.avatarUrl || d.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop')
        : (d.avatarUrl || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&h=150&q=80');

      return {
        id: d.id,
        ...d,
        avatarUrl: finalAvatar,
        name: finalName,
        otherMember: (d.type === 'one-to-one' && otherUser) ? {
          id: otherUser.id,
          username: otherUser.username || '',
          displayName: otherUser.displayName || '',
          avatarUrl: otherUser.avatarUrl || '',
          verified: !!otherUser.verified,
          onlineStatus: otherUser.onlineStatus,
          lastSeen: otherUser.lastSeen,
          bannerUrl: otherUser.bannerUrl,
          backgroundBannerUrl: otherUser.backgroundBannerUrl,
          bannerShadowOpacity: otherUser.bannerShadowOpacity,
          bgBannerShadowOpacity: otherUser.bgBannerShadowOpacity
        } : (d.type === 'one-to-one' ? otherUserFallback : undefined),
        activeTypers: activeTypersForChat,
        activeRecorders: activeRecordersForChat,
        unreadCount: d.unreadCount || 0
      };
    });

    let filtered = mapped.filter((c: any) => {
      if (c.members?.some((m: any) => m.id === 'user-bot-dirasha' || m.id === 'user-bot-gemini' || m.username === 'dirasha_system' || m.username === 'nexora') || c.id.includes('bot-dirasha') || c.id.includes('bot-gemini') || c.otherMember?.id === 'user-bot-dirasha' || c.otherMember?.id === 'user-bot-gemini') return false;
      // Always show group chats
      if (c.type === 'group' || c.type === 'channel') return true;
      // Show if it has at least one message
      if (c.lastMessage) return true;
      // Show if it is the currently active chat for the user
      if (c.id === activeChatId) return true;
      // Hide empty one-on-one chats
      return false;
    });

    return filtered.sort((a, b) => {
      const timeA = a.lastMessage ? new Date(a.lastMessage.createdAt).getTime() : new Date(a.updatedAt || 0).getTime();
      const timeB = b.lastMessage ? new Date(b.lastMessage.createdAt).getTime() : new Date(b.updatedAt || 0).getTime();
      return timeB - timeA;
    });
  }, [rawChats, allUsers, currentUserId, activeChatId]);

  // ── PWA unread badge ──────────────────────────────────────────────────────
  // Mirror the total unread count across all chats onto the app icon
  // (Chrome/Edge desktop + Android via navigator.setAppBadge). Feature-detected;
  // unsupported browsers and rejected promises are silently ignored. The
  // service-worker notification badge flow is left untouched.
  const totalUnreadChats = React.useMemo(
    () => chats.reduce((sum: number, c: any) => sum + (c.unreadCount || 0), 0),
    [chats]
  );
  useEffect(() => {
    if (typeof navigator === 'undefined' || !('setAppBadge' in navigator)) return;
    const nav = navigator as Navigator & {
      setAppBadge?: (counter?: number) => Promise<void>;
      clearAppBadge?: () => Promise<void>;
    };
    try {
      if (totalUnreadChats > 0) {
        nav.setAppBadge?.(totalUnreadChats)?.catch(() => {});
      } else {
        nav.clearAppBadge?.()?.catch(() => {});
      }
    } catch (_) { /* badge APIs are best-effort */ }
    return () => {
      try {
        nav.clearAppBadge?.()?.catch(() => {});
      } catch (_) {}
    };
  }, [totalUnreadChats]);

  // 4. Load messages with Instant Cache + Server Delta Sync strategy
  useEffect(() => {
    if (!activeChatId || !currentUserId || !accessToken) {
      setRawMessages([]);
      return;
    }

    // Instantly clear old messages from view while we fetch the cache to prevent stale screen flashes
    setRawMessages([]);
    let isSubscribed = true;

    const syncMessagesWithCache = async () => {
      setLoadingMessages(true);
      try {

        // 1. Fetch from local IndexedDB cache instantly
        let cached = await MessagesCacheDB.get(activeChatId);
        
        // Auto-heal corrupted caches (where we accidentally saved another chat's messages due to a previous bug)
        if (cached && cached.length > 0) {
          const validCached = cached.filter(m => m.chatId === activeChatId);
          if (validCached.length !== cached.length) {
            console.warn('[MessagesCache] Corrupted cache detected. Self-healing...');
            cached = validCached;
            // Only keep if there are still messages, otherwise fallback to full fetch
          }
        }
        
        if (cached && cached.length > 0 && isSubscribed) {

          // E2EE: decrypt any DIR1 contents from the cache before they hit the UI.
          const decCached = await decryptHistoryMessages(activeChatId, cached);
          if (!isSubscribed) return;

          setRawMessages(decCached);
          setHasMoreMessages(false);
          
          // 2. Perform aggressive Delta/Recovery synchronization
          // We always fetch the latest 100 messages by default to heal ANY gaps that occurred while offline
          // This avoids the fatal flaw of using `afterTimestamp` which permanently bakes Race Condition gaps into the CacheDB.
          const response = await fetch(`/api/chats/${activeChatId}/messages?limit=100`, {
            headers: {
              'Authorization': `Bearer ${accessToken}`,
              'Content-Type': 'application/json'
            }
          });
          
          if (response.ok && isSubscribed) {
            const data = await response.json();
            // E2EE: decrypt server batch before merge (plaintext is cached).
            const serverLatest = await decryptHistoryMessages(activeChatId, data.messages || []);
            if (!isSubscribed) return;

            if (serverLatest.length > 0) {
              setRawMessages((prev) => {
                // Check if the server's oldest fetched message exists in our cache.
                // If it DOES NOT exist, and we fetched exactly 100 (meaning there might be more),
                // we have a GAP that is larger than 100 messages.
                // In this case, we DISCARD the old cache to prevent a visual "teleportation gap" and let the user scroll up normally.
                
                const oldestServerMsg = serverLatest[serverLatest.length - 1]; // Because server returns descending, last is oldest. Wait, actually server database returns ascending or descending?
                // The server `getMessagesForChat` does `return enriched.reverse()`, so it returns ASCENDING (oldest first).
                const oldestServerMsgAsc = serverLatest[0];
                const hasOverlap = prev.some(m => m.id === oldestServerMsgAsc.id) || prev.length === 0;
                
                let merged: any[];
                if (!hasOverlap && serverLatest.length === 100) {
                   console.log('[MessagesCache] Large gap detected (>100 messages). Discarding stale cache to preserve contiguous scroll history.');
                   merged = serverLatest.sort((a: any, b: any) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
                } else {
                   // Normal merge - deduplicate and sort
                   const filtered = prev.filter(m => !serverLatest.some((d: any) => d.id === m.id));
                   merged = [...filtered, ...serverLatest].sort(
                     (a: any, b: any) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
                   );
                }
                
                MessagesCacheDB.put(activeChatId, merged).catch(() => {});
                return merged;
              });
            }
          }
          return;
        }
        
        // 3. Fallback: If no cache, perform fresh fetch of last 100 messages

        const response = await fetch(`/api/chats/${activeChatId}/messages?limit=100`, {
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        });

        if (!response.ok) {
          throw new Error(`SQL REST endpoint returned ${response.status}`);
        }

        const data = await response.json();
        // E2EE: decrypt server batch before it reaches the UI / cache.
        const sqlMessages = await decryptHistoryMessages(activeChatId, data.messages || []);

        if (isSubscribed) {
          sqlMessages.sort((a: any, b: any) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
          setRawMessages(sqlMessages);
          setHasMoreMessages(sqlMessages.length >= 100);
          // Persist to local cache for subsequent mounts
          MessagesCacheDB.put(activeChatId, sqlMessages).catch(() => {});
        }
      } catch (err) {
        console.error('[syncMessagesWithCache] error:', err);
      } finally {
        if (isSubscribed) {
          setLoadingMessages(false);
        }
      }
    };

    syncMessagesWithCache();

    return () => {
      isSubscribed = false;
    };
  }, [activeChatId, currentUserId, accessToken]);

  // Instantly zero out the active chat's unreadCount when clicked/active
  useEffect(() => {
    if (activeChatId) {
      setRawChats((prev) => {
        return prev.map((chat) => {
          if (chat.id === activeChatId) {
            // Optimistically clear unread count and set last message state to read if it's from others
            const updatedLastMsg = chat.lastMessage && chat.lastMessage.senderId !== currentUserId
              ? { ...chat.lastMessage, state: 'read' }
              : chat.lastMessage;
              
            return { 
              ...chat, 
              unreadCount: 0,
              lastMessage: updatedLastMsg
            };
          }
          return chat;
        });
      });

      // Also update rawMessages to show blue ticks immediately for current user's perspective
      setRawMessages(prev => prev.map(m => {
        if (m.chatId === activeChatId && m.senderId !== currentUserId && m.state !== 'read') {
          return { ...m, state: 'read' };
        }
        return m;
      }));
    }
  }, [activeChatId, currentUserId]);

  // Continuously persist the current active chat room message state to local IndexedDB
  useEffect(() => {
    if (activeChatId && rawMessages.length > 0) {
      // CRITICAL: Ensure the messages actually belong to the active chat before saving!
      // When switching chats, activeChatId updates before rawMessages are cleared/fetched,
      // which would cause us to save Chat A's messages into Chat B's cache.
      const isValidForChat = rawMessages.every(m => m.chatId === activeChatId);
      if (isValidForChat) {
        MessagesCacheDB.put(activeChatId, rawMessages).catch((err) => {
          console.error('[MessagesCache] Continuous update failure:', err);
        });
      }
    }
  }, [rawMessages, activeChatId]);

  // Synchronize dynamic gaps / delta sync when websocket reconnects
  const wasConnectedRef = useRef(false);
  useEffect(() => {
    if (websocketConnected) {
      if (!wasConnectedRef.current) {
        wasConnectedRef.current = true;
        
        // WebSocket transitioned from offline to online - Aggressively refresh state!
        if (currentUserId && accessToken) {
          console.log('[Connection Recovery] Network restored. Firing full state synchronization...');

          // 0. Outbox revival: messages marked FAILED during a connection-loss
          // window (5 retries all landing inside the dead-socket period) must
          // NOT stay dead once the connection recovers. Revive failed items
          // (bounded retries) so they re-enter the send loop automatically.
          try {
            const revived = outboxQueueRef.current.filter((it: any) => it.status === 'failed' && (outboxMetaRef.current[it.id]?.retryCount || 0) < 20);
            if (revived.length > 0) {
              revived.forEach((it: any) => { it.status = 'pending'; });
              outboxMetaRef.current = Object.fromEntries(Object.entries(outboxMetaRef.current).map(([k, v]: any) => [k, { ...v, retryCount: Math.min(v.retryCount || 0, 8), nextRetryTime: 0 }]));
              const next = [...outboxQueueRef.current];
              outboxQueueRef.current = next;
              setOutboxQueue(next);
              next.forEach((it: any) => { if (it.status === 'pending') OutboxDB.put(it).catch(() => {}); });
              console.log(`[Outbox] Revived ${revived.length} failed message(s) after reconnection`);
            }
          } catch { /* revival is best-effort */ }

          // 1. Recover thread list
          queryClient.invalidateQueries({ queryKey: ['chats', currentUserId] });
          fetch('/api/chats', {
            headers: { 'Authorization': `Bearer ${accessToken}` }
          })
          .then(res => res.json())
          .then(data => {
            if (data.chats && Array.isArray(data.chats)) {
              setRawChats(data.chats);
              localStorage.setItem(`chats_list_${currentUserId}`, JSON.stringify(data.chats));
              console.log('[Delta Sync] Chats thread list refreshed successfully.');
            }
          })
          .catch(err => {
            if (err?.message !== 'Failed to fetch' && !err?.message?.includes('Failed to fetch')) {
              console.warn('[Delta Sync] Failed to refresh chats thread list on reconnection:', err);
            }
          });

          // 2. Recover active chat messages specifically to heal the "WebSocket Race Condition"
          // We always fetch the latest 100 messages without constraints on reconnect to guarantee no gaps.
          if (activeChatId) {
             const recoveryChatId = activeChatId;
             fetch(`/api/chats/${recoveryChatId}/messages?limit=100`, {
               headers: { 'Authorization': `Bearer ${accessToken}`, 'Content-Type': 'application/json' }
             })
             .then(res => res.json())
             .then(async (data: any) => {
                // Safeguard against Chat Switching while fetch was pending
                if (activeChatIdRef.current !== recoveryChatId) {
                   console.log('[Sync] Discarding stale active chat reconnect sync.');
                   return;
                }
                // E2EE: decrypt server batch before merge.
                const serverLatest = await decryptHistoryMessages(recoveryChatId, data.messages || []);
                if (activeChatIdRef.current !== recoveryChatId) return;
                if (serverLatest.length > 0) {
                   setRawMessages((prev) => {
                     const oldestServerMsgAsc = serverLatest[0];
                     const hasOverlap = prev.some(m => m.id === oldestServerMsgAsc.id) || prev.length === 0;
                     let merged: any[];
                     
                     if (!hasOverlap && serverLatest.length === 100) {
                        console.log('[Sync] Gap detected upon reconnect. Syncing timeline.');
                        merged = serverLatest.sort((a: any, b: any) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
                     } else {
                        const filtered = prev.filter(m => !serverLatest.some((d: any) => d.id === m.id));
                        merged = [...filtered, ...serverLatest].sort((a: any, b: any) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
                        if (merged.length > prev.length) {
                           console.log(`[Sync] Merged ${merged.length - prev.length} messages after reconnection.`);
                        }
                     }
                     MessagesCacheDB.put(recoveryChatId, merged).catch(()=>{});
                     return merged;
                   });
                }
             })
             .catch(()=>{});
          }
        }
      }
    } else {
      wasConnectedRef.current = false;
    }
  }, [websocketConnected, accessToken, currentUserId, queryClient, activeChatId]);

  // Outbox Retry Processor & Exponential Backoff Engine (1s, 2s, 4s, 8s, 16s)
  useEffect(() => {
    if (!accessToken || !currentUserId) return;

    // Direct live socket status resolver to evade stale closures
    const isSocketConnected = () => {
      return websocketConnected || (socketClientRef.current && socketClientRef.current.isConnected());
    };

    // Trigger immediate retry of all elements upon coming back online
    if (isSocketConnected()) {
      // console.log('[Outbox] WebSocket connected. Resetting outbox metadata for pending items.');
      const currentQueue = outboxQueueRef.current;
      currentQueue.forEach((item) => {
        if (item.status !== 'failed') {
          const meta = outboxMetaRef.current[item.id] || { retryCount: 0, nextRetryTime: 0 };
          outboxMetaRef.current[item.id] = { ...meta, nextRetryTime: 0 };
          delete sentTimestampsRef.current[item.id];
        }
      });
    }

    const timer = setInterval(async () => {
      const currentQueue = outboxQueueRef.current;
      if (currentQueue.length === 0) return;

      const now = Date.now();
      let outboxChanged = false;
      const updatedQueue = [...currentQueue];
      const online = isSocketConnected();

      for (let i = 0; i < updatedQueue.length; i++) {
        const item = updatedQueue[i];
        if (item.senderId && currentUserId && item.senderId !== currentUserId) continue;

        // Get or initialize meta
        const meta = outboxMetaRef.current[item.id] || { retryCount: 0, nextRetryTime: 0 };
        outboxMetaRef.current[item.id] = meta;

        // If marked failed, skip automatic processing (requires manual tap to retry)
        if (item.status === 'failed') continue;

        // Check if waiting for ACK
        const sentTime = sentTimestampsRef.current[item.id];
        if (sentTime !== undefined) {
          const elapsed = now - sentTime;
          if (elapsed >= 10000) { // 10 seconds ACK Timeout!
            console.warn(`[Outbox] ACK timeout for item: ${item.id}. Retries so far: ${meta.retryCount}`);
            delete sentTimestampsRef.current[item.id];
            
            const nextCount = meta.retryCount + 1;
            if (nextCount >= 5) {
              console.error(`[Outbox] Message marked as FAILED after 5 retries: ${item.id}`);
              item.status = 'failed';
              outboxChanged = true;
              
              // Persist failed status to database
              await OutboxDB.put(item);

              // Also update in rawMessages if it exists there
              setRawMessages((prev) =>
                prev.map((m) => (m.id === item.id ? { ...m, state: 'failed' } : m))
              );
            } else {
              // Exponential delay: 1s, 2s, 4s, 8s, 16s
              const delay = Math.pow(2, nextCount) * 1000;
              meta.retryCount = nextCount;
              meta.nextRetryTime = now + delay;
            }
          }
        } else {
          // Message not currently waiting for ACK. Handle transmission/retry timing.
          if (online && now >= meta.nextRetryTime) {
            // console.log(`[Outbox] Emitting MSG:SEND for item: ${item.id}`);
            sentTimestampsRef.current[item.id] = now;

            // Notify UI that it is transmitting
            setRawMessages((prev) =>
              prev.map((m) => (m.id === item.id ? { ...m, state: 'sending' } : m))
            );

            setRawChats((prev) => {
              return prev.map((chat) => {
                if (chat.id === item.chatId) {
                  return {
                    ...chat,
                    lastMessage: {
                      ...chat.lastMessage,
                      id: item.id,
                      content: item.content,
                      createdAt: item.createdAt,
                      senderId: currentUserId,
                      state: 'sending'
                    }
                  };
                }
                return chat;
              });
            });

            if (socketClientRef.current) {
              const timings = (item as any).traceTimings || {
                clientCreated: Date.now(),
                clientWSSent: Date.now(),
                serverReceived: 0,
                dbInsertStart: 0,
                dbInsertEnd: 0,
                redisPubStart: 0,
                redisPubEnd: 0,
                targetWSReceived: 0,
                targetUIRendered: 0
              };
              timings.clientWSSent = Date.now();

              socketClientRef.current.emit('msg:send', {
                tempMessageId: item.id,
                chatId: item.chatId,
                content: item.content,
                type: item.type,
                attachments: item.attachments,
                replyTo: item.replyTo,
                mv: (rawChatsRef.current || []).find((c: any) => c?.id === item.chatId)?.membershipVersion,
                traceTimings: timings
              });
            } else {
               console.warn('[Outbox] socketClientRef.current is missing!');
            }
          }
        }
      }

      if (outboxChanged) {
        setRawChats((prev) => [...prev]); // trigger state update dependency sync
        setOutboxQueue(updatedQueue);
        outboxQueueRef.current = updatedQueue;
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [websocketConnected, accessToken, currentUserId]);

  const handleRetryMessage = async (messageId: string) => {

    
    // Find item
    const item = outboxQueue.find((i) => i.id === messageId);
    if (!item) return;

    // Reset its retry count & metadata
    outboxMetaRef.current[messageId] = { retryCount: 0, nextRetryTime: 0 };
    delete sentTimestampsRef.current[messageId];

    // Update state to pending to retry immediately
    setRawMessages((prev) =>
      prev.map((m) => (m.id === messageId ? { ...m, state: 'pending' } : m))
    );

    // Update item status in IndexedDB
    const updatedItem = { ...item, retryCount: 0, status: 'pending' };
    await OutboxDB.put(updatedItem);
    
    // Refresh queue state
    const currentItems = await OutboxDB.getAll();
    setOutboxQueue(currentItems);
  };

  // 4b. Map raw messages to renderable client messages and append local offline outbox items
  const messages = React.useMemo(() => {
    const nowTime = new Date();
    const dbMessages = rawMessages
      .filter(m => !m.expiresAt || new Date(m.expiresAt) > nowTime)
      .map(d => {
      const sender = allUsers[d.senderId];
      const sState = d.state || 'sent';
      return {
        id: d.id,
        ...d,
        sender: sender ? {
          id: sender.id,
          username: sender.username || '',
          displayName: sender.displayName || '',
          avatarUrl: sender.avatarUrl || '',
          verified: !!sender.verified
        } : {
          id: d.senderId,
          username: 'unknown',
          displayName: d.senderName || 'Anonymous User',
          avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop'
        },
        state: sState === 'pending' || sState === 'sending' ? 'pending' : sState
      };
    });

    const activeChatOutbox = outboxQueue
      .filter((item) => item.chatId === activeChatId && !dbMessages.some((m) => m.id === item.id))
      .map((item) => {
        return {
          id: item.id,
          chatId: item.chatId,
          senderId: item.senderId,
          content: item.content,
          type: item.type,
          attachments: item.attachments,
          createdAt: item.createdAt,
          replyTo: item.replyTo,
          state: (item.status === 'failed' ? 'failed' : 'pending') as 'failed' | 'pending',
          sender: {
            id: item.senderId,
            username: currentUser?.username || '',
            displayName: currentUser?.displayName || 'Me',
            avatarUrl: currentUser?.avatarUrl || '',
            verified: !!currentUser?.verified
          }
        };
      });

    return [...dbMessages, ...activeChatOutbox].sort(
      (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
    );
  }, [rawMessages, outboxQueue, activeChatId, allUsers, currentUser, expiryTick]);

  const handleChatSelect = (chatId: string) => {
    setActiveChatId(chatId);
    setRawMessages([]); // Transition loaders
  };

  const handleSelectUserDirect = async (targetUserId: string) => {
    if (!currentUser) return;
    const myId = currentUser.uid || currentUser.id;
    if (myId === targetUserId) return; // Can't chat with self

    const sortedIds = [myId, targetUserId].sort();
    const chatId = `one_to_one_${sortedIds[0]}___${sortedIds[1]}`;

    // Check if a direct one-to-one chat already exists
    const existing = chats.find(c => c.id === chatId);
    
    if (existing) {
      handleChatSelect(chatId);
      return;
    }

    try {
      // Create or update deterministic chat document via REST API
      const response = await fetch('/api/chats', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          type: 'one-to-one',
          memberIds: [myId, targetUserId]
        })
      });

      if (response.ok) {
        const data = await response.json();
        const serverChatId = data.chat?.id || data.id;
        
        if (serverChatId) {
          handleChatSelect(serverChatId);
        } else {
          handleChatSelect(chatId);
        }
        
        // Refresh local chat lists immediately
        const listRes = await fetch('/api/chats', {
          headers: { 'Authorization': `Bearer ${accessToken}` }
        });
        if (listRes.ok) {
          const listData = await listRes.json();
          setRawChats(listData.chats || []);
        }
      }
    } catch (err) {
      console.error('[SelectUserDirect] Failed creating chat via REST API:', err);
    }
  };

  const loadOlderMessages = async (oldestCreatedAt: string) => {
    if (!activeChatId || !hasMoreMessages) return;
    try {
      const response = await fetch(`/api/chats/${activeChatId}/messages?before=${encodeURIComponent(oldestCreatedAt)}&limit=100`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });
      if (response.ok) {
        const data = await response.json();
        // E2EE: decrypt the older batch before merging into the timeline.
        const olderMessages = await decryptHistoryMessages(activeChatId, data.messages || []);
        if (olderMessages.length > 0) {
          setRawMessages(prev => {
            const filtered = prev.filter(m => !olderMessages.some((om: any) => om.id === m.id));
            const merged = [...olderMessages, ...filtered].sort((a,b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
            MessagesCacheDB.put(activeChatId, merged).catch(() => {});
            return merged;
          });
        }
        setHasMoreMessages(olderMessages.length >= 100);
      }
    } catch (err) {
      console.error('[loadOlderMessages] error:', err);
    }
  };

  const handleSendMessage = async (content: string, attachments: any[] = [], replyTo: any = null, attachmentFiles: any[] = []) => {
    if (!activeChatId || !currentUser) return;
    // P0-A (external-audit E2EE-01/02): block group sends while a membership
    // rotation is in flight so no message leaves under a stale epoch.
    const sendTimeChat = (rawChatsRef.current || []).find((c: any) => c?.id === activeChatId);
    if (sendTimeChat && isE2eeGroupChat(sendTimeChat) && rekeyPendingRef.current.has(activeChatId)) {
      showToast('جارٍ تدوير مفاتيح المجموعة — أعد الإرسال بعد لحظات', 'info');
      return;
    }
    const myId = currentUser.uid || currentUser.id;
    const nowIso = new Date().toISOString();
    
    // Calculate Self-Destruct / Disappearing Messages expiry if setting is active
    let expiresAt: string | null = null;
    const disappearSetting = currentUser.privacySettings?.disappearingMessagesDefault || 'off';
    
    if (disappearSetting !== 'off') {
      const now = new Date();
      if (disappearSetting === '30s') now.setSeconds(now.getSeconds() + 30);
      else if (disappearSetting === '5m') now.setMinutes(now.getMinutes() + 5);
      else if (disappearSetting === '1h') now.setHours(now.getHours() + 1);
      else if (disappearSetting === '1d') now.setDate(now.getDate() + 1);
      else if (disappearSetting === '1w') now.setDate(now.getDate() + 7);
      expiresAt = now.toISOString();
    }

    // ── E2EE send wrap (Agent I + media E2EE) ─────────────────────────────────
    // Eligible 1:1 DMs encrypt TEXT + ATTACHMENTS to 'DIR1:...' for the wire.
    // Attachments: each file's bytes are encrypted client-side
    // (encryptAttachment) and ONLY the encrypted blob is uploaded
    // (application/octet-stream 'enc.bin'); the decryption payload rides
    // INSIDE the encrypted text envelope (buildEncryptedPayload). The local
    // optimistic copy keeps the PLAINTEXT text and the ORIGINAL attachments;
    // the outbox and the WS payload carry the ENCRYPTED content + wire
    // attachments (retries re-send the exact same ciphertext envelope).
    const e2eePeer = e2eePeerForChat(activeChatId);
    let wireContent = content || '';
    let isE2ee = false;

    const wireAttachmentsInitial = attachments || [];
    let wireAttachments = wireAttachmentsInitial;
    const filesPayloads: any[] = [];
    const hasAttachments = wireAttachmentsInitial.length > 0;

    // Media E2EE (shared by the 1:1 and group send wraps): encrypt every real
    // attachment before anything goes out. Pseudo attachments (location /
    // contact / poll cards) carry no uploadable bytes and keep riding the wire
    // as-is. Encrypted blobs are uploaded as application/octet-stream
    // 'enc.bin'; the decryption payloads accumulate in filesPayloads and ride
    // INSIDE the encrypted text envelope.
    const encryptAttachmentsForWire = async (): Promise<void> => {
      if (!hasAttachments) return;
      const encAtts: any[] = [];
      for (let i = 0; i < wireAttachmentsInitial.length; i++) {
        const att: any = wireAttachmentsInitial[i];
        const attMime: string = typeof att?.mimeType === 'string' ? att.mimeType : '';
        const isPseudo = attMime.startsWith('application/x-dirasha-');
        if (isPseudo) {
          encAtts.push(att);
          continue;
        }
        // Encrypt-at-source skip-guard (F1/P0): the composer (ChatWindow) may
        // have ALREADY encrypted + uploaded this attachment as an opaque
        // 'enc.bin' blob (meta.e2ee === true). Those are authoritative — no
        // re-encryption, no re-upload, NO fetch of any bytes. The decryption
        // payload rides in-memory on meta.e2eePayload: push it into
        // filesPayloads (→ buildEncryptedPayload → inside the encrypted
        // envelope) and STRIP it from the wire copy, so key material is never
        // serialized to the server / DB / recipient attachment metadata.
        if (isAlreadyEncryptedAttachment(att)) {
          const payload = att?.meta?.e2eePayload;
          if (payload) filesPayloads.push(payload);
          const { e2eePayload: _stripPayload, ...cleanMeta } = att.meta || {};
          encAtts.push({ ...att, meta: cleanMeta });
          continue;
        }
        // Bytes source: the composer passes raw File/Blob objects aligned
        // by index; when a raw file is missing (sticker / forward), fetch
        // the already-uploaded bytes back and encrypt those.
        let bytes: Uint8Array | null = null;
        let mime = attMime;
        let name: string = typeof att?.name === 'string' ? att.name : '';
        const raw = attachmentFiles?.[i];
        if (raw && typeof raw.arrayBuffer === 'function') {
          bytes = new Uint8Array(await raw.arrayBuffer());
          if (!mime) mime = raw.type || 'application/octet-stream';
          if (!name) name = raw.name || 'file';
        } else if (att?.url && typeof att.url === 'string') {
          try {
            // P1-H (AUTH-05): scoped short-lived media token — the long-lived
            // access JWT never rides media URLs. On token failure the URL is
            // left WITHOUT a token (honest 401); E2EE-capable chats then fail
            // closed below via E2EE_ATTACHMENT_BYTES_UNAVAILABLE.
            const isApiUrl = att.url.startsWith('/api');
            const mt = isApiUrl && accessToken ? await getAppScopedMediaToken(accessToken) : null;
            const src = isApiUrl && mt
              ? `${att.url}${att.url.includes('?') ? '&' : '?'}access_token=${mt}`
              : att.url;
            const res = await fetch(src);
            if (res.ok) {
              bytes = new Uint8Array(await res.arrayBuffer());
            }
          } catch { /* bytes stay null → E2EE chats fail closed below; non-E2EE keeps the original attachment */ }
          if (!mime) mime = 'application/octet-stream';
          if (!name) name = 'file';
        }
        if (!bytes || bytes.length === 0) {
          // P1-A (external-audit E2EE-04): FAIL-CLOSED — in an E2EE-capable
          // chat, a real attachment whose bytes cannot be fetched/encrypted
          // ABORTS the whole send (the old code pushed the ORIGINAL attachment:
          // the unencrypted URL rode the E2EE message). Already-encrypted
          // source attachments skip earlier via meta.e2eePayload.
          const sendChatP1A = (rawChatsRef.current || []).find((c: any) => c?.id === activeChatId);
          const e2eeCapableP1A = !!sendChatP1A && (isE2eeGroupChat(sendChatP1A) || !!e2eePeerForChat(activeChatId));
          if (e2eeCapableP1A) {
            throw new Error('E2EE_ATTACHMENT_BYTES_UNAVAILABLE');
          }
          encAtts.push(att);
          continue;
        }
        const enc = encryptAttachment(bytes, mime || 'application/octet-stream', name || 'file');
        const uploadedEnc = await uploadFileToDrive(
          new Blob([enc.blob as BlobPart], { type: 'application/octet-stream' }),
          'enc.bin'
        );
        encAtts.push({
          id: enc.payload.attId,
          url: uploadedEnc.url,
          mimeType: 'application/octet-stream',
          name: 'enc.bin',
          size: enc.blob.length,
          meta: { e2ee: true, attId: enc.payload.attId },
        });
        filesPayloads.push(enc.payload);
      }
      wireAttachments = encAtts;
    };

    // ── GROUP E2EE send wrap (Sender Keys) ───────────────────────────────────
    // Eligible REGULAR groups encrypt to 'DIRG1:...'. Media E2EE: attachments
    // are encrypted exactly like the 1:1 path and their decryption payloads
    // ride INSIDE the envelope via the SAME 'dirasha-msg-v1' container
    // (media.ts buildEncryptedPayload) — encryptGroupMessage treats the string
    // opaquely, so no group.ts change is needed. Runs BEFORE the 1:1 branch —
    // the two paths are exclusive (group vs one-to-one chat types).
    // Distribution is awaited BEFORE encrypting so new members receive our
    // current sender key and can decrypt this very message. On crypto failure
    // we abort (never send plaintext silently), mirroring the 1:1 behavior.
    const activeGroupChat = (rawChatsRef.current || []).find((c: any) => c?.id === activeChatId);
    if (
      isE2eeGroupChat(activeGroupChat) &&
      ((typeof content === 'string' && content.trim().length > 0) || hasAttachments)
    ) {
      const gc = groupCryptoRef.current;
      if (!gc) {
        showToast('تعذر تشفير الرسالة', 'error');
        return;
      }
      try {
        await ensureGroupDistribution(activeGroupChat);
        await encryptAttachmentsForWire();
        const groupPayload =
          hasAttachments || filesPayloads.length > 0
            ? buildEncryptedPayload(content || '', filesPayloads)
            : content;
        wireContent = await gc.encryptGroupMessage(activeChatId, groupPayload, myId, Number(sendTimeChat?.membershipVersion) || 1);
        isE2ee = true;
      } catch {
        showToast('تعذر تشفير الرسالة', 'error');
        return;
      }
    }

    if (e2eePeer && (wireContent || hasAttachments)) {
      try {
        const engine = e2eeRef.current;
        if (!engine) throw new Error('E2EE engine unavailable');

        // Media E2EE: encrypt every real attachment before anything goes out
        // (shared helper declared above — identical flow for groups and DMs).
        await encryptAttachmentsForWire();

        // Text + attachment payloads travel together inside ONE envelope
        // (also covers attachments-only messages: text may be '').
        const payloadText = buildEncryptedPayload(content || '', filesPayloads);
        const encMsg = await engine.encryptMessage(e2eePeer, payloadText);
        wireContent = encMsg.content;
        isE2ee = true;
        // F8: encryption SUCCEEDED — the engine cleared the per-peer downgrade
        // memory; mirror it in the UI state immediately (badge disappears).
        setActiveChatDowngraded(false);
      } catch (err: any) {
        if (err?.name === 'PeerNotRegisteredError') {
          // E2EE-09 (external audit): FAIL-CLOSED. The peer has no E2EE bundle
          // → plaintext is NEVER sent silently. Default: abort the send with a
          // clear toast and keep the downgrade badge (F8: the engine persisted
          // the per-peer downgrade memory → the "غير مشفرة طرف-لطرف" badge
          // replaces the lock). The ONLY way plaintext leaves this client for
          // this chat is the EXPLICIT per-chat opt-in flag
          // 'e2eeAllowPlaintext:<chatId>' = '1', set ONLY after a
          // window.confirm disclosing the message will be sent UNENCRYPTED.
          // No per-message silent fallbacks.
          setActiveChatDowngraded(true);
          const allowPlaintextKey = `e2eeAllowPlaintext:${activeChatId}`;
          const plaintextAllowed = (() => {
            try { return localStorage.getItem(allowPlaintextKey) === '1'; } catch { return false; }
          })();
          if (!plaintextAllowed && !window.confirm(
            'تعذر تشفير الرسالة: الطرف الآخر غير مسجل للتشفير.\n\nهل تريد السماح بإرسال الرسائل في هذه المحادثة بدون تشفير (نص صريح غير محمي طرف-لطرف)؟',
          )) {
            // Declined → abort: the message is NOT sent, plaintext or else.
            pushSecurityEvent('downgrade', { stage: 'send-aborted', peerId: e2eePeer, chatId: activeChatId });
            showToast('الطرف الآخر غير مسجل للتشفير — الرسالة لم تُرسل', 'error');
            return;
          }
          if (!plaintextAllowed) {
            try { localStorage.setItem(allowPlaintextKey, '1'); } catch { /* storage unavailable → retry prompt next send */ }
          }
          // Explicit per-chat opt-in (pre-existing or just confirmed) → the
          // plaintext send proceeds below and the downgrade badge shows.
          // Monitoring: record the downgrade event on the confirm path too.
          pushSecurityEvent('downgrade', { stage: plaintextAllowed ? 'send-allowed' : 'send-confirmed', peerId: e2eePeer, chatId: activeChatId });
        } else {
          // Monitoring: a TamperedError here is a PQ downgrade attempt (F9:
          // 'pq downgraded — …') or another crypto tamper rejection — record
          // it content-free before the generic failure toast.
          if (err?.name === 'TamperedError') {
            pushSecurityEvent(
              /pq downgraded/i.test(String(err?.message || '')) ? 'pq-downgrade' : 'tamper-detected',
              { stage: 'send', peerId: e2eePeer },
            );
          }
          // Unexpected crypto/transport failure → abort, never fall back to
          // plaintext silently.
          showToast('تعذر تشفير الرسالة', 'error');
          return;
        }
      }
    }

    // Generate unique Client Message ID as UUID v4 client-side
    const clientMessageId = crypto.randomUUID();
    const clientCreated = Date.now();

    const isAttachment = attachments && attachments.length > 0;
    const messageObj: any = {
      id: clientMessageId,
      chatId: activeChatId,
      senderId: myId,
      senderName: currentUser.displayName || currentUser.username || 'User',
      // Optimistic UI shows the plaintext the user typed (e2ee flag marks it).
      content: content || '',
      e2ee: isE2ee,
      createdAt: nowIso,
      expiresAt: expiresAt,
      state: 'pending', // Starts in pending state instantly for true Optimistic UI
      type: isAttachment ? 'attachment' : 'text',
      attachments: attachments || [],
      // Media E2EE: the sender's optimistic copy keeps the ORIGINAL attachment
      // objects (rich previews from the composer uploads) plus the decryption
      // payloads — no self-decrypt needed on the sending side.
      ...(filesPayloads.length > 0 ? { e2eeFiles: filesPayloads } : {}),
      replyTo: replyTo || null,
      traceTimings: {
        clientCreated,
        clientWSSent: 0,
        serverReceived: 0,
        dbInsertStart: 0,
        dbInsertEnd: 0,
        redisPubStart: 0,
        redisPubEnd: 0,
        targetWSReceived: 0,
        targetUIRendered: 0
      }
    };

    // 1. Optimistic display update: add to rawMessages instantly
    setRawMessages((prev) => [...prev, messageObj]);

    // 2. Store in local Outbox queue to protect from connection failures
    // E2EE: the outbox carries the ENCRYPTED content so retries re-send the
    // exact same ciphertext envelope (never re-encrypt the plaintext).
    const outboxItem = {
      id: clientMessageId,
      chatId: activeChatId,
      senderId: myId,
      content: wireContent,
      e2ee: isE2ee,
      type: messageObj.type,
      // Media E2EE: the outbox carries the WIRE attachments (octet-stream
      // enc.bin) + the decryption payloads so retries re-send the exact same
      // envelope and the sender can still decrypt own media after recovery.
      attachments: wireAttachments,
      ...(filesPayloads.length > 0 ? { e2eeFiles: filesPayloads } : {}),
      createdAt: nowIso,
      replyTo: messageObj.replyTo,
      retryCount: 0,
      nextRetryTime: 0, // process immediately
      status: 'pending' as const,
      traceTimings: messageObj.traceTimings
    };

    setOutboxQueue((prev) => {
      const next = [...prev, outboxItem];
      outboxQueueRef.current = next;
      OutboxDB.put(outboxItem).catch((err) => console.error('[IndexedDB] put error:', err));
      return next;
    });

    // 3. Emit instantly over WebSocket if healthy to avoid interval/queue delays
    if (socketClientRef.current && websocketConnected) {
      const clientWSSent = Date.now();
      messageObj.traceTimings.clientWSSent = clientWSSent;

      sentTimestampsRef.current[clientMessageId] = Date.now();
      
      socketClientRef.current.emit('msg:send', {
        tempMessageId: clientMessageId,
        chatId: activeChatId,
        content: wireContent, // E2EE: encrypted wire content for eligible DMs
        type: messageObj.type,
        attachments: wireAttachments, // Media E2EE: octet-stream enc.bin wire objects
        replyTo: messageObj.replyTo,
        mv: (rawChatsRef.current || []).find((c: any) => c?.id === activeChatId)?.membershipVersion,
        expiresAt: messageObj.expiresAt,
        clientSendTimestamp: Date.now(),
        traceTimings: messageObj.traceTimings
      });
    }
  };

  // Mark latest messages as read via WebSocket (Grouped & batched with 500ms debounce)
  const readReceiptDebounceTimersRef = useRef<Record<string, any>>({});
  const lastEmtittedMessageIdByChatRef = useRef<Record<string, string>>({});

  const handleMarkRead = (lastMessageId?: string) => {
    if (!activeChatId || !currentUser || !lastMessageId) return;

    // Privacy Check: Only emit read receipts if settings allow it
    if (currentUser.privacySettings?.readReceiptsEnabled === false) return;

    if (lastEmtittedMessageIdByChatRef.current[activeChatId] === lastMessageId) {
      return; // Already sent or scheduled this exact receipt
    }
    lastEmtittedMessageIdByChatRef.current[activeChatId] = lastMessageId;

    // Clear unread count locally immediately for best UX sync
    setRawChats(prev => prev.map(chat => {
      if (chat.id === activeChatId && (chat.unreadCount || 0) > 0) {
        return { ...chat, unreadCount: 0 };
      }
      return chat;
    }));

    // Also update rawMessages to show blue checkmarks instantly for the read messages
    setRawMessages(prev => prev.map(m => {
      if (m.chatId === activeChatId && m.senderId !== currentUserId && (m.state !== 'read' && m.state !== 'deleted')) {
        return { ...m, state: 'read' };
      }
      return m;
    }));

    // Clear existing timer for this chat
    if (readReceiptDebounceTimersRef.current[activeChatId]) {
      clearTimeout(readReceiptDebounceTimersRef.current[activeChatId]);
    }

    // Schedule slightly faster read delivery in 150ms (responsive but prevents spam)
    readReceiptDebounceTimersRef.current[activeChatId] = setTimeout(() => {
      if (socketClientRef.current && websocketConnected) {
        socketClientRef.current.emit('msg:read', { chatId: activeChatId, lastMessageId });
      }
      delete readReceiptDebounceTimersRef.current[activeChatId];
    }, 150);
  };

  // Propagate user typing indicators inside parent chat room metadata via WebSocket
  const handleEmitTyping = async (isTyping: boolean) => {
    if (!activeChatId || !currentUser) return;

    // Privacy Check: Only emit typing if setting is enabled
    if (currentUser.privacySettings?.typingIndicatorEnabled === false) return;

    // WebSocket optimized ephemeral typing notification
    if (socketClientRef.current && websocketConnected) {
      socketClientRef.current.emitTyping(activeChatId, isTyping);
    }
  };

  const handleRecordingStatusChange = async (isRecording: boolean) => {
    if (!activeChatId || !currentUser) return;
    if (socketClientRef.current && websocketConnected) {
      socketClientRef.current.emit('presence:typing', { chatId: activeChatId, isTyping: isRecording, extra: 'recording' });
    }
  };

  const handleLogout = async () => {
    const storedToken = TokenVault.getAccessToken();
    const activeSessionId = TokenVault.getSessionId();
    if (storedToken && activeSessionId) {
      try {
        await fetch(`/api/auth/sessions/${activeSessionId}`, {
          method: 'DELETE',
          headers: { 'Authorization': `Bearer ${storedToken}` }
        });
      } catch (_) {}
    }

    // P1-hardening: server clears the refresh cookie; scrub local state only.
    try {
      await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin' });
    } catch (_) {}
    localStorage.removeItem('dirasha_user');
    TokenVault.clearVault();

    setAccessToken(null);
    setCurrentUser(null);
    setActiveChatId(null);
    setRawMessages([]);
    setRawChats([]);

    // Clear the PWA app-icon unread badge on logout (feature-detected).
    try {
      if (typeof navigator !== 'undefined' && 'clearAppBadge' in navigator) {
        (navigator as Navigator & { clearAppBadge?: () => Promise<void> }).clearAppBadge?.()?.catch(() => {});
      }
    } catch (_) {}
  };

  // RESTORING SECURE WORKSPACE - Application Boot Phase
  if (checkingAuth) {
    return (
      <div className="w-screen h-screen bg-[#0a0a0a] flex flex-col items-center justify-center relative overflow-hidden">
        {/* Subtle ambient glow background */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-white/[0.02] rounded-full blur-[120px] pointer-events-none" />
        
        <div className="relative flex flex-col items-center">
          {/* Glassy Loading Orb */}
          <div className="relative w-20 h-20 mb-10">
            {/* Outer soft pulsing ring */}
            <motion.div 
              animate={{ 
                scale: [1, 1.1, 1],
                opacity: [0.1, 0.2, 0.1] 
              }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -inset-4 border border-white/10 rounded-full"
            />
            {/* Middle orbital ring */}
            <motion.div 
              animate={{ rotate: 360 }}
              transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
              className="absolute inset-0 border-[1.5px] border-t-white/20 border-r-white/5 border-b-white/5 border-l-white/5 rounded-full"
            />
            {/* Inner Glass Orb */}
            <div className="absolute inset-2 bg-gradient-to-br from-white/[0.08] to-white/[0.02] backdrop-blur-md rounded-full border border-white/10 shadow-2xl flex items-center justify-center">
              <motion.div 
                animate={{ opacity: [0.3, 0.7, 0.3] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                className="w-2 h-2 bg-white/40 rounded-full"
              />
            </div>
          </div>

          {/* Minimalist Typography */}
          <div className="flex flex-col items-center gap-3">
            <motion.p 
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-[11px] font-medium text-zinc-400 uppercase tracking-[0.5em] select-none"
            >
              Restoring Workspace
            </motion.p>
            <div className="flex gap-1.5 h-1 items-center">
              {[0, 1, 2].map((i) => (
                <motion.div 
                  key={i}
                  animate={{ 
                    scale: [1, 1.5, 1],
                    opacity: [0.2, 0.5, 0.2] 
                  }}
                  transition={{ 
                    duration: 1.5, 
                    repeat: Infinity, 
                    delay: i * 0.2,
                    ease: "easeInOut" 
                  }}
                  className="w-1 h-1 rounded-full bg-white/30"
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  let activeChatMeta = chats.find(c => c.id === activeChatId);
  if (!activeChatMeta && activeChatId) {
    if (activeChatId.startsWith('one_to_one_')) {
      const myId = currentUser?.uid || currentUser?.id;
      const participants = activeChatId.replace('one_to_one_', '').split('___');
      const otherUserId = participants.find(id => id !== myId);
      const otherUser = otherUserId ? allUsers[otherUserId] : null;

      activeChatMeta = {
        id: activeChatId,
        type: 'one-to-one',
        memberIds: participants,
        name: otherUser?.displayName || 'جاري ربط المحادثة...',
        avatarUrl: otherUser?.avatarUrl || otherUser?.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop',
        otherMember: otherUser ? {
          id: otherUser.id,
          username: otherUser.username || '',
          displayName: otherUser.displayName || '',
          avatarUrl: otherUser.avatarUrl || otherUser.photoURL || '',
          bannerUrl: otherUser.bannerUrl,
          backgroundBannerUrl: otherUser.backgroundBannerUrl,
          bannerShadowOpacity: otherUser.bannerShadowOpacity,
          bgBannerShadowOpacity: otherUser.bgBannerShadowOpacity
        } : undefined,
        unreadCount: 0,
        lastMessage: null,
        activeTypers: [],
        activeRecorders: []
      };
    } else {
      // Fallback for newly created or loading chats
      activeChatMeta = {
        id: activeChatId,
        type: 'one-to-one',
        name: 'جاري تحميل تفاصيل المحادثة...',
        avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&h=150&q=80',
        unreadCount: 0,
        lastMessage: null,
        activeTypers: [],
        activeRecorders: []
      };
    }
  }
  const activeTypers = activeChatMeta?.activeTypers || [];
  const activeRecorders = activeChatMeta?.activeRecorders || [];

  const theme = currentUser?.appearanceSettings?.theme || 'dark';
  const isLight = theme === 'light' || (theme === 'system' && typeof window !== 'undefined' && !window.matchMedia('(prefers-color-scheme: dark)').matches);
  const compactMode = currentUser?.appearanceSettings?.compactMode;
  const fontSize = currentUser?.appearanceSettings?.fontSize || 'medium';

  const rootClasses = [
    "h-screen w-screen flex flex-col font-sans select-none overflow-hidden transition-all duration-300 bg-[var(--app-bg)] text-[var(--text-primary)]",
    isLight ? "light-theme" : "",
    compactMode ? "compact-mode" : "",
    fontSize === 'small' ? 'font-size-small' : fontSize === 'large' ? 'font-size-large' : '',
    // Appearance depth (batch 12): accent + bubble corners
    currentUser?.appearanceSettings?.accentColor ? 'app-accent' : '',
    currentUser?.appearanceSettings?.bubbleCorners ? `corners-${currentUser.appearanceSettings.bubbleCorners}` : ''
  ].join(' ');

  const accentHex: Record<string, string> = {
    emerald: '#10b981', blue: '#3b82f6', purple: '#8b5cf6',
    rose: '#f43f5e', amber: '#f59e0b', teal: '#14b8a6',
  };
  const accentStyle = {
    direction: 'ltr',
    ...(currentUser?.appearanceSettings?.accentColor
      ? { '--accent': accentHex[currentUser.appearanceSettings.accentColor] || currentUser.appearanceSettings.accentColor } as any
      : {}),
  };

  return (
    <div className="bg-black min-h-screen">
      <AnimatePresence mode="wait">
        {!accessToken || !currentUser ? (
          <motion.div
            key="auth_screen"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 0.9, filter: 'blur(40px)' }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="fixed inset-0 z-[1000] bg-black"
          >
            <AuthScreen 
              onAuthSuccess={(token, profile, sessionId) => {
                setIsFreshLogin(true);
                setAccessToken(token);
                setCurrentUser(profile);
                TokenVault.setAccessToken(token);
                localStorage.setItem('dirasha_user', JSON.stringify(profile));
                if (sessionId) {
                  TokenVault.setSessionId(sessionId);
                }
              }} 
            />
          </motion.div>
        ) : (
          <motion.div 
            key="main_app"
            initial={isFreshLogin ? { opacity: 0, scale: 1.1, filter: 'blur(30px)' } : { opacity: 0 }}
            animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            className={rootClasses}
            style={accentStyle}
          >
          
          {quotaExceeded && (
            <div className="bg-orange-600/15 border-b border-orange-500/30 px-6 py-3 flex items-center justify-between gap-4 text-orange-200 text-[13px] shrink-0 shadow-lg relative z-50 backdrop-blur-2xl">
              <div className="flex items-center gap-3 flex-1">
                <AlertTriangle className="w-5 h-5 text-orange-400" />
                <span className="font-bold tracking-tight uppercase italic">
                  <strong>SYSTEM ALERT:</strong> High infrastructure load. Switching to persistent mirror mode temporarily. All services will restore automatically.
                </span>
              </div>
              <button 
                onClick={() => {
                  setQuotaExceeded(false);
                  localStorage.removeItem('firestore_quota_exceeded');
                }} 
                className="text-orange-500 hover:text-white font-black px-4 py-2 text-xs transition-all hover:scale-105 active:scale-95 bg-white/5 rounded-xl border border-white/5"
              >
                DISMISS
              </button>
            </div>
          )}
      
      {/* Main Container */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Sidebar directory - on the left in LTR */}
        <ChatSidebar
                  onOpenSessionsPanel={() => setSessionsPanelOpen(true)}
                  onEmergencyRotate={async () => {
                    const engine = e2eeRef.current;
                    if (!engine) throw new Error('E2EE engine not ready');
                    return engine.emergencyRotate();
                  }}
          accessToken={accessToken}
          activeChatId={activeChatId}
          chats={chats}
          currentUser={currentUser}
          allUsers={allUsers}
          onChatSelect={(id) => {
            handleChatSelect(id);
            setStatusFile(null); // Close studio when chat selected
          }}
          onLogout={handleLogout}
          onRefreshChats={() => {}}
          onSelectUserDirect={handleSelectUserDirect}
          onViewProfile={setViewUserProfileId}
          presenceTick={presenceTick}
          onSetHighlightMsgId={(chatId: string, msgId: string) => {
            setHighlightMsgId(msgId);
            handleChatSelect(chatId);
            setStatusFile(null);
          }}
          setCurrentUser={setCurrentUser}
          onOpenModerationCenter={() => setShowModerationCenter(true)}
          unreadReportsCount={unreadReportsCount}
          onReportUser={(userId: string) => {
            setReportingUserId(userId);
          }}
          targetStatusData={targetStatusData}
          setTargetStatusData={setTargetStatusData}
          statusFile={statusFile}
          onStatusFileChange={handleStatusFileChange}
        />

        {/* Chat window logic - If active chat, render ChatWindow, otherwise a beautiful selection view */}
        <div className={`main-content-panel flex-col ${(!activeChatId) ? 'inactive' : 'flex'}`}>
          {activeChatId && activeChatMeta ? (
            <div className="relative w-full h-full flex flex-col">
              {/* Group-call entry buttons (App-rendered overlay aligned with the
                  ChatWindow top bar — ChatWindow only shows 1:1 call buttons).
                  Offset right to sit inline before the group-settings button. */}
              {activeChatMeta?.type === 'group' && !groupCallState && (
                <div className="absolute top-0 left-0 right-0 z-40 pointer-events-none">
                  <div className="max-w-[720px] mx-auto p-3 md:p-4 pr-[54px] md:pr-[58px] flex items-center justify-end gap-2">
                    <div
                      onClick={() => startGroupCall(activeChatMeta, 'voice')}
                      className="btn-circle cursor-pointer pointer-events-auto hover:bg-white/10 active:scale-95 transition-all"
                      title="مكالمة صوتية جماعية"
                    >
                      <Phone className="w-4 h-4 text-zinc-300 pointer-events-none" />
                    </div>
                    <div
                      onClick={() => startGroupCall(activeChatMeta, 'video')}
                      className="btn-circle cursor-pointer pointer-events-auto hover:bg-white/10 active:scale-95 transition-all"
                      title="مكالمة فيديو جماعية"
                    >
                      <Video className="w-4 h-4 text-zinc-300 pointer-events-none" />
                    </div>
                  </div>
                </div>
              )}
              <ChatWindow
                accessToken={accessToken}
                chatId={activeChatId}
                currentUser={currentUser}
                allUsers={allUsers}
                messages={messages}
                typingUsers={activeTypers}
                recordingUsers={activeRecorders}
                isLoadingMessages={loadingMessages}
                onSendMessage={handleSendMessage}
                encryptContentForChat={encryptContentForChat}
                chatSupportsE2ee={(cid: string) => {
                  const chat = (rawChatsRef.current || []).find((c: any) => c?.id === cid);
                  return !!chat && (chat.type === 'group' || !!e2eePeerForChat(cid));
                }}
                onEmitTyping={handleEmitTyping}
                onRecordingStatusChange={handleRecordingStatusChange}
                onMarkRead={handleMarkRead}
                onLoadMoreMessages={loadOlderMessages}
                hasMore={hasMoreMessages}
                selectedChatMeta={activeChatMeta}
                onGetSafetyNumber={async (peerId: string) => {
                  const engine = e2eeRef.current;
                  if (!engine) throw new Error('E2EE engine not ready');
                  const sn = await engine.getSafetyNumber(peerId);
                  // Task C: record 'e2eeLastSN' on every successful fetch and
                  // detect rekeys (number differs from the last recorded one).
                  recordSafetyNumberFetch(peerId, sn);
                  return sn;
                }}
                /* Encrypt-at-source eligibility (F1/P0): EXACTLY mirrors the
                   send-wrap eligibility (REGULAR group via isE2eeGroupChat, or
                   1:1 DM with a resolvable e2eePeer). ChatWindow uses it to
                   encrypt composer media BEFORE upload; ineligible chats keep
                   the legacy plaintext upload path. */
                e2eeActive={
                  isE2eeGroupChat((rawChatsRef.current || []).find((c: any) => c?.id === activeChatId)) ||
                  !!e2eePeerForChat(activeChatId)
                }
                /* F8 (audit): plaintext-downgrade memory surfaced — when the
                   active DM peer has no E2EE bundle the engine persists the
                   per-peer flag and ChatWindow renders the "غير مشفرة
                   طرف-لطرف" badge in place of the lock (no silent downgrade). */
                e2eeDowngraded={activeChatDowngraded}
                onExportChat={() => setBackupPanel({ id: activeChatId, name: (activeChatMeta as any)?.name || 'محادثة' })}
                onBack={() => setActiveChatId(null)}
                presenceTick={presenceTick}
                highlightMsgId={highlightMsgId}
                onClearHighlight={() => setHighlightMsgId(null)}
                onViewProfile={setViewUserProfileId}
                onRetryMessage={handleRetryMessage}
                onReportMessage={(messageId: string, senderId: string, senderName: string, content: string) => {
                  setReportingMessage({ messageId, senderId, senderName, content });
                }}
                onStartVoiceCall={() => {
                  if (activeChatMeta.type !== 'one-to-one') {
                    alert('المكالمات الصوتية متاحة فقط لمحادثات مستخدم إلى مستخدم (1-to-1).');
                    return;
                  }
                  const targetUserId = activeChatMeta.otherMember?.id;
                  const partnerName = activeChatMeta.name;
                  const partnerAvatar = activeChatMeta.avatarUrl;
                  if (targetUserId) {
                    startVoiceCall(targetUserId, partnerName, partnerAvatar, 'voice', activeChatId || undefined);
                  } else {
                    alert('حدث خطأ: لم يتم العثور على معرف المستخدم المستهدف.');
                  }
                }}
                onStartVideoCall={() => {
                  if (activeChatMeta.type !== 'one-to-one') {
                    alert('مكالمات الفيديو متاحة فقط لمحادثات مستخدم إلى مستخدم (1-to-1).');
                    return;
                  }
                  const targetUserId = activeChatMeta.otherMember?.id;
                  const partnerName = activeChatMeta.name;
                  const partnerAvatar = activeChatMeta.avatarUrl;
                  if (targetUserId) {
                    startVoiceCall(targetUserId, partnerName, partnerAvatar, 'video', activeChatId || undefined);
                  } else {
                    alert('حدث خطأ: لم يتم العثور على معرف المستخدم المستهدف.');
                  }
                }}
                onOpenStatus={(statusId, userId) => {
                  setTargetStatusData({ statusId, userId });
                }}
              />
            </div>
          ) : (
            <div className="hidden md:flex flex-1 h-full bg-[#030304] flex-col justify-center items-center p-8 text-center">
              <div className="p-6 bg-white/5 rounded-[36px] mb-6 border border-white/10 shadow-2xl relative">
                <ShieldCheck className="w-16 h-16 text-slate-400" />
              </div>
              
              <h3 className="text-2xl font-bold text-white mb-2 tracking-tight">DIRASHA</h3>
              <p className="text-[15px] text-slate-400 max-w-sm leading-relaxed mb-8 font-medium">
                Select a chat to start messaging
              </p>
  
              <div className="flex items-center gap-2 text-[13px] text-slate-500 bg-white/5 py-2.5 px-6 rounded-full border border-white/10 shadow-inner font-medium">
                <svg className="w-4 h-4 text-slate-400" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                </svg>
                <span>🔒 مشفّر أثناء النقل (TLS) — الخصوصية أولوية</span>
              </div>
            </div>
          )}
        </div>

      </div>
      
      {viewUserProfileId && (
        <Suspense fallback={<LazyChunkFallback />}>
        {backupPanel && (
          <Suspense fallback={null}>
            <E2eeBackupPanel
              open={true}
              chatId={backupPanel.id}
              chatName={backupPanel.name}
              getMessages={async () => {
                const all = (rawMessagesRef.current || []) as any[];
                return all
                  .filter((m: any) => !m.chatId || m.chatId === backupPanel.id)
                  .map((m: any) => ({
                    id: m.id,
                    senderId: m.senderId,
                    senderName: m.senderName,
                    content: m.content,
                    createdAt: m.createdAt,
                    type: m.type,
                  }));
              }}
              onClose={() => setBackupPanel(null)}
            />
          </Suspense>
        )}
        {sessionsPanelOpen && (
          <Suspense fallback={null}>
            <ActiveSessionsPanel open={true} onClose={() => setSessionsPanelOpen(false)} />
          </Suspense>
        )}
          <UserProfileModal
          userId={viewUserProfileId}
          allUsers={allUsers}
          currentUserId={currentUserId}
          onClose={() => setViewUserProfileId(null)}
          onStartDirectMessage={handleSelectUserDirect}
          onReportUser={(userId: string) => {
            setReportingUserId(userId);
            setViewUserProfileId(null);
          }}
          />
        </Suspense>
      )}

      {reportingUserId && (
        <Suspense fallback={<LazyChunkFallback />}>
          <ReportModal
          isOpen={!!reportingUserId}
          targetUserId={reportingUserId}
          targetUserDisplayName={allUsers[reportingUserId]?.displayName || reportingUserId}
          accessToken={accessToken!}
          onClose={() => setReportingUserId(null)}
          />
        </Suspense>
      )}

      {reportingMessage && (
        <Suspense fallback={<LazyChunkFallback />}>
          <ReportModal
          isOpen={!!reportingMessage}
          targetUserId={reportingMessage.senderId}
          targetUserDisplayName={reportingMessage.senderName}
          targetMessageId={reportingMessage.messageId}
          targetMessageContent={reportingMessage.content}
          accessToken={accessToken!}
          onClose={() => setReportingMessage(null)}
          />
        </Suspense>
      )}

      {showModerationCenter && (
        <Suspense fallback={<LazyChunkFallback />}>
          <ModerationCenter
          isOpen={showModerationCenter}
          onClose={() => setShowModerationCenter(false)}
          accessToken={accessToken}
          currentUser={currentUser}
          />
        </Suspense>
      )}

      {activeCall && (
        <CallInterface
          call={activeCall}
          localStream={localStream}
          remoteStream={remoteStream}
          allUsers={allUsers}
          onAccept={acceptVoiceCall}
          onReject={rejectVoiceCall}
          onRejectWithMessage={rejectVoiceCallWithMessage}
          ringtoneStyle={currentUser?.notificationSettings?.ringtoneStyle}
          onEnd={handleEndCall}
          onLocalStreamChange={(stream) => {
            localStreamRef.current = stream;
            setLocalStreamState(stream);
          }}
          peerConnection={peerConnectionState}
        />
      )}

      {groupCallState && (
        <Suspense fallback={<LazyChunkFallback />}>
          <GroupCallView
          call={groupCallState}
          myId={currentUserId}
          participants={groupCallTiles}
          remoteStreams={groupRemoteStreams}
          localStream={groupLocalStream}
          isMuted={groupIsMuted}
          isCameraOff={groupIsCameraOff}
          screenStream={groupScreenShare?.stream || null}
          isScreenSharing={!!groupScreenShare}
          onToggleMute={toggleGroupMute}
          onToggleCamera={toggleGroupCamera}
          onToggleScreenShare={toggleGroupScreenShare}
          onLeave={leaveGroupCall}
          />
        </Suspense>
      )}

      {/* Group-call invite ringing banner (one-shot broadcast, auto-dismiss 45s) */}
      {groupIncomingInvite && !groupCallState && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="fixed top-6 right-6 z-[9998] w-[min(92vw,360px)] bg-[#0c0c0e]/95 backdrop-blur-xl border border-emerald-500/25 rounded-2xl shadow-[0_0_40px_rgba(0,0,0,0.8)] p-4"
          style={{ direction: 'rtl' }}
        >
          <div className="flex items-start gap-3">
            <div className="relative shrink-0">
              <div className="w-11 h-11 rounded-full bg-gradient-to-tr from-emerald-600 to-emerald-400 flex items-center justify-center text-white border border-white/10">
                <Users className="w-5 h-5" />
              </div>
              <motion.div
                animate={{ scale: [1, 1.4, 1], opacity: [0.6, 0, 0.6] }}
                transition={{ repeat: Infinity, duration: 1.8, ease: 'easeInOut' }}
                className="absolute -inset-1.5 rounded-full border border-emerald-500/40 pointer-events-none"
              />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-white truncate">
                {groupIncomingInvite.type === 'video' ? 'مكالمة فيديو جماعية' : 'مكالمة صوتية جماعية'}
              </p>
              <p className="text-[11px] text-zinc-400 truncate">
                {groupIncomingInvite.initiatorName} يدعوك للانضمام — {groupIncomingInvite.chatName}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 mt-3">
            <button
              type="button"
              onClick={() => joinIncomingGroupCall(groupIncomingInvite)}
              className="flex-1 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold transition-all active:scale-95 cursor-pointer"
            >
              انضمام
            </button>
            <button
              type="button"
              onClick={dismissGroupInvite}
              className="flex-1 py-2 rounded-xl bg-white/10 border border-white/10 text-zinc-300 text-xs font-bold hover:bg-white/20 transition-all active:scale-95 cursor-pointer"
            >
              رفض
            </button>
          </div>
        </motion.div>
      )}

      {showLockScreen && (
        <div className="fixed inset-0 bg-[#0e1118] text-white z-[9999] flex flex-col items-center justify-center p-6 select-none font-sans">
          <div className="max-w-md w-full flex flex-col items-center space-y-8 animate-fade-in text-center">
            {/* Pulsing Lock Icon */}
            <div className="relative">
              <div className="absolute inset-0 bg-blue-500/20 rounded-full blur-2xl animate-pulse w-24 h-24 -m-4"></div>
              <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-blue-600 to-blue-400 flex items-center justify-center text-slate-900 shadow-[0_8px_30px_rgb(59,130,246,0.3)] border border-blue-300/30">
                <Lock className="w-8 h-8 text-slate-950" />
              </div>
            </div>

            {/* Title & Info */}
            <div className="space-y-2 animate-fade-in-up">
              <h2 className="text-[22px] font-black tracking-tighter text-white italic uppercase">Screen Locked</h2>
              <p className="text-[13px] text-white/40 max-w-xs mx-auto">
                Enter your PIN to unlock the interface. This is a privacy screen lock only — it does not encrypt or decrypt any data.
              </p>
            </div>

            {/* Error Message */}
            <div className="h-5">
              {pinError && (
                <span className="text-red-400 text-xs font-bold animate-pulse">{pinError}</span>
              )}
            </div>

            {/* Dots Display */}
            <div className={`flex justify-center gap-6 py-2 ${pinShake ? 'animate-bounce' : ''}`}>
              {[0, 1, 2, 3].map((idx) => {
                const filled = typedPin.length > idx;
                return (
                  <div
                    key={idx}
                    className={`h-4.5 w-4.5 rounded-full border-2 transition-all duration-150 ${
                      filled
                        ? 'bg-blue-400 border-blue-400 scale-110 shadow-[0_0_12px_rgba(59,130,246,0.6)]'
                        : 'border-white/10 bg-white/5'
                    }`}
                  />
                );
              })}
            </div>

            {/* Numeric Grid */}
            <div className="grid grid-cols-3 gap-x-8 gap-y-4 pt-3 max-w-[280px] w-full">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => handleKeyPress(String(num))}
                  className="h-16 w-16 rounded-full bg-white/[0.03] border border-white/5 text-[22px] font-bold hover:bg-white/[0.08] hover:border-white/10 active:bg-white/[0.15] active:scale-90 transition-all cursor-pointer flex items-center justify-center font-mono"
                >
                  {num}
                </button>
              ))}
              <button
                type="button"
                onClick={() => {
                  setTypedPin('');
                  setPinError(null);
                }}
                className="h-16 w-16 text-[12px] font-bold text-white/30 hover:text-white/60 active:scale-90 transition-all cursor-pointer flex items-center justify-center"
              >
                CLEAR
              </button>
              <button
                type="button"
                onClick={() => handleKeyPress('0')}
                className="h-16 w-16 rounded-full bg-white/[0.03] border border-white/5 text-[22px] font-bold hover:bg-white/[0.08] hover:border-white/10 active:bg-white/[0.15] active:scale-90 transition-all cursor-pointer flex items-center justify-center font-mono"
              >
                0
              </button>
              <button
                type="button"
                onClick={handleBackspace}
                className="h-16 w-16 text-white/40 hover:text-white/70 active:scale-90 transition-all cursor-pointer flex items-center justify-center text-xl font-mono"
              >
                ⌫
              </button>
            </div>
            
            <button
              onClick={handleLogout}
              className="text-xs font-bold text-red-400/40 hover:text-red-400 hover:underline pt-4 tracking-wider uppercase transition-colors"
            >
              TERMINATE SESSION
            </button>
          </div>
        </div>
      )}

        </motion.div>
      )}
    </AnimatePresence>
      {/* Premium Glassmorphic iPhone-Style PWA Install Prompt */}
      <AnimatePresence>
        {showPWAInstallPrompt && (
          <div className="fixed inset-0 z-[10000] flex items-center justify-center bg-black/60 backdrop-blur-xl px-6" style={{ direction: 'ltr' }}>
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 30 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.98, opacity: 0, y: 15 }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="relative w-full max-w-sm rounded-[40px] bg-white/[0.08] border border-white/20 p-8 text-center shadow-[0_32px_80px_rgba(0,0,0,0.9)] overflow-hidden backdrop-blur-[60px]"
            >
              {/* App Icon Visual - Professional Central Layout */}
              <div className="relative mb-6 inline-block">
                <div className="w-20 h-20 rounded-[22px] bg-white/[0.05] border border-white/10 flex items-center justify-center shadow-2xl overflow-hidden p-0.5">
                  <img
                    src="https://i.ibb.co/MD4bsZC3/96.png"
                    alt="Dirasha App"
                    className="w-full h-full rounded-[20px] object-cover"
                  />
                </div>
              </div>

              {/* Title & Description */}
              <h3 className="text-[20px] font-black text-white mb-3 tracking-tight">ديراشة | Dirasha</h3>
              <p className="text-[13px] text-zinc-300/90 leading-relaxed mb-8 px-2">
                قم بتثبيت التطبيق على جهازك للحصول على تجربة ملء الشاشة الكاملة وتصفح أسرع وأكثر استقراراً.
              </p>

              {/* Liquid List Style Options */}
              <div className="flex flex-col w-full divide-y divide-white/10 rounded-[24px] bg-white/[0.05] border border-white/10 overflow-hidden">
                {/iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream ? (
                  // iOS Specific Safari Instructions in List Item style
                  <div className="p-5 text-left space-y-4">
                    <div className="flex items-center gap-3 text-xs text-white/90">
                      <div className="w-6 h-6 rounded-lg bg-sky-500/20 border border-sky-500/20 flex items-center justify-center text-[10px] font-black shrink-0">١</div>
                      <span>اضغط على <Share className="w-3.5 h-3.5 inline mx-0.5 text-sky-400" /> في متصفح سفاري</span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-white/90">
                      <div className="w-6 h-6 rounded-lg bg-sky-500/20 border border-sky-500/20 flex items-center justify-center text-[10px] font-black shrink-0">٢</div>
                      <span>اختر "إضافة للشاشة الرئيسية"</span>
                    </div>
                    <button
                      type="button"
                      onClick={handleDismissPWAInstall}
                      className="w-full py-4 text-sm font-bold text-white/40 hover:text-white transition-colors pt-6"
                    >
                      إغلاق
                    </button>
                  </div>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={handleInstallPWA}
                      className="w-full py-4.5 px-6 text-white font-black text-[15px] hover:bg-white/5 active:scale-95 transition-all cursor-pointer"
                    >
                      تثبيت التطبيق الآن
                    </button>
                    <button
                      type="button"
                      onClick={handleDismissPWAInstall}
                      className="w-full py-4.5 px-6 text-white/40 hover:text-white/70 font-bold text-[13px] hover:bg-white/5 active:scale-95 transition-all cursor-pointer"
                    >
                      تذكيري لاحقاً
                    </button>
                  </>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Full-Screen Photo & Video Status Studios */}
      {statusFile && (
        <div className="fixed inset-0 z-[9000] bg-zinc-950/98 backdrop-blur-3xl flex items-center justify-center overflow-hidden font-sans">
          {statusFile.type.startsWith('video/') ? (
            <Suspense fallback={<LazyChunkFallback />}>
              <VideoStudio
              file={statusFile}
              onCancel={() => setStatusFile(null)}
              submitLabel="SEND"
              submitIcon={Plus}
              isSubmitting={isUploadingStatus}
              onSend={async (editedFile, options) => {
                try {
                  setIsUploadingStatus(true);
                  if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                    (window as any).showGlobalToast('Uploading video status...', 'info');
                  }
                  const { uploadImageToStorage } = await import('./lib/storageUtils');
                  const base64Url = await uploadImageToStorage(editedFile, 'status-media', 1200, 0.85);

                  const response = await fetch('/api/statuses', {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/json',
                      'Authorization': `Bearer ${accessToken}`,
                    },
                    body: JSON.stringify({
                      content_type: 'video',
                      media_url: base64Url,
                      text_content: options.caption,
                      duration_hours: 24,
                      settings: {
                        startTime: options.startTime,
                        endTime: options.endTime,
                        textOverlays: options.textOverlays
                      }
                    }),
                  });

                  if (response.ok) {
                    if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                      (window as any).showGlobalToast('تم تحديث الحالة بنجاح!', 'success');
                    }
                    setStatusFile(null);
                    window.dispatchEvent(new CustomEvent('status-updated'));
                  }
                } catch (err) {
                  console.error('Failed to upload status:', err);
                } finally {
                  setIsUploadingStatus(false);
                }
              }}
              />
            </Suspense>
          ) : (
            <Suspense fallback={<LazyChunkFallback />}>
              <ImageEditor
              file={statusFile}
              onCancel={() => setStatusFile(null)}
              submitLabel="SEND"
              submitIcon={Plus}
              isSubmitting={isUploadingStatus}
              onSend={async (editedFile) => {
                try {
                  setIsUploadingStatus(true);
                  if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                    (window as any).showGlobalToast('Uploading status...', 'info');
                  }
                  const { uploadImageToStorage } = await import('./lib/storageUtils');
                  const base64Url = await uploadImageToStorage(editedFile, 'status-media', 1200, 0.85);

                  const response = await fetch('/api/statuses', {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/json',
                      'Authorization': `Bearer ${accessToken}`,
                    },
                    body: JSON.stringify({
                      content_type: 'image',
                      media_url: base64Url,
                      duration_hours: 24,
                    }),
                  });

                  if (response.ok) {
                    if (typeof window !== 'undefined' && (window as any).showGlobalToast) {
                      (window as any).showGlobalToast('تم تحديث الحالة بنجاح!', 'success');
                    }
                    setStatusFile(null);
                    window.dispatchEvent(new CustomEvent('status-updated'));
                  }
                } catch (err) {
                  console.error('Failed to upload status:', err);
                } finally {
                  setIsUploadingStatus(false);
                }
              }}
              />
            </Suspense>
          )}
        </div>
      )}

      {isUploadingStatus && (
        <div className="fixed inset-0 z-[99999] bg-zinc-950/90 backdrop-blur-xl flex flex-col items-center justify-center gap-6 font-sans">
          <div className="relative w-24 h-24 flex items-center justify-center">
            {/* Spinning glowing glass circle */}
            <div className="absolute inset-0 border-4 border-emerald-500/10 border-t-emerald-500 rounded-full animate-spin"></div>
            <div className="absolute inset-2 border-4 border-teal-500/20 border-b-teal-500 rounded-full animate-spin [animation-direction:reverse]"></div>
            <div className="text-emerald-500 p-2 font-mono text-xs font-bold animate-pulse">UP</div>
          </div>
          <div className="flex flex-col items-center gap-2">
            <h3 className="text-white font-semibold tracking-wider text-lg">جاري رفع الحالة الآن...</h3>
            <p className="text-emerald-400/80 text-xs font-mono">يرجى الانتظار، يتم معالجة وتشفير الوسائط</p>
          </div>
          {/* Animated custom visual progress bar */}
          <div className="w-64 h-1.5 bg-white/10 rounded-full overflow-hidden relative">
            <div className="absolute left-0 top-0 h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full animate-[progress_2.5s_ease-in-out_infinite]" style={{ width: '100%' }}></div>
          </div>
          <style>{`
            @keyframes progress {
              0% { transform: translateX(-100%); }
              50% { transform: translateX(0); }
              100% { transform: translateX(100%); }
            }
          `}</style>
        </div>
      )}

    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <AppContent />
    </ToastProvider>
  );
}
