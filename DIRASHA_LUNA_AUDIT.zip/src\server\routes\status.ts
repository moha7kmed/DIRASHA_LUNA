import express, { Request, Response } from 'express';
import { db, pool } from '../database.ts';
import { redisCluster } from '../websocket/redis_client.ts';
import { canViewStatus, getStatusVisibility, validateComment } from '../guards/statusPolicy.ts';
import crypto from 'crypto';

export const statusRouter = express.Router();

/** Load a full status row (or null) — shared by the gated sub-routes. */
async function loadStatusRow(statusId: string): Promise<any | null> {
  const res = await pool.query('SELECT * FROM statuses WHERE id = $1', [statusId]);
  return res.rows[0] || null;
}

// Get active statuses from contacts and self
statusRouter.get('/', async (req: Request, res: Response) => {
  try {
    const userId = req.user!.userId;
    // In a real app we'd filter by contacts or who the user follows.
    // For now we will fetch all active non-archived statuses that haven't expired.

    const query = `
      SELECT s.*, u.username, u.display_name, u.avatar_url,
      (SELECT COUNT(*) FROM status_views sv WHERE sv.status_id = s.id) as views_count,
      (SELECT COUNT(*) FROM status_likes sl WHERE sl.status_id = s.id) as likes_count,
      (SELECT EXISTS(SELECT 1 FROM status_likes sl WHERE sl.status_id = s.id AND sl.user_id = $1)) as has_liked
      FROM statuses s
      JOIN users u ON s.user_id = u.id
      WHERE s.is_archived = FALSE
      AND s.expires_at > CURRENT_TIMESTAMP
      ORDER BY s.created_at DESC
      LIMIT 100
    `;

    const result = await pool.query(query, [userId]);

    // STATUS-01: unified privacy enforcement — the same canViewStatus policy
    // used by the WS fanout and every status sub-route. Self statuses always
    // visible; others filtered per owner's settings (fail-closed).
    const visibilityFiltered: any[] = [];
    for (const row of result.rows) {
      if (await canViewStatus(db, userId, row)) {
        visibilityFiltered.push(row);
      }
    }

    res.json({ statuses: visibilityFiltered });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Create a new status
statusRouter.post('/', async (req: Request, res: Response) => {
  try {
    const userId = req.user!.userId;
    const { content_type, media_url, text_content, duration_hours, settings } = req.body;

    // BATCH-6 (NEW-A-07): statuses are bounded like comments (the 5MB body
    // limit previously allowed megabyte rows) and lifetime is capped at 7 days.
    const statusText = typeof text_content === 'string' ? text_content : '';
    if (statusText.length > 500) {
      return res.status(413).json({ error: 'الحالة طويلة جداً (الحد 500 حرف).' });
    }
    const boundedDuration = Math.max(1, Math.min(Number(duration_hours) || 24, 168));

    if (!content_type) {
      return res.status(400).json({ error: 'content_type is required' });
    }

    // MEDIA ARCHITECTURE GUARD: statuses must reference externally-hosted media.
    // Inline base64 is rejected — clients must presign+PUT to object storage first.
    if (typeof media_url === 'string' && media_url.startsWith('data:')) {
      return res.status(400).json({ error: 'يجب رفع وسائط الحالة إلى التخزين السحابي أولاً.' });
    }
    if (media_url && !/^https:\/\//i.test(media_url)) {
      return res.status(400).json({ error: 'رابط الوسائط يجب أن يكون HTTPS من تخزين سحابي.' });
    }

    const statusId = 'status-' + crypto.randomUUID();
    const duration = boundedDuration; // BATCH-7 (Agent-B re-verification): the bounded value MUST be the persisted one (dead-store recurrence of the AB-06 class)
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + duration);

    // Robustly parse and clean up incoming settings input to avoid PG datatype errors or double stringification
    let cleanedSettings = settings;
    if (typeof cleanedSettings === 'string') {
      try {
        cleanedSettings = JSON.parse(cleanedSettings);
      } catch (e) {
        cleanedSettings = null;
      }
    }
    if (!cleanedSettings || typeof cleanedSettings !== 'object') {
      cleanedSettings = { likes_visibility: 'everyone', comments: 'open', replies: 'open', views_visibility: 'everyone' };
    }

    const insertQuery = `
      INSERT INTO statuses (id, user_id, content_type, media_url, text_content, duration_hours, expires_at, settings)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING *
    `;

    const result = await pool.query(insertQuery, [
      statusId,
      userId,
      content_type,
      media_url || null,
      statusText || null,
      duration,
      expiresAt.toISOString(),
      JSON.stringify(cleanedSettings)
    ]);

    // STATUS-01: per-recipient fanout — the global `presence:broadcast`
    // channel NEVER carries status rows again (it previously leaked
    // text_content/media_url to every open socket, including users the
    // owner's statusVisibility excluded). Instead, each allowed recipient's
    // private `user:updates:<uid>` channel receives a pointer-only event
    // {statusId, ownerId}; recipients fetch the status via the authenticated
    // GET, which enforces canViewStatus server-side.
    const created = result.rows[0];
    try {
      const visibility = await getStatusVisibility(db, userId);
      let candidates: string[] = [];
      if (visibility === 'contacts') {
        candidates = await db.getContacts(userId);
      } else if (visibility === 'everyone') {
        const users = await db.getUsers();
        candidates = users.map((u: any) => u?.id).filter((id: any) => typeof id === 'string');
      } // 'nobody' → no broadcast at all

      const pointerPayload = { statusId: created.id, ownerId: userId };
      const notified = new Set<string>();
      for (const recipientId of candidates) {
        if (!recipientId || recipientId === userId || notified.has(recipientId)) continue;
        notified.add(recipientId);
        // Defense-in-depth: re-check the policy per recipient (settings may
        // resolve differently per viewer, e.g. contact-list churn).
        if (!(await canViewStatus(db, recipientId, created))) continue;
        await redisCluster.publish(`user:updates:${recipientId}`, {
          event: 'status:new',
          payload: pointerPayload,
        });
      }
    } catch (fanoutError: any) {
      // The status exists — a fanout failure must not fail the create.
      console.warn('[statusRouter] status:new fanout failed:', fanoutError?.message);
    }

    res.status(201).json({ status: created });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Register a view
statusRouter.post('/:id/view', async (req: Request, res: Response) => {
  try {
    const userId = req.user!.userId;
    const statusId = req.params.id;

    // STATUS-01: viewers must be allowed to see the status they register a view on.
    const status = await loadStatusRow(statusId);
    if (!status) {
      return res.status(404).json({ error: 'Status not found' });
    }
    if (!(await canViewStatus(db, userId, status))) {
      return res.status(403).json({ error: 'لا يمكنك الوصول إلى هذه الحالة.' });
    }

    // Insert view ignoring duplicates
    await pool.query(`
      INSERT INTO status_views (status_id, user_id)
      VALUES ($1, $2)
      ON CONFLICT (status_id, user_id) DO NOTHING
    `, [statusId, userId]);

    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Like a status
statusRouter.post('/:id/like', async (req: Request, res: Response) => {
  try {
    const userId = req.user!.userId;
    const statusId = req.params.id;

    // STATUS-01: likes are limited to users who can actually see the status.
    const status = await loadStatusRow(statusId);
    if (!status) {
      return res.status(404).json({ error: 'Status not found' });
    }
    if (!(await canViewStatus(db, userId, status))) {
      return res.status(403).json({ error: 'لا يمكنك الوصول إلى هذه الحالة.' });
    }

    await pool.query(`
      INSERT INTO status_likes (status_id, user_id)
      VALUES ($1, $2)
      ON CONFLICT (status_id, user_id) DO NOTHING
    `, [statusId, userId]);

    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Unlike a status
statusRouter.post('/:id/unlike', async (req: Request, res: Response) => {
  try {
    const userId = req.user!.userId;
    const statusId = req.params.id;

    // STATUS-01: same visibility gate as like (fail-closed symmetry).
    const status = await loadStatusRow(statusId);
    if (!status) {
      return res.status(404).json({ error: 'Status not found' });
    }
    if (!(await canViewStatus(db, userId, status))) {
      return res.status(403).json({ error: 'لا يمكنك الوصول إلى هذه الحالة.' });
    }

    await pool.query(`
      DELETE FROM status_likes
      WHERE status_id = $1 AND user_id = $2
    `, [statusId, userId]);

    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Get viewers for a status (only allowed for the status creator)
statusRouter.get('/:id/viewers', async (req: Request, res: Response) => {
  try {
    const userId = req.user!.userId;
    const statusId = req.params.id;

    // Check ownership of the status
    const statusCheck = await pool.query(`
      SELECT user_id FROM statuses WHERE id = $1
    `, [statusId]);

    if (statusCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Status not found' });
    }

    if (statusCheck.rows[0].user_id !== userId) {
      return res.status(403).json({ error: 'Unauthorized to view status viewers' });
    }

    // Get viewers details
    const viewersQuery = `
      SELECT sv.viewed_at, u.id, u.username, u.display_name, u.avatar_url
      FROM status_views sv
      JOIN users u ON sv.user_id = u.id
      WHERE sv.status_id = $1
      ORDER BY sv.viewed_at DESC
    `;

    const viewersResult = await pool.query(viewersQuery, [statusId]);
    res.json({ viewers: viewersResult.rows });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Comment on a status
statusRouter.post('/:id/comments', async (req: Request, res: Response) => {
  try {
    const userId = req.user!.userId;
    const statusId = req.params.id;
    const { text_content } = req.body;

    // BATCH-6 (B5-F2 — adversarial review): the validated value must be the
    // persisted value. Raw-length is rejected BEFORE trim (whitespace-padded
    // 5MB payloads no longer reach processing), and `comment` (the validated,
    // trimmed value) is what the INSERT binds.
    const validation = validateComment(text_content);
    if (!validation.ok) {
      const reason = validation.reason === 'too-long'
        ? { error: 'التعليق طويل جداً (الحد 500 حرف).' }
        : { error: 'Comment body cannot be empty' };
      return res.status(validation.reason === 'too-long' ? 413 : 400).json(reason);
    }
    const comment = validation.value;

    // STATUS-01: commenters must be able to see the status.
    const status = await loadStatusRow(statusId);
    if (!status) {
      return res.status(404).json({ error: 'Status not found' });
    }
    if (!(await canViewStatus(db, userId, status))) {
      return res.status(403).json({ error: 'لا يمكنك الوصول إلى هذه الحالة.' });
    }

    // STATUS-01: server-side enforcement of the per-status engagement
    // settings (comments/replies: 'open' | 'closed'). Unknown/missing
    // comments setting fails closed (must be 'open' to accept writes).
    let statusSettings: any = status.settings;
    if (typeof statusSettings === 'string') {
      try { statusSettings = JSON.parse(statusSettings); } catch (e) { statusSettings = null; }
    }
    if (statusSettings?.comments !== 'open') {
      return res.status(403).json({ error: 'التعليقات مغلقة على هذه الحالة.' });
    }

    // Replies ride the same route via parent_id — the reply gate applies
    // separately so a status can allow comments but close replies.
    let parentId: string | null = null;
    const rawParent = req.body?.parent_id ?? req.body?.parentId;
    if (typeof rawParent === 'string' && rawParent.length > 0) {
      if (statusSettings?.replies !== 'open') {
        return res.status(403).json({ error: 'الردود مغلقة على هذه الحالة.' });
      }
      const parentCheck = await pool.query(
        'SELECT id FROM status_comments WHERE id = $1 AND status_id = $2',
        [rawParent, statusId],
      );
      if (parentCheck.rows.length === 0) {
        return res.status(400).json({ error: 'التعليق الأصلي غير موجود.' });
      }
      parentId = rawParent;
    }

    const commentId = 'comment-' + crypto.randomUUID();

    const insertComment = `
      INSERT INTO status_comments (id, status_id, user_id, parent_id, content)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING *, content AS text_content
    `;

    const commentResult = await pool.query(insertComment, [commentId, statusId, userId, parentId, comment]);

    res.status(201).json({ comment: commentResult.rows[0] });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Get comments for a status
statusRouter.get('/:id/comments', async (req: Request, res: Response) => {
  try {
    const userId = req.user!.userId;
    const statusId = req.params.id;

    // STATUS-01: comments inherit the status visibility — a viewer excluded
    // by statusVisibility cannot read (or harvest) the comment thread either.
    const status = await loadStatusRow(statusId);
    if (!status) {
      return res.status(404).json({ error: 'Status not found' });
    }
    if (!(await canViewStatus(db, userId, status))) {
      return res.status(403).json({ error: 'لا يمكنك الوصول إلى هذه الحالة.' });
    }

    const commentsQuery = `
      SELECT sc.*, sc.content AS text_content, u.username, u.display_name, u.avatar_url
      FROM status_comments sc
      JOIN users u ON sc.user_id = u.id
      WHERE sc.status_id = $1
      ORDER BY sc.created_at ASC
    `;

    const commentsResult = await pool.query(commentsQuery, [statusId]);
    res.json({ comments: commentsResult.rows });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Delete status
statusRouter.delete('/:id', async (req: Request, res: Response) => {
  try {
    const userId = req.user!.userId;
    const statusId = req.params.id;

    // Check ownership
    const checkRes = await pool.query('SELECT user_id FROM statuses WHERE id = $1', [statusId]);
    if (checkRes.rows.length === 0) {
      return res.status(404).json({ error: 'Status not found' });
    }

    if (checkRes.rows[0].user_id !== userId) {
      return res.status(403).json({ error: 'Unauthorized to delete this status' });
    }

    // Delete all related child records first to ensure absolute cascading across all schema environments
    await pool.query('DELETE FROM status_comments WHERE status_id = $1', [statusId]);
    await pool.query('DELETE FROM status_likes WHERE status_id = $1', [statusId]);
    await pool.query('DELETE FROM status_views WHERE status_id = $1', [statusId]);

    // Perform cascaded delete (or soft delete)
    await pool.query('DELETE FROM statuses WHERE id = $1', [statusId]);

    res.json({ success: true, message: 'Status deleted successfully.' });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});
