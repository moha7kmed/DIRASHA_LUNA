/**
 * Dirasha E2EE group-module tests (Sender Keys, phase 2).
 *
 * Three members (Alice/Bob/Carol), each with its own GroupCrypto + MemoryKVStore,
 * exchange distribution payloads pairwise (as the integration layer will: send
 * distributionPayload() through the 1:1 engine, feed inbound ctrl into
 * processControl()).
 *
 * Covers: distribution/ctrl round-trip, full 3-member mesh, out-of-order
 * delivery (stateless chain), rotation invalidating old envelopes, tamper
 * rejection + state survival, needsDistribution semantics, deleteGroup cleanup,
 * namespace isolation, and never-throw decrypt contract.
 */
import { describe, it, expect } from 'vitest';

import {
  GroupCrypto,
  SELF,
  GROUP_WIRE_PREFIX,
  GROUP_CTRL_KIND,
  GROUP_AAD_TEMPLATE,
  deriveGroupMessageKey,
  groupAad,
  isCtrlPayload,
} from '../src/lib/e2ee/group.ts';
import { MemoryKVStore } from '../src/lib/e2ee/store.ts';
import { E2eeError } from '../src/lib/e2ee/types.ts';
import { b64encode, b64decode, utf8Encode, utf8Decode, aeadSeal, randomBytes } from '../src/lib/e2ee/crypto.ts';

const GROUP = 'group-1';

interface Member {
  id: string;
  groups: GroupCrypto;
  store: MemoryKVStore;
}

function makeMember(id: string, namespace?: string): Member {
  const store = new MemoryKVStore();
  return { id, groups: new GroupCrypto({ store, namespace }), store };
}

/** Pairwise ctrl exchange: everyone distributes their sender key to everyone. */
async function distributeAll(members: Member[], groupId = GROUP): Promise<void> {
  for (const sender of members) {
    await sender.groups.ensureSenderKey(groupId);
    const payload = await sender.groups.distributionPayload(groupId);
    for (const receiver of members) {
      if (receiver.id === sender.id) continue;
      const ok = await receiver.groups.processControl(sender.id, JSON.parse(payload));
      expect(ok).toBe(true);
    }
  }
}

describe('GroupCrypto — sender keys & distribution', () => {
  it('ensureSenderKey creates a record once and is idempotent', async () => {
    const alice = makeMember('alice');
    const first = await alice.groups.ensureSenderKey(GROUP);
    expect(Number.isInteger(first.keyId)).toBe(true);
    expect(first.epoch).toBe(1);

    const rec = await alice.groups.getSenderKey(GROUP);
    expect(rec).not.toBeNull();
    expect(rec!.keyId).toBe(first.keyId);
    expect(rec!.epoch).toBe(1);
    expect(rec!.n).toBe(0);
    expect(b64decode(rec!.chainKey).length).toBe(32);

    const second = await alice.groups.ensureSenderKey(GROUP);
    expect(second).toEqual(first); // same keyId/epoch — no re-create
  });

  it('distributionPayload throws E2eeError before ensureSenderKey', async () => {
    const alice = makeMember('alice');
    await expect(alice.groups.distributionPayload(GROUP)).rejects.toBeInstanceOf(E2eeError);
    await alice.groups.ensureSenderKey(GROUP);
    await expect(alice.groups.distributionPayload(GROUP)).resolves.toContain(GROUP_CTRL_KIND);
  });

  it('distributionPayload → processControl round-trip stores the member key', async () => {
    const alice = makeMember('alice');
    const bob = makeMember('bob');
    await alice.groups.ensureSenderKey(GROUP);
    const payload = await alice.groups.distributionPayload(GROUP);

    expect(await bob.groups.needsDistribution(GROUP, 'alice')).toBe(true);
    const ok = await bob.groups.processControl('alice', JSON.parse(payload));
    expect(ok).toBe(true);
    expect(await bob.groups.needsDistribution(GROUP, 'alice')).toBe(false);

    const aliceKey = await alice.groups.getSenderKey(GROUP);
    const memberRaw = await bob.store.get(`gmi:${GROUP}:alice`);
    expect(memberRaw).not.toBeNull();
    const member = JSON.parse(memberRaw!);
    expect(member.keyId).toBe(aliceKey!.keyId);
    expect(member.epoch).toBe(aliceKey!.epoch);
    expect(member.chainKey).toBe(aliceKey!.chainKey);
    expect(typeof member.receivedAt).toBe('number');
  });

  it('processControl returns false for unknown kinds and invalid payloads', async () => {
    const bob = makeMember('bob');
    expect(await bob.groups.processControl('alice', { kind: 'something-else', type: 'sender-key' })).toBe(false);
    expect(await bob.groups.processControl('alice', null)).toBe(false);
    expect(await bob.groups.processControl('alice', 'not-an-object')).toBe(false);

    // Kind matches but key is not 32 bytes.
    const bad = { kind: GROUP_CTRL_KIND, type: 'sender-key', groupId: GROUP, keyId: 1, epoch: 1, key: b64encode(randomBytes(16)), n: 0 }; // short key still rejected
    expect(await bob.groups.processControl('alice', bad)).toBe(false);

    // Non-integer / out-of-range ints.
    const badInts = { kind: GROUP_CTRL_KIND, type: 'sender-key', groupId: GROUP, keyId: 1.5, epoch: 1, key: b64encode(randomBytes(32)), n: 0 };
    expect(await bob.groups.processControl('alice', badInts)).toBe(false);

    // Nothing persisted.
    expect(await bob.groups.needsDistribution(GROUP, 'alice')).toBe(true);
  });

  it('isCtrlPayload is a working type guard', () => {
    const good = { kind: GROUP_CTRL_KIND, type: 'sender-key', groupId: GROUP, keyId: 5, epoch: 1, key: 'aaa', n: 0 }; // v2: n required
    expect(isCtrlPayload(good)).toBe(true);
    expect(isCtrlPayload({ ...good, kind: 'nope' })).toBe(false);
    expect(isCtrlPayload({ ...good, keyId: '5' })).toBe(false);
    expect(isCtrlPayload(undefined)).toBe(false);
  });
});

describe('GroupCrypto — group messaging', () => {
  it('three members exchange distribution payloads pairwise and decrypt each other', async () => {
    const alice = makeMember('alice');
    const bob = makeMember('bob');
    const carol = makeMember('carol');
    const members = [alice, bob, carol];
    await distributeAll(members);

    // Everyone needs nobody anymore.
    for (const m of members) {
      for (const peer of members) {
        if (peer.id === m.id) continue;
        expect(await m.groups.needsDistribution(GROUP, peer.id)).toBe(false);
      }
    }

    const cA = await alice.groups.encryptGroupMessage(GROUP, 'hello from alice', 'alice', 1);
    const cB = await bob.groups.encryptGroupMessage(GROUP, 'hello from bob', 'bob', 1);
    const cC = await carol.groups.encryptGroupMessage(GROUP, 'hello from carol', 'carol', 1);
    expect(cA.startsWith(GROUP_WIRE_PREFIX)).toBe(true);

    expect(await bob.groups.decryptGroupMessage(GROUP, 'alice', cA)).toEqual({ plaintext: 'hello from alice' });
    expect(await carol.groups.decryptGroupMessage(GROUP, 'alice', cA)).toEqual({ plaintext: 'hello from alice' });
    expect(await alice.groups.decryptGroupMessage(GROUP, 'bob', cB)).toEqual({ plaintext: 'hello from bob' });
    expect(await carol.groups.decryptGroupMessage(GROUP, 'bob', cB)).toEqual({ plaintext: 'hello from bob' });
    expect(await alice.groups.decryptGroupMessage(GROUP, 'carol', cC)).toEqual({ plaintext: 'hello from carol' });
    expect(await bob.groups.decryptGroupMessage(GROUP, 'carol', cC)).toEqual({ plaintext: 'hello from carol' });
  });

  it('encrypt advances the persisted chain counter (clone-and-save)', async () => {
    const alice = makeMember('alice');
    await alice.groups.ensureSenderKey(GROUP);
    await alice.groups.encryptGroupMessage(GROUP, 'one', 'alice', 1);
    await alice.groups.encryptGroupMessage(GROUP, 'two', 'alice', 1);
    const rec = await alice.groups.getSenderKey(GROUP);
    expect(rec!.n).toBe(2);
  });

  it('out-of-order delivery within a chain works (stateless derivation)', async () => {
    const alice = makeMember('alice');
    const bob = makeMember('bob');
    await distributeAll([alice, bob]);

    const c1 = await alice.groups.encryptGroupMessage(GROUP, 'm1', 'alice', 1);
    const c2 = await alice.groups.encryptGroupMessage(GROUP, 'm2', 'alice', 1);
    const c3 = await alice.groups.encryptGroupMessage(GROUP, 'm3', 'alice', 1);

    // Deliver 3, 1, 2 — receiver keeps no chain state, so order is irrelevant.
    expect(await bob.groups.decryptGroupMessage(GROUP, 'alice', c3)).toEqual({ plaintext: 'm3' });
    expect(await bob.groups.decryptGroupMessage(GROUP, 'alice', c1)).toEqual({ plaintext: 'm1' });
    expect(await bob.groups.decryptGroupMessage(GROUP, 'alice', c2)).toEqual({ plaintext: 'm2' });
  });

  it('rotation invalidates old envelopes; new ones decrypt after re-distribution', async () => {
    const alice = makeMember('alice');
    const bob = makeMember('bob');
    await distributeAll([alice, bob]);

    const oldContent = await alice.groups.encryptGroupMessage(GROUP, 'pre-rotation', 'alice', 1);

    const rotated = await alice.groups.rotateSenderKey(GROUP);
    expect(rotated.epoch).toBe(2);
    expect(Number.isInteger(rotated.keyId)).toBe(true);

    // Re-distribute the new key pairwise (integration does this automatically).
    const payload = await alice.groups.distributionPayload(GROUP);
    expect(await bob.groups.processControl('alice', JSON.parse(payload))).toBe(true);

    const newContent = await alice.groups.encryptGroupMessage(GROUP, 'post-rotation', 'alice', 1);

    // Old-epoch envelope must fail closed...
    const oldResult = await bob.groups.decryptGroupMessage(GROUP, 'alice', oldContent);
    expect(oldResult).toEqual({ error: 'DecryptFailedError' });
    // ...while the new one works.
    expect(await bob.groups.decryptGroupMessage(GROUP, 'alice', newContent)).toEqual({ plaintext: 'post-rotation' });

    // Counter was reset on rotation.
    const rec = await alice.groups.getSenderKey(GROUP);
    expect(rec!.epoch).toBe(2);
    expect(rec!.n).toBe(1);
  });

  it('tampered ciphertext/AAD returns {error} and does not break later messages', async () => {
    const alice = makeMember('alice');
    const bob = makeMember('bob');
    await distributeAll([alice, bob]);

    const valid = await alice.groups.encryptGroupMessage(GROUP, 'secret', 'alice', 1);

    // Tamper with the ciphertext (flip bits inside the b64 ct field).
    const env = JSON.parse(utf8Decode(b64decode(valid.slice(GROUP_WIRE_PREFIX.length))));
    const ct: string = env.ct;
    env.ct = (ct[0] === 'A' ? 'B' : 'A') + ct.slice(1);
    const tamperedCt = GROUP_WIRE_PREFIX + b64encode(utf8Encode(JSON.stringify(env)));
    expect(await bob.groups.decryptGroupMessage(GROUP, 'alice', tamperedCt)).toEqual({ error: 'TamperedError' });

    // Tamper with the AAD: mutate the envelope's `n` field (valid shape, but the
    // recomputed AAD `${v}|${groupId}|${skId}|${n}` no longer matches the seal).
    const aadEnv = JSON.parse(utf8Decode(b64decode(valid.slice(GROUP_WIRE_PREFIX.length))));
    aadEnv.n = aadEnv.n + 1;
    const tamperedAad = GROUP_WIRE_PREFIX + b64encode(utf8Encode(JSON.stringify(aadEnv)));
    expect(await bob.groups.decryptGroupMessage(GROUP, 'alice', tamperedAad)).toEqual({ error: 'TamperedError' });

    // Wrong groupId: no member key for that group → fails closed (no key material).
    expect(await bob.groups.decryptGroupMessage('other-group', 'alice', valid)).toEqual({ error: 'DecryptFailedError' });

    // Tamper structurally: garbage after the wire prefix / truncated payload.
    expect(await bob.groups.decryptGroupMessage(GROUP, 'alice', 'DIRG1:not-base64!!')).toEqual({ error: 'DecryptFailedError' });
    expect(await bob.groups.decryptGroupMessage(GROUP, 'alice', 'DIRG1:')).toEqual({ error: 'DecryptFailedError' });

    // Subsequent valid traffic still decrypts (no state was corrupted).
    expect(await bob.groups.decryptGroupMessage(GROUP, 'alice', valid)).toEqual({ plaintext: 'secret' });
    const next = await alice.groups.encryptGroupMessage(GROUP, 'still fine', 'alice', 1);
    expect(await bob.groups.decryptGroupMessage(GROUP, 'alice', next)).toEqual({ plaintext: 'still fine' });
  });

  it('decrypt never throws: missing member key / non-DIRG1 content → {error}', async () => {
    const alice = makeMember('alice');
    const bob = makeMember('bob');
    await alice.groups.ensureSenderKey(GROUP);

    // Bob has no member key for alice yet.
    const content = await alice.groups.encryptGroupMessage(GROUP, 'hi', 'alice', 1);
    expect(await bob.groups.decryptGroupMessage(GROUP, 'alice', content)).toEqual({ error: 'DecryptFailedError' });

    // Non-group content and unknown sender.
    expect(await bob.groups.decryptGroupMessage(GROUP, 'alice', 'plain text')).toEqual({ error: 'DecryptFailedError' });
    expect(await bob.groups.decryptGroupMessage(GROUP, 'mallory', content)).toEqual({ error: 'DecryptFailedError' });
  });

  it('senderId === SELF uses our own sender key (self path)', async () => {
    const alice = makeMember('alice');
    await alice.groups.ensureSenderKey(GROUP);
    const content = await alice.groups.encryptGroupMessage(GROUP, 'note to self', 'alice', 1);
    expect(await alice.groups.decryptGroupMessage(GROUP, SELF, content)).toEqual({ plaintext: 'note to self' });
  });

  it('AAD matches GROUP_AAD_TEMPLATE and the wire is DIRG1:b64(JSON)', async () => {
    // Single-source AAD sanity: substitution of the template equals groupAad().
    expect(groupAad(2, 'g1', 42, 7, 'alice', 3)).toBe(GROUP_AAD_TEMPLATE.replace('${v}', '2').replace('${groupId}', 'g1').replace('${skId}', '42').replace('${n}', '7').replace('${senderId}', 'alice').replace('${mv}', '3'));
    expect(groupAad(2, 'g1', 42, 7, 'alice', 3)).toBe('2|g1|42|7|alice|3');

    const alice = makeMember('alice');
    const bob = makeMember('bob');
    await distributeAll([alice, bob]);

    const content = await alice.groups.encryptGroupMessage(GROUP, 'wire check', 'alice', 1);
    expect(content.startsWith(GROUP_WIRE_PREFIX)).toBe(true);
    const env = JSON.parse(utf8Decode(b64decode(content.slice(GROUP_WIRE_PREFIX.length))));
    expect(env.v).toBe(2);
    expect(typeof env.skId).toBe('number');
    expect(typeof env.n).toBe('number');
    expect(b64decode(env.iv).length).toBe(12);

    // v2: the sender-side re-derivation check is replaced by the ratchet
    // proof tests (tests/group-ratchet.test.ts) — the real receive path proves
    // the chain derivation end-to-end.
    expect(await bob.groups.decryptGroupMessage(GROUP, 'alice', content)).toEqual({ plaintext: 'wire check' });
  });
});

describe('GroupCrypto — lifecycle & isolation', () => {
  it('needsDistribution semantics: true before ctrl, false after, true after delete', async () => {
    const alice = makeMember('alice');
    const bob = makeMember('bob');
    await alice.groups.ensureSenderKey(GROUP);
    expect(await bob.groups.needsDistribution(GROUP, 'alice')).toBe(true);
    const payload = await alice.groups.distributionPayload(GROUP);
    await bob.groups.processControl('alice', JSON.parse(payload));
    expect(await bob.groups.needsDistribution(GROUP, 'alice')).toBe(false);
    await bob.groups.deleteGroup(GROUP);
    expect(await bob.groups.needsDistribution(GROUP, 'alice')).toBe(true);
  });

  it('deleteGroup removes gsk and every gmi:<groupId>:* key, only those', async () => {
    const bob = makeMember('bob');
    const alice = makeMember('alice');
    const carol = makeMember('carol');
    await distributeAll([alice, bob, carol]);
    // Bob also holds keys for a second group.
    const other = 'group-2';
    await distributeAll([alice, bob], other);
    await bob.groups.encryptGroupMessage(other, 'keep me', 'bob', 1);

    expect((await bob.store.keys()).filter((k) => k.startsWith('gmi:group-1:')).length).toBe(2);
    expect(await bob.store.get(`gsk:${GROUP}`)).not.toBeNull();

    await bob.groups.deleteGroup(GROUP);

    expect(await bob.store.get(`gsk:${GROUP}`)).toBeNull();
    expect(await bob.store.get(`gmi:${GROUP}:alice`)).toBeNull();
    expect(await bob.store.get(`gmi:${GROUP}:carol`)).toBeNull();
    // Unrelated keys survive.
    expect(await bob.store.get(`gsk:${other}`)).not.toBeNull();
    expect(await bob.store.get(`gmi:${other}:alice`)).not.toBeNull();
    // needsDistribution flips back to true for the deleted group.
    expect(await bob.groups.needsDistribution(GROUP, 'alice')).toBe(true);
  });

  it('namespace option isolates accounts over the same underlying store', async () => {
    const shared = new MemoryKVStore();
    const acctA = new GroupCrypto({ store: shared, namespace: 'acct-a' });
    const acctB = new GroupCrypto({ store: shared, namespace: 'acct-b' });

    await acctA.ensureSenderKey(GROUP);
    const keyA = await acctA.getSenderKey(GROUP);
    // acctB sees nothing of acctA's group state.
    expect(await acctB.getSenderKey(GROUP)).toBeNull();

    // Cross-account distribution still works when explicitly wired (keys differ).
    const payloadB = await acctB.distributionPayload(GROUP).catch(() => null);
    expect(payloadB).toBeNull(); // acctB has no own key yet — throws as contract requires
    await acctB.ensureSenderKey(GROUP);
    const keyB = await acctB.getSenderKey(GROUP);
    expect(keyB!.chainKey).not.toBe(keyA!.chainKey);

    // Raw store keys carry the namespace prefix.
    const rawKeys = await shared.keys();
    expect(rawKeys).toContain(`acct-a:gsk:${GROUP}`);
    expect(rawKeys).toContain(`acct-b:gsk:${GROUP}`);
  });
});
