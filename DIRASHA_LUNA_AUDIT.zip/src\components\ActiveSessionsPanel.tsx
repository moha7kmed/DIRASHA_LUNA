/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * ActiveSessionsPanel — "الأجهزة والجلسات النشطة" (Devices & Active Sessions,
 * Signal/WhatsApp parity). Self-contained modal/panel: lists the account's
 * live sessions (device label + IP + last activity), marks the current device,
 * and lets the user remotely revoke a single session or every other device.
 *
 * Auth contract: by default credentials come from TokenVault (access token +
 * sessionId). A host app may pass `authHeaders` to supply its own headers
 * (e.g. when tokens live in React state only).
 *
 * Backed by:
 *   GET  /api/auth/sessions            → { sessions: [{sessionId, deviceLabel, ip, createdAt, lastActive, current}] }
 *   POST /api/auth/sessions/revoke     → { sessionId }  (rate limit 10/h)
 *   POST /api/auth/sessions/revoke-others              (rate limit 5/h)
 * Styling mirrors E2eeSafetyModal (fixed overlay + zinc-900 card, Arabic RTL).
 */

import React, { useState, useEffect, useCallback } from 'react';
import { X, Monitor, Loader2, RefreshCw, ShieldCheck, AlertCircle, LogOut, Check } from 'lucide-react';
import { authHeaders as defaultAuthHeaders, getSessionId } from '../lib/token_vault.ts';

interface ActiveSessionsPanelProps {
  open: boolean;
  onClose: () => void;
  /**
   * Optional override for credential headers. Defaults to TokenVault.authHeaders()
   * (Bearer access token). The panel additionally sends `x-session-id` so the
   * server can flag/protect the current device.
   */
  authHeaders?: () => Record<string, string>;
}

interface SessionRow {
  sessionId: string;
  deviceLabel: string;
  ip: string;
  createdAt: string | null;
  lastActive: string | null;
  current: boolean;
}

/** 'نشط الآن' when active within 2 minutes, otherwise Arabic relative time. */
function formatLastActive(iso: string | null): string {
  if (!iso) return 'آخر نشاط غير معروف';
  const t = new Date(iso).getTime();
  if (Number.isNaN(t)) return 'آخر نشاط غير معروف';
  const diff = Date.now() - t;
  if (diff < 2 * 60 * 1000) return 'نشط الآن';
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `آخر نشاط قبل ${mins} دقيقة`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `آخر نشاط قبل ${hours} ساعة`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `آخر نشاط قبل ${days} يوم`;
  return `آخر نشاط ${new Date(iso).toLocaleDateString('ar-EG')}`;
}

export function ActiveSessionsPanel({ open, onClose, authHeaders }: ActiveSessionsPanelProps) {
  const headersFn = authHeaders || defaultAuthHeaders;
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sessions, setSessions] = useState<SessionRow[]>([]);
  const [busyId, setBusyId] = useState<string | null>(null);      // row currently being revoked
  const [confirmRevokeId, setConfirmRevokeId] = useState<string | null>(null); // inline row confirm
  const [confirmBulk, setConfirmBulk] = useState(false);          // bulk confirm dialog
  const [bulkBusy, setBulkBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  const fetchSessions = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/auth/sessions', {
        headers: { ...headersFn(), 'x-session-id': getSessionId() || '' },
      });
      if (!res.ok) {
        if (res.status === 401) {
          setError('انتهت صلاحية الجلسة. أعد تسجيل الدخول ثم حاول مجدداً.');
        } else if (res.status === 429) {
          setError('طلبات كثيرة على قائمة الجلسات. انتظر قليلاً ثم أعد المحاولة.');
        } else {
          setError('تعذر جلب قائمة الجلسات النشطة. حاول مرة أخرى.');
        }
        return;
      }
      const data = await res.json();
      const list = Array.isArray(data?.sessions) ? data.sessions : [];
      const mapped: SessionRow[] = list.map((s: any) => ({
        sessionId: String(s.sessionId || s.id || ''),
        deviceLabel: String(s.deviceLabel || s.userAgent || 'جهاز غير معروف'),
        ip: String(s.ip || s.ipAddress || s.ip_address || ''),
        createdAt: s.createdAt || s.created_at || null,
        lastActive: s.lastActive || s.last_active || s.updatedAt || s.updated_at || s.createdAt || s.created_at || null,
        current: s.current === true || (getSessionId() ? s.id === getSessionId() : false),
      }));
      // Current device first, then most-recent activity.
      mapped.sort((a, b) => {
        if (a.current !== b.current) return a.current ? -1 : 1;
        const ta = a.lastActive ? new Date(a.lastActive).getTime() : 0;
        const tb = b.lastActive ? new Date(b.lastActive).getTime() : 0;
        return tb - ta;
      });
      setSessions(mapped);
    } catch {
      setError('تعذر الاتصال بالخادم. تحقق من اتصالك ثم أعد المحاولة.');
    } finally {
      setLoading(false);
    }
  }, [headersFn]);

  // Fetch on open + auto-refresh every 30s while open.
  useEffect(() => {
    if (!open) return;
    fetchSessions();
    const interval = window.setInterval(() => {
      fetchSessions();
    }, 30 * 1000);
    return () => window.clearInterval(interval);
  }, [open, fetchSessions]);

  // Reset transient state when closed.
  useEffect(() => {
    if (!open) {
      setSessions([]);
      setError(null);
      setNotice(null);
      setConfirmRevokeId(null);
      setConfirmBulk(false);
      setBusyId(null);
      setBulkBusy(false);
    }
  }, [open]);

  const revokeSession = useCallback(async (sessionId: string) => {
    setBusyId(sessionId);
    setError(null);
    setNotice(null);
    try {
      const res = await fetch('/api/auth/sessions/revoke', {
        method: 'POST',
        headers: { ...headersFn(), 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setError(data?.error || (res.status === 429
          ? 'عدد كبير من عمليات الإبطال. حاول بعد ساعة.'
          : 'تعذر إبطال الجلسة. حاول مرة أخرى.'));
        return;
      }
      setNotice('تم إبطال الجلسة وتسجيل الخروج من ذلك الجهاز.');
      await fetchSessions();
    } catch {
      setError('تعذر الاتصال بالخادم. تحقق من اتصالك ثم أعد المحاولة.');
    } finally {
      setBusyId(null);
      setConfirmRevokeId(null);
    }
  }, [headersFn, fetchSessions]);

  const revokeOthers = useCallback(async () => {
    setBulkBusy(true);
    setError(null);
    setNotice(null);
    try {
      const res = await fetch('/api/auth/sessions/revoke-others', {
        method: 'POST',
        headers: { ...headersFn(), 'x-session-id': getSessionId() || '' },
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setError(data?.error || (res.status === 429
          ? 'عدد كبير من عمليات الإبطال الجماعي. حاول بعد ساعة.'
          : 'تعذر إبطال الجلسات الأخرى. حاول مرة أخرى.'));
        return;
      }
      setNotice('تم تسجيل الخروج من جميع الأجهزة الأخرى.');
      await fetchSessions();
    } catch {
      setError('تعذر الاتصال بالخادم. تحقق من اتصالك ثم أعد المحاولة.');
    } finally {
      setBulkBusy(false);
      setConfirmBulk(false);
    }
  }, [headersFn, fetchSessions]);

  if (!open) return null;

  const otherCount = sessions.filter(s => !s.current).length;

  return (
    <div
      className="fixed inset-0 z-[2000] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md bg-zinc-900 border border-white/10 rounded-3xl overflow-hidden max-h-[85vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
        style={{ direction: 'rtl' }}
      >
        {/* Header — mirrors the existing modal pattern (icon + title + close) */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/5 shrink-0">
          <div className="flex items-center gap-2">
            <ShieldCheck size={18} className="text-emerald-400" />
            <h3 className="text-white font-bold text-sm">الأجهزة والجلسات النشطة</h3>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={fetchSessions}
              className="text-zinc-400 hover:text-white p-1"
              aria-label="تحديث القائمة"
              title="تحديث القائمة"
            >
              <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
            </button>
            <button onClick={onClose} className="text-zinc-400 hover:text-white p-1" aria-label="إغلاق">
              <X size={18} />
            </button>
          </div>
        </div>

        <div className="p-5 space-y-4 overflow-y-auto">
          <p className="text-[11px] text-zinc-500 leading-relaxed">
            هذه قائمة بكل الأجهزة المسجّل الدخول إلى حسابك حالياً. إذا رأيت جهازاً لا تعرفه،
            أبطِل جلسته فوراً ثم غيّر كلمة المرور.
          </p>

          {notice && (
            <div className="flex items-center gap-2 p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs">
              <Check size={16} className="shrink-0" />
              <span>{notice}</span>
            </div>
          )}

          {error && (
            <div className="flex items-start gap-2 p-3 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-300 text-xs leading-relaxed">
              <AlertCircle size={16} className="shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {loading && sessions.length === 0 && (
            <div className="flex items-center justify-center gap-2 py-6 text-zinc-400 text-sm select-none">
              <Loader2 size={18} className="animate-spin text-emerald-400" />
              <span>جارٍ جلب الجلسات النشطة...</span>
            </div>
          )}

          {!loading && !error && sessions.length === 0 && (
            <div className="py-6 text-center text-zinc-500 text-xs select-none">
              لا توجد جلسات نشطة.
            </div>
          )}

          <div className="space-y-2">
            {sessions.map((s) => {
              const isConfirming = confirmRevokeId === s.sessionId;
              const isBusy = busyId === s.sessionId;
              const activeNow = s.lastActive ? (Date.now() - new Date(s.lastActive).getTime()) < 2 * 60 * 1000 : false;
              return (
                <div
                  key={s.sessionId || s.deviceLabel}
                  className={`rounded-2xl border p-3 ${s.current ? 'border-emerald-500/30 bg-emerald-500/[0.06]' : 'border-white/10 bg-white/[0.03]'}`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2.5 min-w-0">
                      <div className={`mt-0.5 p-1.5 rounded-xl shrink-0 ${s.current ? 'bg-emerald-500/15 text-emerald-400' : 'bg-white/5 text-zinc-400'}`}>
                        <Monitor size={16} />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center flex-wrap gap-1.5">
                          <span className="text-[13px] font-bold text-white/90 truncate">{s.deviceLabel}</span>
                          {s.current && (
                            <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30 select-none">
                              هذا الجهاز
                            </span>
                          )}
                        </div>
                        <div className="mt-0.5 flex items-center flex-wrap gap-x-2 text-[11px] text-zinc-500">
                          <span className={activeNow ? 'text-emerald-400 font-bold' : ''}>
                            {formatLastActive(s.lastActive)}
                          </span>
                          {s.ip && (
                            <span dir="ltr" className="font-mono text-zinc-600">IP: {s.ip}</span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Revoke control: inline confirm, disabled for the current device */}
                    {!s.current && (
                      <div className="shrink-0">
                        {!isConfirming ? (
                          <button
                            onClick={() => setConfirmRevokeId(s.sessionId)}
                            disabled={isBusy}
                            className="px-3 py-1.5 rounded-xl bg-red-500/10 border border-red-500/20 text-red-300 text-[11px] font-bold hover:bg-red-500/20 transition-colors cursor-pointer disabled:opacity-40 flex items-center gap-1"
                            aria-label="إبطال الجلسة"
                          >
                            <LogOut size={12} />
                            إبطال
                          </button>
                        ) : (
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => revokeSession(s.sessionId)}
                              disabled={isBusy}
                              className="px-2.5 py-1.5 rounded-xl bg-red-500 text-white text-[11px] font-black hover:bg-red-400 transition-colors cursor-pointer disabled:opacity-40 flex items-center gap-1"
                            >
                              {isBusy ? <Loader2 size={12} className="animate-spin" /> : <Check size={12} />}
                              تأكيد
                            </button>
                            <button
                              onClick={() => setConfirmRevokeId(null)}
                              disabled={isBusy}
                              className="px-2 py-1.5 rounded-xl bg-white/5 border border-white/10 text-zinc-300 text-[11px] hover:bg-white/10 transition-colors cursor-pointer"
                            >
                              إلغاء
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Bulk revoke — hidden when there is nothing else to revoke */}
          {otherCount > 0 && (
            <div className="pt-1">
              {!confirmBulk ? (
                <button
                  onClick={() => setConfirmBulk(true)}
                  disabled={bulkBusy}
                  className="w-full py-2.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-300 font-bold text-xs flex items-center justify-center gap-2 hover:bg-amber-500/20 transition-colors cursor-pointer disabled:opacity-40"
                >
                  <LogOut size={14} />
                  إبطال كل الأجهزة الأخرى ({otherCount})
                </button>
              ) : (
                <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 space-y-2.5">
                  <p className="text-amber-200 text-xs leading-relaxed">
                    هل أنت متأكد؟ سيتم تسجيل الخروج من {otherCount} {otherCount === 1 ? 'جهاز آخر' : 'أجهزة أخرى'} فوراً،
                    وستحتاج لتسجيل الدخول مرة أخرى عليها.
                  </p>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={revokeOthers}
                      disabled={bulkBusy}
                      className="flex-1 py-2 rounded-xl bg-amber-500 text-black font-black text-xs flex items-center justify-center gap-1.5 hover:bg-amber-400 transition-colors cursor-pointer disabled:opacity-40"
                    >
                      {bulkBusy ? <Loader2 size={14} className="animate-spin" /> : <LogOut size={14} />}
                      نعم، إبطال الكل
                    </button>
                    <button
                      onClick={() => setConfirmBulk(false)}
                      disabled={bulkBusy}
                      className="px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-zinc-300 font-bold text-xs hover:bg-white/10 transition-colors cursor-pointer"
                    >
                      إلغاء
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="flex items-center gap-1.5 text-[10.5px] text-zinc-500 select-none pt-1">
            <ShieldCheck size={11} className="text-emerald-500/80 shrink-0" />
            <span>
              يتم تحديث القائمة تلقائياً كل 30 ثانية ما دامت النافذة مفتوحة. الأجهزة المبطّلة
              تفشل في تجديد جلستها وتُسجَّل خروجاً تلقائياً.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ActiveSessionsPanel;
