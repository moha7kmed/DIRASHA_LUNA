/**
 * External Media Storage Routes (BYO-Cloud + Managed Fallback)
 * -------------------------------------------------------------
 *   GET    /api/storage/status   → is the caller linked? is fallback active?
 *   POST   /api/storage/link     → attach the caller's own S3-compatible bucket
 *   DELETE /api/storage/link     → detach (falls back to managed bucket)
 *   POST   /api/storage/presign  → { fileName, mimeType, sizeBytes } → direct-upload URL
 *
 * Server only ever signs URLs and stores metadata — media bytes flow
 * client ⇄ object-storage directly, so our bandwidth cost stays ~zero.
 */

import type { Express, Request, Response, NextFunction } from 'express';
import { db , pool } from '../database.ts';
import { decideProxyHeaders } from '../guards/proxyHeaders.ts';
import {
  S3Config, STORAGE_RULES, validateUploadRequest, encryptCredentials,
  decryptCredentials, getFallbackS3Config, buildObjectKey, buildPublicUrl,
  buildPresignedPutUrl,
} from '../services/storage.ts';
import {
  isGdriveConfigured, GDRIVE_NOT_CONFIGURED, buildAuthUrl, consumeState,
  exchangeCode, refreshAccessToken, buildGdriveCredentials, ensureFolder,
  invalidateGdriveCaches, getDriveEmailHint, requestAccessTokenForRefreshToken,
  fetchWithTimeout } from '../services/gdrive.ts';
import { AuthService } from '../services/auth.ts';
import { logger } from '../logger.ts';
import type { RateLimitRuleName } from '../services/rate_limiter.ts';

interface StorageRouteDeps {
  requireAuth: (req: Request, res: Response, next: NextFunction) => void;
  /** Project 5: table-driven distributed limiter — true = rate limited (deny). */
  checkLimit: (rule: RateLimitRuleName, key: string) => Promise<boolean>;
}

// Presign issuance rate limit — prevents storage-abuse even on BYO buckets.
// Values now live in the central RATE_LIMIT_RULES table ('storage:presign').

// Google Drive upload-ticket rate limit — 30 per 10 minutes per user.
// Values now live in the central RATE_LIMIT_RULES table ('storage:gdrive-ticket').

const SUPPORTED_PROVIDERS = new Set(['r2', 'b2', 's3', 'minio', 'other']);

function isHttpsUrl(value: unknown): value is string {
  return typeof value === 'string' && /^https:\/\/[^\s/$.?#].[^\s]*$/i.test(value);
}

/** Proxy-aware request origin (same logic family as the attachment allowlist). */
function getReqOrigin(req: Request): string {
  const fwdProto = req.headers['x-forwarded-proto'];
  const proto = (typeof fwdProto === 'string' ? fwdProto.split(',')[0]?.trim() : undefined) || 'https';
  const fwdHost = req.headers['x-forwarded-host'];
  const host = (typeof fwdHost === 'string' ? fwdHost.split(',')[0]?.trim() : undefined)
    || (typeof req.headers.host === 'string' ? req.headers.host : '')
    || '';
  return host ? proto + '://' + host : '';
}

let activePgPoolQueryAttachmentSender: ((fileId: string) => Promise<{ senderId: string } | null>) | null = null;
/** Wired by bootstrap: resolves the sender of an attachment by Drive fileId. */
export function setGdriveAttachmentSenderResolver(fn: (fileId: string) => Promise<{ senderId: string } | null>): void {
  activePgPoolQueryAttachmentSender = fn;
}

/**
 * MEDIA-01 (external audit): fail-closed membership decision for the media
 * proxy — a requester may stream a file only while they are a CURRENT member
 * of the chat that shared it. Possession of the fileId alone is NOT
 * authorization. Kept pure and unexported (route-internal); exercised
 * behaviorally through the registered routes in tests/media-auth.test.ts.
 */
function isCurrentChatMember(
  members: Array<{ userId?: string | null }> | null | undefined,
  requesterId: string | null | undefined,
): boolean {
  if (!requesterId || !Array.isArray(members) || members.length === 0) return false;
  return members.some((m) => !!m && m.userId === requesterId);
}

/**
 * Resolve the sender + owning chat of a Drive attachment by fileId (media
 * proxy). The LIKE lookup stays for now (no exact-match-by-url helper exists
 * in database.ts — a dedicated indexed file_id column is a DB follow-up);
 * m.chat_id rides along so the route can enforce CURRENT chat membership
 * before streaming anything.
 */
async function resolveGdriveAttachmentSenderWired(fileId: string): Promise<{ senderId: string; chatId: string | null } | null> {
  const res = await pool.query(
    'SELECT m.sender_id AS sender_id, m.chat_id AS chat_id FROM attachments a JOIN messages m ON m.id = a.message_id WHERE a.url LIKE $1 LIMIT 1',
    ['%' + fileId + '%'],
  );
  const row = res.rows[0];
  if (!row?.sender_id) return null;
  return {
    senderId: row.sender_id,
    chatId: typeof row.chat_id === 'string' && row.chat_id ? row.chat_id : null,
  };
}

export function registerStorageRoutes(app: Express, deps: StorageRouteDeps): void {
  const { requireAuth, checkLimit } = deps;

  /* ------- Resolve which bucket this user's upload should target ------- */
  async function resolveTarget(userId: string): Promise<
    | { source: 'linked' | 'fallback'; config: S3Config }
    | { source: 'none'; config: null }
  > {
    const linked = await db.getUserStorage(userId);
    if (linked && linked.isActive && linked.provider !== 'gdrive') {
      // Google Drive rows are handled by the dedicated gdrive upload flow,
      // never by the S3 presigner.
      try {
        const creds = decryptCredentials(linked.credentialsEncrypted);
        return {
          source: 'linked',
          config: {
            endpoint: linked.endpoint,
            region: linked.region,
            bucket: linked.bucket,
            accessKeyId: creds.accessKeyId,
            secretAccessKey: creds.secretAccessKey,
            publicBaseUrl: linked.publicBaseUrl,
            forcePathStyle: linked.forcePathStyle,
          },
        };
      } catch (e: any) {
        logger.error(`[Storage] Failed to decrypt linked storage for user ${userId}:`, e?.message);
        // fall through to fallback bucket
      }
    }
    const fallback = getFallbackS3Config();
    if (fallback) return { source: 'fallback', config: fallback };
    return { source: 'none', config: null };
  }

  /* ===================== STATUS ===================== */
  app.get('/api/storage/status', requireAuth, async (req: Request, res: Response) => {
    try {
      const linked = await db.getUserStorage(req.user!.userId);
      const fallback = getFallbackS3Config();
      res.status(200).json({
        linked: !!(linked && linked.isActive),
        provider: linked?.provider || null,
        bucket: linked?.bucket || null,
        publicBaseUrl: linked?.publicBaseUrl || null,
        fallbackActive: !!fallback,
        // Google Drive layer ("movie-site streaming pattern") — the client
        // dispatcher (uploadMediaFile) picks the Drive path when this is true.
        gdrive: !!(linked && linked.isActive && linked.provider === 'gdrive'),
        gdriveSupported: isGdriveConfigured(),
        supportedProviders: Array.from(SUPPORTED_PROVIDERS),
        caps: {
          fallback: STORAGE_RULES.FALLBACK_MAX_BYTES,
          linked: STORAGE_RULES.LINKED_MAX_BYTES,
        },
      });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  /* ===================== LINK (BYO bucket) ===================== */
  app.post('/api/storage/link', requireAuth, async (req: Request, res: Response) => {
    try {
      const {
        provider, endpoint, region, bucket,
        accessKeyId, secretAccessKey, publicBaseUrl, forcePathStyle,
      } = req.body || {};

      if (!SUPPORTED_PROVIDERS.has(String(provider || '').toLowerCase())) {
        return res.status(400).json({ error: 'مزوّد التخزين غير مدعوم. المدعوم: Cloudflare R2، Backblaze B2، AWS S3، MinIO.' });
      }
      if (!isHttpsUrl(endpoint) || !isHttpsUrl(publicBaseUrl)) {
        return res.status(400).json({ error: 'روابط النقطة الطرفية والرابط العام يجب أن تبدأ بـ https://' });
      }
      if (typeof bucket !== 'string' || !/^[a-z0-9][a-z0-9.\-]{1,62}[a-z0-9]$/.test(bucket)) {
        return res.status(400).json({ error: 'اسم الحاوية (Bucket) غير صالح.' });
      }
      if (typeof accessKeyId !== 'string' || accessKeyId.length < 8 || accessKeyId.length > 256) {
        return res.status(400).json({ error: 'مفتاح الوصول (Access Key) غير صالح.' });
      }
      if (typeof secretAccessKey !== 'string' || secretAccessKey.length < 16 || secretAccessKey.length > 512) {
        return res.status(400).json({ error: 'المفتاح السري (Secret Key) غير صالح.' });
      }

      // Verify the credentials ACTUALLY work by signing a test PUT URL and
      // issuing a zero-byte probe is intentionally skipped (some providers
      // reject empty PUTs). Instead we do a cheap signed HEAD on the bucket
      // via presigned URL semantics — if signing params are malformed the
      // bucket will reject the first real upload and the user can re-link.

      await db.upsertUserStorage(req.user!.userId, {
        provider: String(provider).toLowerCase(),
        endpoint: endpoint.replace(/\/+$/, ''),
        region: typeof region === 'string' && region.trim() ? region.trim() : 'auto',
        bucket: bucket.trim(),
        publicBaseUrl: publicBaseUrl.replace(/\/+$/, ''),
        forcePathStyle: forcePathStyle === true,
        credentialsEncrypted: encryptCredentials({ accessKeyId, secretAccessKey }),
      });

      await db.logAuthAction(req.user!.userId, 'storage_linked', { provider: String(provider).toLowerCase(), bucket });
      logger.info(`[Storage] User ${req.user!.userId} linked ${provider} bucket "${bucket}"`);

      res.status(200).json({
        ok: true,
        linked: true,
        provider: String(provider).toLowerCase(),
        bucket,
        // Feature-by-design: any HTTPS publicBaseUrl is accepted, so remind the
        // user that media from their linked domain is delivered as-is to recipients.
        warning: 'الوسائط من نطاقك المرتبط تُحمَّل مباشرة لدى المستلمين — استخدم نطاقاً تثق به.',
      });
    } catch (err: any) {
      logger.error('[Storage] link failed:', err?.message);
      res.status(500).json({ error: 'تعذر ربط التخزين السحابي. تحقق من البيانات وحاول مجدداً.' });
    }
  });

  /* ===================== UNLINK ===================== */
  app.delete('/api/storage/link', requireAuth, async (req: Request, res: Response) => {
    try {
      await db.deleteUserStorage(req.user!.userId);
      await db.logAuthAction(req.user!.userId, 'storage_unlinked', {});
      res.status(200).json({ ok: true, linked: false });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });


  /* ===================== PRESIGN (direct client → bucket upload) ===================== */
  app.post('/api/storage/presign', requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.userId;
      const { fileName, mimeType, sizeBytes } = req.body || {};

      // Muted users cannot upload (weaponized-media guard)
      const uDB = await db.getUserById(userId);
      if (uDB?.mutedUntil && new Date(uDB.mutedUntil) > new Date()) {
        return res.status(403).json({ error: 'حسابك مقيّد حالياً من رفع الملفات.' });
      }

      if (await checkLimit('storage:presign', userId)) {
        return res.status(429).json({ error: 'تجاوزت حد الرفع المسموح هذه الساعة. حاول لاحقاً.' });
      }

      // Reject unsupported MIME types BEFORE storage resolution (clearer errors)
      const mimeCheck = String(mimeType || '').toLowerCase();
      if (!STORAGE_RULES.ALLOWED_MIME.has(mimeCheck)) {
        return res.status(400).json({ error: `نوع الملف غير مسموح (${mimeCheck || 'غير معروف'}). المسموح: صور، صوت، فيديو، PDF، نص.` });
      }

      const target = await resolveTarget(userId);
      if (target.source === 'none') {
        return res.status(503).json({
          error: 'STORAGE_NOT_CONFIGURED',
          message: 'لا يوجد تخزين متاح. اربط تخزينك السحابي الخاص من الإعدادات أولاً.',
        });
      }

      const check = validateUploadRequest(String(mimeType || ''), Number(sizeBytes), target.source === 'linked');
      if (!check.ok) {
        return res.status(400).json({ error: check.error });
      }

      const key = buildObjectKey(userId, String(mimeType));
      const uploadUrl = buildPresignedPutUrl(target.config, key, String(mimeType).toLowerCase());
      const publicUrl = buildPublicUrl(target.config, key);

      res.status(200).json({
        uploadUrl,
        publicUrl,
        key,
        source: target.source,               // 'linked' | 'fallback' — UI can badge it
        expiresInSec: STORAGE_RULES.PRESIGN_TTL_SEC,
        requiredHeaders: { 'Content-Type': String(mimeType).toLowerCase() },
      });
    } catch (err: any) {
      logger.error('[Storage] presign failed:', err?.message);
      res.status(500).json({ error: 'تعذر تجهيز رابط الرفع. حاول مرة أخرى.' });
    }
  });

  /* =====================================================================
     GOOGLE DRIVE per-user storage (drive.file scope, direct browser upload)
     ===================================================================== */

  /* ---------- Start OAuth consent (302 → accounts.google.com) ---------- */
  app.post('/api/storage/gdrive/start', requireAuth, (req: Request, res: Response) => {
    if (!isGdriveConfigured()) {
      return res.status(503).json(GDRIVE_NOT_CONFIGURED);
    }
    const origin = getReqOrigin(req);
    if (!origin) {
      return res.status(400).json({ error: 'تعذر تحديد عنوان التطبيق لإتمام الربط.' });
    }
    res.status(200).json({ consentUrl: buildAuthUrl(req.user!.userId, origin) });
  });

  app.get('/api/storage/gdrive/start', requireAuth, (req: Request, res: Response) => {
    if (!isGdriveConfigured()) {
      return res.status(503).json(GDRIVE_NOT_CONFIGURED);
    }
    const origin = getReqOrigin(req);
    if (!origin) {
      return res.status(400).json({ error: 'تعذر تحديد عنوان التطبيق لإتمام الربط.' });
    }
    res.redirect(302, buildAuthUrl(req.user!.userId, origin));
  });

  /* ---------- OAuth callback (no auth — state token binds the user) ---------- */
  app.get('/api/storage/gdrive/callback', async (req: Request, res: Response) => {
    const { code, state, error: oauthError } = req.query as Record<string, string>;
    const stateEntry = typeof state === 'string' ? consumeState(state) : null;
    const origin = stateEntry?.origin || getReqOrigin(req) || '/';

    const bail = (reason: string) => {
      logger.warn(`[GDrive] callback aborted: ${reason}`);
      res.redirect(302, `${origin}/?storage=error`);
    };

    if (oauthError) return bail(`oauth error: ${oauthError}`);
    if (!stateEntry) return bail('invalid or expired state');
    if (!isGdriveConfigured()) return bail('gdrive not configured');
    if (typeof code !== 'string' || !code) return bail('missing code');

    try {
      const tokens = await exchangeCode(code, `${stateEntry.origin}/api/storage/gdrive/callback`);
      const accessToken = await requestAccessTokenForRefreshToken(tokens.refreshToken);
      const folderId = await ensureFolder(stateEntry.userId, accessToken);

      await db.upsertUserStorage(stateEntry.userId, {
        provider: 'gdrive',
        endpoint: 'https://www.googleapis.com',
        region: 'gdrive',
        bucket: 'gdrive',
        publicBaseUrl: '', // Drive serves media via drive.usercontent.google.com
        forcePathStyle: false,
        credentialsEncrypted: buildGdriveCredentials(tokens.refreshToken),
      });
      await db.logAuthAction(stateEntry.userId, 'storage_linked', { provider: 'gdrive', bucket: folderId });
      logger.info(`[GDrive] User ${stateEntry.userId} linked Google Drive (folder ${folderId})`);

      res.redirect(302, `${stateEntry.origin}/?storage=linked`);
    } catch (err: any) {
      logger.error('[GDrive] callback failed:', err?.message);
      res.redirect(302, `${stateEntry.origin}/?storage=error`);
    }
  });

  /* ---------- Linked status (cheap, optional email hint) ---------- */
  app.get('/api/storage/gdrive/status', requireAuth, async (req: Request, res: Response) => {
    try {
      if (!isGdriveConfigured()) {
        return res.status(200).json({ linked: false, provider: null, gdriveSupported: false });
      }
      const linked = await db.getUserStorage(req.user!.userId);
      if (!linked || !linked.isActive || linked.provider !== 'gdrive') {
        return res.status(200).json({ linked: false, provider: null, gdriveSupported: true });
      }
      let emailHint: string | null = null;
      try {
        const accessToken = await refreshAccessToken(req.user!.userId, linked.credentialsEncrypted);
        emailHint = await getDriveEmailHint(req.user!.userId, accessToken);
      } catch (e: any) {
        // Token revoked/expired-refresh — report the link but without the hint.
        logger.warn(`[GDrive] status token check failed for ${req.user!.userId}: ${e?.message}`);
      }
      res.status(200).json({ linked: true, provider: 'gdrive', gdriveSupported: true, emailHint });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });

  /* ---------- Upload ticket: { accessToken, folderId } for direct browser upload ---------- */
  /* ── Media proxy: same-origin Drive streaming (owner-token, Range-aware) ──
   * The recipient's browser never touches Google: we stream the file with
   * the SENDER's stored token (files stay PRIVATE on Drive — stronger
   * privacy than public sharing) and pass Range through for <video> seek.
   * Auth (MEDIA-01): requireAuth on both routes — Bearer header, or a
   * short-lived media token via ?access_token= for <img>/<video> tags that
   * cannot send headers — PLUS a current chat-membership check below.
   */
  const gdriveMediaHandler = async (req: Request, res: Response) => {
    try {
      const fileId = String(req.query.id || '');
      if (!/^[A-Za-z0-9_-]{10,}$/.test(fileId)) {
        return res.status(400).json({ error: 'معرّف ملف غير صالح.' });
      }
      // DIR-NEW-10 (external audit): per-file token binding. The token payload
      // reaches this handler as req.user (requireAuth stores the decoded JWT
      // there). When the presented media token carries a resourceId claim it
      // is valid for THAT file only — a bound token replayed against another
      // fileId fails closed with 403. Tokens WITHOUT the claim still pass
      // here; their boundary is the current-chat-membership check below.
      const boundResourceId = (req.user as { resourceId?: string } | undefined)?.resourceId;
      if (boundResourceId && boundResourceId !== fileId) {
        return res.status(403).json({ error: 'غير مصرح لك بالوصول إلى هذا الملف.' });
      }
      // MEDIA-01 (external audit): the capability-URL model is retired.
      // requireAuth has already authenticated the caller; here we verify the
      // caller is STILL a current member of the chat that shared the file —
      // removed members / leaked links fail closed with 403. The check is
      // uniform for every mime type (ciphertext enc.bin included: the bytes
      // may be unreadable to outsiders, the metadata is not).
      const att = await resolveGdriveAttachmentSenderWired(fileId);
      if (!att) return res.status(404).json({ error: 'الملف غير موجود.' });
      let members: Array<{ userId?: string | null }> | null = null;
      try {
        members = att.chatId ? await db.getChatMembers(att.chatId) : null;
      } catch (e: any) {
        logger.warn(`[GDrive] media membership lookup failed for ${fileId}: ${e?.message?.slice(0, 120)}`);
        members = null; // DB failure → fail closed
      }
      if (!isCurrentChatMember(members, req.user?.userId)) {
        return res.status(403).json({ error: 'غير مصرح لك بالوصول إلى هذا الملف.' });
      }
      const senderRow = await db.getUserStorage(att.senderId);
      if (!senderRow || !senderRow.isActive || senderRow.provider !== 'gdrive') {
        return res.status(404).json({ error: 'الملف غير متاح.' });
      }
      const senderCredentials = senderRow.credentialsEncrypted;
      const senderId = att.senderId;
      const token = await refreshAccessToken(senderId, senderCredentials);
      const range = req.headers.range;
      const upstream = await fetchWithTimeout(
        'https://www.googleapis.com/drive/v3/files/' + fileId + '?alt=media',
        {
          headers: {
            Authorization: 'Bearer ' + token,
            ...(range ? { Range: range } : {}),
          },
        },
        30000,
      );
      if (!upstream.ok && upstream.status !== 206) {
        logger.warn(`[GDrive] media proxy upstream ${upstream.status} for ${fileId}`);
        return res.status(upstream.status).json({ error: 'تعذر جلب الملف من Google Drive.' });
      }
      const upstreamCt = upstream.headers.get('content-type');
      // BATCH-6 (B5-F1 — adversarial review): the inline decision is now a
      // pure, tested guard with an EXACT allowlist — no wildcard image|audio|
      // video families, so image/svg+xml (uploadable directly to the sender's
      // linked Drive, bypassing the app's upload MIME gate) can never be
      // served inline on the app origin.
      const proxyDecision = decideProxyHeaders(upstreamCt);
      const headers: Record<string, string> = {
        'Content-Type': proxyDecision.contentType,
        'X-Content-Type-Options': 'nosniff',
        'Content-Disposition': proxyDecision.contentDisposition,
      };
      const len = upstream.headers.get('content-length');
      if (len) headers['Content-Length'] = len;
      const cr = upstream.headers.get('content-range');
      if (cr) headers['Content-Range'] = cr;
      headers['Accept-Ranges'] = 'bytes';
      // MEDIA-01: authenticated media must not be cache-retained — the old
      // 24h private max-age kept private media in shared caches/proxies.
      headers['Cache-Control'] = 'private, no-store';
      res.status(upstream.status);
      for (const [k, v] of Object.entries(headers)) res.setHeader(k, v);
      const nodeStream = (await import('stream')).Readable.fromWeb(upstream.body as any);
      nodeStream.pipe(res);
    } catch (err: any) {
      logger.warn(`[GDrive] media proxy error: ${err?.message?.slice(0, 120)}`);
      if (!res.headersSent) res.status(502).json({ error: 'تعذر جلب الوسائط.' });
    }
  };

  // MEDIA-01: both media routes sit behind requireAuth — Bearer header, or a
  // short-lived media token via ?access_token= (media tags cannot send headers).
  app.get('/api/media/gdrive', requireAuth, (req: Request, res: Response) => gdriveMediaHandler(req, res));
  app.get('/api/media/gdrive/:fileId', requireAuth, (req: Request, res: Response) => {
    req.query.id = req.params.fileId;
    return gdriveMediaHandler(req, res);
  });
  // DIR-NEW-10 (external audit): the POST /api/storage/gdrive/share route was
  // REMOVED. It called shareFileToAnyone() (Drive permission type 'anyone',
  // role 'reader'), making files PUBLIC — a public-link capability that
  // contradicts the private-media model of the proxy above (files stay
  // private on Drive; every access is re-authenticated and membership-checked
  // per request). No frontend caller existed. The now-unreachable gdrive.ts
  // helper remains untouched (not owned by this change).

  app.post('/api/storage/gdrive/upload-ticket', requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.userId;

      // Muted users cannot upload (same weaponized-media guard as presign).
      const uDB = await db.getUserById(userId);
      if (uDB?.mutedUntil && new Date(uDB.mutedUntil) > new Date()) {
        return res.status(403).json({ error: 'حسابك مقيّد حالياً من رفع الملفات.' });
      }

      if (await checkLimit('storage:gdrive-ticket', userId)) {
        return res.status(429).json({ error: 'تجاوزت حد عمليات الرفع المسموحة. حاول بعد قليل.' });
      }

      if (!isGdriveConfigured()) {
        return res.status(503).json(GDRIVE_NOT_CONFIGURED);
      }

      const linked = await db.getUserStorage(userId);
      if (!linked || !linked.isActive || linked.provider !== 'gdrive') {
        return res.status(403).json({
          error: 'STORAGE_NOT_LINKED',
          message: 'اربط مساحتك المجانية بحساب Google أولاً لإرسال الوسائط.',
        });
      }

      // Guardrails: same MIME whitelist and size caps as the presign path
      // (linked-tier caps apply — it's the user's own 15GB).
      const { mimeType, sizeBytes } = req.body || {};
      const check = validateUploadRequest(String(mimeType || ''), Number(sizeBytes) || 0, true);
      if (!check.ok) {
        return res.status(400).json({ error: check.error });
      }

      let accessToken: string;
      try {
        accessToken = await refreshAccessToken(userId, linked.credentialsEncrypted);
      } catch (e: any) {
        if (String(e?.message) === 'GDRIVE_TOKEN_REVOKED') {
          return res.status(401).json({
            error: 'GDRIVE_LINK_BROKEN',
            message: 'انقطع ربط حساب Google — أعد الربط من الإعدادات.',
          });
        }
        throw e;
      }
      const folderId = await ensureFolder(userId, accessToken);

      res.status(200).json({ accessToken, expiresInSec: 3600, folderId });
    } catch (err: any) {
      logger.error('[GDrive] upload-ticket failed:', err?.message);
      res.status(500).json({ error: 'تعذر تجهيز رفع الملف إلى Google Drive. حاول مرة أخرى.' });
    }
  });

  /* ---------- Unlink Google Drive ---------- */
  app.delete('/api/storage/gdrive', requireAuth, async (req: Request, res: Response) => {
    try {
      await db.deleteUserStorage(req.user!.userId);
      invalidateGdriveCaches(req.user!.userId);
      await db.logAuthAction(req.user!.userId, 'storage_unlinked', { provider: 'gdrive' });
      res.status(200).json({ ok: true, linked: false });
    } catch (err: any) {
      console.error('[Server] Unhandled route error:', err);
      res.status(500).json({ error: 'حدث خطأ في الخادم. حاول مرة أخرى.' });
    }
  });
}

