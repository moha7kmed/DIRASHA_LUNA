/**
 * Passkeys (WebAuthn) client — Project 9.
 *
 * Passkeys protect LOGIN only. They do NOT encrypt chats and do NOT restore
 * E2EE keys: the end-to-end encryption keys live exclusively in this device's
 * IndexedDB vault (src/lib/e2ee/**) and a passkey login cannot export them.
 * Passwords remain a full, unaffected login path.
 */

import { startRegistration, startAuthentication } from '@simplewebauthn/browser';
import type { RegistrationResponseJSON, AuthenticationResponseJSON } from '@simplewebauthn/browser';
import { getAccessToken } from './token_vault';

export interface PasskeyCredentialInfo {
  id: number;
  credentialId: string;
  device: string;
  transports: string[];
  createdAt: string;
  lastUsedAt: string | null;
}

function authHeaders(): Record<string, string> {
  const t = getAccessToken();
  const h: Record<string, string> = { 'Content-Type': 'application/json' };
  if (t) h.Authorization = `Bearer ${t}`;
  return h;
}

/**
 * Register a passkey for the CURRENTLY logged-in user:
 * server options (auth) → navigator credentials → server verify (auth).
 * Throws Error with an Arabic message suitable for direct UI display.
 */
export async function startPasskeyRegistration(): Promise<void> {
  const optionsRes = await fetch('/api/auth/passkeys/register-options', {
    method: 'POST',
    headers: authHeaders(),
  });
  const options = await optionsRes.json().catch(() => ({}));
  if (!optionsRes.ok) throw new Error(options?.error || 'تعذر بدء تسجيل مفتاح المرور.');

  let attResp: RegistrationResponseJSON;
  try {
    attResp = await startRegistration({ optionsJSON: options });
  } catch (e: any) {
    if (e?.name === 'NotAllowedError') throw new Error('تم إلغاء العملية من المتصفح أو انتهت المهلة.');
    if (e?.name === 'SecurityError') throw new Error('المتصفح رفض العملية: النطاق الحالي لا يطابق نطاق التسجيل.');
    throw new Error('المتصفح أو الجهاز لا يدعم مفاتيح المرور.');
  }

  const verifyRes = await fetch('/api/auth/passkeys/register-verify', {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify({ response: attResp }),
  });
  const data = await verifyRes.json().catch(() => ({}));
  if (!verifyRes.ok) throw new Error(data?.error || 'فشل تأكيد تسجيل مفتاح المرور.');
}

/**
 * Log in with a passkey for the given username:
 * server options (username-keyed) → navigator assertion → server verify.
 * Returns the SAME session payload shape as POST /api/auth/login
 * ({ user, accessToken, refreshToken, sessionId }) so the login screen
 * reuses its existing session-handling code path.
 */
export async function authenticateWithPasskey(username: string): Promise<{
  user: any;
  accessToken: string;
  refreshToken?: string;
  sessionId?: string;
}> {
  const optionsRes = await fetch('/api/auth/passkeys/login-options', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username }),
  });
  const options = await optionsRes.json().catch(() => ({}));
  if (!optionsRes.ok) throw new Error(options?.error || 'تعذر بدء الدخول بمفتاح المرور.');

  let authResp: AuthenticationResponseJSON;
  try {
    authResp = await startAuthentication({ optionsJSON: options });
  } catch (e: any) {
    if (e?.name === 'NotAllowedError') throw new Error('تم إلغاء العملية من المتصفح أو انتهت المهلة.');
    if (e?.name === 'SecurityError') throw new Error('المتصفح رفض العملية: النطاق الحالي لا يطابق نطاق التسجيل.');
    throw new Error('المتصفح أو الجهاز لا يدعم مفاتيح المرور.');
  }

  const verifyRes = await fetch('/api/auth/passkeys/login-verify', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, response: authResp }),
  });
  const data = await verifyRes.json().catch(() => ({}));
  if (!verifyRes.ok) throw new Error(data?.error || 'فشل الدخول بمفتاح المرور.');
  return data;
}

/** List the current user's registered passkeys (auth). */
export async function listPasskeys(): Promise<PasskeyCredentialInfo[]> {
  const res = await fetch('/api/auth/passkeys', { headers: authHeaders() });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.error || 'تعذر تحميل قائمة مفاتيح المرور.');
  return Array.isArray(data.credentials) ? data.credentials : [];
}

/** Delete one of the current user's passkeys (auth, ownership enforced server-side). */
export async function deletePasskey(credentialId: string): Promise<void> {
  const res = await fetch(`/api/auth/passkeys/${encodeURIComponent(credentialId)}`, {
    method: 'DELETE',
    headers: authHeaders(),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.error || 'تعذر حذف مفتاح المرور.');
}
