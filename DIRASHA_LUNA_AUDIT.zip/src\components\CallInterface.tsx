/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Phone, PhoneOff, Mic, MicOff, Volume2, VolumeX, Shield, Loader2, Video, VideoOff, RefreshCw, Monitor, MonitorOff, PictureInPicture2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { VerifiedBadge } from './VerifiedBadge';
import { formatCallDuration } from '../lib/callUiHelpers';

// Unified Call Tone Generator using browser Web Audio API
class CallToneGenerator {
  private ctx: AudioContext | null = null;
  private oscillator1: OscillatorNode | null = null;
  private oscillator2: OscillatorNode | null = null;
  private gainNode: GainNode | null = null;
  private intervalId: any = null;

  private initCtx() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.ctx = new AudioContextClass();
      }
    }
  }

  playCallingTone() {
    this.stop();
    this.initCtx();
    if (!this.ctx) return;

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }

    const playTone = () => {
      if (!this.ctx) return;
      try {
        this.oscillator1 = this.ctx.createOscillator();
        this.oscillator2 = this.ctx.createOscillator();
        this.gainNode = this.ctx.createGain();

        this.oscillator1.type = 'sine';
        this.oscillator1.frequency.setValueAtTime(440, this.ctx.currentTime); // 440Hz

        this.oscillator2.type = 'sine';
        this.oscillator2.frequency.setValueAtTime(480, this.ctx.currentTime); // 480Hz

        this.gainNode.gain.setValueAtTime(0, this.ctx.currentTime);
        this.gainNode.gain.linearRampToValueAtTime(0.08, this.ctx.currentTime + 0.05);
        this.gainNode.gain.setValueAtTime(0.08, this.ctx.currentTime + 1.2);
        this.gainNode.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 1.3);

        this.oscillator1.connect(this.gainNode);
        this.oscillator2.connect(this.gainNode);
        this.gainNode.connect(this.ctx.destination);

        this.oscillator1.start();
        this.oscillator2.start();

        this.oscillator1.stop(this.ctx.currentTime + 1.3);
        this.oscillator2.stop(this.ctx.currentTime + 1.3);
      } catch (e) {
        console.warn('Error playing tone:', e);
      }
    };

    playTone();
    this.intervalId = setInterval(playTone, 3000);
  }

  playRingingTone(style?: string) {
    this.stop();
    this.initCtx();
    if (!this.ctx) return;

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }

    // Ring style variants (notificationSettings.ringtoneStyle)
    const isDouble = style === 'double';
    const isSoft = style === 'soft';
    const f1 = isSoft ? 330 : 400;
    const f2 = isSoft ? 380 : 450;
    const vol = isSoft ? 0.07 : 0.12;

    const playTone = () => {
      if (!this.ctx) return;
      try {
        this.oscillator1 = this.ctx.createOscillator();
        this.oscillator2 = this.ctx.createOscillator();
        this.gainNode = this.ctx.createGain();

        this.oscillator1.type = 'sine';
        this.oscillator1.frequency.setValueAtTime(f1, this.ctx.currentTime);

        this.oscillator2.type = 'sine';
        this.oscillator2.frequency.setValueAtTime(f2, this.ctx.currentTime);

        this.gainNode.gain.setValueAtTime(0, this.ctx.currentTime);
        if (isDouble) {
          this.gainNode.gain.linearRampToValueAtTime(vol, this.ctx.currentTime + 0.05);
          this.gainNode.gain.setValueAtTime(vol, this.ctx.currentTime + 0.25);
          this.gainNode.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 0.3);
          this.gainNode.gain.setValueAtTime(0, this.ctx.currentTime + 0.45);
          this.gainNode.gain.linearRampToValueAtTime(vol, this.ctx.currentTime + 0.5);
          this.gainNode.gain.setValueAtTime(vol, this.ctx.currentTime + 0.7);
          this.gainNode.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 0.75);
        } else {
          this.gainNode.gain.linearRampToValueAtTime(vol, this.ctx.currentTime + 0.08);
          this.gainNode.gain.setValueAtTime(vol, this.ctx.currentTime + 1.5);
          this.gainNode.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 1.7);
        }

        this.oscillator1.connect(this.gainNode);
        this.oscillator2.connect(this.gainNode);
        this.gainNode.connect(this.ctx.destination);

        this.oscillator1.start();
        this.oscillator2.start();

        this.oscillator1.stop(this.ctx.currentTime + 1.7);
        this.oscillator2.stop(this.ctx.currentTime + 1.7);
      } catch (e) {
        console.warn('Error playing tone:', e);
      }
    };

    playTone();
    this.intervalId = setInterval(playTone, 3500);
  }

  playEndTone() {
    this.stop();
    this.initCtx();
    if (!this.ctx) return;

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }

    try {
      this.oscillator1 = this.ctx.createOscillator();
      this.gainNode = this.ctx.createGain();

      this.oscillator1.type = 'sine';
      this.oscillator1.frequency.setValueAtTime(250, this.ctx.currentTime); // low pitch double beep
      this.oscillator1.frequency.setValueAtTime(180, this.ctx.currentTime + 0.15);

      this.gainNode.gain.setValueAtTime(0, this.ctx.currentTime);
      this.gainNode.gain.linearRampToValueAtTime(0.1, this.ctx.currentTime + 0.05);
      this.gainNode.gain.setValueAtTime(0.1, this.ctx.currentTime + 0.3);
      this.gainNode.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 0.35);

      this.oscillator1.connect(this.gainNode);
      this.gainNode.connect(this.ctx.destination);

      this.oscillator1.start();
      this.oscillator1.stop(this.ctx.currentTime + 0.35);
    } catch (e) {
      console.warn('Error playing tone:', e);
    }
  }

  stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    if (this.oscillator1) {
      try { this.oscillator1.stop(); } catch (e) {}
      this.oscillator1 = null;
    }
    if (this.oscillator2) {
      try { this.oscillator2.stop(); } catch (e) {}
      this.oscillator2 = null;
    }
    if (this.gainNode) {
      try { this.gainNode.disconnect(); } catch (e) {}
      this.gainNode = null;
    }
  }
}

const toneGenerator = new CallToneGenerator();

interface CallInterfaceProps {
  call: {
    callId: string;
    role: 'caller' | 'callee';
    partnerId: string;
    partnerName: string;
    partnerAvatar?: string;
    status: 'calling' | 'ringing' | 'connecting' | 'connected' | 'ended';
    type: 'voice' | 'video';
    // True when the call started as 'video' but the camera was denied/unavailable
    // and the call continues as a voice call (WhatsApp parity downgrade).
    videoDowngraded?: boolean;
  };
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
  allUsers: Record<string, any>;
  onAccept: () => void;
  onReject: () => void;
  onRejectWithMessage?: (reason: string) => void;
  ringtoneStyle?: string;
  connectionState?: string;
  onEnd: () => void;
  onLocalStreamChange?: (stream: MediaStream | null) => void;
  peerConnection?: RTCPeerConnection | null;
}

export function CallInterface({
  call,
  localStream,
  remoteStream,
  allUsers,
  onAccept,
  onReject,
  onRejectWithMessage,
  ringtoneStyle,
  connectionState,
  onEnd,
  onLocalStreamChange,
  peerConnection
}: CallInterfaceProps) {
  const [showRejectReasons, setShowRejectReasons] = useState(false);
  const [duration, setDuration] = useState(0);
  const [isLocalMuted, setIsLocalMuted] = useState(false);
  // Downgrade parity: a video call whose camera was denied/unavailable continues
  // as a VOICE call — render the voice layout (avatar), never black video tiles,
  // and keep the call alive. The camera/video buttons hide via isVideoCall.
  const isVideoDowngraded = call.type === 'video' && call.videoDowngraded === true;
  const [isLocalVideoEnabled, setIsLocalVideoEnabled] = useState(call.type === 'video' && call.videoDowngraded !== true);
  const [isRemoteVideoEnabled, setIsRemoteVideoEnabled] = useState(call.type === 'video' && call.videoDowngraded !== true);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [waveHeights, setWaveHeights] = useState<number[]>(Array.from({ length: 15 }, () => 8));

  // ── Screen sharing (1:1) ─────────────────────────────────────────────
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  // The screen stream drives the LOCAL preview tile while sharing.
  const [screenStreamState, setScreenStreamState] = useState<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const screenTrackRef = useRef<MediaStreamTrack | null>(null);
  // Original camera track — kept referenced so we can restore it in the sender.
  const cameraVideoTrackRef = useRef<MediaStreamTrack | null>(null);
  const cameraWasEnabledRef = useRef<boolean>(true);
  // The 'ended' listener added to the live screen track (held in a ref so the
  // exact function identity can be removed later — calling stop() itself
  // fires 'ended', and stale handlers must stay inert).
  const screenEndedHandlerRef = useRef<(() => void) | null>(null);
  // getDisplayMedia feature detection (button hidden when unsupported).
  const canScreenShare = typeof navigator !== 'undefined'
    && !!navigator.mediaDevices
    && typeof (navigator.mediaDevices as MediaDevices & { getDisplayMedia?: unknown }).getDisplayMedia === 'function';

  // ── Call stats (RTT / packet loss / bitrate) for the connection pill tooltip ──
  const [callStats, setCallStats] = useState<{
    rttMs: number | null;
    packetsLost: number | null;
    kbps: number | null;
  } | null>(null);
  // CallInterface can mirror the PC's own connectionState when App doesn't pass one.
  const [derivedPcState, setDerivedPcState] = useState<string | null>(null);

  // Audio & Video outputs
  const remoteAudioRef = useRef<HTMLAudioElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);
  const localVideoRef = useRef<HTMLVideoElement | null>(null);

  const analyserRef = useRef<AnalyserNode | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Retrieve the partner's dynamically synced profile variables from allUsers
  const partnerUser = allUsers[call.partnerId] || {};
  const partnerName = partnerUser.displayName || call.partnerName;
  const partnerAvatar = partnerUser.avatarUrl || call.partnerAvatar;
  const isVerified = !!partnerUser.verified;

  // Stop / play tone generators as state shifts
  useEffect(() => {
    if (call.status === 'calling') {
      toneGenerator.playCallingTone();
    } else if (call.status === 'ringing') {
      toneGenerator.playRingingTone(ringtoneStyle);
    } else if (call.status === 'connected' || call.status === 'connecting') {
      toneGenerator.stop();
    } else if (call.status === 'ended') {
      toneGenerator.playEndTone();
      const t = setTimeout(() => {
        toneGenerator.stop();
      }, 1000);
      return () => clearTimeout(t);
    }

    return () => {
      toneGenerator.stop();
    };
  }, [call.status]);

  // Hook local video preview track. While screen sharing, the preview tile
  // swaps to the screen stream; otherwise it shows the camera stream.
  useEffect(() => {
    const activeStream = (isScreenSharing && screenStreamState) ? screenStreamState : localStream;
    if (localVideoRef.current && activeStream) {
      console.log('[WebRTC localVideo] Binding localStream to preview element and executing play()');
      localVideoRef.current.srcObject = activeStream;
      localVideoRef.current.play().catch(e => {
        console.warn('[WebRTC localVideo] Local video preview playback failed:', e);
      });

      // Only sync the "camera enabled" pill state from the camera stream —
      // the screen track's enabled flag is unrelated to camera state.
      if (!isScreenSharing) {
        const videoTrack = activeStream.getVideoTracks()[0];
        if (videoTrack) {
          setIsLocalVideoEnabled(videoTrack.enabled);
        }
      }
    }
  }, [localStream, screenStreamState, isScreenSharing, call.status]);

  // Hook remote audio/video tracks
  useEffect(() => {
    if (call.status === 'connected' && remoteStream) {
      // Downgraded calls have no usable video — bind remote audio to the audio
      // element so voice always plays even when call.type is still 'video'.
      if (call.type === 'video' && !isVideoDowngraded) {
        if (remoteVideoRef.current) {
          console.log('[WebRTC Video] Binding remoteStream to video element');
          remoteVideoRef.current.srcObject = remoteStream;
          remoteVideoRef.current.play().catch(e => {
            console.error('[WebRTC Video] Remote video playback failed:', e);
          });
        }
      } else {
        if (remoteAudioRef.current) {
          console.log('[WebRTC Audio] Binding remoteStream to audio context element');
          remoteAudioRef.current.srcObject = remoteStream;
          remoteAudioRef.current.play().catch((err) => {
            console.error('[WebRTC Audio] Remote audio playback failed:', err);
          });
        }
      }
    }
  }, [remoteStream, call.status, call.type, isVideoDowngraded]);

  // Track if remote side has video active (by examining remote stream's active tracks)
  useEffect(() => {
    if (remoteStream && call.type === 'video' && !isVideoDowngraded) {
      const checkRemoteTracks = () => {
        const videoTrack = remoteStream.getVideoTracks()[0];
        if (videoTrack) {
          setIsRemoteVideoEnabled(videoTrack.enabled);
        } else {
          setIsRemoteVideoEnabled(false);
        }
      };

      checkRemoteTracks();
      const interval = setInterval(checkRemoteTracks, 1000);
      return () => clearInterval(interval);
    }
  }, [remoteStream, call.type, isVideoDowngraded]);

  // Count call active duration
  useEffect(() => {
    let timer: any = null;
    if (call.status === 'connected') {
      timer = setInterval(() => {
        setDuration(prev => prev + 1);
      }, 1000);
    } else {
      setDuration(0);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [call.status]);

  // Sound waves visuals
  useEffect(() => {
    if (call.status === 'connected' && localStream) {
      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioCtx) {
          const audioCtx = new AudioCtx();
          audioContextRef.current = audioCtx;
          const source = audioCtx.createMediaStreamSource(localStream);
          const analyser = audioCtx.createAnalyser();
          analyser.fftSize = 64;
          source.connect(analyser);
          analyserRef.current = analyser;

          const dataArray = new Uint8Array(analyser.frequencyBinCount);
          
          const drawWave = () => {
            if (!analyserRef.current) return;
            analyserRef.current.getByteFrequencyData(dataArray);

            const heights: number[] = [];
            const step = Math.ceil(dataArray.length / 15);
            for (let i = 0; i < 15; i++) {
              const val = dataArray[i * step] || 0;
              // Map 0-255 frequency amplitude to heights 6px - 45px
              const height = isLocalMuted ? 6 : Math.max(6, Math.round((val / 255) * 38) + 6);
              heights.push(height);
            }
            setWaveHeights(heights);
            animationFrameRef.current = requestAnimationFrame(drawWave);
          };
          animationFrameRef.current = requestAnimationFrame(drawWave);
        }
      } catch (err) {
        console.warn('Failed setting up mic volume visualizer:', err);
      }
    } else if (call.status === 'calling' || call.status === 'ringing') {
      // pulsating idle visualizer waves
      let ticks = 0;
      const interval = setInterval(() => {
        const heights = Array.from({ length: 15 }, (_, idx) => {
          const val = Math.sin((ticks + idx) * 0.5) * Math.cos((ticks - idx) * 0.3);
          return Math.max(6, Math.round(Math.abs(val) * 20) + 8);
        });
        setWaveHeights(heights);
        ticks++;
      }, 150);
      return () => clearInterval(interval);
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
        animationFrameRef.current = null;
      }
      if (audioContextRef.current) {
        try {
          audioContextRef.current.close();
        } catch (e) {}
        audioContextRef.current = null;
      }
    };
  }, [call.status, localStream, isLocalMuted]);

  // Toggle local microphone
  const toggleMute = () => {
    if (localStream) {
      localStream.getAudioTracks().forEach(track => {
        track.enabled = !track.enabled;
      });
      setIsLocalMuted(!isLocalMuted);
    }
  };

  // Toggle local camera (video call option)
  const toggleCamera = () => {
    if (localStream) {
      const videoTrack = localStream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setIsLocalVideoEnabled(videoTrack.enabled);
        // While sharing, the camera track is parked (not sent). Remember its
        // enabled state so it is restored faithfully when sharing stops.
        if (isScreenSharing) {
          cameraWasEnabledRef.current = videoTrack.enabled;
        }
        console.log(`[CallInterface] Local video track enabled state = ${videoTrack.enabled}`);
      } else if (call.type === 'video') {
         // No video track found, let's request camera stream and push it
         console.warn('[CallInterface] No existing video track to toggle.');
      }
    }
  };

  // Switch front/back camera (Facing Mode switch for Mobile environments)
  const switchCamera = async () => {
    if (!localStream || !onLocalStreamChange) return;
    // Switching camera mid-share would overwrite the screen track in the
    // sender — block it until the share ends.
    if (isScreenSharing) return;
    const videoTrack = localStream.getVideoTracks()[0];
    if (!videoTrack) return;

    const nextFacingMode = facingMode === 'user' ? 'environment' : 'user';
    console.log(`[CallInterface] Toggling camera facing mode to: ${nextFacingMode}`);

    try {
      videoTrack.stop();
      
      const newStream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: { facingMode: nextFacingMode }
      });
      const newTrack = newStream.getVideoTracks()[0];

      if (peerConnection) {
        const senders = peerConnection.getSenders();
        const sender = senders.find(s => s.track && s.track.kind === 'video');
        if (sender) {
          console.log('[CallInterface] Replacing video track inside RTCPeerConnection sender');
          await sender.replaceTrack(newTrack);
        }
      }

      const audioTracks = localStream.getAudioTracks();
      const combinedStream = new MediaStream([...audioTracks, newTrack]);
      
      onLocalStreamChange(combinedStream);
      setFacingMode(nextFacingMode);
    } catch (e) {
      console.warn('[CallInterface] Failed to switch camera facing option:', e);
    }
  };

  // ── Screen sharing (1:1) ────────────────────────────────────────────────
  // Flow: getDisplayMedia → sender.replaceTrack(screenTrack) on the existing
  // video sender (no renegotiation needed). The camera track stays referenced
  // (cameraVideoTrackRef) and is parked (enabled=false) until restore.

  // Internal teardown used by the toggle, the browser's native
  // 'Stop sharing' handler, and call-end cleanup.
  const stopScreenShareInternal = async (opts: { restoreSender: boolean; notify: boolean }) => {
    const screenTrack = screenTrackRef.current;
    const screenStream = screenStreamRef.current;
    const endedHandler = screenEndedHandlerRef.current;

    screenTrackRef.current = null;
    screenStreamRef.current = null;
    screenEndedHandlerRef.current = null;
    setScreenStreamState(null);
    setIsScreenSharing(false);

    // Detach the 'ended' listener BEFORE stopping the track (stop() fires
    // 'ended' and we don't want the handler to double-run).
    if (screenTrack && endedHandler) {
      try { screenTrack.removeEventListener('ended', endedHandler); } catch (_) {}
    }
    // Stop the screen tracks — getDisplayMedia streams are ours to release.
    if (screenStream) {
      screenStream.getTracks().forEach(t => { try { t.stop(); } catch (_) {} });
    }

    // Restore the camera: back into the sender + re-enable capture.
    const cameraTrack = cameraVideoTrackRef.current;
    if (cameraTrack && cameraTrack.readyState === 'live') {
      if (opts.restoreSender && peerConnection) {
        const sender = peerConnection.getSenders().find(s => s.track?.kind === 'video');
        if (sender) {
          try { await sender.replaceTrack(cameraTrack); } catch (e) {
            console.warn('[CallInterface] Failed to restore camera track into sender:', e);
          }
        }
      }
      const wasEnabled = cameraWasEnabledRef.current;
      if (cameraTrack.enabled !== wasEnabled) {
        cameraTrack.enabled = wasEnabled;
      }
      setIsLocalVideoEnabled(wasEnabled);
    }
    cameraVideoTrackRef.current = null;

    if (opts.notify && (window as any).showGlobalToast) {
      (window as any).showGlobalToast('تم إيقاف مشاركة الشاشة', 'info');
    }
  };

  const startScreenShare = async () => {
    if (isScreenSharing || !isVideoCall || call.status !== 'connected') return;
    const md = navigator.mediaDevices as MediaDevices & {
      getDisplayMedia?: (constraints: MediaStreamConstraints) => Promise<MediaStream>;
    };
    if (!md?.getDisplayMedia) return;

    try {
      const stream = await md.getDisplayMedia({
        video: { frameRate: { ideal: 15, max: 15 } },
        audio: false
      });
      const screenTrack = stream.getVideoTracks()[0];
      // Guard: never wire an already-ended track into the sender.
      if (!screenTrack || screenTrack.readyState !== 'live') {
        stream.getTracks().forEach(t => { try { t.stop(); } catch (_) {} });
        return;
      }

      const cameraTrack = localStream?.getVideoTracks()[0] || null;
      cameraVideoTrackRef.current = cameraTrack;
      cameraWasEnabledRef.current = cameraTrack ? cameraTrack.enabled : true;
      // Park the camera while the screen is being sent instead.
      if (cameraTrack) cameraTrack.enabled = false;

      screenTrackRef.current = screenTrack;
      screenStreamRef.current = stream;

      const sender = peerConnection?.getSenders().find(s => s.track?.kind === 'video');
      if (sender) {
        await sender.replaceTrack(screenTrack);
        console.log('[CallInterface] Screen track installed into video sender');
      } else {
        console.warn('[CallInterface] No video sender on the peer connection — sharing preview only');
      }

      // Browser's native 'Stop sharing' bar → auto-restore the camera.
      const onScreenEnded = () => {
        console.log('[CallInterface] Screen track ended externally — restoring camera');
        stopScreenShareInternal({ restoreSender: true, notify: true });
      };
      screenEndedHandlerRef.current = onScreenEnded;
      screenTrack.addEventListener('ended', onScreenEnded);
      setScreenStreamState(stream);
      setIsScreenSharing(true);
      setIsLocalVideoEnabled(false);

      if ((window as any).showGlobalToast) {
        (window as any).showGlobalToast('🖥 بدأت مشاركة الشاشة', 'success');
      }
    } catch (err: any) {
      // Permission denial / user picked nothing and cancelled: silent toast.
      if (err?.name === 'NotAllowedError') {
        if ((window as any).showGlobalToast) {
          (window as any).showGlobalToast('تم إلغاء مشاركة الشاشة', 'info');
        }
      } else {
        console.warn('[CallInterface] Screen share failed:', err);
      }
    }
  };

  const toggleScreenShare = () => {
    if (isScreenSharing) {
      stopScreenShareInternal({ restoreSender: true, notify: true });
    } else {
      startScreenShare();
    }
  };

  // Screen tracks must never outlive the call: tear down on 'ended' status
  // and on unmount (the 1:1 machine tears the PC down moments later).
  useEffect(() => {
    if (call.status === 'ended' && screenTrackRef.current) {
      stopScreenShareInternal({ restoreSender: false, notify: false });
    }
  }, [call.status]);

  useEffect(() => {
    return () => {
      if (screenTrackRef.current) {
        stopScreenShareInternal({ restoreSender: false, notify: false });
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── Call stats: real getStats every 2s → tooltip on the connection pill ──
  // All failures are silent (a torn-down PC throws; stats are best-effort).
  useEffect(() => {
    if (call.status !== 'connected' || !peerConnection) {
      setCallStats(null);
      setDerivedPcState(null);
      return;
    }
    let cancelled = false;
    let prevBytes: number | null = null;
    let prevTs: number | null = null;

    const poll = async () => {
      try {
        const report = await peerConnection.getStats();
        if (cancelled) return;
        // Mirror the PC's live connectionState (used when App doesn't pass one).
        setDerivedPcState(peerConnection.connectionState);

        let rttMs: number | null = null;
        let packetsLost: number | null = null;
        let bytes = 0;
        let ts = 0;
        let sawInbound = false;

        report.forEach((raw: any) => {
          // RTT: the currently selected candidate pair (Chrome marks it
          // selected/nominated; standard reports expose currentRoundTripTime).
          if (raw.type === 'candidate-pair' && typeof raw.currentRoundTripTime === 'number') {
            if (rttMs === null || raw.selected || raw.nominated) {
              rttMs = raw.currentRoundTripTime * 1000;
            }
          } else if (raw.type === 'inbound-rtp' && raw.kind === 'video') {
            sawInbound = true;
            if (typeof raw.packetsLost === 'number') {
              packetsLost = (packetsLost ?? 0) + raw.packetsLost;
            }
            if (typeof raw.bytesReceived === 'number') bytes += raw.bytesReceived;
            if (typeof raw.timestamp === 'number') ts = Math.max(ts, raw.timestamp);
          }
        });

        // Receive bitrate = delta(bytesReceived) / delta(timestamp).
        let kbps: number | null = null;
        if (sawInbound && prevBytes !== null && prevTs !== null && ts > prevTs) {
          kbps = Math.max(0, Math.round(((bytes - prevBytes) * 8) / (ts - prevTs)));
        }
        prevBytes = sawInbound ? bytes : null;
        prevTs = sawInbound ? ts : null;

        if (!cancelled) setCallStats({ rttMs, packetsLost, kbps });
      } catch {
        /* getStats on a closed/failing PC throws — stay silent */
      }
    };

    poll();
    const interval = setInterval(poll, 2000);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [call.status, peerConnection]);

  // Connection quality pill: derived from the optional connectionState prop,
  // falling back to the PC's live state mirrored via the getStats poll.
  // Hidden entirely when neither source is available.
  const getConnectionPill = () => {
    const stateSource = connectionState || derivedPcState;
    if (!stateSource) return null;
    const state = stateSource.toLowerCase();
    if (state === 'connected') {
      return { label: '🟢 متصلة', className: 'text-emerald-300 bg-emerald-500/10 border-emerald-500/20' };
    }
    if (state === 'connecting' || state === 'new') {
      return { label: '🟡 جارٍ الاتصال', className: 'text-amber-300 bg-amber-500/10 border-amber-500/20' };
    }
    if (state.includes('fail') || state.includes('disconnect')) {
      return { label: '🔴 ضعيف — جارٍ الاستعادة', className: 'text-rose-300 bg-rose-500/10 border-rose-500/20' };
    }
    return null;
  };
  const connectionPill = getConnectionPill();

  // Stats tooltip: RTT + packets lost + receive bitrate, refreshed every 2s
  // by the getStats poll. All values optional — the tooltip degrades to the
  // plain connection label when a metric is unavailable.
  const connectionTooltip = (() => {
    const lines: string[] = ['حالة الاتصال'];
    if (callStats) {
      if (callStats.rttMs !== null) lines.push(`زمن الاستجابة: ${Math.round(callStats.rttMs)} مللي ثانية`);
      if (callStats.packetsLost !== null) lines.push(`فقدان الحزم: ${callStats.packetsLost}`);
      if (callStats.kbps !== null) lines.push(`سرعة الاستقبال: ${callStats.kbps} kbps`);
    }
    return lines.join('\n');
  })();

  const getStatusText = () => {
    switch (call.status) {
      case 'calling':
        return 'جاري الاتصال...';
      case 'ringing':
        return call.type === 'video' ? 'مكالمة فيديو واردة...' : 'اتصال وارد...';
      case 'connecting':
        return 'جاري الضبط...';
      case 'connected':
        // Downgraded (camera denied) calls read as voice once connected.
        return (call.type === 'video' && !isVideoDowngraded) ? 'مكالمة فيديو متصلة' : 'مكالمة متصلة';
      case 'ended':
        return 'انتهت المكالمة';
      default:
        return '';
    }
  };

  // Immersive styling — a downgraded video call renders the VOICE layout
  // (avatar + soundwaves) instead of video tiles, without closing the call.
  const isVideoCall = call.type === 'video' && !isVideoDowngraded;
  const showVideoStreams = isVideoCall && (call.status === 'connected' || call.status === 'connecting' || call.status === 'calling');
  // While screen sharing, the preview tile shows the screen stream even
  // though the (parked) camera track is disabled.
  const showLocalPreview = isScreenSharing || isLocalVideoEnabled;

  // ── Picture-in-Picture (remote video only) ────────────────────────────────
  // Feature-detected Document Picture-in-Picture on the REMOTE video element.
  // requestPictureInPicture() is invoked directly from the button's click
  // handler, which satisfies the user-gesture requirement.
  const canPip = typeof document !== 'undefined'
    && 'pictureInPictureEnabled' in document
    && !!document.pictureInPictureEnabled;

  const toggleRemotePip = async () => {
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else {
        await remoteVideoRef.current?.requestPictureInPicture();
      }
    } catch (_) {
      // Failures (no video data yet, gesture lost, unsupported track) are silent.
    }
  };

  // Auto-exit PiP when the call ends and on unmount so the floating window
  // never outlives the session.
  useEffect(() => {
    if (call.status === 'ended' && document.pictureInPictureElement) {
      document.exitPictureInPicture().catch(() => {});
    }
  }, [call.status]);
  useEffect(() => () => {
    if (document.pictureInPictureElement) {
      document.exitPictureInPicture().catch(() => {});
    }
  }, []);

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/75 backdrop-blur-md px-4" style={{ direction: 'ltr' }}>
        {/* Render Audio Element as fallback/voice receiver */}
        <audio ref={remoteAudioRef} autoPlay className="hidden" />

        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 30 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.95, opacity: 0, y: 20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 150 }}
          className={`relative w-full ${isVideoCall ? 'max-w-xl aspect-[3/4] sm:aspect-[9/16] max-h-[90vh]' : 'max-w-sm'} rounded-[36px] bg-[#0c0c0e] border border-white/10 shadow-[0_0_60px_rgba(0,0,0,0.9)] overflow-hidden flex flex-col items-center`}
        >
          {/* VIDEO INSETS / VIEWS */}
          {showVideoStreams ? (
            <div className="absolute inset-0 w-full h-full bg-[#030304] z-0">
              {/* Remote camera viewport */}
              <video
                ref={remoteVideoRef}
                autoPlay
                playsInline
                className={`w-full h-full object-cover transition-all duration-300 ${!isRemoteVideoEnabled ? 'opacity-0 scale-95 blur-md' : 'opacity-100 scale-100'}`}
              />

              {/* Blurred fallback screen overlay if remote side turns off they camera feed */}
              {!isRemoteVideoEnabled && (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 backdrop-blur-xl z-1">
                  <div className="relative mb-4">
                    <img
                      src={partnerAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop'}
                      alt={partnerName}
                      referrerPolicy="no-referrer"
                      className="w-24 h-24 rounded-full border-2 border-white/10 object-cover shadow-2xl scale-105"
                    />
                    <motion.div
                      animate={{ scale: [1, 1.3, 1], opacity: [0.5, 0.1, 0.5] }}
                      transition={{ repeat: Infinity, duration: 2.5, ease: 'easeInOut' }}
                      className="absolute -inset-2 rounded-full border border-sky-500/30 pointer-events-none"
                    />
                  </div>
                  <p className="text-sm font-semibold text-zinc-300">أوقف {partnerName} الكاميرا</p>
                </div>
              )}

              {/* Local camera preview inset element */}
              {localStream && (
                <div className="absolute top-6 left-6 z-10">
                  <div className="relative group">
                    <video
                      ref={localVideoRef}
                      autoPlay
                      playsInline
                      muted
                      disablePictureInPicture
                      className={`w-[100px] h-[145px] sm:w-[120px] sm:h-[180px] rounded-2xl object-cover border-2 border-white/25 shadow-2xl bg-black ${!showLocalPreview ? 'opacity-0 scale-90' : 'opacity-100 scale-100'} transition-all duration-300`}
                    />

                    {/* Fallback for local preview if local camera is turned off */}
                    {!showLocalPreview && (
                      <div className="w-[100px] h-[145px] sm:w-[120px] sm:h-[180px] rounded-2xl border-2 border-white/10 bg-zinc-950/90 flex flex-col items-center justify-center gap-1 shadow-2xl">
                        <VideoOff className="w-5 h-5 text-zinc-400" />
                        <span className="text-[9px] text-zinc-400">الكاميرا معطلة</span>
                      </div>
                    )}

                    {/* Quick switch-camera overlay panel for Mobile UI within local video frame */}
                    {isLocalVideoEnabled && (
                      <button
                        type="button"
                        onClick={switchCamera}
                        className="absolute bottom-2 right-2 p-1.5 bg-black/60 rounded-lg hover:bg-black/80 transition-all text-white active:scale-95 shadow-lg border border-white/10 cursor-pointer"
                        title="تبديل الكاميرا"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* Header Info Panel styled transparent glass */}
              <div className="absolute top-6 right-6 left-[140px] z-10 text-left bg-black/45 backdrop-blur-md border border-white/10 rounded-2xl px-4 py-2 flex flex-col justify-center max-w-[260px] mr-auto">
                <div className="flex items-center gap-1 text-left mt-0.5 min-w-0">
                  <span className="text-sm font-bold text-white truncate max-w-[180px] tracking-wide">{partnerName}</span>
                  {isVerified && <VerifiedBadge className="w-3.5 h-3.5 shrink-0" />}
                </div>
                <span className="text-[11px] text-zinc-300 font-semibold">{getStatusText()}</span>
              </div>
            </div>
          ) : null}

          {/* SATE INTENT OVERLAY GRADIENT */}
          {isVideoCall ? (
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-black/30 pointer-events-none z-[1]" />
          ) : (
            <div className="absolute inset-0 bg-radial-gradient from-blue-500/10 via-transparent to-transparent pointer-events-none" />
          )}

          {/* Standard layout elements (Only on voice call or RINGING callee video calls to avoid blocking remote preview) */}
          {(!showVideoStreams || call.status === 'ringing') && (
            <div className="p-8 w-full flex flex-col items-center z-[2]">
              {/* Secure Encryption Banner */}
              <div className="flex items-center gap-1.5 py-1 px-3 bg-white/5 border border-white/5 rounded-full mb-8 relative z-10">
                <Shield className="w-3 text-sky-400" />
                <span className="text-[10px] text-zinc-400 font-medium">مكالمة مشفرة (P2P WebRTC)</span>
              </div>

              {/* Downgrade badge: video call continuing as voice (camera unavailable) */}
              {isVideoDowngraded && (
                <div className="flex items-center gap-1.5 py-1 px-3 bg-amber-500/10 border border-amber-500/20 rounded-full mb-4 -mt-4 relative z-10">
                  <VideoOff className="w-3 text-amber-400 shrink-0" />
                  <span className="text-[10px] text-amber-300 font-medium">مكالمة صوتية (الكاميرا غير متاحة)</span>
                </div>
              )}

              {/* Avatar Area with dynamic rings */}
              <div className="relative mb-6">
                <AnimatePresence>
                  {(call.status === 'calling' || call.status === 'ringing' || call.status === 'connecting') && (
                    <>
                      <motion.div
                        animate={{ scale: [1, 1.45, 1], opacity: [0.4, 0, 0.4] }}
                        transition={{ repeat: Infinity, duration: 2.2, ease: 'easeInOut' }}
                        className="absolute -inset-4 rounded-full border border-blue-500/20"
                      />
                      <motion.div
                        animate={{ scale: [1, 1.8, 1], opacity: [0.2, 0, 0.2] }}
                        transition={{ repeat: Infinity, duration: 2.2, delay: 0.7, ease: 'easeInOut' }}
                        className="absolute -inset-8 rounded-full border border-blue-500/10"
                      />
                    </>
                  )}
                </AnimatePresence>

                <img
                  src={partnerAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop'}
                  alt={partnerName}
                  referrerPolicy="no-referrer"
                  className="w-24 h-24 rounded-full border-2 border-white/10 object-cover shadow-2xl relative z-10"
                />
              </div>

              {/* Name & Title (caller type icon shown while ringing) */}
              <div className="flex items-center gap-1.5 mb-2 relative z-10 justify-center">
                {call.status === 'ringing' && (
                  isVideoCall
                    ? <Video className="w-4 h-4 text-sky-400 shrink-0" aria-label="مكالمة فيديو واردة" />
                    : <Phone className="w-4 h-4 text-emerald-400 shrink-0" aria-label="اتصال صوتي وارد" />
                )}
                <h2 className="text-xl font-bold text-white tracking-wide">{partnerName}</h2>
                {isVerified && <VerifiedBadge className="w-4 h-4" />}
              </div>
              
              <div className="flex items-center gap-2 mb-8 relative z-10 justify-center">
                {call.status === 'connecting' && <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-400" />}
                <span className={`text-xs font-semibold tracking-wider ${call.status === 'connected' ? 'text-green-400' : 'text-zinc-400'}`}>
                  {getStatusText()}
                </span>
              </div>

              {/* Audio Soundwaves Visualizer (Voice layouts) */}
              <div className="h-16 flex items-center justify-center gap-[3px] mb-10 w-full relative z-10">
                {waveHeights.map((height, idx) => (
                  <motion.div
                    key={idx}
                    animate={{ height }}
                    transition={{ type: 'spring', damping: 15, stiffness: 300 }}
                    className={`w-[4px] rounded-full ${
                      isLocalMuted 
                        ? 'bg-zinc-600' 
                        : call.status === 'connected' 
                        ? 'bg-gradient-to-t from-blue-500 to-sky-400 shadow-[0_0_8px_rgba(56,189,248,0.3)]' 
                        : 'bg-zinc-700'
                    }`}
                  />
                ))}
              </div>

              {/* Call connected duration counter + connection quality pill */}
              {call.status === 'connected' && (
                <div className="flex items-center gap-2 mb-10 relative z-10 justify-center animate-fade-in">
                  <div className="text-base font-mono text-zinc-300 font-semibold tracking-wide bg-white/5 border border-white/5 px-4 py-1.5 rounded-full">
                    {formatCallDuration(duration)}
                  </div>
                  {connectionPill && (
                    <span className={`text-[10px] font-bold px-2.5 py-1.5 rounded-full border ${connectionPill.className}`} title={connectionTooltip}>
                      {connectionPill.label}
                    </span>
                  )}
                </div>
              )}
            </div>
          )}

          {/* ACTIVE CALL FLOATING METRIC (Only on video calls) */}
          {showVideoStreams && call.status === 'connected' && (
            <div className="absolute bottom-28 left-6 z-10 flex flex-col gap-2 items-start select-none animate-fade-in">
              <div className="font-mono text-xs text-zinc-300 bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-full flex items-center gap-1.5 border border-white/5">
                <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                <span>{formatCallDuration(duration)}</span>
              </div>
              {connectionPill && (
                <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full border backdrop-blur-md ${connectionPill.className}`} title={connectionTooltip}>
                  {connectionPill.label}
                </span>
              )}
            </div>
          )}

          {/* GLOBAL CONTROLLER PANEL ACTIONS */}
          <div className="absolute bottom-8 left-0 right-0 z-20 flex items-center justify-center gap-6 px-8 py-2 w-full mt-auto">
            {call.status === 'ringing' ? (
              <div className="flex items-center gap-8 justify-center w-full">
                {/* Accept Button */}
                <button
                  type="button"
                  onClick={onAccept}
                  className="w-14 h-14 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white flex items-center justify-center transition-all duration-150 active:scale-95 shadow-[0_10px_25px_rgba(16,185,129,0.3)] hover:shadow-[0_10px_30px_rgba(16,185,129,0.5)] cursor-pointer"
                  title="قبول"
                >
                  <Phone className="w-6 h-6 fill-current text-white animate-pulse" />
                </button>

                {/* Reject Button — opens quick-reason sheet (WhatsApp parity) */}
                {showRejectReasons && call.role === 'callee' ? (
                  <div className="flex flex-col gap-1.5 w-full max-w-xs">
                    {['مشغول الآن', 'أعود إليك حالاً', 'سأتصل بك لاحقاً'].map((reason) => (
                      <button
                        key={reason}
                        type="button"
                        onClick={() => { setShowRejectReasons(false); onRejectWithMessage?.(reason); }}
                        className="w-full py-2.5 rounded-xl bg-white/10 border border-white/10 text-white text-xs font-bold hover:bg-white/20 transition-all cursor-pointer"
                      >
                        📩 {reason}
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={onReject}
                      className="w-full py-2 rounded-xl text-rose-300 text-xs font-bold hover:bg-rose-500/10 transition-all cursor-pointer"
                    >
                      رفض بدون رسالة
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      if (call.role === 'callee' && onRejectWithMessage) setShowRejectReasons(true);
                      else onReject();
                    }}
                    className="w-14 h-14 rounded-full bg-rose-500 hover:bg-rose-600 text-white flex items-center justify-center transition-all duration-150 active:scale-95 shadow-[0_10px_25px_rgba(244,63,94,0.3)] hover:shadow-[0_10px_30px_rgba(244,63,94,0.5)] cursor-pointer"
                    title="رفض"
                  >
                    <PhoneOff className="w-6 h-6 text-white" />
                  </button>
                )}
              </div>
            ) : (
              /* ACTIVE CALL CONTROLLER VIEW */
              <div className="flex items-center gap-5 justify-center w-full bg-black/45 backdrop-blur-lg border border-white/10 rounded-full py-2.5 px-6 max-w-sm shadow-xl">
                {/* Mute Mic toggle */}
                {call.status === 'connected' && (
                  <button
                    type="button"
                    onClick={toggleMute}
                    className={`w-11 h-11 rounded-full flex items-center justify-center transition-all duration-150 active:scale-95 border cursor-pointer ${
                      isLocalMuted
                        ? 'bg-rose-500/15 border-rose-500/35 text-rose-500 hover:bg-rose-500/25'
                        : 'bg-white/5 border-white/10 text-zinc-300 hover:bg-white/10'
                    }`}
                    title={isLocalMuted ? "إلغاء كتم الميكروفون" : "كتم الميكروفون"}
                  >
                    {isLocalMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                  </button>
                )}

                {/* Toggle Camera (Only on video calls) */}
                {isVideoCall && call.status === 'connected' && (
                  <button
                    type="button"
                    onClick={toggleCamera}
                    className={`w-11 h-11 rounded-full flex items-center justify-center transition-all duration-150 active:scale-95 border cursor-pointer ${
                      !isLocalVideoEnabled && !isScreenSharing
                        ? 'bg-rose-500/15 border-rose-500/35 text-rose-500 hover:bg-rose-500/25'
                        : 'bg-white/5 border-white/10 text-zinc-300 hover:bg-white/10'
                    }`}
                    title={isLocalVideoEnabled ? "إيقاف الكاميرا" : "تشغيل الكاميرا"}
                  >
                    {isLocalVideoEnabled ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
                  </button>
                )}

                {/* Screen share toggle (Only on supported video calls) */}
                {isVideoCall && call.status === 'connected' && canScreenShare && (
                  <button
                    type="button"
                    onClick={toggleScreenShare}
                    className={`w-11 h-11 rounded-full flex items-center justify-center transition-all duration-150 active:scale-95 border cursor-pointer ${
                      isScreenSharing
                        ? 'bg-sky-500/15 border-sky-500/35 text-sky-400 hover:bg-sky-500/25'
                        : 'bg-white/5 border-white/10 text-zinc-300 hover:bg-white/10'
                    }`}
                    title={isScreenSharing ? "إيقاف مشاركة الشاشة" : "مشاركة الشاشة"}
                  >
                    {isScreenSharing ? <MonitorOff className="w-5 h-5" /> : <Monitor className="w-5 h-5" />}
                  </button>
                )}

                {/* Picture-in-Picture on the remote stream (video calls only) */}
                {isVideoCall && call.status === 'connected' && canPip && isRemoteVideoEnabled && (
                  <button
                    type="button"
                    onClick={toggleRemotePip}
                    className="w-11 h-11 rounded-full flex items-center justify-center transition-all duration-150 active:scale-95 border bg-white/5 border-white/10 text-zinc-300 hover:bg-white/10 cursor-pointer"
                    title="نافذة عائمة (PiP)"
                  >
                    <PictureInPicture2 className="w-5 h-5" />
                  </button>
                )}

                {/* End Call Button */}
                <button
                  type="button"
                  onClick={onEnd}
                  className="w-12 h-12 rounded-full bg-rose-500 hover:bg-rose-600 text-white flex items-center justify-center transition-all duration-150 active:scale-95 shadow-[0_10px_20px_rgba(244,63,94,0.3)] hover:shadow-[0_10px_25px_rgba(244,63,94,0.5)] cursor-pointer"
                  title="إنهاء"
                >
                  <PhoneOff className="w-5 h-5 text-white" />
                </button>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
