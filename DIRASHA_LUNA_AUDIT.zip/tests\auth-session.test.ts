/**
 * AUTH-01 / AUTH-02 / AUTH-03 / AUTH-05 — session & token engine remediation
 * tests (external-audit wave).
 *
 * Covers:
 *   AUTH-01  Refresh-token rotation is an ATOMIC compare-and-swap over
 *            sha256-hex HASHES (db.rotateRefreshTokenCas) with token-family
 *            reuse detection: presenting a SPENT or STALE token revokes the
 *            whole token family (db.revokeSessionFamily) and yields NO new
 *            tokens. Raw refresh tokens never cross the persistence boundary
 *            (hashes only), and the raw token stays cookie-transport-only.
 *   AUTH-05  Media tokens are audience-scoped (aud:'media'), optionally bound
 *            to a single resource (resourceType/resourceId), and verify with a
 *            DISTINGUISHABLE result (verifyMediaToken) instead of null.
 *   AUTH-03  Access tokens carry jti + auth_time (+ sid when session-bound);
 *            isTokenRevocationCheckable detects revocation-checkable tokens.
 *   AUTH-02  Passkey enrollment pins userVerification:'required' (+ requireUserVerification
 *            at verify) and gates register-verify / credential DELETE behind
 *            step-up: fresh auth_time/iat (≤ 5 min) OR password re-verification;
 *            new-credential registrations write an audit line.
 *
 * Test split (same constraint as tests/media-auth.test.ts — server.ts boots
 * the HTTP listener at import): the auth service is driven against a MOCKED
 * database module with the CAS signatures, and the passkey routes are
 * registered on a recording fake app (server-owned requireAuth replaced by a
 * stub that injects the JWT claims under test).
 *
 * Run: npx vitest run tests/auth-session.test.ts
 */
import { describe, it, expect, vi, beforeAll, beforeEach, afterAll } from 'vitest';
import crypto from 'crypto';
import jwt from 'jsonwebtoken';

/* ── Hoisted mock fns shared with the vi.mock factories ───────────────────── */
const h = vi.hoisted(() => ({
  poolQuery: vi.fn(),
  getSessionByRefreshToken: vi.fn(),
  rotateRefreshTokenCas: vi.fn(),
  markRefreshTokenSpent: vi.fn(),
  isRefreshTokenSpent: vi.fn(),
  revokeSessionFamily: vi.fn(),
  revokeAllUserSessions: vi.fn(),
  getUserById: vi.fn(),
  getUserByUsername: vi.fn(),
  getUserSecrets: vi.fn(),
  updateUser: vi.fn(),
  createSession: vi.fn(),
  logAuthAction: vi.fn(),
  recordLoginResult: vi.fn(),
  revokeSession: vi.fn(),
  banUser: vi.fn(),
  generateRegistrationOptions: vi.fn(),
  verifyRegistrationResponse: vi.fn(),
}));

vi.mock('../src/server/database.ts', () => ({
  db: {
    getSessionByRefreshToken: h.getSessionByRefreshToken,
    rotateRefreshTokenCas: h.rotateRefreshTokenCas,
    markRefreshTokenSpent: h.markRefreshTokenSpent,
    isRefreshTokenSpent: h.isRefreshTokenSpent,
    revokeSessionFamily: h.revokeSessionFamily,
    revokeAllUserSessions: h.revokeAllUserSessions,
    getUserById: h.getUserById,
    getUserByUsername: h.getUserByUsername,
    getUserSecrets: h.getUserSecrets,
    updateUser: h.updateUser,
    createSession: h.createSession,
    logAuthAction: h.logAuthAction,
    recordLoginResult: h.recordLoginResult,
    revokeSession: h.revokeSession,
    banUser: h.banUser,
  },
  pool: { query: h.poolQuery },
}));

vi.mock('@simplewebauthn/server', () => ({
  generateRegistrationOptions: h.generateRegistrationOptions,
  verifyRegistrationResponse: h.verifyRegistrationResponse,
  generateAuthenticationOptions: vi.fn(),
  verifyAuthenticationResponse: vi.fn(),
}));

import { AuthService, hashRefreshToken, isTokenRevocationCheckable, isScopedMediaTokenPayload } from '../src/server/services/auth.ts';
import type { ScopedMediaTokenPayload } from '../src/server/services/auth.ts';
import { isFreshAuthEvent, STEP_UP_FRESH_WINDOW_MS } from '../src/server/routes/passkeys.ts';
import { hashSecret } from '../src/server/services/password.ts';

/* ── Shared fixtures (unique per test to keep the issued-token history clean) ── */
const USER = { id: 'user-1', username: 'alice', displayName: 'Alice', isBanned: false } as any;

function sessionFixture(sessionId: string, overrides: Record<string, unknown> = {}) {
  const in7days = new Date(); in7days.setDate(in7days.getDate() + 7);
  return {
    id: sessionId,
    userId: 'user-1',
    refreshToken: '',
    userAgent: 'Vitest UA',
    ipAddress: '10.0.0.1',
    isRevoked: false,
    expiresAt: in7days.toISOString(),
    createdAt: new Date().toISOString(),
    ...overrides,
  } as any;
}

/** sha256-hex computed INDEPENDENTLY of auth.ts (guards the hash contract). */
function sha256hex(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

const nowSec = () => Math.floor(Date.now() / 1000);

/* ════════════════════════ AUTH-01 — refresh rotation ════════════════════════ */
describe('AUTH-01: CAS refresh-token rotation (hash-only, atomic)', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    h.markRefreshTokenSpent.mockResolvedValue(undefined);
    h.isRefreshTokenSpent.mockResolvedValue(false);
    h.revokeSessionFamily.mockResolvedValue(undefined);
    h.revokeAllUserSessions.mockResolvedValue(undefined);
    h.getUserById.mockResolvedValue(USER);
    h.logAuthAction.mockResolvedValue(undefined);
    h.updateUser.mockResolvedValue(undefined);
    h.createSession.mockImplementation(async (s: any) => s);
  });

  it('rotates atomically: CAS gets hashes (never raw tokens), spent hash is recorded, no family revoke', async () => {
    const oldToken = 'rot-success-old-token-001';
    h.getSessionByRefreshToken.mockResolvedValue(sessionFixture('sess-rot-success'));
    h.rotateRefreshTokenCas.mockResolvedValue('rotated');

    const bundle = await AuthService.rotateRefreshToken(oldToken, 'UA', '1.2.3.4');
    expect(bundle).not.toBeNull();
    expect(bundle!.sessionId).toBe('sess-rot-success');

    // CAS received (sessionId, OLD hash, NEW hash, ISO expiry) — hashes only.
    const [sid, oldHashArg, newHashArg, expiryArg] = h.rotateRefreshTokenCas.mock.calls[0];
    expect(sid).toBe('sess-rot-success');
    expect(oldHashArg).toBe(sha256hex(oldToken));
    expect(oldHashArg).toMatch(/^[0-9a-f]{64}$/);
    expect(newHashArg).toBe(sha256hex(bundle!.refreshToken));
    expect(newHashArg).toMatch(/^[0-9a-f]{64}$/);
    expect(expiryArg).toMatch(/^\d{4}-\d{2}-\d{2}T/);
    // The raw NEW token must never be the CAS argument (hash-only contract).
    expect(newHashArg).not.toBe(bundle!.refreshToken);

    // Successor hash was recorded as spent + audit line written.
    expect(h.markRefreshTokenSpent).toHaveBeenCalledWith('sess-rot-success', sha256hex(oldToken));
    expect(h.logAuthAction).toHaveBeenCalledWith('user-1', 'session_refresh', expect.objectContaining({ sessionId: 'sess-rot-success' }));
    // A healthy rotation NEVER touches the family-revocation path.
    expect(h.revokeSessionFamily).not.toHaveBeenCalled();
    expect(h.revokeAllUserSessions).not.toHaveBeenCalled();
  });

  it('mints a session-bound access token (sid) on rotation (AUTH-03 tie-in)', async () => {
    h.getSessionByRefreshToken.mockResolvedValue(sessionFixture('sess-rot-at'));
    h.rotateRefreshTokenCas.mockResolvedValue('rotated');
    const bundle = await AuthService.rotateRefreshToken('rot-at-token-002', 'UA', 'ip');
    const decoded: any = AuthService.verifyAccessToken(bundle!.accessToken);
    expect(decoded.sid).toBe('sess-rot-at');
    expect(typeof decoded.jti).toBe('string');
    expect(isTokenRevocationCheckable(decoded)).toBe(true);
  });

  it('CAS stale (concurrent refresh lost the race) = REUSE: revokes the family, issues NO tokens', async () => {
    h.getSessionByRefreshToken.mockResolvedValue(sessionFixture('sess-rot-race'));
    h.rotateRefreshTokenCas.mockResolvedValue('stale');

    const result = await AuthService.rotateRefreshToken('rot-race-token-003', 'UA', 'ip');
    expect(result).toBeNull();
    expect(h.revokeSessionFamily).toHaveBeenCalledWith('sess-rot-race');
    expect(h.logAuthAction).toHaveBeenCalledWith('user-1', 'refresh_token_reuse', expect.objectContaining({ sessionId: 'sess-rot-race' }));
    // The loser must not record spends or mint tokens.
    expect(h.markRefreshTokenSpent).not.toHaveBeenCalled();
  });

  it('REPLAY of a spent token (lookup miss + issued-history hit) = REUSE: family revoked', async () => {
    // First: a successful rotation seeds the issued-token history.
    h.getSessionByRefreshToken.mockResolvedValue(sessionFixture('sess-replay'));
    h.rotateRefreshTokenCas.mockResolvedValue('rotated');
    const bundle = await AuthService.rotateRefreshToken('replay-old-token-004', 'UA', 'ip');
    expect(bundle).not.toBeNull();

    // Then the OLD token is replayed after it was rotated away: the live
    // lookup misses (hash superseded), the issued-history hit resolves the
    // family → revokeSessionFamily + audit, and NO new tokens are minted.
    h.getSessionByRefreshToken.mockResolvedValue(undefined);
    h.isRefreshTokenSpent.mockResolvedValue(true);
    h.revokeSessionFamily.mockClear();
    h.logAuthAction.mockClear();
    h.markRefreshTokenSpent.mockClear();

    const replay = await AuthService.rotateRefreshToken('replay-old-token-004', 'UA', 'ip');
    expect(replay).toBeNull();
    expect(h.revokeSessionFamily).toHaveBeenCalledWith('sess-replay');
    expect(h.logAuthAction).toHaveBeenCalledWith('user-1', 'refresh_token_reuse', expect.objectContaining({ sessionId: 'sess-replay', spent: true }));
    // The replay must NOT mint/mark anything — rejection only.
    expect(h.markRefreshTokenSpent).not.toHaveBeenCalled();
  });

  it('REPLAY of the stale SUCCESSOR hash (session revoked after family revoke) is also REUSE', async () => {
    h.getSessionByRefreshToken.mockResolvedValue(sessionFixture('sess-stale-cur'));
    h.rotateRefreshTokenCas.mockResolvedValue('rotated');
    const bundle = await AuthService.rotateRefreshToken('stale-cur-old-005', 'UA', 'ip');
    expect(bundle).not.toBeNull();

    h.getSessionByRefreshToken.mockResolvedValue(undefined); // family now revoked → lookup misses
    h.isRefreshTokenSpent.mockResolvedValue(false);          // not a spent hash — a STALE current one
    h.revokeSessionFamily.mockClear();
    h.logAuthAction.mockClear();

    const again = await AuthService.rotateRefreshToken(bundle!.refreshToken, 'UA', 'ip');
    expect(again).toBeNull();
    expect(h.revokeSessionFamily).toHaveBeenCalledWith('sess-stale-cur');
    expect(h.logAuthAction).toHaveBeenCalledWith('user-1', 'refresh_token_reuse', expect.objectContaining({ spent: false }));
  });

  it('unknown (never-issued) token: plain reject — no revocation, no tokens', async () => {
    h.getSessionByRefreshToken.mockResolvedValue(undefined);
    const result = await AuthService.rotateRefreshToken('never-issued-token-006', 'UA', 'ip');
    expect(result).toBeNull();
    expect(h.revokeSessionFamily).not.toHaveBeenCalled();
    expect(h.logAuthAction).not.toHaveBeenCalled();
  });

  it("CAS 'not-found' (session vanished) = plain 401-equivalent failure, no reuse handling", async () => {
    h.getSessionByRefreshToken.mockResolvedValue(sessionFixture('sess-gone'));
    h.rotateRefreshTokenCas.mockResolvedValue('not-found');
    const result = await AuthService.rotateRefreshToken('not-found-token-007', 'UA', 'ip');
    expect(result).toBeNull();
    expect(h.revokeSessionFamily).not.toHaveBeenCalled();
    expect(h.markRefreshTokenSpent).not.toHaveBeenCalled();
  });

  it('absolute 30-day session cap still wipes user sessions (OWASP Session CS, unchanged)', async () => {
    const old = new Date(); old.setDate(old.getDate() - 31);
    h.getSessionByRefreshToken.mockResolvedValue(sessionFixture('sess-cap', { createdAt: old.toISOString() }));
    const result = await AuthService.rotateRefreshToken('cap-token-008', 'UA', 'ip');
    expect(result).toBeNull();
    expect(h.revokeAllUserSessions).toHaveBeenCalledWith('user-1');
    expect(h.rotateRefreshTokenCas).not.toHaveBeenCalled();
  });

  it('naturally expired refresh token is rejected (pre-existing full-wipe semantics)', async () => {
    const past = new Date(); past.setDate(past.getDate() - 1);
    h.getSessionByRefreshToken.mockResolvedValue(sessionFixture('sess-exp', { expiresAt: past.toISOString() }));
    const result = await AuthService.rotateRefreshToken('expired-token-009', 'UA', 'ip');
    expect(result).toBeNull();
    expect(h.revokeAllUserSessions).toHaveBeenCalledWith('user-1');
    expect(h.rotateRefreshTokenCas).not.toHaveBeenCalled();
  });

  it('banned account cannot rotate (no CAS, no tokens)', async () => {
    const in3days = new Date(); in3days.setDate(in3days.getDate() + 3);
    h.getSessionByRefreshToken.mockResolvedValue(sessionFixture('sess-banned'));
    h.getUserById.mockResolvedValue({ ...USER, isBanned: true, bannedUntil: in3days.toISOString(), banReason: 'test' });
    const result = await AuthService.rotateRefreshToken('banned-token-010', 'UA', 'ip');
    expect(result).toBeNull();
    expect(h.rotateRefreshTokenCas).not.toHaveBeenCalled();
  });

  it('issueSession: access token is session-bound and the issued refresh hash is indexed for reuse detection', async () => {
    h.createSession.mockImplementation(async (s: any) => s);
    const bundle = await AuthService.issueSession(USER, 'UA', '1.2.3.4');

    const decoded: any = AuthService.verifyAccessToken(bundle.accessToken);
    expect(decoded.sid).toBe(bundle.sessionId);
    expect(typeof decoded.jti).toBe('string');
    expect(decoded.auth_time).toBeLessThanOrEqual(nowSec());
    expect(isTokenRevocationCheckable(decoded)).toBe(true);

    // Simulate the session row being revoked, then the issued token replayed:
    // history hit → family revocation (reuse detection covers fresh logins too).
    h.getSessionByRefreshToken.mockResolvedValue(undefined);
    h.isRefreshTokenSpent.mockResolvedValue(true);
    h.revokeSessionFamily.mockClear();
    const replay = await AuthService.rotateRefreshToken(bundle.refreshToken, 'UA', 'ip');
    expect(replay).toBeNull();
    expect(h.revokeSessionFamily).toHaveBeenCalledWith(bundle.sessionId);
  });
});

/* ════════════════════════ AUTH-05 — scoped media tokens ══════════════════════ */
describe('AUTH-05: audience-scoped media tokens', () => {
  const claims = { userId: 'u1', username: 'alice', displayName: 'Alice' };

  it('media tokens carry aud:"media" AND purpose:"media" and pass the scoped guard', () => {
    const mt = AuthService.generateMediaToken(claims);
    const decoded: any = AuthService.verifyAccessToken(mt);
    expect(decoded.aud).toBe('media');
    expect(decoded.purpose).toBe('media');
    expect(isScopedMediaTokenPayload(decoded)).toBe(true);
    expect(AuthService.isScopedMediaToken(decoded)).toBe(true);
    // Legacy purpose-only guard still accepts it (server.ts query-string gate).
    expect(AuthService.isMediaToken(decoded)).toBe(true);
  });

  it('optional resource binding survives a verify round-trip (and is absent when not requested)', () => {
    const scoped = AuthService.generateMediaToken(claims, { resourceType: 'attachment', resourceId: 'att-42' });
    const decoded: any = AuthService.verifyAccessToken(scoped);
    expect(decoded.resourceType).toBe('attachment');
    expect(decoded.resourceId).toBe('att-42');

    const unscoped = AuthService.generateMediaToken(claims);
    const decoded2: any = AuthService.verifyAccessToken(unscoped);
    expect(decoded2.resourceType).toBeUndefined();
    expect(decoded2.resourceId).toBeUndefined();
  });

  it('verifyMediaToken returns a DISTINGUISHABLE ok result with the full payload', () => {
    const mt = AuthService.generateMediaToken(claims, { resourceType: 'avatar', resourceId: 'av-1' });
    const r = AuthService.verifyMediaToken(mt);
    expect(r.ok).toBe(true);
    expect((r as any).payload.userId).toBe('u1');
    expect((r as any).payload.resourceId).toBe('av-1');
    expect((r as any).payload.aud).toBe('media');
  });

  it('an ACCESS token is never a media token: wrong-audience (this is the requireAuth Bearer rejection signal)', () => {
    const at = AuthService.generateAccessToken({ id: 'u1', username: 'alice', displayName: 'Alice' } as any);
    const r = AuthService.verifyMediaToken(at);
    expect(r).toEqual({ ok: false, reason: 'wrong-audience' });
    expect(isScopedMediaTokenPayload(AuthService.verifyAccessToken(at))).toBe(false);
    expect(AuthService.isMediaToken(AuthService.verifyAccessToken(at))).toBe(false);
  });

  it('verifyMediaToken distinguishes expired vs malformed vs wrong-audience', () => {
    // Signed with the dev-fallback secret (vitest does not load .env; prod
    // requires JWT_SECRET) — an expired media-shaped token:
    const DEV_SECRET = 'dirasha-development-secured-jwt-key-2026-core'; // gitleaks:allow (declared dev-fallback test fixture, documented in module header)
    const expired = jwt.sign({ userId: 'u1', username: 'a', displayName: 'a', purpose: 'media', aud: 'media' }, DEV_SECRET, { expiresIn: '-10s' });
    expect(AuthService.verifyMediaToken(expired)).toEqual({ ok: false, reason: 'expired' });

    // Right audience, but missing the purpose tag → not a valid media token:
    const audOnly = jwt.sign({ userId: 'u1', username: 'a', displayName: 'a', aud: 'media' }, DEV_SECRET, { expiresIn: '60s' });
    expect(AuthService.verifyMediaToken(audOnly)).toEqual({ ok: false, reason: 'wrong-audience' });

    // Garbage:
    expect(AuthService.verifyMediaToken('not-a-jwt')).toEqual({ ok: false, reason: 'invalid' });
  });

  it('isScopedMediaTokenPayload rejects non-media payloads and garbage (strict matrix)', () => {
    expect(isScopedMediaTokenPayload(null)).toBe(false);
    expect(isScopedMediaTokenPayload(undefined)).toBe(false);
    expect(isScopedMediaTokenPayload('media')).toBe(false);
    expect(isScopedMediaTokenPayload({})).toBe(false);
    expect(isScopedMediaTokenPayload({ aud: 'media' })).toBe(false);                 // missing purpose
    expect(isScopedMediaTokenPayload({ purpose: 'media' })).toBe(false);             // missing aud (legacy shape)
    expect(isScopedMediaTokenPayload({ aud: 'media', purpose: 'media' })).toBe(false); // missing userId
    expect(isScopedMediaTokenPayload({ aud: 'media', purpose: 'media', userId: '' })).toBe(false);
    expect(isScopedMediaTokenPayload({ aud: 'access', purpose: 'media', userId: 'u1' })).toBe(false);
    const ok = { aud: 'media', purpose: 'media', userId: 'u1' } as unknown as ScopedMediaTokenPayload;
    expect(isScopedMediaTokenPayload(ok)).toBe(true);
  });

  it('media tokens keep the 120s short lifetime', () => {
    const mt = AuthService.generateMediaToken(claims);
    const decoded: any = AuthService.verifyAccessToken(mt);
    expect(decoded.exp - decoded.iat).toBeLessThanOrEqual(120);
  });
});

/* ════════════════════════ AUTH-03 — jti/auth_time claims ═════════════════════ */
describe('AUTH-03: jti + auth_time on access tokens (revocation-checkable groundwork)', () => {
  it('every access token carries a UUID jti and an issuance-time auth_time', () => {
    const before = nowSec();
    const at = AuthService.generateAccessToken({ id: 'u1', username: 'alice', displayName: 'Alice' } as any);
    const decoded: any = AuthService.verifyAccessToken(at);
    expect(decoded.jti).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/);
    expect(decoded.auth_time).toBeGreaterThanOrEqual(before);
    expect(decoded.auth_time).toBeLessThanOrEqual(nowSec());
    expect(decoded.iat).toBeLessThanOrEqual(decoded.auth_time + 1);
  });

  it('jti is unique per token', () => {
    const a: any = AuthService.verifyAccessToken(AuthService.generateAccessToken({ id: 'u1', username: 'a', displayName: 'a' } as any));
    const b: any = AuthService.verifyAccessToken(AuthService.generateAccessToken({ id: 'u1', username: 'a', displayName: 'a' } as any));
    expect(a.jti).not.toBe(b.jti);
  });

  it('isTokenRevocationCheckable requires BOTH jti and sid (fail-closed for legacy tokens)', () => {
    expect(isTokenRevocationCheckable({ jti: 'x', sid: 's' })).toBe(true);
    expect(isTokenRevocationCheckable({ jti: 'x' })).toBe(false);          // no session claim
    expect(isTokenRevocationCheckable({ sid: 's' })).toBe(false);          // no jti
    expect(isTokenRevocationCheckable({ jti: '', sid: 's' })).toBe(false);
    expect(isTokenRevocationCheckable({ jti: 'x', sid: '' })).toBe(false);
    expect(isTokenRevocationCheckable(null)).toBe(false);
    expect(isTokenRevocationCheckable('token')).toBe(false);
    expect(isTokenRevocationCheckable(undefined)).toBe(false);
  });
});

/* ══════════════════ AUTH-02 — passkey UV + step-up (unit) ════════════════════ */
describe('AUTH-02: isFreshAuthEvent (step-up freshness policy)', () => {
  const now = 1_800_000_000_000;
  const sec = (ms: number) => Math.floor(ms / 1000);

  it('auth_time within the 5-minute window is fresh (preferred signal)', () => {
    expect(isFreshAuthEvent({ auth_time: sec(now - 10_000) }, now)).toBe(true);
    expect(isFreshAuthEvent({ auth_time: sec(now - STEP_UP_FRESH_WINDOW_MS + 1000) }, now)).toBe(true);
  });

  it('iat fallback (pre-AUTH-03 tokens) is honored with identical semantics', () => {
    expect(isFreshAuthEvent({ iat: sec(now - 10_000) }, now)).toBe(true);
    expect(isFreshAuthEvent({ iat: sec(now - 400_000) }, now)).toBe(false);
  });

  it('exactly at the window edge is fresh; one second older is not', () => {
    expect(isFreshAuthEvent({ auth_time: sec(now - STEP_UP_FRESH_WINDOW_MS) }, now)).toBe(true);
    expect(isFreshAuthEvent({ auth_time: sec(now - STEP_UP_FRESH_WINDOW_MS - 2_000) }, now)).toBe(false);
  });

  it('future timestamps beyond the 30s skew tolerance are never fresh', () => {
    expect(isFreshAuthEvent({ auth_time: sec(now + 5_000) }, now)).toBe(true);   // tiny skew OK
    expect(isFreshAuthEvent({ auth_time: sec(now + 120_000) }, now)).toBe(false); // forged future
    expect(isFreshAuthEvent({ iat: sec(now + 120_000) }, now)).toBe(false);
  });

  it('missing, malformed or non-positive claims fail closed', () => {
    expect(isFreshAuthEvent(null, now)).toBe(false);
    expect(isFreshAuthEvent(undefined, now)).toBe(false);
    expect(isFreshAuthEvent({}, now)).toBe(false);
    expect(isFreshAuthEvent({ auth_time: 'garbage' }, now)).toBe(false);
    expect(isFreshAuthEvent({ auth_time: 0 }, now)).toBe(false);
    expect(isFreshAuthEvent({ auth_time: -5 }, now)).toBe(false);
    expect(isFreshAuthEvent({ iat: NaN }, now)).toBe(false);
  });
});

/* ═══════════════════ AUTH-02 — passkey routes (behavioral) ═══════════════════ */
describe('AUTH-02: passkey routes — userVerification required + step-up gate', () => {
  type RouteRec = { method: string; path: string; args: any[] };
  let routes: RouteRec[];
  let registerPasskeyRoutes: any;
  /** JWT claims the requireAuth stub injects (per-test). */
  let currentClaims: Record<string, unknown> | null;
  const STEP_UP_PASSWORD = 'StepUp-Password-99';
  let passwordHash = '';

  const handler = (method: string, path: string): any => {
    const rec = routes.find((r) => r.method === method && r.path === path);
    expect(rec, `${method} ${path} must be registered`).toBeDefined();
    return rec!.args[rec!.args.length - 1];
  };

  const makeReq = (overrides: Record<string, unknown> = {}): any => ({
    method: 'POST',
    headers: { origin: 'https://localhost:3000', host: 'localhost:3000' },
    body: {},
    query: {},
    params: {},
    user: currentClaims,
    ...overrides,
  });

  const makeRes = (): any => ({
    statusCode: 0,
    body: null as any,
    headers: {} as Record<string, string>,
    status(code: number) { this.statusCode = code; return this; },
    json(payload: any) { this.body = payload; return this; },
    cookie(name: string, value: string, opts: any) { this.headers[`set-${name}`] = value; return this; },
  });

  /** Drives register-options first so the one-time registration challenge exists. */
  const seedRegistrationChallenge = async (userId = 'user-1') => {
    currentClaims = { userId, iat: nowSec() };
    await handler('POST', '/api/auth/passkeys/register-options')(makeReq(), makeRes(), () => {});
  };

  /**
   * register-verify call WITHOUT seeding a challenge — the challenge store is
   * module state, so the first call drains any leftover from earlier tests and
   * the SECOND call is guaranteed challenge-less. Used to isolate the step-up
   * signal: when step-up passes, the flow dies at challenge consumption with
   * the 401 'انتهت صلاحية جلسة التسجيل' message (never the step-up message).
   */
  const verifyWithoutChallenge = async (body: Record<string, unknown>) => {
    await handler('POST', '/api/auth/passkeys/register-verify')(makeReq({ body }), makeRes(), () => {});
    const res = makeRes();
    await handler('POST', '/api/auth/passkeys/register-verify')(makeReq({ body }), res, () => {});
    return res;
  };

  beforeAll(async () => {
    ({ registerPasskeyRoutes } = await import('../src/server/routes/passkeys.ts'));
    passwordHash = await hashSecret(STEP_UP_PASSWORD); // real peppered scrypt v2 hash
  });

  beforeEach(() => {
    vi.clearAllMocks();
    routes = [];
    const app: any = {
      get: (p: string, ...args: any[]) => routes.push({ method: 'GET', path: p, args }),
      post: (p: string, ...args: any[]) => routes.push({ method: 'POST', path: p, args }),
      delete: (p: string, ...args: any[]) => routes.push({ method: 'DELETE', path: p, args }),
    };
    registerPasskeyRoutes(app, {
      requireAuth: (req: any, _res: any, next: any) => { req.user = currentClaims; next(); },
      checkLimit: async () => false,
    });
    h.logAuthAction.mockResolvedValue(undefined);
    h.updateUser.mockResolvedValue(undefined);
    h.createSession.mockImplementation(async (s: any) => s);
    h.getUserById.mockResolvedValue(USER);
    h.getUserSecrets.mockResolvedValue({ passwordHash });
    h.poolQuery.mockResolvedValue({ rowCount: 1, rows: [] });
    // Deterministic library-mock defaults: success tests override below.
    h.generateRegistrationOptions.mockResolvedValue({ challenge: 'CHALLENGE-OPTS', excludeCredentials: [] });
    h.verifyRegistrationResponse.mockResolvedValue({ verified: false });
    // Fresh-but-legacy claims by default (iat only — pre-AUTH-03 tokens must pass too).
    currentClaims = { userId: 'user-1', iat: nowSec() - 10 };
  });

  it('register-options pins userVerification:"required" (AUTH-02)', async () => {
    const res = makeRes();
    await handler('POST', '/api/auth/passkeys/register-options')(makeReq(), res, () => {});
    expect(res.statusCode).toBe(200);
    expect(h.generateRegistrationOptions).toHaveBeenCalledWith(expect.objectContaining({
      authenticatorSelection: expect.objectContaining({ userVerification: 'required' }),
    }));
    expect(res.body.challenge).toBe('CHALLENGE-OPTS');
  });

  it('register-verify enforces requireUserVerification:true at the library verify boundary', async () => {
    await seedRegistrationChallenge();
    h.verifyRegistrationResponse.mockResolvedValue({
      verified: true,
      registrationInfo: {
        credential: { id: 'CRED-1234567890abcdef', publicKey: new Uint8Array([1, 2, 3]), counter: 5, transports: ['internal'] },
        credentialDeviceType: 'singleDevice',
      },
    });
    const res = makeRes();
    await handler('POST', '/api/auth/passkeys/register-verify')(
      makeReq({ body: { response: { id: 'resp-1', response: {} } } }),
      res,
      () => {},
    );
    expect(h.verifyRegistrationResponse).toHaveBeenCalledWith(expect.objectContaining({ requireUserVerification: true }));
    expect(res.statusCode).toBe(200);
  });

  it('register-verify success writes the AUTH-02 audit line (truncated credential id + device class)', async () => {
    await seedRegistrationChallenge();
    h.verifyRegistrationResponse.mockResolvedValue({
      verified: true,
      registrationInfo: {
        credential: { id: 'CRED-1234567890abcdef', publicKey: new Uint8Array([1, 2, 3]), counter: 5, transports: ['internal'] },
        credentialDeviceType: 'singleDevice',
      },
    });
    const res = makeRes();
    await handler('POST', '/api/auth/passkeys/register-verify')(
      makeReq({ body: { response: { id: 'resp-1', response: {} } } }),
      res,
      () => {},
    );
    expect(res.statusCode).toBe(200);
    expect(res.body.ok).toBe(true);
    // Credential INSERT reached the store…
    expect(h.poolQuery).toHaveBeenCalledWith(expect.stringMatching(/INSERT INTO webauthn_credentials/), expect.anything());
    // …and the audit trail carries no full credential id (truncated) + device class.
    expect(h.logAuthAction).toHaveBeenCalledWith('user-1', 'passkey_registered', expect.objectContaining({
      credentialId: 'CRED-1234567890abcdef'.slice(0, 16),
      deviceType: 'singleDevice',
    }));
  });

  it('register-verify with a STALE token (11 min) and NO password → step-up 401 BEFORE any WebAuthn work', async () => {
    currentClaims = { userId: 'user-1', iat: nowSec() - 660 };
    const res = makeRes();
    await handler('POST', '/api/auth/passkeys/register-verify')(
      makeReq({ body: { response: { id: 'resp-1', response: {} } } }),
      res,
      () => {},
    );
    expect(res.statusCode).toBe(401);
    expect(res.body.error).toContain('تحققاً حديثاً');
    expect(h.verifyRegistrationResponse).not.toHaveBeenCalled();
    expect(h.poolQuery).not.toHaveBeenCalled();
    // Denied step-ups are audit-logged (best-effort pattern).
    expect(h.logAuthAction).toHaveBeenCalledWith('user-1', 'passkey_stepup_denied', expect.objectContaining({ ip: expect.any(String) }));
  });

  it('register-verify step-up PASSES on fresh auth_time (no password needed)', async () => {
    // Fresh AUTH-03 auth_time token; challenge drained by verifyWithoutChallenge.
    currentClaims = { userId: 'user-1', auth_time: nowSec() - 30 };
    const res = await verifyWithoutChallenge({ response: { id: 'resp-1', response: {} } });
    // 401 with the CHALLENGE message (not the step-up message) proves step-up
    // passed and the flow reached one-time challenge consumption.
    expect(res.statusCode).toBe(401);
    expect(res.body.error).toContain('انتهت صلاحية جلسة التسجيل');
    expect(res.body.error).not.toContain('تحققاً حديثاً');
  });

  it('register-verify step-up FALLBACK: stale token + CORRECT body.password (real peppered scrypt verify)', async () => {
    currentClaims = { userId: 'user-1', iat: nowSec() - 660 };
    const res = await verifyWithoutChallenge({ password: STEP_UP_PASSWORD, response: { id: 'resp-1', response: {} } });
    // Password re-verification succeeded → step-up passed → next gate is the
    // (drained) challenge, NOT the step-up error.
    expect(res.statusCode).toBe(401);
    expect(res.body.error).toContain('انتهت صلاحية جلسة التسجيل');
    expect(res.body.error).not.toContain('تحققاً حديثاً');
    expect(h.getUserSecrets).toHaveBeenCalledWith('user-1');
  });

  it('register-verify step-up fallback with a WRONG password → 401 step-up error', async () => {
    currentClaims = { userId: 'user-1', iat: nowSec() - 660 };
    const res = makeRes();
    await handler('POST', '/api/auth/passkeys/register-verify')(
      makeReq({ body: { password: 'Wrong-Password-99', response: { id: 'resp-1', response: {} } } }),
      res,
      () => {},
    );
    expect(res.statusCode).toBe(401);
    expect(res.body.error).toContain('تحققاً حديثاً');
    expect(h.verifyRegistrationResponse).not.toHaveBeenCalled();
  });

  it('register-verify step-up FAILS CLOSED when the account has no password hash (OTP-era)', async () => {
    currentClaims = { userId: 'user-1', iat: nowSec() - 660 };
    h.getUserSecrets.mockResolvedValue({}); // no passwordHash on record
    const res = makeRes();
    await handler('POST', '/api/auth/passkeys/register-verify')(
      makeReq({ body: { password: 'Whatever-123', response: { id: 'resp-1', response: {} } } }),
      res,
      () => {},
    );
    expect(res.statusCode).toBe(401);
    expect(res.body.error).toContain('تحققاً حديثاً');
  });

  it('credential DELETE requires step-up: stale token without password is rejected before any deletion', async () => {
    currentClaims = { userId: 'user-1', iat: nowSec() - 660 };
    h.poolQuery.mockClear();
    const res = makeRes();
    await handler('DELETE', '/api/auth/passkeys/:credentialId')(
      makeReq({ method: 'DELETE', params: { credentialId: 'CRED-XYZ' } }),
      res,
      () => {},
    );
    expect(res.statusCode).toBe(401);
    expect(res.body.error).toContain('تحققاً حديثاً');
    expect(h.poolQuery).not.toHaveBeenCalled(); // nothing was deleted
  });

  it('credential DELETE proceeds with a fresh token (and audits passkey_removed)', async () => {
    currentClaims = { userId: 'user-1', auth_time: nowSec() - 30 };
    const res = makeRes();
    await handler('DELETE', '/api/auth/passkeys/:credentialId')(
      makeReq({ method: 'DELETE', params: { credentialId: 'CRED-XYZ' } }),
      res,
      () => {},
    );
    expect(res.statusCode).toBe(200);
    expect(res.body.ok).toBe(true);
    expect(h.poolQuery).toHaveBeenCalledWith(expect.stringMatching(/DELETE FROM webauthn_credentials/), expect.anything());
    expect(h.logAuthAction).toHaveBeenCalledWith('user-1', 'passkey_removed', expect.anything());
  });

  it('credential DELETE with a stale token + CORRECT password re-verification succeeds', async () => {
    currentClaims = { userId: 'user-1', iat: nowSec() - 660 };
    const res = makeRes();
    await handler('DELETE', '/api/auth/passkeys/:credentialId')(
      makeReq({ method: 'DELETE', params: { credentialId: 'CRED-XYZ' }, body: { password: STEP_UP_PASSWORD } }),
      res,
      () => {},
    );
    expect(res.statusCode).toBe(200);
    expect(res.body.ok).toBe(true);
  });

  it('register-verify with fresh claims but a MISSING WebAuthn response body → 400 (step-up already passed)', async () => {
    const res = makeRes();
    await handler('POST', '/api/auth/passkeys/register-verify')(makeReq({ body: {} }), res, () => {});
    expect(res.statusCode).toBe(400);
    expect(res.body.error).not.toContain('تحققاً حديثاً');
  });
});

/* ── Restore any globals touched by the module graph (defensive parity) ─────── */
afterAll(() => {
  vi.restoreAllMocks();
});
