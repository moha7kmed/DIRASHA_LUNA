// Lists ONLY the KEY NAMES present in .env (never prints values).
import fs from 'fs';
import path from 'path';

const envPath = path.join(process.cwd(), '.env');
if (!fs.existsSync(envPath)) {
  console.log('NO .env FILE');
  process.exit(0);
}
const lines = fs.readFileSync(envPath, 'utf8').split(/\r?\n/);
for (const line of lines) {
  const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)$/);
  if (!m) continue;
  const [, key, rawVal] = m;
  let val = rawVal.trim();
  let state = 'EMPTY';
  if (val) {
    if (/^postgres(ql)?:\/\//i.test(val)) {
      try {
        const u = new URL(val);
        state = `set (host=${u.hostname} port=${u.port || '5432'} db=${u.pathname.replace('/', '')} user=${u.username} pass=${u.password ? 'YES' : 'NO'})`;
      } catch { state = 'set (unparsable url)'; }
    } else if (val.length > 12 && /^[A-Za-z0-9_\-+/=.]+$/.test(val)) {
      state = `set (${val.length} chars, masked)`;
    } else {
      state = `set (${val.length} chars)`;
    }
  }
  console.log(`${key} :: ${state}`);
}
