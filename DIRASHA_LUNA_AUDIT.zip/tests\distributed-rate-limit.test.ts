/**
 * Project 5 — Distributed Rate Limiting tests.
 *
 * Covers the Redis-backed atomic limiter in src/server/services/rate_limiter.ts:
 *   1. Atomicity/concurrency: N parallel check() calls across SIMULATED
 *      instances (separate DistributedRateLimiter objects sharing one mock
 *      Redis) never exceed the limit — with limit 10 and 100 parallel hits,
 *      exactly 10 are allowed.
 *   2. Distributed sharing: two instances share the same counter.
 *   3. Failure semantics: Redis outage → critical rules FAIL CLOSED (deny +
 *      loud log), throughput rules degrade to the local Map (loud log).
 *   4. Window reset: counters expire after the window (TTL semantics).
 *   5. Central table invariants: every rule has limit/window/class, values
 *      match the tuned production values.
 *
 * The mock Redis implements the SAME semantics as the production Lua script
 * (INCR + PEXPIRE-on-first + compare) atomically on the JS event loop —
 * JS's single-threaded execution of the check body guarantees no
 * read-then-write race, mirroring Redis's serial script execution.
 *
 * Run: npx vitest run tests/distributed-rate-limit.test.ts
 */
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import {
  DistributedRateLimiter,
  RATE_LIMIT_RULES,
  RATE_LIMIT_LUA,
  type RateLimitRedisAdapter,
} from '../src/server/services/rate_limiter.ts';

/**
 * Atomic in-memory Redis mock. Implements exactly the production script's
 * semantics: INCR, PEXPIRE only on the first hit, compare against limit.
 */
class MockRedis implements RateLimitRedisAdapter {
  private store = new Map<string, { count: number; expiresAt: number }>();
  public evalCalls = 0;

  /**
   * @param mode 'ok'           → evalAtomic works (Redis healthy)
   *             'down'         → configured via env but UNREACHABLE (outage):
   *                              evalAtomic resolves null (failure semantics path)
   *             'unconfigured' → no REDIS_URL/REDIS_HOST (single-node mode)
   */
  constructor(private mode: 'ok' | 'down' | 'unconfigured' = 'ok') {}

  getIsConfigured(): boolean {
    return this.mode !== 'unconfigured';
  }

  getIsConnected(): boolean {
    return this.mode === 'ok';
  }

  /** Same shape as RedisClusterClient.evalAtomic. Never rejects. */
  async evalAtomic(script: string, keys: string[], args: (string | number)[]): Promise<string | null> {
    if (this.mode === 'down') return null;
    if (this.mode !== 'ok') return null;
    if (script !== RATE_LIMIT_LUA) {
      throw new Error(`MockRedis only understands RATE_LIMIT_LUA (got: ${script.slice(0, 40)}...)`);
    }
    this.evalCalls++;
    const key = keys[0];
    const windowMs = Number(args[0]);
    const limit = Number(args[1]);
    const now = Date.now();

    let bucket = this.store.get(key);
    if (!bucket || bucket.expiresAt <= now) {
      bucket = { count: 1, expiresAt: now + windowMs };
      this.store.set(key, bucket);
    } else {
      bucket.count++;
    }
    return bucket.count > limit ? '1' : '0';
  }

  /** Mock-only: TTL survival check (restart simulation = recreate the limiter). */
  getRaw(key: string): { count: number; expiresAt: number } | undefined {
    return this.store.get(key);
  }
}

describe('DistributedRateLimiter — atomicity & concurrency', () => {
  let redis: MockRedis;

  beforeEach(() => {
    redis = new MockRedis();
  });

  it('100 parallel check() calls with limit 10 → exactly 10 allowed (single instance)', async () => {
    const limiter = new DistributedRateLimiter(redis);
    // Fire 100 parallel hits at 'e2ee:prekeys' (limit 10) and count outcomes.
    const results = await Promise.all(
      Array.from({ length: 100 }, () => limiter.check('e2ee:prekeys', 'user-1')), // limit 10
    );
    const denied = results.filter(Boolean).length;
    const allowed = results.filter((r) => !r).length;
    expect(RATE_LIMIT_RULES['e2ee:prekeys'].limit).toBe(10);
    expect(allowed).toBe(10);
    expect(denied).toBe(90);
    expect(redis.evalCalls).toBe(100);
  });

  it('100 parallel calls across simulated instances share one counter → exactly 10 allowed', async () => {
    // Simulate 3 separate server processes: separate limiter objects, ONE Redis.
    const limiters = [
      new DistributedRateLimiter(redis),
      new DistributedRateLimiter(redis),
      new DistributedRateLimiter(redis),
    ];
    const tasks: Promise<boolean>[] = [];
    for (let i = 0; i < 100; i++) {
      const limiter = limiters[i % 3];
      tasks.push(limiter.check('e2ee:prekeys', 'user-1'));
    }
    const results = await Promise.all(tasks);
    const allowed = results.filter((r) => !r).length;
    expect(allowed).toBe(10);
  });

  it('different keys do not share buckets; same key across rules is isolated', async () => {
    const limiter = new DistributedRateLimiter(redis);
    // Drain the 10-allowed budget for one key...
    for (let i = 0; i < 10; i++) expect(await limiter.check('e2ee:prekeys', 'user-2')).toBe(false);
    expect(await limiter.check('e2ee:prekeys', 'user-2')).toBe(true);
    // ...another key is untouched...
    expect(await limiter.check('e2ee:prekeys', 'user-3')).toBe(false);
    // ...and another RULE with the same key suffix is a different bucket.
    expect(await limiter.check('e2ee:register', 'user-2')).toBe(false);
  });

  it('window reset: the counter expires after windowMs (TTL semantics)', async () => {
    vi.useFakeTimers();
    try {
      const limiter = new DistributedRateLimiter(redis);
      for (let i = 0; i < 10; i++) expect(await limiter.check('e2ee:prekeys', 'user-4')).toBe(false);
      expect(await limiter.check('e2ee:prekeys', 'user-4')).toBe(true);
      // Advance past the 1-hour window → fresh window.
      vi.advanceTimersByTime(60 * 60 * 1000 + 1);
      expect(await limiter.check('e2ee:prekeys', 'user-4')).toBe(false);
    } finally {
      vi.useRealTimers();
    }
  });

  it('survives restart: a NEW limiter instance over the same Redis keeps counting', async () => {
    const first = new DistributedRateLimiter(redis);
    for (let i = 0; i < 10; i++) expect(await first.check('e2ee:prekeys', 'user-5')).toBe(false);
    first.dispose();
    // "Restart": brand-new limiter object, same Redis store.
    const second = new DistributedRateLimiter(redis);
    expect(await second.check('e2ee:prekeys', 'user-5')).toBe(true); // still over budget
  });
});

describe('DistributedRateLimiter — failure semantics (binding directive)', () => {
  let errorSpy: ReturnType<typeof vi.spyOn>;
  let warnSpy: ReturnType<typeof vi.spyOn>;

  beforeEach(() => {
    errorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
    warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
  });

  afterEach(() => {
    errorSpy.mockRestore();
    warnSpy.mockRestore();
  });

  it('critical rule + Redis outage → FAIL CLOSED (deny) with a loud error log', async () => {
    const limiter = new DistributedRateLimiter(new MockRedis('down'));
    const denied = await limiter.check('auth:login:ip', '1.2.3.4');
    expect(denied).toBe(true);
    expect(errorSpy).toHaveBeenCalledWith(expect.stringContaining('FAIL CLOSED'));
    expect(errorSpy).toHaveBeenCalledWith(expect.stringContaining('auth:login:ip'));
  });

  it('ALL critical rules fail closed on outage (no silent protection loss)', async () => {
    const limiter = new DistributedRateLimiter(new MockRedis('down'));
    const criticalRules = (Object.keys(RATE_LIMIT_RULES) as (keyof typeof RATE_LIMIT_RULES)[])
      .filter((r) => RATE_LIMIT_RULES[r].class === 'critical');
    expect(criticalRules.length).toBeGreaterThanOrEqual(11);
    for (const rule of criticalRules) {
      expect(await limiter.check(rule, 'victim-key')).toBe(true);
    }
    expect(errorSpy).toHaveBeenCalled();
  });

  it('throughput rule + Redis outage → local Map fallback (deny only past limit) with loud warn', async () => {
    const limiter = new DistributedRateLimiter(new MockRedis('down'));
    const results: boolean[] = [];
    for (let i = 0; i < 61; i++) results.push(await limiter.check('search:user', 'user-9'));
    // limit 60: first 60 allowed via local Map, the 61st denied.
    expect(results.filter((r) => r).length).toBe(1);
    expect(limiter.localBucketCount()).toBe(1);
    expect(warnSpy).toHaveBeenCalledWith(expect.stringContaining('local Map'));
    expect(errorSpy).not.toHaveBeenCalled();
  });

  it('Redis NOT configured → single-node mode uses the local Map for BOTH classes (warned once at startup)', async () => {
    const adapter: RateLimitRedisAdapter = {
      getIsConfigured: () => false,
      getIsConnected: () => false,
      evalAtomic: async () => null,
    };
    const limiter = new DistributedRateLimiter(adapter);
    expect(warnSpy).toHaveBeenCalledWith(expect.stringContaining('REDIS_URL/REDIS_HOST not configured'));
    // Critical: local Map enforces the limit (not fail-closed — not-configured
    // is a deployment mode, not an outage).
    for (let i = 0; i < 10; i++) expect(await limiter.check('e2ee:prekeys', 'u')).toBe(false);
    expect(await limiter.check('e2ee:prekeys', 'u')).toBe(true);
    warnSpy.mockClear();
  });

  it('Redis configured but evalAtomic throws → treated as outage (critical denies)', async () => {
    const adapter: RateLimitRedisAdapter = {
      getIsConfigured: () => true,
      getIsConnected: () => true,
      evalAtomic: async () => {
        throw new Error('connection reset');
      },
    };
    const limiter = new DistributedRateLimiter(adapter);
    expect(await limiter.check('auth:register:ip', '5.6.7.8')).toBe(true);
    expect(errorSpy).toHaveBeenCalledWith(expect.stringContaining('FAIL CLOSED'));
  });
});

describe('RATE_LIMIT_RULES — central table invariants', () => {
  it('every rule has a positive limit, windowMs, and a valid class', () => {
    for (const [name, rule] of Object.entries(RATE_LIMIT_RULES)) {
      expect(Number.isInteger(rule.limit), name).toBe(true);
      expect(rule.limit).toBeGreaterThan(0);
      expect(Number.isInteger(rule.windowMs), name).toBe(true);
      expect(rule.windowMs).toBeGreaterThan(0);
      expect(['critical', 'throughput']).toContain(rule.class);
    }
  });

  it('limit VALUES are unchanged from the tuned per-route values', () => {
    // Verbatim snapshots of the previously-inline production values.
    expect(RATE_LIMIT_RULES['auth:register:ip']).toMatchObject({ limit: 10, windowMs: 60 * 60 * 1000 });
    expect(RATE_LIMIT_RULES['auth:login:ip']).toMatchObject({ limit: 30, windowMs: 10 * 60 * 1000 });
    expect(RATE_LIMIT_RULES['auth:recover:ip']).toMatchObject({ limit: 8, windowMs: 60 * 60 * 1000 });
    expect(RATE_LIMIT_RULES['auth:recover:user']).toMatchObject({ limit: 5, windowMs: 30 * 60 * 1000 });
    expect(RATE_LIMIT_RULES['auth:passwordchange:user']).toMatchObject({ limit: 5, windowMs: 60 * 60 * 1000 });
    expect(RATE_LIMIT_RULES['auth:sessions:revoke']).toMatchObject({ limit: 10, windowMs: 60 * 60 * 1000 });
    expect(RATE_LIMIT_RULES['auth:sessions:revoke-others']).toMatchObject({ limit: 5, windowMs: 60 * 60 * 1000 });
    expect(RATE_LIMIT_RULES['auth:sessions:list']).toMatchObject({ limit: 30, windowMs: 60 * 1000 });
    expect(RATE_LIMIT_RULES['username:change']).toMatchObject({ limit: 3, windowMs: 60 * 60 * 1000 });
    expect(RATE_LIMIT_RULES['search:user']).toMatchObject({ limit: 60, windowMs: 60 * 1000 });
    expect(RATE_LIMIT_RULES['storage:presign']).toMatchObject({ limit: 60, windowMs: 60 * 60 * 1000 });
    expect(RATE_LIMIT_RULES['gdrive:share']).toMatchObject({ limit: 30, windowMs: 10 * 60 * 1000 });
    expect(RATE_LIMIT_RULES['storage:gdrive-ticket']).toMatchObject({ limit: 30, windowMs: 10 * 60 * 1000 });
    expect(RATE_LIMIT_RULES['e2ee:register']).toMatchObject({ limit: 30, windowMs: 60 * 60 * 1000 });
    expect(RATE_LIMIT_RULES['e2ee:bundle']).toMatchObject({ limit: 120, windowMs: 60 * 60 * 1000 });
    expect(RATE_LIMIT_RULES['e2ee:identity']).toMatchObject({ limit: 60, windowMs: 60 * 60 * 1000 });
    expect(RATE_LIMIT_RULES['e2ee:status']).toMatchObject({ limit: 30, windowMs: 60 * 1000 });
    expect(RATE_LIMIT_RULES['e2ee:prekeys']).toMatchObject({ limit: 10, windowMs: 60 * 60 * 1000 });
    expect(RATE_LIMIT_RULES['e2ee:bundlepeer']).toMatchObject({ limit: 10, windowMs: 10 * 60 * 1000 });
  });

  it('class assignment matches the security directive', () => {
    const critical: (keyof typeof RATE_LIMIT_RULES)[] = [
      'auth:login:ip', 'auth:register:ip', 'auth:recover:ip', 'auth:recover:user',
      'auth:passwordchange:user', 'auth:sessions:revoke', 'auth:sessions:revoke-others',
      'passkeys:register-verify', 'passkeys:login-verify', 'passkeys:login-options',
      'e2ee:register', 'e2ee:bundle', 'e2ee:prekeys', 'e2ee:bundlepeer',
      'export:data:user', 'auth:pin:change',
    ];
    for (const rule of critical) {
      expect(RATE_LIMIT_RULES[rule].class, rule).toBe('critical');
    }
    for (const rule of Object.keys(RATE_LIMIT_RULES) as (keyof typeof RATE_LIMIT_RULES)[]) {
      if (!critical.includes(rule)) {
        expect(RATE_LIMIT_RULES[rule].class, rule).toBe('throughput');
      }
    }
  });
});

/* ── F5: users-directory scrape budget (new rule added with the P1 fixes) ────── */
describe('F5 — users:directory:list (GET /api/users scrape budget)', () => {
  it('table entry: 30/min, throughput class', () => {
    expect(RATE_LIMIT_RULES['users:directory:list']).toMatchObject({
      limit: 30,
      windowMs: 60 * 1000,
      class: 'throughput',
    });
  });

  it('30 requests per window are allowed, the 31st is denied; buckets are per-user', async () => {
    const limiter = new DistributedRateLimiter(new MockRedis('ok'));
    for (let i = 0; i < 30; i++) {
      expect(await limiter.check('users:directory:list', 'dir-user-1')).toBe(false);
    }
    expect(await limiter.check('users:directory:list', 'dir-user-1')).toBe(true);
    // Another user gets their own independent bucket.
    expect(await limiter.check('users:directory:list', 'dir-user-2')).toBe(false);
  });

  it('Redis outage degrades to the local Map (throughput class), never silent', async () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    try {
      const limiter = new DistributedRateLimiter(new MockRedis('down'));
      for (let i = 0; i < 30; i++) expect(await limiter.check('users:directory:list', 'dir-outage')).toBe(false);
      expect(await limiter.check('users:directory:list', 'dir-outage')).toBe(true);
      expect(warnSpy).toHaveBeenCalledWith(expect.stringContaining('REDIS UNAVAILABLE'));
    } finally {
      warnSpy.mockRestore();
    }
  });
});
