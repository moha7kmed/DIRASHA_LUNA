/**
 * MEDIA-01 (external audit) — GDrive media proxy: bearer-capability links retired.
 *
 * Before: GET /api/media/gdrive(+/:fileId) had NO auth and NO membership check —
 * possession of the fileId WAS the authorization (an unauthenticated bearer
 * capability that kept working forever after a user left the chat), and
 * responses were cached 24h (private, max-age=86400).
 *
 * After: requireAuth on both routes (Bearer header OR short-lived media token
 * via ?access_token=) + a CURRENT chat-membership gate (db.getChatMembers on
 * the chat resolved from the attachments/messages lookup) + Cache-Control:
 * private, no-store. Fail-closed everywhere: missing chat, empty member list,
 * DB errors → 403.
 *
 * Test split (same constraint as tests/group-membership.test.ts — server.ts
 * boots the HTTP listener at import, so in-process route tests run against
 * registerStorageRoutes with a recording app + mocked db/gdrive modules):
 *
 *   1. BEHAVIORAL: registered media-route handlers with mocked db/pool/gdrive —
 *      members stream with private,no-store; removed members / empty lists /
 *      DB failures / chat-less rows fail closed with 403 BEFORE any upstream
 *      fetch or sender-storage access; unknown file → 404; bad id → 400.
 *   2. STATIC-SOURCE: requireAuth wired on both registrations, membership gate
 *      ordered BEFORE sender-storage/token/upstream work, no-store header,
 *      chat_id resolved by the lookup query.
 *
 * Run: npx vitest run tests/media-auth.test.ts
 */
import { describe, it, expect, vi, beforeAll, beforeEach } from 'vitest';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const storageSrc = fs.readFileSync(path.join(repoRoot, 'src/server/routes/storage.ts'), 'utf8');

/* ── Hoisted mock fns shared with the vi.mock factories ───────────────────── */
const h = vi.hoisted(() => ({
  poolQuery: vi.fn(),
  getChatMembers: vi.fn(),
  getUserStorage: vi.fn(),
  refreshAccessToken: vi.fn(),
  fetchMedia: vi.fn(),
}));

vi.mock('../src/server/database.ts', () => ({
  db: {
    getChatMembers: h.getChatMembers,
    getUserStorage: h.getUserStorage,
  },
  pool: { query: h.poolQuery },
}));

vi.mock('../src/server/services/gdrive.ts', () => ({
  isGdriveConfigured: () => true,
  GDRIVE_NOT_CONFIGURED: { error: 'GDRIVE_NOT_CONFIGURED' },
  buildAuthUrl: vi.fn(),
  consumeState: vi.fn(),
  exchangeCode: vi.fn(),
  refreshAccessToken: h.refreshAccessToken,
  buildGdriveCredentials: vi.fn(),
  ensureFolder: vi.fn(),
  invalidateGdriveCaches: vi.fn(),
  getDriveEmailHint: vi.fn(),
  requestAccessTokenForRefreshToken: vi.fn(),
  shareFileToAnyone: vi.fn(),
  fetchWithTimeout: h.fetchMedia,
}));

const FILE_ID = 'fileId-1234567890'; // matches ^[A-Za-z0-9_-]{10,}$
const CURRENT_USER = 'member-1';

/* ── Route registration capture (registerStorageRoutes against a fake app) ── */
type RouteRec = { method: string; path: string; args: any[] };
let routes: RouteRec[];
let requireAuthStub: any;
let registerStorageRoutes: any;

beforeAll(async () => {
  ({ registerStorageRoutes } = await import('../src/server/routes/storage.ts'));
});

beforeEach(() => {
  vi.clearAllMocks();
  routes = [];
  const app: any = {
    get: (p: string, ...args: any[]) => routes.push({ method: 'GET', path: p, args }),
    post: (p: string, ...args: any[]) => routes.push({ method: 'POST', path: p, args }),
    delete: (p: string, ...args: any[]) => routes.push({ method: 'DELETE', path: p, args }),
  };
  // Mirrors server.ts's requireAuth contract: sets req.user then next().
  requireAuthStub = vi.fn((req: any, _res: any, next: any) => {
    req.user = { userId: CURRENT_USER };
    next();
  });
  registerStorageRoutes(app, { requireAuth: requireAuthStub, checkLimit: async () => false });
});

function mediaRoute(pathSuffix: string): RouteRec {
  const rec = routes.find((r) => r.path === '/api/media/gdrive' + pathSuffix);
  expect(rec, `route /api/media/gdrive${pathSuffix} must be registered`).toBeDefined();
  return rec as RouteRec;
}

function makeReq(overrides: Record<string, unknown> = {}): any {
  return {
    method: 'GET',
    query: { id: FILE_ID },
    params: {},
    headers: {},
    user: { userId: CURRENT_USER },
    ...overrides,
  };
}

/** Minimal writable-ish response — pipe-compatible sink + header/status capture. */
function makeRes(): any {
  const res: any = {
    statusCode: 0,
    headers: {} as Record<string, string>,
    jsonBody: undefined as any,
    headersSent: false,
    ended: false,
    status(c: number) { res.statusCode = c; return res; },
    json(b: any) { res.jsonBody = b; return res; },
    setHeader(k: string, v: string) { res.headers[String(k).toLowerCase()] = v; },
    on() { return res; },
    once() { return res; },
    emit() { return true; },
    write() { return true; },
    end() { res.ended = true; return res; },
  };
  return res;
}

/** Mock Drive upstream response (one-chunk web stream; pipe completes). */
function upstreamMock(status = 200, contentType = 'application/octet-stream') {
  const body = new ReadableStream({
    start(c) { c.enqueue(new TextEncoder().encode('media-bytes')); c.close(); },
  });
  return {
    ok: status < 400,
    status,
    headers: { get: (k: string) => (String(k).toLowerCase() === 'content-type' ? contentType : null) },
    body,
  };
}

/** Full allow-path wiring: file row → chat-1 with CURRENT_USER as member. */
function happyPath(chatId = 'chat-1') {
  h.poolQuery.mockResolvedValue({ rows: [{ sender_id: 'sender-1', chat_id: chatId }] });
  h.getChatMembers.mockResolvedValue([{ chatId, userId: CURRENT_USER, joinedAt: '2026-01-01T00:00:00Z' }]);
  h.getUserStorage.mockResolvedValue({ isActive: true, provider: 'gdrive', credentialsEncrypted: 'enc-creds' });
  h.refreshAccessToken.mockResolvedValue('tok-123');
  h.fetchMedia.mockResolvedValue(upstreamMock());
}

/* ── 1. Behavioral: the registered media handlers themselves ──────────────── */

describe('media proxy handlers — auth + current-membership gate (MEDIA-01)', () => {
  it('both media routes are registered WITH requireAuth in the middleware chain', () => {
    for (const suffix of ['', '/:fileId']) {
      const rec = mediaRoute(suffix);
      expect(rec.method).toBe('GET');
      expect(rec.args, 'requireAuth must precede the handler').toContain(requireAuthStub);
      expect(rec.args[rec.args.length - 1]).toBeTypeOf('function');
    }
  });

  it('current member of the owning chat streams the file with Cache-Control: private, no-store', async () => {
    happyPath();
    const handler = mediaRoute('').args[mediaRoute('').args.length - 1];
    const res = makeRes();
    await handler(makeReq(), res);

    expect(res.statusCode).toBe(200);
    expect(res.headers['cache-control']).toBe('private, no-store');
    expect(res.headers['content-type']).toBe('application/octet-stream');
    expect(h.fetchMedia).toHaveBeenCalledTimes(1);
    const [url, init] = h.fetchMedia.mock.calls[0];
    expect(String(url)).toContain('/drive/v3/files/' + FILE_ID);
    expect(init.headers.Authorization).toBe('Bearer tok-123');
  });

  it('REMOVED member (not in the member list) → 403, denied BEFORE any upstream fetch or sender-storage access', async () => {
    happyPath();
    h.getChatMembers.mockResolvedValue([{ chatId: 'chat-1', userId: 'someone-else', joinedAt: 'x' }]);
    const handler = mediaRoute('').args[mediaRoute('').args.length - 1];
    const res = makeRes();
    await handler(makeReq(), res);

    expect(res.statusCode).toBe(403);
    expect(String(res.jsonBody?.error)).toContain('غير مصرح');
    expect(h.fetchMedia).not.toHaveBeenCalled();
    expect(h.getUserStorage).not.toHaveBeenCalled();
    expect(h.refreshAccessToken).not.toHaveBeenCalled();
  });

  it('empty member list → 403 (fail-closed)', async () => {
    happyPath();
    h.getChatMembers.mockResolvedValue([]);
    const handler = mediaRoute('').args[mediaRoute('').args.length - 1];
    const res = makeRes();
    await handler(makeReq(), res);
    expect(res.statusCode).toBe(403);
    expect(h.fetchMedia).not.toHaveBeenCalled();
  });

  it('getChatMembers DB failure → 403 (fail-closed, not 500/leak)', async () => {
    happyPath();
    h.getChatMembers.mockRejectedValue(new Error('db down'));
    const handler = mediaRoute('').args[mediaRoute('').args.length - 1];
    const res = makeRes();
    await handler(makeReq(), res);
    expect(res.statusCode).toBe(403);
    expect(h.fetchMedia).not.toHaveBeenCalled();
  });

  it('attachment row without a resolvable chat_id → 403 (fail-closed)', async () => {
    h.poolQuery.mockResolvedValue({ rows: [{ sender_id: 'sender-1', chat_id: null }] });
    h.getChatMembers.mockResolvedValue([{ chatId: 'chat-1', userId: CURRENT_USER, joinedAt: 'x' }]);
    const handler = mediaRoute('').args[mediaRoute('').args.length - 1];
    const res = makeRes();
    await handler(makeReq(), res);
    expect(res.statusCode).toBe(403);
    expect(h.getChatMembers).not.toHaveBeenCalled();
    expect(h.fetchMedia).not.toHaveBeenCalled();
  });

  it('unauthenticated request (no req.user) → 403 even if a member list arrives (fail-closed)', async () => {
    happyPath();
    const handler = mediaRoute('').args[mediaRoute('').args.length - 1];
    const res = makeRes();
    await handler(makeReq({ user: undefined }), res);
    expect(res.statusCode).toBe(403);
    expect(h.fetchMedia).not.toHaveBeenCalled();
  });

  it('unknown fileId (no attachment row) → 404', async () => {
    h.poolQuery.mockResolvedValue({ rows: [] });
    const handler = mediaRoute('').args[mediaRoute('').args.length - 1];
    const res = makeRes();
    await handler(makeReq(), res);
    expect(res.statusCode).toBe(404);
    expect(h.getChatMembers).not.toHaveBeenCalled();
    expect(h.fetchMedia).not.toHaveBeenCalled();
  });

  it('malformed fileId → 400 before any lookup', async () => {
    const handler = mediaRoute('').args[mediaRoute('').args.length - 1];
    const res = makeRes();
    await handler(makeReq({ query: { id: 'short' } }), res);
    expect(res.statusCode).toBe(400);
    expect(h.poolQuery).not.toHaveBeenCalled();
    expect(h.fetchMedia).not.toHaveBeenCalled();
  });

  it('param route /:fileId behaves identically (membership gate + no-store)', async () => {
    happyPath();
    const rec = mediaRoute('/:fileId');
    const handler = rec.args[rec.args.length - 1];
    const res = makeRes();
    await handler(makeReq({ query: {}, params: { fileId: FILE_ID } }), res);
    expect(res.statusCode).toBe(200);
    expect(res.headers['cache-control']).toBe('private, no-store');
    expect(h.getChatMembers).toHaveBeenCalledWith('chat-1');
    expect(h.fetchMedia).toHaveBeenCalledTimes(1);
  });
});

/* ── 2. Static-source asserts (boot-at-import server — repo convention) ───── */

describe('storage.ts wiring — requireAuth + membership gate + no-store (static)', () => {
  it('both media route registrations carry requireAuth', () => {
    expect(storageSrc).toContain("app.get('/api/media/gdrive', requireAuth,");
    expect(storageSrc).toContain("app.get('/api/media/gdrive/:fileId', requireAuth,");
  });

  it('authenticated media is no longer cached 24h — private, no-store only', () => {
    expect(storageSrc).toContain("headers['Cache-Control'] = 'private, no-store';");
    expect(storageSrc).not.toContain('max-age=86400');
  });

  it('membership gate runs BEFORE sender-storage/token/upstream work inside gdriveMediaHandler', () => {
    const block = storageSrc.slice(
      storageSrc.indexOf('const gdriveMediaHandler'),
      storageSrc.indexOf("app.get('/api/media/gdrive'"),
    );
    expect(block).toContain('db.getChatMembers(');
    expect(block).toContain('isCurrentChatMember(');
    expect(block).toContain('403');
    expect(block).toContain('غير مصرح');
    const idxMembers = block.indexOf('db.getChatMembers(');
    const idxStorage = block.indexOf('db.getUserStorage(att.senderId)');
    const idxToken = block.indexOf('refreshAccessToken(senderId');
    expect(idxMembers).toBeGreaterThan(-1);
    expect(idxStorage).toBeGreaterThan(idxMembers);
    expect(idxToken).toBeGreaterThan(idxStorage);
  });

  it('attachment lookup resolves the owning chat (m.chat_id) so membership can be enforced', () => {
    expect(storageSrc).toContain('m.chat_id AS chat_id');
    expect(storageSrc).toContain('function isCurrentChatMember(');
  });
});
