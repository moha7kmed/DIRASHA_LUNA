import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    build: {
      rollupOptions: {
        output: {
          // Split the framework runtime (react/react-dom) into its own chunk:
          // it changes only on dependency upgrades, so app-code deploys keep
          // hitting the cached vendor chunk. Feature code is split via
          // React.lazy() in src/App.tsx (async chunks per lazy component).
          manualChunks: {
            'react-vendor': ['react', 'react-dom', 'react-dom/client'],
          },
        },
      },
    },
    server: {
      // Conditional configuration for hot-module replacement and file observation
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
