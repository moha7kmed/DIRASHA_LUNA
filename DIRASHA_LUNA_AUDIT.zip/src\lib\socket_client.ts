/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import type { ClientToServerEvent, ServerToClientEvent, WSFrame } from '../types.ts';

type SocketSubscriber = (payload: any) => void;

export class RealTimeSocketClient {
  private ws: WebSocket | null = null;
  private url: string;
  private token: string | null = null;
  
  // Connection state trackers
  private isConnecting = false;
  private autoReconnect = true;
  private reconnectAttempts = 0;
  private maxReconnectDelay = 16000; // Cap backoff delay at 16 seconds
  private reconnectTimer: any = null;

  // Connection active states
  private connectedStatus = false;
  private activeRooms = new Set<string>();

  // Heartbeat state machine and watchdog parameters
  public internalState: 'CONNECTING' | 'CONNECTED' | 'DEGRADED' | 'DISCONNECTED' = 'DISCONNECTED';
  private lastReceivedTimestamp = Date.now();
  private pingTimeoutTimer: any = null;
  private degradedTimeoutTimer: any = null;

  // Event Subscription mappings
  private subscribers = new Map<string, Set<SocketSubscriber>>();

  // Buffers and Queues
  private offlineOutputQueue: WSFrame[] = [];

  private proactiveHeartbeatInterval: any = null;

  constructor(customUrl?: string) {
    // Derive secure WebSocket configuration relative to host domain
    if (customUrl) {
      this.url = customUrl;
    } else {
      const isHttps = window.location.protocol === 'https:';
      const wsProtocol = isHttps ? 'wss:' : 'ws:';
      const host = window.location.host;
      this.url = `${wsProtocol}//${host}`;
    }

    // Bind instant reconnection listeners for absolute connectivity resilience
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => {
        this.reconnectImmediately();
      });

      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') {
          this.reconnectImmediately();
        }
      });

      window.addEventListener('focus', () => {
        this.reconnectImmediately();
      });
    }
  }

  /**
   * Triggers an immediate, proactive reconnect bypassing any active exponential backoffs
   */
  public reconnectImmediately() {
    // If the websocket is already open or connecting, we do not need to do anything
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }

    console.log('[RealTimeSocketClient] Running instant reconnect sequence (bypassing timeouts).');
    this.clearReconnectionTimer();
    this.reconnectAttempts = 0; // Reset retry counter to start fresh
    if (this.token) {
      this.connect(this.token);
    }
  }

  /**
   * Starts proactive client-to-server heartbeat ticks every 15 seconds to ensure
   * proxies (e.g. Cloud Run, Nginx) do not sever the connection due to inactivity timeouts.
   */
  private startProactiveHeartbeat() {
    this.stopProactiveHeartbeat();
    this.proactiveHeartbeatInterval = setInterval(() => {
      if (this.isConnected() && this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.emit('socket:pong', { timestamp: Date.now(), proactive: true });
      }
    }, 15000); // 15s interval
  }

  private stopProactiveHeartbeat() {
    if (this.proactiveHeartbeatInterval) {
      clearInterval(this.proactiveHeartbeatInterval);
      this.proactiveHeartbeatInterval = null;
    }
  }

  /**
   * Broadcasts internal heartbeat state transitions to listeners
   */
  private setHeartbeatState(newState: 'CONNECTING' | 'CONNECTED' | 'DEGRADED' | 'DISCONNECTED') {
    if (this.internalState !== newState) {

      this.internalState = newState;
      this.triggerEvent('heartbeat:state', { state: newState });
    }
  }

  /**
   * WS-01: guards against stale async ticket fetches opening a socket after
   * a newer connect()/disconnect() superseded them (tickets are single-use).
   */
  private connectGeneration = 0;

  /**
   * Establishes direct real-time session socket with authenticated JWT.
   * WS-01: the access JWT must NOT ride the upgrade URL — the client first
   * exchanges it (over an Authorization header, never a URL) for a
   * short-lived single-use ?ticket= via GET /api/ws-ticket. When the ticket
   * endpoint is not wired yet (404/network error), the client falls back to
   * the legacy ?token= path so connectivity never regresses. Tokens and
   * tickets are NEVER logged.
   */
  public connect(token: string) {
    if (this.token === token) {
      if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
        return; // Keep existing active stream
      }
      if (this.reconnectTimer) {
        return; // Respect active exponential backoff reconnect timers
      }
    } else {
      this.disconnect(); // Terminate old token session to reconnect freshly
    }

    this.token = token;
    this.autoReconnect = true;
    this.isConnecting = true;
    this.setHeartbeatState('CONNECTING');

    const generation = ++this.connectGeneration;
    // Async ticket acquisition — single-use tickets must be minted fresh for
    // every (re)connection attempt, so no caching of the fetch result here.
    void this.openWithTicket(token, generation);
  }

  /**
   * WS-01: resolve a single-use WS ticket, then open the socket with it.
   * Falls back to the legacy ?token= upgrade whenever the ticket endpoint is
   * unavailable (404 while server.ts wiring is pending, or any fetch failure).
   */
  private async openWithTicket(token: string, generation: number) {
    const ticket = await this.fetchWsTicket(token);

    // A disconnect()/reconnect() superseded this attempt — burn nothing.
    if (generation !== this.connectGeneration) return;

    // Single-use ticket: consumed by exactly ONE upgrade attempt. A rejection
    // here surfaces through onerror/onclose and the normal backoff reconnect
    // mints a fresh ticket via connect().
    const upgradedUrl = ticket
      ? `${this.url}?ticket=${encodeURIComponent(ticket)}`
      : `${this.url}?token=${encodeURIComponent(token)}`; // legacy fallback (integration seam)

    try {
      this.ws = new WebSocket(upgradedUrl);
      this.bindSocketEvents();
    } catch (err: any) {
      console.error('[RealTimeSocketClient] Web Socket execution failure:', err);
      this.setHeartbeatState('DISCONNECTED');
      this.scheduleReconnection();
    }
  }

  /**
   * WS-01: exchange the Bearer access token for a short-lived single-use
   * WebSocket upgrade ticket. The token travels ONLY in the Authorization
   * header (never in a URL) and is never logged. Any failure — endpoint not
   * wired (404), network error, malformed body — yields null and the caller
   * falls back to the legacy ?token= path.
   */
  private async fetchWsTicket(token: string): Promise<string | null> {
    if (typeof fetch === 'undefined' || typeof window === 'undefined') return null;
    try {
      const httpBase = this.url
        .replace(/^ws:/i, 'http:')
        .replace(/^wss:/i, 'https:')
        .replace(/\/+$/, '');
      const res = await fetch(`${httpBase}/api/ws-ticket`, {
        method: 'GET',
        headers: { Authorization: `Bearer ${token}` },
        credentials: 'omit',
      });
      if (!res.ok) return null; // 404 (route not wired yet) or auth failure → legacy fallback
      const data: any = await res.json().catch(() => null);
      const ticket = data?.ticket;
      return typeof ticket === 'string' && ticket.length > 0 ? ticket : null;
    } catch {
      return null;
    }
  }

  /**
   * Safe termination of websocket connection
   */
  public disconnect() {
    this.autoReconnect = false;
    // WS-01: invalidate any in-flight ticket-fetch connect attempt.
    this.connectGeneration++;
    this.clearReconnectionTimer();
    this.clearHeartbeatTimer();
    this.stopProactiveHeartbeat();
    this.activeRooms.clear();
    this.setHeartbeatState('DISCONNECTED');

    if (this.ws) {
      try {
        this.ws.close();
      } catch (e) {}
      this.ws = null;
    }
    
    if (this.connectedStatus) {
      this.connectedStatus = false;
      this.triggerEvent('status:change', { connected: false });
    }
    this.isConnecting = false;
  }

  /**
   * Wire standard socket interface transitions
   */
  private bindSocketEvents() {
    if (!this.ws) return;

    this.ws.onopen = () => {
      this.isConnecting = false;
      this.connectedStatus = true;
      this.reconnectAttempts = 0;
      this.setHeartbeatState('CONNECTED');
      
      this.triggerEvent('status:change', { connected: true });

      // Start ping monitoring checks immediately
      this.resetHeartbeatTimer();

      // Start proactive keepalive heartbeat
      this.startProactiveHeartbeat();

      // Automatically rejoin rooms and empty queued frames
      this.syncSessionRecoveryOnConnect();
    };

    this.ws.onmessage = (event: MessageEvent) => {
      this.resetHeartbeatTimer(); // Feed watchdog timer

      try {
        const frame: WSFrame = JSON.parse(event.data);
        if (frame && frame.event) {
          if (frame.event === 'socket:ping') {
            // Send back app-level pong
            this.emit('socket:pong', { timestamp: Date.now() });
            
            // If we received a ping, we are certainly communicating. If we were listed degraded, recover!
            if (this.internalState === 'DEGRADED') {
              this.setHeartbeatState('CONNECTED');
            }
          }
          this.triggerEvent(frame.event, frame.payload);
        }
      } catch (e) {
        console.warn('[RealTimeSocketClient] Received unparseable socket text payload:', event.data);
      }
    };

    this.ws.onclose = () => {
      this.stopProactiveHeartbeat();
      this.handleSocketBreak();
    };

    this.ws.onerror = () => {
      console.log('[RealTimeSocketClient] Connection lifecycle status: Interrupted, auto-reconnect queueing.');
      this.stopProactiveHeartbeat();
      // Close explicitly to force trigger onclose handling
      if (this.ws) this.ws.close();
    };
  }

  /**
   * Formats and pushes frames to server. Buffers packets in a queue if disconnected.
   */
  public emit(event: ClientToServerEvent | string, payload: any, traceId?: string) {
    if (event === 'e2ee:ctrl' && typeof localStorage !== 'undefined' && localStorage.getItem('e2eeDebug')) console.log('[SOCKET-EMIT]', event, 'internalStatus=', this.connectedStatus, 'hasWs=', !!this.ws, 'readyState=', this.ws ? this.ws.readyState : 'none');
    const frame: WSFrame = {
      event,
      payload,
      traceId: traceId || 'client-trace-' + Math.random().toString(36).substring(4, 12),
    };

    if (this.connectedStatus && this.ws && this.ws.readyState === WebSocket.OPEN) {
      try {
        this.ws.send(JSON.stringify(frame));
        return;
      } catch (err) {
        console.warn('[RealTimeSocketClient] Live transmission failed, queueing frame:', err);
      }
    }

    // Capture in buffer queue for transmission upon reconnection online
    if (event === 'msg:send') {

      this.offlineOutputQueue.push(frame);
    }
  }

  /**
   * Subscribes observer listeners to a specific real-time event
   */
  public on(event: ServerToClientEvent | 'status:change' | string, callback: SocketSubscriber): () => void {
    if (!this.subscribers.has(event)) {
      this.subscribers.set(event, new Set());
    }
    this.subscribers.get(event)!.add(callback);

    // Return auto unsubscribe hook
    return () => this.off(event, callback);
  }

  /**
   * Unsubscribes observer listeners
   */
  public off(event: string, callback: SocketSubscriber) {
    const set = this.subscribers.get(event);
    if (set) {
      set.delete(callback);
      if (set.size === 0) {
        this.subscribers.delete(event);
      }
    }
  }

  /**
   * Subscribe and join a real-time Chat room subscription
   */
  public joinRoom(chatId: string) {
    if (!chatId) return;
    if (this.activeRooms.has(chatId)) return; // Prevent duplicate join payloads
    this.activeRooms.add(chatId);
    this.emit('chat:join', { chatId });
  }

  /**
   * Propagates client typing triggers
   */
  public emitTyping(chatId: string, isTyping: boolean) {
    this.emit('presence:typing', { chatId, isTyping });
  }

  /**
   * Dispatches events to local listeners
   */
  private triggerEvent(event: string, payload: any) {
    const set = this.subscribers.get(event);
    if (set) {
      set.forEach((callback) => {
        try {
          callback(payload);
        } catch (e) {
          console.error(`[RealTimeSocketClient] Error executing callback on event '${event}':`, e);
        }
      });
    }
  }

  /**
   * Clean websocket break routines
   */
  private handleSocketBreak() {
    this.ws = null;
    this.clearHeartbeatTimer();
    this.setHeartbeatState('DISCONNECTED');

    if (this.connectedStatus) {
      this.connectedStatus = false;
      this.triggerEvent('status:change', { connected: false });
    }

    if (this.autoReconnect) {
      this.scheduleReconnection();
    }
  }

  /**
   * Setup Reconnect timer with ultra-low latency starting at 500ms and capping at 4s for extreme resilience
   */
  private scheduleReconnection() {
    this.clearReconnectionTimer();

    const delay = Math.min(Math.pow(2, this.reconnectAttempts) * 500, 4000);

    this.reconnectAttempts++;

    this.reconnectTimer = setTimeout(() => {
      if (this.token) {
        this.connect(this.token);
      }
    }, delay);
  }

  /**
   * Watchdog timer for connection silence detection
   */
  private resetHeartbeatTimer() {
    this.clearHeartbeatTimer();
    this.lastReceivedTimestamp = Date.now();

    // 1. Mark as DEGRADED if no server traffic/ping is received within 28 seconds
    this.degradedTimeoutTimer = setTimeout(() => {
      this.setHeartbeatState('DEGRADED');
    }, 28000);

    // 2. Tear down socket to force reconnect if 45 seconds of absolute silence occurs
    this.pingTimeoutTimer = setTimeout(() => {
      console.error('[RealTimeSocketClient] Keep-alive watchdog: 45s silence exceeded. Forcing DISCONNECTED state and reconnecting.');
      this.setHeartbeatState('DISCONNECTED');
      if (this.ws) {
        try {
          this.ws.close();
        } catch (e) {}
      }
    }, 45000);
  }

  /**
   * Empty offline message sync streams and re-subscribe to saved rooms on reconnection
   */
  private syncSessionRecoveryOnConnect() {
    // 1. Re-subscribe to all rooms previously joined
    this.activeRooms.forEach((chatId) => {
      this.emit('chat:join', { chatId });
    });

    // 2. Dispatch all messages generated or retried while offline
    if (this.offlineOutputQueue.length > 0) {
      console.log(`[RealTimeSocketClient] Connection re-established. Syncing ${this.offlineOutputQueue.length} queued messages...`);
      const payloadBatch = [...this.offlineOutputQueue];
      this.offlineOutputQueue = [];

      payloadBatch.forEach((frame) => {
        this.emit(frame.event, frame.payload, frame.traceId);
      });
    }
  }

  private clearReconnectionTimer() {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
  }

  private clearHeartbeatTimer() {
    if (this.pingTimeoutTimer) {
      clearTimeout(this.pingTimeoutTimer);
      this.pingTimeoutTimer = null;
    }
    if (this.degradedTimeoutTimer) {
      clearTimeout(this.degradedTimeoutTimer);
      this.degradedTimeoutTimer = null;
    }
  }

  /**
   * Real-time connected indicator helper
   */
  public isConnected(): boolean {
    return this.connectedStatus;
  }
}
