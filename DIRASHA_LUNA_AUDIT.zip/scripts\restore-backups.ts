import fs from 'fs';
import path from 'path';
import { pool, db } from '../src/server/database.ts';

// Robust structural JSON array recovery utility
function trySalvageJsonArray(rawData: string, filename: string): any[] {
  const trimmed = rawData.trim();
  if (!trimmed) return [];

  try {
    return JSON.parse(trimmed);
  } catch (err: any) {
    console.warn(`[Salvage] Standard JSON parsing failed for '${filename}': ${err.message}. Initiating deep structural recovery...`);
  }

  const items: any[] = [];
  let braceCount = 0;
  let inString = false;
  let isEscaped = false;
  let objectStartIdx = -1;

  for (let i = 0; i < trimmed.length; i++) {
    const char = trimmed[i];

    if (isEscaped) {
      isEscaped = false;
      continue;
    }

    if (char === '\\') {
      isEscaped = true;
      continue;
    }

    if (char === '"') {
      inString = !inString;
      continue;
    }

    if (!inString) {
      if (char === '{') {
        if (braceCount === 0) {
          objectStartIdx = i;
        }
        braceCount++;
      } else if (char === '}') {
        braceCount--;
        if (braceCount === 0 && objectStartIdx !== -1) {
          const objStr = trimmed.substring(objectStartIdx, i + 1);
          try {
            const parsedObj = JSON.parse(objStr);
            items.push(parsedObj);
          } catch (err) {
            // Drop corrupted/incomplete object sections (such as truncations)
          }
          objectStartIdx = -1;
        }
      }
    }
  }

  console.log(`✅ Recovery: Successfully salvaged ${items.length} records dynamically from truncated/corrupted '${filename}' file.`);
  return items;
}

// Main execution block
async function main() {
  console.log('================================================================');
  console.log('🔄 DATABASE BACKUP RESTORATION UTILITY 🔄');
  console.log('================================================================');

  try {
    // 1. Ensure DB schemas and extensions are fully established
    console.log('[Step 1/5] Initializing database connections & migrations...');
    await db.init();
    console.log('✅ Database state verified.');

    // 2. Identify existing records to keep track of foreign relations
    console.log('\n[Step 2/5] Building reference sets for foreign key validation...');
    
    const existingUserIds = new Set<string>();
    const existingChatIds = new Set<string>();
    const existingMessageIds = new Set<string>();

    const usersRes = await pool.query('SELECT id FROM users');
    usersRes.rows.forEach(r => existingUserIds.add(r.id));
    console.log(`- Loaded ${existingUserIds.size} existing user IDs.`);

    const chatsRes = await pool.query('SELECT id FROM chats');
    chatsRes.rows.forEach(r => existingChatIds.add(r.id));
    console.log(`- Loaded ${existingChatIds.size} existing chat IDs.`);

    const messagesRes = await pool.query('SELECT id FROM messages');
    messagesRes.rows.forEach(r => existingMessageIds.add(r.id));
    console.log(`- Loaded ${existingMessageIds.size} existing message IDs.`);

    // 3. Define mapping of backup files to DB tables with their constraint keys
    const backupsDir = path.join(process.cwd(), 'backups');
    if (!fs.existsSync(backupsDir)) {
      console.error(`❌ Backups directory not found at: ${backupsDir}`);
      process.exit(1);
    }

    const tableMappings = [
      {
        filename: 'users_backup_2026-06-07.json',
        tableName: 'users',
        pks: ['id']
      },
      {
        filename: 'chats_backup_2026-06-07.json',
        tableName: 'chats',
        pks: ['id']
      },
      {
        filename: 'user_profiles_backup_2026-06-07.json',
        tableName: 'user_profiles',
        pks: ['user_id']
      },
      {
        filename: 'user_settings_backup_2026-06-07.json',
        tableName: 'user_settings',
        pks: ['user_id']
      },
      {
        filename: 'chat_members_backup_2026-06-07.json',
        tableName: 'chat_members',
        pks: ['chat_id', 'user_id']
      },
      {
        filename: 'messages_backup_2026-06-07.json',
        tableName: 'messages',
        pks: ['id']
      },
      {
        filename: 'attachments_backup_2026-06-07.json',
        tableName: 'attachments',
        pks: ['id']
      },
      {
        filename: 'message_reactions_backup_2026-06-07.json',
        tableName: 'message_reactions',
        pks: ['message_id', 'user_id', 'reaction_emoji']
      },
      {
        filename: 'message_reads_backup_2026-06-07.json',
        tableName: 'message_reads', // mapped dynamically to message_read_receipts or message_reads properties
        pks: ['message_id', 'user_id']
      },
      {
        filename: 'message_pins_backup_2026-06-07.json',
        tableName: 'message_pins',
        pks: ['chat_id', 'message_id']
      },
      {
        filename: 'message_stars_backup_2026-06-07.json',
        tableName: 'message_stars',
        pks: ['user_id', 'message_id']
      },
      {
        filename: 'contacts_backup_2026-06-07.json',
        tableName: 'contacts',
        pks: ['user_id', 'contact_id']
      },
      {
        filename: 'blocks_backup_2026-06-07.json',
        tableName: 'blocks',
        pks: ['user_id', 'blocked_id']
      },
      {
        filename: 'user_username_history_backup_2026-06-07.json',
        tableName: 'user_username_history',
        pks: ['id']
      },
      {
        filename: 'user_profile_changes_backup_2026-06-07.json',
        tableName: 'user_profile_changes',
        pks: ['id']
      },
      {
        filename: 'password_reset_tokens_backup_2026-06-07.json',
        tableName: 'password_reset_tokens',
        pks: ['token']
      },
      {
        filename: 'verification_tokens_backup_2026-06-07.json',
        tableName: 'verification_tokens',
        pks: ['token']
      },
      {
        filename: 'push_subscriptions_backup_2026-06-07.json',
        tableName: 'push_subscriptions',
        pks: ['endpoint']
      },
      {
        filename: 'audit_logs_backup_2026-06-07.json',
        tableName: 'audit_logs',
        pks: ['id']
      },
      {
        filename: 'user_sessions_backup_2026-06-07.json',
        tableName: 'user_sessions',
        pks: ['id']
      }
    ];

    // Reference tables definition
    const userRefCols: Record<string, string[]> = {
      user_profiles: ['user_id'],
      user_settings: ['user_id'],
      chat_members: ['user_id'],
      messages: ['sender_id'],
      message_reactions: ['user_id'],
      message_reads: ['user_id'],
      message_read_receipts: ['user_id'],
      message_pins: ['pinned_by'],
      message_stars: ['user_id'],
      contacts: ['user_id', 'contact_id'],
      blocks: ['user_id', 'blocked_id'],
      user_username_history: ['user_id'],
      user_profile_changes: ['user_id'],
      password_reset_tokens: ['user_id'],
      push_subscriptions: ['user_id'],
      audit_logs: ['user_id'],
      user_sessions: ['user_id']
    };

    const chatRefCols: Record<string, string[]> = {
      chat_members: ['chat_id'],
      messages: ['chat_id'],
      message_reads: ['chat_id'],
      message_read_receipts: ['chat_id'],
      message_pins: ['chat_id']
    };

    const messageRefCols: Record<string, string[]> = {
      attachments: ['message_id'],
      message_reactions: ['message_id'],
      message_reads: ['message_id'],
      message_read_receipts: ['message_id'],
      message_pins: ['message_id'],
      message_stars: ['message_id']
    };

    console.log('\n[Step 3/5] Starting table processing...');

    for (const mapping of tableMappings) {
      const filePath = path.join(backupsDir, mapping.filename);
      if (!fs.existsSync(filePath)) {
        console.log(`⚠️ Skip: Backup file ${mapping.filename} does not exist inside /backups`);
        continue;
      }

      // Check current target table name (handle message_reads vs message_read_receipts)
      let targetTable = mapping.tableName;
      if (targetTable === 'message_reads') {
        const checkReceipts = await pool.query(`
          SELECT EXISTS (
            SELECT FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_name = 'message_read_receipts'
          )
        `);
        if (checkReceipts.rows[0].exists) {
          targetTable = 'message_read_receipts';
        }
      }

      // Verify table exists in active schema
      const tableCheck = await pool.query(`
        SELECT EXISTS (
          SELECT FROM information_schema.tables 
          WHERE table_schema = 'public' 
          AND table_name = $1
        )
      `, [targetTable]);

      if (!tableCheck.rows[0].exists) {
        console.log(`⚠️ Skip: Table '${targetTable}' does not exist in your active PostgreSQL database schema.`);
        continue;
      }

      // Read backup JSON with structural salvage protection
      const rawData = fs.readFileSync(filePath, 'utf-8');
      const items = trySalvageJsonArray(rawData, mapping.filename);
      if (!Array.isArray(items) || items.length === 0) {
        console.log(`- Table '${targetTable}': Backup file is empty, skipping.`);
        continue;
      }

      console.log(`\n📦 Importing backup into table '${targetTable}' (${items.length} records available)...`);

      // Query database columns to dynamically secure column mapping
      const colRes = await pool.query(
        `SELECT column_name FROM information_schema.columns WHERE table_schema = 'public' AND table_name = $1`,
        [targetTable]
      );
      const validCols = new Set(colRes.rows.map(r => r.column_name));

      let processedCount = 0;
      let insertedCount = 0;
      let skippedCount = 0;

      // Start transaction per table to keep it highly performant yet isolated
      const client = await pool.connect();
      try {
        await client.query('BEGIN');

        for (const rawItem of items) {
          processedCount++;

          // 1. Filter out keys that don't exist in the database table schema
          const item: Record<string, any> = {};
          for (const key of Object.keys(rawItem)) {
            if (validCols.has(key)) {
              item[key] = rawItem[key];
            }
          }

          // 2. Validate Foreign Keys constraints
          let shouldSkip = false;

          // Check user references
          const uCols = userRefCols[targetTable] || [];
          for (const col of uCols) {
            const val = item[col];
            if (val && !existingUserIds.has(val)) {
              shouldSkip = true;
              break;
            }
          }

          // Check chat references
          const cCols = chatRefCols[targetTable] || [];
          for (const col of cCols) {
            const val = item[col];
            if (val && !existingChatIds.has(val)) {
              shouldSkip = true;
              break;
            }
          }

          // Check message references
          const mCols = messageRefCols[targetTable] || [];
          for (const col of mCols) {
            const val = item[col];
            if (val && !existingMessageIds.has(val)) {
              shouldSkip = true;
              break;
            }
          }

          if (shouldSkip) {
            skippedCount++;
            continue;
          }

          // Special case: self-referential message reply_to_id parent must exist
          if (targetTable === 'messages') {
            const replyId = item['reply_to_id'];
            if (replyId && !existingMessageIds.has(replyId)) {
              item['reply_to_id'] = null; // Unlink parent if it hasn't been loaded
            }
          }

          // 3. Construct dynamic parameterised SQL statement
          const entryColumns = Object.keys(item);
          if (entryColumns.length === 0) continue;

          const placeholders = entryColumns.map((_, i) => `$${i + 1}`).join(', ');
          const values = entryColumns.map(col => {
            // Convert objects/arrays to JSON string for jsonb columns support
            const val = item[col];
            if (val !== null && typeof val === 'object') {
              return JSON.stringify(val);
            }
            return val;
          });

          // Build conflict statement
          const pks = mapping.pks;
          const pkStr = pks.join(', ');
          const nonPkCols = entryColumns.filter(c => !pks.includes(c));

          let conflictClause = '';
          if (nonPkCols.length > 0) {
            const updateStr = nonPkCols.map(c => `${c} = EXCLUDED.${c}`).join(', ');
            conflictClause = `ON CONFLICT (${pkStr}) DO UPDATE SET ${updateStr}`;
          } else {
            conflictClause = `ON CONFLICT (${pkStr}) DO NOTHING`;
          }

          const sql = `
            INSERT INTO ${targetTable} (${entryColumns.join(', ')})
            VALUES (${placeholders})
            ${conflictClause}
          `;

          await client.query(sql, values);
          insertedCount++;

          // Build index references in memory for subsequent imports
          if (targetTable === 'users' && item.id) {
            existingUserIds.add(item.id);
          } else if (targetTable === 'chats' && item.id) {
            existingChatIds.add(item.id);
          } else if (targetTable === 'messages' && item.id) {
            existingMessageIds.add(item.id);
          }
        }

        await client.query('COMMIT');
        console.log(`✅ Success: Merged ${insertedCount} rows into '${targetTable}' (Skipped ${skippedCount} items due to constraint fails).`);
      } catch (tableErr: any) {
        await client.query('ROLLBACK');
        console.error(`❌ Failed: Table '${targetTable}' rollback due to error:`, tableErr.message || tableErr);
      } finally {
        client.release();
      }
    }

    console.log('\n[Step 4/5] Running database optimization post-import...');
    // Clear dynamic user cache to reflect updates
    db.userCache.clear();
    
    // Automatically review of duplicate user emails if any occurred during the restore
    await db.mergeDuplicateUsers();
    
    // Ensure the Gemini default assistant accounts exist
    await db.ensureGeminiBot();

    console.log('\n================================================================');
    console.log('🎉 DATABASE RESTORATION COMPLETED SUCCESSFULLY! 🎉');
    console.log('================================================================');

  } catch (err: any) {
    console.error('\n❌ CRITICAL ERROR DURING DATABASE RESTORATION:');
    console.error(err.message || err);
    process.exit(1);
  } finally {
    // End pool connections gracefully
    await pool.end();
  }
}

main();
