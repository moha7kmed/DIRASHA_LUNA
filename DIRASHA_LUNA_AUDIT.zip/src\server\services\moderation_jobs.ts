/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { db } from '../database.ts';
import { assertCanSendMessage, SendBlockedError } from '../guards/sendGate.ts';
import { redisCluster } from '../websocket/redis_client.ts';

let isModerationJobsStarted = false;

export function startModerationJobs() {
  if (isModerationJobsStarted) return;
  isModerationJobsStarted = true;

  console.log('[ModerationJobs] Enrolling Automated Retention Job: Deleted Messages Vault cleanup.');
  
  // Run once immediately on startup after confirming tables are fully defined
  setTimeout(async () => {
    try {
      await db.init();
      await runCleanupJob();
      // F10: auth-log retention also runs once at boot so a long-lived
      // process never waits a full day for the first 180-day sweep.
      try {
        const prunedAuth = await db.pruneOldAuthLogs();
        console.log(`[ModerationJobs] Auth-log retention run (180-day window): removed ${prunedAuth} auth_logs entr(ies).`);
      } catch (err: any) {
        console.error('[ModerationJobs] Auth-log retention prune failed:', err.message);
      }
      // Deliver anything scheduled while the server was down without waiting
      // for the first 5-minute tick.
      await deliverScheduledMessages();
    } catch (err: any) {
      console.error('[ModerationJobs] Initial run failed:', err);
    }
  }, 10000);

  // Run once every 24 hours (86400000 ms)
  setInterval(async () => {
    try {
      await db.init();
      await runCleanupJob();
      // F10: auth_logs retention — the documented 180-day window (loud log
      // on every run, even when nothing expires).
      try {
        const prunedAuth = await db.pruneOldAuthLogs();
        console.log(`[ModerationJobs] Auth-log retention run (180-day window): removed ${prunedAuth} auth_logs entr(ies).`);
      } catch (err: any) {
        console.error('[ModerationJobs] Auth-log retention prune failed:', err.message);
      }
    } catch (err: any) {
      console.error('[ModerationJobs] Scheduled cleanup failed:', err);
    }
  }, 24 * 60 * 60 * 1000);

  // Disappearing-messages sweep (WhatsApp parity): every 5 minutes
  setInterval(async () => {
    try {
      const expired = db.collectExpiredMessages();
      if (expired.length === 0) return;
      for (const item of expired) {
        await redisCluster.publish(`chat:${item.chatId}`, {
          event: 'msg:delete:everyone',
          payload: { chatId: item.chatId, messageId: item.messageId, reason: 'disappeared' },
        }).catch(() => {});
      }
      console.log(`[ModerationJobs] Disappearing sweep: ${expired.length} message(s) vanished.`);
    } catch (err: any) {
      console.error('[ModerationJobs] Disappearing sweep failed:', err.message);
    }

    // Scheduled-message delivery (v5): broadcast msg:new for due messages.
    await deliverScheduledMessages();

    // Retention pruning (batched, capped) — throttled to once per hour so the
    // DELETE scans do not run on every 5-minute tick.
    const now = Date.now();
    if (now - lastPruneRun >= PRUNE_INTERVAL_MS) {
      lastPruneRun = now;
      await pruneRetentionTables();
    }
  }, 5 * 60 * 1000);

  // Auto-delete inactive accounts (Telegram parity): daily check inside the
  // retention job — each user opts in via autoDeleteAfterMonths.
  setInterval(async () => {
    try {
      const inactive = db.collectInactiveAccounts();
      for (const item of inactive) {
        await db.deleteUser(item.userId);
        console.log(`[ModerationJobs] Auto-deleted inactive account ${item.userId} (inactive > ${item.months} months).`);
      }
    } catch (err: any) {
      console.error('[ModerationJobs] Inactive-account sweep failed:', err.message);
    }
  }, 24 * 60 * 60 * 1000);
}

async function runCleanupJob() {
  console.log('[ModerationJobs] Executing retention policy sweep for Deleted Messages Vault (30 days limit)...');
  try {
    const deletedCount = await db.cleanupExpiredDeletedMessages();
    if (deletedCount > 0) {
      console.log(`[ModerationJobs] Retention Sweep completed: Permanently deleted ${deletedCount} expired messages older than 30 days.`);
    } else {
      console.log(`[ModerationJobs] Retention Sweep completed: No expired messages found.`);
    }
  } catch (err: any) {
    console.error('[ModerationJobs] Error performing retention purge:', err.message);
  }
}

// ── Scheduled-message delivery (v5) ───────────────────────────────────────────
// The 5-minute sweep claims due scheduled messages via db.collectDueScheduledMessages
// (which stamps broadcast_at = NOW() atomically and bumps chat updated_at) and
// fans out msg:new EXACTLY like the REST send route: one publish to the chat
// room channel plus one per member on their user:updates channel, same payload
// shape (enriched message + state 'sent' + full sender object, mentions ride
// along inside the enriched payload). Per-message try/catch: one failure never
// stops the sweep.
async function deliverScheduledMessages(): Promise<void> {
  let due: Awaited<ReturnType<typeof db.collectDueScheduledMessages>> = [];
  try {
    due = await db.collectDueScheduledMessages(50);
  } catch (err: any) {
    console.error('[ScheduledMessages] Delivery sweep failed:', err.message);
    return;
  }
  if (due.length === 0) return;

  let delivered = 0;
  for (const message of due) {
    try {
      const chatId = message.chatId;
      // BATCH-6 (ADV-03): the delivery sweep re-runs the composition gates —
      // scheduled messages were previously gated only at COMPOSE time.
      const senderObj = await db.getUserById(message.senderId);
      // (a) sender must still exist and not be banned/muted
      if (!senderObj || senderObj.isBanned || (senderObj.mutedUntil && new Date(senderObj.mutedUntil) > new Date())) {
        await db.unmarkScheduledBroadcast(message.id);
        console.warn(`[ScheduledMessages] gated (sender banned/muted/gone) — unclaimed: ${message.id}`);
        continue;
      }
      // (b) sender must STILL be a member of the chat
      const membersNow = await db.getChatMembers(chatId);
      if (!membersNow.some((m: any) => m.userId === message.senderId)) {
        await db.unmarkScheduledBroadcast(message.id);
        console.warn(`[ScheduledMessages] gated (sender left) — unclaimed: ${message.id}`);
        continue;
      }
      // (c) BATCH-6 (NEW-A-02): epoch gate is FAIL-CLOSED for groups — NULL
      // compose_mv (pre-migration rows or a failed marking) gates too, not
      // bypasses. Legacy NULL rows on GROUP chats stay gated by design.
      const composeMv = (message as any).compose_mv;
      const chatIsGroup = db.getChatInfo(chatId)?.type === 'group';
      if (chatIsGroup) {
        const currentMv = db.getMembershipVersion(chatId);
        if (composeMv == null || Number(composeMv) !== Number(currentMv)) {
          await db.unmarkScheduledBroadcast(message.id);
          console.warn(`[ScheduledMessages] gated (epoch compose_mv=${composeMv} != ${currentMv}) — unclaimed: ${message.id}`);
          continue;
        }
      }
      // (d) BATCH-6 (NEW-A-01): the FULL live-send policy re-check at delivery
      // time — blocks, DM policy, whoCanSend, channel role, restrictions were
      // previously compose-time-only.
      try {
        await assertCanSendMessage(db, message.senderId, chatId, { attachments: (message as any).attachments || [] });
      } catch (e: any) {
        if (e instanceof SendBlockedError) {
          await db.unmarkScheduledBroadcast(message.id);
          console.warn(`[ScheduledMessages] gated (send policy) — unclaimed: ${message.id}`);
          continue;
        }
        throw e;
      }
      const msgNewPayload = {
        ...message,
        state: 'sent',
        // BATCH-6 (ADV-03 tail): lastSeen never rides msg:new fan-out —
        // lastSeenVisibility is a per-viewer policy (AB-09 parity).
        sender: senderObj ? {
          id: senderObj.id,
          username: senderObj.username,
          displayName: senderObj.displayName,
          avatarUrl: senderObj.avatarUrl,
          onlineStatus: senderObj.onlineStatus
        } : undefined
      };

      const members = await db.getChatMembers(chatId);
      const pubPromises = [
        redisCluster.publish(`chat:${chatId}`, {
          event: 'msg:new',
          payload: msgNewPayload
        })
      ];
      for (const memb of members) {
        pubPromises.push(
          redisCluster.publish(`user:updates:${memb.userId}`, {
            event: 'msg:new',
            payload: msgNewPayload
          })
        );
      }
      await Promise.all(pubPromises);
      delivered++;
    } catch (err: any) {
      console.error(`[ScheduledMessages] Failed to deliver message ${message.id}:`, err.message);
    }
  }
  if (delivered > 0) {
    console.log(`[ScheduledMessages] Delivered ${delivered} message(s).`);
  }
}

// ── Retention pruning (message_reads > 180d, moderation_audit_logs > 365d) ────
// Batched + capped inside the DB layer; throttled here to once per hour.
const PRUNE_INTERVAL_MS = 60 * 60 * 1000;
let lastPruneRun = 0;

async function pruneRetentionTables(): Promise<void> {
  try {
    const prunedReads = await db.pruneOldReadReceipts();
    if (prunedReads > 0) {
      console.log(`[ModerationJobs] Retention prune: removed ${prunedReads} read receipt(s) for messages older than 180 days.`);
    }
  } catch (err: any) {
    console.error('[ModerationJobs] Read-receipt prune failed:', err.message);
  }
  try {
    const prunedLogs = await db.pruneOldAuditLogs();
    if (prunedLogs > 0) {
      console.log(`[ModerationJobs] Retention prune: removed ${prunedLogs} audit log(s) older than 365 days.`);
    }
  } catch (err: any) {
    console.error('[ModerationJobs] Audit-log prune failed:', err.message);
  }
}
