/**
 * BATCH-2 regression tests (CB-01 / DIR-MV-01 / AB-02 / E2EE-01/02 residuals).
 * Static source asserts locking the membership-epoch consistency hardening:
 *   b2-1  hydration carries membership_version from PG (no reset-to-1).
 *   b2-2  applyMembershipChange snapshots + restores roster on tx failure.
 *   b2-3  banGroupMember no longer bypasses the epoch mechanism.
 *   b2-4  ban route: applyMembershipChange + membership_changed to remaining
 *         + evicted WITH userId.
 *   b2-5  join + approval paths broadcast chat:membership_changed (5/5 paths).
 */
import { describe, it, expect } from 'vitest';
import { readFileSync } from 'fs';
import path from 'path';

const repo = path.resolve(__dirname, '..');
const read = (p: string) => readFileSync(path.join(repo, p), 'utf8');

describe('BATCH-2 remediation (CB-01/DIR-MV-01/AB-02)', () => {
  it('b2-1 hydration carries membership_version from PG', () => {
    const db = read('src/server/database.ts');
    expect(db).toMatch(/membership_version: Number\(c\.membership_version\) \|\| 1/);
    expect(db).toMatch(/hydration MUST carry the authoritative PG/);
  });

  it('b2-2 applyMembershipChange: roster snapshot + restore on tx failure', () => {
    const db = read('src/server/database.ts');
    expect(db).toMatch(/snapshot the roster mirrors BEFORE mutation/);
    expect(db).toMatch(/const prevMembers = new Set\(memoryStore\.chatMembers\.get\(chatId\) \|\| \[\]\)/);
    expect(db).toMatch(/memoryStore\.chatMembers\.set\(chatId, prevMembers\)/);
    expect(db).toMatch(/memoryStore\.chatRoles\.set\(chatId, prevRoles\)/);
  });

  it('b2-3 banGroupMember: ban-bookkeeping only, no epoch bypass', () => {
    const db = read('src/server/database.ts');
    const region = db.slice(db.indexOf('public banGroupMember'), db.indexOf('public unbanGroupMember'));
    expect(region).not.toMatch(/removeChatMember/);
    expect(region).toMatch(/must never bypass the membership-epoch mechanism/);
  });

  it('b2-4 ban route: atomic removal + full broadcasts with identity', () => {
    const srv = read('server.ts');
    const region = srv.slice(srv.indexOf("/api/chats/:chatId/ban'"), srv.indexOf("/api/chats/:chatId/unban'"));
    expect(region).toMatch(/applyMembershipChange\(chatId, 'remove', \[userId\]\)/);
    expect(region).toMatch(/event: 'chat:membership_changed'/);
    expect(region).toMatch(/event: 'chat:evicted', payload: \{ chatId, userId, membershipVersion: newMv \}/);
  });

  it('b2-5 join and approval broadcast membership_changed (5/5 paths)', () => {
    const srv = read('server.ts');
    expect(srv).toMatch(/join is a membership change — remaining/);
    expect(srv).toMatch(/approval-add broadcasts too — all five/);
    const count = (srv.match(/event: 'chat:membership_changed'/g) || []).length;
    // remove + leave + add + join + approval + ban = 6 publish regions (leave/add existed)
    expect(count).toBeGreaterThanOrEqual(4);
  });
});
