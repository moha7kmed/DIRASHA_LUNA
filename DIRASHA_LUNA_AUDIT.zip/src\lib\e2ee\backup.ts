/**
 * Dirasha E2EE — encrypted backup (pure module, no DOM/storage deps).
 *
 * Exports a portable snapshot of the user's chats as a single self-contained
 * string (the `.dirasha-backup` file content). The passphrase is NEVER stored
 * anywhere — it exists only long enough to derive the encryption key.
 *
 * File format (E2EE-SPEC.md backup module):
 *
 *   DIRBK1: + base64(JSON {
 *     v:    1,            // format version
 *     salt: b64(16B),     // scrypt salt (fresh random per backup)
 *     iv:   b64(12B),     // ChaCha20-Poly1305 nonce (fresh random per backup)
 *     ct:   b64,          // ciphertext || 16B Poly1305 tag
 *     hint: string        // b64(first 8 bytes of sha256(passKey)) — see below
 *   })
 *
 * Scheme:
 *   passKey = scrypt(UTF8(passphrase), salt, { N: 2**15, r: 8, p: 1, dkLen: 32 })
 *   encKey  = HKDF-SHA256(ikm = passKey, salt = zeros(32),
 *                         info = 'DirashaBackup-v1', 32 bytes)
 *   ct      = ChaCha20-Poly1305(encKey, iv, UTF8(JSON(payload)),
 *                               AAD = UTF8('DirashaBackup-v1|' + saltB64))
 *   payload = { kind: 'dirasha-backup-v1', createdAt, chats: [...] } — a
 *   portable plaintext-independent snapshot (see BackupPayload).
 *
 * The `hint` field is a KDF-verification token: b64(first 8 bytes of
 * sha256(passKey)). It lets the UI show a short "backup fingerprint"
 * (see backupFingerprint()) so a user can verify a passphrase opens the right
 * backup WITHOUT the passphrase ever being stored. SECURITY NOTE: the hint is
 * NOT a brute-force-resistant passphrase checker — an offline attacker with
 * the file can test a guessed passphrase against the 64 bits of hint without
 * paying the scrypt cost... except that verifying the hint still requires
 * recomputing scrypt to get passKey, so it leaks nothing beyond what the
 * AEAD tag already leaks. Its real limitation: only 64 bits, so it is a
 * CONVENIENCE FINGERPRINT for humans, not a security boundary. Authorization
 * always comes from the AEAD tag itself.
 *
 * PERFORMANCE (UI contract): scrypt with N=2**15 / r=8 is deliberately slow
 * (~0.3–1s per call). createBackup, openBackup and backupFingerprint all run
 * a full scrypt — the calling UI MUST show a progress/spinner note
 * ("جاري تشفير النسخة الاحتياطية…") and should not call these functions on
 * the render path. Use `scryptAsync`-style threading only if the UI blocks;
 * these functions are synchronous by design so callers can wrap them in a
 * worker themselves.
 *
 * Runs identically in tests, web workers and the main thread: imports only
 * src/lib/e2ee/crypto.ts + @noble/hashes; no DOM, no storage, no fetch.
 */

import { hkdf } from '@noble/hashes/hkdf';
import { scrypt } from '@noble/hashes/scrypt';
import { sha256 } from '@noble/hashes/sha256';

import {
  aeadOpen,
  aeadSeal,
  b64decode,
  b64encode,
  randomBytes,
  utf8Decode,
  utf8Encode,
} from './crypto.ts';

/* ══ Constants ══ */

/** File magic prefix of every encrypted backup. */
export const BACKUP_MAGIC = 'DIRBK1:';
/** HKDF info string (also the AAD prefix) for backup key derivation. */
export const BACKUP_INFO = 'DirashaBackup-v1';
/** `kind` discriminator of the decrypted payload (single-chat v1 files). */
export const BACKUP_KIND = 'dirasha-backup-v1';
/** Backup format version (`v` field of the header + payload) — v1 single-chat. */
export const BACKUP_VERSION = 1;
/**
 * Project 11 — full ACCOUNT backup: `kind` discriminator of the v2 payload.
 * Same DIRBK1 container/scrypt/AEAD scheme as v1; only the payload `kind` and
 * the header `v` differ (v2 carries ALL chats, v1 exactly one).
 */
export const BACKUP_KIND_V2 = 'dirasha-backup-v2';
/** Full-account backup format version (header `v` field). */
export const BACKUP_VERSION_V2 = 2;
/** Header `v` values accepted by the versioned parser ({@link importAccountBackup}). */
export const BACKUP_SUPPORTED_VERSIONS = [BACKUP_VERSION, BACKUP_VERSION_V2] as const;
/** scrypt salt length (bytes). */
export const BACKUP_SALT_BYTES = 16;
/** AEAD nonce length (bytes). */
export const BACKUP_IV_BYTES = 12;
/** Derived passKey / encKey length (bytes). */
export const BACKUP_KEY_BYTES = 32;
/** Length of the KDF-verification hint preimage (bytes of sha256 kept). */
export const BACKUP_HINT_BYTES = 8;

/** scrypt work factor. Deliberately high: ~1s on commodity hardware. */
export const BACKUP_SCRYPT_N = 2 ** 15;
/** scrypt block size. */
export const BACKUP_SCRYPT_R = 8;
/** scrypt parallelization factor. */
export const BACKUP_SCRYPT_P = 1;

/** HKDF salt: 32 zero bytes (fixed per spec). */
const ZERO32 = new Uint8Array(32);

/* ══ Errors ══ */

/** Backup failure codes carried on {@link BackupError}.code. */
export type BackupErrorCode = 'BAD_PASSPHRASE' | 'MALFORMED';

/**
 * Typed error for every backup failure (E2EE-SPEC failure UX contract).
 * - `.code === 'BAD_PASSPHRASE'` — the AEAD tag failed to verify: the
 *   passphrase is wrong OR the ciphertext was tampered/corrupted. The UI
 *   should prompt to re-enter the passphrase.
 * - `.code === 'MALFORMED'` — structural problem: bad magic, invalid base64,
 *   unparseable header/payload, wrong lengths or wrong `kind`. No amount of
 *   retrying with another passphrase will help.
 */
export class BackupError extends Error {
  /** Machine-readable failure code ('BAD_PASSPHRASE' | 'MALFORMED'). */
  code: BackupErrorCode;

  constructor(code: BackupErrorCode, message: string) {
    super(message);
    this.name = 'BackupError';
    this.code = code;
  }
}

/* ══ Portable payload shapes ══ */

/** A single message inside a backup snapshot. */
export interface BackupMessage {
  id: string;
  senderId: string;
  senderName: string;
  content: string;
  createdAt: string;
  type: string;
}

/** One chat (with its display metadata) inside a backup snapshot. */
export interface BackupChat {
  chatId: string;
  peerName: string;
  messages: BackupMessage[];
}

/** All chats in the backup, in caller-supplied order. */
export type BackupChats = BackupChat[];

/** The decrypted JSON payload sealed inside a (v1, single-chat) backup file. */
export interface BackupPayload {
  kind: typeof BACKUP_KIND;
  createdAt: string;
  chats: BackupChats;
}

/**
 * Project 11 — the decrypted JSON payload sealed inside a full ACCOUNT backup
 * (v2). Identical shape to {@link BackupPayload} except the `kind`
 * discriminator; `chats` carries ALL of the account's chats (not just one).
 */
export interface AccountBackupPayload {
  kind: typeof BACKUP_KIND_V2;
  createdAt: string;
  chats: BackupChats;
}

/** Union of every supported decrypted payload (v1 + v2). */
export type AnyBackupPayload = BackupPayload | AccountBackupPayload;

/** Result of a successful {@link openBackup}. */
export interface OpenedBackup {
  chats: BackupChats;
  createdAt: string;
}

/** Serialized header (the b64-decoded JSON after BACKUP_MAGIC). */
interface BackupHeader {
  v: number;
  salt: string;
  iv: string;
  ct: string;
  hint: string;
}

/* ══ Key derivation ══ */

/**
 * passKey = scrypt(UTF8(passphrase), salt, N=2^15, r=8, p=1, 32B).
 * SLOW BY DESIGN (~1s) — UI must show a progress note while this runs.
 */
function derivePassKey(passphrase: string, salt: Uint8Array): Uint8Array {
  return scrypt(utf8Encode(passphrase), salt, {
    N: BACKUP_SCRYPT_N,
    r: BACKUP_SCRYPT_R,
    p: BACKUP_SCRYPT_P,
    dkLen: BACKUP_KEY_BYTES,
  });
}

/**
 * encKey = HKDF-SHA256(ikm = passKey, salt = zeros(32),
 *                      info = 'DirashaBackup-v1', 32B).
 * Domain-separates the backup key from passKey so the hint (sha256 of
 * passKey) never reveals anything about the AEAD key.
 */
function deriveEncKey(passKey: Uint8Array): Uint8Array {
  return hkdf(sha256, passKey, ZERO32, utf8Encode(BACKUP_INFO), BACKUP_KEY_BYTES);
}

/** AAD = UTF8('DirashaBackup-v1|' + saltB64) — binds ciphertext to the salt. */
function backupAad(saltB64: string): Uint8Array {
  return utf8Encode(`${BACKUP_INFO}|${saltB64}`);
}

/**
 * KDF-verification token: b64(first 8 bytes of sha256(passKey)).
 *
 * SECURITY NOTE (jsdoc contract): the hint is a CONVENIENCE FINGERPRINT, not
 * a passphrase checker. It carries only 64 bits and is stored in the clear
 * inside the file; a UI may compare `backupFingerprint(guessPassphrase)` to
 * the fingerprint derived from `header.hint` purely to show "this looks like
 * the right backup" — it must NEVER be treated as authentication. Actual
 * authorization is the ChaCha20-Poly1305 tag over the whole payload, and any
 * offline brute-force attacker faces the full scrypt cost per guess.
 */
function passKeyHint(passKey: Uint8Array): string {
  return b64encode(sha256(passKey).slice(0, BACKUP_HINT_BYTES));
}

function bytesToHex(b: Uint8Array): string {
  let s = '';
  for (let i = 0; i < b.length; i++) s += b[i].toString(16).padStart(2, '0');
  return s;
}

/**
 * 8-hex-char fingerprint from the raw hint preimage bytes: hex of the first
 * 4 bytes. Shared by {@link backupFingerprint} and {@link fingerprintFromHint}
 * so both sides of the UI comparison are computed identically.
 */
function fingerprintFromPassKey(passKey: Uint8Array): string {
  return bytesToHex(sha256(passKey).slice(0, 4));
}

/* ══ Shared seal / open cores (versioned — v1 single-chat, v2 full-account) ══ */

/**
 * Seal any payload (v1 or v2) into a DIRBK1 file string. Fresh 16B salt + 12B
 * iv per call, scrypt + HKDF (SLOW ~1s), ChaCha20-Poly1305 over the JSON
 * payload. The container/scrypt/AEAD scheme is IDENTICAL across versions —
 * only header `v` and payload `kind` differ.
 */
function sealBackupFile(passphrase: string, payload: AnyBackupPayload, version: number): string {
  const salt = randomBytes(BACKUP_SALT_BYTES);
  const iv = randomBytes(BACKUP_IV_BYTES);
  const saltB64 = b64encode(salt);

  const passKey = derivePassKey(passphrase, salt);
  const encKey = deriveEncKey(passKey);
  const ct = aeadSeal(encKey, iv, utf8Encode(JSON.stringify(payload)), backupAad(saltB64));

  const header: BackupHeader = {
    v: version,
    salt: saltB64,
    iv: b64encode(iv),
    ct: b64encode(ct),
    hint: passKeyHint(passKey),
  };

  return BACKUP_MAGIC + b64encode(utf8Encode(JSON.stringify(header)));
}

/** Structural validation of the decrypted `chats` payload — MALFORMED on any shape violation. */
function validateChatsPayload(chats: unknown): void {
  if (!Array.isArray(chats)) {
    throw new BackupError('MALFORMED', 'backup payload chats is not an array');
  }
  for (const chat of chats) {
    if (typeof chat !== 'object' || chat === null || Array.isArray(chat)) {
      throw new BackupError('MALFORMED', 'backup chat entry is not an object');
    }
    if (typeof (chat as BackupChat).chatId !== 'string' ||
        typeof (chat as BackupChat).peerName !== 'string' ||
        !Array.isArray((chat as BackupChat).messages)) {
      throw new BackupError('MALFORMED', 'backup chat entry missing chatId/peerName/messages');
    }
    for (const msg of (chat as BackupChat).messages) {
      if (typeof msg !== 'object' || msg === null || Array.isArray(msg)) {
        throw new BackupError('MALFORMED', 'backup message entry is not an object');
      }
      if (typeof msg.id !== 'string' || typeof msg.senderId !== 'string' ||
          typeof msg.senderName !== 'string' || typeof msg.content !== 'string' ||
          typeof msg.createdAt !== 'string' || typeof msg.type !== 'string') {
        throw new BackupError('MALFORMED', 'backup message entry missing required string fields');
      }
    }
  }
}

/**
 * Versioned open core: structural header checks → key derivation → AEAD open →
 * payload JSON parse → kind/version consistency → chats validation. Returns the
 * decrypted payload; callers narrow the kind per their supported versions.
 * Throws {@link BackupError} ('MALFORMED' for structural problems, including
 * unknown/unexpected format versions; 'BAD_PASSPHRASE' on AEAD failure).
 */
function openBackupCore(
  passphrase: string,
  fileText: string,
  supportedVersions: readonly number[],
): { kind: string; createdAt: string; chats: BackupChats } {
  // ── Structural checks → MALFORMED ──
  if (typeof fileText !== 'string' || !fileText.startsWith(BACKUP_MAGIC)) {
    throw new BackupError('MALFORMED', 'not a Dirasha backup file (bad magic)');
  }

  let header: BackupHeader;
  try {
    const headerJson = utf8Decode(b64decode(fileText.slice(BACKUP_MAGIC.length)));
    const parsed: unknown = JSON.parse(headerJson);
    if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
      throw new Error('header is not an object');
    }
    header = parsed as BackupHeader;
  } catch (e) {
    throw new BackupError('MALFORMED', `unreadable backup header: ${(e as Error).message}`);
  }

  // Format-version guard: only the explicitly supported header versions may
  // proceed. A FUTURE version (v3+) must fail loudly, never parse-guess.
  if (!supportedVersions.includes(header.v)) {
    throw new BackupError('MALFORMED', `unsupported backup version ${String(header.v)}`);
  }
  if (typeof header.salt !== 'string' || typeof header.iv !== 'string' ||
      typeof header.ct !== 'string' || typeof header.hint !== 'string') {
    throw new BackupError('MALFORMED', 'backup header missing salt/iv/ct/hint');
  }

  let salt: Uint8Array;
  let iv: Uint8Array;
  let ct: Uint8Array;
  try {
    salt = b64decode(header.salt);
    iv = b64decode(header.iv);
    ct = b64decode(header.ct);
  } catch (e) {
    throw new BackupError('MALFORMED', `invalid base64 in backup header: ${(e as Error).message}`);
  }
  if (salt.length !== BACKUP_SALT_BYTES) {
    throw new BackupError('MALFORMED', `bad salt length ${salt.length}, expected ${BACKUP_SALT_BYTES}`);
  }
  if (iv.length !== BACKUP_IV_BYTES) {
    throw new BackupError('MALFORMED', `bad iv length ${iv.length}, expected ${BACKUP_IV_BYTES}`);
  }
  if (ct.length <= 16) {
    throw new BackupError('MALFORMED', 'ciphertext too short to contain a Poly1305 tag');
  }

  // ── Key derivation + AEAD → BAD_PASSPHRASE on tag failure ──
  const passKey = derivePassKey(passphrase, salt);
  const encKey = deriveEncKey(passKey);
  let plaintext: Uint8Array;
  try {
    plaintext = aeadOpen(encKey, iv, ct, backupAad(header.salt));
  } catch {
    throw new BackupError(
      'BAD_PASSPHRASE',
      'wrong passphrase or corrupted backup (AEAD verification failed)',
    );
  }

  // ── Payload shape → MALFORMED ──
  let payload: { kind?: unknown; createdAt?: unknown; chats?: unknown };
  try {
    const parsed: unknown = JSON.parse(utf8Decode(plaintext));
    if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
      throw new Error('payload is not an object');
    }
    payload = parsed as { kind?: unknown; createdAt?: unknown; chats?: unknown };
  } catch (e) {
    throw new BackupError('MALFORMED', `unreadable backup payload: ${(e as Error).message}`);
  }
  // Kind/version consistency: the payload `kind` discriminator must match the
  // header `v` exactly — a v1 header claiming a v2 kind (or vice versa) is
  // malformed and never parsed guessingly.
  const expectedKind = header.v === BACKUP_VERSION_V2 ? BACKUP_KIND_V2 : BACKUP_KIND;
  if (payload.kind !== expectedKind) {
    throw new BackupError('MALFORMED', `unexpected payload kind ${String(payload.kind)}`);
  }
  if (typeof payload.createdAt !== 'string') {
    throw new BackupError('MALFORMED', 'backup payload createdAt is not a string');
  }
  validateChatsPayload(payload.chats);

  return {
    kind: payload.kind as string,
    createdAt: payload.createdAt as string,
    chats: payload.chats as BackupChats,
  };
}

/* ══ Public API — pure functions ══ */

/**
 * Create an encrypted single-chat backup file string (v1 format).
 *
 * Generates a fresh 16B salt and 12B iv per call, derives keys via
 * scrypt + HKDF (SLOW ~1s — UI should show a progress note), seals the
 * payload with ChaCha20-Poly1305 and returns `'DIRBK1:' + b64(header)`.
 *
 * @param passphrase User passphrase (any string incl. unicode; never stored).
 * @param chats     Portable snapshot of chats to seal (v1 convention: exactly one).
 * @returns The complete backup file content (write it to `<name>.dirk`).
 */
export function createBackup(passphrase: string, chats: BackupChats): string {
  const payload: BackupPayload = {
    kind: BACKUP_KIND,
    createdAt: new Date().toISOString(),
    chats,
  };
  return sealBackupFile(passphrase, payload, BACKUP_VERSION);
}

/**
 * Project 11 — FULL ACCOUNT BACKUP: create an encrypted backup of ALL the
 * account's chats (v2 format).
 *
 * SAME DIRBK1 container, same scrypt+HKDF+ChaCha20-Poly1305 scheme (SLOW ~1s —
 * UI must show a progress note). Differences from {@link createBackup}:
 *   - header `v: 2`, payload `kind: 'dirasha-backup-v2'`;
 *   - `chats` carries EVERY chat the caller provides (multi-chat).
 *
 * HONEST SCOPE OF WHAT IS SEALED (restore semantics — see importAccountBackup):
 * ONLY message content + the metadata listed on {@link BackupMessage} (id,
 * sender, timestamp, type). Session secrets, E2EE private keys, identity keys
 * and passphrases are NEVER included — a backup cannot restore the ability to
 * decrypt live conversations, only to READ the archived plaintext it carries.
 *
 * @param passphrase User passphrase (never stored anywhere).
 * @param chats     ALL chats to seal (caller-supplied snapshot).
 * @returns The complete `.dirk` file content.
 */
export function exportAccountBackup(passphrase: string, chats: BackupChats): string {
  // Fail fast on a structurally invalid snapshot BEFORE paying the scrypt cost.
  validateChatsPayload(chats);
  const payload: AccountBackupPayload = {
    kind: BACKUP_KIND_V2,
    createdAt: new Date().toISOString(),
    chats,
  };
  return sealBackupFile(passphrase, payload, BACKUP_VERSION_V2);
}

/**
 * Open an encrypted SINGLE-CHAT (v1) backup file.
 *
 * Verifies the magic, decodes + validates the header, re-derives keys from
 * the passphrase (SLOW ~1s — UI should show a progress note) and opens the
 * AEAD. Any failure throws {@link BackupError}:
 * - `code='BAD_PASSPHRASE'` — AEAD tag verification failed (wrong passphrase
 *   or corrupted/tampered ciphertext).
 * - `code='MALFORMED'` — bad magic, invalid base64, unparseable or
 *   wrongly-shaped header/payload, wrong lengths, wrong `kind`, or an
 *   unsupported format version (a v2 full-account file opened here is a
 *   MALFORMED version mismatch — use {@link importAccountBackup}).
 *
 * @param passphrase The passphrase the user typed.
 * @param fileText   Full contents of the `.dirasha-backup` file.
 * @returns The decrypted snapshot `{ chats, createdAt }`.
 */
export function openBackup(passphrase: string, fileText: string): OpenedBackup {
  const opened = openBackupCore(passphrase, fileText, [BACKUP_VERSION]);
  return { chats: opened.chats, createdAt: opened.createdAt };
}

/**
 * Project 11 — open a FULL ACCOUNT (v2) backup file. Accepts BOTH v1 and v2
 * files (versioned parse: the header `v` selects the expected payload `kind`;
 * v2 files and v1 files both yield `{ chats, createdAt }`).
 *
 * RESTORE SEMANTICS (honest contract):
 *   - "Restore" here means DECRYPT + DISPLAY. The result is a read-only,
 *     in-memory archive for the existing viewer — nothing is written to the
 *     server, the local message store, or any live chat. Messages are NOT
 *     re-uploaded to the server: re-uploading would pollute history with new
 *     timestamps and fake sender events.
 *   - WHAT IS INSIDE: only message content + the metadata on
 *     {@link BackupMessage} (message id, sender id/name, timestamp, type) per
 *     chat (chatId, peerName). Session secrets, E2EE private keys (identity,
 *     SPK, OPK privs) and ratchet state are NEVER included in any backup —
 *     a backup cannot bring a device back into live E2EE sessions, only
 *     re-display the archived plaintext.
 *   - Failure modes are identical to {@link openBackup} ('BAD_PASSPHRASE' /
 *     'MALFORMED'); an unknown FUTURE version (v3+) is rejected with
 *     MALFORMED (format-version guard) — never parsed guessingly.
 *
 * @param passphrase The passphrase the user typed.
 * @param fileText   Full contents of the `.dirk` file (v1 or v2).
 * @returns The decrypted snapshot `{ chats, createdAt }`.
 */
export function importAccountBackup(passphrase: string, fileText: string): OpenedBackup {
  const opened = openBackupCore(passphrase, fileText, BACKUP_SUPPORTED_VERSIONS);
  return { chats: opened.chats, createdAt: opened.createdAt };
}

/**
 * Short human-verifiable fingerprint of a passphrase: 8 hex chars derived
 * from the same chain as the file's `hint` field
 * (sha256(passKey) → first 4 bytes → hex).
 *
 * Two call modes:
 * - `backupFingerprint(passphrase)` — salt-independent fingerprint (zero
 *   salt), a stable per-passphrase identifier a UI can display when the
 *   passphrase is typed (e.g. at creation time).
 * - `backupFingerprint(passphrase, saltB64)` — when you have the target
 *   file's header salt, this yields the fingerprint that matches
 *   `fingerprintFromHint(header.hint)` for that file, so the UI can confirm
 *   "this passphrase is the one for THIS backup" before running the AEAD
 *   open. Both modes run a full scrypt (SLOW ~1s) — UI should show a
 *   progress note.
 *
 * Purely cosmetic/convenience — see the hint security note in the module
 * jsdoc; never treat it as authentication.
 */
export function backupFingerprint(passphrase: string, saltB64?: string): string {
  const salt = saltB64 !== undefined
    ? b64decode(saltB64)
    : new Uint8Array(BACKUP_SALT_BYTES);
  return fingerprintFromPassKey(derivePassKey(passphrase, salt));
}

/**
 * 8-hex-char fingerprint derived directly from a backup file's `hint` field
 * (the stored b64 of the first 8 bytes of sha256(passKey)). Instant — no
 * scrypt — so the UI can cheaply compare
 * `fingerprintFromHint(header.hint)` against
 * `backupFingerprint(passphrase, header.salt)` to flag a probable
 * wrong-passphrase attempt before the AEAD attempt. Convenience only —
 * never treat it as authentication (see hint security note).
 */
export function fingerprintFromHint(hintB64: string): string {
  const hint = b64decode(hintB64);
  if (hint.length !== BACKUP_HINT_BYTES) {
    throw new BackupError('MALFORMED', `bad hint length ${hint.length}, expected ${BACKUP_HINT_BYTES}`);
  }
  return bytesToHex(hint.slice(0, 4));
}

/* ══ Public API — convenience class ══ */

/**
 * Thin stateless wrapper around the pure backup functions, for callers that
 * prefer an injectable instance over free functions. Holds no keys, no
 * storage, no DOM — safe to construct anywhere.
 */
export class BackupManager {
  /** See {@link createBackup}. */
  create(passphrase: string, chats: BackupChats): string {
    return createBackup(passphrase, chats);
  }

  /** See {@link openBackup}. */
  open(passphrase: string, fileText: string): OpenedBackup {
    return openBackup(passphrase, fileText);
  }

  /** See {@link exportAccountBackup} (Project 11 — full account, v2). */
  exportAccount(passphrase: string, chats: BackupChats): string {
    return exportAccountBackup(passphrase, chats);
  }

  /** See {@link importAccountBackup} (Project 11 — accepts v1 + v2). */
  importAccount(passphrase: string, fileText: string): OpenedBackup {
    return importAccountBackup(passphrase, fileText);
  }

  /** See {@link backupFingerprint}. */
  fingerprint(passphrase: string, saltB64?: string): string {
    return backupFingerprint(passphrase, saltB64);
  }

  /** See {@link fingerprintFromHint}. */
  fingerprintFromHint(hintB64: string): string {
    return fingerprintFromHint(hintB64);
  }
}
