/**
 * WS-01 (external audit) — short-lived, single-use, userId+Origin-bound
 * WebSocket upgrade tickets.
 *
 * Test split (repo convention — server.ts boots the HTTP listener at import;
 * ws_server.ts however is import-safe: the class is instantiated only by
 * server.ts, so the REAL ticket store is exercised in-process):
 *
 *   1. BEHAVIORAL (pure): the REAL issueWsTicket / consumeWsTicket exported
 *      from ws_server.ts — issuance TTL, single-use burn, expiry, origin
 *      binding (incl. trailing-slash normalization + fail-closed cases),
 *      per-user binding, uniqueness.
 *   2. STATIC-SOURCE: the upgrade path prefers ?ticket=, keeps the legacy
 *      ?token= transport behind a one-shot deprecation warning, rejects
 *      scoped media tokens, and the client mints tickets per connection.
 *
 * Run: npx vitest run tests/ws-ticket.test.ts
 */
import { describe, it, expect, beforeAll, afterEach, vi } from 'vitest';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const wsSrc = fs.readFileSync(path.join(repoRoot, 'src/server/websocket/ws_server.ts'), 'utf8');
const socketSrc = fs.readFileSync(path.join(repoRoot, 'src/lib/socket_client.ts'), 'utf8');

let issueWsTicket: any;
let consumeWsTicket: any;

beforeAll(async () => {
  const mod: any = await import('../src/server/websocket/ws_server.ts');
  issueWsTicket = mod.issueWsTicket;
  consumeWsTicket = mod.consumeWsTicket;
  expect(issueWsTicket).toBeTypeOf('function');
  expect(consumeWsTicket).toBeTypeOf('function');
});

afterEach(() => {
  vi.useRealTimers();
});

/* ── 1. Real ticket store behavior ──────────────────────────────────────────── */

describe('issueWsTicket / consumeWsTicket — single-use, TTL, origin binding', () => {
  it('mints a ticket with a ~60s expiry and consumes it for the ISSUING user', () => {
    const before = Date.now();
    const { ticket, exp } = issueWsTicket('user-A');
    expect(ticket).toBeTypeOf('string');
    expect(ticket.length).toBeGreaterThan(20);
    expect(exp).toBeGreaterThanOrEqual(before + 59_000);
    expect(exp).toBeLessThanOrEqual(Date.now() + 61_000);
    expect(consumeWsTicket(ticket)).toEqual({ userId: 'user-A' });
  });

  it('is SINGLE-USE: the second consume attempt fails closed', () => {
    const { ticket } = issueWsTicket('user-A');
    expect(consumeWsTicket(ticket)).toEqual({ userId: 'user-A' });
    expect(consumeWsTicket(ticket)).toBeNull();
    expect(consumeWsTicket(ticket)).toBeNull();
  });

  it('binds the ticket to its userId — different users never cross', () => {
    const a = issueWsTicket('user-A');
    const b = issueWsTicket('user-B');
    expect(consumeWsTicket(b.ticket)).toEqual({ userId: 'user-B' });
    expect(consumeWsTicket(a.ticket)).toEqual({ userId: 'user-A' });
  });

  it('expired tickets fail closed (60s TTL)', () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date('2026-01-01T00:00:00Z'));
    const { ticket } = issueWsTicket('user-A');
    expect(consumeWsTicket(ticket)).toEqual({ userId: 'user-A' }); // fresh ticket works
    const { ticket: t2, exp: exp2 } = issueWsTicket('user-B'); // never consumed
    vi.setSystemTime(new Date(exp2 + 1));
    expect(consumeWsTicket(t2)).toBeNull(); // past TTL
    expect(consumeWsTicket(ticket)).toBeNull(); // replay after expiry
  });

  it('an expired ticket cannot be resurrected by replaying it later', () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date('2026-01-01T00:00:00Z'));
    const { ticket, exp } = issueWsTicket('user-A');
    vi.setSystemTime(new Date(exp + 1));
    expect(consumeWsTicket(ticket)).toBeNull();
    vi.setSystemTime(new Date('2026-01-01T00:03:00Z'));
    expect(consumeWsTicket(ticket)).toBeNull();
  });

  it('binds to the Origin seen at issue time — mismatched Origin fails closed', () => {
    const { ticket } = issueWsTicket('user-A', 'https://app.example.com');
    expect(consumeWsTicket(ticket, 'https://app.example.com')).toEqual({ userId: 'user-A' });

    const t2 = issueWsTicket('user-A', 'https://app.example.com');
    expect(consumeWsTicket(t2.ticket, 'https://evil.example.com')).toBeNull(); // burned
    expect(consumeWsTicket(t2.ticket, 'https://app.example.com')).toBeNull(); // already burned once
  });

  it('normalizes a trailing slash on the bound Origin', () => {
    const { ticket } = issueWsTicket('user-A', 'https://app.example.com/');
    expect(consumeWsTicket(ticket, 'https://app.example.com')).toEqual({ userId: 'user-A' });
  });

  it('a ticket issued WITH an Origin cannot be redeemed with a different or missing Origin', () => {
    const withOrigin = issueWsTicket('user-A', 'https://app.example.com');
    expect(consumeWsTicket(withOrigin.ticket, null)).toBeNull(); // missing Origin — burned
    expect(consumeWsTicket(withOrigin.ticket, 'https://app.example.com')).toBeNull(); // already burned

    const withOrigin2 = issueWsTicket('user-A', 'https://app.example.com');
    expect(consumeWsTicket(withOrigin2.ticket, 'https://evil.example.com')).toBeNull(); // mismatch — burned
    expect(consumeWsTicket(withOrigin2.ticket)).toBeNull();
  });

  it('an UNBOUND ticket (issuer had no Origin header) accepts any presented Origin', () => {
    // Same-origin GET fetches carry no Origin header in browsers, yet the WS
    // upgrade always does — an unbound ticket must not break that flow.
    const noOrigin = issueWsTicket('user-B', null);
    expect(consumeWsTicket(noOrigin.ticket, 'https://app.example.com')).toEqual({ userId: 'user-B' });

    const noOrigin2 = issueWsTicket('user-B', null);
    expect(consumeWsTicket(noOrigin2.ticket)).toEqual({ userId: 'user-B' }); // both sides origin-less
  });

  it('unknown, empty, and non-string tickets fail closed', () => {
    expect(consumeWsTicket('no-such-ticket')).toBeNull();
    expect(consumeWsTicket('')).toBeNull();
    expect(consumeWsTicket(null)).toBeNull();
    expect(consumeWsTicket(undefined)).toBeNull();
    expect(consumeWsTicket(12345)).toBeNull();
    expect(consumeWsTicket({ ticket: 'forged' })).toBeNull();
  });

  it('issues unique, unguessable tickets (32 random bytes each)', () => {
    const t1 = issueWsTicket('user-A').ticket;
    const t2 = issueWsTicket('user-A').ticket;
    expect(t1).not.toBe(t2);
    expect(t1).toMatch(/^[A-Za-z0-9_-]{40,}$/); // base64url of 32 bytes
  });

  it('rejects issuance without a userId (the REST route is the auth boundary)', () => {
    expect(() => issueWsTicket('')).toThrow();
    expect(() => issueWsTicket(undefined)).toThrow();
  });
});

/* ── 2. Upgrade-path wiring (static) ────────────────────────────────────────── */

describe('ws_server.ts upgrade path — ticket-first, legacy compat (static)', () => {
  it('accepts the ?ticket= parameter and consumes it against the upgrade Origin', () => {
    expect(wsSrc).toContain('parsedUrl.query.ticket');
    expect(wsSrc).toContain('consumeWsTicket(queryTicket, upgradeOrigin)');
    // A failed consume never upgrades the socket.
    const block = wsSrc.slice(wsSrc.indexOf('if (queryTicket)'));
    expect(block).toContain('invalid, expired, replayed, or origin-mismatched WS ticket');
  });

  it('resolves the ticket-bound user from the database before upgrading', () => {
    const block = wsSrc.slice(wsSrc.indexOf('if (queryTicket)'));
    expect(block).toContain('.getUserById(consumed.userId)');
    expect(block).toContain('nonexistent or unverifiable user');
  });

  it('applies the CSWSH Origin allowlist to the ticket path too (defense-in-depth)', () => {
    const block = wsSrc.slice(wsSrc.indexOf('if (queryTicket)'));
    expect(block).toContain('isBrowserOriginAllowed(upgradeOrigin)');
    expect(block).toContain('attempted ticket upgrade');
  });

  it('keeps the legacy ?token=/Bearer-protocol path behind a one-shot deprecation warning', () => {
    expect(wsSrc).toContain('DEPRECATION: legacy ?token=/Bearer-protocol WebSocket upgrades are deprecated');
    expect(wsSrc).toContain('legacyTokenDeprecationWarned');
  });

  it('rejects scoped media tokens on the upgrade path (never an upgrade credential)', () => {
    expect(wsSrc).toContain('AuthService.isScopedMediaToken(decoded)');
    expect(wsSrc).toContain('AuthService.isMediaToken(decoded)');
    expect(wsSrc).toContain('media-scoped token presented on the WebSocket upgrade path');
  });

  it('the ticket store shape is single-use with expiry + origin fields', () => {
    expect(wsSrc).toContain('interface WsTicketRecord');
    expect(wsSrc).toMatch(/userId: string;\s*\n\s*exp: number;\s*\n\s*used: boolean;\s*\n\s*\/\*\* Normalized Origin bound at issue time/);
    expect(wsSrc).toContain('wsTickets.delete(ticket)'); // burned on ANY consume attempt
  });
});

describe('socket_client.ts — fresh single-use ticket per connection (static)', () => {
  it('mints the ticket inside the connect flow (never cached across reconnects)', () => {
    expect(socketSrc).toContain('openWithTicket(token, generation)');
    expect(socketSrc).toContain('connectGeneration');
    expect(socketSrc).toContain('single-use tickets must be minted fresh');
  });

  it('disconnect invalidates in-flight ticket fetches (no stale single-use reuse)', () => {
    const block = socketSrc.slice(socketSrc.indexOf('public disconnect()'));
    expect(block).toContain('this.connectGeneration++');
  });
});
