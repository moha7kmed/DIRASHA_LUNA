/**
 * Outbox persistence (external-audit E2EE-05 — P1-B): the ENTIRE outbox item
 * (encrypted content, attachment decryption payloads e2eeFiles, reply quote,
 * attachments metadata) is persisted as a SINGLE AES-GCM envelope under the
 * account-bound cache-KEK machinery (own vault DB, uid-namespaced KEK).
 *
 * Fail-closed policy (mirrors MessagesCacheDB after P1-B):
 *   - no WebCrypto / KEK unavailable → put() THROWS (item stays memory-only;
 *     it is never persisted as plaintext),
 *   - undecryptable stored record (other account's KEK / corruption) → record
 *     is deleted and skipped,
 *   - legacy plaintext record → deleted on read (never surfaced, never kept).
 */

import {
  getOrCreateKek,
  encryptToEnvelope,
  decryptEnvelope,
  isVaultEnvelope,
  IndexedDBKekStore,
} from './e2ee/vault.ts';
import type { KekStore, VaultEnvelope } from './e2ee/vault.ts';

export interface OutboxItem {
  id: string; // clientMessageId
  chatId: string;
  senderId: string;
  content: string;
  type: string;
  attachments: any[];
  createdAt: string;
  replyTo: any;
  retryCount: number;
  nextRetryTime: number;
  status: 'pending' | 'failed';
  // optional fields the App adds on the wire item
  e2ee?: boolean;
  e2eeFiles?: any[];
  traceTimings?: any;
  [k: string]: any;
}

export interface OutboxRecordStore {
  getAllRaw(): Promise<any[]>;
  putSealed(rec: any): Promise<void>;
  deleteRaw(id: string): Promise<void>;
}

const DB_NAME = 'dirashaOutboxDB';
const STORE_NAME = 'outbox';
const DB_VERSION = 1;
const OUTBOX_KEK_DB = 'dirasha-outbox-vault';
const OUTBOX_KEK_STORE = 'keys';

function outboxKekId(uid: string): string {
  return 'outbox-kek:' + (uid || 'anon');
}

export class OutboxDB {
  private static ownerUid: string | null = null;
  private static kekPromise: Promise<CryptoKey | null> | null = null;
  private static dbPromise: Promise<IDBDatabase> | null = null;
  private static injectedKekStore: KekStore | null = null;
  private static injectedRecordStore: OutboxRecordStore | null = null;

  /** Bind the outbox to the logged-in account (App.tsx, alongside the cache). */
  public static setOwnerUid(uid: string | null): void {
    const next = uid || null;
    if (this.ownerUid === next) return;
    this.ownerUid = next;
    this.kekPromise = null;
    this.dbPromise = null;
  }

  /** Test seam (Node tests inject an in-memory KEK store). */
  public static configureForTests(opts: { recordStore?: OutboxRecordStore; kekStore?: KekStore }): void {
    this.injectedRecordStore = opts.recordStore ?? null;
    this.injectedKekStore = opts.kekStore ?? null;
    this.ownerUid = null;
    this.kekPromise = null;
  }

  public static resetForTests(): void {
    this.injectedKekStore = null;
    this.ownerUid = null;
    this.kekPromise = null;
    this.dbPromise = null;
  }

  private static async getKek(): Promise<CryptoKey | null> {
    if (!this.kekPromise) {
      if (typeof crypto === 'undefined' || !crypto.subtle) {
        this.kekPromise = Promise.resolve(null);
      } else {
        const kekStore = this.injectedKekStore
          ?? new IndexedDBKekStore(OUTBOX_KEK_DB, OUTBOX_KEK_STORE, outboxKekId(this.ownerUid ?? ''));
        this.kekPromise = getOrCreateKek(kekStore).catch(() => null);
      }
    }
    return this.kekPromise;
  }

  private static async getDb(): Promise<IDBDatabase> {
    if (!this.dbPromise) {
      this.dbPromise = new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);
        request.onupgradeneeded = (event: any) => {
          const db = event.target.result;
          if (!db.objectStoreNames.contains(STORE_NAME)) {
            db.createObjectStore(STORE_NAME, { keyPath: 'id' });
          }
        };
        request.onsuccess = (event: any) => resolve(event.target.result);
        request.onerror = (event: any) => reject(event.target.error);
      });
    }
    return this.dbPromise;
  }

  /** Seal the whole item into {id, v, iv, ct} (fail-closed without KEK). */
  private static async seal(item: OutboxItem): Promise<any> {
    const kek = await this.getKek();
    if (!kek) throw new Error('OUTBOX_KEK_UNAVAILABLE');
    const env = await encryptToEnvelope(kek, JSON.stringify(item));
    return { id: item.id, v: env.v, iv: env.iv, ct: env.ct };
  }

  /** Open a stored record; null when undecryptable (caller deletes). */
  private static async open(rec: any): Promise<OutboxItem | null> {
    if (!rec || typeof rec !== 'object') return null;
    if (!isVaultEnvelope(rec)) return null;
    const kek = await this.getKek();
    if (!kek) return null;
    const plain = await decryptEnvelope(kek, { v: rec.v, iv: rec.iv, ct: rec.ct });
    if (plain === null) return null;
    try {
      const parsed = JSON.parse(plain);
      return (parsed && typeof parsed === 'object') ? parsed as OutboxItem : null;
    } catch {
      return null;
    }
  }

  public static async put(item: OutboxItem): Promise<void> {
    const sealed = await this.seal(item); // throws OUTBOX_KEK_UNAVAILABLE — fail-closed
    if (this.injectedRecordStore) return this.injectedRecordStore.putSealed(sealed);
    const db = await this.getDb();
    return new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).put(sealed);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  private static async idbAllRaw(): Promise<any[]> {
    const db = await this.getDb();
    return new Promise((resolve) => {
      const out: any[] = [];
      const tx = db.transaction(STORE_NAME, 'readonly');
      const cursorReq = tx.objectStore(STORE_NAME).openCursor();
      cursorReq.onsuccess = () => {
        const cursor = cursorReq.result;
        if (cursor) { out.push(cursor.value); cursor.continue(); }
        else resolve(out);
      };
      cursorReq.onerror = () => resolve(out);
    });
  }

  public static async getAll(): Promise<OutboxItem[]> {
    let recs: any[] = [];
    let db: IDBDatabase | null = null;
    try {
      if (this.injectedRecordStore) {
        recs = await this.injectedRecordStore.getAllRaw();
      } else {
        db = await this.getDb();
        recs = await this.idbAllRaw();
      }
      const out: OutboxItem[] = [];
      for (const rec of recs) {
        const item = await this.open(rec);
        if (item) {
          out.push(item);
        } else {
          // Undecryptable (other account / corruption) or legacy plaintext —
          // fail-closed: DELETE the record, never surface it.
          try {
            if (this.injectedRecordStore) await this.injectedRecordStore.deleteRaw(rec?.id);
            else {
              const tx = db!.transaction(STORE_NAME, 'readwrite');
              tx.objectStore(STORE_NAME).delete(rec?.id);
            }
          } catch { /* best-effort delete */ }
        }
      }
      return out;
    } catch (err) {
      console.error('[OutboxDB] getAll failed:', err);
      return [];
    }
  }

  public static async remove(id: string): Promise<void> {
    const db = await this.getDb();
    return new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  public static async clear(): Promise<void> {
    const db = await this.getDb();
    return new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).clear();
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
}
