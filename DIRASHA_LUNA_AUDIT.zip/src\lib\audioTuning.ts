/**
 * Audio tuning (FREE quality stack)
 * ---------------------------------
 * Opus SDP tuning: inband FEC (packet-loss resilience), DTX (bandwidth during
 * silence) and explicit maxaveragebitrate (clarity). Applied to the AUDIO
 * m-line only — standard, widely-used SDP parameter technique (RFC 7587).
 *
 * Modes: dataSaver (12k) · standard (24k) · high (32k) — FEC always on.
 */

export type AudioMode = 'dataSaver' | 'standard' | 'high';

export interface AudioTuneOpts {
  fec: boolean;
  dtx: boolean;
  maxBitrate: number;
}

export const AUDIO_PROFILES: Record<AudioMode, AudioTuneOpts> = {
  dataSaver: { fec: true, dtx: true, maxBitrate: 12000 },
  standard: { fec: true, dtx: true, maxBitrate: 24000 },
  high: { fec: true, dtx: false, maxBitrate: 32000 },
};

export function optsForMode(mode: string | undefined): AudioTuneOpts {
  return AUDIO_PROFILES[(mode as AudioMode) || 'standard'] || AUDIO_PROFILES.standard;
}

/** Merge Opus parameters into the audio m-line's fmtp entry (id 111 typical). */
export function tuneOpusSdp(sdp: string, opts: AudioTuneOpts): string {
  const params = buildParams(opts);
  const lines = sdp.split('\r\n');
  const out: string[] = [];
  let inAudio = false;
  let done = false;
  for (const line of lines) {
    if (line.startsWith('m=')) {
      if (inAudio && !done) {
        out.push(...fmtpLines(params));
        done = true;
      }
      inAudio = line.startsWith('m=audio');
    }
    if (inAudio && line.startsWith('a=fmtp:111')) {
      // merge with existing params, never duplicate keys
      const existing = new Map<string, string>();
      line.split(' ').slice(1).forEach(kv => {
        const [k, v] = kv.split('=');
        if (k) existing.set(k, v ?? '');
      });
      Object.entries(params).forEach(([k, v]) => existing.set(k, v));
      out.push('a=fmtp:111 ' + Array.from(existing.entries()).map(([k, v]) => (v === '' ? k : `${k}=${v}`)).join(' '));
      done = true;
      continue;
    }
    out.push(line);
  }
  if (!done) out.push(...fmtpLines(params));
  return out.join('\r\n');
}

function buildParams(opts: AudioTuneOpts): Record<string, string> {
  const p: Record<string, string> = { useinbandfec: '1', maxaveragebitrate: String(opts.maxBitrate) };
  if (opts.dtx) p.usedtx = '1';
  return p;
}

function fmtpLines(params: Record<string, string>): string[] {
  const kv = Object.entries(params).map(([k, v]) => `${k}=${v}`).join(' ');
  return [`a=fmtp:111 ${kv}`];
}

/** Audio-only processing constraints builder (user settings → getUserMedia). */
export function buildAudioConstraints(processing?: {
  echoCancellation?: boolean;
  noiseSuppression?: boolean;
  autoGainControl?: boolean;
}): { echoCancellation: boolean; noiseSuppression: boolean; autoGainControl: boolean } {
  return {
    echoCancellation: processing?.echoCancellation !== false,
    noiseSuppression: processing?.noiseSuppression !== false,
    autoGainControl: processing?.autoGainControl !== false,
  };
}
