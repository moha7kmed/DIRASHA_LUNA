# DIRASHA_CRYPTO_PRIVACY_ADVERSARIAL_REVIEW — Agent B (Cryptography, Privacy & Protocol Red Team)
## الجولتان المدمجتان — النص المنظم (الأصل الحرفي في evidence/agent-b-crypto-output-unfiltered.txt)

## الجولة 1 — على `006a004`: **APPROVE WITH CONDITIONS**
- **206/206 اختبارًا تشفيريًا ناجحًا** (14 ملفًا، 134s) — أعد الوكيل تشغيلها بنفسه. typecheck نظيف.
- **جدول الخصائص (نماذج):** Entropy PASS (E5) · OPK lifecycle PASS · PQXDH composition PASS w/note (responder-side inbound PQ gate asymmetry) · 1:1 DR PASS (E5 — Signal-exact) · AAD 1:1 PASS w/note (sd/p خارج AAD = DIR-2026-045) · AAD group PASS w/note (CB-06) · Nonce PASS w/condition (035) · 1:1 replay PASS (لا replay ناجح قابل للبناء — E5) · Group replay PASS w/note (نافذة rotation→ctrl) · Group FS PASS w/limits (من نقطة التوزيع) · Sender-key distribution PASS w/limits (root key shipped) · Membership rotation PASS (تتبع end-to-end) · Crash-safe PASS · Vault PASS w/limits (KEK sharing مؤكد) · Backup CONDITION (N=2^15) · Media PASS · KT CONDITION (witness=same server; الرياضيات byte-exact بين الطرفين) · Downgrade PASS w/condition · **Metadata CONDITION** (DIRG1 **غير مبطن** — group.ts:386؛ 1:1 bucketed؛ لا sealed sender) · noble CONDITION (الإصدارات مثبتة؛ **zero-secret check مؤكد في المصدر المثبت: montgomery.js:71-72 يرمي على zero** — حُلّت 038).
- **المقارنات:** Signal X3DH/PQXDH/DR — مطابقة أساسية (جدول لكل delta)؛ MLS RFC 9420 — فجوة TreeKEM/PCS معمارية؛ Sealed Sender — غير منفذ (تصميم فقط)؛ NIST FIPS 203 — مطابق + **تناقض ادعاء**: "audited noble 1.x" بينما PQ package 0.7.1 pre-1.0.
- **Protocol readiness (الجولة 1):** PARTIALLY READY — 6 تغييرات معمارية مطلوبة قبل كتابة مواصفة (group protocol من App.tsx، version negotiation، MLS قرار، witness، relay split، metadata).

## الجولة 2 — على `4403165` + BATCH-7b: **APPROVE WITH CONDITIONS** (ضُيق لثلاثة)
1. **DIR-2026-035**: Web Locks نُفذت على مسار **إرسال المجموعات فقط** (`withCrossTabLock` — قفلان متسلسلان بلا deadlock، fallback يحفظ الدلالة) — **لكن**: 1:1 engine كامل بلا cross-tab serialization، group receive/SELF ما زال last-write-wins (نافذة replay محدودة عبر التابات)، ولا اختبار يمس المسار النشط → **الحالة الصحيحة PARTIAL** (تصحيح overclaim في السجل).
2. **PQ responder gate**: تحقق الوكيل من مسار الهروب الموثق (h3) وأقر بأن التراجع **justified, not evasion** — البوابة initiator-side only بقرار تصميمي؛ الحد المتبقي يتطلب مفاتيح الطرف نفسه.
3. **بدء فحص BATCH-7:** NEW-A-05 (deletion step-up: peppered scrypt + timingSafeEqual + limiter critical + audit قبل الـ wipe) — **مُنفذ بشكل صحيح**؛ NEW-A-06 (404 بنفس الشكل — لا existence oracle) — **مُغلق**؛ NEW-A-02 (compose_mv fail-closed) — **متحقق وظيفيًا**؛ NEW-A-01 — لا تحويل محتوى ولا E2EE regression.

## الإجابات الـ 11 (الجولة 2)
1. **نواة 1:1 سليمة؟** نعم — X3DH/PQXDH، رياضيات الـ ratchet، دفاعات replay، derive-then-commit، OPK hygiene — Signal-exact بأدلة (28+8 اختبار). لا replay أو forgery قابل للبناء من المصدر.
2. **PQXDH حقيقي؟** نعم — PQ_SS داخل HKDF IKM واحد مع info string مميز، توقيع SPK+PQ مُتحقق من العميل، pq:1⇔pqCt fail-closed. البقايا: بوابة responder غير متماثلة (الجهاز الجديد).
3. **المجموعات سليمة؟** داخل نموذج Sender Keys نعم: سلسلة أحادية، monotonic ctrl، AAD sender/epoch/mv، rotation مُتتبع end-to-end. حدان موثقان: CB-06 وCB-08.
4. **Replay؟** 1:1: لا. المجموعات: فقط داخل نافذة rotation→ctrl؛ مغلق بعد وصول ctrl. سباقات التابات = فقد رسائل لا nonce reuse.
5. **ما يراه السيرفر؟** مرسل/محادثة/توقيت/حجم (bucketed للـ 1:1؛ **غير مبطن للمجموعات**)، رسم مفاتيح، ctrl relay. لا sealed sender.
6. **KT load-bearing؟** فقط عند تثبيت witness + enforcement. الرياضيات مؤكدة الطرفين؛ ضد المالك الخبيث لا تحصيل حاصل.
7. **Vault/backup/media؟** Non-extractability حقيقية ضد file-theft (موثقة ضد in-page malware)؛ KEK sharing هو البقايا؛ backup دون أرضية OWASP (مؤجل)؛ media كاملة.
8. **Supply chain؟** noble مثبت بأدق الإصدارات؛ zero-secret VERIFIED في المصدر المثبت؛ PQ pre-1.0 يناقض تعليق "audited 1.x" (موثق).
9. **سباقات التابات؟** 035 غير منفذ بالكامل — فقد رسائل لا كسر مفاتيح.
10. **Protocol readiness؟** PARTIALLY READY — 1:1/PQXDH/media جاهزة للاستخلاص؛ group protocol وversion negotiation متشابكان مع التطبيق؛ KT storage coupling؛ لا capability negotiation.
11. **الإجمالي:** ادعاءات المطور **تطابق الكود** عند `006a004` لكل خاصية حاسمة تم اختبارها؛ حيث تجاوزت الادعاءات (KT trust-anchor افتراضيًا، تماثل "no silent downgrade"، "audited noble 1.x") — التجاوز موثق ومحدود.

## الحكم النهائي: **APPROVE WITH CONDITIONS** (ضُيّقت لثلاثة — كلها عولجت في BATCH-7b)
1. 035 → PARTIAL (تم في السجل) + إما توسيع Web Locks أو تثبيت إرشاد single-tab كحد صريح (تم التثبيت في CRYPTOGRAPHIC_RESIDUALS).
2. duration dead store → **مُصلح** (boundedDuration wired).
3. PQ boundary → **مُسجل فعليًا** في CRYPTOGRAPHIC_RESIDUALS (التعليق في الكود كان يدّعيه والمستند لم يحويه — تمت المزامنة).
**UNABLE TO VERIFY:** noble advisory history (offline)، runtime الإنتاج، multi-instance Redis تحت حمل حقيقي.
