# تقرير معالجة المراجعة الأمنية المستقلة — ديراشة
## External Audit Remediation Report

**التاريخ:** 2026-11-19 | **الفرع:** `remediation-external-audit` (21 commitًا من `e77cfb7`)
**المرجع:** تقرير المراجعة المستقلة (22 نتيجة) + أمر العمل الملزم
**الحصيلة النهائية:** **557 اختبارًا ناجحًا | 1 متخطى (موثق) | 0 فاشل | 34 ملف اختبار | صفر أخطاء tsc**
**Baseline كان:** 306 اختبارًا. **أُضيف: 251 اختبارًا جديدًا** (سلوكية حقيقية + static-source على المسارات الفعلية).

> القاعدة الحاكمة مُطبقة: كل إغلاق = تعديل مسار الإنتاج + اختبار يثبت السلوك السالب والموجب.
> الاختبار الأخضر وحده لم يُقبل إغلاقًا لأي بند.

---

## 0. توضيحات العدّ (ردًّا على المراجعة الثانية — القسم 5)

- **عدد النتائج:** المراجعة الأولى صنّفت النتائج في **25 معرّفًا** (E2EE-01..09، AUTH-01..07، DATA-01، TLS-01، MEDIA-01، STATUS-01، WS-01، WS-02، GROUP-01، GROUP-02، DB-01). رقم "22" في نص هذا التقرير جاء من جدول ملخص المراجعة الأولى (22 صفًا) — الجداول التالية تغطي كل الـ25 معرّفًا فعليًا.
- **عدد الـcommits:** رقم "21" كان لحظة كتابة التقرير. العدد النهائي يُحتسب دائمًا بـ `git rev-list --count master..HEAD` عند HEAD المُعلن في PROVENANCE (وليس رقمًا ثابتًا في نص).
- **DIR-NEW-11 (RLS):** يُعاد تصنيفه رسميًا من "معالَج" إلى **RESIDUAL موثق** (قرار معماري معلن — يُزال من قائمة المغلق).

## 1. جدول الإغلاق — النتائج الحرجة P0

| Finding | السبب الجذري | الملفات | الضمانة الأمنية | إثبات سالب | إثبات موجب | المخاطر المتبقية |
|---|---|---|---|---|---|---|
| **E2EE-01** | الطرد/المغادرة لم يبلّغ الأعضاء الباقين (الحدث للمزال فقط، بلا هويته) | server.ts، database.ts (migration 12)، sendGate.ts، ws_server.ts، App.tsx، group.ts | تغيير العضوية يرفع `membership_version` دائمًا + بث `chat:membership_changed` لكل الأعضاء الباقين + حمولة الطرد تحمل هويّة المزال | اختبار static: مسارات remove/leave تبث للباقين + userId في الطرد | crypto proof: المُزال حامل مفتاح الحقبة القديمة يفشل `DecryptFailedError` بعد التدوير | الاعتماد على ترطيب mv عند إعادة الاتصال (بوابة epoch السيرفر تغطي) |
| **E2EE-02** | إضافة عضو بلا حقبة جديدة — الاشتقاق الساكن يكشف تاريخ الحقبة | نفس الملفات | bump عند الإضافة + تدوير إلزامي قبل أي توزيع | proof: العضو الجديد بمفتاح ما بعد التدوير يفشل فك ما قبله | post-join traffic يفك طبيعيًا | — |
| **E2EE-03** | edit/schedule/forward/reply ترسل نصًا صريحًا خارج مسار التشفير | guards/encryptionPolicy.ts (جديد)، server.ts، ChatWindow.tsx، App.tsx | بوابة `assertEncryptedIngress` على WS + 3 REST + التعديل: النص الصريح في محادثة مؤهلة **مرفوض سيرفريًا**؛ الرد يركب id-only | اختبار behavior للبوابة (eligible/قنوات/DB-error) + static wiring | المستلم المصرّح يفك ويطبع | محتوى forward attachments يركب كما هو (payloads في الـenvelope الأصلي — موثق) |
| **E2EE-04** | فشل جلب بايتات المرفق → الأصل غير المشفر يركب | App.tsx | fail-closed: فشل الجلب/التشفير في محادثة E2EE = **إلغاء الرسالة كاملة** | fetch-fail → `E2EE_ATTACHMENT_BYTES_UNAVAILABLE` + لا إرسال | المرفقات المشفرة-مصدرًا تمر عبر e2eePayload skip | — |

## 2. جدول الإغلاق — P1

| Finding | السبب الجذري | الملفات | الضمانة الأمنية | إثبات سالب | إثبات موجب | المخاطر المتبقية |
|---|---|---|---|---|---|---|
| **E2EE-05** | Outbox يخزن مفاتيح المرفقات والاقتباس خامًا في IndexedDB | outbox_db.ts (إعادة كتابة)، App.tsx | السجل كله مغلف AES-GCM تحت KEK مرتبط بالحساب؛ بلا KEK = put يفشل (لا plaintext مطلقًا) | marker test: raw IndexedDB بلا أي marker/مفتاح/اقتباس | round-trip كامل | — |
| **E2EE-06** | الكاش يهبط لـplaintext عند فشل WebCrypto + legacy يُخدم قبل الترحيل | messages_cache_db.ts | حذف fallback نهائيًا: بلا KEK = لا كتابة (cache miss)؛ legacy يُرحَّل verify-then-serve أو **يُحذف** | 3 اختبارات فشل → حذف، لا خدمة | الترحيل الناجح round-trips | توفر الكاش معطّل بلا WebCrypto (مقصود) |
| **E2EE-07** | اشتقاق ساكن HKDF(key,n) — تسريب المفتاح يكشف الحقبة + replay ممكن | group.ts (ratchet v2)، App.tsx | **Ratchet أحادي الاتجاه بنمط Signal الموثق** (kdfCk نفس primitive الـ1:1): mk=HMAC(ck,0x01) يُستهلك مرة، ck'=HMAC(ck,0x02)؛ نافذة out-of-order (MAX_SKIP=1000)؛ AAD يربط المرسل+mv؛ هوية wire-bound + anti-spoof | 8 اختبارات قبول: تسريب ck الحالي لا يكشف القديم، replay مرفوض، خارج النافذة مرفوض، حقبة قديمة مرفوضة، عبث هوية/mv مرفوض | 5 رسائل متتالية تفك + SELF ضمن النافذة | Forward secrecy داخل الحقبة فقط (Sender Keys وليست Double Ratchet — موثق بصدق)؛ تاريخ الذات بعد النافذة (500) لا يفك محليًا |
| **E2EE-08** | KT رصد غير حاجز — bundle يُستخدم قبل التحقق (fire-and-forget) | kt-client.ts، engine.ts، server.ts | **بوابة متزامنة صارمة**: fetch+verify **قبل** أي استخدام؛ غير موثق/فاشل/rollback = `KT_UNVERIFIED_PEER` (حظر إرسال)؛ KT_SIGNING_KEY إلزامي إنتاجًا | اختبار wiring معاد: unavailable/tampered/rollback ترفض + علم KT | honest proof يفك ويرسل | بلا witness pinned = بواب مطفأ (unverified mode صريح)؛ الـescape hatch موثق |
| **E2EE-09** | PeerNotRegisteredError → plaintext بصمت | App.tsx | فشل مغلق: إيقاف + توضيح؛ plaintext فقط بعد `window.confirm` صريح لكل محادثة (localStorage) + حدثا أمان على المسارين | الاختبار: بلا opt-in لا إرسال | opt-in صريح يسمح + الأحداث مسجلة | opt-in دائم لحين مسحه؛ call-log يركب نصًا (metadata — follow-up موثق) |
| **AUTH-01** | كشف إعادة الاستخدام ميّت (الهاش القديم مستبعد) + سباق تدوير | auth.ts، database.ts (migration 13) | عائلات توكن: CAS ذري `WHERE id AND hash`، spent-history (هاشات فقط)، إعادة الاستخدام → **إبطال العائلة** | replay القديم/المتوازي → revocation + رفض | تدوير طبيعي يعمل | كشف replay عبر العمليات يحتاج lookup دائم (residual موثق) |
| **DATA-01** | أي خطأ SQL يقلب الصحة + boot بالذاكرة في الإنتاج | database.ts | تصنيف أخطاء اتصال عن SQL؛ **boot الإنتاج يرمي** عند فشل PG؛ سجل CRITICAL لأي كتابة auth بالذاكرة | اختبارات التصنيف | PG سليم = مسار عادي | كتابة mid-flight أثناء انقطاع = recovery عبر snapshot (موثق) |
| **TLS-01** | شهادة فاسدة مع REQUIRE=1 → unverified بصمت | database.ts | مادة CA مُهيأة وفاسدة + REQUIRE=1 = **فشل إقلاع** | اختبار invalid-pinned المحدّث | valid CA → verified | — |
| **MEDIA-01** | حيازة الرابط = تفويض + caching 24h | storage.ts | requireAuth + بوابة **العضوية الحالية** (fail-closed) + no-store | عضو مُزال/بلا جلسة → 403/401 | عضو حالي يبث | lookup LIKE حتى تصل عمود drive_file_id (follow-up)؛ روابط قديمة تموت (مقصود) |
| **AUTH-05** | media token scope مفتوح + access JWT في URLs | auth.ts، server.ts، ChatWindow/E2eeMedia/App | media tokens: `aud:media` + URL-only GET + رفض كـBearer؛ **صفر access JWT في أي URL** (14 موقعًا) | media token على غير /api/media/* → 401 | media token صحيح على مسار الوسائط يعمل | ?access_token في logs (TTL 120s يخفف) |
| **STATUS-01** | بث الصف الكامل لقناة عالمية بلا فلترة + تعليقات بلا رؤية | status.ts، statusPolicy.ts (جديد)، ws_server.ts | `canViewStatus` موحدة fail-closed على REST/WS/التعليقات؛ fanout per-recipient بـ{statusId, ownerId} فقط؛ comments/replies settings مفروضة سيرفريًا | اختبارات nobody/contacts + مغلق → 403 | everyone يرى + المسار الصحيح يعمل | عميل قديم يتوقع صفًا كاملًا في status:new (يجلبه عبر GET) |

## 3. جدول الإغلاق — P2 + P3

| Finding/بند | الإصلاح | الاختبارات | المخاطر المتبقية |
|---|---|---|---|
| **AUTH-02** | userVerification='required' + requireUserVerification:true + step-up (auth_time ≤5 د أو password re-verify) قبل التسجيل/الحذف + تدقيق | ضمن auth-session (38) | التدوير يعيد auth_time (حامل refresh = وصول كامل أصلًا) |
| **AUTH-03** | jti+auth_time+sid على كل access JWT + **فحص إلغاء حي** في requireAuth (وWS عبر ticket) | ضمن auth-session + ws-ticket | التوكنات القديمة pre-deploy grace (موثق) |
| **AUTH-04** | حذف '0000' نهائيًا (App+Sidebar)، toggle يتطلب PIN حقيقي، نصوص صادقة "قفل واجهة فقط" | app-client-hardening (15) | القفل قابل للتجاوز (موثق بصدق)؛ الـPIN في privacySettings يُزامن سيرفريًا (بند متابعة) |
| **AUTH-06** | قاعدة `auth:pin:change` حرجة 5/10min، مفتاح user+IP، INCR قبل verifySecret، 429 عربي | authclassic-hardening (34) | 2fa/disable بلا حد (مشار لمالك authClassic — residual موثق) |
| **AUTH-07** | clientIp صارم: TRUST_PROXY_HOPS=Nth-from-right؛ بلا env = socket فقط (لا ثقة بـXFF)؛ shared helpers للـpasskeys | authclassic-hardening | حدوث وصول مباشر متجاوزًا الـproxy = inherent لـhop-trust (Render مقصور) |
| **WS-01** | تذاكر 60s أحادية الاستخدام مرتبطة بالأصل + `?ticket=` أولاً + legacy deprecated + رفض media tokens | ws-ticket (11 سلوكي) | المخزن per-process (sticky routing عند تعدد العقد) |
| **WS-02** | isWsAttachmentUrlAllowed على WS: data: مرفوض، allowlist/same-origin، fail-closed | ضمن status-privacy/ws-ticket | REST أوسع (linked-storage) — توحيد لاحق أو ضبط MEDIA_HOST_ALLOWLIST |
| **GROUP-01** | nobody = حظر مطلق على الإنشاء والإضافة + contacts مفحوص على كليهما | +2 static | — 
| **GROUP-02** | تعديل رسالة يتطلب عضوية حالية (403 للمستقيل) | ضمن ingress-policy (22 اختبارًا) | — |
| **DB-01** | قرار معماري موثق: RLS no-op للمالك الوحيد بلا FORCE؛ FORCE بلا سياسات = outage؛ شروط إعادة النظر مثبتة في database.ts | db-fail-closed (static) | طبقة RLS الفعلية تتحقق عند دور غير مالك + سياسات |
| **P3-Docker** | حذف COPY data/ (mkdir زمن التشغيل — يسد مسار تسريب snapshot الجهاز للصورة) + node:22.23.5-slim pinned | infra-p3 (17 اختبارًا) | digest يُسجل عند أول deploy |
| **P3-Render** | كل المتغيرات المطلوبة والاختيارية sync:false (صفر أسرار) + TRUST_PROXY_HOPS=1 | infra-p3 | — |
| **P3-CI** | كل uses: مثبتة بـSHA كامل (مصدرها ls-remote حي) | infra-p3 | التحديث عبر نافذة مراقبة |
| **P3-scanner** | scan-secrets يعمل بلا .git (tree fallback) + تغطية .pem/.key + fixture معلن | stage0 (214 ملف PASS) | — |
| **P3-zip** | ZIP جديد بفواصل / + MANIFEST + تحقق فك كامل | هذا التسليم | — |

## 4. تقرير الاختبارات الموحد (التشغيل النهائي على الفرع)
- **الإجمالي: 558 | ناجح: 557 | فاشل: 0 | متخطى: 1 | غير مشغل: 0**
- الملفات: 34. typecheck: صفر أخطاء. build: أخضر.
- الـskip الوحيد مورث وموثق (توكن refresh-body في passkeys.ts) — المتخطى لا يُعد نجاحًا.
- اختباران أُعيدا توجيههما عمدًا لدلالات السياسات الجديدة (KT trust-gate + critical class) — التغيير معلن في commits 1df414c و1c4e118 وليس إخفاء فشل.

## 5. بنود "ممنوع" في أمر العمل — الحالة
- لا تحديث تقارير بلا كود: كل بند عدّل مسار الإنتاج فعليًا.
- لا skip لإخراج CI أخضر: فوق.
- لا mock يحل محل المسار الحقيقي: البوابات الحقيقية (assertMembershipFresh / assertEncryptedIngress / canViewStatus / CAS / tickets) اختبرت سلوكيًا حول الكود الحقيقي + static على المسارات؛ قيود boot-at-import موثقة في كل ملف اختبار.
- لا plaintext عند تعذر التشفير: كل المسارات fail-closed + opt-in صريح واحد موثق (E2EE-09).
- لا ادعاء Production-Ready أو E2EE كامل: القسم 6 هو الحكم.

## 6. الحكم الصادق
1. كل نتائج المراجعة الـ22 عولجت بكود إنتاجي + اختبارات، والـresidual risks موثقة لكل بند أعلاه.
2. لم يحدث تدقيق خارجي جديد — هذا التقرير مدخله؛ لا يدعيه.
3. حدود بالتصميم تبقى صادقة: القنوات غير E2EE، الميتاداتا ظاهرة للسيرفر، Sender Keys توفر forward secrecy داخل الحقبة فقط (ليست Double Ratchet)، بلا مقاومة كم مستمرة للرسائل.
4. التوصية: مراجعة مستقلة جديدة على هذا الفرع قبل أي إعلان جاهزية.
