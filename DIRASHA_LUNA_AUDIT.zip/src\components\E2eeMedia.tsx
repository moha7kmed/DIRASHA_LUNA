import { useEffect, useState } from 'react';
import { Download, FileText, Loader2, Lock, RefreshCw } from 'lucide-react';

import { decryptAttachment, TamperedError } from '../lib/e2ee/media.ts';
import type { AttachmentPayload } from '../lib/e2ee/media.ts';

/* ═══════════════════════════════════════════════════════════════════════════
 * E2eeMedia — decrypts and renders one encrypted chat attachment.
 *
 * The wire attachment is an opaque application/octet-stream 'enc.bin' blob;
 * the real mime/name/size/key/iv live in the AttachmentPayload that arrived
 * INSIDE the encrypted message envelope (message.e2eeFiles). This component:
 *   1. fetch(att.url) → ciphertext bytes (same-origin Drive proxy, token-quoted)
 *   2. decryptAttachment(payload, bytes) → verified plaintext (AEAD + sha256)
 *   3. objectURL of the plaintext Blob → rendered by mime:
 *      image → <img> · video → <video controls> · audio → <audio controls>
 *      else → generic file card with the DECRYPTED name/size + download link.
 *
 * States: loading (skeleton) · decrypting · ready · locked (no payload —
 * own-echo loss / parse failure, muted non-functional card) · error
 * (TamperedError or fetch failure → Arabic message + click-to-retry via the
 * `attempt` key, same remount pattern as MediaGate).
 * ═══════════════════════════════════════════════════════════════════════════ */

interface E2eeMediaProps {
  /** Wire attachment object ({ id, url, mimeType: 'application/octet-stream', ... }). */
  att: any;
  /** Decryption payload from message.e2eeFiles — null renders the lock card. */
  payload: AttachmentPayload | null;
  /** Access token appended to /api media proxy URLs (same quoting as MediaGate). */
  accessToken?: string;
  /** Tap-to-open for images → the existing fullscreen viewer. */
  onOpenImage?: (url: string, name: string) => void;
}

type Phase = 'loading' | 'decrypting' | 'ready' | 'locked' | 'error';

/** Small local size formatter (avoids importing ChatWindow internals). */
function formatBytes(n: number): string {
  if (!Number.isFinite(n) || n <= 0) return '';
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(2)} MB`;
}

export function E2eeMedia({ att, payload, accessToken, onOpenImage }: E2eeMediaProps) {
  const [phase, setPhase] = useState<Phase>(payload ? 'loading' : 'locked');
  const [attempt, setAttempt] = useState(0);
  const [objUrl, setObjUrl] = useState<string | null>(null);
  const [decMime, setDecMime] = useState<string>('');
  const [decName, setDecName] = useState<string>('');
  const [wasTampered, setWasTampered] = useState(false);

  useEffect(() => {
    if (!payload || !att?.url) {
      setPhase('locked');
      return;
    }
    let cancelled = false;
    let created: string | null = null;
    (async () => {
      setPhase('loading');
      setObjUrl(null);
      try {
        // Same access-token quoting as every other media renderer in ChatWindow.
        const base: string = att.url;
        // P1-H (AUTH-05): scoped short-lived media token — the access JWT
        // never rides media URLs (component-local fetch, no cross-module cache).
        let mt: string | null = null;
        if (accessToken) {
          try {
            const r = await fetch('/api/media-token', { headers: { Authorization: 'Bearer ' + accessToken } });
            const d = await r.json().catch(() => null);
            if (r.ok && d?.token) mt = String(d.token);
          } catch { mt = null; }
        }
        const src = base.startsWith('/api') && mt
          ? `${base}${base.includes('?') ? '&' : '?'}access_token=${mt}`
          : base;
        const res = await fetch(src);
        if (!res.ok) throw new Error(`fetch failed (${res.status})`);
        const buf = await res.arrayBuffer();
        if (cancelled) return;
        setPhase('decrypting');
        const dec = decryptAttachment(payload, new Uint8Array(buf));
        const blob = new Blob([dec.bytes as BlobPart], {
          type: dec.mime || payload.mime || 'application/octet-stream',
        });
        const url = URL.createObjectURL(blob);
        created = url;
        if (cancelled) {
          URL.revokeObjectURL(url);
          return;
        }
        setObjUrl(url);
        setDecMime(dec.mime || payload.mime || 'application/octet-stream');
        setDecName(dec.name || payload.name || 'file');
        setPhase('ready');
      } catch (err: any) {
        if (cancelled) return;
        setWasTampered(err instanceof TamperedError || err?.name === 'TamperedError');
        setPhase('error');
      }
    })();
    return () => {
      cancelled = true;
      if (created) URL.revokeObjectURL(created);
    };
    // `attempt` drives click-to-retry remounts; att/payload are stable per message.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [attempt]);

  /* ── Lock card: meta.e2ee attachment with NO usable payload ── */
  if (phase === 'locked') {
    return (
      <div
        className="mt-2.5 p-3 bg-black/30 border border-white/5 rounded-xl flex items-center gap-3 text-slate-400 text-left min-w-[230px] opacity-70"
        style={{ direction: 'rtl' }}
      >
        <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center shrink-0">
          <Lock className="w-5 h-5 text-slate-500" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-[12px] font-bold truncate text-slate-400">مرفق مشفر</p>
          <span className="text-[10px] text-slate-500">تعذر جلب مفاتيح فك التشفير لهذا المرفق</span>
        </div>
      </div>
    );
  }

  /* ── Error card: fetch/decrypt failure → click-to-retry ── */
  if (phase === 'error') {
    return (
      <div
        onClick={() => setAttempt((a) => a + 1)}
        className="mt-2.5 p-3 bg-black/30 border border-rose-500/20 rounded-xl flex items-center gap-3 text-rose-300 text-left min-w-[230px] cursor-pointer hover:bg-black/40 transition-colors"
        style={{ direction: 'rtl' }}
      >
        <div className="w-10 h-10 rounded-xl bg-rose-500/10 flex items-center justify-center shrink-0">
          <Lock className="w-5 h-5" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-[12px] font-bold truncate">تعذر فك تشفير المرفق</p>
          <span className="text-[10px] text-rose-400/70 flex items-center gap-1">
            <RefreshCw className="w-3 h-3" /> اضغط لإعادة المحاولة
          </span>
        </div>
      </div>
    );
  }

  /* ── Loading / decrypting skeleton ── */
  if (phase !== 'ready' || !objUrl) {
    const label = phase === 'decrypting' ? 'جارٍ فك التشفير...' : 'جارٍ التحميل...';
    return (
      <div
        className="mt-2 h-36 w-full rounded-2xl bg-black/30 border border-white/10 flex flex-col items-center justify-center gap-2"
        style={{ direction: 'rtl' }}
      >
        <Loader2 className="w-5 h-5 text-slate-400 animate-spin" />
        <span className="text-[11px] text-slate-400">{label}</span>
      </div>
    );
  }

  /* ── Ready: render the decrypted plaintext by mime ── */
  const mime = decMime || 'application/octet-stream';
  if (mime.startsWith('image/')) {
    return (
      <img
        src={objUrl}
        alt={decName || 'صورة'}
        onClick={() => onOpenImage?.(objUrl, decName || 'صورة')}
        className="mt-2 rounded-2xl cursor-pointer"
        style={{ maxWidth: '100%', maxHeight: 400, display: 'block' }}
      />
    );
  }
  if (mime.startsWith('video/')) {
    return (
      <video
        src={objUrl}
        controls
        preload="metadata"
        playsInline
        className="mt-2 max-h-[400px] w-full rounded-2xl"
      />
    );
  }
  if (mime.startsWith('audio/')) {
    return (
      <div className="mt-2.5 p-3 bg-black/30 border border-white/5 rounded-2xl min-w-[230px] text-left">
        <div className="flex items-center gap-2 mb-2" style={{ direction: 'rtl' }}>
          <FileText className="w-4 h-4 text-pink-400 shrink-0" />
          <p className="text-[11px] font-bold text-white truncate flex-1">{decName || 'ملف صوتي'}</p>
          <span className="text-[9px] text-slate-400 shrink-0">{formatBytes(payload?.size || 0)}</span>
        </div>
        <audio src={objUrl} controls preload="metadata" className="w-full h-9" />
      </div>
    );
  }
  // Generic file card — decrypted name + size + download link.
  return (
    <div
      className="mt-2.5 p-3 bg-black/30 border border-white/5 rounded-xl flex items-center gap-3 text-slate-200 text-left min-w-[230px]"
      style={{ direction: 'rtl' }}
    >
      <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center shrink-0">
        <FileText className="w-5 h-5 text-sky-400" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-[12px] font-bold truncate text-white">{decName || 'ملف'}</p>
        <span className="text-[10px] text-slate-400">{formatBytes(payload?.size || 0)}</span>
      </div>
      <a
        href={objUrl}
        download={decName || 'file'}
        title="تنزيل"
        className="p-2 hover:bg-white/5 rounded-lg text-slate-300 hover:text-blue-400 transition-all shrink-0"
      >
        <Download className="w-4 h-4" />
      </a>
    </div>
  );
}
