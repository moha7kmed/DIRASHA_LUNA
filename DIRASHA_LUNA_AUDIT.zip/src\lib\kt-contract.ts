/**
 * Key Transparency — CLIENT API CONTRACT (types only, no runtime code)
 * --------------------------------------------------------------------
 * Server side: src/server/services/key_transparency.ts (owner: KT project).
 * Client side: the e2ee engine will consume these types + the endpoints below
 * (NOT implemented in engine.ts in this round — documented contract for the
 * lead / follow-up round). This file is deliberately dependency-free so both
 * server and client can import it.
 *
 * ## Endpoints (all under /api/e2ee/kt, Bearer auth)
 *
 *   GET /api/e2ee/kt/root
 *        → { treeVersion, rootHash, signature, signedAt, mode }
 *        Current signed snapshot. `mode`:
 *          - 'verified'   → server holds KT_SIGNING_KEY; signature is a valid
 *                           Ed25519 signature (std b64) over
 *                           'DirashaKT-v1:<treeVersion>:<rootHash>' from the
 *                           witness key. Clients SHOULD verify it against a
 *                           pinned/witness public key when one is configured.
 *          - 'unverified' → no KT_SIGNING_KEY configured: signature is ''.
 *                           Clients MUST surface a persistent 'unverified'
 *                           warning banner — never silently trust this mode.
 *
 *   GET /api/e2ee/kt/proof/:userId?sinceVersion=N
 *        → { userId, found, snapshot, inclusion?, consistency? }
 *        `inclusion`: proof that the user's CURRENT key commitment is the leaf
 *        at `leafIndex` of the snapshot tree (size = snapshot.treeVersion).
 *        `consistency`: proof that snapshot N (client's last anchored version)
 *        is a prefix of the current snapshot — detects hidden/rewritten
 *        history (fork / split-view attacks). Omitted when sinceVersion is
 *        absent/0 (Trust-On-First-Use anchor) or equals the current version.
 *        If `found` is false the user has no entry in the log yet (only the
 *        snapshot is returned).
 *
 *   POST /api/e2ee/kt/replay-detect   (admin-only)
 *        → records a client verification failure into the admin audit log and
 *        returns the recent reports. Body:
 *        { subjectUserId?, expectedRoot?, observedRoot?, detail? }.
 *
 * ## Client verification algorithm (to be implemented in engine.ts later)
 *
 *   1. TOFU anchor: on first sight, store snapshot {treeVersion, rootHash,
 *      signature, signedAt} locally. Without a prior anchor there is nothing
 *      to compare against — this limitation is documented by design.
 *   2. On every subsequent bundle/identity fetch for a peer, request
 *      /proof/:userId?sinceVersion=<stored treeVersion>.
 *   3. Verify: verifyConsistencyProof(storedVersion, snapshot.treeVersion,
 *      consistency.proof, storedRootHash, snapshot.rootHash) must be true.
 *      Failure = fork → loud UI warning + refuse the fetched key material +
 *      report via /replay-detect.
 *   4. Verify: verifyInclusionProof(inclusion.leafIndex, snapshot.treeVersion,
 *      inclusion.leafHash, inclusion.authPath, snapshot.rootHash) must be
 *      true AND inclusion.leafHash must equal
 *      ktLeafHash(inclusion.seq, userId, locallyComputedCommitment) where the
 *      local commitment is sha256 over the peer's sorted device identity pubs
 *      (computeFleetCommitment shape). Mismatch = server/keys tampering.
 *   5. If mode === 'unverified' (signature ''), show the persistent
 *      'unverified' warning; if mode === 'verified' and a witness public key
 *      is pinned, verify the snapshot signature with verifySnapshotSignature.
 *
 * Hashing conventions (RFC-6962-style domain separation, all sha256, hex
 * output): leaf = H(0x00 || '<seq>|<userId>|<commitment>'),
 * node = H(0x01 || left || right), empty tree root = sha256('').
 */

/** Current signed checkpoint of the transparency tree. */
export interface KtSnapshot {
  /** Number of log entries covered by this tree (= tree size / leaf count). */
  treeVersion: number;
  /** Hex-encoded Merkle root over the first `treeVersion` log entries. */
  rootHash: string;
  /** std-base64 Ed25519 signature over 'DirashaKT-v1:<v>:<rootHash>'; '' in unverified mode. */
  signature: string;
  /** ISO timestamp of signing (null for the synthetic version-0 snapshot). */
  signedAt: string | null;
}

export type KtMode = 'verified' | 'unverified';

export interface KtRootResponse extends KtSnapshot {
  mode: KtMode;
}

/** Auth path for a leaf: sibling hashes ordered leaf-up (path[0] closest to the leaf). */
export interface KtInclusionProof {
  /** 0-based position of the user's latest log entry in the snapshot tree. */
  leafIndex: number;
  /** Tree size the proof is valid for (= snapshot.treeVersion). */
  treeSize: number;
  /** Hex leaf hash of the user's latest log entry. */
  leafHash: string;
  /** Hex sibling hashes, leaf-up order. */
  authPath: string[];
  /** The user's commitment covered by this proof (hex sha256 of fleet keys). */
  commitment: string;
  /** Log seq of the entry proven. */
  seq: number;
}

export interface KtConsistencyProof {
  /** Client's anchored snapshot version (m). */
  fromVersion: number;
  /** Current snapshot version (n). */
  toVersion: number;
  /** Hex proof elements (generation order, deepest first). */
  proof: string[];
}

export interface KtProofResponse {
  userId: string;
  /** false = user not in the log yet; only `snapshot` is meaningful. */
  found: boolean;
  snapshot: KtRootResponse;
  inclusion?: KtInclusionProof;
  consistency?: KtConsistencyProof;
}

export interface KtMismatchReport {
  id: number;
  reporterId: string;
  subjectUserId: string | null;
  expectedRoot: string | null;
  observedRoot: string | null;
  detail: string | null;
  createdAt: string;
}
