# DIRASHA_CRYPTOGRAPHIC_RESIDUALS
## القيود التشفيرية المتبقية — بلا أي تغيير بروتوكولي في هذه الموجة

**قاعدة الموجة:** لا تغيير تصميم تشفيري دون مراجعة متخصصة — حُفظت حرفيًا؛ كل إصلاحات BATCH-6 كانت control-plane.

## الحدود الخمسة (مثبتة/مفترضة — تفصيل كامل في REMAINING_CRYPTOGRAPHIC_REVIEW.md)

| البند | الحد | التصنيف |
|---|---|---|
| **DIR-2026-019** | witness KT = نفس السيرفر — لا حماية ضد malicious server افتراضيًا | Requires specialist review (بنية witness مستقل) |
| **DIR-2026-035** | سباق تابين في 1:1 → فقدان رسالة (لا كسر سرية؛ nonce فريد) | Requires specialist review (Web Locks على مسار التشفير) |
| **DIR-CB-06** | السيرفر يفحص mv المعلن؛ ربط AAD-mv بنيويًا مستحيل بلا فك | موثق صادقًا؛ حماية العميل (rotate) + فشل مغلق للمستلم |
| **DIR-CB-08** | رسائل الذات غير قابلة للفك على الجهاز الثاني (توزيع الذات مُسقط) | Requires specialist review (Sesame-like design) |
| **DIR-2026-038** | فحص zero-shared-secret غير متحقق من noble 1.x | UNABLE-TO-VERIFY — فحص صريح في موجة التصميم |

## تأثير الحدود على الخصائص الست (ثابت)
- **FS:** 1:1 كاملة (Double Ratchet)؛ المجموعات **داخل الحقبة** (ratchet v2 أحادي).
- **PCS:** **غير مدعوم للمجموعات** — Sender Keys ليست Double Ratchet (موثق بصدق في مستندات المشروع نفسه).
- **Device sync:** PQXDH لكل جهاز (runtime-tested) — محدود بـ CB-08.
- **Membership changes:** bump+broadcast 5/5 + بوابة epoch fail-closed + (جديد) **بوابة epoch وقت تسليم الجدولة** (ADV-03 fix).
- **Key Transparency:** بوابة متزامنة حقيقية — مقيدة بـ witness نفس السيرفر.
- **Replay resistance:** 1:1 محكمة؛ المجموعات: نافذة splice + monotonic ctrl — البقايا: CB-06 (تصريحي) + دون تتبع عبر إعادة التركيب.

## ما يمنع أي ادعاء تشفيري مبالغ (قواعد ملزمة للتوثيق)
1. لا "Sender Keys ≡ Double Ratchet".
2. لا "PCS للمجموعات".
3. لا "KT ضد malicious server" افتراضيًا.
4. اذكر CB-06/CB-08/019/035/038 كحدود موثقة في أي وثيقة أمنية.
5. ما يتطلب مراجعة متخصصة: إعادة تصميم السلسلة (chain evolution للتوزيع الذاتي)، witness مستقل، Web Locks، فحص zero-secret.


## تحديث الحملة الختامية (2026-11-21 — Agent-B conditions)

1. **بوابة PQ downgrade بقرار تصميمي: INITIATOR-SIDE ONLY.** نفذتْ بوابة responder-side ثم تراجعت: تكسر مسار الهروب الموثق والمُختبَر (crypto-hardening h3: classical re-init بعد deleteSession الصريح من الطرف يجب أن ينجح — استرجاع فقدان الجلسة). الحد المتبقي الموثق: طرف يظهر classically بـ deviceId جديد — يتطلب مفاتيح الطرف نفسه (داخل حد الثقة)، وإعلان الأسطول (fleet advertisement) هو مصدر القدرة، ووضع KT المفروض يعلّم تغيّر الأسطول. مكتوب في `engine.ts` (buildResponderSession).
2. **DIR-2026-038 حُلّت:** تحقق Agent-B من المصدر المثبت — `@noble/curves/abstract/montgomery.js:71-72` يرمي على zero DH output (إصدار مثبت 1.9.7) → FIXED-VERIFIED عند الإصدار المثبت. فحص advisory history يظل UNABLE-TO-VERIFY (offline).
3. **DIR-2026-035 تحديث:** Web Locks نُفذت على مسار إرسال المجموعات فقط (`withCrossTabLock`)؛ **بقية المسارات (1:1 send/receive، group receive/SELF) ما زالت last-write-wins** → الحالة الصحيحة PARTIAL لا FIXED-VERIFIED (تصحيح overclaim سابق).
4. **سطر قديم منسّخ:** الإشارة إلى "Web Locks pending specialist review" في هذا الملف كانت متعارضة مع السجل — تمت المزامنة الآن.
