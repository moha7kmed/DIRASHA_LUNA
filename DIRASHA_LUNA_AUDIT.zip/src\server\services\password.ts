/**
 * Password & PIN Cryptography Service
 * -------------------------------------
 * Multi-layered credential protection:
 *   Layer 1 — scrypt (OWASP-recommended memory-hard KDF): N=16384, r=8, p=1
 *   Layer 2 — Per-secret random 16-byte salt
 *   Layer 3 — Server-side pepper (env-only, never touches the DB)
 *   Layer 4 — crypto.timingSafeEqual comparisons (no timing oracles)
 * Stored formats (versioned):
 *   v1 legacy:    scrypt$v1$<saltB64>$<hashB64>               N=16384, r=8, p=1
 *   v2 current:   scrypt$v2$<N>$<r>$<p>$<saltB64>$<hashB64>   N=32768, r=8, p=3
 * v2 = OWASP-equivalent strong config (32 MiB). v1 stays verifiable;
 * callers re-hash to v2 on successful auth (OWASP: rehash on login).
 */

import crypto from 'crypto';

const PEPPER = process.env.AUTH_PEPPER || process.env.JWT_SECRET
  || (process.env.NODE_ENV === 'production' ? '' : 'dirasha-dev-only-pepper');
if (!PEPPER) {
  throw new Error('FATAL: AUTH_PEPPER (or JWT_SECRET) environment variable is required in production.');
}

const FORMAT_TAG = 'scrypt';
const V2_PARAMS = { N: 2 ** 15, r: 8, p: 3, keyLen: 64 };
const SCRYPT_MAXMEM = 128 * 1024 * 1024;

function peppered(input: string): Buffer {
  return crypto.createHmac('sha256', PEPPER).update(input, 'utf8').digest();
}

/** Hash with CURRENT (v2) params — async (scrypt is intentionally CPU-expensive). */
export async function hashSecret(secret: string): Promise<string> {
  const salt = crypto.randomBytes(16);
  const { N, r, p, keyLen } = V2_PARAMS;
  const key: Buffer = await new Promise((resolve, reject) => {
    crypto.scrypt(peppered(secret), salt, keyLen, { N, r, p, maxmem: SCRYPT_MAXMEM }, (err, derivedKey) => {
      if (err) reject(err);
      else resolve(derivedKey);
    });
  });
  return `${FORMAT_TAG}$v2$${N}$${r}$${p}$${salt.toString('base64')}$${key.toString('base64')}`;
}

/**
 * Constant-time verification against any stored version (v1 or v2). Never throws.
 * Returns details so callers can re-hash legacy v1 credentials up to v2 on
 * successful auth (OWASP Password Storage CS — rehash on login).
 */
export async function verifySecretDetailed(
  secret: string,
  stored: string,
): Promise<{ ok: boolean; version: 'v1' | 'v2' | null; needsRehash: boolean }> {
  try {
    const parts = (stored || '').split('$');
    if (parts[0] !== FORMAT_TAG) return { ok: false, version: null, needsRehash: false };

    let N: number, r: number, p: number, saltB64: string, hashB64: string;
    let version: 'v1' | 'v2';
    if (parts[1] === 'v1' && parts.length === 4) {
      version = 'v1';
      N = 16384; r = 8; p = 1;
      saltB64 = parts[2]; hashB64 = parts[3];
    } else if (parts[1] === 'v2' && parts.length === 7) {
      version = 'v2';
      N = parseInt(parts[2], 10);
      r = parseInt(parts[3], 10);
      p = parseInt(parts[4], 10);
      saltB64 = parts[5]; hashB64 = parts[6];
    } else {
      return { ok: false, version: null, needsRehash: false };
    }

    if (!Number.isFinite(N) || N < 16384 || r < 8 || p < 1) {
      return { ok: false, version: null, needsRehash: false };
    }

    const salt = Buffer.from(saltB64, 'base64');
    const expected = Buffer.from(hashB64, 'base64');
    const actual: Buffer = await new Promise((resolve, reject) => {
      crypto.scrypt(peppered(secret), salt, expected.length, { N, r, p, maxmem: SCRYPT_MAXMEM }, (err, derivedKey) => {
        if (err) reject(err);
        else resolve(derivedKey);
      });
    });
    const ok = expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
    return { ok, version, needsRehash: ok && version === 'v1' };
  } catch {
    return { ok: false, version: null, needsRehash: false };
  }
}

/** Back-compat boolean wrapper. */
export async function verifySecret(secret: string, stored: string): Promise<boolean> {
  return (await verifySecretDetailed(secret, stored)).ok;
}

/** Fast keyed digest for HIGH-ENTROPY secrets (device keys, reset tokens, recovery codes). */
export function digestToken(token: string): string {
  return crypto.createHmac('sha256', PEPPER).update(`tok:${token}`).digest('hex');
}

/* ==================== Password policy (chat-app grade) ==================== */

const COMMON_PASSWORDS = new Set([
  'password', 'password1', '12345678', '123456789', 'qwerty123', '11111111',
  'iloveyou', '00000000', 'abc12345', '1234567890', 'letmein1', 'welcome1',
  'admin123', 'p@ssw0rd', 'passw0rd', 'qwertyuiop',
]);

export function validatePasswordStrength(password: string, username = ''): { isValid: boolean; error?: string } {
  if (typeof password !== 'string' || password.length < 10) {
    return { isValid: false, error: 'كلمة المرور يجب أن تكون 10 أحرف على الأقل.' };
  }
  if (password.length > 128) {
    return { isValid: false, error: 'كلمة المرور طويلة جداً (الحد الأقصى 128 حرفاً لصياغات المرور).' };
  }
  if (username && password.toLowerCase().includes(username.toLowerCase())) {
    return { isValid: false, error: 'كلمة المرور لا يجب أن تحتوي على اسم المستخدم.' };
  }
  if (COMMON_PASSWORDS.has(password.toLowerCase())) {
    return { isValid: false, error: 'كلمة المرور شائعة جداً ويسهل تخمينها. اختر أخرى أقوى.' };
  }
  return { isValid: true };
}

/** Live strength meter (0-4) for the UI. */
export function passwordStrengthScore(password: string): 0 | 1 | 2 | 3 | 4 {
  let score = 0;
  if (!password) return 0;
  if (password.length >= 8) score++;
  if (password.length >= 12) score++;
  if (/[a-z]/.test(password) && /[A-Z]/.test(password)) score++;
  if (/\d/.test(password) && /[^a-zA-Z0-9]/.test(password)) score++;
  return Math.min(4, score) as 0 | 1 | 2 | 3 | 4;
}

/* ==================== PIN policy (recovery credential) ==================== */

const TRIVIAL_PINS = new Set(['000000', '111111', '222222', '333333', '444444', '555555',
  '666666', '777777', '888888', '999999', '123456', '654321', '112233', '121212', '000001']);

export function validatePin(pin: string): { isValid: boolean; error?: string } {
  if (!/^\d{6}$/.test(pin || '')) {
    return { isValid: false, error: 'رمز PIN يجب أن يتكون من 6 أرقام بالضبط.' };
  }
  if (TRIVIAL_PINS.has(pin)) {
    return { isValid: false, error: 'رمز PIN هذا بديهي جداً وسهل التخمين. اختر رمزاً أصعب.' };
  }
  return { isValid: true };
}
