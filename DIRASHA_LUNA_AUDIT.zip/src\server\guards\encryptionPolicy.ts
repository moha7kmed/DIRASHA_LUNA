/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Server-side E2EE ingress policy (external-audit E2EE-03 — P0-B).
 *
 * The client encrypts the MAIN send path, but the external audit proved that
 * edit / schedule / forward / side functions bypassed encryption entirely. The
 * server is now the enforcement point: content ingressing into an E2EE-eligible
 * chat must ALREADY be a Dirasha wire envelope (DIR1:/DIRM1:/DIRG1:). Plaintext
 * is rejected regardless of what the UI did.
 *
 * Eligibility (honest boundaries — mirrors client isE2eeGroupChat):
 *   - group    → eligible (client encrypts ALL group messages via Sender Keys)
 *   - one-to-one → eligible iff BOTH members have registered E2EE devices
 *   - channel  → NOT eligible (documented non-E2EE boundary — never upgraded
 *                silently, never enforced here)
 */

export class E2eeRequiredError extends Error {
  constructor(public reason: string) {
    super(reason);
    this.name = "E2eeRequiredError";
  }
}

/** Dirasha wire envelope prefixes (single source — mirrors client checks). */
const ENVELOPE_PREFIXES = ["DIR1:", "DIRM1:", "DIRG1:"];

export function isWireEnvelope(content: unknown): boolean {
  if (typeof content !== "string") return false;
  return ENVELOPE_PREFIXES.some((p) => content.startsWith(p));
}

/**
 * True when THIS chat is E2EE-eligible server-side. one-to-one eligibility
 * requires both members to have registered E2EE devices (the pairwise path
 * needs a peer bundle; a peer without registrations could never decrypt).
 */
export type E2eeEligibility = 'eligible' | 'ineligible' | 'unknown';

/**
 * Tri-state verdict (DIR-NEW-01): 'eligible' → enforce the envelope gate;
 * 'ineligible' → explicit non-E2EE policy (legacy/channels/no devices);
 * 'unknown' → verification unavailable — the ingress MUST reject. A boolean
 * conflates \"not registered\" with \"cannot verify\", which is exactly the
 * plaintext-on-DB-failure bug.
 */
export async function getE2eeEligibility(db: any, chatId: string): Promise<E2eeEligibility> {
  const chat = db.getChatInfo(chatId);
  if (!chat) return 'unknown';
  if (chat.type === "group") return 'eligible';
  if (chat.type === "one-to-one") {
    const members = await db.getChatMembers(chatId);
    if (!Array.isArray(members) || members.length !== 2) return 'unknown';
    for (const m of members) {
      let count: number;
      try {
        if (typeof db.getE2eeDeviceCount === 'function') {
          count = await db.getE2eeDeviceCount(m.userId);
        } else {
          count = ((await db.getExportE2eePublicKeys(m.userId)) || []).length;
        }
      } catch {
        return 'unknown';
      }
      if (count === 0) return 'ineligible';
    }
    return 'eligible';
  }
  return 'ineligible'; // channels + unknown types: explicit non-E2EE policy
}

/** Boolean wrapper kept for existing callers/tests (see DIR-NEW-01 note). */
export async function isE2eeEligibleChat(db: any, chatId: string): Promise<boolean> {
  return (await getE2eeEligibility(db, chatId)) === 'eligible';
}

/**
 * Ingress enforcement: content entering an E2EE-eligible chat must already be
 * a wire envelope. Call at every message ingress (WS msg:send + REST creates
 * + edit) BEFORE persistence/broadcast.
 */
export class E2eePolicyUnavailableError extends Error {
  constructor(public reason: string) {
    super(reason);
    this.name = 'E2eePolicyUnavailableError';
  }
}

export async function assertEncryptedIngress(db: any, chatId: string, content: unknown): Promise<void> {
  const verdict = await getE2eeEligibility(db, chatId);
  if (verdict === 'unknown') {
    // DIR-NEW-01: verification unavailable ≠ not-encrypted chat. Reject the
    // send with a policy-unavailable error (caller answers 503) — plaintext
    // must NOT ride an unverifiable DM.
    throw new E2eePolicyUnavailableError(
      'لا يمكن التحقق من سياسة التشفير الآن — أعد المحاولة (E2EE_POLICY_UNAVAILABLE).',
    );
  }
  if (verdict === 'eligible' && !isWireEnvelope(content)) {
    throw new E2eeRequiredError(
      'هذه المحادثة مشفرة طرف-لطرف — يجب إرسال محتوى مشفر (DIR1/DIRM1/DIRG1).',
    );
  }
}
