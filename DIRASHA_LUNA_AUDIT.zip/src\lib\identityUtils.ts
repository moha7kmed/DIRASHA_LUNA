/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PrivacySettings, NotificationSettings, AppearanceSettings, ChatSettings, User } from '../types';

// Reserved lists to prevent spam and impersonation
export const RESERVED_USERNAMES = new Set([
  'admin',
  'administrator',
  'owner',
  'system',
  'support',
  'staff',
  'moderator',
  'root',
  'null',
  'undefined',
  'test',
  'google',
  'discord',
  'telegram'
]);

// Impersonation patterns (case insensitive)
export const BAN_DISPLAY_NAME_PATTERNS = [
  /admin/i,
  /administrator/i,
  /support/i,
  /system/i,
  /moderator/i,
  /official/i,
  /security/i,
  /verified/i,
  /dirasha/i,
  /facebook/i,
  /whatsapp/i,
  /telegram/i,
  /discord/i,
  /google/i,
  /owner/i,
  /staff/i,
  /✓/i,
  /✔/i,
  /☑/i,
  /✅/i,
  /✪/i,
  /badge/i
];

/**
 * Normalize username to ensure lowercase, clean, and ignore optical/unicode exploits.
 */
export function normalizeUsername(username: string): string {
  return username
    .toLowerCase()
    .trim()
    .normalize('NFKC') // Normalize unicode characters to equivalents
    .replace(/[^a-z0-9_.]/g, ''); // Allow letters, numbers, underscores, and periods
}

/**
 * Filter the username input representation on-the-fly as the user types
 */
export function normalizeUsernameInput(username: string): string {
  return username
    .toLowerCase()
    .replace(/[^a-z0-9_.]/g, ''); // Filter out all non-alphanumeric/dot/underscore keys
}

/**
 * Validate username constraints (length, characters, and reserved status)
 * Precise rules (similar to Telegram, Instagram, and popular apps):
 * - Length: 3 to 20 characters
 * - Characters allowed: Lowercase/Uppercase English letters, numbers, underscore (_), or period (.)
 * - No start/end with period or underscore
 * - No consecutive periods or underscores (or mixing like ._ or _.)
 * - Case-insensitive
 * - Unique (checked elsewhere)
 */
export function validateUsername(username: string): { isValid: boolean; error?: string } {
  const lowercase = username.toLowerCase().trim();

  // 1. Minimum and maximum length
  if (lowercase.length < 3) {
    return {
      isValid: false,
      error: 'اسم المستخدم قصير جداً (الحد الأدنى 3 أحرف) | Handle is too short (minimum 3 characters).'
    };
  }

  if (lowercase.length > 20) {
    return {
      isValid: false,
      error: 'اسم المستخدم طويل جداً (الحد الأقصى 20 حرفاً) | Handle is too long (maximum 20 characters).'
    };
  }

  // 2. Allowed characters pattern
  if (!/^[a-zA-Z0-9_.]+$/.test(username)) {
    return {
      isValid: false,
      error: 'يجب أن يحتوي اسم المستخدم على أحرف إنجليزية، أرقام، شرطة سفلية (_) أو نقطة (.) فقط | Handle must contain only English letters, numbers, underscores, or periods.'
    };
  }

  // 3. No starting/ending with a special character
  if (/^[._]/.test(lowercase)) {
    return {
      isValid: false,
      error: 'لا يمكن لاسم المستخدم أن يبدأ بنقطة أو شرطة سفلية | Handle cannot start with a period or underscore.'
    };
  }

  if (/[._]$/.test(lowercase)) {
    return {
      isValid: false,
      error: 'لا يمكن لاسم المستخدم أن ينتهي بنقطة أو شرطة سفلية | Handle cannot end with a period or underscore.'
    };
  }

  // 4. No consecutive symbols (e.g. .., __, ._, _.)
  if (lowercase.includes('..') || lowercase.includes('__') || lowercase.includes('._') || lowercase.includes('_.')) {
    return {
      isValid: false,
      error: 'لا يمكن استخدام الرموز الخاصة متتالية | Consecutive periods or underscores are not permitted.'
    };
  }

  // 5. Reserved name checks
  if (RESERVED_USERNAMES.has(lowercase)) {
    return {
      isValid: false,
      error: 'اسم المستخدم هذا محجوز ومحمي | This handle is protected or reserved.'
    };
  }

  return { isValid: true };
}

/**
 * Stage 3 Display Name Quality Assessment
 */
export function evaluateDisplayNameQuality(name: string): { rating: 'Excellent' | 'Good' | 'Weak'; reason: string; isValid: boolean } {
  const trimmed = name.trim();
  
  if (trimmed.length < 3) {
    return { isValid: false, rating: 'Weak', reason: 'الاسم قصير جداً (الحد الأدنى 3 أحرف) | Display name is too short (min 3 characters).' };
  }
  if (trimmed.length > 35) {
    return { isValid: false, rating: 'Weak', reason: 'الاسم طويل جداً (الحد الأقصى 35 حرفاً) | Display name is too long (max 35 characters).' };
  }

  // Reject purely repetitive digits/characters/dots (aaaaaa, 111111, ....., xxxxx, test test, asdfgh)
  const isRepetitive = /^(.)\1+$/.test(trimmed.replace(/\s+/g, ''));
  if (isRepetitive) {
    return { isValid: false, rating: 'Weak', reason: 'الاسم يحتوي على تكرار عشوائي غير مسموح به | Prohibited repetitive sequences detected.' };
  }

  const lowercase = trimmed.toLowerCase();
  
  // Specific banned sequences like asdfg, xxxxx, test test
  if (['aaaaaa', '111111', '......', 'xxxxx', 'test test', 'asdfgh', 'asdfghjk', 'qwerty', '123456'].some(seq => lowercase.includes(seq))) {
    return { isValid: false, rating: 'Weak', reason: 'اللقب يحتوي على أحرف أو أرقام تسلسلية وهمية | Common prohibited pattern detected.' };
  }

  // Check pattern representation to prevent forbidden words / impersonation
  const claimsAdmin = BAN_DISPLAY_NAME_PATTERNS.some(regex => regex.test(lowercase));
  if (claimsAdmin) {
    return { isValid: false, rating: 'Weak', reason: 'الاسم يحتوي على مصطلحات محمية أو محظورة للتطبيق | Protected or prohibited terminology detected.' };
  }

  // Evaluatation Ratings:
  // Excellent: Structured first & last name separated by whitespace, starting with capitals, unique length > 8
  const parts = trimmed.split(' ');
  const hasMultipleNames = parts.length >= 2 && parts[0].length >= 3 && parts[1].length >= 3;
  const isOptimalLength = trimmed.length >= 8 && trimmed.length <= 26;

  if (hasMultipleNames && isOptimalLength) {
    return {
      isValid: true,
      rating: 'Excellent',
      reason: 'تركيبة ممتازة ومتكاملة للقب | Outstanding fully-structured identifier foundation.'
    };
  } else if (trimmed.length >= 4) {
    return {
      isValid: true,
      rating: 'Good',
      reason: 'الاسم معتمد وصالح للاستخدام | Valid format. Multi-part recommended for higher clarity.'
    };
  } else {
    return {
      isValid: true,
      rating: 'Weak',
      reason: 'الاسم قصير نسبياً، نوصي بكتابة اسم ثنائي واضح | Identifier is relatively concise. Formal foundation recommended.'
    };
  }
}

/**
 * Sanitize and validate Display Names to stop emoji flooding, fake verification badges,
 * invisible control codes, duplicate whitespace, and unreadable character sequences.
 */
export function sanitizeDisplayName(name: string): string {
  if (!name) return 'Dirasha User';

  // 1. Remove invisible / control characters & zero-width spaces
  let cleaned = name
    .replace(/[\u200B-\u200D\uFEFF]/g, '') // Zero width spaces
    .replace(/[\x00-\x1F\x7F-\x9F]/g, ''); // Control characters

  // 2. Clean duplicate whitespace
  cleaned = cleaned.replace(/\s+/g, ' ').trim();

  // 3. Prevent fake verified flags/badges and admin impersonation
  for (const pattern of BAN_DISPLAY_NAME_PATTERNS) {
    cleaned = cleaned.replace(pattern, '');
  }

  // 4. Ensure duplicate characters are capped (e.g. restrict flooding of "!!!!!" or ".....")
  cleaned = cleaned.replace(/([!.\-?_~])\1{2,}/g, '$1$1'); // max 2 consecutive punctuation symbols

  // 5. Cap consecutive emojis to prevent visual performance stress and visual clutter
  // General Emoji regex matching standard sequences
  const emojiRegex = /[\u{1F300}-\u{1F64F}\u{1F680}-\u{1F6FF}\u{1F1E6}-\u{1F1FF}\u{1F900}-\u{1F9FF}\u{2600}-\u{27BF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FAFF}\u{2000}-\u{32FF}]/gu;
  
  let finalString = '';
  let emojiCount = 0;
  
  for (const char of cleaned) {
    if (emojiRegex.test(char)) {
      emojiCount++;
      if (emojiCount <= 2) {
        finalString += char;
      }
    } else {
      emojiCount = 0;
      finalString += char;
    }
  }
  cleaned = finalString.trim();

  // 6. Ensure length is bounded
  if (cleaned.length > 50) {
    cleaned = cleaned.substring(0, 50).trim();
  }

  // 7. If it is completely empty or symbols-only, fall back
  if (!cleaned || cleaned.replace(/[!.\-?_~*()#@]/g, '').trim().length === 0) {
    return 'Dirasha User';
  }

  return cleaned;
}

/**
 * Strong validation check for display name
 */
export function validateDisplayName(name: string): { isValid: boolean; error?: string } {
  const trimmed = name.trim();
  
  if (trimmed.length < 3) {
    return { isValid: false, error: 'الاسم قصير جداً (الحد الأدنى 3 أحرف) | Display name is too short (min 3 characters).' };
  }
  if (trimmed.length > 35) {
    return { isValid: false, error: 'الاسم طويل جداً (الحد الأقصى 35 حرفاً) | Display name is too long (max 35 characters).' };
  }

  // Clean or check for invisible control characters.
  if (/[\u200B-\u200D\uFEFF]/.test(trimmed)) {
    return {
      isValid: false,
      error: 'يحتوي الاسم على رموز غير مرئية أو مسافات خفية غير مسموح بها | Prohibited invisible characters detected.'
    };
  }

  // Ensure double spaces are blocked
  if (trimmed.includes('  ')) {
    return {
      isValid: false,
      error: 'لا يُسمح باستخدام مسافات مزدوجة متتالية | Multiple consecutive spaces are not allowed.'
    };
  }

  // Check impersonation explicitly
  const normalizedLower = trimmed.toLowerCase();
  const claimsAdmin = BAN_DISPLAY_NAME_PATTERNS.some(regex => regex.test(normalizedLower));
  if (claimsAdmin) {
    return { isValid: false, error: 'الاسم يحتوي على مصطلحات محمية أو محظورة للتطبيق | Protected or prohibited terminology detected.' };
  }

  return { isValid: true };
}

/**
 * Get initial default partition settings
 */
export function createDefaultUser(
  uid: string,
  username: string,
  displayName: string,
  email: string,
  photoURL: string
): Omit<User, 'onlineStatus' | 'lastSeen'> {
  const now = new Date().toISOString();
  return {
    id: uid,
    uid,
    phoneNumber: '', // provisioned via OTP flow; legacy factory keeps it empty
    profileCompleted: true,
    username: normalizeUsername(username),
    displayName: sanitizeDisplayName(displayName),
    email: '',
    avatarUrl: photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150&q=80',
    photoURL: photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150&q=80',
    bio: 'Secured node initialized.',
    verified: false,
    createdAt: now,
    updatedAt: now,
    privacySettings: {
      lastSeenVisibility: 'everyone',
      avatarVisibility: 'everyone',
      statusVisibility: 'everyone',
      searchVisibility: 'everyone',
      aboutVisibility: 'everyone',
      allowDirectMessages: 'everyone',
      allowGroupInvites: 'everyone'
    },
    notificationSettings: {
      enabled: true,
      privateMessages: true,
      groupMessages: true,
      soundEnabled: true,
      soundVolume: 80,
      vibration: true,
      desktopNotifications: true
    },
    appearanceSettings: {
      theme: 'dark',
      fontSize: 'medium',
      compactMode: false,
      density: 'comfortable',
      animationsEnabled: true
    },
    chatSettings: {
      enterToSend: true,
      mediaAutoDownload: true,
      readReceipts: true
    },
    blockedUsers: [],
    mutedUsers: [],
    usernameChangeHistory: {
      lastChangedAt: now,
      count: 0
    }
  };
}
