import { useEffect, useState, useCallback } from 'react';
import { X, Loader2, Crown, Shield, UserPlus, LogOut, Trash2, UserMinus, Check, Users, Ban } from 'lucide-react';
import { getAccessToken } from '../lib/token_vault';

interface Props {
  chatId: string;
  onClose: () => void;
  onLeft: () => void;
}

/**
 * Group settings panel (WhatsApp/TG parity): edit info (permission-gated),
 * members with roles, add/remove, promote/demote, permissions (who can send
 * / edit info), leave (owner transfer) and delete (owner).
 */
export function GroupSettingsPanel({ chatId, onClose, onLeft }: Props) {
  const [group, setGroup] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [adding, setAdding] = useState('');
  const [searchRes, setSearchRes] = useState<any[]>([]);
  const [confirmLeave, setConfirmLeave] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [inviteCode, setInviteCode] = useState<string | null>(null);
  const [joinRequests, setJoinRequests] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [restrictedCycle, setRestrictedCycle] = useState<Record<string, number>>({});
  const [showRightsFor, setShowRightsFor] = useState<string | null>(null);
  const [adminRights, setAdminRights] = useState<Record<string, any>>({});
  const [pastMembers, setPastMembers] = useState<any[]>([]);
  const [inviteLimit, setInviteLimit] = useState(0);
  const [editing, setEditing] = useState<{ name?: string; description?: string }>({});

  const load = useCallback(async () => {
    try {
      const res = await fetch(`/api/chats/${chatId}/group`, { headers: { Authorization: `Bearer ${getAccessToken()}` } });
      const data = await res.json();
      if (res.ok) setGroup(data.group);
      else setError(data.error || 'تعذر تحميل المجموعة.');
    } catch { setError('خطأ في الاتصال.'); }
  }, [chatId]);

  useEffect(() => { load(); }, [load]);

  const act = async (fn: () => Promise<Response>, okMsg?: string) => {
    setBusy(true); setError(null);
    try {
      const res = await fn();
      const d = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(d.error || 'فشل.');
      if (okMsg) setGroup(g => ({ ...g, ...(d.group || {}) }));
      await load();
      return true;
    } catch (e: any) {
      setError(e.message);
      return false;
    } finally {
      setBusy(false);
    }
  };

  if (!group && !error) {
    return (
      <div className="fixed inset-0 z-[2000] bg-black/70 flex items-center justify-center">
        <Loader2 className="animate-spin text-zinc-400" size={28} />
      </div>
    );
  }

  const me = (() => { try { return JSON.parse(localStorage.getItem('dirasha_user') || '{}'); } catch { return {}; } })();
  const myRole = group?.members?.find((m: any) => m.userId === me.id)?.role || 'member';
  const isOwner = myRole === 'owner';
  const isAdmin = myRole === 'owner' || myRole === 'admin';
  const canEditInfo = isAdmin || group?.permissions?.whoCanEditInfo === 'all';

  // Load join requests + stats for admins (after role resolution)
  useEffect(() => {
    if (!isAdmin || !group) return;
    (async () => {
      try {
        const jr = await fetch(`/api/chats/${chatId}/join-requests`, { headers: { Authorization: `Bearer ${getAccessToken()}` } });
        if (jr.ok) setJoinRequests((await jr.json()).requests || []);
        const st = await fetch(`/api/chats/${chatId}/stats`, { headers: { Authorization: `Bearer ${getAccessToken()}` } });
        if (st.ok) setStats(await st.json());
        const pm = await fetch(`/api/chats/${chatId}/past-members`, { headers: { Authorization: `Bearer ${getAccessToken()}` } });
        if (pm.ok) setPastMembers((await pm.json()).pastMembers || []);
        // load current granular rights for admins
        const rightsMap: Record<string, any> = {};
        (group?.members || []).filter((m: any) => m.role === 'admin').forEach((m: any) => {
          rightsMap[m.userId] = { addMembers: true, editInfo: true, pinMessages: true, deleteMessages: true };
        });
        setAdminRights(rightsMap);
      } catch { /* non-fatal */ }
    })();
  }, [isAdmin, group, chatId]);

  const searchUsers = async (q: string) => {
    setAdding(q);
    if (!q.trim()) { setSearchRes([]); return; }
    try {
      const res = await fetch(`/api/users/search?query=${encodeURIComponent(q)}`, { headers: { Authorization: `Bearer ${getAccessToken()}` } });
      const d = await res.json();
      const members = new Set((group?.members || []).map((m: any) => m.userId));
      setSearchRes((d.results || d.users || []).filter((u: any) => !members.has(u.id)));
    } catch { setSearchRes([]); }
  };

  return (
    <div className="fixed inset-0 z-[2000] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div className="w-full max-w-md max-h-[85vh] overflow-y-auto bg-zinc-900 border border-white/10 rounded-3xl" onClick={(e) => e.stopPropagation()}>
        {!group ? (
          <div className="p-6 text-center text-red-400 text-sm">{error}</div>
        ) : (
          <div className="p-5 space-y-5">
            <div className="flex items-center justify-between">
              <h3 className="text-white font-bold text-sm flex items-center gap-2"><Users /> إعدادات المجموعة</h3>
              <button onClick={onClose} className="text-zinc-400 hover:text-white"><X size={18} /></button>
            </div>

            {/* Info (permission-gated editing) */}
            {isAdmin && stats && (
              <div className="bg-white/[0.03] rounded-2xl px-4 py-3 grid grid-cols-3 gap-2 text-center">
                <div>
                  <p className="text-white font-black text-sm">{stats.totalMessages}</p>
                  <p className="text-[9px] text-zinc-500">رسالة</p>
                </div>
                <div>
                  <p className="text-white font-black text-sm">{stats.messagesLast7Days}</p>
                  <p className="text-[9px] text-zinc-500">آخر 7 أيام</p>
                </div>
                <div>
                  <p className="text-white font-black text-sm">{stats.memberCount}</p>
                  <p className="text-[9px] text-zinc-500">عضو</p>
                </div>
              </div>
            )}

            {/* Info (permission-gated editing) */}
            <div className="space-y-2">
              <input
                value={editing.name ?? group.name ?? ''}
                onChange={(e) => setEditing({ ...editing, name: e.target.value })}
                disabled={!canEditInfo}
                className="w-full bg-zinc-800/80 border border-white/10 rounded-xl px-3 py-2.5 text-white font-bold text-sm outline-none disabled:opacity-60"
              />
              <textarea
                value={editing.description ?? group.description ?? ''}
                onChange={(e) => setEditing({ ...editing, description: e.target.value })}
                disabled={!canEditInfo}
                placeholder="وصف المجموعة..."
                rows={2}
                className="w-full bg-zinc-800/80 border border-white/10 rounded-xl px-3 py-2.5 text-xs text-zinc-300 outline-none disabled:opacity-60 resize-none"
              />
              {canEditInfo && (editing.name !== undefined || editing.description !== undefined) && (
                <button
                  onClick={async () => {
                    const ok = await act(() => fetch(`/api/chats/${chatId}/info`, { method: 'PUT', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` }, body: JSON.stringify(editing) }));
                    if (ok) setEditing({});
                  }}
                  disabled={busy}
                  className="w-full py-2 rounded-xl bg-blue-500/20 text-blue-300 border border-blue-500/30 text-xs font-bold"
                >
                  حفظ المعلومات
              </button>
              )}
            </div>

            {/* Permissions (admins only) */}
            {isAdmin && (
              <div className="space-y-2 border-t border-white/5 pt-4">
                <p className="text-[11px] font-bold text-white/50 uppercase tracking-widest">أذونات المجموعة</p>
                {([
                  { key: 'whoCanSend', label: 'من يمكنه الإرسال', all: 'الكل', admins: 'المشرفون فقط' },
                  { key: 'whoCanEditInfo', label: 'من يمكنه تعديل المعلومات', all: 'الكل', admins: 'المشرفون فقط' },
                ] as const).map((p) => (
                  <div key={p.key} className="flex items-center justify-between gap-2 bg-white/[0.03] rounded-xl px-3 py-2">
                    <span className="text-xs text-zinc-300">{p.label}</span>
                    <div className="flex gap-1">
                      {(['all', 'admins'] as const).map(v => {
                        const active = (group.permissions?.[p.key] || (p.key === 'whoCanSend' ? 'all' : 'admins')) === v;
                        return (
                          <button
                            key={v}
                            onClick={() => act(() => fetch(`/api/chats/${chatId}/permissions`, { method: 'PUT', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` }, body: JSON.stringify({ [p.key]: v }) }))}
                            className={`px-2.5 py-1 rounded-lg text-[10px] font-bold ${active ? 'bg-blue-500/25 text-blue-300' : 'bg-white/5 text-zinc-400'}`}
                          >
                            {v === 'all' ? p.all : p.admins}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Invite code (admins) — WhatsApp parity */}
            {isAdmin && (
              <div className="space-y-2 border-t border-white/5 pt-4">
                <p className="text-[11px] font-bold text-white/50 uppercase tracking-widest">رابط الدعوة</p>
                <button
                  onClick={async () => {
                    try {
                      const res = await fetch(`/api/chats/${chatId}/invite`, { method: 'POST', headers: { Authorization: `Bearer ${getAccessToken()}` } });
                      const d = await res.json();
                      if (d.code) setInviteCode(d.code);
                    } catch { /* handled by error state */ }
                  }}
                  className="w-full py-2.5 rounded-xl bg-blue-500/15 text-blue-300 border border-blue-500/25 text-xs font-bold"
                >
                  {inviteCode ? 'تحديث عرض الكود' : 'إنشاء كود دعوة'}
                </button>
                {inviteCode && (
                  <div className="flex items-center gap-2 bg-black/30 rounded-xl px-3 py-2">
                    <code className="flex-1 text-[11px] font-mono text-emerald-300 break-all">{inviteCode}</code>
                    <button
                      onClick={() => { try { navigator.clipboard.writeText(inviteCode); } catch {} }}
                      className="text-[10px] font-bold px-2 py-1 rounded-lg bg-white/10 text-zinc-200 hover:bg-white/20"
                    >
                      نسخ
                    </button>
                  </div>
                )}
                {/* Invite usage limit (WhatsApp parity) */}
                {inviteCode && (
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-zinc-400 shrink-0">حد الاستخدام:</span>
                    {[0, 10, 50, 100].map((n) => (
                      <button
                        key={n}
                        onClick={() => fetch(`/api/chats/${chatId}/invite`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` }, body: JSON.stringify({ usageLimit: n }) })}
                        className={`px-2 py-1 rounded-lg text-[10px] font-bold ${inviteLimit === n ? 'bg-blue-500/25 text-blue-300' : 'bg-white/5 text-zinc-400'}`}
                      >
                        {n === 0 ? 'بلا حد' : n}
                      </button>
                    ))}
                  </div>
                )}
                {/* Telegram-style expiry options */}
                {inviteCode && (
                  <div className="flex gap-1.5">
                    {[
                      { label: 'يوم', val: '1d' },
                      { label: 'أسبوع', val: '1w' },
                      { label: 'دائم', val: 'never' },
                    ].map((o) => (
                      <button
                        key={o.val}
                        onClick={async () => {
                          try {
                            const res = await fetch(`/api/chats/${chatId}/invite`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` }, body: JSON.stringify({ expiresIn: o.val }) });
                            const d = await res.json();
                            if (d.code) setInviteCode(d.code);
                          } catch { /* error state */ }
                          setInviteLimit(0);
                        }}
                        className="flex-1 py-1.5 rounded-lg text-[10px] font-bold bg-white/5 text-zinc-300 hover:bg-white/10 border border-white/10"
                      >
                        صلاحية: {o.label}
                      </button>
                    ))}
                  </div>
                )}
                {/* Protected content (Telegram parity) */}
                <div className="flex items-center justify-between gap-2 bg-white/[0.03] rounded-xl px-3 py-2">
                  <span className="text-xs text-zinc-300">حماية المحتوى (منع النسخ والحفظ)</span>
                  <button
                    onClick={() => act(() => fetch(`/api/chats/${chatId}/protected`, { method: 'PUT', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` }, body: JSON.stringify({ enabled: !group.permissions?.protectedContent }) }))}
                    className={`h-5 w-9 rounded-full p-0.5 transition-colors ${group.permissions?.protectedContent ? 'bg-blue-600' : 'bg-white/10'}`}
                  >
                    <div className={`h-4 w-4 rounded-full bg-white transition-transform ${group.permissions?.protectedContent ? '-translate-x-4' : 'translate-x-0'}`} />
                  </button>
                </div>

                {/* Slow mode (Telegram parity) */}
                <div className="flex items-center justify-between gap-2 bg-white/[0.03] rounded-xl px-3 py-2">
                  <span className="text-xs text-zinc-300">الوضع البطيء</span>
                  <div className="flex gap-1">
                    {[0, 10, 30, 60, 300].map((s) => {
                      const active = Number(group.permissions?.slowMode || 0) === s;
                      return (
                        <button
                          key={s}
                          onClick={() => act(() => fetch(`/api/chats/${chatId}/slow-mode`, { method: 'PUT', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` }, body: JSON.stringify({ seconds: s }) }))}
                          className={`px-2 py-1 rounded-lg text-[10px] font-bold ${active ? 'bg-blue-500/25 text-blue-300' : 'bg-white/5 text-zinc-400'}`}
                        >
                          {s === 0 ? 'إيقاف' : s + 'ث'}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Join approval toggle + pending requests (Telegram parity) */}
                <div className="flex items-center justify-between gap-2 bg-white/[0.03] rounded-xl px-3 py-2">
                  <span className="text-xs text-zinc-300">موافقة المشرف قبل الانضمام</span>
                  <button
                    onClick={() => act(() => fetch(`/api/chats/${chatId}/permissions`, { method: 'PUT', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` }, body: JSON.stringify({ joinApproval: !group.permissions?.joinApproval }) }))}
                    className={`h-5 w-9 rounded-full p-0.5 transition-colors ${group.permissions?.joinApproval ? 'bg-blue-600' : 'bg-white/10'}`}
                  >
                    <div className={`h-4 w-4 rounded-full bg-white transition-transform ${group.permissions?.joinApproval ? '-translate-x-4' : 'translate-x-0'}`} />
                  </button>
                </div>
                {(group.permissions?.joinApproval || joinRequests.length > 0) && joinRequests.length > 0 && (
                  <div className="space-y-1">
                    {joinRequests.map((r: any) => (
                      <div key={r.userId} className="flex items-center gap-2 bg-black/20 rounded-xl px-2 py-1.5">
                        <span className="flex-1 text-[11px] text-white">{r.displayName} <span className="text-zinc-500">@{r.username}</span></span>
                        <button onClick={() => act(() => fetch(`/api/chats/${chatId}/join-requests/${r.userId}`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` }, body: JSON.stringify({ approve: true }) })).then(ok => ok && load())} className="text-[10px] font-bold px-2 py-1 rounded-lg bg-emerald-500/20 text-emerald-300">قبول</button>
                        <button onClick={() => act(() => fetch(`/api/chats/${chatId}/join-requests/${r.userId}`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` }, body: JSON.stringify({ approve: false }) })).then(ok => ok && load())} className="text-[10px] font-bold px-2 py-1 rounded-lg bg-red-500/15 text-red-300">رفض</button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Members */}
            <div className="space-y-2 border-t border-white/5 pt-4">
              <p className="text-[11px] font-bold text-white/50 uppercase tracking-widest">الأعضاء ({group.members.length})</p>
              {group.members.map((m: any) => (
                <div key={m.userId} className="flex items-center gap-3 p-2 rounded-xl hover:bg-white/[0.03]">
                  <img src={m.avatarUrl || `https://api.dicebear.com/9.x/initials/png?seed=${encodeURIComponent(m.displayName)}`} alt="" className="w-9 h-9 rounded-full object-cover" />
                  <div className="flex-1 text-right">
                    <p className="text-[13px] text-white font-bold flex items-center gap-1 justify-end">
                      {m.displayName}
                      {m.role === 'owner' && <Crown size={12} className="text-amber-400" />}
                      {m.role === 'admin' && <Shield size={12} className="text-blue-400" />}
                    </p>
                    <p className="text-[10px] text-zinc-500">@{m.username} · {m.role === 'owner' ? 'مالك' : m.role === 'admin' ? 'مشرف' : 'عضو'}</p>
                  </div>
                  {isOwner && m.role !== 'owner' && (
                    <>
                      <button
                        onClick={() => setShowRightsFor(showRightsFor === m.userId ? null : m.userId)}
                        className="text-[10px] font-bold px-2 py-1 rounded-lg bg-white/5 text-zinc-300 hover:bg-white/10"
                        title="صلاحيات المشرف"
                      >
                        صلاحيات
                      </button>
                      <button
                        onClick={() => act(() => fetch(`/api/chats/${chatId}/promote`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` }, body: JSON.stringify({ userId: m.userId, role: m.role === 'admin' ? 'member' : 'admin' }) }))}
                        className="text-[10px] font-bold px-2 py-1 rounded-lg bg-white/5 text-zinc-300 hover:bg-white/10"
                      >
                        {m.role === 'admin' ? 'تخفيض' : 'ترقية'}
                      </button>
                    </>
                  )}
                  {showRightsFor === m.userId && m.role === 'admin' && (
                    <div className="w-full col-span-full bg-black/20 rounded-xl p-2.5 space-y-1.5">
                      {([
                        { k: 'addMembers', l: 'إضافة أعضاء' },
                        { k: 'editInfo', l: 'تعديل المعلومات' },
                        { k: 'pinMessages', l: 'تثبيت الرسائل' },
                        { k: 'deleteMessages', l: 'حذف الرسائل' },
                      ] as const).map((r) => {
                        const cur = adminRights[m.userId]?.[r.k] ?? true;
                        return (
                          <label key={r.k} className="flex items-center justify-between text-[11px] text-zinc-300">
                            {r.l}
                            <input
                              type="checkbox"
                              checked={cur}
                              onChange={(e) => {
                                setAdminRights(prev => ({ ...prev, [m.userId]: { ...(prev[m.userId] || { addMembers: true, editInfo: true, pinMessages: true, deleteMessages: true }), [r.k]: e.target.checked } }));
                                fetch(`/api/chats/${chatId}/admin-rights`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` }, body: JSON.stringify({ userId: m.userId, right: r.k, value: e.target.checked }) });
                              }}
                              className="accent-blue-500"
                            />
                          </label>
                        );
                      })}
                    </div>
                  )}
                  {isAdmin && m.role !== 'owner' && (
                    <>
                      <button
                        onClick={() => act(() => fetch(`/api/chats/${chatId}/restrict`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` }, body: JSON.stringify({ userId: m.userId, minutes: m.userId === restrictedCycle[m.userId] ? -1 : (restrictedCycle[m.userId] || 0) === 0 ? 10 : (restrictedCycle[m.userId]) === 10 ? 60 : (restrictedCycle[m.userId]) === 60 ? 1440 : -1 }) })).then(ok => { if (ok) setRestrictedCycle(c => ({ ...c, [m.userId]: ((c[m.userId] || 0) === 0 ? 10 : (c[m.userId]) === 10 ? 60 : (c[m.userId]) === 60 ? 1440 : 0) })); })}
                        className="text-[10px] font-bold px-2 py-1 rounded-lg bg-amber-500/10 text-amber-300 hover:bg-amber-500/20"
                        title="كتم من الإرسال داخل المجموعة"
                      >
                        {restrictedCycle[m.userId] ? `كتم ${restrictedCycle[m.userId] === -1 ? 'دائم' : restrictedCycle[m.userId] + 'د'}` : 'كتم'}
                      </button>
                      <button
                        onClick={() => act(() => fetch(`/api/chats/${chatId}/ban`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` }, body: JSON.stringify({ userId: m.userId }) })).then(ok => ok && load())}
                        className="text-red-400 hover:text-red-300 p-1"
                        title="حظر نهائي"
                      >
                        <Ban size={14} />
                      </button>
                    </>
                  )}
                  {isAdmin && m.role !== 'owner' && m.userId !== me.id && (
                    <button
                      onClick={() => act(() => fetch(`/api/chats/${chatId}/members/${m.userId}`, { method: 'DELETE', headers: { Authorization: `Bearer ${getAccessToken()}` } }))}
                      className="text-red-400 hover:text-red-300 p-1"
                      title="إزالة"
                    >
                      <UserMinus size={14} />
                    </button>
                  )}
                </div>
              ))}
            </div>

            {/* Add member (admins) */}
            {isAdmin && (
              <div className="space-y-2 border-t border-white/5 pt-4">
                <p className="text-[11px] font-bold text-white/50 uppercase tracking-widest flex items-center gap-1"><UserPlus size={12} /> إضافة عضو</p>
                <input
                  value={adding}
                  onChange={(e) => searchUsers(e.target.value)}
                  placeholder="ابحث باسم المستخدم..."
                  className="w-full bg-zinc-800/80 border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none"
                />
                {searchRes.map((u: any) => (
                  <button
                    key={u.id}
                    onClick={() => act(() => fetch(`/api/chats/${chatId}/members`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` }, body: JSON.stringify({ userIds: [u.id] }) })).then(ok => ok && setSearchRes([]))}
                    className="w-full flex items-center gap-2 p-2 rounded-xl bg-white/[0.03] hover:bg-white/10 text-right"
                  >
                    <img src={u.avatarUrl} alt="" className="w-7 h-7 rounded-full object-cover" />
                    <span className="text-xs text-white flex-1">{u.displayName} <span className="text-zinc-500">@{u.username}</span></span>
                    <Check size={14} className="text-emerald-400" />
                  </button>
                ))}
              </div>
            )}

            {/* Past members (WhatsApp parity) */}
            {isAdmin && pastMembers.length > 0 && (
              <div className="space-y-2 border-t border-white/5 pt-4">
                <p className="text-[11px] font-bold text-white/50 uppercase tracking-widest">الأعضاء السابقون ({pastMembers.length})</p>
                {pastMembers.map((p: any) => {
                  const isBanned = (group as any)?.bannedUserIds?.includes?.(p.userId);
                  return (
                    <div key={p.userId} className="flex items-center gap-2 bg-white/[0.03] rounded-xl px-3 py-2">
                      <div className="flex-1 text-right">
                        <p className="text-[12px] text-zinc-300">{p.displayName}</p>
                        <p className="text-[9px] text-zinc-500">{p.removedBy ? `أزاله ${p.removedBy}` : 'غادر'} · {new Date(p.leftAt).toLocaleDateString()}</p>
                      </div>
                      {isBanned && <span className="text-[9px] text-red-400 font-bold">محظور</span>}
                      {!isBanned && (
                        <button
                          onClick={() => act(() => fetch(`/api/chats/${chatId}/members`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAccessToken()}` }, body: JSON.stringify({ userIds: [p.userId] }) })).then(ok => ok && load())}
                          className="text-[10px] font-bold px-2 py-1 rounded-lg bg-blue-500/15 text-blue-300"
                        >
                          إعادة إضافة
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {/* Danger zone */}
            <div className="border-t border-white/5 pt-4 space-y-2">
              <button
                onClick={() => setConfirmLeave(true)}
                className="w-full py-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20 text-xs font-bold flex items-center justify-center gap-2"
              >
                <LogOut size={14} /> مغادرة المجموعة
              </button>
              {isOwner && (
                <button
                  onClick={() => setConfirmDelete(true)}
                  className="w-full py-2.5 rounded-xl bg-red-500/10 text-red-400 border border-red-500/20 text-xs font-bold flex items-center justify-center gap-2"
                >
                  <Trash2 size={14} /> حذف المجموعة
                </button>
              )}
              {confirmLeave && (
                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 space-y-2">
                  <p>هل تريد المغادرة؟{isOwner ? ' سينتقل الملكية لعضو آخر.' : ''}</p>
                  <div className="flex gap-2">
                    <button onClick={() => setConfirmLeave(false)} className="flex-1 py-1.5 rounded-lg bg-white/5 text-zinc-300">إلغاء</button>
                    <button
                      onClick={async () => {
                        const ok = await act(() => fetch(`/api/chats/${chatId}/leave`, { method: 'POST', headers: { Authorization: `Bearer ${getAccessToken()}` } }));
                        if (ok) onLeft();
                      }}
                      className="flex-1 py-1.5 rounded-lg bg-amber-500 text-black font-black"
                    >
                      مغادرة
                    </button>
                  </div>
                </div>
              )}
              {confirmDelete && (
                <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-xs text-red-300 space-y-2">
                  <p>سيتم حذف المجموعة وكل رسائلها نهائياً.</p>
                  <div className="flex gap-2">
                    <button onClick={() => setConfirmDelete(false)} className="flex-1 py-1.5 rounded-lg bg-white/5 text-zinc-300">إلغاء</button>
                    <button
                      onClick={async () => {
                        const ok = await act(() => fetch(`/api/chats/${chatId}`, { method: 'DELETE', headers: { Authorization: `Bearer ${getAccessToken()}` } }));
                        if (ok) onLeft();
                      }}
                      className="flex-1 py-1.5 rounded-lg bg-red-500 text-white font-black"
                    >
                      حذف نهائي
                    </button>
                  </div>
                </div>
              )}
            </div>

            {error && <p className="text-red-400 text-xs">{error}</p>}
          </div>
        )}
      </div>
    </div>
  );
}
